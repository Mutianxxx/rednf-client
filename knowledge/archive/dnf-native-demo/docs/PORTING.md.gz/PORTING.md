> 2026-11-02：新增[面向对象架构拆分大纲](ARCHITECTURE-REFACTOR-OUTLINE.md)，保留平台无关内容/模拟与可替换渲染后端，准备渐进整理现有C++。本轮只有文档，Godot移植保持暂停，现有来源/存档/候选保护规则不变。

<!-- equipment458-live-status -->
# 当前装备资格与正常学习预算节点

阶段：`paused_after_original_o3_debugger1`；会话：`None`。预计459份编译输入、181份完整报告，独立构建`cache/seven-job-equipment458-build`。最新已验证体验仍按实际完成记录：`checkpoints/20261020T224815926748Z-mage-upper457`；统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

**已按用户要求暂停。** 当前一轮已结束；不再启动构建、测试、备份发布或后续节点。恢复先读本节点PAUSE-SUMMARY-20261021.md和PAUSE-RECEIPT.json，等待用户继续。

女法师天击457已完成1142成员源码/产物/证据备份，两遍哈希零差异。当前仅继续装备单ID技能资格、正常SP/TP预算及目标私有恢复/GSD预检；分支赠送与真实30200条件眩晕不混入完成。女格斗普通副本死亡失败保留，七职业全普通副本/完整技能和最终十职业beta尚未完成。原资料、正常存档和历史候选保护，构建/运行/备份串行；前台画面、听音、手感与原版动态比较待用户。

恢复读`dnf-native-demo/reports/seven-job-world-20261020/equipment458-integration/RUNNING-STATE.json`、本节点PROGRESS与实际日志。先poll实际会话，不重跑已结束attempt，不删除他人锁或覆盖运行产物。下方旧记录为历史。
<!-- /equipment458-live-status -->

<!-- mage457-live-status -->
# 当前女法师天击节点（以实际收据为准）

阶段：`mage457_complete`；会话：`None`。候选输入预期457份、完整报告180份，构建目录`cache/seven-job-mage-upper457-build`。最新已验证体验：`checkpoints/20261020T224815926748Z-mage-upper457`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

女格斗原ordinary1死亡及观察复现完整保留；该失败不算正常游玩通过。Mage是独立功能验证，七职业全部普通副本、完整技能及最终十职业beta仍未完成。所有新构建、测试、审计和备份串行，原资料、用户存档及历史候选保护；前台画面、听音、手感与原版动态比较由用户执行。

恢复先读`dnf-native-demo/reports/seven-job-world-20261020/mage-upper457-integration/RUNNING-STATE.json`与节点PROGRESS、实际日志；不重启已结束attempt，不删除他人锁。下方保留历史记录。
<!-- /mage457-live-status -->

# 当前节点：女格斗上勾拳自动通过并备份，继续职业/普通副本

fighter-upper454完整核心/音频/隐藏UI、同主EXE来源/content/dummy及源码产物证据备份通过，EXE `8c37d12288b0f6dbbe6a0731140b2dbd4581e587eed9bcf9f6b7df1280665249`，454输入/179报告，ACT62、九声音18PCM。自身初始5/正常SP20/MP-CD/默认Z/双音/真实EQU与怪物反应及恢复已接；TP163、拳套required34与原生caller仍有具体缺口。Priest e6b57/ready5完整三段fixture链及实际失败与应用证据、movement fixture3及实例clock/frameStartMs和前序Water/Knee/AI/奖励保留。Fighter a182→8b1a计时采样及真实30200错误成功前提两次窄修、原preflight1/2失败/独立诊断和父应用收据完整保留，原740..774未改。四类World释放通过；拳套仅严格原子拒绝与独立源几何，不称五类实跑。本轮还保full1真实失败、精确SkillKey休眠preview测试修正和独审/父应用；normal/runtime1与dormant10不变，完整normal bridge新增第五专项。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-node/PROGRESS.md，备份 `20261020T211925962396Z-fighter-upper454`。七职业全副本/最终十职业未完成，原资料/存档/历史候选保护，继续。

# 当前恢复点：454预览索引断言已独审窄修，等待新正式验证（2026-10-21）

最新已验证体验仍453：`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。454尚未完成，不更新latest。

compile3/preflight3通过后，full attempt1/session24920真实exit1于旧normal bridge预览数组[0]断言。父保原断言诊断session28360实测：目标{1,6}正常1、预览10，数组首项实际为新增免费{1,5}/1；运行时恢复正确。原full失败、原C++再次exit1、观测与完整闭包保留。

Skill封31成员最窄提案（manifest4d4279aa，test46387ffc），UI独审6成员b2f08abb通过；父独立编译并运行整份normal bridge提案session88480退出0，RESULT652ac822。随后父按精确diff合入，`legacy-preview-APPLICATION.json`保真实pass/独审/旧失败身份，其余453输入逐hash不变。仅按完整SkillKey唯一找预览binding；normal mode/runtime1/dormant10及其他76检查不变，运行时不改。当前无运行会话，UI在准备全新ready5，追加第5项完整normal bridge专项，保原四项、454输入/179报告与全部来源/事务门。

恢复优先读本节点RUNNING-STATE、PROGRESS和真实日志，不重跑历史attempt/旧ready4验证新源，不删除活动锁。下一步ready5父核→compile4→preflight4五专项→full attempt2→同EXE/源码产物证据二遍备份→普通job1/DGN1/seed1。ordinary路径工具须在新禁用successor绑定实际ready5 schema，不改旧封包。OBJ0显式manifest交叉门overlay、装备预算和分支赠送successor均封未合，女法天击在独占staging实现；不并行构建运行。原资源/历史候选/正常存档保护，全部D盘；七职业全部普通副本/完整技能及最终十职业仍未完成，持续实施。

# 当前恢复点：女格斗454编译通过，专项计时采样窄修已应用（2026-10-21）

453已完整验证备份，最新体验为`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，1537成员二遍零差异；普通圣职DGN1/seed1四房/21击杀拾取/20技能及结算恢复返城通过132检查。454 compile1已通过；preflight1真实168检查末条时长失败，clock-diagnostic1保原断言实测源body740ms在按键后750ms完成，旧测试漏计首tick16ms而得到734ms。独审只移动started到按键前，原740..774和全部断言不变；父已精确应用test8b1a，其余453编译输入不变。当前无运行会话，等待ready2工具绑定实际失败/独审/应用后compile2和preflight2，再full/同EXE/二遍备份，latest保持453。恢复读`dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-integration/PROGRESS.md`、RUNNING-STATE及真实日志；不复用旧ready1假称新闭包，不并行构建运行/改正式源。原资料/历史候选/正常存档保护，七职全普通副本和完整技能/最终十职未完成，继续。下方running为历史。

# 当前适配候选：女格斗上勾拳454完整重编中（2026-10-21）

453源码产物及证据1537成员已二遍备份。454的12目标已独审后窄合，保留源毫秒/全部帧/武器层/判定/音源及证据等级；Fighter action-start owner-rate视觉不混Priest frameStartMs source-clock策略。正式输入冻结，compile1/session9555，尚未专项/full/audit/本节点备份；不将静态检查计为运行验收。全部D盘，原资料/历史候选/正常存档保护。恢复见`reports/seven-job-world-20261020/fighter-upper454-integration/`，latest仍`20261020T183257823234Z-priest-upper453`。

# 当前节点：圣职者空斩打自动通过并备份，继续职业/普通副本（2026-10-20）

priest-upper完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `924ff1f85d65154c1f87ff200fffdd1e64ca97de143fed871d31ddc66ece8490`，453输入/178报告。正常初始1/SP20升2/真实EQU攻击框/精确frame2效果出生/240ms源寿命及伤害/ACT40/保存恢复已接；TP210与Avenger123仍未实现，旧已学收费前诊断保ledger，WillDriver13 active gate留后续。前序Water/Knee/AI/拾取/学习/奖励保留。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/priest-upper453-node/PROGRESS.md，备份 `20261020T183257823234Z-priest-upper453`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续。

# 圣职空斩打共享实例时钟接入中（2026-10-21）

恢复补充：compile2通过，第二次专项失败已诊断为纯runtime夹具没有提供源武器subtype，成本规则不放宽。fixture-revision2只从真实priest.etc/EQU补装备前提并增加正常动作开始/成本断言；所有原毫秒/deadline/源寿命断言保留，当前待独审。完整验收与备份仍未完成。

453新增实例层clock与显式无SKL速度列政策，保原ANI毫秒/源值/坐标、EQU全部攻击层、frameStartMs和movement修复，源数据不改。compile1通过，fixture故障注入修正待独审；专项/完整回归/备份未完，不算可移植技能完成。上个完整备份为checkpoints/20261020T163114547687Z-movement-reaction，恢复入口和实时日志见priest-upper453-integration；原资料、用户存档和历史候选继续保护。

# 当前节点：普通受击方向输入恢复自动通过并备份（2026-10-20）

movement-reaction完整核心/音频/隐藏UI及同主EXE来源/content/3秒dummy通过，EXE `00ee62e405344c3879ce18461cf844ee293aaa70f7aa9a7ffc2a2f2c2844934e`，452输入/177报告。原test修前真实失败560→560，revision2/3仅修城镇Knee配置及源来袭准备，green1/2失败和诊断保留；最终两个clock六样本验证普通受击恢复方向、KEYUP/失焦双击/换房及正常Knee MP/CD无重放，不称测试字节未变。仅活人显式中断保四方向，其余动作清理，source/数值不改，策略保持推断；status/lethal无新增直接覆盖，普通副本额外结果不泛化。备份 `20261020T163114547687Z-movement-reaction`，详见dnf-native-demo/reports/seven-job-world-20261020/movement-reaction-node/PROGRESS.md。七职业全普通副本及最终十职业未完成，特殊机制延期；后续Priest须实际452新基线窄重基。原资源/历史候选/正常存档保护，继续。

# 可移植输入生命周期补充（2026-10-20）

动作中断与物理KEYUP分开：宿主在普通存活受击/控制中断保留四方向，经完整取消清所有动作请求和实体，再恢复方向；焦点丢失、死亡、场景/角色及重载边界继续全清，并重置双击历史。既有MP/CD、配置和单调序号不退款、不重置。此通用宿主策略归inferred beta，原始CHR/ANI/ATK与源毫秒/盒/有序元数据保持；不将PC输入策略写回源资源或旧GBA。452 compile4及green3两clock/六samples已过，完整回归与节点备份未完，实际边界见reports/seven-job-world-20261020/movement-reaction-integration，状态/普通致死动态仍有限。原资料/历史候选/用户存档保护，未来端口合同保留。

# 当前节点：男法魔法冰球正常基础26自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon-normal完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e183644cb660b231ff7205ba7cb2b36d4cd451ca2b3010c7bbc453c355d89ffc`，451输入/176报告。正常26已接来源初始1/SP15升2/learned槽/一次MP-CD/真实flight-impact/受击/GSD/保存恢复；TP236与元素链51仍false，已学旧被动具体挡在收费前且保账本。前序Water、正常Knee/AI/active/拾取/学习/保存奖励保留；实际边界、beta推断与用户步骤见dnf-native-demo/reports/seven-job-world-20261020/watercannon-normal-node/PROGRESS.md，备份 `20261020T145242215868Z-watercannon-normal`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 当前节点：男法魔法冰球预览链自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e059c892d4c2182911670581c0390ddaa457d37e358080ed8753a97b5172d3e8`，450输入/175报告。已接自身来源fixed body→moving PO→accepted nonmiss→impact/typed排除与独立ALS树；正常26/TP236/元素链51仍false。保留正常Knee/AI/active/拾取/学习/保存奖励，新增实际ACT16场景、六声音12项PCM及两clock等检查。beta回调/缩放/受击等推断与待用户体验见dnf-native-demo/reports/seven-job-world-20261020/watercannon-node/PROGRESS.md，备份 `20261020T141256959979Z-watercannon`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 当前节点：正常怪物Event与男枪膝撞自动通过并备份，继续职业/普通副本（2026-10-20）

normal-combat完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `1f29cfe5ad188dc3565bcea5169ccbd183d53927ef7217345fbd7222e32e35d8`，448输入/174报告。普通source-think自动安装现有Event子集，显式/F7/恢复binding/pending/window/RNG保留；实际Event到Jena ACT及MAP factory通过，不称完整AI。男枪2/4正常初始/SP/槽/Z/MP/CD/伤害/ACT22/装备/GSD/恢复已接，stable Audio0与三份OGG独立dummy解码通过；TP168正常仍false，原生caller/保护/公式等保持推断。金币等前节点修复保留，范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/normal-combat-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续真实多房洛兰和男法WaterCannon；七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 正在实施：普通Event与膝撞正常接纳，完整回归中（2026-10-20）

最近验证备份为checkpoints/20261020T121835179429Z-active-source-reaction，EXE75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e。随后normal AI7与Knee13文件已窄合，compile-only与六组专项通过，448输入冻结运行normal-combat full attempt2；尚未新交付。先读reports/seven-job-world-20261020/normal-combat-integration/PROGRESS.md与RUNNING-STATE.json恢复，禁止测试中改源码或并行构建。原资料/存档/历史候选保护，自动仅hidden/dummy；任务继续。

# 当前节点：地面来源技能活跃ACT受击自动通过并备份，继续技能/普通AI（2026-10-20）

active-source-reaction完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e`，446输入/173报告。精确地面单BodyAttack的霸体/普通/控制/死亡和prepared清理已接；两个clock共22场景通过，MISS/fault不取消，多owner晚故障保留前一成功。MP/CD/KEYUP/序号保持；实体/channel/空中仍具体挡。男枪膝撞正常implemented=false，新生产技能0，TP/声音/接纳继续。金币等前节点修复保留。范围/推断/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/active-source-reaction-node/PROGRESS.md，备份查checkpoints/LATEST.md。全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：基本副本奖励与保存恢复自动通过并备份，继续技能/普通AI（2026-10-20）

basic-dungeon-flow完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `9fc5e798d0df028f92f50181a6cf09324c5798289bdfaa67a5f3509b6382ff09`，446输入/173报告。已接独立击杀奖励游标、intent→私有准备→final持久化→Results/房门、实际writer证明/normal-beta显式handover、KEYDOWN/UP冻结与tick后点击门、主入口共享beta退出确认Reset及可重试保存。正常学习/升级/分支隔离组合、四GSD故障和beta退出故障已执行。金币及同物品图标回退保留。fixture不等于全main/全副本按键游玩，具体七类未覆盖边界/来源/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/basic-dungeon-flow-node/PROGRESS.md。备份查checkpoints/LATEST.md。继续地面source-body活跃ACT受击、膝撞正常接纳和普通Event.ai；全七职业全副本/最终十职业未完成，特殊机制延期。原资料/存档/历史候选保护。

# 当前节点：男枪膝撞来源预览自动通过并备份，继续基本副本（2026-10-20）

gunner-knee完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `7c0b508feb3227a2c892e0f5620367a9b4b33a945e05cc407397313f5f035aad`，434输入/160报告。own job2/skill4的SKL/CHR motion11/ATK1、原750ms身体/装备判定、速度/独立攻击/浮空和窄特效已接隔离预览；特效caller/层、攻速/浮空和当前帧type13霸体保持版本推断。TP/取消/语音/活跃ACT受击/正常接纳未闭合，正常implemented=false，新完整生产技能0。金币和同物品图标回退等前节点修复保留。范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-knee-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续窄合基本副本A/B/C/D及保存期间KEYUP冻结缺口；全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：正常学习/快捷栏/运行时桥自动通过，继续技能与基本副本（2026-10-20）

normal-learning完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `2562c82999bfd1bc7f39ee64a2b9eee5ce463f594dfdc1cd799f33f2366cf3cc`，433输入/159报告。K/NPC正常学习→SkillKey持久购买→有效已学F6快捷栏→原runtime单次MP/CD→同代重载/GSD已接已有消费者；normal/test/manual配置隔离，旧raw休眠，F9显式preview，身体/装备模板与目标外观保存前预检。仅四个own source动作及女枪19主动/12被动正常接纳，其他行保留具体禁用，新生产控制器0。金币等前节点修复保留。具体范围、推断和用户步骤见dnf-native-demo/reports/seven-job-world-20261020/normal-learning-node/PROGRESS.md，备份目录查主工程checkpoints/LATEST.md。下一步膝撞、基本副本A+B及writer/恢复诊断修正；全七职业全副本和最终十职业beta未完成，特殊机制延期。任务继续，原客户端/资料/正常存档/历史候选保护。

# 当前节点：普通/觉醒技能资格分表自动通过，继续正常学习桥（2026-10-20）

second-qualification完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `12b91631fba0a521c9d333a5768d577cdfbd979db3cf47012fb943eeb62fb22c`，430输入/156报告。修复合法空普通fitness和仅有独立觉醒fitness来源的资格早退；当前1734注册行形状已核查，女枪四觉醒/女法光电冰墙及实际GSD rebase消费者同闭包验证。分表选择/两列/回退仍标推断，无新生产控制器或完整正常学习声称。金币等上一节点修复保留，来源/边界/用户步骤见dnf-native-demo/reports/seven-job-world-20261020/second-qualification-node/PROGRESS.md，源码/产物/证据备份查主工程checkpoints/LATEST.md。下一步完整非鬼剑士正常SP学习UI/事务/binding/恢复桥，基本副本A+B仍私有待合、特殊机制延期。原客户端/资料/正常存档/历史候选保护，任务继续。

# 当前节点：掉落/拾取与交互界面自动通过，继续七职业/全副本（2026-10-20）

presentation-pickup完整核心/音频/隐藏SDL、同主EXE profile/content和dummy通过。EXE `c0d35235cdb2d64ba688f56276ac5097994b65b92396aba00f90fd268154995e`，429输入/155报告。金币独立绘制、同物品缺图回退、材料锚点、七职业GetItem与ACT提交打断、NPC X/点击、大地图移动、源加载图/标题、Boss矩形末管红、卡片四档/双击与GSD源等级直接转职一觉已整合。实际范围、推断和待用户体验见dnf-native-demo/reports/seven-job-world-20261020/presentation-pickup-node/PROGRESS.md；节点源码/产物/证据备份查checkpoints/LATEST.md。女法龙牙与七职业中立地面受击已同闭包重编。七职业完整技能/正常非鬼剑士SP学习/全副本基本结算仍未完成，普通Event.ai自动安装和难度属性倍率具体缺口保留，特殊机制延期。下一步继续实质技能和基本副本，原资料/正常存档/历史候选保护有效。

# 当前节点：复仇之刺/下段踢自动通过并备份，继续技能与交互界面（2026-10-20）

body-skills完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过。EXE `e86bd50de645720698a93294d20a550e4d156a64b2e08cef98d07f4fa3954133`，409输入/145报告。job4/116复仇之刺与job1/6下段踢实际消费者已合入，源链/推断/正常学习缺口及用户步骤见dnf-native-demo/reports/seven-job-world-20261020/body-skills-node/PROGRESS.md。逐节点源码/产物/证据备份见checkpoints/LATEST.md。接着窄合女法龙牙、prepared七职业地面受击、GSD直接身份与新版界面/拾取；特殊机制延期，全副本基本流程与七职业完整内容仍未完成。最新Boss矩形多色末管红、卡片难度/双击、源加载图/标题、大地图移动、对话按X/点击继续、拾取动作/高亮/金币图像正在独立节点中，尚未包含。原资源/正常存档/历史候选保护，任务继续。

# 当前节点：ACT判定、伤害窗口与同代恢复自动通过，继续职业技能（2026-10-20）

act-window完整核心/音频/隐藏UI、同EXE profile/content及SDL dummy通过；EXE `fd6c1d415122c917d001b5656c314ac6d792067bb8482cd4f906b58a59c183e5`，407输入/143报告。真实monster→中立地面鬼剑士根ANI接触、源伤害/去重/事务回滚，与三个player→monster伤害生产者窗口/Event.ai pending/typed房间同代恢复已串行整合。具体来源、推断、已支持范围、用户步骤与恢复查dnf-native-demo/reports/seven-job-world-20261020/act-window-node/PROGRESS.md，节点源码/编译产物备份查主工程checkpoints/LATEST.md。实验职业/动作中断、空中/恢复/抓取、DOT/非玩家来源仍未闭合；不把诊断fixture计作完整怪物。用户本轮只需全部副本基本进出/战斗/通关/结算/返城，特殊机制延期；转职觉醒来源等级达标后GSD直接设置、无任务材料并控制学习，详见PLAYABLE-SCOPE-UPDATE.md。GSD尚待实现，下一步圣职复仇之刺/女格斗下段踢、其余职业与prepared反应、GSD及普通副本。原资源/历史候选/正常存档继续保护，任务持续。

# 最新用户范围：全部副本基本流程，等级达标后GSD直接转职觉醒（2026-10-20）

用户明确本轮正常游玩只需所有副本能进入、基本战斗/清图/通关/结算/返城，不要求全部特殊机制；转职/觉醒达到来源等级后在GSD直接设置，无任务材料流程，按新身份/觉醒阶段/等级控制学习。原源数据保留，简化单列用户策略，不将空图加载失败算通关或模板算完整技能。七职业技能和已反馈战斗/UI/地图/性能修复继续，正常学习与测试overlay隔离。GSD直接设置尚未正式实现，由ui-staging/gsd-advancement-next独占节点推进。详细范围与验收见dnf-native-demo/reports/seven-job-world-20261020/PLAYABLE-SCOPE-UPDATE.md；此条覆盖下文完整机制和转职任务的旧门槛。原资源/历史候选/正常存档保护及逐节点备份继续。

# 最新用户调整：副本特殊机制先不做，七职业技能与普通副本优先（2026-10-20）

用户明确“副本特殊机制可以先不做”。本轮暂缓hellparty/深渊/APC特殊遭遇、塔专属流程及副本专属机关/特殊反击扩展；来源和已完成私有成果保留，不计完成。七职业实质技能、正常学习/装备/成长、普通怪物AI与Boss基础战斗、物件/门、地图/UI/性能及普通副本结算返城继续优先。全地图暂不等级/任务准入，资源/格式缺口具体诊断，特殊路径不静默算通关。当前已合ACT/window完成必要全量验证和备份后转回职业技能。详细范围与恢复见dnf-native-demo/reports/seven-job-world-20261020/SPECIAL-MECHANISMS-DEFERRED.md。此条覆盖下文先做特殊机制的旧排序，原资源/历史候选/正常存档继续保护。

# 当前节点：男枪普攻/跳跃与世界反馈自动通过，持续后续实施（2026-10-20）

gunner-world 完整核心/音频/隐藏UI、同主EXE来源审计及SDL dummy通过；EXE `ab83a1c666b6e9c432c086be3f831f3c26cacd21adab84f64ff86360da957130`，398输入/140报告。男枪第三枪分段/源弹速和跳跃局部时钟、枪口渲染profile、UI/门/TIL、入场怪物等级及选角回区域源赛丽亚已整合；精确范围/推断/用户步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-world-node/PROGRESS.md。独立源码/编译产物/证据备份查主工程checkpoints/LATEST.md。男枪948、枪口profile98、raw11命中72等专项在本次正式闭包重跑；前台/原版动态待用户，不将通过检查计作技能完整度。下一步SET DAMAGE CHECK、hellparty与ACT/APC/塔及其余职业技能，七职业全副本/最终十职业门槛仍开放。此最新状态覆盖下文历史未合入和等待门；不暂停任务、不缩范围，原资料/正常存档/历史候选保护有效。

# 当前节点：属性弹、源缓存与共享攻击移动自动通过，继续地图/UI及登录修复（2026-10-20）

attack-motion完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过；EXE `1b65e9728181dc8460026aa0596593ba0ea4a2e107b71f61c8c7050fb377d932`，374输入/124报告。专项移动672、属性弹1468、缓存28、跳攻436、Action.ai787。准确推断/范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/attack-motion-node/PROGRESS.md，源码/产物节点备份查主工程checkpoints/LATEST.md。下一节点修进图退出/长诊断、怪物按入场角色有效等级冻结、再选角色回当前区域赛丽亚及选择/地图UI；这些最新要求尚未在本节点完成。ACT/APC/五职业实质技能和全图门槛继续开放，不暂停任务、不缩减范围，原资源/历史候选/正常存档保护有效。

# 当前节点：女枪跳攻/源武器与Action.ai自动通过，任务继续（2026-10-20）

正式combat-source节点完成完整核心/音频/隐藏UI、同EXE profile/content与SDL dummy；EXE `fe53ce32fabeddb916af979d0f55ba4c35a13a9644e777a950f8dfee460b3a1d`，370输入/121报告，真实World女枪跳攻/源枪口/资格436项与Action.ai787项通过。build为cache/seven-job-combat-source-build，tests为cache/seven-job-combat-source-tests-attempt1。范围、推断、用户步骤和恢复查dnf-native-demo/reports/seven-job-world-20261020/combat-source-node/PROGRESS.md，节点源码/产物/证据备份查主工程checkpoints/LATEST.md。按需PVF/场景节点保留；这是中间节点，继续源工作缓存/属性弹、共享攻击移动、ACT碰撞受击、APC/塔及七职业全副本，不按历史等待门暂停。原生socket/PTL运动、Destination/Move消费者、完整ACT pending恢复、statBase27与五职业技能缺口仍具体保留，不将索引或模板计作完成。原资源/历史候选/用户存档保护有效。

# 七职业全副本修复：性能基础节点自动通过，继续整合（2026-10-20）

下一待验节点的ScriptFieldView明确是元数据投影，不伪作完整Script；完整rawBytes/source和重复有序fields/selectedTokens仍可跨平台复用。Pvf/Assets缓存仍单owner，不能并发修改。WalkGeometryView借用不可变下一场景碰撞列表，与live World共享相同源几何算法，不借临时交换live状态进行预检。MapDefinition追加acceptedDoorMasks保留MAP greed全部类型；新v2精确匹配来源列表，历史v1生成/旧存档保留原合同，不能载入时重抽。

按需PVF/世界节点已完整自动验证，保留全部原始字节/有序token/重复字段/偏移及来源身份；stringtable延迟CP936解码、翻译组和场景延迟准备只改变消费时机，不修改来源编码或删依赖。主入口OnDemand，轻量MAP归属索引与完整DGN MAP/MOB闭包分离；静态完整指纹继续验证。v2拓扑使用greed接受列表，v1旧会话保持不重抽；跨333副本后保存恢复与重复访问缓存检查通过。源能力/塔APC/statBase27缺口继续具体记录，不能缩减全副本范围。WalkGeometryView提取原几何算法以支持下一场景私有准备。会话资源缓存尚无预算/淘汰、多线程共享缓存未实现；未来端口预算须另做。实际范围/身份/恢复见reports/seven-job-world-20261020/resource-world-node/PROGRESS.md及CURRENT-NODE.md。

用户本轮13项及追加7项已授权继续；当前先验证独立性能基础节点，随后继续技能、全区域与怪物整合，尚未交付七职业全副本候选。调试服务缓存不可变来源身份行并逐次检查实际controller支持集，命令回执仅变更时复制；所有HP/MP、身份、pending tick、AI诊断仍即时更新。删除无消费者的逐帧World全量快照。空ACT宿主在没有实例、速度、关系、显示所有权及气泡时只提交连续tick和publication epoch，避免每tick复制全部Actor来源属性；有任何运行状态仍走原子Batch。具体前后同场景测量与状态一致性见reports/seven-job-world-20261020/performance-*.json；这是CPU逻辑量测，不是用户设备GPU/FPS验收。怪物渲染诊断按来源条目及ACT消费状态一次记录，仍保留两种模式的差异。原PVF/ANI、正常存档、历史候选及未来平台原始数据均保留。

<!-- selection-ime-verified-handoff -->
# 最新体验候选：技能图层、选择界面与IME自动验证通过，等待用户确认

主工程当前候选完整核心/音频/隐藏UI、同EXE来源审计和SDL dummy冒烟通过；EXE `74b7e5c3a59783057c482c4f442889389f9d849706527ee367a5e62d88dfd26a`，349输入/110报告绑定。入口`D:\dnf-rebuild\dnf-native-demo\Start-Selection-IME-Fixes.cmd`在checkpoint核验后发布，准确备份目录见dnf-native-demo/checkpoints/LATEST.md。范围、源透明/缺图、未恢复Full输入及其他推断/缺口、用户步骤和恢复点见dnf-native-demo/reports/selection-ime-20261020/NODE-PROGRESS.md；不是全十职业beta完成。前台/IME/听音/手感和原版动态待用户。**交付后等待用户确认才继续其他节点。** 不维护独立预览，原资源/历史候选/用户存档保护继续有效。

# 当前动作/技能节点自动通过，继续整合已排入的界面节点

完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy冒烟通过。EXE `d571ad37668b52c38afa0bd8e18c216eeb44256a2a9b56183066d60bb68fe0b9`；332输入/102报告绑定。范围、推断、失败记录、用户步骤和恢复点见reports/attack-timing-offset-20261020/NODE-PROGRESS.md。节点备份目录以checkpoints/LATEST.md为准，完成备份后才继续正式源整合。当前只是中间节点，最终体验候选尚待下一节点编译和用户确认，不能当完整beta。

# 当前候选的移植与保存边界（2026-10-20）

动作时序覆盖、技能附层列表、ALS宿主/独立实例与XYZ插值为瞬态运行字段，保留原ANI字节/帧/DELAY及SourceRef；不写入正常技能学习或奖励账本。原始与运行时间轴分开，图层排序和世界地面Y分开，供未来端口复用。UTF-8编辑模型保持无SDL/Win32依赖，平台宿主仅负责事件所有权、组字/候选位置和实际保存事务。新节点必须分别编译验证并备份，当前Windows自动通过不代表其他端或原版视觉通过。

# R60-03技能空放退出修复：自动验证通过（2026-10-20）

新主EXE `f2d7434e25b297d03e9d7c611db9f03ea945db407ec15f8f1e81114bba5d6638`，实际World 2692项/18次空放、学习51项、完整核心/音频30项、来源审计及局部SDL dummy smoke通过。启动 `D:\dnf-rebuild\dnf-native-demo\Start-Skill-Crashfix.cmd`；备份查 `reverse-60us/checkpoints/LATEST.json`。用户操作复测待执行。后续集中主工程，不单独维护独立技能预览；R60-04草稿保留，下一步继续04。完整记录见 `reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md`。

# 当前补充：学习绑定与运行时冷却（2026-10-20）

学习身份与瞬时冷却必须分开。`learning-v2:` 指纹忽略CD数值以及只含key(job_id,skill_id)、level0的纯运行时空行；未知记录/键/顶层字段和学习元数据仍进入hash。旧hash须先匹配旧算法或规范化摘要，才可升级；无法证明一致的旧binding保留显式冲突，不静默重绑。保存schema1和原bytes/来源不变。实际World及迁移负例验证结果见技能退出修复进度。
# 女枪与业务 UI/地图便携边界（2026-10-20）

本轮隔离候选、备份和恢复状态查 `reports/knowledge-base-audit/NODE-PROGRESS.md`。源PVF/NPK/知识库、历史候选和用户存档保持只读。候选使用自身存档目录；SourceRef、原始字节/有序字段/未知标签、CHI/ANI/ATK/OBJ绑定、TP基表与逐列操作和证据分类保留，供未来PSP等平台复用，不从旧GBA或DFQ UI派生。

`FemaleGunnerWorld` 为平台无关模拟消费者，人物/特效显示仍通过通用SDL适配器；攻击、状态和资源的float32/整数边界保留trace。火弹每目标类别、独立弹体/脉冲、实体句柄、抓取/G组所有权及事务/RNG不依赖渲染FPS。UI只返回操作意图，由已有事务提交；输入测试覆盖不写正常学习账本。Windows SDL dummy检查与新平台验收分开，不能沿用本轮结果宣称未来平台或原生动态通过。

持续实体重载仍采取显式cancel-transient策略；未完成被动/正常女枪学习/职业业务与推理时序完整记录在覆盖矩阵，不删除源记录降低最终十职业门槛。待用户确认本轮候选后才继续后续节点。

# R60-03 便携时钟与生命周期合同（2026-10-20）

状态：**automated pass / user pending**。[R60-03-VERIFICATION.json](../../reverse-60us/integration/R60-03-VERIFICATION.json) 已绑定主工程285份输入、84份报告、完整核心／音频及同EXE来源／dummy检查。正式测试目录 `cache/r60-03-tests-final-r4-checked` 的 [clock报告](../cache/r60-03-tests-final-r4-checked/reports/animation-clock-tests.json) 为1541项通过，含九个实验职业完整往返；另有46个冻结原生输出／157项便携检查及24项ALS检查通过。用户画面、听音、手感及原版动态比较待执行，当前Windows结果不代表未来平台通过。

新增共享 C++17 头 `reverse-60us/integration/include/dnf_ani_clock.hpp` 无平台 API、客户端地址或内容 ID 依赖。它保留来源 DELAY、两种 clock 政策、安装／刷新速率表达式、明确 float32 存储和整数截断，以及连续60Hz tick、暂停、首帧／跨帧 visit、ended 保留与 root/child 投影。46个冻结 native 输出和157项便携检查只覆盖所列输入，不证明所有 x87 输入／控制字或1031原生调度。迁入1031的属性映射与宿主行为仍标跨版本推断。

Cursor 借用不可变延时数组；宿主 `AnimationPlayback` 与实验运行时通过共享不可变存储保持复制／移动后的数组寿命，各自推进独立游标。子层 min-delay 视图不改写源动画。平台必须消费发布的 frame/local/span/ended，不能把 elapsed 再除原始 DELAY 或二次乘攻速。普通姿态游标失去所有权时释放，攻击快照仍由其原 owner 保留；不能跨过未消费 tick 直接恢复旧游标。

位置跟随、暂停、速率／root 绑定和销毁条件是不同合同。ALS 事件按父 visit 与源记录顺序消费；ANI ended 不等于销毁。显式 offset 回退、脚本／角色／场景取消和后代清理也须保留到其他平台。ACT 的 SourceMilliseconds／ExternalAnimationDelta 继续互斥。普通保存／重载仍取消瞬态，本节点没有引入动作续演 schema 或借已有存档重放历史声音／奖励。

两工程构建身份须纳入共享 clock/render 头；恢复源码时保留 `source/{dnf-native-demo,rep-player-1031-pvf,reverse-60us}` 的相邻目录布局，避免相对 include 缺失。原始字节、有序字段、原时长／坐标、SourceRef 与版本 hash 继续只读保留；GBA／PSP或其他后端的帧率、量化和图形策略不能写回 PVF。构建、缓存、候选和报告均留在D盘独立目录，历史候选和用户存档保持保护。

当前技能专用阶段、怪物和物件仍使用各自 source-milliseconds 消费者，完整控制器和原生 timer 仍待后续核对；用户画面／声音／手感和原版动态比较待执行。新便携头与消费者接入不增加完整原生技能计数，也不缩减十个非缔造者职业的最终范围。

# 历史 R60-02 便携渲染与源码闭包（2026-10-20）

共享C++17头 `reverse-60us/integration/include/dnf_ani_render.hpp` 无平台/地址/内容ID依赖；显式保留legacy与跨版本inferred策略、源弧度/负rate/颜色截断/float32。源bytes、有序属性、原延时/坐标/裁剪不改写。未来端口分别实现顶点/混合后端，不将SDL/D3D策略写回PVF。

构建身份新增共享header，节点源码保留与两工程相邻的目录布局；只复制单个工程目录会缺少相对include，必须按 [节点源码闭包](../../reverse-60us/integration/R60-02-PROGRESS.md) 恢复。普通sprite/PTL角度仍是度，ANI是弧度；normal pivot以外、原生clock、PTL/居中原点及原版像素等效保持未验证。profile和局部算术通过不能升级为全技能控制器完成。

# 历史平台无关边界更新（2026-10-19）

build30将来源相机逻辑尺寸/裁剪/视差与平台视口/缩放分离，并保留独立源MAP通行数据；实现见 [NODE-PROGRESS](../reports/beta-script-camera-20261019/NODE-PROGRESS.md)，自动检查通过但画面尚待用户。技能反馈抖动和默认Z自然衔接属于模拟输入策略，应保持不写回PVF；Z释放时重验源资格、资源和冷却。Squirrel使用 `official3.1-int32-UTF16-float32-stringhash32-inferred-v1` 具名推理策略，当前来源客户端证实版本为2.1.1，故移植层必须保存策略版本和行为缺口，不能声称完全原生等价。

下一启动节点要保留来源哈希与完整错误诊断。哈希任务可独立并行，但资源对象的可变缓存继续单owner；稳定合并顺序、完整PVF/静态消费校验和取消清理必须跨平台保持一致。

# 当前整合：城镇身份与共享攻击读取合同（2026-10-19）

build26完整核心/音频与同EXE无前台audit通过，222源码/79报告绑定，EXE `84025a71f14e6efd1f2747695c73284f26518ac05532a86e11771fd51287dad4`，真实范围/备份查 [CURRENT_TASK](../CURRENT_TASK.md)。TownLocation以town/area唯一对、TWN/MAP路径及完整SourceRef共同验证；未知扩展保留，跨来源或ID/path矛盾拒绝。旧room/town/entrance与无anchor地下城档只在缺字段时显式迁移，不能把显式新城镇回落艾尔文。14个别名是PVF版本绑定的集中适配，保留原literal/实际路径和诊断。

城镇私有准备复用原MAP坐标/地面/出口，副本门缺席area保持absent；端口不能将全部源门映成洛兰或将公会/PVP/raid的可观察场景视为业务完成。current/return anchor随玩家、模拟与RNG同代入CharacterStore；直接运行备份的独立存档路径属于平台启动策略，不写回源内容。

`CharacterAttackMotion` 保留身体及精确装备武器ANI；按身体pose索引读武器盒是用户临时测试策略，和原始帧时长/坐标/层次分别保留。实验源帧有效区间持续采样、每action/target接受去重、声音仅新帧事件；临时普攻模板保留同职业SKL身份、源MP/CD及分类标记。其他平台须保留源内容和具名策略，不能据此宣布全职业专用控制器恢复。

Event.ai使用独立随机域、一次性接受事件和候选发布；F9测试策略设计仅拥有自身binding/pending/精确ACT。真实F7 Jena因未知非零statBase27被拒，当前仅拒绝路径已验；独立诊断World通过不替代源成长准入/真实F9拥有权验证。原始表列、MOB等级与失败报告保留，端口不能以零或假定暴击中和。ACT typed宿主90/68已验，外层续演和Squirrel接线仍staging。

下一节点的相机修复以艾尔文防线为参照，源地图尺寸/坐标/视差与平台视口/分辨率策略分别保留，不写回源可走区域。NUT依赖矩阵、默认Z队列与失败呈现、物件PTL源寿命及独立last行为同样按后续实际消费者记录，staging不计通过。前台与原版对照、完整beta门槛均未完成。

# 历史节点：全地图与角色实验入口（2026-10-19）

build19完整核心/音频与同EXE来源审计通过，204输入/73报告，EXE `1afb8642b7bfa3471d203d2ec9c195753f9118044d3905559a74bde542883955`。详见 [NODE-PROGRESS](../reports/beta-experiment-20261019/NODE-PROGRESS.md) 和 [LATEST](../checkpoints/LATEST.md)。

新增map_access/map_exploration保留全部MAP成员/注册及SourceRef，元数据延迟读取；Scene/World私有准备，缺几何明确阻行。地图完整度与各消费者能力分离，源怪身份绑定handle/path/id及冻结属性；新增端口必须保留未知字段/保护/缺失诊断，不能沿用演示平面或套其他怪物AI。

experimental_character及World适配保留同职业CHR动作/ATK槽、源费用和配置策略。13槽配置、剩余CD随同一模拟边界保存，严格核对来源，未知有序字段保留；起始武器是具名用户实验SD/EQU策略，非原生赠送证明。正常Swordman第13槽独立消费当前绑定。五个实验职业本次实际扣HP、四个仅动作，不能推导完整职业行为。

自动范围与前台/原版对照分开；完整beta约10%，P01–P19继续。当前ACT磁盘恢复仍取消瞬态，后续typed收据/完整图remap/宿主候选/外层同代发布尚在staging，不以这些未测算法充当续演完成。保护原434基线未刷新，正常档新差异和调查见本节点进度。

# 核心接口、数据与移植约定

## 2026-10-19 ACT World 服务

最新 [NODE-PROGRESS](../reports/beta-act-world-20261019/NODE-PROGRESS.md) 与 [LATEST](../checkpoints/LATEST.md) 对应build13，EXE `144efcfe162b1b0c9cb86cd918a41c734f5f823760cb0f8918ce5ef1c30cf76b`。monster_behavior保留原路径token、完整空槽/重复/作用域、配对CD/ATK；monster_spawn全批私有准备。ActWorldHost的Batch同时保存演员、实体、状态、事件/编号及宿主状态，用无抛出swap发布；动画时钟只来自固定tick的一种模式，动作速度只积分一次。抓取/受击恢复保持公共生命周期；DESTROY移除不发击杀奖励。

来源毫秒、原字节/有序字段/SourceRef、静态资源manifest身份、外部动作时钟、随机流和ownership cleanup都须供未来端口保留。当前磁盘恢复取消瞬态，不是完整ACT续演；typed事件收据/remap设计与未完成实现留staging。新增全图/其他职业实验入口应单独标记用户配置和未完成机制，不能污染普通学习/装备账本或写回源数据。完整范围与新发现存档差异见节点进度。

## 2026-10-19 状态服务与非回退身份合同

最新已测实现/产物与恢复入口见 [NODE-PROGRESS](../reports/beta-status-20261019/NODE-PROGRESS.md) 和 [LATEST](../checkpoints/LATEST.md)，EXE `d6633262e4ebe43d3964cda2aec0ea71e749c7decdd3eecb9dfcc5cb8c6e2d53`。`attack_status`保留ATK完整有序字段、来源字节和offset、CHR/EQU/MOB抗性、具名概率策略、状态/接触实例与固定ms生命周期；`status_runtime`真正消费World伤害/RNG、输入/AI门槛及room/player显式remap。stun不是普通受击硬直；非stun与未选择的非零抗性推理仍明确阻断。

`MonotonicIds::merge`取非回退水位，0为永久耗尽而非最小值；`EntityRegistry::restore`仍是底层精确替换，World恢复另用`mergeAllocationWatermark`防旧句柄复活。只实体与状态分配历史保持前进，clock/RNG/action/attack/command仍按同代保存数据恢复。全roster先私有分配，再cleanup/publish；CharacterStore在取消角色前检查select和最终restore容量。状态成功ID跨bundle核对归属，允许simulation/player同应用副本。

build10核心/音频与75/31/20/23专项通过，源/二进制/实际静态库/64份报告hash绑定；30/60/144FPS和有预算补tick的真实Tau行为一致。未来端口必须保持60Hz16/17ms、源毫秒及已恢复算术边界，不改源ANI或双乘动画时间。Tau接近控制器、状态概率/抗性公式明确推理，不作原生数值担保。

ACT/Squirrel完整World/持久恢复仍待整合，standalone玩家无bundle清理边界仍留待修复；正常main先换场恢复路径已测。用户前台/原版动态及其它平台尚待验证。每完成节点备份production源码、EXE、静态库、证据与PROGRESS，原资料/用户档只读；完整beta约10%为工程估计。

## 2026-10-19 学习与伤害节点合同

最新开发备份和已知问题见 [PROGRESS](../checkpoints/20261018T165352718179Z-source-projectiles-object-damage/PROGRESS.md)。第二节点546文件复核，EXE `ac7bfda2e31529593e0de22fb89afc07a4df82efdd05ff0aa5d3415ff891eac1`。`skill_learning`的normal账本、初始化/迁移、SP/TP购买历史和独立test overlay分离；`skill_learning_transaction`先保存同代候选再发布，重试不重算/重复扣点。World兼容数组仅投影，正常等级独立于debug覆盖。

`combat_attributes/monster_combat_attributes/damage_resolution`保留有序来源、常量表、推理策略和float32 trace；四主属性、装备攻防、独立/绝对/暴击/元素分开，成功才提交随机流。Actor保存已算combat receipt，恢复检查来源不重算；run的HP与combat策略分别冻结。投掷物发射冻结主人属性/句柄/攻击实例，源ANI攻击盒消费OBJ ATK；显式HP物件用具名中性目标推理策略，未知实质修饰阻断。AttackVolume冻结实际ATK/技能参数，避免消费时重查当前pose。stun和destroy PTL仍缺消费者，平台不可据模型存在就登记完整支持。

用户要求每节点源码和编译产物独立备份，`tools/checkpoint_node.py`输出manifest及逐文件hash、测试身份与PROGRESS恢复入口；原客户端/存档不复制或覆盖。首次节点294文件已复核，保护基线的旧build4项差异明文留存。仅Windows逻辑检查，未来端口/前台/原版对比待验。

## 基础设施候选2已接入合同（2026-10-18）

当前已验证归档为 `candidates/beta-foundation-2-20261018`，EXE SHA256 `5004fee99851d415a9ee6286230778df2f44b7731aad253a6e18ff54f8dfbaec`；后续源码在继续实施。构建、核心/音频与无前台profile/content审计绑定归档的source/evidence，不能外推为其他平台或完整beta验收。完整状态见[CURRENT_TASK](../CURRENT_TASK.md)。后文旧候选均保留为历史。

新增 `content_profile/content_catalog` 保存PVF与静态根独立身份、SourceRef成员hash/范围、原始字节、有序token、重复/未知字段及能力诊断。路径迁移与内容身份分离，缓存和存档按内容隔离；来源不回写，所有派生缓存/报告/构建位于D盘。

`simulation` 的60Hz时钟、实体代际句柄、动作ID、命令边界和PCG独立随机流与SDL分离。持久提交同时保存世界/RNG/事件与进度；session v4直接保存选定DGN布局和随机状态，重载不重新生成。仍未实现完整动作/持续实体图续演，不能将取消瞬态控制器的恢复边界冒充完整续演。

`attributes/speed_attributes/equipment_attributes/skill_cost/monster_attributes` 为平台无关来源与推理策略层。CHR成长和EQU资源累加保留float32阶段，整数转换只在明确消费者；HP/MP、速度千分值、百分比和CHR四系数单位分开。速度基础普攻采用ScaledLocalAge，原ANI帧时长不可同时再次按rate缩放。GBA、PSP策略不得覆盖源数据。

装备资源结果只能从纯CHR重建；marker阻止二次叠加，失败也进入adjusted.diagnostics。正常资格等级与debug有效等级分开，装备事务在候选状态完成来源/属性/外观预检再发布。World统一决定当前HP/MP重算语义和死亡规则，模型不自行回血。

怪物来源模型保留完整MOB/TBL脚本，Actor仅保存计算receipt。MAP等级先64位验证再收窄；来源HP正值在每个整数消费者截断。session新增可选monster_stat_policy，整次run冻结，缺失旧字段选legacy；source_stats作为开放对象保留未知字段，坏类型拒绝。旧已访房间HP不重算，旧未访房间不切换新来源策略。

F9窗口通过平台无关管理命令接口与World交互；SDL只负责工具显示/输入。HP/MP锁独立，debug等级与正常成长/装备资格隔离，测试存档独立。软件fallback renderer也必须显式关闭工具窗口vsync。仅Windows和SDL dummy逻辑已验证，画面/听音/手感与未来端口均待验证。

下一版跨端合同见[总体架构](../../dnf-native-build-plan/01-architecture-and-contracts.md)、[内容版本](../../dnf-native-build-plan/02-content-loading-and-versioning.md)及[平台构建](../../dnf-native-build-plan/12-platform-build-and-release.md)。采用来源/语义/模拟/表现/平台分层，独立PVF与静态根、明确LE和float合同、内容隔离存档。仅Windows作为本轮实现目标，其他平台保留完整数据和接口；此次新增方案不代表端口已通过验证。

## 角色与技能数据

将 PVF 解密字节、顺序 token、重复字段、作用域、原始偏移、资源路径和版本来源作为只读内容模型保留。角色身份、局部技能键与装备编号引用源注册表；默认外观经 CHR/SD → equipment.lst → EQU → LAY/ANI/IMG 解析。未来平台应复用这些平台无关模型与源引用，再由各自资源读取和渲染后端消费，不能把某一 PC 构建里的角色 ID、默认装扮、贴图路径或图层数值复制进新平台常量。

技能控制器逻辑可以由代码实现，但必须与 SKL 内容分离：名称、作用域参数、等级、消耗、冷却等由资源提供；状态转换、输入、命中和生命周期由控制器处理。没有从来源证实的行为单独标记重建或未知，并保留原资源。新增平台可以适配输入和时钟，不能修改源 ANI/SKL 字节来拟合本地行为。当前鬼剑士技能阶段绑定仍含运行时表，尚未达到“只更新资源即可更新所有技能”的目标；其他角色控制器也未完成。

`skill_data` 以 `SkillKey` 加载登记技能的原字段，在调用方明确选择作用域后提供名称、命令、等级表及消耗/冷却字段。模式覆盖和重复字段的歧义均可追溯至原作用域、序号与偏移；每级参数按表宽精确读取，等级0没有有效参数行。当前 MP/CD 消费仍仅用首端点，不得将此简化外推为中间等级插值或原版最终公式。当前鬼剑士技能清单、阶段和效果／动作绑定仍含运行时表，其他角色控制器也未完成。

选图 UI 及其他 UI 图层按用户最新要求暂缓，用户正在整理相应逆向成果。当前移植工作优先角色、技能与装备模型；本次测试只验证资源解析，不构成任一平台的完整角色或视觉验收。

## 全工作线隔离整合候选（2026-10-18）

最新隔离候选 `cache/build-full-worklines/dnf_native.exe` SHA-256 为 `268f179d718038d1b3644a2f40d1d6813812039976473606fc100c72ba9fc0c6`。本轮新增的对象来源模型、实例身份、固定tick推进和`CharacterIdentity`／`SkillKey`接口继续保留平台无关数据边界；它们不改变原PVF，也不定义GBA或未来PSP的输入、显示或战斗数值。

对象层170项检查和源地图计数可复用为逻辑验证；原生ANI事件、声音/PTL、掉落事务、完整对象存档消费仍有缺口。选图只通过最终候选键盘/资格检查，鼠标和高DPI未验证，且两种分辨率的真实截图显示卡片重叠。所有PC候选结果都不能当作其他平台验收。

角色矩阵仍以历史`1c55ec60`组件候选为身份；当前候选只提供可拒绝未注册身份的路由结构，仍只有未转职鬼剑士可玩。十个基础角色（缔造者暂缓）、转职、觉醒、技能及原版动态对照仍是PC交付门槛。完整本轮证据见`../reports/combat-native-reverse/full-worklines-candidate-20261018.md`。

## 零级技能与水平静态运动合同（1c55ec60历史快照）

## 零级主动技能与水平静态运动合同（2026-10-18）

当前World新技能释放在输入缓冲、扣MP、CD、创建阶段前拒绝明确level0；来自86D9D5..86D9F4，保持==0而非擅自解释为<=0。既有续段是本地已开始动作的请求，未因此成为完整原生useSkill。缓冲先清槽再重入activate，必须重新检查当前等级。CharacterStore存档适配保留显式主动0，负数限制为0、上界沿用demo上限，缺失旧项仍1；这些兼容策略不能成为未来端的原生学习分配。被动和源参数访问器仍是旧demo实现，不因本次局部门声称完整恢复。

`static_motion.hpp/cpp` 无SDL依赖，输入已修饰的normal/alternate速度、独立加速度、方向与倍率。保留SSE float32逐操作顺序、CVTTSS2SI加速度转换、倍率1000旁路；检查与直接存储合同分开，检查速度容差abs(oldV)*2^-23，同加速度不重置duration，直接写入总重置-1。只有a*v<0才按v*-1000/a截断设置剩余加速时间，到期只清加速度，不能额外强制速度0。非finite／越界时长组合命令先拒绝再修改是便携边界；保护owner/authority、dirty通知、原FPU环境、碰撞和状态副作用不在模块中。接口尚未接实体，不能用基础CHR代替最终bank，也不能把本地90/110ms曲线称原生。

horizontal-motion保存原字节／常量、42项静态校验、20项C++专项、独立32位机器码12例与固定VA分配失败。探针只运行自有进程并重定位两常量，不作原客户端动态一致声明。skill-parameters保留受保护入口与有序modifier未知；actor+3858集合的构造空不代表施法时空。洛兰35MAP／4MOB与parser缺省证明可选空中伤害重力未启用，不能用demo damage替代消息−168累积输入或用z>0代替原状态predicate。

所有原始CHR/SKL/MOB/PTL、tokens、偏移、版本hash和失败继续保留。新候选1c55的构建与共享测试副本、普通窗口消息和零级fixture单独归档，旧2567/a63f/7a85身份不混用；全角色矩阵仍标未闭合。GUI／原版动态／其他平台验收分别进行，PC候选未满足10角色完整交付，不能据此宣称未来端已还原。

## 当前候选：分轴积分与粒子纯算术（2026-10-18）

`AxisMotion`／`advanceAxisMotion` 无SDL依赖，输入速度float32、加速度i32、剩余加速毫秒（-1无限）和非负i32 elapsed；输出已限制±2000的位移，同时更新速度和计时。时限中途结束用加速段和末速度段的加权平均，结束仅清加速度；不额外推断零点截速。保留i32低32位乘积和源0.001f，零elapsed清已到期加速度。负时间、非finite速度等拒绝是便携API约束，不当原生异常路径。x87控制字和跨端long double差异没有逐位一致性保证；碰撞、ground状态与副作用由外层处理。

当前World以自身60Hz时钟的16／17ms差分推进人物／怪物Z，430起跳／980重力、落地清零和double位置仍是重建或适配。原生位置接口会写float32，不能声称double累加保留原始逐tick舍入。CHR基础字段→bank0已证明，但bank0→bank3最终修饰、outer schedule和owner碰撞回调未闭合；其他平台不得把现有demo参数固化为源数据。源字节、字段、初始／成长等区块保持原样。

`particleStraightKeepLast` 仅覆盖straight-line与keep-last组合，不依赖角色或SDL。速度由调用方提交最终修饰后的i32，非负i32的t／T为最小适用域；T=0先回绕i32乘积，T>0先各自转float32，再逐操作舍入；没有镜像／旋转／gravity／坐标投影／寿命／删除。不得以fast-math重排或FMA合并这些运算。测试含固定bit-pattern，nearest-even属于host默认参考假设，原版MXCSR仍未实测。尚未用于运行时十字运动，不能把未修饰56样本或当前常速替代当完整原版合同。

`tools/build.py --build-dir cache/build-next --test` 限制构建在项目内并先检查游戏未运行；TEMP/TMP与编译cache仍D盘。候选2567d4d5、旧playable7a85与误编build fc8657dd须分开。最新窗口消息操作、设置重载、accepted-hit fixture、人工截图与来源校验均独立归档，具体身份和未完成全职业门槛看CURRENT_TASK；不要把任一平台自动通过扩大为原PC或其他端视觉通过。

## 最新候选接口：身份、设置与ANI事件（2026-10-18）

`CharacterIdentity{jobId,growtype,awakening}` 与 `SkillKey{jobId,skillId}` 保持job局部编号，不从技能文件名制造跨职业全局ID。World只支持已恢复的{0,0,0}，选择未恢复控制器在改变状态前拒绝；来源保留全部角色（含用户暂缓Creator），不因运行时限制删除数据。CharacterStore schema4兼容旧1..4，保留未知字段／identity扩展、`-1`空快捷槽，并拒绝class和identity冲突。

`DemoBalance`／`AudioVolumes` 无SDL依赖。血量2／3默认、1..10范围均属用户测试设置，相对demo65／240，不修改MOB；每个RegionSession值拷贝冻结，schema3记录配置，旧档无配置默认1／1，恢复实际HP原样。settings独立保存，音量字段非法时按组独立回退，未知字段继续保留。其他端可以另设输入布局，不能把这份PC设置页当原版UI来源。

`AnimationEventCursor` 不持有SDL或可变源ANI：源prop23 int32保留，运行时取低16位，FFFF无事件，跳帧按源序处理非FFFF覆盖单pending，同帧不重发，消费清空，抑制不移动cursor，倒退只取新当前帧。portable非法索引显式拒绝是安全边界。十字控制器保留phase转换的逐tick返回语义、独立附层event和身体frame10退出；不要把当前100%源时钟下500／730ms写成跨平台技能常数。

`monsterFragmentDisplayMs`／`monsterFragmentOpacity` 将用户700／150ms可见调整与源PTL、真实积分年龄分开，生命周期恢复使用同一截止，避免重载延长或重复奖励。实际数学／片块强度仍含重建。音频通过内容catalog类别接口分离scene IDs与SDL mixer；独立music/ambient/effect音量、失败重试与PCM诊断可复用合同，SDL dummy通过不代表目标端听音／设备已验收。

候选构建路径由tools/build.py的项目内 `--build-dir` 指定，TEMP仍D盘；main向上定位CURRENT_TASK确定工作区，嵌套候选不改变默认用户存档根。实际GUI使用隔离save-dir、前后hash保护。构建身份／输入与视觉记录以CURRENT_TASK最新节为准；正式build/playable仍7a85，不能将部分候选视为全角色交付。

## 全角色源模型与原生战斗边界（7a85历史发布）

`character.hpp/cpp` 无SDL依赖。CharacterScript将原始bytes、完整Script和PVF provenance分开保存；CharacterRegistration保存源ID、ordinal、ID/path token offset、原路径字面值与解析路径；CharacterResource保留motion／ATK的原field offset、valueIndex及空字符串／重复项。CharacterStatBlock保存初始／growtype／awakening各自源区间和有序字段，不擅自求继承。原始11角色、1734技能行、1497motion槽、670ATK槽及7份data/skill SD完整保留；CreatorMage的runtimeDeferredByUser仅表达用户允许暂缓运行时，不能作为删除来源或压缩掉空槽的依据。来源注册与控制器实现是不同层，当前仍只有鬼剑士可玩。

`dnf_inspect CLIENT --characters source _ OUTPUT.json` 输出可独立核对的原字节／tokens／字段／绑定，summary模式不输出完整来源。跨平台只复用内容模型及确证合同，不把PC暂定行为写回CHR／ANI／SD。普通鬼剑士取消帧 `[5,4]` 来自当前EXE原生构造与零基消费者，接入时比较当前源帧，未输入保持完整收招，末段无第三阈值。其他角色默认表仅保存确证值和证据，不代表已实现运行时；ATMage源表来自sqr/init_character.nut，技能条件可只减少合法count，不能把全部表项自动当作所有形态的连击资格。事件basic_chain保存旧／新段和阈值。攻速、原生+1A4字段、请求提交和转职覆盖继续保留未知。

`collision.hpp` 保留世界XYZ minimum corner与extent，左向-x-width；非零输入盒面／边相贴成功，可选交集允许0 extent。非finite拒绝是安全加固；原生异常浮点、缩放／分类／接受命中过滤与近战扫掠的完整合同尚未恢复。当前统一近战与PO接触语义，没有由此宣称恢复完整伤害链。原生HP setter到保护值写者及部分死亡触发的有界证据保存在collision报告中，不能用静态调用地址代替伤害公式。

`objects.hpp/cpp` 将 OBJ 内容、地图放置与运行时实例分层保存：来源字节／有序字段／偏移、稳定的副本与MAP记录身份、XYZ坐标、相对动作时间、碰撞状态、攻击登记、随机种子及一次性payload记录均不依赖 SDL。其他平台可复用来源模型和事件/存档接口，但应自行适配固定步长和渲染；`[do not pass]` 尺寸不得冒充ANI受击框，旧 `[int data]` 不可直接映射成HP。当前尚未闭合的原生伤害消费者、PTL调度、声音与工厂payload行为应保留为未知，不能从当前PC候选推导为PSP或其他平台规则。

ANI速率以百分数100为正常，原生effectiveDelay=trunc(rawDelay*100/ratePercent)，CHR1000倍率另存。未来播放器须保持实例时钟／birthOffset、源delay、播放rate和child的自身累计时间；不能修改原ANI时长来实现攻速。ALS原命令顺序、实例身份、循环fired策略、层序与未知项须保留。当前EffectPlan只是有界视觉编译，新增对未支持命令的显式诊断；none-effect、延迟add净出生时钟及真实D3D混合仍未闭合。核对入口为state-attack和resource-render合同，最终构建／前台验收身份看CURRENT_TASK最新记录，下方旧hash属于历史。

最终build/playable SHA256均为 `7a85bd452feb77b2000cec489ed0c35574c4da1d74d00b82f0e80678767fac30`。源模型1828及默认续刀50专项、完整既有核心／区域检查通过，最终inspector独立来源464／464一致。发布EXE普通窗口消息流程 `input-20261018T070550` 25点pass，洛兰／德利拉交互维修／回城与实际存档重载通过，用户存档未变。新帧人工查看和36项发布交叉核对记录在release-verification.json；物理键盘、原版平衡、全部技能／其他职业、像素一致性不据此通过。当前未重跑深处／技能smoke，其他平台不得借用这些PC验证宣称验收。

补充对象倍率生产者证据见 `attack-speed/README.md`：static14FD480传100写global，virtual+708→833420写n并以n*100*.001更新ANI。仅静态初始化与局部写者得到证明，原版g实时值及CHR／装备／状态最终n未知，不能将该例子直接变成移植端武器攻速公式。

## 上一轮24ad命中局部时钟与构建位置（2026-10-18）

`Actor::hitStopTicks`为当前60Hz模拟的剩余局部暂停，`hitStopped`为本tick状态。暂停时平移动画/技能阶段、附着效果born/expires及目标恢复时钟，位移/重力不推进；输入、世界时间、CD、未受击实体和独立弹丸照常推进。相同tick多目标取max，沿用原攻击serial及目标去重。受击暂停不等于霸体、无敌或整个游戏暂停。保存只记录剩余tick，旧档默认0，死亡/换场清理；重载不重发命中。其他平台可以按自身固定步长转换局部时间，不得反写源ANI时长。

CHR `[weapon hit info]`当前为6字段行；运行时四武器映射原subtype0/1/3/2。ATK固定hit info从有序tokens取值，允许枚举为type5，显式0与负值继承分开，末两项保留未知语义。源暂停原值90/70/120/100及各ATK覆盖保留；按毫秒、近战双方停/PO只停目标、rate用于目标暂停的分配是本轮重建策略，不能作为未来PSP/GBA的原生公式依据。固定受击恢复、攻速和取消窗仍未恢复。新增122项行为检查见`reports/combat-feel/tests.json`，不代表原版手感已一致。

当前build/playable EXE SHA256为 `24ad6fa1cb7a0d26c45b867d578e3be92315329e33ed71622d548520b5636e09`，`build.cmd --test`已通过核心30、外观23、技能9、怪物110、区域17及命中反馈122项，日志 `reports/combat-feel/build-test-held-turn.log`。最终串行前台进程验证全部通过，详情 `reports/combat-feel/held-turn/release-validation.json`；发布/source/window审计84项通过，见 `reports/combat-rework/verification.json`。普通洛兰＋深处41点及实际重载通过，当前轮用户存档未变；13技能双向182图＋78补帧、怪物fixture58项、六场景三分辨率完成。普通input/deep审计使用同一成功run；fixture与消息输入不代表原PC平衡或物理键盘/IME验收。中间532构建的深处结算步骤超时保留为失败，用户同时游玩导致的存档变化未回滚，原报告与旧F30证据均保留。

普攻/技能控制器新增200ms瞬时热键缓冲，仅在普通攻击命中暂停中接收、解冻重新验证并消费一次，idle/releaseInputs清理，不保存到角色档，也不增加技能间取消资格。三段斩暂停方向保留在held输入状态，解冻第一tick恢复；普通续刀边界重设pose0。hits_多段间隔随actor局部暂停平移，崩山普通最多2次、末击单独set去重且每目标总<=3。暂停分配、200ms及frame4调度均为重建策略，不反写原内容或充当其他平台的原生常量。

构建进程TEMP/TMP/TMPDIR、Clang module及可选ccache/sccache位于D盘项目cache，Windows全局TEMP不改；用户资料/存档/失败证据保留。原生攻速与取消阈值继续查当前1031，86/DFQ证据保持版本隔离。详见reports/combat-feel/attack-speed-followup.md与reports/combat-native-reverse。

当前原生静态入口审计见 `reports/combat-native-reverse/entry-audit.md`：六份1031 ASM与另六段碰撞范围可匹配当前EXE，新增动画切换与倍率/附属ANI传播路径已保留原字节、偏移和hash；候选虚表的鬼剑士归属、全局倍率和普攻取消/受击控制链尚未恢复，不直接把其他版本数值移入运行时。裂波亮叠层及原黑芯仍未判原版一致。

## 2026-10-18 战斗、死亡与区域模型

新增内容模型继续保持 SDL 无关。`effect_plan.hpp/cpp` 的 EffectPlan／EffectTrack 保存源OBJ／ANI／ALS、字段offset、实例名、累计毫秒、层号和诊断，动画声明与创建／调度控制器分开；只读声明不能自动证明原生调用。主效果的伤害次数由模拟控制，附加视觉轨迹始终 `damageEnabled=false`。同名资源的不同ALS实例保持独立，不按路径去重；未知帧／实例规则显式记录。

`monster_effects.hpp/cpp` 的 MonsterMotion 保存MOB状态绑定、direct ANI／ACT入口、完整MOTION分层和来源引用；ACT的TRIGGER／BEHAVIOR与生成对象不在当前动画编译器执行范围。优先入口已配置但无效时保留错误，不用待机或通用哥布林动作静默覆盖。独立死亡只按有效 `[last action]` 选择；共享MonsterDeathProfile保留原die effect参数、图号／omit、PTL数量／重力／速度／寿命和flash／smoke资源。路径解析要求候选实际存在且唯一。

`ImpactContext` 保存被接受攻击的地面来源XY与travelSpeed；NaN来源才按接口约定回退角色位置。`DeathImpulse` 保留归一化地面方向、输入速度、伤害占最大HP比例及push／lift，XY平面与z高度分离。`MonsterFragment` 的固定种子、初始位置、速度、spin与帧号可由其他后端复用，绝对模拟时间解析轨迹不依赖渲染频率。来源资源保持原值；60/220/90ms视觉阶段、速度／威力合成和阻尼是当前重建策略，不写回源MOB/PTL，也不定义未来GBA／PSP必须采用同样显示预算。

Actor在死亡时保留不可变的当前Motion计划、局部时间、实体锚点／高度、独立死亡或共享资源分支与碎块列表；Renderer使用同一模型绘制白色透明轮廓和原石块IMG，不再把身体矩形切片。RegionSession的`death_visual_version=1`保存源入口／状态／字段身份、年龄、锚点、共享配置、致死输入和碎块初始位置／速度／旋转／图号；`restoreMonsterVisuals`重编译源计划并重设时钟基准，不重新触发死亡／掉落事件。纯数据可跨端保存，不能序列化平台指针或SDL纹理。旧档缺失粒子初始条件时使用已保存的位置／姿态／年龄作稳定重建；当前源绑定或共享配置不再匹配时诊断并退场，不能冒称恢复了旧档从未记录的原始画面。跨时钟JSON重载、轨迹一致、不重复发奖和移除后重返已在统一构建中实际通过，最新 `reports/monster-rework/tests.json` 为110条断言，新增覆盖down／sit恢复。

源技能字段按有序作用域选择PvE `[dungeon]` 数据，避免把同名PvP override误当普通地下城值。MotionProfile保存模拟时长／连续速度曲线和积分；崩山hold到源端点的映射、银落高度门槛、十字创建锚点等重建规则明确留在控制器层。被动63（血气旺盛）决定崩山独立冲击波资格，正常未转职角色不自动获得；诊断fixture不写入正常存档或冒称已完成转职。

人物十字slash1／2的550ms控制器生命周期与源1500ms原时长分开；依据slash2 500..550ms最后短事件帧后进入同图950ms占位，目的是避免固定大十字与移动小十字长期并列。350ms移动OBJ创建及PTL原参数不改，事件23=1的私有语义未闭合。活体落地down末姿态150..500ms、源sit过渡100..400ms（哥布林500／150）也属于本地控制器策略，不把down内10000ms飞行占位当落地硬直，不把官方overturn翻转绑定当通用getup。新平台应保留源绑定、全部原帧、恢复状态和显式path清理，不能将这组PC重建时长写回ANI。

`TownExit`保留MAP原六元矩形／目标及offset/raw；世界Y只加对应MAP的background pos。`TownArea`同时保留TWN原path与resolvedPath：当前缺失`gate.map`的显式别名为`(r)gate.map`，不回写原TWN。门附近32单位落点边距、650ms过渡间隔、NPC近距和鼠标坐标换算是当前PC应用策略，其他端独立适配。清图NPC保留sourcePosition、visible／generatedPlacement和appearedAt，不在draw中改变世界状态；德利拉落点按首领附近安全地面重建，原EXE规则仍未证明。

`DungeonRun`保留源候选和随机seed，当前两个普通地下城合法候选33张（洛兰14／深处19）。`7.map`必需左右上三门，与洛兰两列源DGN不兼容；`5.map`注册ID16无greed，旧救援OBJ的quest1不对应当前任务列表的教程。346份DGN选择字段审计、27／22种拓扑穷举与15份原解密字节/hash见 `reports/elvengard-rework`。原35张MAP均保留，未来平台不得为填满目录而制造门或丢弃特殊图来源。

普通商店／修理／指定任务链已接入。NpcDefinition的服务禁用原因和ShopDefinition的enabled／lockedReason属于当前范围策略，原role／商店字段完整保留；邮箱、金库、活动及袖珍罐未接入不能伪装成可用按钮或扣除货币。UI仍未完整还原，本轮核心pass不等于当前GUI或其他平台验收。

最新统一构建build／playable为 `a3da200d96615ecffd2e3ae8b65e530a870ec768148ccbb322a94eea6657bf31`：核心30标签、技能9项、怪物110条、区域17项、外观23项通过。修正前b04可见fixture `effects-20261018T002018-329d30` 的15样本／56项只验证隔离的accepted-hit与绘制生命周期，不证明普通碰撞、按键、原PC视觉或其他端已通过。该旧构建普通流程 `input-20261018T002135` 绕桶／清4房后在首领房角色死亡，明确为失败；旧13技能smoke `20261018T002514-367ed4b4` 的独立视觉复核记录了十字长残影，未通过原版一致性验收。新构建普通流程 `input-20261018T003634` 及smoke待主任务另行追加，不跨构建借用成功截图。移植端应保留这些验收边界和失败证据。

## 2026-10-18 外观模型与装备UI（上一轮发布记录）

`appearance.hpp/cpp`不依赖SDL。`AppearancePart`保留完整源Script、职业、slot、两个variation、全部层；`AppearanceLayer`保留源数字order、字段offset、来源路径、ANI script/目录。按有序字段解析重复职业/分层区块，不用Script::values扁平覆盖。同slot替换整组旧层，普通属性护甲无外观时不移除时装；五项default.equ为基础外观而非自动赠送物品。身体层号1000仅为当前重建，源EQU的武器650/2790等保持原数值。未知字段仍在源Script与原PVF，不写回简化结果。

`Progression::appearance(Pvf&)`按真实穿戴UID生成模型，`equippedIndex/equipped/unequip`是平台无关接口。Renderer替换当前ANI帧图像模板的variation参数，同时保留ANI局部偏移、IMG crop、时间、方向、旋转与混合。选角/场景/预览共享模型，普通护甲与时装原slot各自保存；没有新增持久化试穿字段，原schema3/未知字段保留。试穿在RegionUi局部副本，退出清除，其他端应保持预览与实际装备分离。

`equipment_ui.cpp`的800×600锚点、8×4/7×4分页、颜色/alpha、显示整理和鼠标右键/双击是当前PC界面适配，不能写回EQU或用于定义GBA/PSP行为。部位图像、层数字、原模板、原RGBA/crop/logical尺寸应跨端保留；未来后端重新决定缩放与输入映射。黑底板颜色/身体order/未核对负重比例的边界均在RENDERING记录。`tools/inspect.cpp --export-image/--export-frames`保留来源归档/偏移/尺寸；导出PNG/contact sheet和实际SDL截图区分。

该次历史发布`ba6f13d48c996f669c4bf2183af1d1528078a29ea6abba079ceed39827feec40`，30核心标签/23外观检查，800×600新角色UI与1280×720外观fixture的保存重载/未知字段/穿脱检查见`reports/equipment-ui/verification.json`。测试fixture复制隔离核心测试存档，不冒充正常获得装扮。原PVF和10个UI源字节范围hash未变，未读旧GBA或DFQ UI。Windows焦点拒绝与像素未验收状态保留；该次UI修复未改战斗控制器/公式，本轮新增战斗模型见首节。

`RegionCatalog`/`DungeonRun`、`Progression`、`RegionSession` 和 `RegionUi` 已加入 C++ PC 运行层。前两者只依赖 JSON/PVF 模型和平台无关时间，后两者分别负责持久状态与 SDL 输入/绘制适配；其他端应复用来源模型和稳定事件键，不把 Windows 文件替换或 800x600 UI 坐标写回内容数据。`MapObject` 的来源 ID、对象尺寸、阻挡和动作字段同样属于可移植内容层。

当前验证平台为 Windows x64 / C++17 / SDL2 2.32.10。PC/PVF 决定内容，原客户端只读；本项目不读取旧 GBA 实现或派生资源。未来平台的适配不能写回原数据。

## 模块边界

| 模块 | 平台无关接口 / 职责 | 平台相关边界 |
| --- | --- | --- |
| resources.hpp / resources.cpp | Pvf、Script、Animation、Assets、Pixels；原路径、重复字段、原始 token、ANI 属性和框 | Windows CP936 → UTF-8；非 Windows 遇非 ASCII CP936 明确失败，移植端必须提供真正转换 |
| scene.hpp / scene.cpp | Scene::load；MAP/TIL、背景原点、图层、可行走单元、issues | draw 在 SDL renderer.cpp 中实现；加载与碰撞模型不依赖 SDL |
| combat.hpp / combat.cpp | World::enqueue(Input)、advance(ns)、Actor、Effect、Event、snapshot、statReport | 无 SDL；测试参数和重建控制器独立于原文件，PC 一致性仍需核对 |
| effect_plan.hpp / effect_plan.cpp | EffectPlan、EffectTrack、源OBJ附层／ANI／命名ALS实例与诊断 | 无SDL；有界视觉计划不执行原生BEHAVIOR，调度策略与源声明分开 |
| monster_effects.hpp / monster_effects.cpp | MonsterMotion／DeathProfile、ImpactContext、确定性碎块采样、源绑定与省略位 | 无SDL；白化时钟和速度合成为重建，后端使用原alpha轮廓与石块资源 |
| region.hpp / region.cpp | TWN／DGN／MAP／NPC／商店注册、全部候选、seed可重现的源门拓扑 | 范围锁定／别名和重建迷宫选择策略明确记录；不写回源资料 |
| progression.hpp / progression.cpp；session.hpp / session.cpp | 稳定任务／击杀／拾取键、装备UID、区域和角色持久状态 | 价格／奖励／初始发放等重建规则分开；存储耐久性由CharacterStore承担 |
| storage.hpp / storage.cpp | CharacterStore 载入/迁移/应用/采集；保留未知字段 | Windows FlushFileBuffers + MoveFileExW；其他端需实现 fsync/rename/目录刷盘等耐久事务 |
| renderer.hpp / renderer.cpp | 身体、衣物、武器、场景、UI 绘制；`textWidth`/掉落 overlay 语义 | SDL 纹理、视口、文字与窗口；客户端 `Fonts/msjh.ttf` 作为来源资源，描边是后端重建，替换渲染后端不能修改 Actor 源坐标 |
| font.hpp / font.cpp | HintedFont 的字形 mask、advance、源字体只读约定 | Windows GDI 灰度/TrueType hint；进程私有 name 别名副本，核对原 glyph/metrics/hint 表；其他端由 Renderer 的 stb 回退或新 hint 后端承担，不需要安装 Windows 字体 |
| geometry.hpp | imageQuad：ANI位移+IMG crop、带符号缩放、旋转、朝向的四角投影 | 无SDL，后端不得用负宽矩形替代原点变换 |
| hud.hpp / hud.cpp | 原HUD帧、图标缓存、HP/MP与冷却显示 | 当前800×600参考坐标；第13槽和宽屏底纹属于demo适配 |
| audio.hpp / audio.cpp | 原 ID / RANDOM 解析、解码与混音 | SDL 音频设备/锁和 WAV 转换；回调不修改战斗世界 |
| main.cpp | 用户界面、角色与场景路由、事件适配、报告 | Windows 入口/文件操作、SDL 键鼠；仍需在未来端拆出流程控制 |

## 时间、输入与生命周期

渲染没有固定 FPS 上限，默认 vsync；战斗独立 60 Hz。World 用纳秒乘 60 的整数累加器，以 10^9 为 tick 阈值并保留余量；原 ANI 时长仍为毫秒。advance 的长停顿补齐 tick，不因渲染频率变化而改变输入回放结果。输入时间戳属于未暂停的模拟时间线；菜单与失焦释放输入，暂停间隔不计入战斗。

普通换场清除技能、抓取、附着/独立效果、输入和保护，但保留剩余技能冷却。重新应用角色配置会清空冷却并关闭 god/freeCd/freezeAi，避免角色间继承测试状态。Actor 和 Effect 的 prev/current 坐标只用于绘制插值；伤害、判定、AI 与事件由模拟推进。

## 坐标与原点

Actor x/y 是地面位置，z 为向上高度。绘制 = 地面位置 − 相机 − 高度 + 控制器局部偏移 + ANI 偏移 + IMG 裁剪偏移；左右镜像围绕局部锚点。ANI 框的六项是 x/y/z/宽/纵深/高度，type 14 为受击框，15 为攻击框。

当前战斗规范沿用MAP+bg坐标，但绘制投影必须区分实体、TIL和屏幕远中景：实测800×600下实体额外+120、TIL保留bg80、far/mid top0。当前六图固定cameraY=−120，避免未经证实的纵向跟随露出地砖底部。旧文档的“统一原点”不能作为各层绘制规则。具体实测来源见RENDERING.md。森林四份01tile00..03的TIL 14×30格采用横16/纵12世界单位，图像仍保留原224×480逻辑画布；两者不可混用。推导只对这些实例成立，并记录在Scene.tileGrids，其他TIL不自动继承。虚拟movable area存在时覆盖TIL网格。赛利亚dummy.til原IMAGE为空，仅保留224宽空白列，不从空图像推断可行走区域；其他未知空图块仍报带上下文的错误。

此前三张洛兰诊断MAP的全部原始怪物出生点已在修正后的森林网格内；旧纵16造成的出生恢复不能当作源地图错误。当前 `nearestWalkable` 先从源可走矩形逐一扣除重叠障碍，再选择真正可通行的最近点；没有自由地面时不伪造备用地面。recoverPosition处理运行时确实离界或障碍内的实体，记录position_recovery，保留原MAP字节。击退受可行走边界约束；当前AI仍为逐轴追踪，尚无完整地形寻路。

## 格式、来源与原始保存

PVF 保存原解密字节和顺序字段/token（offset/type/raw/value），CP936 明确转换。Script::values 只返回第一个同名字段；地下城/PvP 等重复上下文必须显式遍历 fields，不能无条件扁平合并。

IMG 处理交错/分离载荷、链接帧、BGRA/1555/4444/调色板及 DXT1/3/5。DXT 长度按 ceil(w/4)×ceil(h/4)×8 或 16 字节计算，有局部边缘块和后续帧对齐回归；这不代表所有 NPK/IMG 变体已覆盖。ANI 全帧、时长、声音、混合和未知属性仍保留，支持的绘图效果只是源属性子集。

身体/衣物/武器/附着效果/独立效果/弹丸分开保存，不能统一脚底对齐或通过去黑像素替代 ANI 的加色混合。波动剑与裂波斩的特殊占位帧只在运行时解释，原 ANI 不改。中文字体文件只读保留来源 hash；文字的亮色字芯、紧边和弱羽化由 UI 后端重建，不能把 Windows 主机字体名或 800×600 坐标写回来源层。

战斗判定与绘制必须覆盖相同的武器 b/c 层：当前四种武器普通第二刀的 type-15 攻击框仅存在 c 层。World::attackFrames 按身体动作帧索引读取身体及两层原框，strike 按目标对每刀去重，连击切刀清空去重表；不可仅凭某一层缺框就把第二刀当空动作。2026-10-17 四武器 × 双方向回归覆盖每刀命中、跨层/帧去重、结束与步行恢复，原 ANI 框/字节/时间不变。

每次运行 resources.json 保存实际访问的 PVF 路径、偏移、长度、CRC 与 NPK 归档/偏移/长度。tools/export_runtime_manifest.py 生成相应原字节范围的 SHA256；PVF 范围是加密且对齐的字节，与 source-evidence 的解密脚本 hash 分别标注。它是实际访问集合，尚非完整依赖闭包；散装音乐、audio.xml、字体和工具链也仍依赖原环境。

tools/export_evidence.py 从只读 immutable SQLite 研究库导出101份限定源文件、模型与hash，其中74份REP是早先鬼剑士限定导出。当前完整PVF实际有484份REP，技能槽关联研究另在reports/rep-reference；不能把限定导出数量当全PVF数量，按键／时间和播放器语义未验证，不能宣称已恢复原录像回放或完整控制器。新增347份技能成员与区域15份原始脚本各有独立manifest／hash，不覆盖旧证据。

## 存档与报告

角色 schema 3：20 槽，保留 schema 1/2 迁移、技能/绑定/被动、区域迷宫和对象/角色状态、任务/掉落去重账本及未知字段。有效 primary 才更新备份；primary 损坏读备份，两份都坏明确报错并保留文件。原子替换在短暂 Windows 共享冲突时重试，写入与 flush 失败不静默忽略。

每次运行有独立 run ID、run.json、runtime/fatal、输入、事件、截图与实际资源访问报告；smoke 使用私有存档。普通输入验收也使用独立 save-dir，并比较用户存档运行前后 SHA256。报告不能仅凭旧同名文件判断最近运行。

本地发布 tools/package_playable.py 将已有 EXE、SDL2.dll、libunwind.dll 放到与 build 同级的 playable，并生成无需 Python 的启动脚本和 SHA256 清单。当前程序将工作目录定位至 exe 的两级父目录；playable 因此必须保留在工程下，使用原 saves 和完整原客户端，不是可任意移动的资源子集包。发布不复制用户存档，游戏运行时拒绝覆盖。

## 未来端口工作

PSP 等平台需要资源子集/内存预算、真实 CP936 转换、绘制和音频后端、存储耐久性及输入映射。GBA 的采样、调色板、按键组合、提前开放与冷却简化属于独立平台配置。当前 Windows 检查不构成任何其他平台通过的证据。

尚未完成可携带子集包、完整依赖闭包、同版本伤害公式、完整装备/轻甲精通、全图寻路、原 PC 控制器动态金标与全部绘图/声音事件。参见 CONTROLLERS.md 和 IMPLEMENTATION.md，不能把接口存在等同于内容完整。
> 2026-10-18 续做边界：本轮只拟修复Windows验收工具`verify_flow.py`在障碍前微小转向点的导航，8px阈值属于测试器策略，不是PC/PVF原生常量，也不应进入未来移植内容层。原始资源、调用证据、失败运行和当前发布包继续保留。OS112磁盘满及审批服务403阻止新的运行验证，未据此改变当前发布身份或完整度声明。详情见`../reports/combat-rework/continuation-20261018-environment-block.json`。

> 最新续做结果：测试器8px转向阈值与8次无位移诊断属于Windows自动按键策略；`World`目标点碰撞与步长未修改，源PVF/原资源不变。a3da普通洛兰/深处/重载39点通过，不代表全源35图均实际按键走过或PSP/GBA运行验收；合法普通33图模型保留。技能原帧/混合/原生控制器未知继续保留，不能把背景加色差异写回内容资产。


# 当前实施：源时序与控制器时间轴的保全（2026-10-20）

本轮未验收前查`reports/attack-timing-offset-20261020/NODE-PROGRESS.md`。源ANI保持帧不在解析器中截断；便携控制层保存source/runtime delay映射、命令次数/间隔/期限及证据，不将平台时钟或渲染FPS当技能计时。有效根delay以共享不可变所有权跨私有事务复制，供身体、装备、ALS和攻击几何投影；实例退出/换场/死亡清理，普通存档仍取消瞬态。

技能层SourceRef和原图/偏移/框保留，但inferred附件绑定和局部原生坐标证据分开，不能将Windows自动检查推为PSP或原客户端动态已验。新启动脚本保持原客户端和历史候选，只在D盘独立cache/save/report工作。当前版体验候选交付后等用户确认，下一版目录选择仅登记于`OPTIONAL-CONTENT-SELECTOR.md`。

# 2026-10-20 持续输入与测试身份合同

平台输入必须保留Attack/Jump的DOWN边沿和UP事实；OS重复DOWN不等于再次点击，hitstop/暂停不消耗持续时钟，焦点释放会在下一模拟边界停止需按住的channel。源技能热键和Attack是不同输入。停止命令以SkillKey+actionSequence定位本动作持续实体/附层，不清除已独立射出的弹丸；尾效没有伤害，恢复时长与原ANI字节分开。当前窗口专用职业切换通过DebugService命令/回执，主应用先建立BetaSaveBranch再使用CharacterStore自己的EQU/属性预检；正常存档与学习账本不可被覆盖。未来端口保留来源、局部/世界原点、推断锚点及原始ANI/IMG数据。

