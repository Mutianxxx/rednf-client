> 2026-11-02：后续人物/怪物/地图/特效、弹窗/HUD与SDL后端的职责按[架构拆分大纲](ARCHITECTURE-REFACTOR-OUTLINE.md)规划；统一坐标和动画合同，显示不写战斗状态。本轮未修改渲染实现或发布新版本。

<!-- equipment458-live-status -->
# 当前装备资格与正常学习预算节点

阶段：`paused_after_original_o3_debugger1`；会话：`None`。预计459份编译输入、181份完整报告，独立构建`cache/seven-job-equipment458-build`。最新已验证体验仍按实际完成记录：`checkpoints/20261020T224815926748Z-mage-upper457`；统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

**已按用户要求暂停。** 当前一轮已结束；不再启动构建、测试、备份发布或后续节点。恢复先读本节点PAUSE-SUMMARY-20261021.md和PAUSE-RECEIPT.json，等待用户继续。

女法师天击457已完成1142成员源码/产物/证据备份，两遍哈希零差异。当前仅继续装备单ID技能资格、正常SP/TP预算及目标私有恢复/GSD预检；分支赠送与真实30200条件眩晕不混入完成。女格斗普通副本死亡失败保留，七职业全普通副本/完整技能和最终十职业beta尚未完成。原资料、正常存档和历史候选保护，构建/运行/备份串行；前台画面、听音、手感与原版动态比较待用户。

恢复读`dnf-native-demo/reports/seven-job-world-20261020/equipment458-integration/RUNNING-STATE.json`、本节点PROGRESS与实际日志。先poll实际会话，不重跑已结束attempt，不删除他人锁或覆盖运行产物。下方旧记录为历史。
<!-- /equipment458-live-status -->

<!-- mage457-live-status -->
# 当前女法师天击节点（以实际收据为准）

阶段：`mage457_complete`；会话：`None`。候选输入预期457份、完整报告180份，构建目录`cache/seven-job-mage-upper457-build`。最新已验证体验：`checkpoints/20261020T224815926748Z-mage-upper457`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

女格斗原ordinary1死亡及观察复现完整保留；该失败不算正常游玩通过。Mage是独立功能验证，七职业全部普通副本、完整技能及最终十职业beta仍未完成。所有新构建、测试、审计和备份串行，原资料、用户存档及历史候选保护；前台画面、听音、手感与原版动态比较由用户执行。

恢复先读`dnf-native-demo/reports/seven-job-world-20261020/mage-upper457-integration/RUNNING-STATE.json`与节点PROGRESS、实际日志；不重启已结束attempt，不删除他人锁。下方保留历史记录。
<!-- /mage457-live-status -->

# 当前节点：女格斗上勾拳自动通过并备份，继续职业/普通副本

fighter-upper454完整核心/音频/隐藏UI、同主EXE来源/content/dummy及源码产物证据备份通过，EXE `8c37d12288b0f6dbbe6a0731140b2dbd4581e587eed9bcf9f6b7df1280665249`，454输入/179报告，ACT62、九声音18PCM。自身初始5/正常SP20/MP-CD/默认Z/双音/真实EQU与怪物反应及恢复已接；TP163、拳套required34与原生caller仍有具体缺口。Priest e6b57/ready5完整三段fixture链及实际失败与应用证据、movement fixture3及实例clock/frameStartMs和前序Water/Knee/AI/奖励保留。Fighter a182→8b1a计时采样及真实30200错误成功前提两次窄修、原preflight1/2失败/独立诊断和父应用收据完整保留，原740..774未改。四类World释放通过；拳套仅严格原子拒绝与独立源几何，不称五类实跑。本轮还保full1真实失败、精确SkillKey休眠preview测试修正和独审/父应用；normal/runtime1与dormant10不变，完整normal bridge新增第五专项。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-node/PROGRESS.md，备份 `20261020T211925962396Z-fighter-upper454`。七职业全副本/最终十职业未完成，原资料/存档/历史候选保护，继续。

# 当前恢复点：454预览索引断言已独审窄修，等待新正式验证（2026-10-21）

最新已验证体验仍453：`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。454尚未完成，不更新latest。

compile3/preflight3通过后，full attempt1/session24920真实exit1于旧normal bridge预览数组[0]断言。父保原断言诊断session28360实测：目标{1,6}正常1、预览10，数组首项实际为新增免费{1,5}/1；运行时恢复正确。原full失败、原C++再次exit1、观测与完整闭包保留。

Skill封31成员最窄提案（manifest4d4279aa，test46387ffc），UI独审6成员b2f08abb通过；父独立编译并运行整份normal bridge提案session88480退出0，RESULT652ac822。随后父按精确diff合入，`legacy-preview-APPLICATION.json`保真实pass/独审/旧失败身份，其余453输入逐hash不变。仅按完整SkillKey唯一找预览binding；normal mode/runtime1/dormant10及其他76检查不变，运行时不改。当前无运行会话，UI在准备全新ready5，追加第5项完整normal bridge专项，保原四项、454输入/179报告与全部来源/事务门。

恢复优先读本节点RUNNING-STATE、PROGRESS和真实日志，不重跑历史attempt/旧ready4验证新源，不删除活动锁。下一步ready5父核→compile4→preflight4五专项→full attempt2→同EXE/源码产物证据二遍备份→普通job1/DGN1/seed1。ordinary路径工具须在新禁用successor绑定实际ready5 schema，不改旧封包。OBJ0显式manifest交叉门overlay、装备预算和分支赠送successor均封未合，女法天击在独占staging实现；不并行构建运行。原资源/历史候选/正常存档保护，全部D盘；七职业全部普通副本/完整技能及最终十职业仍未完成，持续实施。

# 当前恢复点：女格斗454编译通过，专项计时采样窄修已应用（2026-10-21）

453已完整验证备份，最新体验为`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，1537成员二遍零差异；普通圣职DGN1/seed1四房/21击杀拾取/20技能及结算恢复返城通过132检查。454 compile1已通过；preflight1真实168检查末条时长失败，clock-diagnostic1保原断言实测源body740ms在按键后750ms完成，旧测试漏计首tick16ms而得到734ms。独审只移动started到按键前，原740..774和全部断言不变；父已精确应用test8b1a，其余453编译输入不变。当前无运行会话，等待ready2工具绑定实际失败/独审/应用后compile2和preflight2，再full/同EXE/二遍备份，latest保持453。恢复读`dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-integration/PROGRESS.md`、RUNNING-STATE及真实日志；不复用旧ready1假称新闭包，不并行构建运行/改正式源。原资料/历史候选/正常存档保护，七职全普通副本和完整技能/最终十职未完成，继续。下方running为历史。

# 当前渲染候选：女格斗上勾拳454待运行验证（2026-10-21）

女性自身身体740ms，武器1370ms跟随body不延长动作，女性视觉650ms保首320ms空白并沿自身owner-rate策略；不套Priest独立source-clock出生。READY接受时一次、SWING首真实body type15一次，关联与caller仍inferred beta。已窄合，compile1/session9555串行重编，正式输入冻结，尚未C++专项或画面验收；保留453的frameStartMs/instanceClock，最新已备份体验为`20261020T183257823234Z-priest-upper453`。恢复见`reports/seven-job-world-20261020/fighter-upper454-integration/`。

# 当前节点：圣职者空斩打自动通过并备份，继续职业/普通副本（2026-10-20）

priest-upper完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `924ff1f85d65154c1f87ff200fffdd1e64ca97de143fed871d31ddc66ece8490`，453输入/178报告。正常初始1/SP20升2/真实EQU攻击框/精确frame2效果出生/240ms源寿命及伤害/ACT40/保存恢复已接；TP210与Avenger123仍未实现，旧已学收费前诊断保ledger，WillDriver13 active gate留后续。前序Water/Knee/AI/拾取/学习/奖励保留。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/priest-upper453-node/PROGRESS.md，备份 `20261020T183257823234Z-priest-upper453`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续。

# 圣职空斩打实例效果待验收（2026-10-21）

恢复补充：第二次专项未进入纯runtime动画，原因是测试actor缺武器subtype，不能据此认定ANI时钟错误。独立诊断及失败保留，仅修测试装备前提，继续真实frameStartMs/overshoot/停帧和源寿命验证；尚无本节点前台画面验收。

Upper条件改动已精确合入453：源body780ms不延长，两240ms前后效果从实际武器首攻击frame2的真实deadline出生，以独立rate100实例clock呈现、hitstop冻结、源结束或owner退出清理；renderer只消费快照。关联/前后顺序与出生仍为inferred beta。compile1通过，专项因故障注入未实际命中字段失败，fixture纠正中；没有新前台视觉验收，最新可体验仍movement452备份。

# 当前节点：普通受击方向输入恢复自动通过并备份（2026-10-20）

movement-reaction完整核心/音频/隐藏UI及同主EXE来源/content/3秒dummy通过，EXE `00ee62e405344c3879ce18461cf844ee293aaa70f7aa9a7ffc2a2f2c2844934e`，452输入/177报告。原test修前真实失败560→560，revision2/3仅修城镇Knee配置及源来袭准备，green1/2失败和诊断保留；最终两个clock六样本验证普通受击恢复方向、KEYUP/失焦双击/换房及正常Knee MP/CD无重放，不称测试字节未变。仅活人显式中断保四方向，其余动作清理，source/数值不改，策略保持推断；status/lethal无新增直接覆盖，普通副本额外结果不泛化。备份 `20261020T163114547687Z-movement-reaction`，详见dnf-native-demo/reports/seven-job-world-20261020/movement-reaction-node/PROGRESS.md。七职业全普通副本及最终十职业未完成，特殊机制延期；后续Priest须实际452新基线窄重基。原资源/历史候选/正常存档保护，继续。

# 受击动作与输入恢复：验证状态（2026-10-20）

本次仅修宿主动作取消与物理方向持有的生命周期，不裁剪原ANI、不修改攻击/受击框、坐标、装备层或伤害。source-delay-rate100及inferred60us-percent-deadlines的真实World来源哥布林命中、恢复移动和普通Knee收费检查均通过green3；原版本可复现恢复后X不变。paid场景按已选敌ANI首type15前50ms释放，避免Knee先击倒怪物；这是测试准备，非运行时技能时序调整。完整回归、普通副本与备份尚未完；前台画面/声音/手感及原版动态待用户，latest保持watercannon-normal。来源/失败链及实际状态见reports/seven-job-world-20261020/movement-reaction-integration。

# 当前节点：男法魔法冰球正常基础26自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon-normal完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e183644cb660b231ff7205ba7cb2b36d4cd451ca2b3010c7bbc453c355d89ffc`，451输入/176报告。正常26已接来源初始1/SP15升2/learned槽/一次MP-CD/真实flight-impact/受击/GSD/保存恢复；TP236与元素链51仍false，已学旧被动具体挡在收费前且保账本。前序Water、正常Knee/AI/active/拾取/学习/保存奖励保留；实际边界、beta推断与用户步骤见dnf-native-demo/reports/seven-job-world-20261020/watercannon-normal-node/PROGRESS.md，备份 `20261020T145242215868Z-watercannon-normal`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 当前节点：男法魔法冰球预览链自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e059c892d4c2182911670581c0390ddaa457d37e358080ed8753a97b5172d3e8`，450输入/175报告。已接自身来源fixed body→moving PO→accepted nonmiss→impact/typed排除与独立ALS树；正常26/TP236/元素链51仍false。保留正常Knee/AI/active/拾取/学习/保存奖励，新增实际ACT16场景、六声音12项PCM及两clock等检查。beta回调/缩放/受击等推断与待用户体验见dnf-native-demo/reports/seven-job-world-20261020/watercannon-node/PROGRESS.md，备份 `20261020T141256959979Z-watercannon`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 当前节点：正常怪物Event与男枪膝撞自动通过并备份，继续职业/普通副本（2026-10-20）

normal-combat完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `1f29cfe5ad188dc3565bcea5169ccbd183d53927ef7217345fbd7222e32e35d8`，448输入/174报告。普通source-think自动安装现有Event子集，显式/F7/恢复binding/pending/window/RNG保留；实际Event到Jena ACT及MAP factory通过，不称完整AI。男枪2/4正常初始/SP/槽/Z/MP/CD/伤害/ACT22/装备/GSD/恢复已接，stable Audio0与三份OGG独立dummy解码通过；TP168正常仍false，原生caller/保护/公式等保持推断。金币等前节点修复保留，范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/normal-combat-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续真实多房洛兰和男法WaterCannon；七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 正在实施：普通Event与膝撞正常接纳，完整回归中（2026-10-20）

最近验证备份为checkpoints/20261020T121835179429Z-active-source-reaction，EXE75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e。随后normal AI7与Knee13文件已窄合，compile-only与六组专项通过，448输入冻结运行normal-combat full attempt2；尚未新交付。先读reports/seven-job-world-20261020/normal-combat-integration/PROGRESS.md与RUNNING-STATE.json恢复，禁止测试中改源码或并行构建。原资料/存档/历史候选保护，自动仅hidden/dummy；任务继续。

# 当前节点：地面来源技能活跃ACT受击自动通过并备份，继续技能/普通AI（2026-10-20）

active-source-reaction完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e`，446输入/173报告。精确地面单BodyAttack的霸体/普通/控制/死亡和prepared清理已接；两个clock共22场景通过，MISS/fault不取消，多owner晚故障保留前一成功。MP/CD/KEYUP/序号保持；实体/channel/空中仍具体挡。男枪膝撞正常implemented=false，新生产技能0，TP/声音/接纳继续。金币等前节点修复保留。范围/推断/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/active-source-reaction-node/PROGRESS.md，备份查checkpoints/LATEST.md。全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：基本副本奖励与保存恢复自动通过并备份，继续技能/普通AI（2026-10-20）

basic-dungeon-flow完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `9fc5e798d0df028f92f50181a6cf09324c5798289bdfaa67a5f3509b6382ff09`，446输入/173报告。已接独立击杀奖励游标、intent→私有准备→final持久化→Results/房门、实际writer证明/normal-beta显式handover、KEYDOWN/UP冻结与tick后点击门、主入口共享beta退出确认Reset及可重试保存。正常学习/升级/分支隔离组合、四GSD故障和beta退出故障已执行。金币及同物品图标回退保留。fixture不等于全main/全副本按键游玩，具体七类未覆盖边界/来源/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/basic-dungeon-flow-node/PROGRESS.md。备份查checkpoints/LATEST.md。继续地面source-body活跃ACT受击、膝撞正常接纳和普通Event.ai；全七职业全副本/最终十职业未完成，特殊机制延期。原资料/存档/历史候选保护。

# 当前节点：男枪膝撞来源预览自动通过并备份，继续基本副本（2026-10-20）

gunner-knee完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `7c0b508feb3227a2c892e0f5620367a9b4b33a945e05cc407397313f5f035aad`，434输入/160报告。own job2/skill4的SKL/CHR motion11/ATK1、原750ms身体/装备判定、速度/独立攻击/浮空和窄特效已接隔离预览；特效caller/层、攻速/浮空和当前帧type13霸体保持版本推断。TP/取消/语音/活跃ACT受击/正常接纳未闭合，正常implemented=false，新完整生产技能0。金币和同物品图标回退等前节点修复保留。范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-knee-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续窄合基本副本A/B/C/D及保存期间KEYUP冻结缺口；全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：正常学习/快捷栏/运行时桥自动通过，继续技能与基本副本（2026-10-20）

normal-learning完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `2562c82999bfd1bc7f39ee64a2b9eee5ce463f594dfdc1cd799f33f2366cf3cc`，433输入/159报告。K/NPC正常学习→SkillKey持久购买→有效已学F6快捷栏→原runtime单次MP/CD→同代重载/GSD已接已有消费者；normal/test/manual配置隔离，旧raw休眠，F9显式preview，身体/装备模板与目标外观保存前预检。仅四个own source动作及女枪19主动/12被动正常接纳，其他行保留具体禁用，新生产控制器0。金币等前节点修复保留。具体范围、推断和用户步骤见dnf-native-demo/reports/seven-job-world-20261020/normal-learning-node/PROGRESS.md，备份目录查主工程checkpoints/LATEST.md。下一步膝撞、基本副本A+B及writer/恢复诊断修正；全七职业全副本和最终十职业beta未完成，特殊机制延期。任务继续，原客户端/资料/正常存档/历史候选保护。

# 当前节点：普通/觉醒技能资格分表自动通过，继续正常学习桥（2026-10-20）

second-qualification完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `12b91631fba0a521c9d333a5768d577cdfbd979db3cf47012fb943eeb62fb22c`，430输入/156报告。修复合法空普通fitness和仅有独立觉醒fitness来源的资格早退；当前1734注册行形状已核查，女枪四觉醒/女法光电冰墙及实际GSD rebase消费者同闭包验证。分表选择/两列/回退仍标推断，无新生产控制器或完整正常学习声称。金币等上一节点修复保留，来源/边界/用户步骤见dnf-native-demo/reports/seven-job-world-20261020/second-qualification-node/PROGRESS.md，源码/产物/证据备份查主工程checkpoints/LATEST.md。下一步完整非鬼剑士正常SP学习UI/事务/binding/恢复桥，基本副本A+B仍私有待合、特殊机制延期。原客户端/资料/正常存档/历史候选保护，任务继续。

# 当前节点：掉落/拾取与交互界面自动通过，继续七职业/全副本（2026-10-20）

presentation-pickup完整核心/音频/隐藏SDL、同主EXE profile/content和dummy通过。EXE `c0d35235cdb2d64ba688f56276ac5097994b65b92396aba00f90fd268154995e`，429输入/155报告。金币独立绘制、同物品缺图回退、材料锚点、七职业GetItem与ACT提交打断、NPC X/点击、大地图移动、源加载图/标题、Boss矩形末管红、卡片四档/双击与GSD源等级直接转职一觉已整合。实际范围、推断和待用户体验见dnf-native-demo/reports/seven-job-world-20261020/presentation-pickup-node/PROGRESS.md；节点源码/产物/证据备份查checkpoints/LATEST.md。女法龙牙与七职业中立地面受击已同闭包重编。七职业完整技能/正常非鬼剑士SP学习/全副本基本结算仍未完成，普通Event.ai自动安装和难度属性倍率具体缺口保留，特殊机制延期。下一步继续实质技能和基本副本，原资料/正常存档/历史候选保护有效。

# 当前节点：复仇之刺/下段踢自动通过并备份，继续技能与交互界面（2026-10-20）

body-skills完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过。EXE `e86bd50de645720698a93294d20a550e4d156a64b2e08cef98d07f4fa3954133`，409输入/145报告。job4/116复仇之刺与job1/6下段踢实际消费者已合入，源链/推断/正常学习缺口及用户步骤见dnf-native-demo/reports/seven-job-world-20261020/body-skills-node/PROGRESS.md。逐节点源码/产物/证据备份见checkpoints/LATEST.md。接着窄合女法龙牙、prepared七职业地面受击、GSD直接身份与新版界面/拾取；特殊机制延期，全副本基本流程与七职业完整内容仍未完成。最新Boss矩形多色末管红、卡片难度/双击、源加载图/标题、大地图移动、对话按X/点击继续、拾取动作/高亮/金币图像正在独立节点中，尚未包含。原资源/正常存档/历史候选保护，任务继续。

# 当前节点：ACT判定、伤害窗口与同代恢复自动通过，继续职业技能（2026-10-20）

act-window完整核心/音频/隐藏UI、同EXE profile/content及SDL dummy通过；EXE `fd6c1d415122c917d001b5656c314ac6d792067bb8482cd4f906b58a59c183e5`，407输入/143报告。真实monster→中立地面鬼剑士根ANI接触、源伤害/去重/事务回滚，与三个player→monster伤害生产者窗口/Event.ai pending/typed房间同代恢复已串行整合。具体来源、推断、已支持范围、用户步骤与恢复查dnf-native-demo/reports/seven-job-world-20261020/act-window-node/PROGRESS.md，节点源码/编译产物备份查主工程checkpoints/LATEST.md。实验职业/动作中断、空中/恢复/抓取、DOT/非玩家来源仍未闭合；不把诊断fixture计作完整怪物。用户本轮只需全部副本基本进出/战斗/通关/结算/返城，特殊机制延期；转职觉醒来源等级达标后GSD直接设置、无任务材料并控制学习，详见PLAYABLE-SCOPE-UPDATE.md。GSD尚待实现，下一步圣职复仇之刺/女格斗下段踢、其余职业与prepared反应、GSD及普通副本。原资源/历史候选/正常存档继续保护，任务持续。

# 最新用户范围：全部副本基本流程，等级达标后GSD直接转职觉醒（2026-10-20）

用户明确本轮正常游玩只需所有副本能进入、基本战斗/清图/通关/结算/返城，不要求全部特殊机制；转职/觉醒达到来源等级后在GSD直接设置，无任务材料流程，按新身份/觉醒阶段/等级控制学习。原源数据保留，简化单列用户策略，不将空图加载失败算通关或模板算完整技能。七职业技能和已反馈战斗/UI/地图/性能修复继续，正常学习与测试overlay隔离。GSD直接设置尚未正式实现，由ui-staging/gsd-advancement-next独占节点推进。详细范围与验收见dnf-native-demo/reports/seven-job-world-20261020/PLAYABLE-SCOPE-UPDATE.md；此条覆盖下文完整机制和转职任务的旧门槛。原资源/历史候选/正常存档保护及逐节点备份继续。

# 最新用户调整：副本特殊机制先不做，七职业技能与普通副本优先（2026-10-20）

用户明确“副本特殊机制可以先不做”。本轮暂缓hellparty/深渊/APC特殊遭遇、塔专属流程及副本专属机关/特殊反击扩展；来源和已完成私有成果保留，不计完成。七职业实质技能、正常学习/装备/成长、普通怪物AI与Boss基础战斗、物件/门、地图/UI/性能及普通副本结算返城继续优先。全地图暂不等级/任务准入，资源/格式缺口具体诊断，特殊路径不静默算通关。当前已合ACT/window完成必要全量验证和备份后转回职业技能。详细范围与恢复见dnf-native-demo/reports/seven-job-world-20261020/SPECIAL-MECHANISMS-DEFERRED.md。此条覆盖下文先做特殊机制的旧排序，原资源/历史候选/正常存档继续保护。

# 当前节点：男枪普攻/跳跃与世界反馈自动通过，持续后续实施（2026-10-20）

gunner-world 完整核心/音频/隐藏UI、同主EXE来源审计及SDL dummy通过；EXE `ab83a1c666b6e9c432c086be3f831f3c26cacd21adab84f64ff86360da957130`，398输入/140报告。男枪第三枪分段/源弹速和跳跃局部时钟、枪口渲染profile、UI/门/TIL、入场怪物等级及选角回区域源赛丽亚已整合；精确范围/推断/用户步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-world-node/PROGRESS.md。独立源码/编译产物/证据备份查主工程checkpoints/LATEST.md。男枪948、枪口profile98、raw11命中72等专项在本次正式闭包重跑；前台/原版动态待用户，不将通过检查计作技能完整度。下一步SET DAMAGE CHECK、hellparty与ACT/APC/塔及其余职业技能，七职业全副本/最终十职业门槛仍开放。此最新状态覆盖下文历史未合入和等待门；不暂停任务、不缩范围，原资料/正常存档/历史候选保护有效。

# 当前节点：属性弹、源缓存与共享攻击移动自动通过，继续地图/UI及登录修复（2026-10-20）

attack-motion完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过；EXE `1b65e9728181dc8460026aa0596593ba0ea4a2e107b71f61c8c7050fb377d932`，374输入/124报告。专项移动672、属性弹1468、缓存28、跳攻436、Action.ai787。准确推断/范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/attack-motion-node/PROGRESS.md，源码/产物节点备份查主工程checkpoints/LATEST.md。下一节点修进图退出/长诊断、怪物按入场角色有效等级冻结、再选角色回当前区域赛丽亚及选择/地图UI；这些最新要求尚未在本节点完成。ACT/APC/五职业实质技能和全图门槛继续开放，不暂停任务、不缩减范围，原资源/历史候选/正常存档保护有效。

# 当前节点：女枪跳攻/源武器与Action.ai自动通过，任务继续（2026-10-20）

正式combat-source节点完成完整核心/音频/隐藏UI、同EXE profile/content与SDL dummy；EXE `fe53ce32fabeddb916af979d0f55ba4c35a13a9644e777a950f8dfee460b3a1d`，370输入/121报告，真实World女枪跳攻/源枪口/资格436项与Action.ai787项通过。build为cache/seven-job-combat-source-build，tests为cache/seven-job-combat-source-tests-attempt1。范围、推断、用户步骤和恢复查dnf-native-demo/reports/seven-job-world-20261020/combat-source-node/PROGRESS.md，节点源码/产物/证据备份查主工程checkpoints/LATEST.md。按需PVF/场景节点保留；这是中间节点，继续源工作缓存/属性弹、共享攻击移动、ACT碰撞受击、APC/塔及七职业全副本，不按历史等待门暂停。原生socket/PTL运动、Destination/Move消费者、完整ACT pending恢复、statBase27与五职业技能缺口仍具体保留，不将索引或模板计作完成。原资源/历史候选/用户存档保护有效。

# 七职业全副本修复：性能基础节点自动通过，继续整合（2026-10-20）

下一待验节点新增源MM多层地图、WDM入口、源小地图方向/Boss帧、Boss血条和地面ANI光环；UI布局/标记/绑定及闪动选择仍按报告区分推断。物件仅7个已审计ID/path消费源破坏ANI/PTL/声音，未批量推断全部目录。源受击两个可用姿态由独立、可恢复MonsterHurt随机域选取，空中/倒地沿旧反应规则。此批正式合入不等于新EXE或前台已通过；当前可打开性能备份见checkpoints/LATEST.md。

当前按需资源/世界节点已通过完整构建、核心/音频/隐藏UI及同主EXE来源/SDL dummy审计；实际源WDM/MM、方向小地图、Boss专属血条/地面光环、物件受击破坏/粒子及可恢复受击随机已接消费者。四组同代专项为88/1112/142/6项，真实隐藏截图随报告保留；前台画面/听音/手感与原版动态仍待用户。私有下一Scene先准备资源和恢复后障碍，失败保留旧房间。精确范围见reports/seven-job-world-20261020/resource-world-node/PROGRESS.md和CURRENT-NODE.md。按需不改变ANI原始坐标与时钟；未实现内存淘汰预算，CPU量测不包含GPU/FPS验收。女枪枪口/跳攻新包尚未窄合正式树，不能提前宣布解决。

用户本轮13项及追加7项已授权继续；当前先验证独立性能基础节点，随后继续技能、全区域与怪物整合，尚未交付七职业全副本候选。调试服务缓存不可变来源身份行并逐次检查实际controller支持集，命令回执仅变更时复制；所有HP/MP、身份、pending tick、AI诊断仍即时更新。删除无消费者的逐帧World全量快照。空ACT宿主在没有实例、速度、关系、显示所有权及气泡时只提交连续tick和publication epoch，避免每tick复制全部Actor来源属性；有任何运行状态仍走原子Batch。具体前后同场景测量与状态一致性见reports/seven-job-world-20261020/performance-*.json；这是CPU逻辑量测，不是用户设备GPU/FPS验收。怪物渲染诊断按来源条目及ACT消费状态一次记录，仍保留两种模式的差异。原PVF/ANI、正常存档、历史候选及未来平台原始数据均保留。

<!-- selection-ime-verified-handoff -->
# 最新体验候选：技能图层、选择界面与IME自动验证通过，等待用户确认

主工程当前候选完整核心/音频/隐藏UI、同EXE来源审计和SDL dummy冒烟通过；EXE `74b7e5c3a59783057c482c4f442889389f9d849706527ee367a5e62d88dfd26a`，349输入/110报告绑定。入口`D:\dnf-rebuild\dnf-native-demo\Start-Selection-IME-Fixes.cmd`在checkpoint核验后发布，准确备份目录见dnf-native-demo/checkpoints/LATEST.md。范围、源透明/缺图、未恢复Full输入及其他推断/缺口、用户步骤和恢复点见dnf-native-demo/reports/selection-ime-20261020/NODE-PROGRESS.md；不是全十职业beta完成。前台/IME/听音/手感和原版动态待用户。**交付后等待用户确认才继续其他节点。** 不维护独立预览，原资源/历史候选/用户存档保护继续有效。

# 当前动作/技能节点自动通过，继续整合已排入的界面节点

完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy冒烟通过。EXE `d571ad37668b52c38afa0bd8e18c216eeb44256a2a9b56183066d60bb68fe0b9`；332输入/102报告绑定。范围、推断、失败记录、用户步骤和恢复点见reports/attack-timing-offset-20261020/NODE-PROGRESS.md。节点备份目录以checkpoints/LATEST.md为准，完成备份后才继续正式源整合。当前只是中间节点，最终体验候选尚待下一节点编译和用户确认，不能当完整beta。

# 当前动作附层与坐标修复（2026-10-20）

SKL/CHR人物动作、EQU/LAY装备、控制器技能武器层和ALS独立视觉实例分别消费来源与时钟。受控时序保留源DELAY，独立发布runtime DELAY给身体、同步图层和装备框；非同步图层按自身DELAY/loop绘制。普通ALS draw-only使用ownerX+facing*sourceX、ownerY+sourceY、ownerZ+sourceZ生成世界实例；不能用同一Z修正套所有资源。效果XYZ前态用同一alpha插值，图层顺序只在相同groundY排序，显式groundRender与任意负source layer分开。特殊ground sentinel、follow/random等ALS仍给具体诊断。

新来源与实际消费者矩阵位于reports/attack-timing-offset-20261020/；枪舞/重武器绑定和层序仍为集中推断，原版动态及用户画面未验收。最终构建/测试与backup身份以节点进度记录为准。

# 女枪实体、业务 UI 与地图层序修复（2026-10-20）

验证身份、当前通过项和用户步骤查 `reports/knowledge-base-audit/NODE-PROGRESS.md`，未产出该报告前不视为交付完成。女枪人物动作/装备仍由CHR/EQU/LAY绘制，独立OBJ/MOB阶段和ALS由实际World实体管理；枪舞不将可变装扮模板路径当特效IMG直接打开，也不重复绘制身体。根效果与动态ALS按源帧区间推进，移动实体的子层跟随父实例，延迟阶段在born前不显示，切图/死亡/父实例过期清理。独立效果保持SourceDelay100时钟；候选人物时钟与跨版本渲染策略明确登记，二者不混作原生1031证实。

业务UI读取当前1031的popup.img、WindowCommon、NPC对话底板和肖像索引；当前版本的popups02社交菜单不用于替代NPC服务菜单。装备绑定源槽位，任务/正文/技能列表分页；学习图标使用common `[icon]` 元数据，费用小数仅在显示处格式化，不改源数值。自定义分页/技能格布局与完整原客户端像素对照分别记录。

`sceneDrawCommands` 保留背景ANI的sourceLayer、sourceOrder和数值order，分别消费far/middle/near视差，兼容upper与[upper]。close/below在TIL前，close/upper在人物及近景层后。实际FireCurtain的SDL dummy前景像素检查与124张优先源图的尺寸/边界检查分别进行；不能据矩形覆盖就宣称所有透明像素、顶部/底部黑边和用户原版画面一致。相机公式本轮未查到新的可复现算术错误，保留既有按源覆盖及分辨率重算的合同。

# R60-03技能空放退出修复：自动验证通过（2026-10-20）

新主EXE `f2d7434e25b297d03e9d7c611db9f03ea945db407ec15f8f1e81114bba5d6638`，实际World 2692项/18次空放、学习51项、完整核心/音频30项、来源审计及局部SDL dummy smoke通过。启动 `D:\dnf-rebuild\dnf-native-demo\Start-Skill-Crashfix.cmd`；备份查 `reverse-60us/checkpoints/LATEST.json`。用户操作复测待执行。后续集中主工程，不单独维护独立技能预览；R60-04草稿保留，下一步继续04。完整记录见 `reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md`。

# 当前补充：技能退出修复的显示边界（2026-10-20）

R60-03技能空放退出修复只修改学习指纹与测试覆盖迁移，不改ANI时钟、渲染、动作/特效资源和攻击框。R60-04尚未验证的renderer/World草稿已隔离，不混入此次修复。用户已要求后续不再维护独立技能预览程序；历史播放器和证据仍保留。结果与待测步骤见 `reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md`。
# R60-03 运行时帧区间与装备投影（2026-10-20）

状态：**automated pass / user pending**。最终构建、报告身份及结果已绑定于 [R60-03-VERIFICATION.json](../../reverse-60us/integration/R60-03-VERIFICATION.json)。主工程完整核心／音频、同EXE来源审计及 SDL dummy 局部 smoke 通过；`cache/r60-03-tests-final-r4-checked` 的 [clock报告](../cache/r60-03-tests-final-r4-checked/reports/animation-clock-tests.json) 为1541项，含九个实验职业完整往返。独立播放器最终候选另有72项D3D读回与78帧隐藏UI检查通过，不能据此推成 SDL 像素或原游戏动态等价。操作步骤见 [节点进度](../../reverse-60us/integration/R60-03-PROGRESS.md)，用户画面、听音、手感及原版动态比较仍待执行。

新时钟动作把只读 frame/local/span/ended 快照交给 `Animation::samplePose`，插值使用实际 deadline 区间；图片、属性和框仍取当前源帧。正常 clock 普攻与实验攻击不再用 poseFrame 冻结插值；诊断明确指定 frameOverride 时继续冻结。clock 政策与 `legacy1031`／`inferred60us1031` 渲染政策独立，不会因切换绘制算法而再缩放模拟时间。

Renderer 先核对当前身体 motion 的规范化资源路径与 animationClockSource，匹配后才应用根快照。同 motion 装备使用根 elapsed/rate 和 `min(bodyFrameCount, childFrameCount)` 的 decoded DELAY 视图，保留子层自己的图片、框、额外帧及延时；攻击盒共用该投影接口。等待／移动等姿态有 source-rate100 根，身体与装备不会意外消费旧攻击帧；实验职业从攻击返回原待机 motion 时重新安装等待游标。

独立效果消费自己的快照；ALS 生成／移除由父 FrameVisit 消费，与位置跟随和暂停绑定分开。限时轨迹子层保持出生位置连续；animationOffset 跳转实例锁定具名 legacy 回退，避免 offset 归零后恢复已经跳 tick 的游标。ANI ended 保持末姿态，外层寿命负责清理。怪物、物件及技能专用阶段的时钟尚未统一为本次普攻模型。

这些1031行为中的速率映射、固定 tick 宿主调度和 ALS 绑定仍是明确推断，不能由60US局部证据推成1031原生事实。源坐标、原始 DELAY、资源字节和缓存动画未改写；SDL 像素、原游戏混合及完整技能表现仍有待比较的边界。

# 历史 R60-02 普通ANI渲染策略（2026-10-20）

`Renderer::setRenderProfile` / CLI `--ani-render-profile` 选择 `legacy1031` 或 `inferred60us1031`。后者采用60US已核对的完整结果截断、float32和负弧度/输出轴缩放，1031适用性仍是跨版本推断。身体、装备、效果走 `Animation::samplePose → Renderer::animation → drawImage → SDL_RenderGeometry`；generic sprite/TIL/PTL保持原度数接口与legacy矩阵。IMAGE POS与IMG crop合入变换，RGBA alpha只乘一次；inferred仅NONE/LINEARDODGE有局部依据，其他enum诊断回退。

独立播放器的同一便携内核另经D3D11实际读回检查通过，不能替代SDL像素或原游戏对照。当前战斗poseFrame冻结语义仍保留，下一R60-03负责真实区间/统一clock。参见 [节点进度与比较步骤](../../reverse-60us/integration/R60-02-PROGRESS.md)。

# 历史相机实现与用户验证状态（2026-10-19）

build30已通过相机自动检查，详细来源和几何边界见 [NODE-PROGRESS](../reports/beta-script-camera-20261019/NODE-PROGRESS.md)，可试玩备份见 [LATEST](../checkpoints/LATEST.md)。艾尔文防线作为参照；浅图保持原纵向构图，扩展/高图受可见源列首段连续范围约束，renderer和NPC选取共用同一有效视口。渲染源宽与碰撞Scene宽分开，窗口缩放不改变源MAP/可走区域。自动检查覆盖640x480至2560x720及实际来源城镇/地下城；source_floor_covered是几何覆盖检查，不证明源图内部像素全不透明。

本轮没有启动前台，用户仍需在真实窗口中检查画面、背景视差、黑边、NPC拾取与宽屏构图；艾尔文防线之外仍有空TIL布局缺尺寸的已知诊断。启动进度窗为后续节点，当前EXE尚无此功能。

# 当前整合：城镇与实验模板入口（2026-10-19）

build26完整核心/音频及同EXE无前台audit通过，EXE `84025a71f14e6efd1f2747695c73284f26518ac05532a86e11771fd51287dad4`，222输入/79报告；范围与备份查 [CURRENT_TASK](../CURRENT_TASK.md)。F10复用现有地图模态窗口查询/分页/键盘和鼠标路由，普通与测试展示全部源城镇区域，77/77源区域自动准备通过；源NPC可见不代表业务齐全。九实验职业近身HP检查通过，仍非全部技能/武器画面验收。

用户报告探索/其他城镇上下移动的地面背景随动异常及分辨率后底边黑框，下一节点修复，以**艾尔文防线**为对照。当前新图cameraY仍无条件playerY-360，缺少源画布范围约束；背景与地面Y投影需共同核查源视差。保留源坐标、可走区域和ANI/IMG逻辑尺寸，按地图纵向空间选择固定或整体滚动；本EXE尚未修复。前台画面/听音/手感和原版动态仍待用户。

F6/实验K增加“普攻模板”按钮：将当前源技能配到选中槽，明确展示这是临时基本动作；手动配置可替换。共享攻击读取包含真实装备武器层，不以身体动画有无type15判断整个动作是否可命中；身体pose-index同步武器仍是明确临时策略。F9逻辑画布800×720及同一缩放点击变换容纳Event.ai实际源难度选择，其他窗口默认800×600不变。声音、画面和手感未由自动检查验收。

# 历史节点：全地图与角色实验入口（2026-10-19）

build19完整核心/音频及同EXE无前台审计通过；EXE `1afb8642b7bfa3471d203d2ec9c195753f9118044d3905559a74bde542883955`，204输入/73报告。详见 [NODE-PROGRESS](../reports/beta-experiment-20261019/NODE-PROGRESS.md) 和 [LATEST](../checkpoints/LATEST.md)。

F7显示全MAP分页/搜索与诊断，F9测试总开关后可提前入图；名称查询提交后才全量读取。探索镜头Y跟随玩家，缺几何允许观察但阻行，已知六图投影不改变。十非Creator创建页标注实验状态，F6/实验K显示13槽同职业源技能/CHR动作/可选ATK配置；HUD消费实际配置图标/CD，F8导出配置与地图诊断。模态输入避免落到后方NPC/商店操作，文字输入随界面开启/关闭。

源动画存在、自动检查和实际画面分别记录。五个实验职业普攻本次有HP损耗，另四仅动作，专用技能/被动未完成。当前没有启动前台；地图图层、角色/装备外观、声音、手感和原版动态均待用户，具体见 [USER-TEST-STEPS](../reports/beta-experiment-20261019/USER-TEST-STEPS.md)。备份后继续完整P01–P19，完整beta约10%工程估计。

# 渲染修正与来源边界（2026-10-18）

## 2026-10-19 ACT 真实呈现接线

build13对应 [NODE-PROGRESS](../reports/beta-act-world-20261019/NODE-PROGRESS.md) / [LATEST](../checkpoints/LATEST.md)，EXE `144efcfe162b1b0c9cb86cd918a41c734f5f823760cb0f8918ce5ef1c30cf76b`。main在World固定tick推进ACT，renderer仅读演员实际source动画与speechBubbles。SPEECH按实体插值位置绘制文本，不交给Audio::play；当前1200ms是具名呈现推理。只有host实际消费的ACT才过滤旧unexecuted标记，其余ALS/图层缺口保留。

核心/音频及不同帧率ACT逻辑通过；未启动前台，画面、听音、手感与原版动态仍由用户验收。全MAP浏览/其他职业自配技能栏正在staging，不属于本EXE验收。实验呈现须显示未完成状态，十职业/全域最终标准仍保留。

## 2026-10-19 来源眩晕与帧率一致性节点

最新构建见 [NODE-PROGRESS](../reports/beta-status-20261019/NODE-PROGRESS.md)，备份见 [LATEST](../checkpoints/LATEST.md)，EXE `d6633262e4ebe43d3964cda2aec0ea71e749c7decdd3eecb9dfcc5cb8c6e2d53`。真实Tau第二攻击在当前ANI type15帧结算源30%/1000ms状态；接近停止点使用来源中后续帧的攻击盒，轨迹仍是明确推理。独立状态门槛、到期和恢复不依赖渲染FPS，30/60/144FPS及分批补tick的实际HP/状态/RNG/事件相同；这是逻辑检查，不是画面/手感或原版动态验收。

build10完整核心/音频通过，音频用SDL dummy，本轮未启动前台，没有新截图/听音证明。状态source/trace与存档恢复身份进入诊断，视觉异常指示和完整表现后续继续。ACT核心capture已测、World host与speech仍待接线；SPEECH必须是文本呈现，不能送Audio::play。Squirrel实际声音请求仍只在隔离typed-host探针，不冒称游戏播放已接。

用户步骤、来源/策略边界、standalone恢复限制和下节点计划在进度文档；源码/EXE/静态库/证据逐节点备份。当前只有基础鬼剑士可玩，完整十职业beta与UI/业务最终门槛仍未通过。

## 2026-10-19 正常学习UI与节点备份

最新已测节点见 [PROGRESS](../checkpoints/20261018T165352718179Z-source-projectiles-object-damage/PROGRESS.md)，EXE `ac7bfda2e31529593e0de22fb89afc07a4df82efdd05ff0aa5d3415ff891eac1`。K菜单显示正常/测试SP/TP、下一等级费用和拒绝原因，通过持久事务或独立测试覆盖学习；保存pending时暂停模拟/业务并显示重试按钮。测试与正常账本分开，source beta禁用演示HP倍率。投掷哥布林石块现使用源ANI/攻击盒、源PTL速度/寿命和源发射帧/偏移；destroy PTL表现仍未消费。人物/怪物属性与伤害trace进入反馈，尚未做原版数值、画面/听音/手感对照。

当前仅完成自动核心/音频/来源审计，未启动前台，Tau stun、ACT/Squirrel及完整职业/业务仍在实施。UI可用与视觉验收必须分开记录。每个节点备份当前source/runtime/evidence与PROGRESS，旧候选不覆盖；完整状态见[CURRENT_TASK](../CURRENT_TASK.md)。

## 基础设施候选2：时钟与独立测试窗

当前已验证归档为 `candidates/beta-foundation-2-20261018`，EXE SHA256 `5004fee99851d415a9ee6286230778df2f44b7731aad253a6e18ff54f8dfbaec`。本轮自动检查未启动前台，没有新增真实游戏截图、听音或原PC动态对照；下文旧截图只属于其各自历史EXE。完整状态见[CURRENT_TASK](../CURRENT_TASK.md)。

普通移动与基础普攻现消费CHR/EQU来源速度。基础攻击采用ScaledLocalAge：只按固定模拟tick累加缩放后的局部年龄，保留源ANI delay，渲染读取同一局部年龄；更换倍率保留已经消费的相位及命中/事件登记。不能再同时改有效帧时长。技能专用速度和所有附层时钟尚未完整接入，不声称全动作速度还原。

F9创建独立SDL管理窗口；关闭仅隐藏，窗口事件按ID路由，失焦清理输入。管理命令在模拟边界一次生效，支持独立HP/MP锁、无CD、AI暂停、等级覆盖及暂停单步。开启后使用独立beta-tests存档分支；反馈包含实际规则与来源trace。用户仍需检查真实双窗操作、布局、焦点、高DPI和手感。

renderer创建后显式调用SDL_RenderSetVSync，包括软件fallback；工具窗口要求关闭同步，失败会清理并报错。原因是SDL dummy软件renderer在创建flags未要求vsync时仍可初始报告PRESENTVSYNC。当前专项检查实际SDL_RendererInfo.flags无PRESENTVSYNC，没有以对象缓存布尔替代真实检查。双窗18项通过，仅表示dummy后端逻辑，不作为前台视觉验收。

装备来源HP/MP和怪物HP改变真实HUD数值，源贴图/ANI/IMG未修改。完整伤害仍有演示策略，当前源怪物HP与伤害不能用于原版平衡验收；必要业务UI、正常学习入口、全职业技能与精细层序仍待继续实现。

下一版设计见[渲染/UI/音频](../../dnf-native-build-plan/09-rendering-ui-and-audio.md)及[独立beta窗口](../../dnf-native-build-plan/11-beta-tools-and-rule-strategies.md)。新UI包与当前PVF身份不同，规则逐项核对采用；Qt预览不作为原生完成证明。技能装备优先，必要UI先闭环，精细层序暂缓。此轮仅文档，前台观察交用户，未生成新视觉验收。

## 人物装备资源绑定

人物默认外观由 `CharacterIdentity` 对应的 CHR/SD `defaultEquipment` 字段提供编号，再经 `equipment.lst` 解析为 EQU。EQU 的 `[animation job]` 决定有效职业区块；`[variation]`、`[layer variation]` 和原图层值直接从所选区块读取。渲染按 EQU 层值稳定排序，并以原 ANI 的图像模板、IMG 裁剪、局部偏移和帧号绘制。身体层值 1000 仍是本地重建约定，不可覆盖源装备层值。

武器、衣物及附层 ANI 从 EQU 引用的 LAY 中绑定；查找键是 CHR 标签、同标签重复字段的出现序号及原始槽号。已验证如暗夜使者 CHR 槽42 `[etc motion]` 由对应 LAY 指向 `ThrowKnife.ani`，不能由身体动作文件名猜成 `Shuriken.ani`。显式空字符串保持为空；多 `[layer]` 布局暂记为不支持并保留原字段，不把数组槽和绘制深度混为一谈。

测试已遍历基础职业 ID 0..9 的默认装备来源并验证职业范围；目前只有鬼剑士有完整运行控制器，其他职业的真实动作层序、逐动作叠层时钟及原版动态画面仍待实现和人工核验。本轮不复现用户暂缓的选图 UI 图层。

## 全工作线候选的真实帧复核（2026-10-18）

候选 `268f179d718038d1b3644a2f40d1d6813812039976473606fc100c72ba9fc0c6` 的六场景置顶冒烟实图位于`../reports/runs/20261018T105540-713898d5/captures/`，六张均已打开，确认画面非空；这只验证场景加载和截图，不是原版视觉通过。窗口内仍有测试版HP/MP恢复提示，UI、深度层序、人物与障碍的原版一致性没有验收。

选图最终候选截图位于`../reports/runs/dungeon-selection-full-worklines-20261018-keyboard/`。800×600的`level-one-selected.png`和1280×720的`wide-keyboard-selection-open.png`均显示卡片明显重叠。布局仍是资源与参考图支持的推理；绘制与点选复用同一几何、键盘资格和取消流程通过，但鼠标、高DPI及原版坐标／锚点仍未验证。此项视觉验收失败，不能用键盘状态通过覆盖。

## 零级资格候选与本轮真实帧（1c55ec60历史）

## 零级资格候选与本轮真实帧

当前候选1c55（完整hash见CURRENT_TASK），零级释放和存档修复不修改ANI／IMG或层序。`input-20261018T092840/zero-02-skill-levels.png`实际显示13项Lv0；`zero-04-ordinary-attack.png`中身体与武器普攻可见；正常输入`092909/gorecross-right-blood-cross.png`中红十字可见。以上三帧已人工查看，只确认这些有限内容。技能菜单仍为demo布局，零级HUD图标可用态、NPC／地图／图层整体和原PC动态一致性仍待独立恢复／验收，不能由核心测试通过判画面无误。

两次消息输入窗口均置顶可见，零级fixture实际退出重载和普通角色11点操作通过；并非物理键盘／IME测试。本轮未重跑死亡fixture或副本48点，旧2567的实际帧仍只属于旧hash。归档构建／GUI身份见`build-checkpoints/eligibility-1c55ec60-final/`。新static_motion仅为未接实体的运动算术，skill-parameters／modifier调查不改变当前十字PO位置；不能把未修饰56样本宣称为原生特效距离。

## 最新运动候选与实际帧复核

候选身份 `2567d4d5288e040b26c64e0f52e41b9ff070a15fdfd8a0d292b58805f26a70b0`；具体构建和流程看CURRENT_TASK首节。`AxisMotion` 接入只改变人物跳跃／怪物浮空的每tick位移，仍使用原ANI／IMG锚点、crop和朝向；430／980、60Hz、落地处理与double高度累加未恢复为完整原生合同。不能把积分测试当作原版跳跃动画／画面验收。十字frame6命中集合重置属于逻辑层；4附层自己的时钟与event1、普通身体frame10退出保留。

已实际查看当前候选 `effects-20261018T085500-95f484/captures/effects-shared-left-weak-{6,7,9}.png`（请求1120／1200／1270ms）：地面右侧原碎石由清晰变淡，再在700ms碎片年龄截止后不可见。原强击旧样本 `effects-20261018T084431-bb7876` 的后段碎片已飞出屏，不能凭该空画面称淡出视觉通过。当前fixture74项包含四方向弱／强的显示期限和淡出状态；仍是人工accepted-hit诊断，未证明正常判定、原生碎片速度或全场景图层一致。

已查看当前 `input-20261018T085401/02f-dash-attack.png`：冲刺攻击身体与武器可见；`gorecross-right-blood-cross.png` 显示红色斩击，未据此判定阶段组合完整。最新设置重载页 `input-20261018T085436/settings-03-reloaded.png` 已实际查看返回按钮与提示。本候选普通洛兰＋深处48点通过，实际查看 `input-20261018T085839/07d-delilah-repair.png` 的商店／修理内容与 `deep-06-room-2.png` 的怪物、场景和门；后者人物在右侧门位置附近不可清楚辨认，不能凭此帧判遮挡正确。上述真实帧不构成原版图层／UI像素一致性验收。UI整体差异、未恢复D3D混合与全职业图层仍待验证。

共享PTL直线／keep-last已实现纯算术采样，但未接入十字实体；最终速度修饰和投影消费者尚未闭合，不把约56未修饰积分当渲染坐标。普通洛兰／深处最新验证及其实际截图身份以CURRENT_TASK首节与候选审计为准，不跨hash借用历史通过。

## 最新候选：十字附层事件、跑动与碎片可见期

本轮候选仅在 `cache/build-next/`，正式7a85发布未覆盖，候选hash和当前验证看CURRENT_TASK首节。身体／武器／附层保留原始ANI时长。跑动与跳跃的显式攻击帧覆盖已清除，修复攻击状态遗留导致移动只画固定一帧；当前输入回归不能代表所有武器／职业图层已验收。

十字斩创建当前SQR注册的4条Slash附层，index1的prop23事件由其自身动画时钟产生，不复制身体帧号。事件生产链 `109FB3A→109FD9B→583840→108F370→109C5EA` 和消费者见 `animation-events/README.md`。原生离开state35清除skill64 index0..3，血十字PO独立继续；当前普通身体frame10退出，撤掉550ms硬截占位。完整世界调度、攻速、D3D混合和ATK选择保护仍未全部闭合。

共享死亡碎片以真实年龄积分，只把可见期限制为min(源PTL寿命,700ms)，末150ms淡出。原3000ms字段、初速度、重力和随机初值保持来源层不变。该期限是用户要求的demo显示调整，白剪影／burst阶段及碎片强度仍有重建，不能说原生700ms。

已实际查看新设置 `input-20261018T081759/settings-03-reloaded.png`：底部Enter提示不再遮住返回按钮；本页仍为测试设置布局。普通R十字双向 `input-20261018T082229/gorecross-*.png` 连同只读runtime采样保存，阶段可见不等于原版逐帧一致，尚需继续审图。旧失败082049是测试分类错误，未据此更改渲染。全部UI像素一致性仍未通过。

## 原生动画合同与来源绑定（7a85历史发布）

当前实现／构建身份优先看CURRENT_TASK最新追加，下方旧24ad等hash属于历史验证。CharacterCatalog现在保留全部11角色真实CHR动作槽、原字节及PVF来源；当前可玩鬼剑士从实际CHR解析动作，不能把AT／DS角色按job拼造目录。AT动作实际可位于父职业的atanimation，DarkKnight位于Swordman的dsanimation；缔造者暂缓运行时但空动作槽与全部资源继续保留。

原生证据 `reports/combat-native-reverse/resource-render/contract.json` 确认：ANI的ratePercent以100为正常速度；`5BA3A0` 对每帧使用trunc(rawDelay*100/ratePercent)。`109CA90` 近零回退1表示1%速率，不能称一倍；CHR的1000是另一单位。中途变速保留相位并传到child。当前World仍为100%源帧时钟，没有借此宣称已恢复武器攻速／全局倍率。以前entry-audit中的“g=1正常”已更正。

原生ANI实例与不可变源独立；child按自己的累计delay映射父帧起始时间，不复制父frame index；跨帧按中间帧顺序派发ALS事件，同帧不重复；附层按signed layer稳定升序。当前有界EffectPlan仅编译add/remove，先收齐完整use-animation表，其他命令保存tag、values、offset和诊断。none-effect首字段=1的视觉消费者、draw-only／random实例的完整执行、延迟add在随后的reset中出生时钟是否清零仍未知，不能猜成已实现。SDL ADD仍不等同原D3D DODGE／LINEARDODGE公式。

鬼剑士默认普攻的源帧5／4续刀已接入模拟，队列输入能提前进入下一刀并重置pose0。源ANI的600／650／550ms及完整帧保留；没有输入不会缩短动作。暂停和未来攻速影响到达帧的墙钟时间，250／200ms不能固化为所有角色或速度的阈值。当前只有鬼剑士控制器可玩，本轮专项通过不代表其他角色、装备遮挡、UI或原版动态视觉一致性通过；新包截图及输入验证见CURRENT_TASK当前记录。

当前build/playable SHA256为 `7a85bd452feb77b2000cec489ed0c35574c4da1d74d00b82f0e80678767fac30`。发布EXE普通窗口消息 `input-20261018T070550` 25点通过、置顶可见及实际重载／用户存档保护已核对。实际查看本轮02b-attack2／02c-attack3／06-room-5／07d-delilah-repair，攻击姿态／武器／剑光和地区流程可见；修理面板仍为重建布局，静态截图不证明完整时序或原版层序。发布交叉记录见 `reports/combat-native-reverse/release-verification.json`，未重复深处或13技能smoke，不拿下方旧图冒充本轮。

`attack-speed/README.md`补充global1A6FBB0的静态初始化传100证据，以及对象virtual+708→833420写n后以n*100*.001更新ANI。静态默认不等于g实时值，CHR／装备到n仍未恢复，所以当前未调整实际攻速。原资源延迟、百分数速率、1000基准对象倍率继续分开。

## 上一轮24ad：命中暂停、短阶段采样与混合诊断

当前build/playable EXE SHA256为 `24ad6fa1cb7a0d26c45b867d578e3be92315329e33ed71622d548520b5636e09`，`build.cmd --test`已通过核心30、外观23、技能9、怪物110、区域17及命中反馈122项，日志 `reports/combat-feel/build-test-held-turn.log`。最终串行前台进程验证全部通过，详情 `reports/combat-feel/held-turn/release-validation.json`；发布/source/window审计84项通过，见 `reports/combat-rework/verification.json`。普通洛兰＋深处41点及实际重载通过，当前轮用户存档未变；13技能双向182图＋78补帧、怪物fixture58项、六场景三分辨率完成。普通input/deep审计使用同一成功run；fixture与消息输入不代表原PC平衡或物理键盘/IME验收。中间532构建的深处结算步骤超时保留为失败，用户同时游玩导致的存档变化未回滚，原报告与旧F30证据均保留。

命中局部暂停冻结身体/武器采样、角色物理和attached特效年龄；独立特效继续。普通本刀锁向，续刀边界从pose0开始，避免上一刀末帧串入新刀一个tick。三段斩暂停期间人物及附着层均不翻面，解冻第一tick再读取held方向并同步锚点/dir。122项行为回归验证局部时钟与方向合同，不能证明原PC视觉或手感一致。源ANI毫秒和原图不改。

技能smoke在原七点/182图外补0.80/0.90/1.35s诊断图和`skill-detail-samples.json`，用于检查裂波黑芯、崩山黄刀等短窗口。effect1和effect2当前均用SDL ADD，二者都明确记录approximation/PC_equivalence=false，不将“已画出”写成原生混合恢复。源与原AVI复核见`reports/skill-chain-rework/blend-audit-controller-findings.md`：卡赞255/30/10/255是RGBA红色调制，30/10不是alpha；基础裂波lighting9有后段红粉双叶，绿色背景上的ADD可使其偏橙白。棋盘/平色合成图是研究图，不是游戏截图，未据此目测染色或换用DS角色资源。

当前原生静态入口审计见 `reports/combat-native-reverse/entry-audit.md`：六份1031 ASM与另六段碰撞范围可匹配当前EXE，新增动画切换与倍率/附属ANI传播路径已保留原字节、偏移和hash；候选虚表的鬼剑士归属、全局倍率和普攻取消/受击控制链尚未恢复，不直接把其他版本数值移入运行时。裂波亮叠层及原黑芯仍未判原版一致。

## 当前战斗特效与怪物绘制

本轮依据当前1031资源、用户新增逆向资料及原 AVI 补齐组成，完整原 PC 动态金标和整套UI仍未通过。`reports/skill-chain-rework` 的原 AVI 排列、资源导出图和 `reports/monster-rework` 的资源计划均是研究证据，不能当作当前 demo 实际截图。下文装备／字体构建 hash 和窗口记录明确属于此前发布。

上一轮build／playable EXE SHA256为 `a3da200d96615ecffd2e3ae8b65e530a870ec768148ccbb322a94eea6657bf31`，核心30标签／技能9项／怪物110条／区域17项／外观23项通过；以下窗口记录属于该历史身份。

修正前b04构建 `b04a33bfc1d8aaca6d9a31b0a9872574ebde95d1cd60002782814436ca74a51a` 的可见特效采样 `reports/runs/effects-20261018T002018-329d30` 实际完成15个样本、56／56项检查，窗口置顶、exit0、用户存档未变。样本通过 `diagnosticHit` 注入被接受的命中，不包含普通碰撞／操作验收；错误计数为空和自动检查通过都不能替代原PC画面对照。该构建普通消息流程 `input-20261018T002135` 已绕桶并清4房，但在首领房角色死亡，保留为失败。其13技能双向104秒smoke `20261018T002514-367ed4b4` 的182张真SDL图已独立查看13排版、9张全尺寸与7原AVI，报告 `visual-review.json` 明确留下十字近身残影、裂波混合和短阶段采样局限，不是视觉通过结论。新版普通流程 `input-20261018T003634` 和新版smoke等待主任务结果，不以旧图替代。

技能视觉使用 `effect_plan.hpp/cpp`：OBJ 的基础及显式附加 ANI、命名 ALS add/remove 实例保留各自源字段 offset、帧累计毫秒和层号。多个同路径 ALS 实例不能按路径去重。子层与父层共用实体坐标和移动，分别保留 ANI 位移、IMG crop、RGBA、图形混合与方向；纯视觉子层禁用伤害。未支持的负帧／实例规则保留诊断，不用目录相邻资源假装原调用闭包。

地裂主波使用源 OBJ 绑定的 `normalwavefire.ani`，单次325ms，补人物刀光；十字斩使用源普通／加色两层和 PTL 的移动／停止参数，浮空锚点按 `worldY-z` 投影，不能把z=82解释成 ANI y=-82。当前 `(85,0,82)` 是跨版本创建观察与本地相同 ANI 支持的重建，尚非1031原生调用值。基础职业不无条件补狂战士追击的GoreCross3/4。银落达到控制器高度条件才生成地波／尘／闪；源flash的scale0.5→2、alpha255→0继续按 ANI 插值。裂波保留人物上挑／下斩刀光与尘、普通闪光与主体，不能把新增每层都计作一次伤害。卡赞的appear／stay／ghost／disappear按各自寿命调度，源图案显现与额外平滑alpha的来源边界不混淆。

十字近身大图来自人物slash2，移动小图来自OBJ共享轨迹，不能把它们当成OBJ两层原点错位。当前把人物slash1／2附着层限定550ms：保留slash2 500..550ms的事件短帧，去掉随后950ms同图占位造成的长残影；slash1同样截止，源1500ms ANI字节不改。350ms移动双层创建不变。550ms为明确重建，源23=1是否对应原生销毁仍未证实。旧b04实图只证明问题，新构建需自己的截图验证改善。

崩山身体多段／剑光和独立冲击波分开。1031 SKL 说明冲击波需要被动“血气旺盛”63，正常未转职角色默认关闭；显式fixture才验证完整前后四层波。波触发采用第二身体阶段 frame4=600ms、前后层相对关系采用经过本地动画兼容核对的新资料观察，属于控制器重建；不把全部目录候选无条件画在基础角色上。

怪物的 `MonsterMotion` 组合直接 ANI 或 ACT MOTION 的 BASE ANI、SUB ANI／WITH XY 和 ALS 实例，使用各层自己的时间、锚点和稳定 layer 顺序。ACT TRIGGER／BEHAVIOR、脚本生成对象和分级分支未执行时保留诊断。有效 `[last action]` 从0ms播放独立死亡计划；没有独立入口时才走源共享死亡配置。存在却无效的独立入口不会被无提示替换成哥布林共享效果。

共享死亡冻结致死动作的完整可见组合和局部时间，由实际透明轮廓生成白色 alpha 剪影，随后绘制 MOB palette 对应的原石块 IMG、PTL 轨迹、flash／smoke ANI。旧的5×2矩形切尸效果已经删除。地面XY方向来自目标减攻击来源，z仍单独控制上抛和落地；碎片位置按绝对模拟时间和固定种子采样，不每帧重新随机。源资源／省略位／寿命与重建的白化时钟、速度倍率分开保存。60ms白化、220ms迸发、90ms身体渐隐来自参考演示器，烟alpha0.35、速度公式和阻尼也不是已证明的原EXE参数。石块目前随父怪物在同次深度队列提交，逐片地面y遮挡仍未完成。

普通命中和技能的受击动画区分 damage1／damage2，实际hit ANI不再由自制圈叉代替。攻击来源和速度由被接受命中的 `ImpactContext` 传入；ATK推力、浮空追加升空与受击闪白在模拟中推进。资源计划正确、核心断言通过不代表所有 blend／遮挡／特效数量已经像素一致。

浮空落地切到MOB自己的down末姿态，控制器将该末帧停留限为150..500ms，再播放源sit过渡100..400ms，恢复stay时清除旧显式path；哥布林现为500／150ms。down中10000ms飞行占位不作为整个落地动画播放，避免倒地仍画damage2或长时间卧地。overturn是独立翻转动作，不用作通用起身。姿态与源绑定保留，具体恢复调度及上下界属于重建，原ANI不改。

## 2026-10-18 装备／装扮与窄版界面（上一轮发布记录）

该次历史构建`ba6f13d48c996f669c4bf2183af1d1528078a29ea6abba079ceed39827feec40`。`Renderer::player(CharacterAppearance)`用真实EQU的两个variation替换当前ANI帧模板，不再把实际装备一律画0000。选角、场景和物品栏共用外观。衣物/武器按源数字layer排序，同slot替换完整分层；普通属性护甲无外观字段时不会抹除时装。EQU武器650/2790为源数字，身体1000仍为重建约定，复杂遮挡未全部确认。该次UI修复没有改战斗控制器或公式，本轮战斗变化见首节。

`equipment_ui.cpp`使用inventory.img背景0/11、装备槽21、法阵18、活动54/55与inventory_tw三行货币框。标题按common9/10/11黑金底→109/114/115透明蓝边→48金圆→accessory0叠加，横向延展保持sy=1；缺底层会透出蓝斜纹。最终空格用common57黑中心/细金边，候选inventory49是偏蓝软边。透明区域加近黑底板{2,14,22,245}，属于截图重建值，未改原IMG或宣称解出原EXE窗口alpha。

参考1000×750按0.8测量；主体约(464,86,258,452)，背包8×4、时装7×4，原48物品容量不变。七项只读试穿只改局部外观，真实穿脱使用Progression的UID；关闭面板清除试穿。tooltip已显示支持字段和同部位对比，但完整词条/精确tab宽/锚点/拖动/负重比例仍缺，负重只绘制源空底条；宠物/徽章禁用。

实际发布截图`reports/runs/input-20261017T172346`和`appearance-20261017T172450`已查看；`reports/equipment-ui/equipment-actual-comparison.png`/`avatar-actual-comparison.png`是参考与真实SDL裁切编排，导出帧/contact sheet/标题叠层研究图另行标注。两流程用户存档未变、置顶可见，Windows焦点拒绝，消息输入通过不等于物理输入或像素一致。来源与限制见`reports/equipment-ui/LAYOUT.md`/`verification.json`及`reports/appearance-source`。

当前构建将原 MAP 被动物件纳入独立 `ObjectSystem`：registry ID/path、原OBJ字段和字节、ANI槽位顺序、`[layer]`、`[width]`/`[pass type]`、MAP记录偏移及特殊payload均保留。Scene只生成绘制视图；对象动作由固定模拟tick推进，避免渲染帧率影响动画。`[do not pass]` 源尺寸只构成移动阻挡，不充当ANI受击框；受击框独立取当前ANI type-15 XYZ。树／石柱／草方向反应和木桶／箱子耐久仍含标注推理或本地测试策略。PTL渐变、声音、原生受击接受与生成物件的消费者未完成，不据此宣称对象动画链已恢复。

用户指出的页面、UI、地图和图层错位确实存在。旧运行错误计数与旧视觉观察不能作为视觉通过证据。本轮采用原PC参考图、原MAP/ANI/IMG和真实SDL截图逐项定位；整体验收仍未通过。

2026-10-17 可玩交付只补齐战斗读取武器 c 层的攻击框，未改变已绘制的 b/c 层或本记录中的投影。普通三连原第二刀有画面但不命中的缺陷已复现/修复；四武器双向命中回归通过。新窗口流程截图位于 reports/runs/input-20261017T124314，实际查看 02b-attack2.png；这是动作可见的证据，不是全 UI、地图图层或原 PC 动态时序通过的结论。

## 本地参考实际量出的坐标

PC截图为1000×750，核对时归一到800×600。`reports/visual-correction/research/measurements.json`保存原图SHA256、NPK字节范围、IMG元数据和局部匹配结果；研究图不是运行截图。

| 内容 | 实测绘制原点或位置 | 依据 |
| --- | --- | --- |
| 赛利亚房间近景GateBack | 图像左上(−45,0)，实体原点y200 | MAP原y0、ANI y−200；4局部NCC 0.949–0.988 |
| 城镇铁匠铺BlackSmith00 | 裁剪图左上(218,225)，实体原点y200 | MAP(382,187)、ANI(−164,−162) |
| 森林远／中景 | 图像top0，原尺寸重复 | 中景5局部、远景透明空隙扫描 |
| 森林地砖01tile03 | 裁剪图top325，逻辑原点80 | crop y245；城镇和地下城草地独立匹配 |
| HUD | 逻辑原点(0,508)，宽800 | interface2/hud/hud.img frame0，crop y1 |
| 红／蓝球 | (13,524)／(732,524) | 源56×56帧匹配 |
| 原12快捷槽 | x538+30n，下排y558／上排y519 | 每排6槽；原参考不是7槽上排 |
| 选角面板／标题／开始 | (17,68,766,451)／(344,33)／(337,526) | 原windowcommon九片及selectcharacter帧 |

这些是当前地图和参考尺寸的测量，不是全部DNF版本的通用常数。官方`mapsample.map:35`只解释background pos是扩展后从旧背景位置向上调整，未给完整投影公式。

## 运行时投影与动画

战斗坐标保留MAP+bg规范。800×600基准中实体绘制增加120，TIL保持原bg，远中景保持屏幕原点。当前六图使用固定垂直投影 cameraY=−120；已撤掉此前未经证实的低处跟随规则，它在原出生点 y410.5 会把地砖底边提到 y509.5，露出直到HUD主栏的黑带。源MAP数值、ANI位移和IMG crop均未修改。

森林四份 `map/01tile00..03.img` 的bitmap逻辑画布224×480，与TIL 14×30碰撞网格的世界尺寸不同。当前按横16、纵12单位处理：ForestOver可走row12..28对应源y144..348，符合三图上下门144/145、348/350和全部原怪物出生点；旧纵16将s0原y180和b1原y173误判出界。实体原点200后最低可走脚点约548，与源地砖底边560和HUD主栏558相容。这是受当前森林实例支持的重建规则，官方样例没有给出通用步长；未推广到其他TIL。Scene.tileGrids和audit保留图像逻辑尺寸、网格数、实际采用的步长和推导边界。

`geometry.hpp::imageQuad`将ANI局部位移和IMG crop相加后，围绕实体锚点应用带符号缩放、旋转与朝向镜像；SDL后端接收四角顶点，避免负宽矩形。赛利亚原ANI scale=(−1,1)的实际数据有锚点回归。全局图形属性和逐帧覆盖分别保留。旋转／复杂图形效果的完整PC语义仍需核对；两个官方ANI样例是空文件，不能据其声称已证实所有二进制规则。

MapLayer保留原layer/order、地面depthY、z投影、背景repeat逻辑宽高、loopY和screenPosition。当前六图主要是distantback/middleback背景，使用实际逻辑宽度代替硬编码640；未验证的背景层组合写入issues。普通场景物件、NPC、角色、门和特效进入深度队列，卡赞地面效果在实体下方。完整六层组合、sort bottom、OBJ layer level与半透明遮挡尚未完整实现。

NPC通过原npc.lst查ID，不再只硬编码赛利亚／林纳斯／土罐。只去重完全相同的重复放置；保留同ID不同坐标实例。当前 `Scene::updateNpcs` 在地下城通关且处于首领房时生成德利拉，绘制阶段不再修改坐标。源`visible on dungeon clear=1`和(0,0,0)保留，实际落点是首领附近再投影至无障碍地面的重建策略；可以交谈、购物、修理，精确原EXE落点和出现动画未证实。场景使用源[field name]而对话保留完整[name]；仓库的field name为动态标牌ANI，当前按role显示“金库”，不把ANI路径当作文字。

赛丽亚房间／艾尔文防线／洛兰入口的切换按源 `[town movable area]` 矩形和目标，宽屏鼠标点击NPC先从居中UI坐标换算到场景视口。未开放道路不伪接其他地图。地图实际读取35份来源，普通源DGN可用33张候选（洛兰14＋深处19）；7.map的三向门与两列DGN不兼容，5.map为旧救援场景且当前选择字段无入口，证据见 `reports/elvengard-rework/topology-audit.json`。这些源拓扑和门附近可走检查不替代逐图视觉／遮挡验收。

Renderer::tileSprite将拼接地砖的四角量化到共享设备像素边界，以修正1280×720等非整数缩放和横向镜头下的一像素漏缝。此操作只影响后端拼接，源纹理、裁剪和逻辑坐标保持不变；800×600基准仍按原像素绘制。121710的camera0截图未复现旧漏缝，不能单独作为消缝证据，后续回归主动使用中部镜头覆盖原失败位置。

## HUD和页面适配

### 字体和掉落文字（2026-10-17）

客户端 `Fonts/msjh.ttf` 被识别为 FangSong/仿宋，具有中文 Unicode cmap；`Gasinamu.ttf` 仅有旧 Wansung cmap，没有 Unicode 映射，不作为当前中文回退。字体来源、hash、cmap 和四张参考图 hash 保存在 `reports/font-reference/source-audit.json`。不能仅凭文件存在就断言原 EXE 必然选此字体。

stb_truetype 不执行 TrueType hint，实际放大截图暴露出小字虚细问题。Windows 的 `HintedFont` 因此使用客户端 TTF 的内存副本注册进程私有别名 DNFSrcUI，防止选择同名系统 FangSong；运行时逐字节核对 glyf/loca/cmap/hmtx/hhea/fpgm/prep/cvt，再用 GDI ANTIALIASED_QUALITY 栅格化。原文件只读，内存副本只改等长 name 记录，不改轮廓/度量/hint 表，退出清理注册。非 Windows 或校验失败保留 stb 无 hint 回退。`runtime.json/font` 记录真实 backend。

参考截图的文字边缘表现为明亮字芯、紧贴的一像素黑色边缘和很弱的第二像素羽化。当前按像素距离使用 0.96/0.68/0.18 的黑边权重，字芯 coverage gamma 0.75，再以字覆盖黑边的 straight-alpha 合成到缓存纹理，由 SDL 调制金/白/红色。它是可追溯的视觉近似，未解出原 EXE 私有参数。不能再把 coverage 同时乘进 RGB 和 alpha 导致字芯二次变暗。掉落牌宽、段落换行和 NPC 居中采用实际 rasterizer 字宽，不用 UTF-8 字节或统一字宽估计。NPC 采用 12px 暖金色。

掉落场景图片按实体深度绘制，名称牌和靠近时的 `P` 标记在场景后作为 overlay，因此角色站在物品上时牌仍可见；拾取键仍为 X。靠近时物品增加窄黄色轮廓，牌边变亮。多物品仍捆绑一张牌/原子拾取，金币地面动画、牌形、物品锚点和完整掉落动态需继续核对，不能称已一致。

该次历史发布 EXE `040a5d0d34f798c46c379b1c95f599ad53eeab15ee734bc59fb108c7bcdf83e5`。发布包 UI 七点截图 `reports/runs/input-20261017T161457` 和六场景三分辨率 `reports/runs/20261017T161531-7a7c0490` 已实际查看代表图；字体裁切对照和来源见 `reports/font-reference/visual-review.json`。整体 UI 仍不匹配，当前不能称像素级复刻。

使用800宽的interface2 HUD替代旧640宽HUD。原12槽、球、按钮和选角九片均按参考锚点绘制；第13个Space格挡槽(488,519)是明确的demo扩展。商城等未实现功能禁用。宽屏世界保持扩展，HUD居中；HUD外侧底部使用原frame84纹理填充，属于显示适配，不能称作原MAP扩展地砖。

创建页恢复原尺寸人物插画、logo、职业头像、能力图与名称区域。下排窄控件已从(518,560)修至测量位置(519,559)。菜单、技能配置、地图窗口、部分文字仍为测试UI；箱子外观状态、NPC名字位置／颜色、原上排窄开关、原版任务／地图面板与完整UI交互尚未复刻。

## 实际验证的解释

核心测试验证几何、源NPC条件、背景元数据和现有战斗／存档回归。普通窗口消息输入流程验证路由、战斗、保存和重载；技能smoke直接激活技能，场景smoke直接换场，均不是原PC实战金标。

`--flow-scene-seconds 5`可将六场景截图回归缩短为30秒，默认仍为每场30秒。自动测试窗口置顶可见。最终报告分别记录运行结果、实际截图观察和剩余视觉差异，不能写“无错误”或整体验收通过。

技能测试曾用 `dir * (offset + size_tIndex * 35)` 放靶，负方向被提升为无符号数，导致左向靶坐标溢出；115542批次左向裂波没有捕获，左三段起点也不足以容纳完整位移，失败证据保留。现转为有符号浮点距离、左右起点分别位于地图1/4和3/4、每轮重置控制器和完整目标状态，并强制检查所有起点在源可走格内。skill-samples.json保存26轮起点与182个采样状态，供坐标/阶段/命中审计，不能替代实际图像检查。
> 2026-10-18 续做抽样复核：a3da怪物落地5/6为横躺源姿势、7站立；共享白剪影、左右反向飞散及强弱位移差可见，chief独立蓝光死亡可见。十字左右0.65秒仅余前方小十字，1.10秒无近身大十字残影。检查银落、地裂、卡赞、裂波联系图及裂波/左地裂/崩山关键原帧。蹲姿恢复、垂直碎片、裂波/崩山短窗口和原版逐帧一致性仍未验收。整体视觉仍未通过；本轮受OS112和审批403阻塞，未补采样，详情见`../reports/combat-rework/continuation-20261018-environment-block.json`。

> 最新续做结果（优先于上方过程阻塞记录）：已直接查看当前13套技能联系图、8张技能原图、9张怪物图和7套原AVI联系图；十字附着残影修复有图支持。深处通关/德利拉/重载新图见`input-20261018T011529`，窗口置顶。技能短窗、渐变和原版混合仍不通过完整验收；卡赞草地背景加色、裂波橙红→粉紫的阶段差异需先查证，不能凭目测直接染色。1/2模式均ADD只是当前近似，诊断空值不是原生混合证据。C盘零空间仍影响补采样/最终审计。


# 当前实施：技能武器/效果层和XYZ（2026-10-20）

本轮状态见`reports/attack-timing-offset-20261020/NODE-PROGRESS.md`。人物动作、技能武器附层和独立效果不能仅凭扩展名混作同一sprite。人物与同动作层共享有效controller delays和根frame/local/span；不匹配的独立层沿用源DELAY/loop。SKL preload只提供资源依赖，不自动触发播放。附层的ANI偏移与IMG逻辑画布crop完整消费，不能统一脚底对齐。

效果的前态X/Y/Z统一插值，再按世界groundY−Z投影；新生未采样的Z以前态缺省当前Z，不从0插入。源layer作为相同地面深度的次序，不再误作10000×0.01像素地面位移。普通ALS draw-only以ownerX±offsetX、ownerY+offsetY、ownerZ+offsetZ创建独立效果；z<=−1000的特殊层语义继续具体诊断，不当普通负高度。单clip自动寿命是具名推断。角色/装备ALS不可见宿主只发事件，不重复画身体，也不因含攻击框就给视觉层额外伤害。

# 2026-10-20 技能资源链补齐

喷火OBJ动画存在仅攻击框、无图片的实际1031源；火焰start/loop/end必须独立可见消费者，不能把无图当成功渲染。激光LaserFire源type15是伤害来源，Tile/End为视觉；各自保留ANI offset/crop及源框。枪口由对应技能开火武器层图像端点推导并携来源证据，仍需用户/原版动态比较；不全局修改Z。M3结束保留无伤害尾效与有限身体恢复，不能让已退休channel残留碰撞。源帧与控制时序分开，ALS帧事件不是毫秒。

