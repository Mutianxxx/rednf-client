> 2026-11-02：已整理[C++架构拆分大纲](ARCHITECTURE-REFACTOR-OUTLINE.md)，按面向对象职责、通用执行链与性能门槛规划后续重构。本轮仅文档核查，运行代码未拆分；下方保留既有实现/验证状态。

<!-- equipment458-live-status -->
# 当前装备资格与正常学习预算节点

阶段：`paused_after_original_o3_debugger1`；会话：`None`。预计459份编译输入、181份完整报告，独立构建`cache/seven-job-equipment458-build`。最新已验证体验仍按实际完成记录：`checkpoints/20261020T224815926748Z-mage-upper457`；统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

**已按用户要求暂停。** 当前一轮已结束；不再启动构建、测试、备份发布或后续节点。恢复先读本节点PAUSE-SUMMARY-20261021.md和PAUSE-RECEIPT.json，等待用户继续。

女法师天击457已完成1142成员源码/产物/证据备份，两遍哈希零差异。当前仅继续装备单ID技能资格、正常SP/TP预算及目标私有恢复/GSD预检；分支赠送与真实30200条件眩晕不混入完成。女格斗普通副本死亡失败保留，七职业全普通副本/完整技能和最终十职业beta尚未完成。原资料、正常存档和历史候选保护，构建/运行/备份串行；前台画面、听音、手感与原版动态比较待用户。

恢复读`dnf-native-demo/reports/seven-job-world-20261020/equipment458-integration/RUNNING-STATE.json`、本节点PROGRESS与实际日志。先poll实际会话，不重跑已结束attempt，不删除他人锁或覆盖运行产物。下方旧记录为历史。
<!-- /equipment458-live-status -->

<!-- mage457-live-status -->
# 当前女法师天击节点（以实际收据为准）

阶段：`mage457_complete`；会话：`None`。候选输入预期457份、完整报告180份，构建目录`cache/seven-job-mage-upper457-build`。最新已验证体验：`checkpoints/20261020T224815926748Z-mage-upper457`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

女格斗原ordinary1死亡及观察复现完整保留；该失败不算正常游玩通过。Mage是独立功能验证，七职业全部普通副本、完整技能及最终十职业beta仍未完成。所有新构建、测试、审计和备份串行，原资料、用户存档及历史候选保护；前台画面、听音、手感与原版动态比较由用户执行。

恢复先读`dnf-native-demo/reports/seven-job-world-20261020/mage-upper457-integration/RUNNING-STATE.json`与节点PROGRESS、实际日志；不重启已结束attempt，不删除他人锁。下方保留历史记录。
<!-- /mage457-live-status -->

# 当前节点：女格斗上勾拳自动通过并备份，继续职业/普通副本

fighter-upper454完整核心/音频/隐藏UI、同主EXE来源/content/dummy及源码产物证据备份通过，EXE `8c37d12288b0f6dbbe6a0731140b2dbd4581e587eed9bcf9f6b7df1280665249`，454输入/179报告，ACT62、九声音18PCM。自身初始5/正常SP20/MP-CD/默认Z/双音/真实EQU与怪物反应及恢复已接；TP163、拳套required34与原生caller仍有具体缺口。Priest e6b57/ready5完整三段fixture链及实际失败与应用证据、movement fixture3及实例clock/frameStartMs和前序Water/Knee/AI/奖励保留。Fighter a182→8b1a计时采样及真实30200错误成功前提两次窄修、原preflight1/2失败/独立诊断和父应用收据完整保留，原740..774未改。四类World释放通过；拳套仅严格原子拒绝与独立源几何，不称五类实跑。本轮还保full1真实失败、精确SkillKey休眠preview测试修正和独审/父应用；normal/runtime1与dormant10不变，完整normal bridge新增第五专项。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-node/PROGRESS.md，备份 `20261020T211925962396Z-fighter-upper454`。七职业全副本/最终十职业未完成，原资料/存档/历史候选保护，继续。

# 当前恢复点：454预览索引断言已独审窄修，等待新正式验证（2026-10-21）

最新已验证体验仍453：`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。454尚未完成，不更新latest。

compile3/preflight3通过后，full attempt1/session24920真实exit1于旧normal bridge预览数组[0]断言。父保原断言诊断session28360实测：目标{1,6}正常1、预览10，数组首项实际为新增免费{1,5}/1；运行时恢复正确。原full失败、原C++再次exit1、观测与完整闭包保留。

Skill封31成员最窄提案（manifest4d4279aa，test46387ffc），UI独审6成员b2f08abb通过；父独立编译并运行整份normal bridge提案session88480退出0，RESULT652ac822。随后父按精确diff合入，`legacy-preview-APPLICATION.json`保真实pass/独审/旧失败身份，其余453输入逐hash不变。仅按完整SkillKey唯一找预览binding；normal mode/runtime1/dormant10及其他76检查不变，运行时不改。当前无运行会话，UI在准备全新ready5，追加第5项完整normal bridge专项，保原四项、454输入/179报告与全部来源/事务门。

恢复优先读本节点RUNNING-STATE、PROGRESS和真实日志，不重跑历史attempt/旧ready4验证新源，不删除活动锁。下一步ready5父核→compile4→preflight4五专项→full attempt2→同EXE/源码产物证据二遍备份→普通job1/DGN1/seed1。ordinary路径工具须在新禁用successor绑定实际ready5 schema，不改旧封包。OBJ0显式manifest交叉门overlay、装备预算和分支赠送successor均封未合，女法天击在独占staging实现；不并行构建运行。原资源/历史候选/正常存档保护，全部D盘；七职业全部普通副本/完整技能及最终十职业仍未完成，持续实施。

# 当前恢复点：女格斗454编译通过，专项计时采样窄修已应用（2026-10-21）

453已完整验证备份，最新体验为`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，1537成员二遍零差异；普通圣职DGN1/seed1四房/21击杀拾取/20技能及结算恢复返城通过132检查。454 compile1已通过；preflight1真实168检查末条时长失败，clock-diagnostic1保原断言实测源body740ms在按键后750ms完成，旧测试漏计首tick16ms而得到734ms。独审只移动started到按键前，原740..774和全部断言不变；父已精确应用test8b1a，其余453编译输入不变。当前无运行会话，等待ready2工具绑定实际失败/独审/应用后compile2和preflight2，再full/同EXE/二遍备份，latest保持453。恢复读`dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-integration/PROGRESS.md`、RUNNING-STATE及真实日志；不复用旧ready1假称新闭包，不并行构建运行/改正式源。原资料/历史候选/正常存档保护，七职全普通副本和完整技能/最终十职未完成，继续。下方running为历史。

# 当前实现候选：女格斗上勾拳454已合入待运行验证（2026-10-21）

453已完整验证备份，普通圣职DGN1/seed1四房/21击杀拾取/20正常技能/结算恢复返城通过132检查。454独审12目标窄合：女性自身SKL/CHR/ANI/ATK/EQU、初始/正常学习/MP-CD/两阶段声音、TP163收费前阻挡及清理；正式454输入冻结，compile1/session9555重编，尚未专项/full/同EXE验收。恢复见`reports/seven-job-world-20261020/fighter-upper454-integration/`。最新体验仍1537成员备份`20261020T183257823234Z-priest-upper453`。不将提案或静态检查称可玩/完整技能。

# 当前节点：圣职者空斩打自动通过并备份，继续职业/普通副本（2026-10-20）

priest-upper完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `924ff1f85d65154c1f87ff200fffdd1e64ca97de143fed871d31ddc66ece8490`，453输入/178报告。正常初始1/SP20升2/真实EQU攻击框/精确frame2效果出生/240ms源寿命及伤害/ACT40/保存恢复已接；TP210与Avenger123仍未实现，旧已学收费前诊断保ledger，WillDriver13 active gate留后续。前序Water/Knee/AI/拾取/学习/奖励保留。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/priest-upper453-node/PROGRESS.md，备份 `20261020T183257823234Z-priest-upper453`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续。

# 圣职空斩打453待实际验收（2026-10-21）

恢复补充：compile2通过；preflight2实际失败，clock-diagnostic1确认纯runtime测试缺weaponSubtype，运行时收费前正确拒绝。fixture-revision2从真实默认EQU读取subtype并加强一次收费动作前提，保原时序断言，尚待独审应用/compile3。运行时未改，当前无会话，完整回归/同EXE/备份待完成，latest仍movement452。

当前正式453输入包含Upper15目标，movement452源码/产物已二遍备份并发布latest。compile1通过，preflight1因malformed_response测试未命中真实源字段而失败，保留全部证据，fixture修正准备中；恢复以reports/seven-job-world-20261020/priest-upper453-integration/状态为准，不当新Upper已交付。真实EQU攻击与实例效果消费者已接，关联/时点保持inferred beta，专项/完整回归/同EXE/备份全部完成后才验收。

# 当前节点：普通受击方向输入恢复自动通过并备份（2026-10-20）

movement-reaction完整核心/音频/隐藏UI及同主EXE来源/content/3秒dummy通过，EXE `00ee62e405344c3879ce18461cf844ee293aaa70f7aa9a7ffc2a2f2c2844934e`，452输入/177报告。原test修前真实失败560→560，revision2/3仅修城镇Knee配置及源来袭准备，green1/2失败和诊断保留；最终两个clock六样本验证普通受击恢复方向、KEYUP/失焦双击/换房及正常Knee MP/CD无重放，不称测试字节未变。仅活人显式中断保四方向，其余动作清理，source/数值不改，策略保持推断；status/lethal无新增直接覆盖，普通副本额外结果不泛化。备份 `20261020T163114547687Z-movement-reaction`，详见dnf-native-demo/reports/seven-job-world-20261020/movement-reaction-node/PROGRESS.md。七职业全普通副本及最终十职业未完成，特殊机制延期；后续Priest须实际452新基线窄重基。原资源/历史候选/正常存档保护，继续。

# 受击输入修复：专项通过，完整回归中（2026-10-20）

普通存活受击和玩家控制中断使用显式保留四方向的动作取消：全部技能/动作请求、连招、持续实体与双击历史清理，已接受的MP/CD及单调计数保留。死亡、换场、切角色、重载、显式失焦release仍全清。此为宿主输入所有权一致性的inferred beta，不是1031原生证实。452输入compile4与green3两clock/六samples通过，旧451真实红测、两次测试准备修正及失败保留。完整核心/音频/隐藏UI attempt1运行中；状态控制和普通致死新增边界尚无独立动态验收，不冒称覆盖。详见reports/seven-job-world-20261020/movement-reaction-integration；普通副本重跑、同EXE审计和本节点备份未完，latest仍watercannon-normal。七职业完整技能/全部普通副本及最终十职业beta未完成。

# 当前节点：男法魔法冰球正常基础26自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon-normal完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e183644cb660b231ff7205ba7cb2b36d4cd451ca2b3010c7bbc453c355d89ffc`，451输入/176报告。正常26已接来源初始1/SP15升2/learned槽/一次MP-CD/真实flight-impact/受击/GSD/保存恢复；TP236与元素链51仍false，已学旧被动具体挡在收费前且保账本。前序Water、正常Knee/AI/active/拾取/学习/保存奖励保留；实际边界、beta推断与用户步骤见dnf-native-demo/reports/seven-job-world-20261020/watercannon-normal-node/PROGRESS.md，备份 `20261020T145242215868Z-watercannon-normal`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 当前节点：男法魔法冰球预览链自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e059c892d4c2182911670581c0390ddaa457d37e358080ed8753a97b5172d3e8`，450输入/175报告。已接自身来源fixed body→moving PO→accepted nonmiss→impact/typed排除与独立ALS树；正常26/TP236/元素链51仍false。保留正常Knee/AI/active/拾取/学习/保存奖励，新增实际ACT16场景、六声音12项PCM及两clock等检查。beta回调/缩放/受击等推断与待用户体验见dnf-native-demo/reports/seven-job-world-20261020/watercannon-node/PROGRESS.md，备份 `20261020T141256959979Z-watercannon`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 当前节点：正常怪物Event与男枪膝撞自动通过并备份，继续职业/普通副本（2026-10-20）

normal-combat完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `1f29cfe5ad188dc3565bcea5169ccbd183d53927ef7217345fbd7222e32e35d8`，448输入/174报告。普通source-think自动安装现有Event子集，显式/F7/恢复binding/pending/window/RNG保留；实际Event到Jena ACT及MAP factory通过，不称完整AI。男枪2/4正常初始/SP/槽/Z/MP/CD/伤害/ACT22/装备/GSD/恢复已接，stable Audio0与三份OGG独立dummy解码通过；TP168正常仍false，原生caller/保护/公式等保持推断。金币等前节点修复保留，范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/normal-combat-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续真实多房洛兰和男法WaterCannon；七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 正在实施：普通Event与膝撞正常接纳，完整回归中（2026-10-20）

最近验证备份为checkpoints/20261020T121835179429Z-active-source-reaction，EXE75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e。随后normal AI7与Knee13文件已窄合，compile-only与六组专项通过，448输入冻结运行normal-combat full attempt2；尚未新交付。先读reports/seven-job-world-20261020/normal-combat-integration/PROGRESS.md与RUNNING-STATE.json恢复，禁止测试中改源码或并行构建。原资料/存档/历史候选保护，自动仅hidden/dummy；任务继续。

# 当前节点：地面来源技能活跃ACT受击自动通过并备份，继续技能/普通AI（2026-10-20）

active-source-reaction完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e`，446输入/173报告。精确地面单BodyAttack的霸体/普通/控制/死亡和prepared清理已接；两个clock共22场景通过，MISS/fault不取消，多owner晚故障保留前一成功。MP/CD/KEYUP/序号保持；实体/channel/空中仍具体挡。男枪膝撞正常implemented=false，新生产技能0，TP/声音/接纳继续。金币等前节点修复保留。范围/推断/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/active-source-reaction-node/PROGRESS.md，备份查checkpoints/LATEST.md。全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：基本副本奖励与保存恢复自动通过并备份，继续技能/普通AI（2026-10-20）

basic-dungeon-flow完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `9fc5e798d0df028f92f50181a6cf09324c5798289bdfaa67a5f3509b6382ff09`，446输入/173报告。已接独立击杀奖励游标、intent→私有准备→final持久化→Results/房门、实际writer证明/normal-beta显式handover、KEYDOWN/UP冻结与tick后点击门、主入口共享beta退出确认Reset及可重试保存。正常学习/升级/分支隔离组合、四GSD故障和beta退出故障已执行。金币及同物品图标回退保留。fixture不等于全main/全副本按键游玩，具体七类未覆盖边界/来源/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/basic-dungeon-flow-node/PROGRESS.md。备份查checkpoints/LATEST.md。继续地面source-body活跃ACT受击、膝撞正常接纳和普通Event.ai；全七职业全副本/最终十职业未完成，特殊机制延期。原资料/存档/历史候选保护。

# 当前节点：男枪膝撞来源预览自动通过并备份，继续基本副本（2026-10-20）

gunner-knee完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `7c0b508feb3227a2c892e0f5620367a9b4b33a945e05cc407397313f5f035aad`，434输入/160报告。own job2/skill4的SKL/CHR motion11/ATK1、原750ms身体/装备判定、速度/独立攻击/浮空和窄特效已接隔离预览；特效caller/层、攻速/浮空和当前帧type13霸体保持版本推断。TP/取消/语音/活跃ACT受击/正常接纳未闭合，正常implemented=false，新完整生产技能0。金币和同物品图标回退等前节点修复保留。范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-knee-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续窄合基本副本A/B/C/D及保存期间KEYUP冻结缺口；全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：正常学习/快捷栏/运行时桥自动通过，继续技能与基本副本（2026-10-20）

normal-learning完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `2562c82999bfd1bc7f39ee64a2b9eee5ce463f594dfdc1cd799f33f2366cf3cc`，433输入/159报告。K/NPC正常学习→SkillKey持久购买→有效已学F6快捷栏→原runtime单次MP/CD→同代重载/GSD已接已有消费者；normal/test/manual配置隔离，旧raw休眠，F9显式preview，身体/装备模板与目标外观保存前预检。仅四个own source动作及女枪19主动/12被动正常接纳，其他行保留具体禁用，新生产控制器0。金币等前节点修复保留。具体范围、推断和用户步骤见dnf-native-demo/reports/seven-job-world-20261020/normal-learning-node/PROGRESS.md，备份目录查主工程checkpoints/LATEST.md。下一步膝撞、基本副本A+B及writer/恢复诊断修正；全七职业全副本和最终十职业beta未完成，特殊机制延期。任务继续，原客户端/资料/正常存档/历史候选保护。

# 当前节点：普通/觉醒技能资格分表自动通过，继续正常学习桥（2026-10-20）

second-qualification完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `12b91631fba0a521c9d333a5768d577cdfbd979db3cf47012fb943eeb62fb22c`，430输入/156报告。修复合法空普通fitness和仅有独立觉醒fitness来源的资格早退；当前1734注册行形状已核查，女枪四觉醒/女法光电冰墙及实际GSD rebase消费者同闭包验证。分表选择/两列/回退仍标推断，无新生产控制器或完整正常学习声称。金币等上一节点修复保留，来源/边界/用户步骤见dnf-native-demo/reports/seven-job-world-20261020/second-qualification-node/PROGRESS.md，源码/产物/证据备份查主工程checkpoints/LATEST.md。下一步完整非鬼剑士正常SP学习UI/事务/binding/恢复桥，基本副本A+B仍私有待合、特殊机制延期。原客户端/资料/正常存档/历史候选保护，任务继续。

# 当前节点：掉落/拾取与交互界面自动通过，继续七职业/全副本（2026-10-20）

presentation-pickup完整核心/音频/隐藏SDL、同主EXE profile/content和dummy通过。EXE `c0d35235cdb2d64ba688f56276ac5097994b65b92396aba00f90fd268154995e`，429输入/155报告。金币独立绘制、同物品缺图回退、材料锚点、七职业GetItem与ACT提交打断、NPC X/点击、大地图移动、源加载图/标题、Boss矩形末管红、卡片四档/双击与GSD源等级直接转职一觉已整合。实际范围、推断和待用户体验见dnf-native-demo/reports/seven-job-world-20261020/presentation-pickup-node/PROGRESS.md；节点源码/产物/证据备份查checkpoints/LATEST.md。女法龙牙与七职业中立地面受击已同闭包重编。七职业完整技能/正常非鬼剑士SP学习/全副本基本结算仍未完成，普通Event.ai自动安装和难度属性倍率具体缺口保留，特殊机制延期。下一步继续实质技能和基本副本，原资料/正常存档/历史候选保护有效。

# 当前节点：复仇之刺/下段踢自动通过并备份，继续技能与交互界面（2026-10-20）

body-skills完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过。EXE `e86bd50de645720698a93294d20a550e4d156a64b2e08cef98d07f4fa3954133`，409输入/145报告。job4/116复仇之刺与job1/6下段踢实际消费者已合入，源链/推断/正常学习缺口及用户步骤见dnf-native-demo/reports/seven-job-world-20261020/body-skills-node/PROGRESS.md。逐节点源码/产物/证据备份见checkpoints/LATEST.md。接着窄合女法龙牙、prepared七职业地面受击、GSD直接身份与新版界面/拾取；特殊机制延期，全副本基本流程与七职业完整内容仍未完成。最新Boss矩形多色末管红、卡片难度/双击、源加载图/标题、大地图移动、对话按X/点击继续、拾取动作/高亮/金币图像正在独立节点中，尚未包含。原资源/正常存档/历史候选保护，任务继续。

# 当前节点：ACT判定、伤害窗口与同代恢复自动通过，继续职业技能（2026-10-20）

act-window完整核心/音频/隐藏UI、同EXE profile/content及SDL dummy通过；EXE `fd6c1d415122c917d001b5656c314ac6d792067bb8482cd4f906b58a59c183e5`，407输入/143报告。真实monster→中立地面鬼剑士根ANI接触、源伤害/去重/事务回滚，与三个player→monster伤害生产者窗口/Event.ai pending/typed房间同代恢复已串行整合。具体来源、推断、已支持范围、用户步骤与恢复查dnf-native-demo/reports/seven-job-world-20261020/act-window-node/PROGRESS.md，节点源码/编译产物备份查主工程checkpoints/LATEST.md。实验职业/动作中断、空中/恢复/抓取、DOT/非玩家来源仍未闭合；不把诊断fixture计作完整怪物。用户本轮只需全部副本基本进出/战斗/通关/结算/返城，特殊机制延期；转职觉醒来源等级达标后GSD直接设置、无任务材料并控制学习，详见PLAYABLE-SCOPE-UPDATE.md。GSD尚待实现，下一步圣职复仇之刺/女格斗下段踢、其余职业与prepared反应、GSD及普通副本。原资源/历史候选/正常存档继续保护，任务持续。

# 最新用户范围：全部副本基本流程，等级达标后GSD直接转职觉醒（2026-10-20）

用户明确本轮正常游玩只需所有副本能进入、基本战斗/清图/通关/结算/返城，不要求全部特殊机制；转职/觉醒达到来源等级后在GSD直接设置，无任务材料流程，按新身份/觉醒阶段/等级控制学习。原源数据保留，简化单列用户策略，不将空图加载失败算通关或模板算完整技能。七职业技能和已反馈战斗/UI/地图/性能修复继续，正常学习与测试overlay隔离。GSD直接设置尚未正式实现，由ui-staging/gsd-advancement-next独占节点推进。详细范围与验收见dnf-native-demo/reports/seven-job-world-20261020/PLAYABLE-SCOPE-UPDATE.md；此条覆盖下文完整机制和转职任务的旧门槛。原资源/历史候选/正常存档保护及逐节点备份继续。

# 最新用户调整：副本特殊机制先不做，七职业技能与普通副本优先（2026-10-20）

用户明确“副本特殊机制可以先不做”。本轮暂缓hellparty/深渊/APC特殊遭遇、塔专属流程及副本专属机关/特殊反击扩展；来源和已完成私有成果保留，不计完成。七职业实质技能、正常学习/装备/成长、普通怪物AI与Boss基础战斗、物件/门、地图/UI/性能及普通副本结算返城继续优先。全地图暂不等级/任务准入，资源/格式缺口具体诊断，特殊路径不静默算通关。当前已合ACT/window完成必要全量验证和备份后转回职业技能。详细范围与恢复见dnf-native-demo/reports/seven-job-world-20261020/SPECIAL-MECHANISMS-DEFERRED.md。此条覆盖下文先做特殊机制的旧排序，原资源/历史候选/正常存档继续保护。

# 当前节点：男枪普攻/跳跃与世界反馈自动通过，持续后续实施（2026-10-20）

gunner-world 完整核心/音频/隐藏UI、同主EXE来源审计及SDL dummy通过；EXE `ab83a1c666b6e9c432c086be3f831f3c26cacd21adab84f64ff86360da957130`，398输入/140报告。男枪第三枪分段/源弹速和跳跃局部时钟、枪口渲染profile、UI/门/TIL、入场怪物等级及选角回区域源赛丽亚已整合；精确范围/推断/用户步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-world-node/PROGRESS.md。独立源码/编译产物/证据备份查主工程checkpoints/LATEST.md。男枪948、枪口profile98、raw11命中72等专项在本次正式闭包重跑；前台/原版动态待用户，不将通过检查计作技能完整度。下一步SET DAMAGE CHECK、hellparty与ACT/APC/塔及其余职业技能，七职业全副本/最终十职业门槛仍开放。此最新状态覆盖下文历史未合入和等待门；不暂停任务、不缩范围，原资料/正常存档/历史候选保护有效。

# 当前节点：属性弹、源缓存与共享攻击移动自动通过，继续地图/UI及登录修复（2026-10-20）

attack-motion完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过；EXE `1b65e9728181dc8460026aa0596593ba0ea4a2e107b71f61c8c7050fb377d932`，374输入/124报告。专项移动672、属性弹1468、缓存28、跳攻436、Action.ai787。准确推断/范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/attack-motion-node/PROGRESS.md，源码/产物节点备份查主工程checkpoints/LATEST.md。下一节点修进图退出/长诊断、怪物按入场角色有效等级冻结、再选角色回当前区域赛丽亚及选择/地图UI；这些最新要求尚未在本节点完成。ACT/APC/五职业实质技能和全图门槛继续开放，不暂停任务、不缩减范围，原资源/历史候选/正常存档保护有效。

# 当前节点：女枪跳攻/源武器与Action.ai自动通过，任务继续（2026-10-20）

正式combat-source节点完成完整核心/音频/隐藏UI、同EXE profile/content与SDL dummy；EXE `fe53ce32fabeddb916af979d0f55ba4c35a13a9644e777a950f8dfee460b3a1d`，370输入/121报告，真实World女枪跳攻/源枪口/资格436项与Action.ai787项通过。build为cache/seven-job-combat-source-build，tests为cache/seven-job-combat-source-tests-attempt1。范围、推断、用户步骤和恢复查dnf-native-demo/reports/seven-job-world-20261020/combat-source-node/PROGRESS.md，节点源码/产物/证据备份查主工程checkpoints/LATEST.md。按需PVF/场景节点保留；这是中间节点，继续源工作缓存/属性弹、共享攻击移动、ACT碰撞受击、APC/塔及七职业全副本，不按历史等待门暂停。原生socket/PTL运动、Destination/Move消费者、完整ACT pending恢复、statBase27与五职业技能缺口仍具体保留，不将索引或模板计作完成。原资源/历史候选/用户存档保护有效。

# 七职业全副本修复：按需资源/世界中间节点自动通过，继续实施（2026-10-20）

正式源码已接入按需PVF、OnDemand区域目录、版本化拓扑/恢复、真实WDM/MM与小地图/Boss表现、36/107实际释放键、物件表现及可恢复受击随机，并通过完整核心/音频/隐藏UI、同主EXE来源审计和3秒SDL dummy；364份编译输入/117份报告，主EXE 36691717e00a8bdef803dbed1b9bc252d4314d5909324a377c3a5da5198a97fb。PVF构造保留原字节、字符串offset及翻译成员目录，只在消费时CP936解码/加载该翻译组；fieldView不缓存完整Script，保留原字节/来源/所选字段offset和token。207脚本和2948 MAP对比一致。RegionCatalog默认InitialRegion兼容历史，主入口明确OnDemand；首次需要时轻扫注册MAP的dungeon字段，随后仅准备所选DGN的MAP/MOB闭包，ANI/图像按实际Scene/角色消费者读取。切图先准备私有Scene、恢复物件及演员来源，WalkGeometryView共享原World几何算法以防借当前房间地面检查下一房间；来源读取失败时过门保留旧房间和诊断。已读资源保留会话缓存，没有实现内存预算/淘汰。重复准备缓存DGN1不增加reads/loadingStats；跨333副本后DGN1/v1和DGN3/v2恢复一致。当前拓扑生成191/333、可见131/135，不能当所有Scene/AI/业务可玩。

性能基础历史备份保留，量测边界见reports/seven-job-world-20261020/performance-node/PROGRESS.md。当前按需节点准确范围与失败见resource-world-node/PROGRESS.md；下一技能jump-weapon-ready1及Action.ai READY仍在独占暂存，须窄合、完整重编和回归后才算正式运行时实现。七职业全副本及十职业最终门槛均继续保留。

用户本轮13项及追加7项已授权继续；当前先验证独立性能基础节点，随后继续技能、全区域与怪物整合，尚未交付七职业全副本候选。调试服务缓存不可变来源身份行并逐次检查实际controller支持集，命令回执仅变更时复制；所有HP/MP、身份、pending tick、AI诊断仍即时更新。删除无消费者的逐帧World全量快照。空ACT宿主在没有实例、速度、关系、显示所有权及气泡时只提交连续tick和publication epoch，避免每tick复制全部Actor来源属性；有任何运行状态仍走原子Batch。具体前后同场景测量与状态一致性见reports/seven-job-world-20261020/performance-*.json；这是CPU逻辑量测，不是用户设备GPU/FPS验收。怪物渲染诊断按来源条目及ACT消费状态一次记录，仍保留两种模式的差异。原PVF/ANI、正常存档、历史候选及未来平台原始数据均保留。

<!-- selection-ime-verified-handoff -->
# 最新体验候选：技能图层、选择界面与IME自动验证通过，等待用户确认

主工程当前候选完整核心/音频/隐藏UI、同EXE来源审计和SDL dummy冒烟通过；EXE `74b7e5c3a59783057c482c4f442889389f9d849706527ee367a5e62d88dfd26a`，349输入/110报告绑定。入口`D:\dnf-rebuild\dnf-native-demo\Start-Selection-IME-Fixes.cmd`在checkpoint核验后发布，准确备份目录见dnf-native-demo/checkpoints/LATEST.md。范围、源透明/缺图、未恢复Full输入及其他推断/缺口、用户步骤和恢复点见dnf-native-demo/reports/selection-ime-20261020/NODE-PROGRESS.md；不是全十职业beta完成。前台/IME/听音/手感和原版动态待用户。**交付后等待用户确认才继续其他节点。** 不维护独立预览，原资源/历史候选/用户存档保护继续有效。

# 当前动作/技能节点自动通过，继续整合已排入的界面节点

完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy冒烟通过。EXE `d571ad37668b52c38afa0bd8e18c216eeb44256a2a9b56183066d60bb68fe0b9`；332输入/102报告绑定。范围、推断、失败记录、用户步骤和恢复点见reports/attack-timing-offset-20261020/NODE-PROGRESS.md。节点备份目录以checkpoints/LATEST.md为准，完成备份后才继续正式源整合。当前只是中间节点，最终体验候选尚待下一节点编译和用户确认，不能当完整beta。

# 当前候选：动作时序、技能资源链与选择/输入法（2026-10-20）

最新优先实施源输入到技能实体的链路：M3按Attack持续/Up停止，格林distinct Down续按/Jump停止；发布带SkillKey+actionSequence的停止事务，独立已射出弹丸继续，持续伤害与附层退休且尾效无伤害。喷火火焰/重武器层与激光LaserFire源框补接。鬼剑士源首帧同tick入场、崩山松键结束准备、三段frame3续段（60US→1031明确推断）。F9职业命令只切隔离测试分支的可执行身份，开放当前技能仍使用测试学习服务或明确基础模板；没有原生消费者的分支不冒充已完成。最新功能运行通过状态查节点报告，不能沿用旧检查。

本版交付门以reports/attack-timing-offset-20261020/NODE-PROGRESS.md及reports/selection-ime-20261020/NODE-PROGRESS.md为准。先完成动作/特效节点构建与备份，再整合角色选择创建、副本选择和IME，最终体验候选交付后等待用户确认，才继续其他功能。当前源码已修普攻持帧、女枪受控时序、真实技能附层/ALS事件和XYZ插值；各阶段自动验证与源码身份独立记录，不能使用旧候选的通过状态。

Play-Latest-Verified.cmd读取最近checkpoint并核对EXE/DLL/profile；Run-From-Source.cmd使用独立增量编译缓存及存档。C++源码启动仍需要编译，开发预览的build-only不作为正式验收。启动时选择客户端、PVF、ImagePacks2目录仅登记为下一版可选工作，见OPTIONAL-CONTENT-SELECTOR.md。

# 本轮女枪、业务 UI 与地图修复（2026-10-20）

当前编译与验收身份以 `reports/knowledge-base-audit/NODE-PROGRESS.md` 及 `cache/requested-repairs-final/build-verification.json` 为准。1031 女枪167注册项保留（72主动、95被动）；主动通过所选自身CHR阶段、装备武器层、OBJ/MOB/ANI/ATK和实际World服务执行，不再使用鬼剑士普攻替代专用技能。参数、费用、TP、独立实体、命中、怪物受击、异常、抓取、G组/变身/弹药模式及清理各有消费者和来源记录。具体调用、速度、位置、时序与部分体积仍是明确的推理实现，不能把资源存在或一次命中当完整原生技能恢复。

`FemaleGunnerWorld::prepare/publish` 将资源预检、实例预算、ID水位、动作与费用发布分开；实体遍历期间产生的火弹爆炸延后发布，避免容器引用失效。每个攻击实例/脉冲维护目标去重；源短帧、补tick和快速弹体跨越区间有消费者。火弹范围攻击的植物/昆虫/建筑加成逐目标选择，可破坏物使用同源Fort系数；不沿用首目标类别。女枪效果与旧鬼剑士同编号技能的专用分支分开。状态的base/TP源和等级可由原始字段重算，周期伤害、感电触发、HP/RNG及恢复由同一事务管理。

本轮覆盖配置独立于正常SP/TP、成长和存档账本。95被动仍存在护甲、装填/穿刺、部分触发、职业业务、队友关系等缺口，详见 `reports/knowledge-base-audit/female-gunner-passive-ledger.json`，不把可配置计为全部完成。女枪持续动作/实体的重载策略为取消瞬态，不伪称完整持续技能恢复。正常女枪转职、觉醒及SP学习仍需后续验证；当前提供隔离配置体验。

五个业务UI由源UI包络、图块、肖像表、分页和真实操作/事务组成；技能学习图标直接读取不可变common元数据，而不是数值选择视图。正常学习仍经统一服务提交，实验女枪通过配置栏设置主动、被动和等级。地图按source layer/order及far/middle/near视差执行；优先124张注册图保留任务房诊断，不将其混入普通池。用户本轮确认门优先于继续后续节点要求：交付候选及备份后，等待用户确认。

# R60-03技能空放退出修复：自动验证通过（2026-10-20）

新主EXE `f2d7434e25b297d03e9d7c611db9f03ea945db407ec15f8f1e81114bba5d6638`，实际World 2692项/18次空放、学习51项、完整核心/音频30项、来源审计及局部SDL dummy smoke通过。启动 `D:\dnf-rebuild\dnf-native-demo\Start-Skill-Crashfix.cmd`；备份查 `reverse-60us/checkpoints/LATEST.json`。用户操作复测待执行。后续集中主工程，不单独维护独立技能预览；R60-04草稿保留，下一步继续04。完整记录见 `reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md`。

# 当前补充：R60-03技能空放退出修复（2026-10-20）

实际用户fatal及原03 core重现均为 `Normal learning state changed; reset the test overlay explicitly`。首次为测试专用技能写冷却会插入正常零级空行，旧指纹误判学习变化。修复只忽略精确空行，真实学习和未知字段仍受保护；旧binding通过精确校验后升级。实际World重复空放/冷却/测试开关/重载与全核心音频正在验证，具体产物查 `reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md`。R60-04未编译草稿已保全；后续不再单独维护独立技能预览，集中主工程。
# R60-03 动画时钟与运行时消费者（2026-10-20）

状态：**automated pass / user pending**（`automated_pass_user_comparison_pending`）。[R60-03-VERIFICATION.json](../../reverse-60us/integration/R60-03-VERIFICATION.json) 已绑定主工程285份输入、84份报告，最终完整核心与音频30项通过；同EXE来源审计和 SDL dummy 局部 smoke 通过。EXE SHA256 为 `7c12c8ca38b717d6da5ec2eeb16ac1f25df372a965e03de836417bfe174db4a0`。正式测试目录 `cache/r60-03-tests-final-r4-checked` 的 [clock报告](../cache/r60-03-tests-final-r4-checked/reports/animation-clock-tests.json) 为1541项通过，含九个实验职业完整待机往返。节点范围与用户步骤见 [R60-03-PROGRESS.md](../../reverse-60us/integration/R60-03-PROGRESS.md)；用户画面、听音、手感及原版动态比较仍待执行。下文旧构建仅对应各自历史身份。

`--ani-clock-policy` 独立选择默认 `legacy-scaled-local-age`、`source-delay-rate100` 或 `inferred60us-percent-deadlines`，与渲染 profile 分开配置。新游标按连续60Hz模拟 tick 提交16/17ms，发布 frame/local/span/ended 和按序 FrameVisit。有效攻速截断为正 int32 Sani 的映射是具名推断；安装与改速刷新保留各自算术表达式，暂停时延后刷新。源 ANI DELAY 与资源缓存保持不变。

普通、冲刺及跳跃攻击实际消费同一根快照驱动身体、同 motion 装备、攻击盒、声音及连击；持帧继续接触新目标，原动作命中账本保持去重。连击安装 tick 消费新动作首帧，不额外推进时间。九个已开放实验职业使用自身 CHR/ANI/ATK/EQU/LAY 和同一接口，仍属于不完整实验控制器。等待／移动等普通姿态另有 source-rate100 根；失去姿态所有权时释放专用游标，保留攻击快照，返回相同待机来源后重新安装，避免跨 tick 恢复旧游标。

效果的位置跟随、玩家暂停绑定、独立 source-rate100 时钟和外层寿命分别处理。ALS 按父帧 visit 和源记录顺序执行 add/remove、同名替换与后代清理；限时移动子层从父当前位置延续剩余轨迹。ANI ended 保留末帧，销毁由 expires/remove 决定。显式 animationOffset 实例持续使用具名 legacy 回退并诊断，不伪装成原生 seek。ACT 继续采用互斥的 source/external 时钟模式，每 tick 只提交一次已选择的动画 delta，未把新 elapsed 再乘攻速。

R1–R4 的修复和新增暂停改速、同 tick 连击、九职业完整待机往返回归见 [独立审查](../../reverse-60us/integration/R60-03-REVIEW.md)；它们已随上述正式全量回归通过，早期4秒测试上限失败及修正证据保留。60US 算术和装备树合同迁入1031仍标跨版本推断。技能专用阶段、怪物／物件仍保留原 source-milliseconds 消费者，完整原生 timer、技能控制器、命中接受和伤害链没有因此完成。普通存档继续取消瞬态。用户画面、听音、手感及原版动态对照待执行；十个非缔造者职业的最终范围保持。

# 历史 R60-02 渲染候选接入（2026-10-20）

隔离构建 `cache/r60-02-build` 完整核心/音频通过，EXE `128fdb1a2a3b533f973179061a8a5bcaa9ef06900592c0f71b2bd05ac0d608eb`。`--ani-render-profile inferred60us1031` 让正常ANI身体、装备、效果共用便携采样/四顶点变换；默认legacy1031保留。来源profile审计与SDL dummy部分渲染smoke通过，画面/声音/手感及原版动态待用户。源码、算法边界和节点备份入口见 [R60-02进度](../../reverse-60us/integration/R60-02-PROGRESS.md)。

R60-02只消费既有资源时间；战斗poseFrame可能冻结插值，原生clock/攻速/附层关系归R60-03，不能据此声明全部技能完整。独立播放器模板未迁入主World，1031十职业最终门槛保留。

# 历史已验证节点：来源相机、NUT动作消费者与技能输入反馈（2026-10-19）

build30完整核心/音频通过，281份源码输入与83份报告hash绑定，EXE `d54f76a3de51fd6c1897a18dc3eb6bd8ce21dc52ffae2c0b34847bcd80babb53`；核心库 `e23ff92ee3fc6512f8f19859652ad5103ec01490d37bc5cd1fd3342d38a5a879`。节点详情、限制与恢复路径见 [NODE-PROGRESS](../reports/beta-script-camera-20261019/NODE-PROGRESS.md) 和 [LATEST](../checkpoints/LATEST.md)。profile/content同EXE审计未启动前台；前台、听音、手感与原版动态仍待用户。

相机从源TIL/IMG逻辑尺寸、裁剪与连续列范围求视口；艾尔文防线及城镇/地下城尺寸、重采样检查通过，source width与碰撞余量分离。技能失败反馈不改变模拟位置；Z队列在动作自然结束tick复核资格、MP和CD。Squirrel typed host经World事务实际触发男魔法师Buff声音回调。完整Buff状态/动画、全NUT API、ACT外层持久续演、statBase27成长消费者仍缺，不能据此声称全技能或全职业完成。

下一节点接入早期启动进度界面和受限并行的独立安全工作；完整哈希与缓存消费校验保留，当前共享Assets/PVF变更型缓存不能直接并发。无前台试玩时只能以串并行内容身份一致性与实测耗时报告代码验证，用户仍需检查启动界面和异常呈现。

# 当前整合：城镇、共享攻击读取与 Event.ai（2026-10-19）

build26完整核心/音频与同EXE无前台审计通过，222输入/79报告绑定，EXE `84025a71f14e6efd1f2747695c73284f26518ac05532a86e11771fd51287dad4`。城镇587项含77/77准备、实验196项含九职业实际HP、存档80项；详细范围和备份见 [NODE-PROGRESS](../reports/beta-act-event-20261019/NODE-PROGRESS.md)、[CURRENT_TASK](../CURRENT_TASK.md)、[LATEST](../checkpoints/LATEST.md)。

`TownAccessCatalog` 保留town.lst/TWN全部注册、原字节/有序字段与SourceRef，F10通过现有地图模态入口提供全部源区域；`prepareTownMapTraversal/prepareTownArea` 共用MAP准备，在私有场景验证源地面和到达点后发布。137条城镇区域链接按源目标导航，30条地下城门保留WDM和缺席的area，11条公会入口显示业务缺口；14条明确MAP别名只对已核PVF生效。TownLocation和return_town随RegionSession进入同一CharacterStore根，普通/测试均提前开放不等于全部业务完成。

`character_attack` 统一现有鬼剑士与实验角色的CHR→身体ANI/装备EQU/LAY武器ANI攻击框读取，保留各职业自身资源。实验运行时每tick采样有效源帧区间，World每action/target去重；ANI声音仅新进入帧消费。用户指定“普攻模板”把所选同职业SKL接自身初始普攻动作/ATK，费用/冷却仍由SKL求值，存档/伤害trace标记临时调整，不计专用技能机制恢复。

F9通过现有命令边界选择实际MOB提供的Event.ai难度，仅F7探索+测试开关+明确选择时安装；不替换普通AI，也不从normal回退easy。F8导出路由、接受接触、候选结果及具体拒绝。直接运行已验证备份EXE默认自身runtime/saves，程序记录实际binary_path/save_directory；历史节点保持原样。

ACT typed runtime/纯候选宿主90/68及Event.ai核心37/独立诊断World26随build26通过。真实F7 Jena源等级60的statBase27非零仍缺语义消费者，24/25失败保留；26仅核明确拒绝/F9不制造演员，positive_f7_source_growth_verified=false，不能称来源战斗已闭合。ACT外层磁盘续演、Squirrel、失败抖动/Z衔接、P14物件仍在独立staging。下一节点相机/分辨率黑框以艾尔文防线为对照。完整beta约10%工程估计，最终范围不变。

# 历史节点：全地图与角色实验入口（2026-10-19）

build19完整核心/音频与同EXE无前台来源审计通过，204输入/73报告；EXE `1afb8642b7bfa3471d203d2ec9c195753f9118044d3905559a74bde542883955`。范围和备份见 [NODE-PROGRESS](../reports/beta-experiment-20261019/NODE-PROGRESS.md) / [LATEST](../checkpoints/LATEST.md)。

全MAP目录与私有准备接F7，F9隔离测试分支可绕等级/任务入图。World每handle独立受击、抓取、AI和ACT能力，缺地面阻行。来源限定适配登记保留完整源槽和实际消费槽；Thrower用源PO攻击路线，不误套MOB直伤。ordered_json收据追加不持有可能失效的子节点引用。

九个其他职业显式实验准入，使用自身CHR/ANI/ATK；初始武器读自身SD/EQU。13槽手动配置、源MP/CD、统一伤害/状态、同代CD与配置磁盘恢复及拒绝原子性已测；配置保留有序未知字段。正常Swordman第13槽使用绑定。五职业本次有实际HP损耗，另四仅动作；专用技能/被动/分支/觉醒继续实现，提前入口不等于完整职业。

自动检查全图36/准备17/World32/实验97/存档79通过，14–18失败保留。434保护原基线428一致，正常两档143/142代在首次观察前已变化，写入者未定；之后不变，原始基线未刷新。前台/声音/手感/原版动态待用户。备份后继续P01–P19；Event.ai、ACT磁盘续演和Squirrel World仍在staging，完整beta约10%工程估计。

## 当前节点：来源 ACT 与 World 宿主（2026-10-19）

build13核心/音频通过，EXE `144efcfe162b1b0c9cb86cd918a41c734f5f823760cb0f8918ce5ef1c30cf76b`；ACT宿主49、路由/工厂47、World服务27、房间状态23项。详细行为/策略/限制及保护变化见 [NODE-PROGRESS](../reports/beta-act-world-20261019/NODE-PROGRESS.md)，备份见 [LATEST](../checkpoints/LATEST.md)。真实MAP→MOB槽→World自有host接tick、替换事务、速度/位置/方向/移除/声音/文字台词；互斥动画时钟、hitstop/stun/AI暂停、抓取恢复及换场清理有实际消费者。Event.ai、ACT攻击/物件及磁盘续演仍待实施，不能标整怪完成。

本次新增用户优先项正在staging：全MAP入口、测试无等级任务准入、其他角色PVF实验体验与13槽技能配置；不属于build13已测内容。完整beta约10%工程估计，十职业最终范围保持，实验内容后续正规验证。434保护基线发现正常存档2项新差异，保留原始证据，详见节点文档；前台/原版动态待用户。

## 历史节点：真实Tau状态与恢复身份（2026-10-19）

状态运行时、同代玩家/房间恢复与重复读档句柄修复已实现，完整节点与续做见 [NODE-PROGRESS](../reports/beta-status-20261019/NODE-PROGRESS.md)，备份入口 [LATEST](../checkpoints/LATEST.md)。最终build10核心/音频通过，EXE `d6633262e4ebe43d3964cda2aec0ea71e749c7decdd3eecb9dfcc5cb8c6e2d53`；状态75、World31、房间20及身份恢复23项分别通过，真实Tau在30/60/144FPS和补tick下HP/状态/RNG/事件一致。06/07失败及修复前审查保留。

伤害/状态共用私有RNG候选，实际眩晕输入/AI门槛与普通硬直分离；同代存档校验策略、源、编号归属/水位和存活资格后显式remap。实体与状态分配水位合并live历史，永久耗尽不回绕；整组演员预分配后发布，CharacterStore在select前预检双次分配，重复apply不复活旧句柄也不写旧档。Tau接近轨迹采用具名推理、攻击帧边界取当前ANI，不称原生证明。

ACT核心capture已编译但World host仍待正式接入；Squirrel兼容/typed宿主探针已冻结但未接游戏。完整十职业/技能/业务仍未完成，beta约10%只是工程估计；normal main恢复已测，不涵盖无bundle的standalone玩家恢复清理边界。新节点备份源码、EXE、实际静态库和证据，434保护基线无新增差异；用户前台与原版对照待验。

## 历史节点：来源投掷物与显式HP物件伤害（2026-10-19）

已测源码/产物/报告归档至 [节点进度](../checkpoints/20261018T165352718179Z-source-projectiles-object-damage/PROGRESS.md)，EXE `ac7bfda2e31529593e0de22fb89afc07a4df82efdd05ff0aa5d3415ff891eac1`，546文件hash复核通过。正常学习/属性链继续回归；投掷哥布林实际消费MOB→PO→ANI/ATK/PTL绑定，发射冻结属性/句柄/攻击实例；显式HP物件接触后使用统一伤害和攻击框冻结来源。build05核心/音频、World伤害38项及物件10项通过，同EXE只读审计完成；03/04失败保留。

Tau第二攻击stun消费者、投掷destroy PTL呈现仍待完成；ACT/Squirrel在隔离staging推进。不能当正常全流程或完整beta验收，十职业/完整装备被动/全域业务未完成，完整beta约10%为工程估计。434保护基线中旧build4个EXE仍是上节点已知变化、其余430一致，无新增差异。完整状态与下一步见[CURRENT_TASK](../CURRENT_TASK.md)。后续每完成节点都新建源码、编译产物、证据和PROGRESS备份，历史保留。

## 历史已验证实现：基础设施候选2（2026-10-18）

完整实施入口仍是[方案v1.1](../../dnf-native-build-plan/README.md)。本节优先于后面的历史“仅文档/最新运行身份”记录。独立候选 [README](../candidates/beta-foundation-2-20261018/README.txt) 对应 EXE SHA256 `5004fee99851d415a9ee6286230778df2f44b7731aad253a6e18ff54f8dfbaec`；实际源码、构建身份及自动检查均归档于候选 `source/evidence`。后续源码继续实施，候选不会自动更新。

`ContentProfile/SourceRef` 分别绑定PVF和静态根、内容/缓存身份及原始脚本字节、有序token、字段与来源范围。`content_catalog` 生成来源索引和能力缺口报告；并未完成所有区域的运行准入。固定模拟、实体句柄、动作实例、命令队列与独立随机流已接入World；存档使用单写者、同代状态/RNG/事件、备份与迁移，完整持续实体图仍未恢复。

人物成长采用 `inferred-chr-growth-v1`，不把CHR攻击/防御系数宣称为已证实最终STR/INT。技能MP/CD通过具名来源策略计算并在释放时消费。`speed_attributes` 汇总正常等级合格装备的来源速度；普通移动和基础普攻使用实际结果，基础攻击仅采用 `ScaledLocalAge`，不改源ANI delay且不双乘倍率。技能各自施法/攻击时钟仍待接入。

`equipment_attributes` 保留EQU实例UID、槽位、耐久、原字段及完整来源；计算HP/MP固定增量，再应用MP百分比。前者依据官方EQU注释156–158，后者依据creaturesample.equ:33；跨装备加算、先flat后rate和破损失效属于明确推理。未知资格、条件或套装不能静默应用。World换装、升级、调试与CharacterStore私有恢复统一准备这些结果，纯CHR全量重建防止叠加。换装夹紧现值，正常升级保留绝对损失，死亡不会被重算复活。

`World::changeEquipment` 在私有Progression副本上完成装备资格、来源属性/速度/外观预检，再发布并commitPrepared；详细失败留statReport，UI仅显示短消息。成功后UI只刷新外观副本并保存，避免再发布一次装备。维修与其他业务事务尚未全部统一。

`monster_attributes` 按MAP自动等级/固定等级、MOB可选HP端点与24列成长表HP列、有序HP category计算；表列映射交叉参考服务端，策略 `inferred-mob-table-hp-v1` 不声称原生PC最终公式。正常新run使用来源HP；legacy演示65/240和用户倍率只用于具名旧策略。session保存策略，旧字段缺失迁移legacy；已访房间的HP损失和source_stats原样恢复。难度/队伍/named/champion完整属性链仍待完成。

独立F9测试窗通过命令边界修改HP/MP锁、无CD、AI暂停、等级覆盖和暂停单步。开启测试先保存正常提交，再隔离到beta-tests；返回选角重新选择恢复正常分支。`SDL_RenderSetVSync(...,0)` 显式关闭工具renderer同步，dummy双窗检查实际SDL flags。

构建/核心/音频最终通过：[日志03](../reports/beta-foundation-2/build-20261018-03.log)。装备模型55、实际资源消费15、事务17、怪物71、调试69、双窗18、恢复180项专项通过；详细报告在隔离 `cache/test-beta-foundation-20261018/reports` 及候选evidence，不能作为职业完整度。初始失败与历史存档差异均保留，保护范围查[当前交接](../CURRENT_TASK.md)。没有前台或原版动态验收。

P05/P06/P07及十职业完整门槛仍未完成：正常技能购买/账本待接入，伤害仍含训练武器常量与简化防御，ACT/Squirrel、其他职业/转职/觉醒、完整被动/装备分组和全域业务仍有实质缺口。正在继续正常学习、推理控制器准入和战斗属性来源模型。

## 历史：下一版技术方案入口（仅文档）

[完整v1.1方案](../../dnf-native-build-plan/README.md)及[执行任务](../../dnf-native-build-plan/13-execution-plan-and-acceptance.md)记录下一版通用资源、十职业、属性装备、行为脚本、世界经济与存档设计。方案允许明确inferred实现，最终完整生命周期门槛不降低。用户负责前台试玩。此次没有修改运行时代码或发布新EXE；下文仍描述已有实现。

## 角色、技能与装备的资源边界

内容来源是当前 PVF 和原客户端资源；运行时代码执行通用规则。`CharacterCatalog` 以源注册表建立职业、技能、CHR 动作与默认装备关系，`CharacterIdentity`／`SkillKey` 保持职业和职业内技能编号。外观通过 CHR/SD 的默认装备列表和 `equipment.lst` 找到 EQU；EQU 的原脚本字段、顺序与偏移继续保留。LAY 动画依照 CHR 原动作标签、重复字段出现次数和数组槽绑定，空槽或未知布局不会回退到相邻动作或鬼剑士资源。

SKL 负责当前源数据中声明的类型、学习字段、MP/CD、等级表和作用域。执行阶段、控制器状态、命中事件与生命周期由运行逻辑负责；当源数据未表达这些行为时，适配配置必须独立记录为已证实、推理或未知，且不伪装成 PVF 原值。当前仅鬼剑士控制器可运行，其可执行技能清单和阶段／效果映射仍有代码表；资源注册完整不代表技能实现完整。增加新职业技能前必须补齐资格、请求、提交、动作/ATK、接触/特效、续段和退出清理链。

`skill_data.hpp/cpp` 按 `SkillKey` 读取 SKL 类型、学习字段、等级表和作用域值。当前 `dungeon`、`pvp`、`warroom`、`death tower` 字段显式覆盖 `common`；选择结果带有原字段、作用域、序号、偏移和原始来源。未实现的未来字段保留在完整脚本中；重复的被选字段不任意选胜者，而留为歧义并阻止依赖它的运行时消费。等级表按首值声明的列宽精确取值，等级0无可执行行。

技能执行阶段、控制器状态、命中事件与生命周期由运行逻辑负责；当前鬼剑士可执行技能清单、阶段、效果路径和部分 `SkillKey` 到行为的绑定仍有代码表；其他角色控制器未开放。MP/CD 当前使用源首端点，不等于两端插值、武器/命令修正或原版公式。

用户已暂缓选图与其他 UI 图层复现，正在整理 UI 逆向成果。当前工作优先角色、技能与装备，UI 不作为本阶段技能或装备完成的验收替代。

## 2026-10-18 全工作线隔离整合候选（最新运行身份）

候选 `cache/build-full-worklines/dnf_native.exe` SHA-256 为 `268f179d718038d1b3644a2f40d1d6813812039976473606fc100c72ba9fc0c6`，构建、核心与音频测试通过。普通控制窗口输入11项和六场景置顶可见冒烟均通过此哈希，用户存档未变。普通输入不是物理键盘／IME或原客户端动态验证。

`CharacterIdentity`、`SkillKey`、身份注册和输入请求边界现已抽出；实际可玩控制器仍只有未转职鬼剑士。此候选不满足除缔造者外10角色、转职、觉醒和完整技能要求。物件层通过170项专项；33份合法MAP、682处放置、198处光效工厂及真实 type-14 XYZ受击框接触有覆盖，但声音/PTL、原生受击资格和payload持久事务未完成。

选图状态和键盘资格验收在800×600及1280×720通过；鼠标、高DPI未验证。已查看最终哈希实图，选图卡片在两种分辨率明显重叠，整体视觉验收失败。旧鼠标失败记录来自哈希`7c6a205c…`，不冒充本候选结果。详细证据见`../reports/combat-native-reverse/full-worklines-candidate-20261018.md`。角色覆盖矩阵仍固定于历史`1c55ec60`，没有随本候选改绑；正式包仍未覆盖。

## 2026-10-18 零级资格接入与水平运动模块（1c55ec60历史快照）

> 2026-10-17 用户复核：页面、UI、地图和图层整体错位，视觉验收失败。先前“错误计数为空”仅是运行日志，不能表示画面正确；先前视觉判断撤回，当前优先修渲染与布局。

## 2026-10-18 零级资格接入与水平运动模块（历史快照）

该阶段隔离候选 `cache/build-eligibility/dnf_native.exe` SHA256为 `1c55ec6089ec2c38189223d8a18d34144c34ba3b0ae471caf7d437dfc797d2b8`，完整构建／核心／音频exit0；playable仍旧7a85，旧2567运动候选与a63f模块游戏EXE单独保留。其构建日志、旧失败和GUI身份按历史记录核对。

`play-combat-candidate.cmd`固定启动1c55，支持原参数、不隐式构建，默认项目saves；它是独立测试入口，未替换正式playable或旧默认启动器。隔离存档可传`--save-dir cache/candidate-user-saves`。

已接入原基类86D9D5..86D9F4的`level==0`新释放拒绝，位于缓冲和MP/CD提交前；既有续段处理不改称完整原生事务。缓冲释放重入资格检查，拒绝的零级输入不延迟施放。CharacterStore明确主动0级现在保留0，旧档缺省仍1；没有改动被动、原版初始学习或最终消耗公式。20项专项含13主动同姿态已学正控、缓冲双向翻级和磁盘重载。独立review和修复前失败见`skill-eligibility/runtime-gate.md`。

当前hash零级隔离fixture6点（092840）与普通新角色操作11点／十字双向阶段（092909）通过、置顶可见、用户存档不变；它们是窗口消息，不是物理键盘、原版动态或全部UI验收。本轮没有重跑完整副本流程和死亡fixture。40项构建／报告／GUI身份归档在`build-checkpoints/eligibility-1c55ec60-final/`；专项JSON按构建保留副本，不能再用最新全局报告验证旧候选。

static_motion纯模块恢复方向0/2负、1/3正、其他0，normal/alternate独立选择、scale1000绕过与原float32乘法顺序；检查速度容差2^-23、同加速度保留计时、直接写入总重置，以及8B0600剩余加速度时长。20项专项及独立32位原机器码12例通过；未接入实体，90/110ms运动曲线仍是重建。探针失败、原字节和来源hash完整保留于horizontal-motion，静态42项与独立review不等于原游戏动态。

skill-parameters静态44项保存level-info列矩阵、学会等级消费者及后续修饰，入口和最终参数仍有保护缺口，未替换运行时getter。jump-physics最新21组证据证明当前洛兰4类MOB未启用可选空中伤害重力，不给它们强行套默认20/−300；消息累计字段不等同demo伤害。女格斗自然退出／五句柄清理及粒子owner修饰集合生命周期已分类保留，完整控制器／最终倍率仍未闭合。全部来源继续保真，当前仍仅鬼剑士可玩，完整10角色交付未完成。

## 2026-10-18 原生运动算术候选（历史）

最新候选 `cache/build-next/dnf_native.exe` 为 `2567d4d5288e040b26c64e0f52e41b9ff070a15fdfd8a0d292b58805f26a70b0`。`build-test-motion-final-20261018.log` 完整构建／核心／音频exit0；正式playable保留旧7a85。build目录为上轮误触发编译产生的fc8657dd，并无完整验证，不再与playable相同。构建脚本现在先解析参数、限制输出在项目内、检测运行中的游戏，再使用D盘缓存。不能按旧段落把build当本候选。

平台无关 `AxisMotion` 采纳 `8B1C40` 已恢复的算术：每轴速度与i32加速度，有限剩余加速时间，tick内到期的分段平均速度，到期仅清加速度，位移而非速度限制±2000。源0.001f与i32低32位乘法保留；零时间仍清已到期加速度。人物跳跃与怪物浮空使用demo时钟的16／17ms推进。当前430／980、60Hz、落地清零和double高度存储仍是重建／适配，不宣称x87控制字、原生位置存储及碰撞副作用一致。`axis-motion-tests.json` 将完整起跳／顶点／落地样本与解析积分核对。

`particleStraightKeepLast` 按 `E581E0` 恢复未投影轴位移，逐步float32，T=0先i32乘积回绕，非零末速度继续推进。10项检查含固定binary32样本，防止换成双精度解析式改变原运算。接口要求已经过调用方修饰的速度；**尚未接入十字PO运行时**。GoreCross最终技能／装备倍率、投影／镜像／更新消费者和删除仍须闭合，约56未修饰样本不是实际终点。

十字frame6沿非空setATK路径重置命中登记的证据见 `skill-controllers/swordman/gorecross-attack-reset.md`；本地清集合、计数并推进serial。受控静止目标fixture记录tick6／27两次身体命中、tick24 reset。原生两阶段均请求selector24，其到CHR具体ATK的保护译码仍未知；本地GoreCross1用于两阶段的映射明确保留重建身份。

当前候选正常窗口消息操作11点＋十字左右阶段：`input-20261018T085401`；设置重载5点：`input-20261018T085436`；accepted-hit特效fixture15例／74检查：`effects-20261018T085500-95f484`。普通洛兰＋深处48点流程 `input-20261018T085839` 通过，含两副本结算、NPC任务／补给／维修、回城和实际退出重载；技能等级／绑定和两副本通关记录一致，最终HP139／MP1。全部hash一致、窗口置顶可见、用户存档不变，测试已退出。技能为demo学习配置，不是全Lv1；fixture不是正常攻击判定或原PC一致性验收。来源／候选身份交叉审计见 `candidate-verification-20261018-motion.json`。

只读 `jump-physics` 已闭合命名字段到bank0和起跳参数语义，最终bank3属性修饰仍受保护；`skill-data` 区分static3B8、level-info3CC与学会等级59C；`particles/straight-keep-last.json` 保留浮点、时间、未知修饰的独立合同。所有原字节／有序tokens／hash和导航更正记录继续保留。除鬼剑士外的职业控制器仍未接入，不能据静态审计或本候选测试称全角色完成。

## 2026-10-18 设置、音频、输入与ANI事件候选（历史）

正式build／playable保留7a85发布，本轮隔离构建 `cache/build-next` 最新通过的EXE为 `2b5e4b6ed69f20beb60942dc36fd6ca7827edc29aaf96a2f28988c4432b71f76`。`build-test-dash-event-input.log` 全套exit0；身份85、用户反馈30、ANI事件11、音频30专项均通过。当前运行时仍仅鬼剑士，来源目录／静态合同不等于其他职业接入，完整交付门槛不变。

`audio_catalog` 遍历场景全部sound ID，按XML分类选择BGM和环境声，不再误用首ID；独立music与ambient bus，同曲跨房延续、失败重试、音效32槽不挤掉音乐。PCM非零计数和SDL dummy专项只验证管线，不当作听音通过。四音量和普通／首领血量倍率有独立设置页及settings持久化，保留未知字段。默认2／3相对旧65／240，新地下城冻结，旧session1／1兼容，RegionSession schema3保留怪物实际HP；CharacterStore schema4保留身份、未知字段、空快捷槽并拒绝未恢复控制器。

移动与跳跃清除遗留攻击poseFrame；dashattack必须从当前dash状态进入，攻击结束不继承旧run资格，持方向恢复步行、新双击才重新跑动。230ms输入窗口仍是本地适配；连突刺按当前SD frame3检查资格。碎片显示700ms上限／150ms末段淡出是用户指定调整，原PTL不改。

`AnimationEventCursor` 保留不可变源ANI和独立可变实例，恢复prop23低16位、FFFF sentinel、跨帧顺序／单pending覆盖、抑制／消费／重置语义。十字斩四附层按各自时间采样，index1事件1驱动phase1→2，下一tick创建血十字，身体frame10普通mode0退出；删除bodyframe7创建及550ms附层硬截。当前原生已证object20028及相对XYZ85／0／82；完整粒子、ATK译码、伤害、攻速／暂停和声音仍有缺口，不能描述完整技能已复刻。报告入口 `animation-events/` 和 `movement-input/`。

设置前台 `input-20261018T081759` 5点pass并实际重启；控制前台 `input-20261018T082229` 11点及十字双向短阶段pass，均用户存档hash不变、窗口置顶可见。设置返回按钮旧提示遮挡已实际看图确认消除。早期深处流程 `input-20261018T075455` 的用户存档发生变化，保留失败边界且未回滚；不能列为存档保护通过。原PC动态、物理键盘和完整UI仍未验收。最新证据与后续候选身份以CURRENT_TASK首节为准。

## 2026-10-18 全角色来源接入与原生默认续刀（历史发布）

本节优先于下方历史构建。最新目标是当前1031 PVF注册的全部角色、转职和技能；用户允许暂缓缔造者运行时及验收，其原始数据、索引和来源继续完整保留。**当前可玩角色仍只有鬼剑士**，其他角色尚未用通用模板替代或开放。

新增平台无关 `CharacterCatalog`（`character.hpp/cpp`），真实读取character和skill根注册表、11份CHR、11份技能表、11份characteretc、default.etc和实际7份data/skill SD。每份脚本保存原始字节、完整Script、有序tokens及PVF成员offset／checksum等provenance；每个注册项保存ID、ordinal、literal／resolved path和token offset。1497动作槽含67空槽，670 ATK槽含28空槽，重复绑定保持；1734技能行对应1711独立SKL，不能据目录中1960个SKL自动开放未注册内容。初始、成长和觉醒分块保留，不扁平取首值。World现有鬼剑士动作从真实CHR绑定读取，基础主动和被动按真实技能注册ID查来源，缺失／歧义显式拒绝。

原生默认鬼剑士普攻取消表 `[5,4]` 已接入当前运行时。`CAE400` 经 `D14710→D15137` 初始化，`67E970` 零基读取，`869EB0` 在state8按当前attackIndex检查取消帧。现在队列输入可在首刀源frame5、第二刀frame4接下一刀；未队列输入保留完整收招，第三刀无凭空的续段阈值。当前100%动画时钟下三刀最早250／450ms进入第2／3刀、1000ms收回；命中本地暂停会平移时钟。四武器／双向、晚输入、无输入、暂停冻结及恢复共50项专项已通过。原生 `+1A4` 完整语义、输入请求队列、转职覆盖及攻速未闭合，不能宣称攻击手感或全部资格已一比一。

共用 `collision.hpp` 按原盒minimum corner和extent处理XYZ接触，左向 `-x-width`，非零输入盒边／面相贴成功，交集输出可为零extent；近战和独立PO使用同一边界规则，近战X扫掠仍为重建。ALS解析先收齐use-animation声明再执行有界add/remove编译；未实现命令保留完整字段诊断，不静默当普通add。当前PVF未发现声明在事件之后的实例，不将该结构改进说成真实内容故障修复。

证据入口：`reports/combat-native-reverse/all-characters/README.md`、`state-attack/findings.md`、`resource-render/README.md`及`collision/README.md`。已确认ANI速率100=正常，child以自身累计delay映射时间，跨帧ALS事件有序分发，层按signed值稳定升序。CHR1000基准不可混用；DODGE／LINEARDODGE真实混合、延迟add出生时钟净效应及none-effect字段消费者未恢复。状态直接set与请求addSetStatePacket分开；移动资格局部谓词、速度／第二运动参数／倍率已确认，完整运动积分仍未知。HP保护值写入和部分死亡触发已定位，碰撞至伤害公式整链未闭合。

最终完整构建 `reports/combat-native-reverse/build-test-final-source-path.log` exit0：核心30、源模型1828、默认续刀50、技能10、外观23、怪物110、区域17及命中反馈122通过。当前build/playable SHA256均为 `7a85bd452feb77b2000cec489ed0c35574c4da1d74d00b82f0e80678767fac30`。最终inspector独立来源464／464通过（catalog-crosscheck/20261018T070529.444202Z-9fd9430a）。发布EXE普通窗口消息流程 `input-20261018T070550` 25点pass，洛兰首领／德利拉维修／回城及实际配置和通关记录重载一致，用户存档未变，两窗口置顶可见。最后HP132，技能配置不是全Lv1；当前未重跑深处或技能smoke，不借用历史截图。实际查看四张本轮攻击／首领房／维修帧，未判整体视觉一致。36项发布交叉核对在`release-verification.json`。

新增attack-speed静态证据：`14FD480`初始化函数传float100给global1A6FBB0的保护赋值入口；virtual+708的`833420`写object+3194并以n*100*.001更新当前ANI。14项磁盘检查通过。它们补齐单位与部分生产者，不证明原版运行时全局值一直100，也未闭合CHR／装备最终攻速。当前C++仍100%源帧时钟。枪手独立射击／装填、useSkill事务和接触接受链在新子目录继续调查；当前尚未开放其他职业。最终全角色控制器、资格、动画、攻速、伤害及原客户端动态对照继续待完成。

## 2026-10-18 命中反馈与构建缓存（24ad历史构建）

当前build/playable EXE SHA256为 `24ad6fa1cb7a0d26c45b867d578e3be92315329e33ed71622d548520b5636e09`，`build.cmd --test`已通过核心30、外观23、技能9、怪物110、区域17及命中反馈122项，日志 `reports/combat-feel/build-test-held-turn.log`。最终串行前台进程验证全部通过，详情 `reports/combat-feel/held-turn/release-validation.json`；发布/source/window审计84项通过，见 `reports/combat-rework/verification.json`。普通洛兰＋深处41点及实际重载通过，当前轮用户存档未变；13技能双向182图＋78补帧、怪物fixture58项、六场景三分辨率完成。普通input/deep审计使用同一成功run；fixture与消息输入不代表原PC平衡或物理键盘/IME验收。中间532构建的深处结算步骤超时保留为失败，用户同时游玩导致的存档变化未回滚，原报告与旧F30证据均保留。

CHR武器hit info六字段按原subtype0/1/3/2读取；ATK的枚举可为type5，固定hit info操作数须按有序tokens读取，不能依赖空的Field.values。显式0和负值继承分开，未释义额外浮点保留。Actor局部hitStopTicks暂停动作/物理/附着特效，世界输入和CD继续，独立PO只停目标，同tick多目标取max；新保存字段兼容旧档。时间单位按ms、双方暂停分配及受击方倍率含义仍为重建。普通受击硬直350/250ms、武器攻速、普攻精确取消窗和完整公式尚未恢复。方向键和C不再把同一刀中途翻向或取消。续刀边界读held方向并置pose0；普通命中暂停中技能热键保留200ms、解冻后检查并只消费一次；三段斩暂停中转向延迟至解冻生效；多段命中间隔也随actor局部时间，死亡立即清暂停。此短缓冲是重建，不增加技能间取消资格。

崩山身体普通/末击/高级被动PO的ATK入口分离，身体frame4末击切换明确标重建，普通段最多2次、末击独立去重、总上限3次；裂波pulse使用原PO ATK，恢复其推力、升力和声音，未再复用人物下斩[none]。原邻怪三次测试的旧失败快照保留；邻怪被推离源框后不强求继续中，抓取目标三次和三个pulse检查仍成立。裂波完整末击调用仍待恢复。证据和122项行为检查见`reports/combat-feel`。

构建TEMP/TMP/TMPDIR、Clang module及可选ccache/sccache全部指向项目cache，build和打包暂存也在D盘。仅作用构建子进程，Windows全局TEMP与执行工具日志未改。C盘检查没有确认本项目残留，未删除其他软件缓存；当前C盘恢复约24GB并非本次清理所得。详见`reports/build-cache/inspection.json`。

当前原生静态入口审计见 `reports/combat-native-reverse/entry-audit.md`：六份1031 ASM与另六段碰撞范围可匹配当前EXE，新增动画切换与倍率/附属ANI传播路径已保留原字节、偏移和hash；候选虚表的鬼剑士归属、全局倍率和普攻取消/受击控制链尚未恢复，不直接把其他版本数值移入运行时。裂波亮叠层及原黑芯仍未判原版一致。

## 2026-10-18 战斗与区域整合（上一轮实现与验证）

用户本轮恢复战斗优先。当前内容仍以 `DNF1031客户端/Script.pvf` 为权威，SHA256 `d13ce454567197bb4617cad4d0e472f609a1ec5cf2256462d780547be878607d`。新增鬼剑士调用链资料属于用户说明的86版本，其 EXE/PVF hash 与当前版本不同；相同 ANI 帧可以支持补层和时序研究，不能把该版本的地址、创建坐标和控制器条件直接写成1031已证实事实。怪物资料 EXE 与当前 EXE 相同，但 PVF 不同，已逐成员核对本轮使用的字段和资源。来源、原字节、逐项差异和证据限制见 `reports/skill-chain-rework` 与 `reports/monster-rework`。

`effect_plan.hpp/cpp` 从源 OBJ 的基础／附加动画与命名 ALS 实例建立有界视觉计划，保留来源、字段 offset、原时间、层和实例身份；纯附层不重复造成伤害。地裂主波改用 OBJ 指向的 `normalwavefire.ani` 单次325ms生命周期并补刀光；十字斩补齐同父移动的普通／加色层，使用源 PTL 速度和停止时点。其创建锚点 `(85,0,82)` 仍为兼容源动画和跨版本观察支持的重建。银落补地波／尘／扩散闪光，并按高度条件生成，落地必然恢复移动。裂波补人物上挑／下斩刀光与尘、主体普通混合层；卡赞保留两层出现、地阵循环、鬼体、消失阶段。附层出现时机与未闭合的原生创建链继续保留重建标记。

旧b04实图复核发现十字斩近身大十字与前方小十字并列至收招：大十字来自人物附着slash2，源500..550ms为带23=1的最后短帧，随后950ms重复同图；slash1末帧也有1000ms占位。当前将附着slash1／2成对截止在550ms，保留全部前段源帧与事件短帧，350ms创建的移动OBJ双层／PTL保持。这是避免长占位残影的控制器重建，不把23=1解释为已证明的原生销毁命令；源ANI的1500ms原时长不改。新增回归实际检查616ms时附着层已消失而移动双层仍在。

崩山击区分身体多段、剑光和独立冲击波：正常未转职鬼剑士不具备 `[血气旺盛]` 被动63，默认不产生源说明限定的冲击波。独立诊断 fixture 可以显式给予该被动检查完整前后四层波，不能据此声称转职系统已经完成。冲击波按第二身体阶段 frame4（600ms）创建；按住时长映射源距离／高度端点、平滑跳跃轨迹和速度倍率仍是控制器重建。`MotionProfile` 使用连续速度曲线及其积分，使移动有起速、减速过程；银落高度门槛及完整原生运动公式尚未恢复。基础十字不自动追加狂战士追击，基础月光不自动追加满月第三刀。

`monster_effects.hpp/cpp` 读取 MOB 直接动作或 ACT 的 MOTION 组合，保留 BASE ANI、SUB ANI／XY、父帧时间、ALS 实例和诊断。ACT 条件、BEHAVIOR 和动态生成对象不因存在动画计划就当作已经执行。受击分开 damage1/damage2，支持的显式 hit ANI 优先，否则使用已有 common slash/knock；再次打中浮空怪物保留正向升空，ATK push 形成受碰撞限制且随 tick 衰减的 XY 速度。

浮空落地先解析自己的down绑定再替换animationPath，修复旧damage2路径误当down覆盖。落地显示down最后源姿态，停留按末帧时长限制在150..500ms；随后采用源sit过渡100..400ms，再清除显式路径恢复stay。哥布林当前为500ms／150ms。down内10000ms飞行占位不再被整段当作落地硬直，overturn保留为独立翻转动作，不能当通用getup。资源与官方术语有依据，具体落地→sit调度及上下界仍是demo控制器策略；原ANI不改，缺失绑定保留诊断。

死亡有两条实际路径：有效 `[last action]` 播放独立死亡计划；没有独立入口时，按 MOB 的共享死亡配置冻结致死姿态，白色 alpha 剪影后使用源石块 IMG、flash／smoke ANI 和 PTL 退场。已删除旧的5×2矩形切尸碎片。石块方向取目标减实际攻击来源的地面 XY 向量，上方受击可以向下方飞散；威力比例、攻击输入速度与源 push/lift 影响强度，具体公式明确为手感重建。白化60ms、迸发220ms、身体渐隐90ms来自用户提供的参考演示器，不是已恢复的原 EXE 时钟；MOB 图号／omit、省略位和 PTL 生命周期保持源值。无效显式入口或缺失资源保留诊断并安全渐隐，不给所有怪物强套哥布林死亡资源。血液、分级分支、完整 ACT 生成行为、特殊声音与独立碎块深度排序仍缺。

区域当前已接入源 TWN／MAP 门矩形驱动的赛丽亚房间↔艾尔文防线↔洛兰入口，以及洛兰／洛兰深处的 DGN 随机房间。普通副本可用候选共 **33张：洛兰14张、洛兰深处19张**，全部35份源 MAP 仍保留。`7.map` 需要左右上三门，而洛兰只有两列，源拓扑无法容纳；`5.map` 注册ID16，是无 greed 的旧救赛丽亚笼子场景，当前346份DGN的地图选择字段没有成立入口，现行教程另用610xx／252xx地图。没有伪造门或任务把两图塞入普通池。穷举27／22种合法起点／首领／边子集及原数据证据见 `reports/elvengard-rework/topology-audit.json`。

`TownExit` 保留源六元记录、目标、offset 和仅加 MAP 背景原点的 Y；TWN 缺失 `gate.map` 用显式 `(r)gate.map` 别名，原字段不改。互返落点、门过渡间隔在应用层，安全投影先扣除所有障碍，避免落在木桶／石柱内；完全没有自由地面时不伪造地面。NPC Enter 和鼠标交谈共用近距检查。德利拉在本次地下城通关且处于首领房时显示，一次性生成在安全地面，保留源 `(0,0,0)` 占位；其准确原版生成坐标和出现动画尚未证实。林纳斯／赛丽亚／德利拉任务、普通商店和修理可用；金库、邮件、梦娜／游戏使者活动和袖珍罐明确禁用，核心购买也拒绝禁用商店。

`RegionSession` 现保存死亡资源身份、相对时钟、冻结姿态与锚点、共享配置、致死输入及碎块初始条件，恢复时按当前源ID重编译计划，保留原死亡进度，不重新发出击杀／奖励事件。旧档缺少新增字段时从保存位置／动作／年龄重建；这不能恢复旧档从未保存的原始随机初始条件。资源绑定或共享配置变化时保留诊断并安全退场。

本轮最新统一 `tools/build.py --test` 已通过：`reports/core-tests.json` 为30项核心标签，`reports/skill-chain-rework/tests.json` 为9项，`reports/monster-rework/tests.json` 为110条断言，`reports/elvengard-rework/tests.json` 为17项，`reports/appearance-tests.json` 的23项保持通过。死亡跨时钟JSON重载已实际覆盖共享死亡、两类独立死亡、源计划重编译、碎块轨迹一致、移除后再次进房，以及旧档恢复和不重复发奖；新增十字附着时钟及down／sit恢复检查也通过。build／playable EXE SHA256 均为 `a3da200d96615ecffd2e3ae8b65e530a870ec768148ccbb322a94eea6657bf31`，发布清单见 `playable/manifest.json`。此前8／106计数与b04身份属于修正前构建，不冒充当前窗口验证。

修正前b04构建 `b04a33bfc1d8aaca6d9a31b0a9872574ebde95d1cd60002782814436ca74a51a` 的可见特效 fixture `reports/runs/effects-20261018T002018-329d30/effects-acceptance.json` 有15个样本、56／56项检查通过；`effects-process.json` 记录 exit0、置顶可见和用户存档未变。此路径用 `diagnosticHit` 注入已经被接受的命中，验证特效／生命周期，不是普通碰撞或实际按键验收，原PC像素一致和物理输入未据此通过。

同一b04普通窗口消息流程 `reports/runs/input-20261018T002135/acceptance.json` 为 **fail**：成功绕过木桶并清理4个房间，进入首领房时HP55，随后角色在正常战斗中死亡，未通关；用户存档未变。保留完整失败报告和截图，不能用fixture通过覆盖该失败。该构建13技能双向smoke `reports/runs/20261018T002514-367ed4b4` 已完成104.04s／6240tick／182张真SDL截图，exit0、置顶可见；独立 `visual-review.json` 实际查看13排版、9全尺寸与7原AVI，明确记录十字残影及裂波混合／采样局限，**未判视觉一致**。最新a3da正常补给／战斗流程 `input-20261018T003634` 与新版smoke尚待主任务追加结果，不预写通关或画面修复通过。

## 2026-10-18 装备／装扮 UI（上一轮发布与历史验证）

上一轮用户要求先修UI、装备和时装，该轮未改战斗控制器、公式、AI或IME。该次build/playable SHA256：`ba6f13d48c996f669c4bf2183af1d1528078a29ea6abba079ceed39827feec40`，不是本轮最终构建身份。双击`playable/play.cmd`，I打开物品栏；右键/双击穿戴或使用，装备槽右键卸下。装扮页“试穿”支持七项源装扮组合和还原，仅改局部预览，不发放、不存档、不参与属性。NPC商店进入“背包/出售”后右键出售一件。

新增`appearance.hpp/cpp`平台无关外观模型：保留EQU职业区块、两个variation、数字layer与ANI目录、隐藏规则、字段offset及完整Script。普通属性护甲与时装slot分开，同一部位替换整组分层，卸下恢复五项源default.equ。Renderer从当前ANI帧模板代入实际变体，保留原坐标/时序；选角、场景、物品预览共用模型。武器b650/c2790来自EQU，身体1000仍为明确重建，未证实原CHR数字。

新增`equipment_ui.cpp`：原版窄窗、石门、中文装扮槽、三行货币框、标题多层、背包细金边空格。原透明图像叠近黑底板，底板色/alpha是截图重建。背包8×4/装扮7×4，分类、翻页、UID不变的显示整理、黑底tooltip/同部位比较接入。精确锚点/tab宽、完整词条、负重、拖动、宠物/徽章和特殊光环/mask仍缺；创建/任务/NPC/商店整体原布局未完成，不能声称像素一致。

`tools/build.py --test`通过30项核心标签，`reports/appearance-tests.json`含23条真实源字段、变体解码、替换、穿脱、存档/未知字段及源字节不变检查。最终发布包实际窗口：800×600正常新角色12点`reports/runs/input-20261017T172346`；1280×720独立外观fixture13点`reports/runs/appearance-20261017T172450`（穿脱/左右动作外观/出售/重载）。均用户存档未变、置顶可见；Windows拒绝前台焦点，消息输入不代表物理输入。fixture来自核心测试，不代表正常取得这些装扮。汇总`reports/equipment-ui/verification.json`复核发布hash、PVF、10份UI NPK范围、三张原截图hash；实际与参考裁切对照也在该目录。源研究、重跑命令和保留的失败见CURRENT_TASK。

## 2026-10-17 C++ 版本继续交付（历史构建）

### 字体参考与掉落 overlay（本次继续）

该次历史字体构建、发布文件和实际证据汇总：`reports/font-reference/verification.json`（2026-10-18）。

`tools/audit_fonts.py` 只读记录原 `Fonts` 的 SHA-256、name/cmap/metrics/样本覆盖和四张参考图 hash；`msjh.ttf` 的内部名称是 FangSong/仿宋，`Gasinamu.ttf` 没有 Unicode cmap。NPK 名称搜索新增 `dnf_inspect --npk-paths`，查到三张 font 命名的技能特效图片，不把它们当中文字体库。

Windows 新增 `font.hpp/font.cpp::HintedFont`，使用源字体内存副本的等长私有别名，逐表校验源 glyph/hint/metrics，GDI 灰度 + TrueType grid fitting 防止小字发虚；stb 回退保留。原文件不变，不安装系统字体，销毁时移除进程注册。`runtime.json/font` 可核对实际 backend。`Renderer::textTexture` 对亮字和距离衰减黑边作 straight-alpha 合成，`textWidth`/段落换行/NPC 居中用相同后端字宽。属于参考图重建，仍非原 EXE 像素金标。

掉落的 field sprite 进入普通深度队列，名称牌和 `P` 标记进入 overlay（拾取键仍为 X），靠近时绘制黄色轮廓。对象恢复/破坏后动态 `World::blockedRects` 不再被初始列表覆盖；源 6.map 木桶回归验证单击去重/销毁放行/保存恢复/新图重置，使用测试 2 HP，未证实原桶 `[int data][5]` 或完整破坏效果。

本节记录本次整合后的实际结果，覆盖旧的三房间测试路线。`RegionCatalog` 从原始 TWN/WDM/DGN/MAP/NPC/商店/任务注册表读取数据；`DungeonRun` 按源 greed 门位生成洛兰（1）和洛兰深处（2）的连接房间。古代地下城 1500/1501 保留原始位置、等级和入场条件，但在本版本锁定。源 MAP 共 35 份，严格候选生成未抽到的 7.map 与特殊任务 5.map 记录在区域报告中，不静默伪造门位。

新增 `Progression`、`RegionSession` 和 schema 3 存档：经验、金币、任务链 101/102/103/4301、商店、维修、武器装备、药水冷却、怪物击杀去重、地面掉落原子拾取，以及迷宫房间/角色状态可恢复。存档仍保留未知字段，旧 schema 迁移和损坏 primary 的 backup 回退保留。`I` 打开背包，`L` 打开任务，靠近原 NPC 按 Enter 交互，洛兰入口显示源选关图，`M` 显示当前迷宫。

战斗新增 Actor 生命周期（死亡姿态、白色剪影、碎片退场）、受击闪白、击飞追加升空、源牛头双攻击动作、卡赞分阶段效果、十字斩第二效果层、Hop Smash 分层、匀加速/减速位移；Renderer 使用连续 ANI 采样与 `Effect.loop/animationOffset`。TargetHud 使用原紧凑目标框和延迟暗血尾。门的开关与发光使用源 OBJ 的多层 ANI，非静态换图闪烁。

Scene 从原 MAP 字节解析 `[passive object]`/`[special passive object]`，保留字段偏移、记录序号、原始记录字节与payload。平台无关的 `ObjectDefinition` 保存有序 OBJ 字段、原始字节、ANI引用和通行形状；`ObjectInstance` 保存稳定身份、独立动作时钟、受击登记、碰撞状态、随机状态及payload消费标记。对象系统由每个60Hz模拟tick推进，ANI type-15 XYZ受击框与 `[do not pass]` 移动形状分开。旧 `[int data]` 按原序保留，不将第六项假定为HP；只有显式 `[hp max]` 是源HP，木桶／箱子的现有耐久是明确标记的本地测试候选。旧int消费者、原生受击接受、PTL／声音调度与掉落／陷阱工厂仍未闭合；特殊payload只作为幂等事件记录，不调用怪物击杀奖励。

最终 build/playable SHA256：`040a5d0d34f798c46c379b1c95f599ad53eeab15ee734bc59fb108c7bcdf83e5`。`tools/build.py --test` 通过 29 项核心标签；`reports/font-tests.json` 验证 7 字号亮字芯/源表/宽度/不裁剪/源不变。发布包 UI `reports/runs/input-20261017T161457` 通过 7 个正常消息输入记录点，用户存档未变；发布包六场景三分辨率 12s `reports/runs/20261017T161531-7a7c0490` exit0/窗口置顶。代表截图已查看，Windows 焦点请求仍被拒绝，不等于物理按键/IME 验收。playable 已重新打包，README 已按当前迷宫/任务/商店操作更新。旧 142732/143547 木桶前失败和后一次 151139 通关均保留，障碍导航未宣布解决；weapon b/c 绘制层序缺权威证据，UI/地图/技能整体仍未通过。

# 实施与验证记录

下列2026-10-17记录保留原构建和失败证据；当前实现以本文首节和 CURRENT_TASK.md 为准。原 PC 控制器与全部视听细节仍在核对。

## 2026-10-17 可玩编译交付

用户确认攻击字母键失效是输入法问题，并要求暂且不论。本轮保留输入实现，未宣称修复中文 IME。独立发现并复现四种武器普通三连第二刀漏判：原身体与武器 b 层的 attack2 都没有 type 15，框在 c 层；旧代码只判 b，渲染却显示 b/c 两层。现 attackFrames 合并身体与武器 b/c 的源框，沿用每刀目标去重，不修改原 ANI 字节、框、时长或伤害参数。

旧实现四武器 × 双方向 8 例全部为 [1,0,1] 命中，失败保存在 reports/attack-freeze/basic-combo-before.json。修复后 reports/basic-combo-tests.json 全部为 [1,1,1]，各刀无重复伤害、动作结束、继续步行 51 单位；共 27 项核心检查标签通过。实际构建命令 tools/build.py --test，exit 0。

该次历史 EXE SHA256 为 0f2c1bd60bb4950577e5d87d18a27623b294977e7da6c9f486a343e14ccc313d。普通窗口消息流程 reports/runs/input-20261017T124314/acceptance.json 通过，17 记录点，实际观察 attack1/2/3、跳跃与恢复移动，三房清怪、首领、返回和保存重载，最终 HP147，技能等级/绑定重载一致，测试开关全关，用户存档未变。等级沿用上挑 Lv2、鬼斩/波动 Lv8、裂波 Lv5，其余 Lv1，不代表全 Lv1 平衡通过。

另尝试 SendInput 物理键盘路径，reports/runs/physical-20261017T124250/acceptance.json 失败于 Windows 拒绝前台焦点，未发送物理攻击键，用户存档未变。窗口仍置顶可见。不能把窗口消息验收表述为物理键盘或中文 IME 已验证。

发布目录 playable 与 build 同级，包含同 SHA256 的 EXE、两份 DLL、无需 Python 的 play.cmd、中文说明及 manifest.json；共享原 saves，仍读取完整原客户端。tools/package_playable.py 仅复制既有构建，不替代验收。发布入口实际启动检查 reports/runs/package-20261017T124501/package-check.json 通过：8 秒、exit 0、窗口置顶可见、全部发布文件哈希匹配、用户存档未变。整体验收及原 PC 视觉/控制器一致性仍未通过。

## 2026-10-17 当前修正与验证

详细投影、几何、森林网格与原UI定位见RENDERING.md；重启交接以CURRENT_TASK.md为准。原参考／旧实际／新实际四组对照在reports/visual-correction/comparisons，保持截图来源与相机差异说明。

已修signed ANI scale/crop/facing、实体/TIL/远中景不同原点、森林横16纵12碰撞范围、错误纵向相机造成的黑带、非整数缩放地砖拼接漏缝、NPC源ID/德利拉提前出现、800px HUD与选角/创建资源布局，以及smoke负方向和size_t乘法造成左靶溢出。原数据未回写；森林步长按实例推导并明确限定，完整图层/控制器/UI仍未完成。

上一轮binary SHA256：c3442b39b718cf8a885af78e4eaa6070142f7453b6fe344b39895018c434f309。24项核心标签pass；普通输入input-20261017T122331为pass、13记录点、首领HP142、重载一致、用户存档未变；六图20261017T122140-a0023035为exit0、1800tick、4614帧、前台可见，与上一轮hash相同。运行错误计数空仅为运行指标，整体验收仍未通过。

20261017T121104-70d4f1a8的104秒历史双向采样修好了左靶/左三段测试问题，182截图和状态/事件可复核；它发生在最后森林网格和拼接修正前，不冒充当前binary。两向裂波5/3/3命中、左三段三阶段完成但当前靶仅第一段命中；PC动态时序和其他武器未核。

PVF官方样例已整理为../skills/dnf-pvf-reference并实际安装。85份编目，13核心全文、4选章和Word主文本实际阅读；源hash不变。skill提供按需参考与带原行号读取工具，不把空ANI样例或未知公式说成已解决。

## 已接入范围

20 槽创建/选角、赛丽亚房间、艾尔文防线、入口选关、源 DGN 随机生成的洛兰与洛兰深处、NPC 交谈、清怪过门、首领和结算返回已接入。`s0 → 4 → b1` 仅保留为诊断 smoke 固定路线，不能代表普通角色实际生成的迷宫。33张合法普通候选与两张保留资料的边界见本文首节。

男鬼剑士 13 项基础技能具备独立阶段、身体/衣物/四类武器/附着和独立特效层、原技能 MP/CD/参数、指令、续段及保护清理。基础精通和四种武器精通的基础伤害倍率已接入；轻甲数据已读取，但没有实际属性轻甲，按件属性贡献仍未实现。详细来源/重建/未知项见 CONTROLLERS.md。

角色 schema 3 保存原技能 ID 等级、被动等级、技能键排列、真实装备／区域／任务与迷宫状态；迁移 schema 1/2，保留未知字段。正常关闭、返回选角与配置修改均保存；有效旧档备份，损坏 primary 回退 backup，双份损坏明确报错并保留。Windows 原子替换先 flush，短暂共享冲突有限重试。显示设置保存窗口尺寸而不以全屏尺寸覆盖。

原 UI 资源已用于选择/创建背景、标题、按钮、选中边框和脚下光圈、HUD、技能图标、HP/MP 液面、怪物顶部血条。选角采用六列两行、两页共 20 槽；菜单、技能窗口和部分文字/布局仍为测试实现，不能称全 UI 复刻。原 music/ambient、NPC/怪物/角色声音进入 SDL 混音，支持 Vorbis 和 WAV、循环音乐；淡入淡出、优先级和完整 ANI 声音覆盖尚未完成。

## 本轮修复

- 重现交接中的 `Missing NPK resource: `：赛利亚 dummy.til 原 IMAGE 是空路径。明确处理这份空白 TIL，保留14×30、横16／纵12世界单位的实例适配记录；其他未知空图块仍失败，并报告 MAP/TIL/IMG 上下文。复现和旧报告保存在 reports/handoff-20261017。
- 裂波斩单目标捕获、目标限定下斩、独立三次区域脉冲；空抓退出且保护清理。十字斩血十字使用独立 phase 1 参数。移动弹丸的朝向镜像 broadphase 已修正。
- 怪物离界出生投影到最近原可走单元并记事件，击退不能越过地面边界。接原倒地/起身 ANI 与恢复时长；再受击保留倒地/起身状态，攻击碰撞读取对应 ANI。
- 修复敌方弹丸遍历 effects 时打断技能删除附着效果导致的迭代器失效；延后应用敌方伤害。
- 修复普通换房清空技能冷却、切角色继承测试开关。场景变化结束动作/抓取/效果/保护并保留冷却；重新选角重置运行时。
- 修复怪物逐 tick 移动使用整数除法，导致追踪速度截成 0 的问题；新回归在首领房原网格上验证横向及纵向移动。
- 修复点击取旧鼠标位置、audio.xml 漏 AMBIENT、原始 DXT mode 5 载荷大小/后续帧对齐、短 IMG 签名越界、非 Windows GBK 静默损坏。
- --audit 实际加载六图并完成 run.json；运行、fatal、截图与资源访问均按唯一 run ID 隔离，旧失败记录保留。用户存档从验收私有目录隔离。

## 当前证据

构建使用本地 LLVM-MinGW 20261006-ucrt-x86_64 / Clang 23.1.3、CMake 4.4.4、Ninja 1.13.1、SDL2 2.32.10、zlib 1.3.1。MSVC 和其他操作系统未验证。

最近核心检查 `reports/core-tests.json` 为 pass：五种渲染频率 30/60/120/144/240 下相同输入得到同一结果；5 秒停顿补 300 tick；13 技能结束/续段/保护；原身体与武器框；裂波斩捕获/下斩/三脉冲与空抓；血十字独立伤害；霸体受伤/无敌拒伤/死亡清理；敌方弹丸中断；首领房 AI 移动；换场冷却与选角测试开关；schema1 迁移/配置/备份；空白 TIL 与 DXT1/3/5 手工金标、部分块、帧对齐和截断拒绝。

六图只读 audit：`reports/runs/20261017T105957-3ca0b4a3`，exit 0，地图宽度 896/1568/896/1120/1344/1568。该结果验证加载与可走数据，不能替代截图和实际走门。

早期正常流程失败均保留：input-20261017T100742 / 101207 / 101421 死亡或首领超时；101052 是 Windows 报告共享冲突；105957 是自动操作在门口先纵向对齐导致超时；110327 是 live.json 只读采样暂时共享冲突。之后修复观察器重试并发现/修复 AI 整数除法。失败记录不能覆盖成成功。

修正前历史运行（下列视觉结论已撤回，不代表当前binary）：

- `reports/runs/20261017T110824-69262cf4`：flow-smoke **300.0119741 秒**、18000 tick、47836 渲染帧、exit0；median 6.060 ms、p95 6.365 ms、max 190.094 ms，effects峰值3，资源/绘制/声音错误及未解声音ID均空。实际六场景和三种分辨率截图已查看。实际资源范围 hash 452项。
- `reports/runs/input-20261017T110701`：普通流程 pass、13记录点、首领清理HP147、保存重载实际技能等级/绑定相同、测试开关全关、用户存档未变；其条件和等级配置见下节。
- `reports/runs/20261017T111344-1053a6dd`：skill-smoke **104.007239秒**、6240 tick、16225帧、exit0；median 6.060 ms、p95 6.389 ms、max61.782 ms；错误和未解声音ID均空，实际资源hash326项。13技能两方向7时点共182张；已查看13张排版及部分全尺寸原帧，观察记在visual-review.json。采样画面未见黑底特效块或跨技能卡赞残留；左三段斩后段抵达世界/视口边界，人物有裁切，未据此接受完整无障碍左向位移。仅默认短剑的视觉采样，其他武器尚需动态验收。
- `reports/runs/20261017T111845-e6fc8c43`：4秒验证新测试启动器的前台可见行为，exit0、visible_on_top=true；Windows拒绝直接键盘焦点切换，测试窗口仍置顶显示。普通交互不强制置顶。

汇总与当前可执行文件SHA256见 `reports/verification-20261017.json`。

## 验证模式边界

普通输入脚本 verify_flow.py 使用 Windows 窗口按键/鼠标消息进入真实 SDL 窗口，私有存档，live.json 只读观察。可用技能等级调整按钮，但不写游戏状态、不传送、不强制死亡、不恢复 HP/MP/CD；明确记录其技能配置，不能当作物理设备人工游玩或全 Lv1 平衡验收。

flow-smoke 每 30 秒直接轮换六场景并切换 800×600、1280×720、1024×768，恢复 HP/MP、免 CD、定时放靶与技能，首领场景开 AI。用于连续运行、资源、绘制与分辨率覆盖，不验证真实路线输入。

skill-smoke 每技能 4 秒、7 个时点，104 秒覆盖 13 项左右两向；每项前清理卡赞等残留，格挡保持快捷键。直接激活技能且使用固定靶和测试 HP/MP/CD，能观察动态帧，不能证明原 PC 控制器完全一致。

## 来源和剩余差异

每次 resources.json 是实际访问集合；tools/export_runtime_manifest.py 另计算源 PVF/NPK 字节范围 SHA256。tools/export_evidence.py 已保存 101 份解密源、token/fields/model/hash，全数匹配研究库；74 份 REP 保留但按键/时间仍未知。未制作完整依赖闭包和客户端子集，仍需完整原客户端及散装音乐/字体/audio.xml。

初始武器发放、250属性除数、怪物demo HP、受击恢复与AI仍有显式重建。防御／暴击／元素／完整装备与轻甲贡献／异常／成长未完成；部分技能无原框处使用重建，复杂混合、深度遮挡和声音时序仍待核。当前区域的指定任务链、普通商店／修理、掉落和洛兰／洛兰深处源迷宫已经接入，不能再写成整体未实现；四转职／觉醒／TP、全任务／经济系统、活动／邮件／仓库和整套原版UI仍未完成。

启动入口为工作区 play-native.cmd 或工程 play.cmd。F8 输出可反馈的状态/输入/事件/截图包。后续移植约定见 PORTING.md。

等级消耗边界：当前 MP 使用 SKL `[consume MP]` 的首项，未实现 min/max 区间随技能等级增长的解释；技能测试面板改等级会改变 level info 伤害参数，但 MP 仍为基础值。正常流程通过属于此 demo 消耗规则，不能当作原版高等级消耗/平衡验证。冷却读取首项，当前这批技能源冷却区间两端相同。
> 2026-10-18 续做记录：当前发布EXE仍为a3da。普通`--deep`尚未通过，旧失败输入run为`input-20261018T004411`，测试器在障碍前2px中间点持续无位移按右。`verify_flow.py`新增安全的微小横向段转向候选修正，运行验证未完成。磁盘满(OS112)阻止进程启动，自动审批另报403；没有成功清理文件或运行新构建/测试。详情与本轮真实帧复核范围见`../reports/combat-rework/continuation-20261018-environment-block.json`。

> 最新续做结果（优先于上方过程阻塞记录）：a3da普通`--deep`在`reports/runs/input-20261018T011529`通过39点。洛兰0→2→4含原卡点同图8.map，交任务102后自然Lv3进入深处3→4→1→2，最终Lv4/XP8150/HP122/MP76。两副本德利拉商店/修理、返城和真实重载通过，用户存档未变。只修改测试器微小中间点导航与8次无位移诊断，没有C++改动/重编。纯导航几何和语法通过；不代表物理键盘/IME或原版战斗公式一致。C盘零空间使最终审计仍间歇无法启动。


# 当前实施：资源链、控制器持帧与实际效果消费者（2026-10-20）

本轮验证/备份身份见`reports/attack-timing-offset-20261020/NODE-PROGRESS.md`，该报告未完成前不可把实现计为新候选通过。源DELAY仍为毫秒：男女枪普攻含末尾9999/10000ms保持姿态；女枪RandomShootWait为50ms，RandomShoot含四个15000ms保持帧/总62400ms。动作控制器推进与ANI时间数据分离，不能全局裁剪或把SKL预加载当实际生成命令。实验职业消费已有自身普攻取消表；枪手抬枪末帧进入门控按1031局部原生证据修复，完整射击/装填原生链仍另行恢复。

女枪控制器时间轴独立保留source/runtime delays、原帧身份和推断依据，控制阶段与实体脉冲使用同一未暂停毫秒期限；有限非控制阶段沿用所选clock/攻速。已选择技能及当前CHR阶段才能发布其技能附层，资源帧/图像/偏移/loop从PVF读取；必要的编译控制器附层绑定集中记录推断，不能把这些绑定宣称为源ALS。已有body/EQU/LAY及显式技能附层的真实ALS经不可见宿主借用当前根快照，避免第二次推进人物。独立效果与附着层的生命周期、判定资格及同名替换分别管理。

