# 当前：C++ 架构拆分大纲（2026-11-02）

用户决定继续完善 C++，先整理架构，再在统一框架下填充功能；最新补充强调面向对象、封装、组合、接口和对象生命周期，同时严格控制性能。

本轮产物：[架构拆分大纲](docs/ARCHITECTURE-REFACTOR-OUTLINE.md)。已核对现有源码与补充PVF资料，明确人物身体/装备/时装、职业普攻/技能、怪物显示/AI、地图、弹窗、HUD及公共动作/战斗/实体/资源/业务/持久化边界。性能候选仅为静态定位，未称实测瓶颈。

**本轮只更新架构文档；没有搬动运行代码、构建、运行游戏或发布候选。** 后续实施按大纲A0–A6渐进推进，优先保留同输入行为和存档合同。最新已验证C++体验仍是Mage457；equipment458/459输入节点的堆异常仍未解决，旧失败/恢复证据全部保留。Godot体验线维持暂停。

下方为原节点状态，不能把历史“任务继续”或“已暂停”当作本轮已进行重构的证明。

<!-- equipment458-live-status -->
# 当前装备资格与正常学习预算节点

阶段：`paused_after_original_o3_debugger1`；会话：`None`。预计459份编译输入、181份完整报告，独立构建`cache/seven-job-equipment458-build`。最新已验证体验仍按实际完成记录：`checkpoints/20261020T224815926748Z-mage-upper457`；统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

**已按用户要求暂停。** 当前一轮已结束；不再启动构建、测试、备份发布或后续节点。恢复先读本节点PAUSE-SUMMARY-20261021.md和PAUSE-RECEIPT.json，等待用户继续。

女法师天击457已完成1142成员源码/产物/证据备份，两遍哈希零差异。当前仅继续装备单ID技能资格、正常SP/TP预算及目标私有恢复/GSD预检；分支赠送与真实30200条件眩晕不混入完成。女格斗普通副本死亡失败保留，七职业全普通副本/完整技能和最终十职业beta尚未完成。原资料、正常存档和历史候选保护，构建/运行/备份串行；前台画面、听音、手感与原版动态比较待用户。

恢复读`dnf-native-demo/reports/seven-job-world-20261020/equipment458-integration/RUNNING-STATE.json`、本节点PROGRESS与实际日志。先poll实际会话，不重跑已结束attempt，不删除他人锁或覆盖运行产物。下方旧记录为历史。
<!-- /equipment458-live-status -->

<!-- mage457-live-status -->
# 当前女法师天击节点（以实际收据为准）

阶段：`mage457_complete`；会话：`None`。候选输入预期457份、完整报告180份，构建目录`cache/seven-job-mage-upper457-build`。最新已验证体验：`checkpoints/20261020T224815926748Z-mage-upper457`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。

女格斗原ordinary1死亡及观察复现完整保留；该失败不算正常游玩通过。Mage是独立功能验证，七职业全部普通副本、完整技能及最终十职业beta仍未完成。所有新构建、测试、审计和备份串行，原资料、用户存档及历史候选保护；前台画面、听音、手感与原版动态比较由用户执行。

恢复先读`dnf-native-demo/reports/seven-job-world-20261020/mage-upper457-integration/RUNNING-STATE.json`与节点PROGRESS、实际日志；不重启已结束attempt，不删除他人锁。下方保留历史记录。
<!-- /mage457-live-status -->

# 当前节点：女格斗上勾拳自动通过并备份，继续职业/普通副本

fighter-upper454完整核心/音频/隐藏UI、同主EXE来源/content/dummy及源码产物证据备份通过，EXE `8c37d12288b0f6dbbe6a0731140b2dbd4581e587eed9bcf9f6b7df1280665249`，454输入/179报告，ACT62、九声音18PCM。自身初始5/正常SP20/MP-CD/默认Z/双音/真实EQU与怪物反应及恢复已接；TP163、拳套required34与原生caller仍有具体缺口。Priest e6b57/ready5完整三段fixture链及实际失败与应用证据、movement fixture3及实例clock/frameStartMs和前序Water/Knee/AI/奖励保留。Fighter a182→8b1a计时采样及真实30200错误成功前提两次窄修、原preflight1/2失败/独立诊断和父应用收据完整保留，原740..774未改。四类World释放通过；拳套仅严格原子拒绝与独立源几何，不称五类实跑。本轮还保full1真实失败、精确SkillKey休眠preview测试修正和独审/父应用；normal/runtime1与dormant10不变，完整normal bridge新增第五专项。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-node/PROGRESS.md，备份 `20261020T211925962396Z-fighter-upper454`。七职业全副本/最终十职业未完成，原资料/存档/历史候选保护，继续。

# 当前恢复点：454预览索引断言已独审窄修，等待新正式验证（2026-10-21）

最新已验证体验仍453：`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，统一入口`dnf-native-demo/Play-Latest-Verified.cmd`。454尚未完成，不更新latest。

compile3/preflight3通过后，full attempt1/session24920真实exit1于旧normal bridge预览数组[0]断言。父保原断言诊断session28360实测：目标{1,6}正常1、预览10，数组首项实际为新增免费{1,5}/1；运行时恢复正确。原full失败、原C++再次exit1、观测与完整闭包保留。

Skill封31成员最窄提案（manifest4d4279aa，test46387ffc），UI独审6成员b2f08abb通过；父独立编译并运行整份normal bridge提案session88480退出0，RESULT652ac822。随后父按精确diff合入，`legacy-preview-APPLICATION.json`保真实pass/独审/旧失败身份，其余453输入逐hash不变。仅按完整SkillKey唯一找预览binding；normal mode/runtime1/dormant10及其他76检查不变，运行时不改。当前无运行会话，UI在准备全新ready5，追加第5项完整normal bridge专项，保原四项、454输入/179报告与全部来源/事务门。

恢复优先读本节点RUNNING-STATE、PROGRESS和真实日志，不重跑历史attempt/旧ready4验证新源，不删除活动锁。下一步ready5父核→compile4→preflight4五专项→full attempt2→同EXE/源码产物证据二遍备份→普通job1/DGN1/seed1。ordinary路径工具须在新禁用successor绑定实际ready5 schema，不改旧封包。OBJ0显式manifest交叉门overlay、装备预算和分支赠送successor均封未合，女法天击在独占staging实现；不并行构建运行。原资源/历史候选/正常存档保护，全部D盘；七职业全部普通副本/完整技能及最终十职业仍未完成，持续实施。

# 当前恢复点：女格斗454编译通过，专项计时采样窄修已应用（2026-10-21）

453已完整验证备份，最新体验为`dnf-native-demo/checkpoints/20261020T183257823234Z-priest-upper453/runtime/play.cmd`，1537成员二遍零差异；普通圣职DGN1/seed1四房/21击杀拾取/20技能及结算恢复返城通过132检查。454 compile1已通过；preflight1真实168检查末条时长失败，clock-diagnostic1保原断言实测源body740ms在按键后750ms完成，旧测试漏计首tick16ms而得到734ms。独审只移动started到按键前，原740..774和全部断言不变；父已精确应用test8b1a，其余453编译输入不变。当前无运行会话，等待ready2工具绑定实际失败/独审/应用后compile2和preflight2，再full/同EXE/二遍备份，latest保持453。恢复读`dnf-native-demo/reports/seven-job-world-20261020/fighter-upper454-integration/PROGRESS.md`、RUNNING-STATE及真实日志；不复用旧ready1假称新闭包，不并行构建运行/改正式源。原资料/历史候选/正常存档保护，七职全普通副本和完整技能/最终十职未完成，继续。下方running为历史。

# 当前恢复点：女格斗上勾拳454已合入，完整重编中（2026-10-21）

圣职453已完成核心/音频51/隐藏UI39、同EXE审计和1537成员二遍备份，最新体验入口指向`checkpoints/20261020T183257823234Z-priest-upper453`。随后普通job4/DGN1/seed1真实四房、21击杀/拾取、20正常技能、结算/重载/赛丽亚返城，132检查通过。Fighter12目标独审及父级preview后窄合；当前454输入冻结，compile1/session9555串行重编。恢复先读`reports/seven-job-world-20261020/fighter-upper454-integration/PROGRESS.md`、RUNNING-STATE和实际日志。尚未新技能运行验收，后续专项/完整回归/同EXE/源码产物备份；latest保持453。禁止并行构建运行/改冻结输入，不维护独立播放器，原资料/历史候选/正常存档保护，全七职全普通副本与最终十职beta未完成。下方运行状态为历史。

# 当前节点：圣职者空斩打自动通过并备份，继续职业/普通副本（2026-10-20）

priest-upper完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `924ff1f85d65154c1f87ff200fffdd1e64ca97de143fed871d31ddc66ece8490`，453输入/178报告。正常初始1/SP20升2/真实EQU攻击框/精确frame2效果出生/240ms源寿命及伤害/ACT40/保存恢复已接；TP210与Avenger123仍未实现，旧已学收费前诊断保ledger，WillDriver13 active gate留后续。前序Water/Knee/AI/拾取/学习/奖励保留。范围、推断、用户步骤和恢复见dnf-native-demo/reports/seven-job-world-20261020/priest-upper453-node/PROGRESS.md，备份 `20261020T183257823234Z-priest-upper453`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续。

# 当前恢复点：圣职453完整回归失败，修正测试准备顺序（2026-10-21）

fixture3已独审精确应用e6b57，compile4与ready5/preflight3全部通过（Priest390/ACT40/movement6/audio51）。当前完整full attempt2在session23092串行运行，453输入冻结；原session85646/full attempt1真实exit1及preflight1/2失败全部保留。full退出后audit/finish、二遍备份再更新latest，当前latest仍movement452。恢复以priest-upper453-integration/PROGRESS.md及RUNNING-STATE.json为准，下方旧running记录为历史。

movement452已验证备份，最新入口仍是 `checkpoints/20261020T163114547687Z-movement-reaction`。453的fixture2经独审精确应用（test17c4）并compile3通过，完整回归attempt1当前session85646运行；ready4已封并复核，453输入冻结。回归结束后串行preflight3、同EXE审计和源码产物二遍备份。恢复先读 `reports/seven-job-world-20261020/priest-upper453-integration/PROGRESS.md` 与 `RUNNING-STATE.json`，下方running记录是历史。Fighter454条件提案尚未合并，独审已发现仅测试故障注入字段需窄修，当前disabled工具不可启用。普通453七职业DGN1 wrapper已封待运行，不是通关结果；保持来源、存档、历史候选保护，继续。

# 正在实施：圣职空斩打453完整重编（2026-10-21）

最近已验证入口Play-Latest-Verified.cmd指向checkpoints/20261020T163114547687Z-movement-reaction，1207成员二遍零差异。正式Upper15目标精确合入，453输入冻结，compile1 session6238正在cache/seven-job-priest-upper453-build完整重编；恢复先读reports/seven-job-world-20261020/priest-upper453-integration/PROGRESS.md、RUNNING-STATE.json及实际日志。新Upper尚未通过专项/完整回归/同EXE/备份，不可当已交付；继续串行验证后再女格斗Upper。原资料、候选及正常存档保护，七职业全普通副本及最终十职业beta未完成。

# 当前节点：普通受击方向输入恢复自动通过并备份（2026-10-20）

movement-reaction完整核心/音频/隐藏UI及同主EXE来源/content/3秒dummy通过，EXE `00ee62e405344c3879ce18461cf844ee293aaa70f7aa9a7ffc2a2f2c2844934e`，452输入/177报告。原test修前真实失败560→560，revision2/3仅修城镇Knee配置及源来袭准备，green1/2失败和诊断保留；最终两个clock六样本验证普通受击恢复方向、KEYUP/失焦双击/换房及正常Knee MP/CD无重放，不称测试字节未变。仅活人显式中断保四方向，其余动作清理，source/数值不改，策略保持推断；status/lethal无新增直接覆盖，普通副本额外结果不泛化。备份 `20261020T163114547687Z-movement-reaction`，详见dnf-native-demo/reports/seven-job-world-20261020/movement-reaction-node/PROGRESS.md。七职业全普通副本及最终十职业未完成，特殊机制延期；后续Priest须实际452新基线窄重基。原资源/历史候选/正常存档保护，继续。

# 正在验证：受击输入修复green3通过，完整回归中（2026-10-20）

compile4通过，正式452输入冻结；green3两clock/六samples通过普通受击后持续方向恢复、KEYUP、动作清理、focus/scene与正常Knee MP/CD。fixture2城镇配置、fixture3来源windup时机的两次测试准备窄修及原失败全部保留，运行时未追加修改。full attempt1正在session54296运行；先读reports/seven-job-world-20261020/movement-reaction-integration/PROGRESS.md、RUNNING-STATE.json及实际build-full-attempt1日志恢复。普通452多房间、同主EXE审计和节点备份尚未完成，Play-Latest-Verified.cmd仍watercannon-normal。禁止并行构建/运行与修改冻结来源；后续完成验证和备份再重基圣职节点。七职业全部普通副本/完整技能及最终十职业beta仍未完成，特殊机制延期。下文compile1状态属历史。

# 正在实施：普通受击后方向输入丢失修复（2026-10-20）

451基线七职业DGN1及DGN2鬼剑士实跑已结束，真实结果在reports/seven-job-world-20261020/ordinary-world-progress。DGN1鬼剑士与DGN2鬼剑士33击杀/33拾取通过；其余职业出现受击后原地死亡或驱动盲X赶路超时，不能称全七职通过。旧451用冻结真实World测试已复现受击后一直持右但X=560不移动。当前8目标精确窄合为452输入，正在cache/seven-job-movement-reaction-build完整重编，compile1 session16976；先读 reports/seven-job-world-20261020/movement-reaction-integration/PROGRESS.md、RUNNING-STATE.json及实际build日志恢复。尚未验收新候选，latest仍watercannon-normal备份。禁止并行构建或修改冻结输入；按同test绿测、full、普通实跑、同EXE审计和源码/产物二遍备份推进。Priest需重基而非直接跑旧451工具；原资源/正常存档/历史候选保护，任务继续。

# 正在执行：七职业正常多房间与洛兰深处实跑（2026-10-20）

正常魔法冰球节点已完整验证并备份至 `checkpoints/20261020T145242215868Z-watercannon-normal`，451输入/176报告、核心/48音频/39隐藏UI及同EXE审计通过，1216备份文件二遍零差异，EXE `e183644cb660b231ff7205ba7cb2b36d4cd451ca2b3010c7bbc453c355d89ffc`。最新体验入口 `Play-Latest-Verified.cmd`。当前保持451源码冻结，串行运行七职业DGN1/seed1，再DGN2；实时状态见 `reports/seven-job-world-20261020/ordinary-world-progress/`，真实尝试日志在 `ordinary-normal-water-multiroom-integration/preflight/`。job0/seed1已通过四房/21击杀/21拾取/5正常技能、同代恢复及源赛丽亚返城；不称全图或全技能。圣职空斩打15目标只在sealed staging，未合入/编译；女格斗初始上勾拳只做来源合同。禁止并行构建或修改运行闭包；原资源/正常存档/历史候选保护，所有输出D盘。继续执行，特殊机制延期，七职业全普通副本和最终十职业未完成。

# 当前节点：男法魔法冰球正常基础26自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon-normal完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e183644cb660b231ff7205ba7cb2b36d4cd451ca2b3010c7bbc453c355d89ffc`，451输入/176报告。正常26已接来源初始1/SP15升2/learned槽/一次MP-CD/真实flight-impact/受击/GSD/保存恢复；TP236与元素链51仍false，已学旧被动具体挡在收费前且保账本。前序Water、正常Knee/AI/active/拾取/学习/保存奖励保留；实际边界、beta推断与用户步骤见dnf-native-demo/reports/seven-job-world-20261020/watercannon-normal-node/PROGRESS.md，备份 `20261020T145242215868Z-watercannon-normal`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 正在实施：魔法冰球正常学习接入（2026-10-20）

最新完整验证体验备份为 checkpoints/20261020T141256959979Z-watercannon，主EXE e059c892d4c2182911670581c0390ddaa457d37e358080ed8753a97b5172d3e8；450输入/175报告、核心/48音频/隐藏UI、同EXE审计及1313备份文件二遍零差异。之后正常基础26六目标已通过revision2精确窄合，正式451输入冻结；当前阶段 backup_attempt1_preparing，session None，尚未验收正常节点。正常source初始1/SP15升2/learned槽/完整视觉树预检及旧已学236/51收费前诊断进入实际验证；TP236与元素链51仍不接纳。封包工具误排nested MANIFEST的只读失败及最窄修正保留，未影响游戏源码或旧备份。恢复读 reports/seven-job-world-20261020/watercannon-normal-integration/PROGRESS.md 与 RUNNING-STATE.json。禁止并行构建或改共享输入，原资源/用户正常存档/历史候选保护。七职业全副本及最终十职业未完成，特殊机制延期，任务继续。

# 当前节点：男法魔法冰球预览链自动通过并备份，继续职业/普通副本（2026-10-20）

watercannon完整核心/音频/隐藏UI及同主EXE来源/content/dummy通过，EXE `e059c892d4c2182911670581c0390ddaa457d37e358080ed8753a97b5172d3e8`，450输入/175报告。已接自身来源fixed body→moving PO→accepted nonmiss→impact/typed排除与独立ALS树；正常26/TP236/元素链51仍false。保留正常Knee/AI/active/拾取/学习/保存奖励，新增实际ACT16场景、六声音12项PCM及两clock等检查。beta回调/缩放/受击等推断与待用户体验见dnf-native-demo/reports/seven-job-world-20261020/watercannon-node/PROGRESS.md，备份 `20261020T141256959979Z-watercannon`。七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护，继续真实多房和逐技能。

# 正在实施：魔法冰球受击修正后的实际验证（2026-10-20）

最近已验证体验版本仍为 checkpoints/20261020T124936192931Z-normal-combat，入口 Play-Latest-Verified.cmd。洛兰真实正常四房 preflight4 已通过（job0/seed1，21击杀/21拾取，5次已学skill46真实扣费，成长Lv2，奖励/同代重载/login publisher）。本轮魔法冰球 targeted/preflight1 失败，实际暴露人物body与独立PO攻击归属检查冲突；窄修保留独立PO拥有ATK、人物body无ATK契约，runtime1及原失败完整保留。compile4全部目标通过，450编译输入冻结，新主EXE e059c892d4c2182911670581c0390ddaa457d37e358080ed8753a97b5172d3e8；十组专项及六音源已通过，完整回归正在执行，状态 full_attempt1_running，session 64212。revision4工具精确三overlay已核验，继续完整回归、同EXE审计和完整节点备份，尚未更新latest。正常26/236/51尚未接纳；不称全七职业/全副本完成。恢复读 reports/seven-job-world-20261020/watercannon-integration/PROGRESS.md 与 RUNNING-STATE.json。原资料、正常存档及历史候选保护。

# 正在实施：正常洛兰多房检查，已发布normal-combat（2026-10-20）

最近验证备份checkpoints/20261020T124936192931Z-normal-combat，EXE1f29cfe5ad188dc3565bcea5169ccbd183d53927ef7217345fbd7222e32e35d8，448输入/174JSON、核心/39音频/39隐藏UI及同EXE三审计通过，1351备份文件零哈希差异。D盘备份不足已对派生测试输出无损压缩并续复制，同一备份已完成，未删历史/原资料/存档。当前ordinary-multiroom preflight1已编译但driver class方括号错配构造失败，未到战斗；原失败保留，独占revision2修driver，不改正式语义。恢复读reports/seven-job-world-20261020/ordinary-multiroom-integration/PROGRESS.md与RUNNING-STATE.json；继续真实输入清房/掉落/奖励/保存，然后男法WaterCannon。七职业全副本/最终十职业未完成，特殊机制延期。

# 当前节点：正常怪物Event与男枪膝撞自动通过并备份，继续职业/普通副本（2026-10-20）

normal-combat完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `1f29cfe5ad188dc3565bcea5169ccbd183d53927ef7217345fbd7222e32e35d8`，448输入/174报告。普通source-think自动安装现有Event子集，显式/F7/恢复binding/pending/window/RNG保留；实际Event到Jena ACT及MAP factory通过，不称完整AI。男枪2/4正常初始/SP/槽/Z/MP/CD/伤害/ACT22/装备/GSD/恢复已接，stable Audio0与三份OGG独立dummy解码通过；TP168正常仍false，原生caller/保护/公式等保持推断。金币等前节点修复保留，范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/normal-combat-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续真实多房洛兰和男法WaterCannon；七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 正在实施：普通Event与膝撞正常接纳，完整回归中（2026-10-20）

最近验证备份为checkpoints/20261020T121835179429Z-active-source-reaction，EXE75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e。随后normal AI7与Knee13文件已窄合，compile-only与六组专项通过，448输入冻结运行normal-combat full attempt2；尚未新交付。先读reports/seven-job-world-20261020/normal-combat-integration/PROGRESS.md与RUNNING-STATE.json恢复，禁止测试中改源码或并行构建。原资料/存档/历史候选保护，自动仅hidden/dummy；任务继续。

# 当前节点：地面来源技能活跃ACT受击自动通过并备份，继续技能/普通AI（2026-10-20）

active-source-reaction完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `75f227d91d0268e4247ba650f39550b423161c57a5fbd4ae6b1b61807a4fe94e`，446输入/173报告。精确地面单BodyAttack的霸体/普通/控制/死亡和prepared清理已接；两个clock共22场景通过，MISS/fault不取消，多owner晚故障保留前一成功。MP/CD/KEYUP/序号保持；实体/channel/空中仍具体挡。男枪膝撞正常implemented=false，新生产技能0，TP/声音/接纳继续。金币等前节点修复保留。范围/推断/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/active-source-reaction-node/PROGRESS.md，备份查checkpoints/LATEST.md。全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：基本副本奖励与保存恢复自动通过并备份，继续技能/普通AI（2026-10-20）

basic-dungeon-flow完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `9fc5e798d0df028f92f50181a6cf09324c5798289bdfaa67a5f3509b6382ff09`，446输入/173报告。已接独立击杀奖励游标、intent→私有准备→final持久化→Results/房门、实际writer证明/normal-beta显式handover、KEYDOWN/UP冻结与tick后点击门、主入口共享beta退出确认Reset及可重试保存。正常学习/升级/分支隔离组合、四GSD故障和beta退出故障已执行。金币及同物品图标回退保留。fixture不等于全main/全副本按键游玩，具体七类未覆盖边界/来源/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/basic-dungeon-flow-node/PROGRESS.md。备份查checkpoints/LATEST.md。继续地面source-body活跃ACT受击、膝撞正常接纳和普通Event.ai；全七职业全副本/最终十职业未完成，特殊机制延期。原资料/存档/历史候选保护。

# 当前节点：男枪膝撞来源预览自动通过并备份，继续基本副本（2026-10-20）

gunner-knee完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过，EXE `7c0b508feb3227a2c892e0f5620367a9b4b33a945e05cc407397313f5f035aad`，434输入/160报告。own job2/skill4的SKL/CHR motion11/ATK1、原750ms身体/装备判定、速度/独立攻击/浮空和窄特效已接隔离预览；特效caller/层、攻速/浮空和当前帧type13霸体保持版本推断。TP/取消/语音/活跃ACT受击/正常接纳未闭合，正常implemented=false，新完整生产技能0。金币和同物品图标回退等前节点修复保留。范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-knee-node/PROGRESS.md，备份查checkpoints/LATEST.md。继续窄合基本副本A/B/C/D及保存期间KEYUP冻结缺口；全七职业全副本/最终十职业未完成，特殊机制延期，原资料/存档/历史候选保护。

# 当前节点：正常学习/快捷栏/运行时桥自动通过，继续技能与基本副本（2026-10-20）

normal-learning完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `2562c82999bfd1bc7f39ee64a2b9eee5ce463f594dfdc1cd799f33f2366cf3cc`，433输入/159报告。K/NPC正常学习→SkillKey持久购买→有效已学F6快捷栏→原runtime单次MP/CD→同代重载/GSD已接已有消费者；normal/test/manual配置隔离，旧raw休眠，F9显式preview，身体/装备模板与目标外观保存前预检。仅四个own source动作及女枪19主动/12被动正常接纳，其他行保留具体禁用，新生产控制器0。金币等前节点修复保留。具体范围、推断和用户步骤见dnf-native-demo/reports/seven-job-world-20261020/normal-learning-node/PROGRESS.md，备份目录查主工程checkpoints/LATEST.md。下一步膝撞、基本副本A+B及writer/恢复诊断修正；全七职业全副本和最终十职业beta未完成，特殊机制延期。任务继续，原客户端/资料/正常存档/历史候选保护。

# 当前节点：普通/觉醒技能资格分表自动通过，继续正常学习桥（2026-10-20）

second-qualification完整核心/音频/隐藏SDL及同主EXE来源/content/dummy通过。EXE `12b91631fba0a521c9d333a5768d577cdfbd979db3cf47012fb943eeb62fb22c`，430输入/156报告。修复合法空普通fitness和仅有独立觉醒fitness来源的资格早退；当前1734注册行形状已核查，女枪四觉醒/女法光电冰墙及实际GSD rebase消费者同闭包验证。分表选择/两列/回退仍标推断，无新生产控制器或完整正常学习声称。金币等上一节点修复保留，来源/边界/用户步骤见dnf-native-demo/reports/seven-job-world-20261020/second-qualification-node/PROGRESS.md，源码/产物/证据备份查主工程checkpoints/LATEST.md。下一步完整非鬼剑士正常SP学习UI/事务/binding/恢复桥，基本副本A+B仍私有待合、特殊机制延期。原客户端/资料/正常存档/历史候选保护，任务继续。

# 当前节点：掉落/拾取与交互界面自动通过，继续七职业/全副本（2026-10-20）

presentation-pickup完整核心/音频/隐藏SDL、同主EXE profile/content和dummy通过。EXE `c0d35235cdb2d64ba688f56276ac5097994b65b92396aba00f90fd268154995e`，429输入/155报告。金币独立绘制、同物品缺图回退、材料锚点、七职业GetItem与ACT提交打断、NPC X/点击、大地图移动、源加载图/标题、Boss矩形末管红、卡片四档/双击与GSD源等级直接转职一觉已整合。实际范围、推断和待用户体验见dnf-native-demo/reports/seven-job-world-20261020/presentation-pickup-node/PROGRESS.md；节点源码/产物/证据备份查checkpoints/LATEST.md。女法龙牙与七职业中立地面受击已同闭包重编。七职业完整技能/正常非鬼剑士SP学习/全副本基本结算仍未完成，普通Event.ai自动安装和难度属性倍率具体缺口保留，特殊机制延期。下一步继续实质技能和基本副本，原资料/正常存档/历史候选保护有效。

# 当前节点：复仇之刺/下段踢自动通过并备份，继续技能与交互界面（2026-10-20）

body-skills完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过。EXE `e86bd50de645720698a93294d20a550e4d156a64b2e08cef98d07f4fa3954133`，409输入/145报告。job4/116复仇之刺与job1/6下段踢实际消费者已合入，源链/推断/正常学习缺口及用户步骤见dnf-native-demo/reports/seven-job-world-20261020/body-skills-node/PROGRESS.md。逐节点源码/产物/证据备份见checkpoints/LATEST.md。接着窄合女法龙牙、prepared七职业地面受击、GSD直接身份与新版界面/拾取；特殊机制延期，全副本基本流程与七职业完整内容仍未完成。最新Boss矩形多色末管红、卡片难度/双击、源加载图/标题、大地图移动、对话按X/点击继续、拾取动作/高亮/金币图像正在独立节点中，尚未包含。原资源/正常存档/历史候选保护，任务继续。

# 当前节点：ACT判定、伤害窗口与同代恢复自动通过，继续职业技能（2026-10-20）

act-window完整核心/音频/隐藏UI、同EXE profile/content及SDL dummy通过；EXE `fd6c1d415122c917d001b5656c314ac6d792067bb8482cd4f906b58a59c183e5`，407输入/143报告。真实monster→中立地面鬼剑士根ANI接触、源伤害/去重/事务回滚，与三个player→monster伤害生产者窗口/Event.ai pending/typed房间同代恢复已串行整合。具体来源、推断、已支持范围、用户步骤与恢复查dnf-native-demo/reports/seven-job-world-20261020/act-window-node/PROGRESS.md，节点源码/编译产物备份查主工程checkpoints/LATEST.md。实验职业/动作中断、空中/恢复/抓取、DOT/非玩家来源仍未闭合；不把诊断fixture计作完整怪物。用户本轮只需全部副本基本进出/战斗/通关/结算/返城，特殊机制延期；转职觉醒来源等级达标后GSD直接设置、无任务材料并控制学习，详见PLAYABLE-SCOPE-UPDATE.md。GSD尚待实现，下一步圣职复仇之刺/女格斗下段踢、其余职业与prepared反应、GSD及普通副本。原资源/历史候选/正常存档继续保护，任务持续。

# 最新用户范围：全部副本基本流程，等级达标后GSD直接转职觉醒（2026-10-20）

用户明确本轮正常游玩只需所有副本能进入、基本战斗/清图/通关/结算/返城，不要求全部特殊机制；转职/觉醒达到来源等级后在GSD直接设置，无任务材料流程，按新身份/觉醒阶段/等级控制学习。原源数据保留，简化单列用户策略，不将空图加载失败算通关或模板算完整技能。七职业技能和已反馈战斗/UI/地图/性能修复继续，正常学习与测试overlay隔离。GSD直接设置尚未正式实现，由ui-staging/gsd-advancement-next独占节点推进。详细范围与验收见dnf-native-demo/reports/seven-job-world-20261020/PLAYABLE-SCOPE-UPDATE.md；此条覆盖下文完整机制和转职任务的旧门槛。原资源/历史候选/正常存档保护及逐节点备份继续。

# 最新用户调整：副本特殊机制先不做，七职业技能与普通副本优先（2026-10-20）

用户明确“副本特殊机制可以先不做”。本轮暂缓hellparty/深渊/APC特殊遭遇、塔专属流程及副本专属机关/特殊反击扩展；来源和已完成私有成果保留，不计完成。七职业实质技能、正常学习/装备/成长、普通怪物AI与Boss基础战斗、物件/门、地图/UI/性能及普通副本结算返城继续优先。全地图暂不等级/任务准入，资源/格式缺口具体诊断，特殊路径不静默算通关。当前已合ACT/window完成必要全量验证和备份后转回职业技能。详细范围与恢复见dnf-native-demo/reports/seven-job-world-20261020/SPECIAL-MECHANISMS-DEFERRED.md。此条覆盖下文先做特殊机制的旧排序，原资源/历史候选/正常存档继续保护。

# 当前节点：男枪普攻/跳跃与世界反馈自动通过，持续后续实施（2026-10-20）

gunner-world 完整核心/音频/隐藏UI、同主EXE来源审计及SDL dummy通过；EXE `ab83a1c666b6e9c432c086be3f831f3c26cacd21adab84f64ff86360da957130`，398输入/140报告。男枪第三枪分段/源弹速和跳跃局部时钟、枪口渲染profile、UI/门/TIL、入场怪物等级及选角回区域源赛丽亚已整合；精确范围/推断/用户步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/gunner-world-node/PROGRESS.md。独立源码/编译产物/证据备份查主工程checkpoints/LATEST.md。男枪948、枪口profile98、raw11命中72等专项在本次正式闭包重跑；前台/原版动态待用户，不将通过检查计作技能完整度。下一步SET DAMAGE CHECK、hellparty与ACT/APC/塔及其余职业技能，七职业全副本/最终十职业门槛仍开放。此最新状态覆盖下文历史未合入和等待门；不暂停任务、不缩范围，原资料/正常存档/历史候选保护有效。

# 当前节点：属性弹、源缓存与共享攻击移动自动通过，继续地图/UI及登录修复（2026-10-20）

attack-motion完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy通过；EXE `1b65e9728181dc8460026aa0596593ba0ea4a2e107b71f61c8c7050fb377d932`，374输入/124报告。专项移动672、属性弹1468、缓存28、跳攻436、Action.ai787。准确推断/范围/步骤/恢复见dnf-native-demo/reports/seven-job-world-20261020/attack-motion-node/PROGRESS.md，源码/产物节点备份查主工程checkpoints/LATEST.md。下一节点修进图退出/长诊断、怪物按入场角色有效等级冻结、再选角色回当前区域赛丽亚及选择/地图UI；这些最新要求尚未在本节点完成。ACT/APC/五职业实质技能和全图门槛继续开放，不暂停任务、不缩减范围，原资源/历史候选/正常存档保护有效。

# 当前节点：女枪跳攻/源武器与Action.ai自动通过，任务继续（2026-10-20）

正式combat-source节点完成完整核心/音频/隐藏UI、同EXE profile/content与SDL dummy；EXE `fe53ce32fabeddb916af979d0f55ba4c35a13a9644e777a950f8dfee460b3a1d`，370输入/121报告，真实World女枪跳攻/源枪口/资格436项与Action.ai787项通过。build为cache/seven-job-combat-source-build，tests为cache/seven-job-combat-source-tests-attempt1。范围、推断、用户步骤和恢复查dnf-native-demo/reports/seven-job-world-20261020/combat-source-node/PROGRESS.md，节点源码/产物/证据备份查主工程checkpoints/LATEST.md。按需PVF/场景节点保留；这是中间节点，继续源工作缓存/属性弹、共享攻击移动、ACT碰撞受击、APC/塔及七职业全副本，不按历史等待门暂停。原生socket/PTL运动、Destination/Move消费者、完整ACT pending恢复、statBase27与五职业技能缺口仍具体保留，不将索引或模板计作完成。原资源/历史候选/用户存档保护有效。

# 当前继续实施：按需加载与场景/表现节点自动通过，继续技能/AI（2026-10-20）

资源/世界节点完整核心/音频/隐藏UI、同EXE profile/content审计与3秒SDL dummy通过；主EXE `36691717e00a8bdef803dbed1b9bc252d4314d5909324a377c3a5da5198a97fb`，364份编译输入/117份JSON报告绑定。build为cache/seven-job-resource-world-build，tests为cache/seven-job-resource-world-tests-attempt3。用户追加的PVF索引/按需字符串翻译与地图依赖、私有下一场景准备已正式接入；207脚本/2948 MAP归属对比一致，重复准备缓存DGN1无新读取/解析，跨333副本缓存后旧会话恢复一致。四组世界专项全部通过，但191/333来源拓扑生成及131/135可见项生成不等于全图可玩。准确范围/失败/恢复见reports/seven-job-world-20261020/resource-world-node/PROGRESS.md和CURRENT-NODE.md；独立源码/产物/进度备份以checkpoints/LATEST.md为准。此为中间节点，任务继续，不按历史等待门停止。接下来窄合jump-weapon-ready1女枪跳攻/枪口/源武器资格（私有436项）、Action.ai READY（私有完整重编787项）及APC实体需求诊断，再补共享攻击移动/属性弹/ACT伤害/APC塔流程。高等级statBase27与五职业完整技能仍是实质缺口。新layout必须完整重编；原客户端/历史候选/正常存档保留。

# 最新继续授权：七职业全副本修复体验版（2026-10-20）

用户体验后提出13项修复并明确继续实施，覆盖此前等待确认门。优先女枪子弹脚底坐标、聚焦/寒冰喷火移动且按住实际释放键持续/松开停止、测试模式进图掉帧；补怪物装备可见、多受击动画可恢复随机、源物件受击/破坏、全副本AI、Boss光环/血条，以及各区域选关/世界地图/副本小地图。暂取消地图等级任务准入，缺资源/格式须具体诊断。当前交付至少七职业（鬼剑士/女格斗/男枪/女枪/男法/女法/圣职）可正常游玩全部副本，不将普攻模板当完整技能。每项先查知识库和1031；缺证反馈。实际进度与并行分工见dnf-native-demo/reports/seven-job-world-20261020/CURRENT-NODE.md。原十职业最终beta门槛、逐节点备份、原资源/历史候选/存档保护有效；本轮尚未编译或验收新候选。
<!-- selection-ime-verified-handoff -->
# 最新体验候选：技能图层、选择界面与IME自动验证通过，等待用户确认

主工程当前候选完整核心/音频/隐藏UI、同EXE来源审计和SDL dummy冒烟通过；EXE `74b7e5c3a59783057c482c4f442889389f9d849706527ee367a5e62d88dfd26a`，349输入/110报告绑定。入口`D:\dnf-rebuild\dnf-native-demo\Start-Selection-IME-Fixes.cmd`在checkpoint核验后发布，准确备份目录见dnf-native-demo/checkpoints/LATEST.md。范围、源透明/缺图、未恢复Full输入及其他推断/缺口、用户步骤和恢复点见dnf-native-demo/reports/selection-ime-20261020/NODE-PROGRESS.md；不是全十职业beta完成。前台/IME/听音/手感和原版动态待用户。**交付后等待用户确认才继续其他节点。** 不维护独立预览，原资源/历史候选/用户存档保护继续有效。

# 当前动作/技能节点自动通过，继续整合已排入的界面节点

完整核心/音频/隐藏UI、同EXE来源审计及SDL dummy冒烟通过。EXE `d571ad37668b52c38afa0bd8e18c216eeb44256a2a9b56183066d60bb68fe0b9`；332输入/102报告绑定。范围、推断、失败记录、用户步骤和恢复点见reports/attack-timing-offset-20261020/NODE-PROGRESS.md。节点备份目录以checkpoints/LATEST.md为准，完成备份后才继续正式源整合。当前只是中间节点，最终体验候选尚待下一节点编译和用户确认，不能当完整beta。

# 最新执行：普攻/剑舞时序及坐标，再处理选择界面/输入法（2026-10-20）

用户已更正为“枪舞”，同时补喷火器/激光炮技能武器贴图。当前最高优先为SKL/CHR/ANI-ALS/OBJ引用分类与实际绘制/判定消费者，不能只修时长。最新交付门：完成本版（含上述及已排入的选择界面/IME）后先交候选及备份，等待用户确认才继续后续节点。下一版可选客户端/PVF/ImagePacks2目录选择仅登记，非当前主线。立即体验入口Play-Latest-Verified.cmd，源码增量构建入口Run-From-Source.cmd，不把source build-only当正式验收。

用户新反馈及继续授权覆盖历史等待门。节点一核对全职业普攻恢复、女枪“枪舞”（已更正，非剑舞）卡首次帧、ANI毫秒单位、枪舞/重武器特效及技能相关格式/特效XYZ；独立验证并备份后，节点二修副本选择、人物选择/创建和IME。当前旧候选不覆盖，新报告目录reports/attack-timing-offset-20261020/与reports/selection-ime-20261020/。只有实际新构建验证与checkpoint完成才记节点完成；用户前台体验仍独立待测。

# 历史：技能/UI/地图修复候选自动通过，等待用户确认

女枪、五界面及地图的主工程隔离修复候选已完成本轮编译和自动验证。统一启动`D:\dnf-rebuild\dnf-native-demo\Start-Requested-Repairs.cmd`；源码/产物/证据备份及本机实际目录查`checkpoints/LATEST.md`。EXE SHA256为`585bbc736e34b257380deac1f583172f19b4d65b1f0728d9c20a5e5d6502a650`。正式输入321份、JSON报告98份，完整核心/音频/UI与同EXE审计通过。范围、步骤、恢复及实质缺口见`reports/knowledge-base-audit/NODE-PROGRESS.md`。

72主动有实际来源阶段及World消费者，不代表全部167技能或95被动完成；正常女枪SP/转职/觉醒、若干被动/业务和原版动态仍有缺口。地图本轮修复共享层序与视差，黑边视觉仍待复测。**候选交付后等待用户明确确认，不继续后续节点；下一次只响应体验反馈或用户继续授权。** 不维护独立技能预览，原资料、历史候选、用户存档及完整十职业最终门槛继续保留。

# 当前优先：知识库核对及技能/UI/地图修复候选（2026-10-20）

最新用户指定候选范围：女神枪手全部技能；装备、技能学习、任务、NPC对话框和点击NPC后菜单；艾尔文防线、洛兰深处、天空城。三线开始实施；基础HUD构建完整通过（86报告、HUD18检查），备份`checkpoints/20261019T190750064062Z-knowledge-hud-foundation`（738文件SHA复核）。该基础不是最终候选，技能/UI/地图修复完成后需再次隔离构建检查和备份。交付后必须等用户确认，不继续R60-04其他内容。

用户要求先遍历新知识库及skill再核对：全库6414文件的字节/hash/文本索引、分域重点阅读和未核实范围见`reports/knowledge-base-audit/`。两份skill已复制至工作区`skills/`并登记根AGENTS；没有执行知识库代码。社区资料存在版本差异和内部矛盾，不批量替换当前1031正确实现。三段斩逐列修改建议因当前SKL反证已撤回，未改其数值链。

用户最新要求本轮优先制作技能、UI、地图修复版并编译供其查看，**候选交付后等待用户确认才可继续后续节点**。HUD按钮源读取已接实际draw/hit-test，`cache/knowledge-hud-build`/`cache/knowledge-hud-tests`正在隔离验证；其他修复仍需来源核实与真实消费者。此段不是验收通过声明。历史技能退出修复入口仍有效；最新候选交付后更新准确路径/hash和恢复点。

# R60-03技能空放退出修复：自动验证通过（2026-10-20）

新主EXE `f2d7434e25b297d03e9d7c611db9f03ea945db407ec15f8f1e81114bba5d6638`，实际World 2692项/18次空放、学习51项、完整核心/音频30项、来源审计及局部SDL dummy smoke通过。启动 `D:\dnf-rebuild\dnf-native-demo\Start-Skill-Crashfix.cmd`；备份查 `reverse-60us/checkpoints/LATEST.json`。用户操作复测待执行。后续集中主工程，不单独维护独立技能预览；R60-04草稿保留，下一步继续04。完整记录见 `reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md`。

# 当前节点：优先修复R60-03已学习技能空放退出（2026-10-20）

实际用户fatal为 `Normal learning state changed; reset the test overlay explicitly`。新实际World回归链接03 core已无怪复现相同异常。修复只规范学习指纹中的精确空零级冷却行，正常学习/购买/未知字段仍校验；旧绑定精确验证后升级，未清存档。隔离 `cache/r60-03-skill-crashfix-build` / `cache/r60-03-skill-crashfix-tests` 正在编译验证，详见 [修复进度](../reverse-60us/integration/R60-03-SKILL-CRASHFIX-PROGRESS.md)。04未编译草稿保存在 `cache/r60-04-interrupted-for-crashfix-20261020-021438-156`，公共三文件已回到03后进行本修复。后续不再维护独立技能预览程序，集中主工程；修复验收备份后继续04。

# 历史节点：R60-03自动验证通过，继续R60-04（2026-10-20）

共享动画clock、普攻/九实验职业/普通姿态身体和装备、攻击/声音及动态ALS已接实际消费者。最终主构建 `cache/r60-03-build`，完整核心/音频测试 `cache/r60-03-tests-final-r4-checked` 通过，日志 `reports/r60-03-build-final-r4-checked.log`。EXE SHA256 `7c12c8ca38b717d6da5ec2eeb16ac1f25df372a965e03de836417bfe174db4a0`，285输入/84报告；clock1541项、九职业完整待机往返及音频30项通过。同EXE来源profile和3秒SDL dummy部分smoke通过。精确身份见 [VERIFICATION](../reverse-60us/integration/R60-03-VERIFICATION.json)，范围/限制/用户步骤见 [PROGRESS](../reverse-60us/integration/R60-03-PROGRESS.md)。

独立预览 `rep-player-1031-pvf/Start-R60-03.cmd` 的72项D3D/78帧UI/184四流程/24104模板通过。主默认仍legacy clock，候选策略与render分别显式选择；1031跨版本复用仍为推断。主存档/原客户端/历史候选未覆盖，完整原生技能新增0。源码/产物/证据/进度/SHA备份查 `reverse-60us/checkpoints/LATEST.json`，03备份核验后继续R60-04的技能阶段与视觉实体；正常转职和派生精通缺口必须按统一资格补充处理。

# 历史节点：R60-02渲染候选已验证，继续R60-03（2026-10-20）

R60-01差异矩阵和R60-02采样/变换/混合接入已完成。隔离构建 `cache/r60-02-build` 核心/音频通过，283份编译输入、83份报告绑定；EXE `128fdb1a2a3b533f973179061a8a5bcaa9ef06900592c0f71b2bd05ac0d608eb`。`--ani-render-profile inferred60us1031` 启用显式跨版本推断，默认legacy保留；身体/装备/效果共享可移植内核。来源profile审计和3秒SDL dummy部分smoke通过，原生clock与战斗poseFrame冻结语义尚待R60-03。两工程整包进度/源码/产物/SHA及用户步骤见 [R60-02进度](../reverse-60us/integration/R60-02-PROGRESS.md) 和 `reverse-60us/checkpoints/LATEST.json`。

独立播放器新入口 `rep-player-1031-pvf/Start-R60-02.cmd` 提供原1031与60US推断渲染比较，并实际显示模板SKL原图标；没有迁入其技能模板。历史build30/节点05/根build警示与用户存档保护继续有效。当前R60-03先完成时钟算术/游标再接实际战斗/装备/附层/暂停，不能把新helper当完成节点。画面/声音/手感和原游戏动态比较仍待用户。

# 历史优先任务：接入60US逆向成果，先渲染（2026-10-20）

用户要求已将本次60US逆向源码、合同、原字节和REA返回单独交接到 [reverse-60us](../reverse-60us/README.md)。接手先读该目录 [CURRENT_TASK](../reverse-60us/CURRENT_TASK.md)、[MODULE_MAP](../reverse-60us/MODULE_MAP.md)、[PORTING_PLAN](../reverse-60us/PORTING_PLAN.md)，按R60-01→R60-02直接推进现有实现差异审查、名称/图标与通用渲染隔离候选，再做原生时钟、技能阶段/视觉实体、怪物受击死亡和场景破坏；完整伤害计算后置。

首先核对 `src/resources.cpp::Animation::samplePose` 的位置/RGBA double mix、`src/renderer.cpp` 的pose消费与本包60US截断/float32/变换/混合证据。已有功能不重做。60US的算法证据不能自动当1031事实；保留独立profile与来源身份，对未核实跨版本复用标推断，不复制60US地址或技能状态编号。原1031十职业/转职觉醒/全技能门槛继续有效。

本次只新增交接与任务安排，没有改本工程C++源码、build、playable、checkpoint、存档或EXE；下述build30与1031预览仍是原身份。旧“等待模板体验”的顺序记录不阻止新授权的证据审查和隔离渲染候选，不代表模板已获原生验证或已迁入主运行时。根build不可作当前有效候选的警示继续有效，恢复仍查已核对checkpoint。

# 历史优先任务：1031 PVF 技能预览映射与独立 demo（2026-10-19）

用户要求先完成当前 1031 PVF 的技能预览映射、制作并编译独立 demo；用户体验后再决定是否将调用链/预览逻辑迁入当前客户端。十个非缔造者职业逐项技能和攻击判定适配排在用户确认 demo 之后。此前 86JP REP 仅作为录像视觉时序参考，不直接套用其 REP 协议或资源映射。

1031 技能预览节点已完成隔离编译与自动映射审计，现等待用户前台体验。固定 PVF SHA256 `d13ce454567197bb4617cad4d0e472f609a1ec5cf2256462d780547be878607d`；10 个职业、1,677 项注册技能、484 份 REP 的 1,817 条输入记录全部映射，未映射槽为 0。现有 884 条 CHR ANI/ATK 名称候选外，已增加 191 条可识别 SQR/NUT loader 的字面 ANI 候选；鬼剑士 skill 79 的基础 Bloody Rave 分支 15 条效果 ANI 全部解析到 1031 PVF，Dark Knight `BloodyRave_DS` 单独归类。SQR/NUT 原生执行、同步时序、命中判定与伤害仍未证实。

实现与运行包：`src/skill_preview.cpp`、CMake target `dnf_skill_preview`、`playable/skill-preview-1031/`。启动器 `play.cmd` 已带 EXE、SDL2.dll 与 libunwind.dll。构建及核心/音频自动检查通过，源码/EXE 哈希与映射统计见 [技能预览节点进度](reports/skill-preview-1031/NODE-PROGRESS.md)；窗口画面、声音、操作感与原版动态对照待用户体验。本次不会迁移到 `dnf_native`；等待用户基于 demo 的反馈后，再安排调用链采纳与十职业技能/攻击判定适配。独立节点备份见 `checkpoints/` 下本节点目录。

原实施线恢复点仍为 build30 检查点 `checkpoints/20261018T201028867867Z-source-camera-nut-skill-feedback`，其试玩入口为 `runtime/play.cmd`。工作目录根 `build` 的 `build-verification.json` 当前为 0 字节，根 `libdnf_core.a` 与检查点哈希不符；不得把根 build 当作有效候选，继续以检查点已校验产物为准。

# 最新完成节点：来源相机、NUT动作消费者与技能输入反馈（2026-10-19）

build30完整核心/音频 exit 0；同一 EXE 的 profile/content 来源审计通过且未启动前台。281份源码输入、83份报告绑定；EXE `d54f76a3de51fd6c1897a18dc3eb6bd8ce21dc52ffae2c0b34847bcd80babb53`，核心库 `e23ff92ee3fc6512f8f19859652ad5103ec01490d37bc5cd1fd3342d38a5a879`。相机172项、技能失败反馈51项、Squirrel action/World桥接44项与技能资格20项均通过；音频检查运行于SDL dummy。细节见 [节点进度](reports/beta-script-camera-20261019/NODE-PROGRESS.md)，本轮checkpoint生成后更新 [LATEST](checkpoints/LATEST.md)。build27–29失败记录保留。

相机按艾尔文防线复核源TIL、IMG逻辑画布/裁剪、源视差和可视宽度；浅图固定Y，高图依据连续源图块范围滚动，调整分辨率后重算视口和NPC拾取逆变换，不扩大通行范围。技能不可释放时提供短暂抖动提示；默认Z可排到当前动作之后，并在结束tick重新校验资格、MP和CD。NUT/Squirrel宿主接入一个真实实验Buff声音回调，事务失败不扣费/起CD并清理VM；Buff属性、动画和其他NUT API仍未完成。

启动进度窗与并行加载是下一节点：先显示PVF指纹/解析及资源进度，启动异常可见；只并行独立安全任务，保持资源共享缓存单owner、确定性合并、完整校验，实测串并行一致性和耗时。之后继续ACT外层同代续演、P14物件破坏、statBase27来源消费者及原P01–P19。当前节点备份为 [20261018T201028867867Z-source-camera-nut-skill-feedback](checkpoints/20261018T201028867867Z-source-camera-nut-skill-feedback/PROGRESS.md)，试玩入口为该目录下 `runtime/play.cmd`。完整beta仍约10%工程估计；前台画面、听音、手感及原版对照由用户执行。

build27–29的编译、资格回归和相机边缘失败及其修复证据保留在 `reports/beta-script-camera-20261019`。build29发现Scene碰撞余量被误作渲染源宽度，现分离 `sceneVisualWidth` 并用真实源边界校验；零级技能用例只允许明确 `unlearned_skill` 提示事件，其他动作/资源/冷却检查仍完整。

用户新增范围继续有效：NUT全技能调用/动画依赖归P07，木桶/草/树等非怪物对象破坏效果归P14；其他职业暂套鬼剑士动作读取和状态机的体验调整不能算完整职业恢复。全地图/测试准入、城镇、实验职业和技能栏仍需正规验证。所有节点独立备份源码、产物、证据与进度；历史候选、原客户端及用户存档不覆盖。

完整 beta 仍约10%工程估计，十个非缔造者职业/实际转职觉醒/全部主动被动与世界业务门槛不减。前台、画面、听音、手感和原版动态比较由用户执行。

# 历史节点：全源城镇与共享攻击读取（2026-10-19）

build23 已完整核心/音频 exit0，ACT runtime90/World host68、Event.ai37/World26项通过。build21/22的 C++17 显式默认构造失败证据保留。build guard 已合入：保护已验证的构建目标目录，默认打包仍全局严格；25项mock通过，真实只读枚举当时无游戏，不声称真实PID路径查询已验。

**build26完整核心/音频exit0，222输入/79报告hash绑定。** EXE `84025a71f14e6efd1f2747695c73284f26518ac05532a86e11771fd51287dad4`，核心库 `1c00b676bf2e305dc84b35edc1eca67d8190ccd1e9c56b78e64c3a1a2fb34595`。城镇587项含77/77准备、实验角色196项含九职业普攻实际HP、存档80项通过。profile/content及真实备份默认路径无前台audit通过。范围见 [NODE-PROGRESS](reports/beta-act-event-20261019/NODE-PROGRESS.md)；备份查 [LATEST](checkpoints/LATEST.md)。下一构建用新报告目录/日志编号27及之后，构建期间冻结include/src/tests/tools/CMake。

已验证F10全17城镇/77区域及源出口、14条PVF身份绑定MAP别名、严格TownLocation/return anchor同代存档；共享character_attack读取各职业自身身体/真实武器层及晚帧/声音去重；F6/实验K用户临时“普攻模板”、资源失败不扣费不漏声音/身份；备份默认独立runtime/saves。manifest/窄patch/证据见reports/beta-act-event-20261019/source-notes。临时模板仍非SKL专用机制恢复。

F9源Event.ai选择已接线，但正向F7真实Jena准入**未通过**：build24未知statBase27/源等级60阻断，build25诊断替代也被来源属性门槛拒绝；日志/草稿保留。build26仅检查真实MAP明确拒绝及F9不能制造演员，报告positive_f7_source_growth_verified=false。独立Event.ai World26项不是来源平衡验收。见SOURCE-F7-EVENT-GAP.md，后续P06实质消费者不减。

ACT外层同代恢复仍在 `cache/act-continuation-outer-staging`，需复用TownLocation validator，不能把typed宿主收据当磁盘续演完成。Squirrel runtime/World仍独立冻结未合入。当前节点通过备份后继续这两项及原计划，不停止。

保护434原基线428一致，4旧build EXE差异未变。正常两存档从本节点首次152/151代变为184/183代、19:34:40 UTC；same_delta_as_first_observation=false，脚本exit1保留，不能称整批保护通过。相邻运行日志明确工作区build及正常存档路径，尚无逐写唯一归因；不回滚/覆盖/刷新原基线。调查后hash稳定，见audits/PROTECTION-INVESTIGATION.md及post-investigation-confirmation。

本节点备份入口以checkpoints/LATEST.md为准；旧 `20261018T184651001560Z-source-map-character-experiments`保持原样。随后继续下一节点相机（参照艾尔文防线）、NUT动作消费者/失败抖动/Z衔接，再接ACT外层及P14物件。staging尚未合入，不计本EXE通过。

# 最新完成节点：全地图与角色实验入口（2026-10-19）

用户优先项已接入并通过 build19 完整核心/音频及同 EXE profile/content 无前台审计。204 份源码输入、73 份报告绑定 hash；EXE `1afb8642b7bfa3471d203d2ec9c195753f9118044d3905559a74bde542883955`，核心库 `0f3bfd785c2f29f418ec757351b70f9cfd37f22771ede48666c5c4692b2777c2`。详细范围、失败修复和恢复步骤见 [节点进度](reports/beta-experiment-20261019/NODE-PROGRESS.md)，已完成备份入口见 [LATEST](checkpoints/LATEST.md) 与 [版本入口](checkpoints/版本入口.md)。

F7 全 2948 MAP 目录，F9 测试总开关开启后提前入图；缺资源有诊断、缺地面阻行，探索不发通关奖励。十个非 Creator 基础职业可创建，九个实验角色使用自身 CHR/ANI/ATK 和 SD/EQU 起始武器。F6/实验 K 提供 13 槽手动技能配置，源 MP/CD、统一伤害、同代保存和重载已测；正常 Swordman Space 换绑及清空也已测。全图索引36、准备17、World消费者32、实验角色97、存档79项通过。五个实验职业普攻测试有 HP 损耗，fighter/mage/thief/demonicswordman 四个仅验证动作；完整技能/被动/分支/觉醒仍未完成。

14–18故障证据与修复说明保留，19 才是本节点已测身份。保护原434基线428一致；4旧EXE差异不变，正常两存档首次观察前已变为143/142代、18:14:09 UTC，写入者未确定，之后未再变化；原基线不刷新，详情见调查文档。试玩使用节点 runtime/play.cmd 独立存档，不直接双击 EXE。前台/听音/手感和原版动态对照待用户；步骤见 [USER-TEST-STEPS](reports/beta-experiment-20261019/USER-TEST-STEPS.md)。

备份后继续原 P01–P19，不停止或缩减范围；完整 beta 仍约10%工程估计。下一步整合 Event.ai 接受接触到 ACT、typed ACT 收据/候选及外层同代恢复、Squirrel World 接线。独立 staging 均未计为通过，不能用旧 staging 覆盖本节点修复。

# 当前实施节点：ACT World 宿主与优先体验入口（2026-10-19）

最新完成节点见 [NODE-PROGRESS](reports/beta-act-world-20261019/NODE-PROGRESS.md)，备份 [LATEST](checkpoints/LATEST.md)，汇总入口 [版本入口](checkpoints/版本入口.md)。build13完整核心/音频通过：ACT宿主49、来源路由/工厂47、来源World服务27、房间状态23项；EXE `144efcfe162b1b0c9cb86cd918a41c734f5f823760cb0f8918ce5ef1c30cf76b`，189输入/67报告hash绑定。11/12故障注入用例修订号失败保留，13为最终身份。

World自有host接主循环，正常MAP共享工厂→MOB原槽→ACT编译/OnSet/速度/方向/位置/移除/声音事件/文字台词；自动Nagor stay、显式Jena slot4、CD和退出已测。hitstop/stun/AI暂停时互斥动画时钟及速度暂停，抓取/受击/死亡/换场清理。standalone无bundle玩家恢复清理已修。Event.ai接受伤害闭环、ACT攻击盒/物件、磁盘续演和Squirrel World接线仍未完成，不计整怪或全区域。

用户新增优先项：本次开放全MAP目录和入口，测试模式可绕过等级/任务等准入；开放其他未完成角色的PVF实验运行与13槽自配技能栏。实验入口不计正规职业/区域完成，后续仍须完整验证。正在独立cache/map-access-staging、map-exploration-staging、experimental-character-staging中实施，尚未随build13验证；主线整合/构建/打包串行。完成备份后继续原任务，完整beta约10%工程估计、十非Creator最终门槛不减。

保护434基线现428一致：旧build4EXE历史差异及新发现正常存档2份变化（17:51:42 UTC、generation90/91，早于build11），写入者未确定，未回滚/覆盖/刷新基线。启动备份请用runtime/play.cmd独立存档参数，不直接点EXE。前台/听音/手感/原版对照由用户执行。

# 历史实施节点：真实Tau眩晕、状态恢复与实体身份（2026-10-19）

本节优先于历史记录。完整beta仍粗估约10%，当前实际可玩仍为未转职鬼剑士，十非缔造者职业及实际分支/觉醒/全部技能和世界业务继续实施，范围没有缩减。最新完成备份查 [checkpoints/LATEST.md](checkpoints/LATEST.md)，本节点详细记录 [NODE-PROGRESS](reports/beta-status-20261019/NODE-PROGRESS.md)。

真实Tau第二攻击已经通过ATK概率30%/等级0/1000ms进入独立StatusHost，伤害/状态/RNG候选发布，眩晕阻断实际输入与AI；来源抗性、expiry/死亡/Removed/换场、玩家/房间同代保存和显式目标重映射已接运行时。接近轨迹修复防止旧冲撞在真正源攻击帧前穿过目标，first type15边界从ANI读取；具名推理不是原生轨迹证明。全局状态编号不回退，坏策略/水位/来源/代/持有者或跨目标复用ID均在读档重置现场前拒绝。

重复恢复同一checkpoint导致旧EntityHandle复活的缺陷已修：候选实体水位合并live历史，0永久耗尽，全部存活/死亡中但未Removed的演员身份先私有预分配；CharacterStore预检select和restore两次分配，失败不清现场。clearSceneTransients不分配身份，正常换场和直接恢复分别发布已准备的句柄。

最终build10完整核心/音频通过，状态服务75、实际World31、房间20、身份恢复23项，含30/60/144FPS与分批补tick一致性。EXE `d6633262e4ebe43d3964cda2aec0ea71e749c7decdd3eecb9dfcc5cb8c6e2d53`；实际静态库与64份报告hash见build-verification，节点工具同时备份编译库。06/07失败、08/09通过与修复前只读审查均保留。profile/content只读审计位于节点audits，未启动前台；前台/听音/手感/原版对照待用户。

下一步正式接ACT World host v2的tick/来源路由/speech及完整持久恢复；核心capture已通过不等于宿主完成。Squirrel typed-host独立919文件冻结，189 decode/compile和32宿主用例通过、仅两个真实API，尚未接World；182脚本缺API不能计完成。直接调用restoreSessionPlayer且无bundle的旧状态清理仍有边界，正常main先changeScene路径已覆盖。434保护文件仍只有历史旧build4项差异、其余430一致，未静默刷新。每节点备份后继续任务。

# 历史实施节点：来源投掷物/显式HP物件与逐节点备份（2026-10-19）

本节优先于后面的历史状态。完整v0.1 beta约10%（工程粗略估计），十非缔造者职业和全部实际开放分支/觉醒/主动被动、世界业务仍未完成。用户要求任务持续，每完成节点都备份源码、编译产物、证据和续做进度文档。

最新节点备份：[PROGRESS.md](checkpoints/20261018T165352718179Z-source-projectiles-object-damage/PROGRESS.md)。546文件SHA256复核通过，含source/runtime/evidence/manifest；EXE `ac7bfda2e31529593e0de22fb89afc07a4df82efdd05ff0aa5d3415ff891eac1`。第一节点备份保留。节点为开发备份，尚不打包候选3，候选2保持原样。

正常来源初始化、SP/TP单一账本、持久化优先购买及故障重试、旧档迁移、独立测试学习覆盖、CHR/EQU人物属性、MOB冻结属性和逐目标具名推理伤害已接实际World。第二节点修复投掷哥布林MOB→PO→ANI/ATK/PTL绑定，发射时冻结主人属性与攻击身份；显式HP物件接触后消费统一伤害，攻击框冻结ATK和技能参数，避免动作结束后误查stay.atk。构建/核心/音频通过 `reports/beta-learning-20261019/build-05.log`；World伤害38项、显式HP物件10项及既有专项通过。同EXE profile/content只读审计完成、未启动前台。失败日志01/03/04均保留。

继续实施：Tau Army第二攻击stun缺消费者被明确阻断，独立状态服务在 `cache/status-host-staging`；投掷destroy PTL的多粒子/旋转/重力/淡出尚未消费。ACT typed执行器及真实World宿主在 `cache/act-host-staging`，尚未接入、不计完成。Squirrel原EXE证实2.1.1/char16/int32，官方固定3.1仅作明确版本差异的兼容候选，在 `cache/squirrel-host-staging` 做隔离探针。十职业、完整装备被动及全域业务继续实施。

保护核对434文件中，旧build目录4个EXE于00:26被默认构建重写，写入者尚未确定，旧build验证记source changed失败。其余430个基线文件一致；原基线、差异和搜寻记录保留 `reports/beta-learning-20261019/audits`。未回滚/静默刷新，不声称整个批次完全未变。历史候选及用户存档未在本次差异中。

备份工具 `tools/checkpoint_node.py` 检查已测源/二进制/报告hash，写全新时间戳目录与PROGRESS.md，并逐文件复核。下一批接状态与ACT，源码冻结后串行build06及同EXE审计，再备份新节点并继续。未完成staging路径已记录，不能冒称已随生产源码验证。原资源只读、D盘产物、前台与原版对照由用户继续有效。

# 历史实施交接：基础设施候选 2（2026-10-18）

已按 v1.1 方案开始实际实施，后文“仅文档”“最新候选”等标题均为历史记录。完整十个非缔造者职业、实际分支/觉醒/全部主动被动与业务闭环门槛仍未完成，当前可玩控制器仍仅未转职鬼剑士。不得将本候选称为完整 v0.1 beta。

独立候选：[beta-foundation-2-20261018](candidates/beta-foundation-2-20261018/README.txt)，双击其 `play.cmd`；默认写候选自身 `saves`，F9 测试分支写其 `saves/beta-tests`。不导入旧存档、不改已有启动器或历史候选。归档 EXE SHA256 为 `5004fee99851d415a9ee6286230778df2f44b7731aad253a6e18ff54f8dfbaec`，源码快照和测试/审计均在候选 `source` / `evidence`，以该快照为构建身份。后续源码继续实施，不把新源码冒称已由该 EXE 验证。

本候选新增实际消费者：

- PVF/静态根独立配置、来源身份/保真脚本、全量来源与能力缺口审计；P02完整运行准入仍未完成。
- 固定模拟时间、实体/动作身份、独立随机流、同代存档/奖励/布局恢复；完整持续实体续演仍未完成。
- CHR来源成长与技能MP/CD推理策略；装备来源速度进入普通移动及基础攻击，技能专用时钟仍待完成。
- EQU HP/MP固定增量及MP百分比进入换装、正常升级、调试设级、破损/维修与恢复的统一重算；真实10564双上限验证。正常换装不回血，升级保留绝对损失，死亡不自动复活。
- 装备UI通过私有候选预检→World完整准备→进度提交；来源资格失败保持原装备/背包/战斗状态，成功后不再二次同步。
- 新beta副本按MAP等级、MOB与成长表计算HP；副本保存 `monster_stat_policy`，旧档缺字段默认legacy，包括尚未访问房间。已保存演员HP与 `source_stats` 不重算。
- F9独立SDL测试窗、HP/MP独立锁、无CD、AI暂停、设级、暂停单步、反馈导出与独立测试存档分支。软件renderer显式应用无vsync，测试检查实际SDL flags。

最终成功命令为 `tools/build.py --build-dir cache/build-beta-foundation-20261018 --test --test-dir cache/test-beta-foundation-20261018`。日志 [build-20261018-03.log](reports/beta-foundation-2/build-20261018-03.log)；核心30项标签、音频30项通过。专项独立报告：装备资源模型55、真实World资源15、装备事务17、怪物来源71、调试命令69、双窗18、session布局/恢复180项通过；这些是逻辑检查，不合计成游戏完成度。首轮编译及第二轮错误边界fixture失败日志01/02均保留；第三轮修正的是测试API及真正溢出输入，没有削弱运行时范围检查。

同EXE的profile/content审计位于 [audits](reports/beta-foundation-2/audits)，均 `frontend_started=false`。初次审计误用含输出字段的effective配置而被严格解析器拒绝，失败日志保留，纯配置 `profile-config.json` 重跑成功。当前PVF SHA256 `d13ce454567197bb4617cad4d0e472f609a1ec5cf2256462d780547be878607d`，内容ID `dbb6d4b7cd315e7b1d52c64689c22663f8c1fbde36912f593cdbb6bcb3dec237`。

保护说明：新打包前基线219文件核对通过。相对于更早的旧基线，两份现有内容存档曾于23:13:48变化，写入者未确定，仍为format1；没有回滚或覆盖。差异保存在 [historical-protection-delta.json](reports/beta-foundation-2/audits/historical-protection-delta.json)，不得声称整个实施批次所有存档未变。

当前继续工作：正常SP/TP学习服务与唯一账本、完整推理控制器准入、CHR/EQU战斗属性模型。正常学习入口尚缺，现有新角色仍沿用旧技能默认；伤害仍有演示武器常量和简化防御。ACT/Squirrel宿主、其他职业与分支技能、完整装备/被动/伤害、全域能力准入/任务经济和P17策略切换等均未完成。前台游玩、画面、听音、手感及原版动态比较全部待用户；本轮没有启动前台游戏。

# 历史 C++ / SDL2 demo 交接

## 最新：完整技术与执行方案已落盘（文档交付）

入口：[dnf-native-build-plan/README.md](../dnf-native-build-plan/README.md)。v1.1包含14份编号技术/执行章节、核心伪代码、推荐决策、来源索引、十一条原则及25类系统映射、P00–P19任务图、技能覆盖schema和完整性核对。该目录的文档检查工具仅检查方案，不运行游戏；检查结果见其verification目录。

用户确认最终保留十非缔造者职业及实际转职/觉醒/全主动被动门槛；所有区域按能力开放。允许明确推理及可切换方案；用户负责前台试玩，开发提供步骤和逻辑检查。技能/装备优先，精细UI暂缓，必要业务界面和独立beta窗口须落实。根约定和本目录AGENTS已同步最新优先级。

本次仅创建、完善和核验文档与文档辅助工具，没有修改游戏C++、重新构建、启动前台或更新交付EXE。下面现有候选/功能记录继续代表实际运行时状态；不能将计划的v0.1 beta内容误记为已完成。

## 最新续做：技能与人物装备优先，UI复现暂缓

用户最新要求将选图及其他 UI 图层复现暂缓，用户正在整理已有 UI 逆向成果；当前优先角色、技能和装备。内容应由当前 PVF／客户端资源提供，代码实现可复用的解析、资格、状态、碰撞、动画与渲染逻辑。不能把职业、技能、装备、帧值或资源路径复制成分散的代码常量；源格式没有表达的控制器行为才放在独立且注明依据的重建适配层。

人物默认外观现按 `CharacterIdentity.jobId` 读取对应 CHR/SD 的 `defaultEquipment`，通过 `equipment.lst` 定位原 EQU，再按 `[animation job]` 解析 variation 与图层；EQU 的原字段和偏移保留。EQU 的 LAY 动作按 CHR 标签、重复字段序号及原槽位精确绑定；空槽、重复项和未支持的 LAY 布局不猜路径。删去鬼剑士专用默认外观包装入口，避免后续调用误用。

本轮修复了过期外观测试假设并扩展覆盖：隔离构建 `cache/build-equipment-source-motion/dnf_native.exe` SHA256 为 `AFBBDDF4DFF86A58E9F107914B91520AD0463B9DE0E0C32ABE8E972C8161B8DA`，与当前 `Script.pvf` SHA256 `D13CE454567197BB4617CAD4D0E472F609A1EC5CF2256462D780547BE878607D` 对应。核心及音频测试通过；技能数据专项 `reports/combat-native-reverse/skill-data/runtime-tests.json` 138 项通过，十个基础职业各验证主动与被动 SKL 来源，外观测试遍历职业 ID 0..9 验证默认 EQU 来源隔离。该结果仅表示资源解析和逻辑模型测试，不代表其余角色已可玩、人物叠层已与原版一致或前台视觉验收通过。没有更新 `playable/`、旧候选、启动器或用户存档，也没有执行 UI 测试。

新增平台无关 `skill_data.hpp/cpp`：以 `SkillKey` 读取 SKL 有序字段，普通字段、地下城/PvP 等作用域覆盖分别保留；字段选择记录原偏移、作用域和顺序。重复字段保留全部候选并标记歧义，不静默挑第一项。当前鬼剑士运行时名称、命令、消耗/冷却字段、静态参数、等级表及成长类型购买上限改走此读取器。等级表按源声明的列宽进行精确行列读取，0级不再错误复用1级被动数值；实际武器精通攻击量与显式0级存档已覆盖。MP/CD仍只消费首个源端点，插值、取整和最终原版公式未恢复。

技能来源完整不等于控制器完整：当前鬼剑士的可执行清单、阶段、特效路径及技能到 CHR 动作的控制器绑定仍含代码表；其他基础职业、转职和觉醒控制器仍禁用，不能仅因存在 SKL/ANI 就开放技能。后续优先为基础角色闭合完整控制器链与装备动画消费，再处理用户暂缓的 UI 图层。

## 2026-10-18 全工作线隔离整合候选（当前）

当前隔离候选 `cache/build-full-worklines/dnf_native.exe` SHA-256 为 `268f179d718038d1b3644a2f40d1d6813812039976473606fc100c72ba9fc0c6`。构建、核心与音频测试通过，最终日志 `reports/combat-native-reverse/build-test-full-worklines-20261018-final.log`。该候选未覆盖正式 `playable/`、旧 `1c55ec60` 候选或既有启动器；新增 `play-full-worklines-candidate.cmd` 固定启动此二进制并默认使用 `cache/full-worklines-candidate-saves`。

- 最终哈希普通操作 `reports/runs/input-20261018T105518/acceptance.json` 通过11项，包含普攻续段、跳跃、双击跑、冲刺攻击、方向保持后恢复普通攻击及十字左右阶段。输入由SDL窗口消息注入，不是物理键盘／IME验收；用户存档哈希未变。
- 最终哈希六场景可见冒烟 `reports/runs/20261018T105540-713898d5/process-check.json` 退出码0、stderr为空、窗口置顶可见。六张实测截图已查看，画面非空；测试覆盖不等于原版画面／层序一致。
- 最终哈希选图键盘验收 `reports/runs/dungeon-selection-full-worklines-20261018-keyboard/acceptance.json` 通过800×600与1280×720下的等级限制、选择、取消后离开入口再进、重复输入抑制及菜单键拦截。鼠标和高DPI明确未验证；真实截图的选图卡片在两种分辨率都明显重叠，视觉验收失败。先前鼠标驱动尝试失败于旧哈希`7c6a205c…`，不能算作最终候选测试。
- 物件专项报告 `reports/combat-native-reverse/objects/tests.json` 为170项；33份合法MAP、682处放置、198处光效工厂及ANI type-14受击框接触有覆盖。对象声音/PTL、原生受击门槛与一次性payload事务仍未闭合；木桶两击和宝箱一击仍是本地候选值。
- `CharacterIdentity`／`SkillKey`注册与请求路由已接入，但控制器仍只有未转职鬼剑士。其他九个基础角色、转职、觉醒及其技能仍未达到交付门槛。`reports/combat-native-reverse/coverage/` 矩阵仍绑定旧 `1c55ec60` 快照，本轮不将其重标为当前候选。

完整身份、截图观察及限制见 `reports/combat-native-reverse/full-worklines-candidate-20261018.md`。旧候选、正式包、原客户端与用户存档继续保留。

## 历史候选：零级技能资格与存档修复（2026-10-18 续）

本节记录当时的最新状态；当前候选身份以本文件首节为准。候选为 `cache/build-eligibility/dnf_native.exe`，SHA256 `1c55ec6089ec2c38189223d8a18d34144c34ba3b0ae471caf7d437dfc797d2b8`；完整构建／核心／音频 `reports/combat-native-reverse/build-test-eligibility-final-20261018.log` exit0。正式playable仍为旧7a85，未覆盖。旧2567运动候选继续保留在build-next；新a63f纯模块构建保留在build-static-motion（其测试EXE因本轮修复前回归已重编，游戏EXE未改）。build仍为旧误编fc8657dd，不能混用。

临时候选入口为 `play-combat-candidate.cmd`，固定启动上述1c55，不自动编译或覆盖旧包；默认沿用项目saves，隔离游玩可传 `--save-dir cache/candidate-user-saves`。仍依赖同级1031完整资源，游玩切英文输入法。该入口不表示全角色正式交付；旧play-native.cmd／play.cmd仍指向旧build，不要混淆。

- `World::activate` 新释放在缓冲、MP、CD、阶段前拒绝 `level==0`，来自原基类 `86D9D5..86D9F4`。同一动作续段仍为既有本地请求，不宣称完整原生资格；缓冲消费重新检查。存档明确主动等级0现在保留0，缺失旧字段仍用demo默认1；被动和学习分配未改。专项20项通过，修复前18项中15项失败的原报告和日志保留。完整说明 `skill-eligibility/runtime-gate.md`，独立review无阻断。
- 当前hash前台可见零级fixture `reports/runs/input-20261018T092840` 6点通过：地面快捷键、空中G/H、源frame3后的冲刺F、普攻／移动及实际新进程重载。13个0级保留，没有技能stage／扣蓝／CD，用户存档不变。较早092806的F等待150ms不足源230ms门，保留为被后续替代的样本。fixture不是正常学习流程。
- 当前hash正常新角色 `input-20261018T092909` 11点＋双向十字阶段通过，用户存档不变。两项均为窗口消息，置顶可见，不是物理键盘／IME或原版动态验收。已人工查看本hash的零级菜单、普通攻击和右向红十字真实帧；UI整体仍未通过。本轮未重跑深处／设置／accepted-hit fixture，不把旧2567的48点或74项结果冒充当前hash。
- 新平台无关 `static_motion.hpp/cpp` 已恢复8328A0方向／倍率顺序、检查与直接写入差异、8B0600加速度剩余计时。20项算术专项通过；**未接入任何实体或技能位移**，最终属性、指向、保护通知和碰撞未闭合。`horizontal-motion/verification.json` 42项通过；独立32位原函数110字节探针 `probes/20261018T091713810383Z` 12例通过，仅重定位常量，不操作原进程。固定地址分配失败091649原记录保留。独立review已按最新测试hash刷新。
- 新分类 `skill-parameters/` 静态44项：level-info运行时列矩阵／学会等级消费者和有序modifier链，保护入口仍未知；**未替换Skill::parameter或MP/CD公式**。不能把源一格当最终技能倍率。
- `jump-physics` 最新21组／170代码／30数据窗口；四bank跳跃速度倍率默认1已证。洛兰35MAP＋4MOB的44份raw/model核对与原实体parser默认关闭证明：本区域未显式启用 `[add gravity in aerial]`，不要把20/−300补正强加到它们。累计消息的HP输入−158与累计−168不同，接受伤害来源、状态／实体绑定仍不完整。
- 女格斗 `fighter-attack/default-exit/` 177项：共享state8直接ANI完成→state0请求；女格斗oldState8清五个确切附层，不能清buff6270／全部特效，也不能假定请求立即提交。实际female tick caller仍未闭合，上层manifest已刷新。`particles/actor-modifier-defaults` 闭合构造默认与owner参数集合登记／注销／读取；施法时最终修饰仍未知，不能把十字未修饰约56当实际终点。新成果均未开放其他角色。

构建与报告身份归档 `reports/combat-native-reverse/build-checkpoints/eligibility-1c55ec60-final/verification.json` 40项通过，含对应核心／音频专项副本、源与EXE hash。之前共享报告保留于 `pre-eligibility-gate/`；首次归档工具错误 `eligibility-1c55ec60/failure.json` 保留。**最新全局reports已属于1c55构建，旧候选审计不能直接引用它们假称旧EXE新验证。**覆盖矩阵已绑定新候选，原始1734注册行完整保留；新增共享零级门只适用于现有13控制器，不赋予其他职业实现状态。

当前仍仅未转职鬼剑士可玩，除缔造者外10角色／实际转职觉醒／完整技能门槛未达到。继续按具体缺口闭合最终属性、移动／指向、完整命中伤害和各职业控制器；不猜保护链，也不以静态数量代替交付。原客户端／PVF／用户存档未改，缓存与输出在D盘，构建／GUI串行。本轮测试窗口已退出。

## 先前候选：原生分轴积分、PTL算术与证据闭合（2026-10-18 历史）

本节优先于下方历史“最新／最终／当前”记录。候选仅位于 `cache/build-next/dnf_native.exe`，SHA256 `2567d4d5288e040b26c64e0f52e41b9ff070a15fdfd8a0d292b58805f26a70b0`；完整构建与核心／音频测试日志 `reports/combat-native-reverse/build-test-motion-final-20261018.log` exit0。正式 `playable/` 仍为旧7a85包；`build/` 因上轮旧脚本误执行 `--help` 被编为 `fc8657dd351a58ae32619fe0e9f340f08b44bcf4b47d7852173b55fbbc4f920c`，不再与playable相同，该build目录没有完整通过记录。`tools/build.py` 已增加参数解析、项目内路径限制和运行中游戏检测，`--help` 不会构建；新脚本已用隔离目录完整构建通过。构建缓存／临时文件仍在D盘，未覆盖正式包或用户游戏。

- `axis_motion.hpp/cpp` 实现当前1031 `8B1C40` 的算术子集：有符号i32加速度乘积、平均速度积分、有限加速度时长的分段积分、到期保留末速度、每tick位移±2000限制。人物跳跃和怪物浮空已接入，按demo时钟每tick的16／17ms推进；零时长到期清理已修。来源链、碰撞、属性修饰、FPU及适用范围分开。430起跳／980重力、60Hz调度、落地清零仍是本地重建；高度继续double累加，与原生float32位置存储有差异。不能称完整原生跳跃还原。
- `particle_motion.hpp/cpp` 实现 `E581E0` 的straight-line／keep-last未投影轴积分，保留逐步float32、T=0先i32回绕、非零末速继续移动，负时间显式拒绝是适配边界。10项专项含固定bit-pattern检查；**没有接入十字斩实体运动**。PTL400→0／280ms的未修饰积分约56，仅为分析样本；技能、装备等最终倍率及对象消费者仍未知，当前十字PO仍常速重建。
- 十字身体frame6重新setATK／resetHitObjectList已在前一候选接入，专项 `gorecross-body-hit-test.json` 冻结目标位置以单独排除击退离框：两次身体命中在tick6／27，reset在tick24。两次原生请求同一selector24，保护selector到具体CHR ATK未恢复；本地两段仍用明确标注的GoreCross1重建映射，不能写成原版两段分别对应1／2。
- 最新普通操作 `reports/runs/input-20261018T085401`：11记录点，三连／跳跃／双击跑／冲刺攻击／持方向恢复步行／普通攻击／重新双击及十字双向4层→血十字→释放通过。设置 `input-20261018T085436`：5点，四音量／血量倍率／实际退出重载通过。两者hash均为本候选，窗口置顶可见，用户存档hash不变；它们是SDL窗口消息输入，不是物理键盘或IME测试。
- 最新accepted-hit诊断fixture `effects-20261018T085500-95f484`：15案例／202截图／74检查通过，窗口置顶可见、exit0、用户存档不变。当前人工已查看弱击左向的1120／1200／1270ms帧：碎片可见→明显变淡→截止后不见；旧强击样本后段已出屏，不能据空画面声称看到渐隐。700ms上限／末150ms淡出是用户指定测试调整，碎片强度／方向速度公式仍为重建。旧 `effects-20261018T083603-1842e7/effects-acceptance-initial-boundary-failure.json` 保留，不覆盖失败。
- 新只读证据：`jump-physics/` 78代码窗口／16数据窗口／14组检查，闭合CHR命名字段→bank0（jump power +3C0、jump speed +3D8、weight +3F0）、state6启动参数与积分；bank0→bank3最终修饰仍受保护。`particles/straight-keep-last.json` 与枪手followup111代码／16数据窗口、PTL模式和SKL路由已复核。`skill-data/` 直接PVF重提取证明static临时3C8→runtime3B8、level-info临时3E8→runtime3CC，cooltime-level为独立临时3DC；59C学会等级写入仍未知。导航误名／相邻guard错配均保留更正记录。女格斗静态证据另见 `fighter-attack/`，未接入其他职业。

普通洛兰＋深处 `reports/runs/input-20261018T085839/acceptance.json` 已 **pass，48记录点**，hash与本候选一致：两副本首领／结算、任务补给、德利拉／维修、回城及实际退出重载通过；技能等级／绑定和两副本通关记录重载一致，用户存档未变，测试开关关闭，最终HP139／MP1。技能配置为上挑2、鬼斩／波动8、裂波5、其余1，不能称原版全Lv1平衡。测试窗口置顶可见并正常退出；原客户端未关闭。过程日志 `reports/combat-native-reverse/flow-deep-motion-20261018.log`。已查看本hash的十字血十字、德利拉维修和深处初始战斗帧，不判UI或图层整体一致。

当前仍只有未转职鬼剑士可玩，**未满足除缔造者外10角色及实际转职／觉醒／完整技能交付门槛**。下一步仍是闭合属性汇总／移动加减速／技能与命中资格／各职业完整控制器、PTL最终倍率与对象更新和原版动态对照。普通UI、物理键盘、听音和全职业画面尚未验收；不把静态检查数量当可玩完成度。最新候选证据交叉审计使用 `tools/verify_combat_candidate.py`，记录在 `reports/combat-native-reverse/candidate-verification-20261018-motion.json`；它只核对来源／候选／当前报告身份，不替代原版验收。主文档与源码已同步，构建／GUI继续串行。

## 先前候选：设置、音频、输入及十字 ANI 事件（2026-10-18 历史）

本历史节对应旧候选 `2b5e4b6ed69f20beb60942dc36fd6ca7827edc29aaf96a2f28988c4432b71f76`，当时build／playable均为7a85，最新身份看首节。完整日志 `reports/combat-native-reverse/build-test-dash-event-input.log` exit0。核心30标签及现有专项、事件11项、身份85项、用户反馈30项和音频30项通过；音频采用SDL dummy，不能当听音验收。

- `audio_catalog` 完整遍历MAP声音ID并按XML类别分出Music／Ambient／Effect，修复只取首ID漏掉洛兰BGM。同曲跨房不重启、失败可重试、音乐不占32音效槽；各bus有独立音量及非零PCM诊断。原混音基线仍是本地重建，原生XML／FMOD局部证据另见 `audio/native/`，不能将XML负值当dB直接套用。
- `DemoBalance` 默认普通2倍／首领3倍，相对旧demo65／240HP；1..10可调，新副本冻结配置，旧session无设置维持旧1／1，已保存怪物实际HP不改。独立settings保存四音量与倍率，保留未知字段。RegionSession schema3；角色schema4保留未知根／角色／identity字段、兼容旧档和`-1`空快捷槽。`CharacterIdentity`／`SkillKey`只建立真实身份，未恢复控制器明确拒绝，不冒用鬼剑士。
- 共享死亡碎片显示最多700ms、末150ms淡出，保持原PTL的3000ms及真实轨迹年龄；这是用户指定调整。跳跃／自由移动清除攻击pose override，跑动多帧回归通过。冲刺攻击须由当前dash状态进入，结束后held方向只走路，重新跑动需新双击；旧230ms窗口仍为本地适配。连突刺使用当前SD `damh start frame=3`，不允许过早扣蓝或反复X无限重启。
- `AnimationEventCursor` 从当前1031 prop23→keyframe+BE→instance+12E→pending+1E8生产／消费链恢复单pending语义。十字斩绑CHR etcmotion25并创建4条SQR附层，身体frame6进入第二阶段，附层index1自己的event1进入phase2，下一tick创建object20028血十字，普通mode0在身体frame10退出；原ANI时长不改。源100%时钟的500ms事件／730ms退出只是当前映射，不能固化为全攻速时间。

前台普通窗口消息设置测试 `reports/runs/input-20261018T081759` 5点pass、实际退出重载及用户存档hash不变，已查看新设置页，返回按钮上方旧提示遮挡已消除。普通输入 `input-20261018T082229` 11记录点pass，并完成十字双向短阶段采样：三连／跳跃／双击跑／冲刺攻击／held步行／后续普通攻击／新双击，以及普通R的4层→第二斩→血十字→释放／独立PO继续，用户存档不变。它们不是物理键盘／IME或原版动态一致性验收。失败 `input-20261018T082049` 保留（测试把退出后phase0错误分类为attached，未捕获released；工具已修），此前不含十字的 `input-20261018T081916` 单独保留。

本轮较早普通洛兰＋深处 `input-20261018T075455` 43点流程pass，但 `user_saves_unchanged=false`，不可列存档保护通过。用户同时运行其他客户端的可能性不等于归因证据；未回滚存档。旧设置 `input-20261018T080238` 仅适用于其旧EXE。

新增分类证据：`animation-events/` 静态43项；`movement-input/` 与 `skill-controllers/swordman/` 的输入描述符、十字阶段／退出清4层、连突刺／跳跃局部链；`advancement/` 静态10079项，明确当前菜单分支数和名称门；`fighter-attack/`、`gunner-attack/` 继续只读取证，状态与数量看各自最新verification。PVF1734技能／17341来源交叉核对只证明来源保真，不能当可玩数量。

本历史节待办的frame6重置、死亡期限采样和分轴算术已在首节推进；PTL最终倍率／消费者、跳跃最终参数、后跳位移36、技能加减速90／110ms、伤害／命中暂停／受击硬直仍须继续追证。不得用局部测试发布为完整全角色版本。构建／GUI串行，保持前台可见和隔离存档，不覆盖运行中的EXE，不关闭原客户端。

## 最新实现：全角色来源模型、默认续刀与原生合同（2026-10-18）

本节优先于下方历史构建及“当前”描述。新增 `character.hpp/cpp` 的平台无关 CharacterCatalog，按当前 `character/character.lst`、`skill/skilllist.lst`、各 CHR／技能表／characteretc、default.etc 与实际7份 `data/skill/*.sd` 建立来源模型。11角色／1734技能注册行、1497动作槽、670ATK槽均保留原始字节、有序token、offset、顺序、重复／空槽与PVF来源；初始／成长／觉醒字段区间分别保存，不用第一条字段代替继承计算。仅CreatorMage标记用户允许暂缓，其他角色仍需完整还原。当前可玩控制器和选角仍只有鬼剑士；来源解析不代表其他角色可玩。

`World` 的人物动作由真实CHR绑定解析，13基础主动技能与被动核对真实注册ID，不再制造技能／动作目录。`dnf_inspect CLIENT --characters source _ OUTPUT.json` 可导出完整来源；`summary` 模式不含原字节／完整token。全角色静态审计入口 `reports/combat-native-reverse/all-characters/README.md`；独立C++导出与Python读取核对工具为 `tools/verify_character_sources.py`。

已接入当前1031原生默认鬼剑士取消帧 `[5,4]`，零基索引，消费者 `869EB0`，初始化 `D14710→D15137→CAE400`。在有续刀输入、地面、合法索引且本地暂停解除时，按当前源帧续段，清去重并重置pose0；末刀无第三阈值，不自动循环。当前100%动画时钟下首刀250ms、第二刀200ms可续，第三刀550ms完整回收；没有续刀输入仍完整播放600ms首刀。固定250／200ms不是原生全攻速规则。`basic_chain`事件记录旧／新comboIndex与源取消帧。50项专项覆盖四武器双向、晚输入、无输入和暂停边界。原生额外 `+1A4` 阻挡字段、完整输入请求／提交、转职覆盖和攻速还未恢复，不能把本地hitstop等同该字段。

`collision.hpp` 统一近战与PO的原ANI XYZ盒接触：左向为 `-x-width`，非零输入盒边／面相贴算接触，可选交集允许0 extent。非finite拒绝属于移植安全边界；原生异常浮点、完整缩放／分类／接受攻击过滤仍未完整复刻。近战X扫掠继续明确为重建策略。ALS先收齐 `[use animation]` 再编译add/remove，其他命令保留tag／原值／offset并明确诊断；未把未知的none-effect字段或draw-only命令猜成普通add。

三条只读审计入口：`state-attack/findings.md`（默认表、状态请求／提交、移动资格／倍率）、`resource-render/README.md`（ANI/ALS实例、时钟、速率、层序）、`collision/README.md`（接触与HP写入，完成状态以文件为准），均位于 `reports/combat-native-reverse/`。原生 ANI速率百分数100=正常，不能与CHR1000基准混用。原生setHp链已追到 `5B6EB0→slot2A0→860520→827500→11A0930` 及部分死亡触发，但碰撞→接受命中→伤害→HP整链尚未闭合；没有将静态地址或其他职业表当成完整运行时实现。

最终完整构建 `reports/combat-native-reverse/build-test-final-source-path.log` exit0：核心30标签、catalog1828、native attack50、技能10、外观23、怪物110、区域17、命中反馈122。ATMage证据精确路径已修正为 `sqr/init_character.nut`。**当前build/playable EXE SHA256均为 `7a85bd452feb77b2000cec489ed0c35574c4da1d74d00b82f0e80678767fac30`**，不是下方旧24ad。最终inspector `9fd9430ae88834eb9b1f406f9d3da4de86d14cd3c0f3a37f7c1aea7312719b59` 已独立复跑464／464来源核对，报告 `catalog-crosscheck/20261018T070529.444202Z-9fd9430a/verification.json`。构建和TEMP继续位于D盘，原客户端、用户存档和历史失败证据不改。

最终发布EXE的普通窗口消息流程 `reports/runs/input-20261018T070550/acceptance.json` **pass，25个记录点**：创建、三连击、跳跃恢复、任务补给、艾尔文／入口、洛兰4房清理／首领、德利拉对话／商店／维修、回城及实际退出重载；技能／绑定和地下城通关记录重载一致，用户存档hash未变，正常模式未启用作弊。普通事件流实际记录frame5/4的basic_chain。最终HP132、MP64；上挑Lv2、鬼斩／波动Lv8、裂波Lv5，其余Lv1，是demo学习配置，不是原版全Lv1平衡验收。两次窗口均visible_on_top=true；本次用窗口键鼠消息，不是物理键盘／IME测试。实际查看02b-attack2、02c-attack3、06-room-5、07d-delilah-repair四张本轮帧，身体／武器／剑光与流程界面可见，未判整体UI或原版动态一致。当前未重复深处／104秒技能smoke；下方历史成功不能冒充本hash的新结果。

发布／来源／流程交叉核对 `reports/combat-native-reverse/release-verification.json` **36／36通过**，记录EXE／test／inspector、payload全文件hash、最终build log、7组专项、464项来源报告、当前流程／重载／窗口、查看截图及修改源码hash。运行日志无错误只表示进程状态。当前新包入口仍为 `playable/play.cmd`，依赖完整同级1031资源；当前测试进程已正常关闭。

只读原生证据已固化：state-attack共148代码窗口、7份SD、3份普攻ANI和4份SQR均匹配；resource-render复核37代码段、70引用VA、2跳表及1179ALS；collision复核239项（220磁盘／静态＋19公式示例），不把它们当native动态执行。HP slot2A0只有相应候选表走860520，其他表不同，11A0930保护gate未完整仿真。新增 `attack-speed/README.md` 和audit.py找到静态初始化14FD480传100给global1A6FBB0，以及virtual+708→833420写object+3194后以n*100*.001更新ANI；14项磁盘检查通过。仅证明静态默认与局部生产者，g实际运行值、CHR／武器最终n和全部状态倍率仍未知，当前运行时继续100%时钟。

并行第二批只读调查已固化：`gunner-attack/README.md`与contract.json恢复独立抬枪／射击／装填、5类GunInfo和15条PTL→注册ID→OBJ链，装填最终idle/move/cancel退出及完整弹丸消费者尚未闭合；最新窗口／表数量以verification为准。`skill-eligibility/findings.md`／contracts.json验证94个native切片、17份PVF原文件、15份有序字段/token模型；sq_IsUseSkill是有副作用事务，命令状态门、0级拒绝、MP写入及CD存储／关联技能传播有局部证据，但脚本保护转发、消耗公式、源auto到runtime+374映射和通知时机未闭合。13源SKL显式auto仅46=1、8=0、77=1；三段斩explain支持结束/中断起CD，但不据此猜所有auto0的共同结束行为。`hit-acceptance/README.md`／contracts.json验证369项（362静态磁盘＋7分析示例），恢复目标查询／登记、部分资格／节流、getTeam/isEnemy、Packet静态复用及55字节发送；+5A0清空周期、接受攻击到HP及无敌／霸体仍有保护和消费者缺口。没有改动这些新调查对应的运行时代码。它们尚未接入其他职业，请继续从具体入口恢复／实现，不重复只统计目录，也不宣称全职业完成。

补充原版现有进程只读观察：PID61396、路径D:/game/DNF1031客户端-20260708/DNF1031客户端/DNF.exe，其EXE hash与本研究一致，PVF为ca756b7103a91628cffdf42fb745e9185fd5937deb229289a74831aa30500e1f（不同于工程d13ce）。未启动／停止它、未写入、注入、远程调用或发送输入。模块枚举访问拒绝与直接header不匹配两次失败保留；WOW64 PEB只读查询得到base400000并核对三处live机器字节一致后，5秒100次采样全匹配候选vtable1706A24，但C0当前ANI均null，未得到动画帧或rate，不能称原版动态时序已验证。报告 `attack-speed/live-readonly-20261018T071852.110112Z.json`。global倍率仅保留编码存储，未解成运行值。该用户原版进程保持运行，不能按旧“无运行中游戏”注释误关。

## 最新用户范围：全角色战斗，缔造者可暂缓（2026-10-18）

最终战斗还原目标扩展到当前1031 PVF注册的全部角色／转职／技能；用户最新明确允许暂时跳过缔造者（CreatorMage）的运行时还原及验收，其原始数据、资源索引及来源必须保留。其他角色不在此例外内。现有可玩包仍仅为鬼剑士测试版，不因范围扩大就宣称其他角色已实现。

本轮沿现有代码缺口追查原 `DNF.exe` 的移动、普攻、判定、行为、状态更新、技能资格、技能动画／渲染及 PVF／静态资源读取链。三个并行调查分别写 `reports/combat-native-reverse/` 的独立报告范围：原生攻击／状态链、全角色CHR／技能／SQR注册普查、资源加载／渲染合同。主代理负责实现整合及串行构建／前台验证。不能把注册数量或字符串xref当成行为复刻完成。根 `agent.md` 与本目录 `AGENTS.md` 已同步此新范围，以下“仅鬼剑士”描述是当前交付或历史阶段范围。

## 上一轮24ad：命中反馈、输入边界与原生攻击链调查（2026-10-18）

用户优先战斗手感，并新增要求基于已有DLL注入／反汇编成果分析DNF.exe的技能与攻击。当前已编译并打包的build/playable EXE SHA256为 `24ad6fa1cb7a0d26c45b867d578e3be92315329e33ed71622d548520b5636e09`。`build.cmd --test`通过：核心30、外观23、技能9、怪物110、区域17、命中反馈122项；日志 `reports/combat-feel/build-test-held-turn.log`。最终串行前台验证已完成：package、普通洛兰＋深处、13技能双向104秒、怪物特效fixture、六场景三分辨率均exit0；`reports/combat-feel/held-turn/release-validation.json`记录当前24ad构建身份。发布/source/window审计84项通过，见 `reports/combat-rework/verification.json`。普通流程41记录点、洛兰路线0→2→4→5，深处0→1→2→3，自然升级后最终Lv4/XP8550/HP148/MP90，德利拉／维修／返城／实际重载成立，当前轮用户存档未变；result_panel_actions为空，结算页本轮自动出现。该普通run同时作为审计的input和deep输入，不冒称两次独立普通游玩。技能有182基础截图＋78短阶段补帧，怪物fixture58项通过；诊断fixture和窗口消息输入均不等于物理键盘／IME或原PC平衡验收。实际查看深处结算/重载、裂波/崩山补帧和双向联系图，裂波亮叠层／黑芯仍未判一致，视觉及原版手感仍未通过。

已完成基于DLL研究成果的首轮静态延伸：`reports/combat-native-reverse/entry-audit.md`与JSON。六份1031 ASM字节、另六段碰撞合同范围hash与当前DNF.exe匹配；从当前磁盘EXE新增恢复8256A0→7FE5C0动画切换及109CA90倍率消费者（保护整数×未知全局浮点×0.001），并确认附属ANI倍率传播和脚本包装器setCurrentAnimation名字。299候选虚表及290/2/7实现频数不是技能ID，尚未证明鬼剑士普攻归属；普通攻击取消阈值、完整hitstop／硬直／HP写链和碎块速度公式仍待继续。86资料保持版本隔离，本次没有注入或修改原客户端。

本轮修复：CHR四武器命中信息按原subtype0/1/3/2继承；ATK按有序token读取hit info，保留显式0、负数继承与未知附项。Actor局部hitstop冻结动作、位移和附着特效，世界输入/CD及独立弹丸继续。普攻本刀锁向，续刀边界读held方向并从pose0开始；暂停中的技能热键保留200ms，解冻后重新检查、仅消费一次，不增加技能间取消资格。三段斩暂停期不翻面，解冻后恢复仍按住的转向；死亡立即清理暂停。多段命中间隔随owner局部时钟平移。

崩山普通段最多2次，原frame4起末击独立去重，保持每目标总计最多3次，基础职业不生成无资格的hopsmashsub。四武器×双向实际源框接触回归通过。裂波pulse用PO vaneslash.atk，完整final吹飞调用尚未恢复。暂停按ms、近战双方/PO只停目标、受击方倍率分配及frame4调度仍是重建；CHR攻速850、普攻精确取消窗、350/250ms固定硬直仍存在差异，不得宣称原版手感一致。

中间F30的前台package/deep/skills/effects/scenes全exit0，记录 `reports/combat-feel/release-validation.json`。随后532构建的普通洛兰通过、深处首领已死且有真实clear记录，但结算窗口观测超时，保留 `reports/runs/input-20261018T061934` 为失败；同一时段另有普通运行 `1792304410284-34496`，用户已确认同时手动启动操作客户端，用户存档变化未回滚。不能直接认定超时由用户操作造成。532的skills/effects/scenes通过，不能冒充当前24ad验证。`verify_flow.py`现先要求真实clear记录，若结果页已关闭则通过可见“通关结算”按钮重新打开，并记录result_panel_actions，不注入状态。

缓存已配置：build.cmd及直接tools/build.py均将TEMP/TMP/TMPDIR放项目cache/build-tmp，Clang module及可选ccache/sccache亦在D盘。C盘检查无能确认归属本项目的残留，未删共享/未知缓存；约24GB可用不是本次清理释放。详见 `reports/build-cache/inspection.json`。

原生逆向资料审计写 `reports/combat-native-reverse`；攻速续查 `reports/combat-feel/attack-speed-followup.md`。当前PC定义1000为100%速度，装备attack speed以0.1%修正，不能把CHR850当加速85%或拿hit info未知附项当攻速。普通三刀无框回收350/450/350ms，男鬼剑士native取消阈值未恢复；其他职业/DFQ/86地址与数值不可直接套用。

## 上一轮：正常洛兰／深处已通过，视觉仍为局部复核

该历史轮发布为a3da，未改C++或重编EXE。本轮修复`tools/verify_flow.py`在障碍边缘追2px中间点的导航：当下一转向在当前位置可直达时跳过微小段，并在8次同向无位移后明确失败。源码确认普通步长3px／跑步5px，原`x=502→504`目标比步长小、下一步撞到`x=505`障碍，所以旧流程持续不动。原失败`input-20261018T004411`保留；其几何复现和脚本语法已通过。

新`reports/runs/input-20261018T011529/acceptance.json`正常`--deep`通过39点，洛兰路线0→2→4（实际经过原卡点同图`map/lorien/8.map`），自然获得经验并交任务102后Lv3进入洛兰深处，深处3→4→1→2完成，最终Lv4/XP8150/HP122/MP76。两次德利拉对话／商店／修理、返城和重载均通过；两副本通关记录保留，用户存档未变。窗口`visible_on_top=true`，输入是SDL窗口键鼠消息，仍不代表物理键盘／IME验收。没有状态注入、god或freeCD；技能等级仍为测试器普通UI配置，不是初始Lv1平衡验收。

本轮直接看完a3da的13张技能双向联系图、8张技能原图、9张怪物效果图及7套原AVI联系图。十字双向0.65秒前方小红十字仍在，1.10秒无大附着残影；怪物850/1250ms横躺、1750ms站立，左右反向碎片与强弱位移差可见。视觉仍未整体通过：蹲姿、垂直碎片、银落连续闪光、卡赞渐入／消失、裂波黑芯和崩山黄刀短窗未充分采样。AVI与当前十字／裂波／卡赞的定性色差仍需核对阶段、混合、背景及资格，不能按目测直接染色；来源混合的1/2均ADD尚未证明原生等价。

执行环境已确认C盘free=0、D盘约97GB，`exec_command`间歇报`helper_log_failed OS112`；自动审批另报403，未执行清理。普通短命令恢复后，用隐藏Python测试helper成功启动置顶SDL并完成上述深处流程。源／存档／发布包／失败证据没有成功删除。后面的“环境阻塞、尚未跑深处”段落是此前过程记录，以上实际成功run优先。最终审计仍需确认`deep-audit.stdout.log`结果；纯工具改动不要求重编旧a3da。

## 当前权威状态：战斗与艾尔文／洛兰整合（2026-10-18）

用户最新优先战斗及赛丽亚→艾尔文防线→洛兰／洛兰深处，新增 `../逆向部分结果参考` 仅为不完整参考。此前UI／装备成果继续保留；以下旧“UI优先／不改战斗”记录均是历史，不是本轮约束。仍须先读 `../agent.md`，原客户端／参考包只读，旧GBA实现与派生素材禁用，DFQ UI禁用。用户已授权独立任务多代理并行，构建与GUI须串行协调。

当前 build/playable EXE SHA256：`a3da200d96615ecffd2e3ae8b65e530a870ec768148ccbb322a94eea6657bf31`。已实际重打包，可双击 `playable/play.cmd`；仍依赖完整 `../DNF1031客户端`，不是独立资源子集。用户存档保护不变。

- `EffectPlan` 从当前源OBJ基础／附层及命名ALS编译有界视觉计划，保留来源、offset、原始时间、层和实例。补地裂源Fire主波及刀光、裂波upper/smash/dust及三次pulse普通层、银落ring/dust/插值flash、十字同轨迹normal/additive两层。附层不重复伤害；去掉独立效果旧中心距离预筛选，使用源框及非循环hurtbox时间。十字 `(85,0,82)` 仍是跨版本观察支持的重建；角色slash对在最后短事件帧结束550ms截止，避免950ms源占位形成固定大十字残影，原ANI不改。
- 崩山ready400ms，第二身体frame4=600ms落地；按住0..200ms映射源距离50..200／高度50..120，水平smoothstep/垂直抛物线仍为重建。正常未转职角色 `bloodyvigorous`=0，只有源被动63明确存在才启用四层冲击。银落峰值高度门槛50是重建，落地始终解锁。基础月光／十字不白送转职派生。
- `MonsterMotion` 支持MOB直接ANI和ACT的MOTION BASE/SUB/XY/ALS；其余ACT行为保留未执行诊断。受击damage1/2分开，真实hit ANI、二维衰减推力、浮空再次命中追加升力。独立死亡仅由有效 `[last action]` 选择；共享死亡冻结完整致死姿态→白剪影→原palette石块＋源flash/smoke/PTL，删除旧5×2矩形切尸。XY方向远离实际接触源；速度综合接触速度、伤害比例与ATK推／升力，公式明确重建。
- 死亡中间态JSON保存完整源身份、相对时钟、锚点／冻结姿态、impact和确定性碎片初始条件；恢复按当前源重编译，不重新发击杀／奖励。旧档未保存随机初值不可能精确恢复，保留安全重建边界。
- 实际审图发现并修复旧动画路径污染down／overturn切换。进一步核对官方资料和源IMG：overturn是倒置，不是通用起身；落地直接采样源down末帧（哥布林横躺），倒地等待150..500ms，之后源sit蹲姿过渡100..400ms再stay。哥布林实际500/150ms；这些触发／限幅是控制器重建，源两段10000ms飞行占位不当作20秒倒地等待。审计见 `reports/monster-rework/recovery-audit.*`。
- TWN／MAP六元门矩形驱动房间↔城镇↔入口；缺失gate.map显式别名(r)gate.map。安全落点先扣除全部障碍。NPC近距点击／Enter共用检查；德利拉只在本次副本通关的首领房一次性出现，普通商店／任务／修理可用。金库／邮件／活动／罐子未开放服务明确禁用。全部35源MAP保留，合法普通池33=洛兰14＋深处19；7.map三门与两列DGN不兼容，5.map旧救援笼子没有当前普通DGN入口，不伪造连接。

最新统一构建 `tools/build.py --test` 已通过：核心30标签、技能9项、怪物110条断言（含跨时钟死亡恢复及落地／蹲姿回归）、区域17项、外观23项。最终构建日志 `reports/skill-chain-rework/build-test-final-4.log`。早期final日志中私有测试接口编译失败和20秒占位回归失败保留，最终已修。

最终发布包普通输入 `reports/runs/input-20261018T003634` 已pass：23记录点，新角色、三连／跳跃／恢复移动、正常1016领药／101交付／林纳斯购药、洛兰三房路线及首领、德利拉对话／商店／修理、返城／实际重载，最终HP172。药水经I消耗品右键，遵守实际组CD；无状态注入／传送／god/freeCD。上挑2、鬼斩／波动8、裂波5、其余1，非全Lv1平衡验收。窗口置顶，但Windows拒绝物理焦点，使用SDL窗口消息，不代表物理键盘／IME通过。用户存档hash不变；本轮访问源范围505项，非依赖全闭包。

最终发布包诊断效果 `reports/runs/effects-20261018T003844-53b5a0` 已58/58，15样本含四方向强弱共享死亡／两种ACT死亡／受击追击／崩山被动对照；新增检查验证down实际路径、短时间恢复。它注入accepted-hit，不能替代普通碰撞验收。最新13技能双向104秒采样 `reports/runs/20261018T004005-34f514cf` 正在收尾，最终画面复核和洛兰深处普通流程尚待本轮继续记录，不能预写通过。

必须保留失败：`input-20261018T001647`旧机器人桶前超时；`input-20261018T002135`清四房后HP55入首领死亡；`input-20261018T002924`硬走NPC非地面点失败。工具已改观察真实障碍的普通按键导航、交互半径内可达NPC落点、源双向门BFS、正常药剂补给和普攻续段。旧b04 EXE的 `effects-20261018T002018-329d30/visual-review.json` 倒地路径失败和 `20261018T002514-367ed4b4/visual-review.json` 十字长残影发现均保留，不把旧56项或日志空视作视觉通过。

来源：本地PVF `d13ce454567197bb4617cad4d0e472f609a1ec5cf2256462d780547be878607d`；原EXE `246b838163fa7c71aa0445fa4aafde04e7ac72aa72855a4b2a7eaeed5eeae264`。新技能包EXE/PVF均不同且自身controller_complete=false，只能支持部分观察；347份原字节／205ANI完整模型及逐项差异见 `reports/skill-chain-rework`。怪物包同EXE异PVF，本轮313成员闭包／39NPK范围核对成立，不宣称全PVF相同。

尚未完成：原生完整技能创建／时序／条件、伤害防御成长／出血及完整公式、血液／年龄分级／ACT生成行为／特殊声音、碎片独立深度排序、全部UI像素复刻、转职／觉醒与金库邮件活动等系统。整体视觉仍未原版一致验收。

收尾命令：`tools/verify_flow.py --binary playable/dnf_native.exe --deep`（先正常通洛兰自然升级再进深处）；`tools/run_demo.py --binary playable/dnf_native.exe --flow-smoke 30 --flow-scene-seconds 5`；`tools/skill_contact_sheets.py <SKILL_RUN>`；`tools/export_runtime_manifest.py <RUN>`；`tools/review_combat_release.py --input-run <INPUT> --skill-run <SKILL> --effects-run <EFFECTS> --scene-run <SCENES> [--deep-run <DEEP>]`。PowerShell5.1，Python `D:/ProgramData/anaconda3/python.exe -X utf8 -B`；中文管道先设UTF8。不要运行中覆盖EXE。

## 以下保留为历史交接与证据

> 2026-10-18 01:25 最新：按用户要求优先修 UI／装备／时装，本轮不改战斗控制器或公式。已用原 NPK 重做右侧窄版物品／装扮栏，新增真实 EQU 外观模型、武器具体变体、时装完整分层替换、穿脱、七项只读组合试穿；选角／场景／预览共用实际外观。build/playable SHA256 为 `ba6f13d48c996f669c4bf2183af1d1528078a29ea6abba079ceed39827feec40`。发布包 800×600 正常新角色 UI 12 点 `input-20261017T172346`、1280×720 独立外观样本 13 点 `appearance-20261017T172450`（穿脱、左右移动／攻击画面、出售、重载）通过，用户存档未变。30 项核心标签及 23 条外观检查通过；真实图与原参考并排核对，整套 UI 仍未像素验收。最新汇总 `reports/equipment-ui/verification.json`。以下字体与旧交付记录保留作历史。

## 2026-10-18 装备／装扮继续修复

- `appearance.hpp/cpp` 独立于战斗：遍历 EQU 有序字段，保留 animation job、variation 两个整数、全部 layer variation 数字/目录、配套 ANI script、隐藏规则、字段 offset 和完整 Script。默认衣物来自五项源 default.equ。普通属性护甲没有外观字段时不替换时装；同部位装扮替换整组分层，卸下恢复默认。
- `Progression::appearance(Pvf&)`、`equippedIndex/equipped/unequip` 已接入。正常角色不再把武器类别直接映射成全0000图片；club_default 的0,7、时装123,0、skin0,1等独立参数都有真实 IMG 回归。选择界面缓存按角色存档更新，场景与物品预览采用同一外观模型。诊断 smoke 的旧 int 武器类别重载保留，不作为普通装备外观来源。
- `equipment_ui.cpp` 使用 inventory.img 的石门0、装扮11、装备槽21、魔法阵18、活动54/55和 inventory_tw 的三行货币框。标题顺序为 common9/10/11→109/114/115→48→accessory0，横向延展必须 sy=1。背包空格最终改用 common57 的细金边；inventory49是偏蓝软边候选，实图对照后弃用。透明 UI 加近黑底板（颜色/alpha是截图重建，非已解出的原 EXE 参数）。
- 装备袋8×4、装扮袋7×4，分类、超一页翻页、UID不变的显示整理、已装备槽、黑底提示/比较、右键或双击穿戴/使用、右键卸下已接入。从商店进入“背包/出售”后右键出售一件，不在普通I面板把右键误当出售。七项试穿为39147/39530/40728/41190/41830/40307/41488，仅修改局部预览，明确显示试穿/还原；不发放、不存档、不影响属性。
- UI 指针按 SDL 事件维护，按钮按下坐标在同批运动/离窗事件之后优先；右键/双击激活与普通单击分开。没有改 IME/文本输入生命周期。
- 源研究 `reports/appearance-source/README.md` / `manifest.json` / `tryon-items.json`，UI来源/尺寸 `reports/equipment-ui/LAYOUT.md` / `index.json`。原PVF及10份UI NPK范围hash复核未变。`dnf_inspect --export-image/--export-frames` 导出原RGBA与crop/logical/归档元数据；导出图、叠层研究图和contact sheet不是游戏截图。
- `tools/verify_flow.py --appearance-fixture` 复制核心测试生成的隔离角色，明确不是正常获取装备；该样本用于真实穿脱、同部位替换、场景/选角/预览一致、重载及未知字段保存。没有在窗口运行时改游戏状态。`--ui-only` 从新建角色走正常UI，不接战斗；两个最终发布验证均置顶可见，Windows拒绝前台焦点，不能称物理鼠标/键盘通过。提示框截图使用普通单击和F12同批消息，避免环境焦点导致自动指针回0。
- 旧失败 `appearance-20261017T170716` 为测试鼠标点击被同批运动覆盖；`appearance-20261017T171645` 为截图辅助点击触发双击且销售时未切回装备页。修正指针事件优先级与测试流程后最终通过，旧证据保留；不掩盖旧失败。

尚未完成：完整tooltip字段/品质浮动，精确tab宽/锚点与拖动，负重上限（当前只画源空底条），宠物/徽章、特殊时装控制器/光环/mask/武器装扮全部组合。身体层号1000仍为明确重建约定，源CHR未证实；EQU的武器650/2790、衣物1200..等是源数字。创建/任务/NPC/商店整体原版布局仍未完成；本轮不改战斗控制器、数值、AI，也没有重跑完整战斗/地图耐久来冒充本轮UI验收。

复跑：`tools/build.py --test`；`tools/package_playable.py`；`tools/verify_flow.py --binary playable/dnf_native.exe --ui-only`；`tools/verify_flow.py --binary playable/dnf_native.exe --appearance-fixture --resolution 1280 720`；`tools/review_equipment_release.py <UI_RUN> <APPEARANCE_RUN>`。用户可双击 `playable/play.cmd`，I→装扮→试穿查看；实际装备通过物品栏穿脱。

> 2026-10-18 00:16 最新：已优先处理用户新增字体参考。`Fonts/msjh.ttf` 实际为 FangSong/仿宋；Windows 运行时新增进程私有字体、核对源 glyph/hint/metric 表、GDI 灰度网格校正，stb 无 hint 回退保留。亮色字芯与紧凑黑色渐变描边已接入，NPC 名称改为暖金色、12px 与实际字宽居中。build/playable EXE 均为 `040a5d0d34f798c46c379b1c95f599ad53eeab15ee734bc59fb108c7bcdf83e5`。29 项核心标签、字体专项、发布包 7 点 UI 消息输入、六场景置顶 smoke 通过；用户存档未变。完整 UI/地图/技能视觉仍未通过，不得宣称像素级一致。以下旧交付记录保留为历史。

> 2026-10-17 当前整合：C++ 版本已从固定 s0/4/b1 路线切换为原始 DGN 门位生成洛兰/洛兰深处房间，加入任务、商店、维修、装备、掉落、背包、任务面板和 schema 3 区域存档。`tools/build.py --test` 通过；前台真实窗口流程 `reports/runs/input-20261017T140811/acceptance.json` 通过（19 个记录点，按源迷宫通关并重载），六场景 smoke `reports/runs/20261017T141512-f8d55fb8` 通过。对象解析与 `[do not pass]` 碰撞已加入，需在下一次前台回归中继续检查桶/石柱遮挡。最新构建 hash 以 `docs/IMPLEMENTATION.md` 为准。古代 1500/1501 保留来源但锁定；未抽到的 source MAP 变体不伪造门规则。

先读 ../agent.md、AGENTS.md 和本文件。用户已授权持续实施及多个进程/子代理并行做文档、实现和研究，分开写入范围并协调构建/运行；不反复询问是否继续。旧GBA代码和派生资产禁用，本轮不修改GBA；PC/PVF为内容权威，原客户端/官方文档/研究库只读，DFQ UI禁止参考。

**视觉整体验收仍未通过。** 用户指出的页面/UI/地图/图层错位成立；旧“错误计数为空”与旧视觉判断不能代表画面正确，已撤回并保留旧失败证据。当前修正有真实截图和来源依据，不能写成完整复刻或完全无错误。

## 历史可玩编译交付（2026-10-17 20:45 后）

用户本次要求编译可游玩版本，并确认攻击字母键问题是输入法导致、要求暂且不论。因此本轮未修改 main.cpp 的文本输入生命周期，不再追查 IME；游玩先切英文输入法。

发现并修复独立战斗缺陷：四种武器普通 attack2 的 type15 攻击框都在 c 层，身体/b 层无框；旧 World::attackFrames 只读 b，导致第二刀只有动画没有命中。现合并身体与 b/c 原框，沿用每刀目标去重。原 ANI/资源/时间/伤害参数不变。

- tools/build.py --test：exit0，27 项核心检查标签通过。新四武器×双方向 8 例通过 X 输入队列完整三连，各刀命中 [1,1,1]，无同刀跨层/帧重复伤害，动作结束后步行 51 单位。旧失败 [1,0,1] 保存在 reports/attack-freeze/basic-combo-before.json，新结果 reports/basic-combo-tests.json。
- reports/runs/input-20261017T124314/acceptance.json：普通窗口键鼠消息流程 pass，17 记录点，普攻 attack1/2/3、跳跃、恢复移动、三房清怪、首领、返回与实际保存重载通过，最终 HP147，用户存档未变。上挑 Lv2、鬼斩/波动 Lv8、裂波 Lv5，其余 Lv1，测试开关全关；不能称全 Lv1 平衡验收。
- reports/runs/physical-20261017T124250/acceptance.json：可选 SendInput 测试失败于 Windows 不允许取得前台焦点，未发送物理攻击键。窗口置顶可见，不代表真实键盘/IME 已通过。tools/verify_flow.py 新增 --physical-keys / --binary 可选参数，焦点不符就停止；默认仍使用窗口消息。
- 新可玩目录 playable/，与 build 同级，内含 EXE、SDL2.dll、libunwind.dll、play.cmd、中文 README.txt、manifest.json。双击 playable/play.cmd 无需 Python；共享原 saves，仍依赖完整 ../DNF1031客户端。工作区 play-native.cmd 仍启动同步更新的 build EXE。
- 发布实际入口 reports/runs/package-20261017T124501/package-check.json：8 秒 exit0，窗口置顶可见、全部文件哈希匹配、用户存档未变。tools/package_playable.py 可重复整理现有构建，游戏运行时拒绝覆盖，不复制用户存档或原资源。

build 与 playable 当前 EXE SHA256 均为 `0f2c1bd60bb4950577e5d87d18a27623b294977e7da6c9f486a343e14ccc313d`。本次汇总 reports/playable-verification-20261017.json。已查看本次 02b-attack2.png，未据此宣称 UI/图层整体通过。本轮未重跑六图/104秒技能采样，下面这些属于上一轮证据。原用户存档保持不变，无运行中游戏。

## 当前范围与启动

独立Windows x64、C++17 + SDL2男鬼剑士战斗测试版。工作区play-native.cmd → 工程play.cmd，依赖 ../DNF1031客户端 完整客户端，尚未制作独立资源子集包。

20角色槽、创建/选角、赛利亚→艾尔文→入口选关→按源 DGN 生成洛兰/洛兰深处房间→首领/返回/保存重载。任务链 101/102/103/4301、商店/维修/装备/药水/掉落及 schema 3 区域状态已接入。13基础技能，原身体/衣物/四武器外观/特效层，原MP/CD首项与level info、基础/武器精通倍率。伤害/怪物HP/AI仍为demo重建；MP等级端点和完整装备/防御公式未完，四转职、觉醒、其他地区与完整原客户端内容未完成。UI 仍有明显布局差异。

渲染无固定FPS上限，默认vsync，分辨率可调；模拟独立60Hz。所有来源字节、字段/token、坐标、时间、原点、未知规则和移植接口继续保留。

## 本轮已修

- geometry.hpp::imageQuad合成ANI位移、IMG crop、带符号scale/rotation/facing；SDL四角绘制避免负宽矩形。修复赛利亚原scale(-1,1)导致横向错位。
- 实测800×600：实体原点增加120，TIL仍bg80，far/mid top0；不能把各层一起加120。来源匹配与哈希在reports/visual-correction/research。
- 森林01tile00..03：图像逻辑224×480，14×30碰撞格采用横16/纵12世界单位。原上下门/全部15个原怪物出生点支持此范围；旧纵16把s0 y180、b1 y173误判出界。推导仅对这四份森林资源成立，保留Scene.tileGrids元数据。官方只给网格数，未给通用像素步长。
- 当前六图cameraY固定−120，撤掉错误纵向follow。原s0出生y410.5的下沿黑带已在实际普通流程消失。Renderer::tileSprite在设备像素边界拼接地砖，最终中部宽屏镜头的旧1像素竖缝未复现；源纹理未改。
- MapLayer保留source layer/order、depthY、repeat逻辑尺寸、screen pos/loopY，视差默认100%；非背景实体/NPC/角色/门/效果进入Y队列。完整排序/遮挡仍未完成。
- NPC经npc.lst解析，精确重复才去重。德利拉读取visible on dungeon clear，(0,0)占位不提前画；真正清图生成与修理未完成，issues保留。
- 原800px interface2 HUD取代640px旧底图；12源槽恢复，Space额外槽明确为demo适配。HP/MP液面、冷却/低MP图标接实际状态，菜单有效、未实现按钮禁用。下排窄控件修至(519,559)，上排窄控件未知未猜补。宽屏footer使用源frame84纹理延展。
- 选角原九片面板、标题/开始/创建按钮；创建页原尺寸插画/logo/头像/能力图。其他窗口与部分文字仍测试UI。
- smoke左靶原dir乘size_t溢出已修：先转有符号浮点；每轮完整目标/控制器状态重置；左右起点1/4与3/4，为三段斩完整位移留空间；起点强制检查源可走格。skill-samples.json保留26轮/182阶段状态。115542失败保留。
- 测试启动器和普通流程自动测试均置顶可见；Windows可能拒绝键盘焦点，仍记录visible_on_top。每次新启动记录binary SHA256，不在程序运行时覆盖构建。

此前战斗/存档修复继续保留：裂波捕获/下斩/三脉冲、血十字独立phase1；敌方弹丸迭代中断安全；倒地/起身与浮点AI；普通换场保CD；20槽schema2迁移/未知字段/backup/flush原子替换；DXT1/3/5帧对齐和截断；WAV/Vorbis循环音乐；dummy.til空路径的特例处理。

## 最近实际验证

上一轮exe SHA256：`c3442b39b718cf8a885af78e4eaa6070142f7453b6fe344b39895018c434f309`。上一轮汇总 reports/verification-20261017.json，核心24项标签pass。新增原出生点/可走地面与HUD界限回归，已有30/60/120/144/240频率、停顿补tick、战斗/保护/存档/DXT回归保持通过。

- 上一轮普通输入：reports/runs/input-20261017T122331/acceptance.json，pass、13点、HP142，用户存档未变，技能等级/绑定重载一致；与上一轮binary hash相同。通过真实SDL窗口键鼠消息，不写游戏状态，不使用god/freeCD/传送/强杀。上挑Lv2、鬼斩/波动Lv8、裂波Lv5，其他Lv1；非全Lv1平衡验收。
- 上一轮六图：reports/runs/20261017T122140-a0023035，30.006秒、1800tick、4614帧、exit0；三分辨率，visible_on_top=true，与上一轮binary hash相同。median 6.0609ms/p95 6.3747ms/max 208.549ms，换场有尖峰，不宣称全程恒定帧时。原资源范围hash291项。代表截图/排版已查看。
- 13技能历史修正采样：reports/runs/20261017T121104-70d4f1a8，104.010秒、6240tick、16277帧、182张，26轮13技能左右向。发生在森林网格及最终拼接修正之前，不能冒充当前exe验证；y344测试走廊在两种网格都合法。状态审计18项pass：两向裂波各捕获1/下斩1/脉冲3，命中5/3/3；实际顺序capture→pulse1→downslash→pulse2→pulse3。左三段完整阶段/结束，x840→245，未撞边，仅第一段命中当前靶，不能说后三段全部命中。仅默认短剑，原PC动态金标缺失。
- 最终运行/声音错误计数空仅记录运行状态，不代表视觉通过。历史五分钟110824已完成，不无理由重复；旧111344视觉报告已标WITHDRAWN，115542左靶/左三段失败保留。

视觉观察 reports/visual-correction/visual-review.json；旧/新实际与原参考对照 comparisons/*.png，manifest保留来源hash和相机/人物差异。HUD源像素定位、森林网格研究、技能状态审计各有独立报告。独立13技能图像复核：research/skill-review-20261017T121104-70d4f1a8.json；接缝证据：research/TILE_SEAMS.md和tile-seam-measurements.json（旧212清屏色像素→新0，只针对原失败草地区域）。

## PVF 官方文档 skill

工作区 ../skills/dnf-pvf-reference，已安装 C:/Users/16908/.codex/skills/dnf-pvf-reference，可用 `$dnf-pvf-reference`。使用SKILL.md按需读取MAP/TIL/UI、SKL/ACT/ALS、实体/迷宫和编码来源4篇参考，脚本支持原文行号读取。

85文件已编目并验证源hash不变；实际阅读13核心全文、4大文件选章、Word主文本，其余仅编目。70文本含65 CP949/4ASCII/1UTF8，11RTF、1OLE DOC、3空。两份ANI样例和guide空，不能据其解释ANI二进制；Word未提图像/原页码。skill/checks/安装一致性在 reports/pvf-docs。不要写成85份全读或完整UI手册。

## 历史待办（完成情况以首节最新交接为准）

1. 依据用户实际反馈继续页面/菜单/技能/地图窗口和NPC名称、箱子外观状态。上排窄控件未确认源frame，不猜补。当前整体视觉仍未通过。
2. 原PC动态金标、四武器动态、崩山红色碎片来源；完整六层排序/sort bottom/OBJ layer level、复杂图形混合和遮挡。
3. 德利拉clear后生成/修理；控制器框/偏移/时序、完整声音事件。MP等级端点、轻甲按件/装备防御异常成长仍缺。
4. 保留独立skill、来源/截图/失败记录和移植文档，不从旧GBA补洞。不要重复把已通过的基础稳定性当待办。

## 2026-10-18 字体与掉落视觉修正（本次继续）

用户新增的四张 `pc版本dnf截图/字体参考截图` 已逐张查看。客户端散装字体只有两个：`Fonts/msjh.ttf` 的内部名称为 FangSong/仿宋（28,522 个 Unicode 码点），`Gasinamu.ttf` 只有旧 Wansung cmap，无 Unicode cmap，不能直接作为中文 UI 回退。`tools/audit_fonts.py` 记录原字体和参考图 hash、name/cmap/metrics/样本文字覆盖；`--npk-paths font` 还查到三张技能文字特效 IMG，不能把它们当中文字体库。字体存在于客户端不等于已经证明原 EXE 的字体选择规则。

`HintedFont` 在 Windows 使用原 TTF 的内存副本，仅把 FangSong 名称改为等长进程私有别名 DNFSrcUI，原文件和字形/度量/hint 表不改。GDI 选中后逐字节核对 glyf/loca/cmap/hmtx/hhea/fpgm/prep/cvt，拒绝同名系统字体替代；退出移除私有注册。采用灰度栅格化及 TrueType grid fitting，修正 stb 不执行 hint 而使小字笔画发虚的问题。其他端/未知字体保留 stb 回退。运行报告 `font` 保存源路径与实际 backend。

描边使用紧邻像素强黑边、斜向/第二像素衰减，将亮字覆盖在黑边上，按 straight-alpha 合成，避免旧 RGB/alpha 双重压暗。此权重和字芯 gamma 是截图重建，尚非原 EXE 私有参数。`textWidth` 和段落换行采用实际 backend 字宽；NPC 12px 暖金色、按实际宽度居中。对照 `reports/font-reference/npc-text-comparison.png` 由真实运行图裁切，当前仍存在字形和内容差异，不能称像素级还原。

掉落 field sprite 留在深度队列，名称牌放入场景之后的 overlay，用实际字宽，清除重复“金币/X拾取”。临近时增加黄色物品轮廓和牌上方的 P 标记（拾取键仍为 X，P 并非按键提示）。对象恢复/破坏后不再用陈旧 `scene.blockedRects` 覆盖 World 的动态列表。新增源 6.map 木桶破坏/单攻击去重/碰撞释放/恢复/新图重置测试；该测试采用 2 HP 校验生命周期，不是原版木桶耐久或特效验收。

最终 build/playable EXE hash：`040a5d0d34f798c46c379b1c95f599ad53eeab15ee734bc59fb108c7bcdf83e5`。`tools/build.py --test` 通过 29 项核心标签，`reports/font-tests.json` 覆盖 7 字号的源表选择/实心字芯/基线裁剪/真实字宽/源不变/退出清理。发布 EXE 的 UI 输入 `reports/runs/input-20261017T161457` 通过 7 个点（创建、房间、物品、对话、任务），用户存档 hash 未变，实际查看截图。发布 EXE 六场景/三分辨率 12s smoke `reports/runs/20261017T161531-7a7c0490` exit0/置顶可见；Windows 仍拒绝焦点，不是物理键盘/IME 验收。playable 已重新打包，README 改为当前源迷宫路线。

汇总 `reports/font-reference/verification.json` 已核对发布清单全部文件、build/playable hash 一致、原字体/四张参考图 hash 不变、六张场景图实际含三种分辨率。无运行中测试窗口。`tools/verify_flow.py --ui-only` 可重跑正常窗口消息 UI 采样，不写用户存档；`tools/probe_font_raster.py` 是独立栅格化研究图，不能与实际游戏截图混淆。

保留原失败 `reports/runs/input-20261017T142732` / `143547`：输入机器人曾在源木桶前追怪而死；后一次 `151139` 通关不证明障碍导航已修。未引入自动瞬移绕桶。`nearestWalkable` 仍可能选中障碍内，桶 `[int data][5]` 的 HP 解释、逐击 1 伤害及销毁 PTL 未核对，必须继续处理。此前 weapon b/c 绘制顺序交换仍缺权威层序证据；创建/装备/任务 UI 仍是主要待办，不能把本次字体修正等同完整计划完成。

## 环境和命令

PowerShell5.1，Python D:/ProgramData/anaconda3/python.exe -X utf8 -B；中文管道先设 $OutputEncoding = New-Object System.Text.UTF8Encoding $false。无git仓库。当前无运行中游戏，原用户存档未变。

```powershell
& 'D:\ProgramData\anaconda3\python.exe' -X utf8 -B tools/build.py --test
& 'D:\ProgramData\anaconda3\python.exe' -X utf8 -B tools/verify_flow.py
& 'D:\ProgramData\anaconda3\python.exe' -X utf8 -B tools/run_demo.py --flow-smoke 30 --flow-scene-seconds 5
& 'D:\ProgramData\anaconda3\python.exe' -X utf8 -B tools/run_demo.py --smoke 104
```

docs/RENDERING.md记录来源、投影与边界，docs/PORTING.md记录接口/存储/格式保留；source-evidence仍101份原解密字节和有序token/model/hash，REP时序未证明。普通流程实际资源范围hash327项，仅访问集合，非完整依赖闭包。
> 2026-10-18 本轮续做受环境阻塞：深处失败 `input-20261018T004411` 在洛兰房间1反复尝试从 `(502,317.6)` 走到只有2px远的转向点 `(504,317.6)`，后续才应下移至326。`tools/verify_flow.py` 已加入微小横向段的安全转向候选修正，尚未运行验证；碰撞边距的具体成因仍是推断。启动 `--deep` 前工具报磁盘空间不足 `OS error 112`，连只读PowerShell也无法启动；自动审批服务另报403，没有成功清理或运行新测试。原资料、存档、发布包及失败证据没有成功删除。已向用户请求释放磁盘空间后继续。
>
> 同轮直接查看a3da真实截图：怪物落地5/6横躺、7恢复站立；共享白剪影及左右碎片可见，强冲击碎片位移更大；chief有独立蓝光死亡。十字左右0.65秒可见前方小红十字，1.10秒无大附着残影。查看了银落、地裂、卡赞、裂波联系图，以及裂波/地裂/崩山关键原帧。蹲姿、垂直碎片、短时技能窗口和原版逐帧对比仍未验收，不能写整体视觉通过。详细暂存：`reports/combat-rework/continuation-20261018-environment-block.json`。释放空间后先确认脚本修正落盘，运行纯导航复现与置顶普通`--deep`，成功后更新最终审计；发布EXE仍为a3da。

# 2026-10-20 最新优先级：技能渲染与判定链

先完成知识库/当前PVF核对后的按住持续与松键结束、女枪特效坐标/武器层/判定、鬼剑士三段斩衔接及崩山击第一帧响应；调试窗口增加隔离职业选择及更多可执行技能。选择创建/副本选择/IME、门户与怪物装备暂存保留，技能后整合。持续技能不能统一成技能热键按住：源M3喷火器说明为攻击键按住，格林为连按攻击延长/跳跃停止。最终体验候选仍需全量构建/自动验证和节点备份，交付后等用户确认。当前没有新的正式通过或checkpoint，不能沿用旧验证。

