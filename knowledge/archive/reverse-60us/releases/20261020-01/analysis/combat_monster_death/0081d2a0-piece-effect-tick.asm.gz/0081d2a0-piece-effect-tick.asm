0081d2a0 55                       push      ebp
0081d2a1 8bec                     mov       ebp, esp
0081d2a3 6aff                     push      -1
0081d2a5 68b7c9c700               push      0xc7c9b7
0081d2aa 64a100000000             mov       eax, dword ptr fs:[0]
0081d2b0 50                       push      eax
0081d2b1 64892500000000           mov       dword ptr fs:[0], esp
0081d2b8 81ec3c020000             sub       esp, 0x23c
0081d2be 53                       push      ebx
0081d2bf 56                       push      esi
0081d2c0 57                       push      edi
0081d2c1 8bf1                     mov       esi, ecx
0081d2c3 e818bdc7ff               call      0x498fe0
0081d2c8 8a860c020000             mov       al, byte ptr [esi + 0x20c]
0081d2ce 84c0                     test      al, al
0081d2d0 c745e801000000           mov       dword ptr [ebp - 0x18], 1
0081d2d7 0f85dc070000             jne       0x81dab9
0081d2dd 8d8ea0000000             lea       ecx, [esi + 0xa0]
0081d2e3 e8189c2e00               call      0xb06f00
0081d2e8 3b8608020000             cmp       eax, dword ptr [esi + 0x208]
0081d2ee 0f8cc5070000             jl        0x81dab9
0081d2f4 8b06                     mov       eax, dword ptr [esi]
0081d2f6 8bce                     mov       ecx, esi
0081d2f8 ff9094000000             call      dword ptr [eax + 0x94]
0081d2fe 8b16                     mov       edx, dword ptr [esi]
0081d300 8bce                     mov       ecx, esi
0081d302 8945ec                   mov       dword ptr [ebp - 0x14], eax
0081d305 ff9298000000             call      dword ptr [edx + 0x98]
0081d30b 8945cc                   mov       dword ptr [ebp - 0x34], eax
0081d30e 8b06                     mov       eax, dword ptr [esi]
0081d310 8bce                     mov       ecx, esi
0081d312 ff909c000000             call      dword ptr [eax + 0x9c]
0081d318 33ff                     xor       edi, edi
0081d31a 8945d0                   mov       dword ptr [ebp - 0x30], eax
0081d31d 897dd8                   mov       dword ptr [ebp - 0x28], edi
0081d320 897ddc                   mov       dword ptr [ebp - 0x24], edi
0081d323 897de0                   mov       dword ptr [ebp - 0x20], edi
0081d326 8a8620020000             mov       al, byte ptr [esi + 0x220]
0081d32c 33db                     xor       ebx, ebx
0081d32e a808                     test      al, 8
0081d330 897dfc                   mov       dword ptr [ebp - 4], edi
0081d333 0f84e6010000             je        0x81d51f
0081d339 68e8010000               push      0x1e8
0081d33e e80d69beff               call      0x403c50
0081d343 83c404                   add       esp, 4
0081d346 8945c8                   mov       dword ptr [ebp - 0x38], eax
0081d349 85c0                     test      eax, eax
0081d34b c645fc01                 mov       byte ptr [ebp - 4], 1
0081d34f 7413                     je        0x81d364
0081d351 6a01                     push      1
0081d353 6890b3e000               push      0xe0b390
0081d358 8bc8                     mov       ecx, eax
0081d35a e87163c7ff               call      0x4936d0
0081d35f 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d362 eb07                     jmp       0x81d36b
0081d364 c745f000000000           mov       dword ptr [ebp - 0x10], 0
0081d36b 68fc010000               push      0x1fc
0081d370 c645fc00                 mov       byte ptr [ebp - 4], 0
0081d374 e8d768beff               call      0x403c50
0081d379 83c404                   add       esp, 4
0081d37c 8945c8                   mov       dword ptr [ebp - 0x38], eax
0081d37f 85c0                     test      eax, eax
0081d381 c645fc02                 mov       byte ptr [ebp - 4], 2
0081d385 7412                     je        0x81d399
0081d387 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
0081d38a 6a01                     push      1
0081d38c 51                       push      ecx
0081d38d 8bc8                     mov       ecx, eax
0081d38f e88ce9c8ff               call      0x4abd20
0081d394 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d397 eb07                     jmp       0x81d3a0
0081d399 c745f000000000           mov       dword ptr [ebp - 0x10], 0
0081d3a0 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081d3a3 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081d3a9 6a00                     push      0
0081d3ab 6a00                     push      0
0081d3ad 56                       push      esi
0081d3ae 52                       push      edx
0081d3af 6a00                     push      0
0081d3b1 6a02                     push      2
0081d3b3 56                       push      esi
0081d3b4 c645fc00                 mov       byte ptr [ebp - 4], 0
0081d3b8 e8b309cfff               call      0x50dd70
0081d3bd 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
0081d3c0 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
0081d3c3 8b01                     mov       eax, dword ptr [ecx]
0081d3c5 52                       push      edx
0081d3c6 8b55cc                   mov       edx, dword ptr [ebp - 0x34]
0081d3c9 52                       push      edx
0081d3ca 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
0081d3cd 52                       push      edx
0081d3ce ff9088000000             call      dword ptr [eax + 0x88]
0081d3d4 a148280001               mov       eax, dword ptr [0x1002848]
0081d3d9 83b8a819000001           cmp       dword ptr [eax + 0x19a8], 1
0081d3e0 0f8439010000             je        0x81d51f
0081d3e6 8b3dec2e0001             mov       edi, dword ptr [0x1002eec]
0081d3ec 8b17                     mov       edx, dword ptr [edi]
0081d3ee 8bcf                     mov       ecx, edi
0081d3f0 ff521c                   call      dword ptr [edx + 0x1c]
0081d3f3 8b07                     mov       eax, dword ptr [edi]
0081d3f5 8bcf                     mov       ecx, edi
0081d3f7 ff5024                   call      dword ptr [eax + 0x24]
0081d3fa 8bd8                     mov       ebx, eax
0081d3fc 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d402 68e0220200               push      0x222e0
0081d407 2d30750000               sub       eax, 0x7530
0081d40c 50                       push      eax
0081d40d 680000f041               push      0x41f00000
0081d412 6800002041               push      0x41200000
0081d417 e894c52e00               call      0xb099b0
0081d41c 83c410                   add       esp, 0x10
0081d41f e820413e00               call      0xc01544
0081d424 8d4de4                   lea       ecx, [ebp - 0x1c]
0081d427 51                       push      ecx
0081d428 8d4b04                   lea       ecx, [ebx + 4]
0081d42b 8945e4                   mov       dword ptr [ebp - 0x1c], eax
0081d42e e82d71beff               call      0x404560
0081d433 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d439 68e0220200               push      0x222e0
0081d43e 2d30750000               sub       eax, 0x7530
0081d443 50                       push      eax
0081d444 680000f041               push      0x41f00000
0081d449 6800002041               push      0x41200000
0081d44e e85dc52e00               call      0xb099b0
0081d453 e8ec403e00               call      0xc01544
0081d458 894310                   mov       dword ptr [ebx + 0x10], eax
0081d45b 894314                   mov       dword ptr [ebx + 0x14], eax
0081d45e 894318                   mov       dword ptr [ebx + 0x18], eax
0081d461 8b9600020000             mov       edx, dword ptr [esi + 0x200]
0081d467 68e0220200               push      0x222e0
0081d46c 81ea30750000             sub       edx, 0x7530
0081d472 52                       push      edx
0081d473 6800000040               push      0x40000000
0081d478 680000803f               push      0x3f800000
0081d47d e82ec52e00               call      0xb099b0
0081d482 d95de4                   fstp      dword ptr [ebp - 0x1c]
0081d485 8b8624020000             mov       eax, dword ptr [esi + 0x224]
0081d48b 83c420                   add       esp, 0x20
0081d48e 85c0                     test      eax, eax
0081d490 0f8589000000             jne       0x81d51f
0081d496 8b07                     mov       eax, dword ptr [edi]
0081d498 6a00                     push      0
0081d49a 8bcf                     mov       ecx, edi
0081d49c ff500c                   call      dword ptr [eax + 0xc]
0081d49f 8b45d0                   mov       eax, dword ptr [ebp - 0x30]
0081d4a2 8b4dcc                   mov       ecx, dword ptr [ebp - 0x34]
0081d4a5 8b17                     mov       edx, dword ptr [edi]
0081d4a7 50                       push      eax
0081d4a8 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
0081d4ab 51                       push      ecx
0081d4ac 50                       push      eax
0081d4ad 8bcf                     mov       ecx, edi
0081d4af ff5228                   call      dword ptr [edx + 0x28]
0081d4b2 8b17                     mov       edx, dword ptr [edi]
0081d4b4 8d45b8                   lea       eax, [ebp - 0x48]
0081d4b7 50                       push      eax
0081d4b8 8bcf                     mov       ecx, edi
0081d4ba ff525c                   call      dword ptr [edx + 0x5c]
0081d4bd 50                       push      eax
0081d4be 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081d4c1 c645fc03                 mov       byte ptr [ebp - 4], 3
0081d4c5 e8e6d3cfff               call      0x51a8b0
0081d4ca 8d4db8                   lea       ecx, [ebp - 0x48]
0081d4cd c645fc00                 mov       byte ptr [ebp - 4], 0
0081d4d1 e87a78e2ff               call      0x644d50
0081d4d6 6a00                     push      0
0081d4d8 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081d4db 51                       push      ecx
0081d4dc 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081d4e2 6a00                     push      0
0081d4e4 6a02                     push      2
0081d4e6 56                       push      esi
0081d4e7 e8740bcfff               call      0x50e060
0081d4ec 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081d4ef 3b45dc                   cmp       eax, dword ptr [ebp - 0x24]
0081d4f2 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d4f5 7428                     je        0x81d51f
0081d4f7 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081d4fa 8b0a                     mov       ecx, dword ptr [edx]
0081d4fc 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
0081d4ff 8b11                     mov       edx, dword ptr [ecx]
0081d501 50                       push      eax
0081d502 ff92f4000000             call      dword ptr [edx + 0xf4]
0081d508 8bc8                     mov       ecx, eax
0081d50a e8a1c22000               call      0xa297b0
0081d50f 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081d512 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
0081d515 83c004                   add       eax, 4
0081d518 3bc1                     cmp       eax, ecx
0081d51a 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d51d 75d8                     jne       0x81d4f7
0081d51f f6862002000002           test      byte ptr [esi + 0x220], 2
0081d526 0f844d010000             je        0x81d679
0081d52c a148280001               mov       eax, dword ptr [0x1002848]
0081d531 8b80a8190000             mov       eax, dword ptr [eax + 0x19a8]
0081d537 83f802                   cmp       eax, 2
0081d53a 0f8439010000             je        0x81d679
0081d540 33c9                     xor       ecx, ecx
0081d542 83f801                   cmp       eax, 1
0081d545 0f95c1                   setne     cl
0081d548 8b3c8dd82e0001           mov       edi, dword ptr [ecx*4 + 0x1002ed8]
0081d54f 8b17                     mov       edx, dword ptr [edi]
0081d551 83c118                   add       ecx, 0x18
0081d554 8bcf                     mov       ecx, edi
0081d556 ff521c                   call      dword ptr [edx + 0x1c]
0081d559 8b07                     mov       eax, dword ptr [edi]
0081d55b 8bcf                     mov       ecx, edi
0081d55d ff5024                   call      dword ptr [eax + 0x24]
0081d560 8bd8                     mov       ebx, eax
0081d562 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d568 68e0220200               push      0x222e0
0081d56d 2d30750000               sub       eax, 0x7530
0081d572 50                       push      eax
0081d573 680000a041               push      0x41a00000
0081d578 6800000041               push      0x41000000
0081d57d e82ec42e00               call      0xb099b0
0081d582 83c410                   add       esp, 0x10
0081d585 e8ba3f3e00               call      0xc01544
0081d58a 8d4de4                   lea       ecx, [ebp - 0x1c]
0081d58d 51                       push      ecx
0081d58e 8d4b04                   lea       ecx, [ebx + 4]
0081d591 8945e4                   mov       dword ptr [ebp - 0x1c], eax
0081d594 e8c76fbeff               call      0x404560
0081d599 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d59f 68e0220200               push      0x222e0
0081d5a4 2d30750000               sub       eax, 0x7530
0081d5a9 50                       push      eax
0081d5aa 6800001643               push      0x43160000
0081d5af 6800004842               push      0x42480000
0081d5b4 e8f7c32e00               call      0xb099b0
0081d5b9 e8863f3e00               call      0xc01544
0081d5be 8d1400                   lea       edx, [eax + eax]
0081d5c1 894310                   mov       dword ptr [ebx + 0x10], eax
0081d5c4 894318                   mov       dword ptr [ebx + 0x18], eax
0081d5c7 895314                   mov       dword ptr [ebx + 0x14], edx
0081d5ca 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d5d0 68e0220200               push      0x222e0
0081d5d5 2d30750000               sub       eax, 0x7530
0081d5da 50                       push      eax
0081d5db 680000803f               push      0x3f800000
0081d5e0 680000803f               push      0x3f800000
0081d5e5 e8c6c32e00               call      0xb099b0
0081d5ea d95de4                   fstp      dword ptr [ebp - 0x1c]
0081d5ed 8b17                     mov       edx, dword ptr [edi]
0081d5ef 83c420                   add       esp, 0x20
0081d5f2 6a00                     push      0
0081d5f4 8bcf                     mov       ecx, edi
0081d5f6 ff520c                   call      dword ptr [edx + 0xc]
0081d5f9 8b4dd0                   mov       ecx, dword ptr [ebp - 0x30]
0081d5fc 8b55cc                   mov       edx, dword ptr [ebp - 0x34]
0081d5ff 8b07                     mov       eax, dword ptr [edi]
0081d601 51                       push      ecx
0081d602 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0081d605 52                       push      edx
0081d606 51                       push      ecx
0081d607 8bcf                     mov       ecx, edi
0081d609 ff5028                   call      dword ptr [eax + 0x28]
0081d60c 8b17                     mov       edx, dword ptr [edi]
0081d60e 8d45b8                   lea       eax, [ebp - 0x48]
0081d611 50                       push      eax
0081d612 8bcf                     mov       ecx, edi
0081d614 ff525c                   call      dword ptr [edx + 0x5c]
0081d617 50                       push      eax
0081d618 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081d61b c645fc04                 mov       byte ptr [ebp - 4], 4
0081d61f e88cd2cfff               call      0x51a8b0
0081d624 8d4db8                   lea       ecx, [ebp - 0x48]
0081d627 c645fc00                 mov       byte ptr [ebp - 4], 0
0081d62b e82077e2ff               call      0x644d50
0081d630 6a00                     push      0
0081d632 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081d635 51                       push      ecx
0081d636 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081d63c 6a00                     push      0
0081d63e 6a02                     push      2
0081d640 56                       push      esi
0081d641 e81a0acfff               call      0x50e060
0081d646 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081d649 3b45dc                   cmp       eax, dword ptr [ebp - 0x24]
0081d64c 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d64f 7428                     je        0x81d679
0081d651 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081d654 8b0a                     mov       ecx, dword ptr [edx]
0081d656 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
0081d659 8b11                     mov       edx, dword ptr [ecx]
0081d65b 50                       push      eax
0081d65c ff92f4000000             call      dword ptr [edx + 0xf4]
0081d662 8bc8                     mov       ecx, eax
0081d664 e847c12000               call      0xa297b0
0081d669 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081d66c 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
0081d66f 83c004                   add       eax, 4
0081d672 3bc1                     cmp       eax, ecx
0081d674 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d677 75d8                     jne       0x81d651
0081d679 f6862002000001           test      byte ptr [esi + 0x220], 1
0081d680 0f84d2030000             je        0x81da58
0081d686 8b8604020000             mov       eax, dword ptr [esi + 0x204]
0081d68c 85c0                     test      eax, eax
0081d68e 0f84c4030000             je        0x81da58
0081d694 a148280001               mov       eax, dword ptr [0x1002848]
0081d699 8b80a8190000             mov       eax, dword ptr [eax + 0x19a8]
0081d69f 85c0                     test      eax, eax
0081d6a1 7508                     jne       0x81d6ab
0081d6a3 8b3de42e0001             mov       edi, dword ptr [0x1002ee4]
0081d6a9 eb18                     jmp       0x81d6c3
0081d6ab 83f801                   cmp       eax, 1
0081d6ae 7508                     jne       0x81d6b8
0081d6b0 8b3de02e0001             mov       edi, dword ptr [0x1002ee0]
0081d6b6 eb0b                     jmp       0x81d6c3
0081d6b8 83f802                   cmp       eax, 2
0081d6bb 7506                     jne       0x81d6c3
0081d6bd 8b3de82e0001             mov       edi, dword ptr [0x1002ee8]
0081d6c3 83f801                   cmp       eax, 1
0081d6c6 7408                     je        0x81d6d0
0081d6c8 85c0                     test      eax, eax
0081d6ca 0f859e000000             jne       0x81d76e
0081d6d0 8b17                     mov       edx, dword ptr [edi]
0081d6d2 8bcf                     mov       ecx, edi
0081d6d4 ff521c                   call      dword ptr [edx + 0x1c]
0081d6d7 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d6da 8b07                     mov       eax, dword ptr [edi]
0081d6dc 8bcf                     mov       ecx, edi
0081d6de ff5024                   call      dword ptr [eax + 0x24]
0081d6e1 8bd8                     mov       ebx, eax
0081d6e3 8b86fc010000             mov       eax, dword ptr [esi + 0x1fc]
0081d6e9 83f801                   cmp       eax, 1
0081d6ec 7460                     je        0x81d74e
0081d6ee 83f802                   cmp       eax, 2
0081d6f1 745b                     je        0x81d74e
0081d6f3 83f803                   cmp       eax, 3
0081d6f6 7426                     je        0x81d71e
0081d6f8 83f804                   cmp       eax, 4
0081d6fb 7421                     je        0x81d71e
0081d6fd 83f805                   cmp       eax, 5
0081d700 756c                     jne       0x81d76e
0081d702 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081d705 b920030000               mov       ecx, 0x320
0081d70a 894822                   mov       dword ptr [eax + 0x22], ecx
0081d70d 894826                   mov       dword ptr [eax + 0x26], ecx
0081d710 c7405000000000           mov       dword ptr [eax + 0x50], 0
0081d717 b80a000000               mov       eax, 0xa
0081d71c eb4a                     jmp       0x81d768
0081d71e 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081d721 b9bc020000               mov       ecx, 0x2bc
0081d726 894822                   mov       dword ptr [eax + 0x22], ecx
0081d729 894826                   mov       dword ptr [eax + 0x26], ecx
0081d72c 8b96fc010000             mov       edx, dword ptr [esi + 0x1fc]
0081d732 33c9                     xor       ecx, ecx
0081d734 83fa03                   cmp       edx, 3
0081d737 0f95c1                   setne     cl
0081d73a 49                       dec       ecx
0081d73b 81e18c000000             and       ecx, 0x8c
0081d741 83c1ba                   add       ecx, -0x46
0081d744 894850                   mov       dword ptr [eax + 0x50], ecx
0081d747 b828000000               mov       eax, 0x28
0081d74c eb1a                     jmp       0x81d768
0081d74e 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081d751 b990010000               mov       ecx, 0x190
0081d756 894822                   mov       dword ptr [eax + 0x22], ecx
0081d759 894826                   mov       dword ptr [eax + 0x26], ecx
0081d75c c7405000000000           mov       dword ptr [eax + 0x50], 0
0081d763 b864000000               mov       eax, 0x64
0081d768 89432c                   mov       dword ptr [ebx + 0x2c], eax
0081d76b 894330                   mov       dword ptr [ebx + 0x30], eax
0081d76e 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d774 68e0220200               push      0x222e0
0081d779 2d30750000               sub       eax, 0x7530
0081d77e 50                       push      eax
0081d77f 680000f041               push      0x41f00000
0081d784 6800002041               push      0x41200000
0081d789 e822c22e00               call      0xb099b0
0081d78e 83c410                   add       esp, 0x10
0081d791 e8ae3d3e00               call      0xc01544
0081d796 8d55e4                   lea       edx, [ebp - 0x1c]
0081d799 8d4b04                   lea       ecx, [ebx + 4]
0081d79c 52                       push      edx
0081d79d 8945e4                   mov       dword ptr [ebp - 0x1c], eax
0081d7a0 e8bb6dbeff               call      0x404560
0081d7a5 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d7ab 68e0220200               push      0x222e0
0081d7b0 2d30750000               sub       eax, 0x7530
0081d7b5 50                       push      eax
0081d7b6 6800001643               push      0x43160000
0081d7bb 6800004842               push      0x42480000
0081d7c0 e8ebc12e00               call      0xb099b0
0081d7c5 e87a3d3e00               call      0xc01544
0081d7ca 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d7cd 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d7d3 68e0220200               push      0x222e0
0081d7d8 2d30750000               sub       eax, 0x7530
0081d7dd 50                       push      eax
0081d7de 680000803f               push      0x3f800000
0081d7e3 680000003f               push      0x3f000000
0081d7e8 e8c3c12e00               call      0xb099b0
0081d7ed d95de4                   fstp      dword ptr [ebp - 0x1c]
0081d7f0 8b0d48280001             mov       ecx, dword ptr [0x1002848]
0081d7f6 8b81a8190000             mov       eax, dword ptr [ecx + 0x19a8]
0081d7fc 83c420                   add       esp, 0x20
0081d7ff 83f802                   cmp       eax, 2
0081d802 7564                     jne       0x81d868
0081d804 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d80a 68e0220200               push      0x222e0
0081d80f 2d30750000               sub       eax, 0x7530
0081d814 50                       push      eax
0081d815 6800007042               push      0x42700000
0081d81a 680000a041               push      0x41a00000
0081d81f e88cc12e00               call      0xb099b0
0081d824 83c410                   add       esp, 0x10
0081d827 e8183d3e00               call      0xc01544
0081d82c 8d55e8                   lea       edx, [ebp - 0x18]
0081d82f 52                       push      edx
0081d830 8d4b04                   lea       ecx, [ebx + 4]
0081d833 8945e8                   mov       dword ptr [ebp - 0x18], eax
0081d836 e8256dbeff               call      0x404560
0081d83b 8b8600020000             mov       eax, dword ptr [esi + 0x200]
0081d841 68e0220200               push      0x222e0
0081d846 2d30750000               sub       eax, 0x7530
0081d84b 50                       push      eax
0081d84c 6800008040               push      0x40800000
0081d851 6800000040               push      0x40000000
0081d856 e855c12e00               call      0xb099b0
0081d85b d95de4                   fstp      dword ptr [ebp - 0x1c]
0081d85e 83c410                   add       esp, 0x10
0081d861 c745e80a000000           mov       dword ptr [ebp - 0x18], 0xa
0081d868 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081d86b 8d0c00                   lea       ecx, [eax + eax]
0081d86e 894b14                   mov       dword ptr [ebx + 0x14], ecx
0081d871 894310                   mov       dword ptr [ebx + 0x10], eax
0081d874 894318                   mov       dword ptr [ebx + 0x18], eax
0081d877 8b17                     mov       edx, dword ptr [edi]
0081d879 6a00                     push      0
0081d87b 8bcf                     mov       ecx, edi
0081d87d ff520c                   call      dword ptr [edx + 0xc]
0081d880 8b4dd0                   mov       ecx, dword ptr [ebp - 0x30]
0081d883 8b55cc                   mov       edx, dword ptr [ebp - 0x34]
0081d886 8b07                     mov       eax, dword ptr [edi]
0081d888 51                       push      ecx
0081d889 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0081d88c 52                       push      edx
0081d88d 51                       push      ecx
0081d88e 8bcf                     mov       ecx, edi
0081d890 ff5028                   call      dword ptr [eax + 0x28]
0081d893 8b17                     mov       edx, dword ptr [edi]
0081d895 8d45b8                   lea       eax, [ebp - 0x48]
0081d898 50                       push      eax
0081d899 8bcf                     mov       ecx, edi
0081d89b ff525c                   call      dword ptr [edx + 0x5c]
0081d89e 50                       push      eax
0081d89f 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081d8a2 c645fc05                 mov       byte ptr [ebp - 4], 5
0081d8a6 e805d0cfff               call      0x51a8b0
0081d8ab 8b45bc                   mov       eax, dword ptr [ebp - 0x44]
0081d8ae 85c0                     test      eax, eax
0081d8b0 c645fc00                 mov       byte ptr [ebp - 4], 0
0081d8b4 7409                     je        0x81d8bf
0081d8b6 50                       push      eax
0081d8b7 e821273e00               call      0xbfffdd
0081d8bc 83c404                   add       esp, 4
0081d8bf 6a00                     push      0
0081d8c1 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081d8c4 51                       push      ecx
0081d8c5 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081d8cb 6a00                     push      0
0081d8cd 6a02                     push      2
0081d8cf 56                       push      esi
0081d8d0 e88b07cfff               call      0x50e060
0081d8d5 8b1548280001             mov       edx, dword ptr [0x1002848]
0081d8db 8b82a8190000             mov       eax, dword ptr [edx + 0x19a8]
0081d8e1 83f801                   cmp       eax, 1
0081d8e4 7522                     jne       0x81d908
0081d8e6 8b8604020000             mov       eax, dword ptr [esi + 0x204]
0081d8ec 50                       push      eax
0081d8ed 6858b3e000               push      0xe0b358
0081d8f2 8d8db8fdffff             lea       ecx, [ebp - 0x248]
0081d8f8 6800020000               push      0x200
0081d8fd 51                       push      ecx
0081d8fe e8ed44beff               call      0x401df0
0081d903 83c410                   add       esp, 0x10
0081d906 eb32                     jmp       0x81d93a
0081d908 85c0                     test      eax, eax
0081d90a 7513                     jne       0x81d91f
0081d90c 6810b3e000               push      0xe0b310
0081d911 6800010000               push      0x100
0081d916 8d95b8fdffff             lea       edx, [ebp - 0x248]
0081d91c 52                       push      edx
0081d91d eb16                     jmp       0x81d935
0081d91f 83f802                   cmp       eax, 2
0081d922 7516                     jne       0x81d93a
0081d924 68b8b2e000               push      0xe0b2b8
0081d929 6800010000               push      0x100
0081d92e 8d85b8fdffff             lea       eax, [ebp - 0x248]
0081d934 50                       push      eax
0081d935 e85638beff               call      0x401190
0081d93a 8b0dd8300001             mov       ecx, dword ptr [0x10030d8]
0081d940 8b11                     mov       edx, dword ptr [ecx]
0081d942 8d85b8fdffff             lea       eax, [ebp - 0x248]
0081d948 50                       push      eax
0081d949 ff5210                   call      dword ptr [edx + 0x10]
0081d94c 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
0081d94f 8945c8                   mov       dword ptr [ebp - 0x38], eax
0081d952 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081d955 3bc1                     cmp       eax, ecx
0081d957 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081d95a 0f84f8000000             je        0x81da58
0081d960 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
0081d963 8b09                     mov       ecx, dword ptr [ecx]
0081d965 8b11                     mov       edx, dword ptr [ecx]
0081d967 ff92f4000000             call      dword ptr [edx + 0xf4]
0081d96d 8b9098000000             mov       edx, dword ptr [eax + 0x98]
0081d973 33db                     xor       ebx, ebx
0081d975 3bd3                     cmp       edx, ebx
0081d977 8945d0                   mov       dword ptr [ebp - 0x30], eax
0081d97a 7504                     jne       0x81d980
0081d97c 33ff                     xor       edi, edi
0081d97e eb1b                     jmp       0x81d99b
0081d980 8b889c000000             mov       ecx, dword ptr [eax + 0x9c]
0081d986 2bca                     sub       ecx, edx
0081d988 b843082184               mov       eax, 0x84210843
0081d98d f7e9                     imul      ecx
0081d98f 03d1                     add       edx, ecx
0081d991 c1fa06                   sar       edx, 6
0081d994 8bfa                     mov       edi, edx
0081d996 c1ef1f                   shr       edi, 0x1f
0081d999 03fa                     add       edi, edx
0081d99b a148280001               mov       eax, dword ptr [0x1002848]
0081d9a0 8b80a8190000             mov       eax, dword ptr [eax + 0x19a8]
0081d9a6 83f801                   cmp       eax, 1
0081d9a9 897dcc                   mov       dword ptr [ebp - 0x34], edi
0081d9ac 895dec                   mov       dword ptr [ebp - 0x14], ebx
0081d9af 7516                     jne       0x81d9c7
0081d9b1 53                       push      ebx
0081d9b2 e839070900               call      0x8ae0f0
0081d9b7 83c404                   add       esp, 4
0081d9ba 2503000080               and       eax, 0x80000003
0081d9bf 793b                     jns       0x81d9fc
0081d9c1 48                       dec       eax
0081d9c2 83c8fc                   or        eax, 0xfffffffc
0081d9c5 eb34                     jmp       0x81d9fb
0081d9c7 3bc3                     cmp       eax, ebx
0081d9c9 7517                     jne       0x81d9e2
0081d9cb 53                       push      ebx
0081d9cc e81f070900               call      0x8ae0f0
0081d9d1 99                       cdq       
0081d9d2 b903000000               mov       ecx, 3
0081d9d7 f7f9                     idiv      ecx
0081d9d9 83c404                   add       esp, 4
0081d9dc 42                       inc       edx
0081d9dd 8955ec                   mov       dword ptr [ebp - 0x14], edx
0081d9e0 eb1d                     jmp       0x81d9ff
0081d9e2 83f802                   cmp       eax, 2
0081d9e5 7518                     jne       0x81d9ff
0081d9e7 53                       push      ebx
0081d9e8 e803070900               call      0x8ae0f0
0081d9ed 83c404                   add       esp, 4
0081d9f0 2501000080               and       eax, 0x80000001
0081d9f5 7905                     jns       0x81d9fc
0081d9f7 48                       dec       eax
0081d9f8 83c8fe                   or        eax, 0xfffffffe
0081d9fb 40                       inc       eax
0081d9fc 8945ec                   mov       dword ptr [ebp - 0x14], eax
0081d9ff 3bfb                     cmp       edi, ebx
0081da01 7e41                     jle       0x81da44
0081da03 8b4dd0                   mov       ecx, dword ptr [ebp - 0x30]
0081da06 53                       push      ebx
0081da07 e884822000               call      0xa25c90
0081da0c 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
0081da0f 8b4dc8                   mov       ecx, dword ptr [ebp - 0x38]
0081da12 52                       push      edx
0081da13 8bf8                     mov       edi, eax
0081da15 e8b6492d00               call      0xaf23d0
0081da1a 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
0081da1d 8907                     mov       dword ptr [edi], eax
0081da1f 8bd1                     mov       edx, ecx
0081da21 3315fc3e0d01             xor       edx, dword ptr [0x10d3efc]
0081da27 8d4714                   lea       eax, [edi + 0x14]
0081da2a 03d0                     add       edx, eax
0081da2c 8910                     mov       dword ptr [eax], edx
0081da2e a1fc3e0d01               mov       eax, dword ptr [0x10d3efc]
0081da33 83c710                   add       edi, 0x10
0081da36 33c8                     xor       ecx, eax
0081da38 8b45cc                   mov       eax, dword ptr [ebp - 0x34]
0081da3b 03cf                     add       ecx, edi
0081da3d 43                       inc       ebx
0081da3e 3bd8                     cmp       ebx, eax
0081da40 890f                     mov       dword ptr [edi], ecx
0081da42 7cbf                     jl        0x81da03
0081da44 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
0081da47 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
0081da4a 83c004                   add       eax, 4
0081da4d 3bc1                     cmp       eax, ecx
0081da4f 8945f0                   mov       dword ptr [ebp - 0x10], eax
0081da52 0f8508ffffff             jne       0x81d960
0081da58 a148280001               mov       eax, dword ptr [0x1002848]
0081da5d 83b8a819000001           cmp       dword ptr [eax + 0x19a8], 1
0081da64 7415                     je        0x81da7b
0081da66 8b16                     mov       edx, dword ptr [esi]
0081da68 6a00                     push      0
0081da6a 6a00                     push      0
0081da6c 6aff                     push      -1
0081da6e 6894b2e000               push      0xe0b294
0081da73 8bce                     mov       ecx, esi
0081da75 ff920c010000             call      dword ptr [edx + 0x10c]
0081da7b 8b9624020000             mov       edx, dword ptr [esi + 0x224]
0081da81 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
0081da84 42                       inc       edx
0081da85 8bca                     mov       ecx, edx
0081da87 3bc8                     cmp       ecx, eax
0081da89 899624020000             mov       dword ptr [esi + 0x224], edx
0081da8f 7c11                     jl        0x81daa2
0081da91 c6860c02000001           mov       byte ptr [esi + 0x20c], 1
0081da98 c7862402000000000000     mov       dword ptr [esi + 0x224], 0
0081daa2 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081daa5 85c0                     test      eax, eax
0081daa7 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081daae 7409                     je        0x81dab9
0081dab0 50                       push      eax
0081dab1 e827253e00               call      0xbfffdd
0081dab6 83c404                   add       esp, 4
0081dab9 f6862002000004           test      byte ptr [esi + 0x220], 4
0081dac0 8d8ea0000000             lea       ecx, [esi + 0xa0]
0081dac6 0f8406060000             je        0x81e0d2
0081dacc e82f942e00               call      0xb06f00
0081dad1 8b8e08020000             mov       ecx, dword ptr [esi + 0x208]
0081dad7 83c164                   add       ecx, 0x64
0081dada 3bc1                     cmp       eax, ecx
0081dadc 0f8c6c050000             jl        0x81e04e
0081dae2 8b16                     mov       edx, dword ptr [esi]
0081dae4 8bce                     mov       ecx, esi
0081dae6 ff9294000000             call      dword ptr [edx + 0x94]
0081daec 8bd8                     mov       ebx, eax
0081daee 8b06                     mov       eax, dword ptr [esi]
0081daf0 8bce                     mov       ecx, esi
0081daf2 895dd0                   mov       dword ptr [ebp - 0x30], ebx
0081daf5 ff9098000000             call      dword ptr [eax + 0x98]
0081dafb 8b0d48280001             mov       ecx, dword ptr [0x1002848]
0081db01 8bd0                     mov       edx, eax
0081db03 8b81a8190000             mov       eax, dword ptr [ecx + 0x19a8]
0081db09 bf02000000               mov       edi, 2
0081db0e 3bc7                     cmp       eax, edi
0081db10 8955f0                   mov       dword ptr [ebp - 0x10], edx
0081db13 0f858b040000             jne       0x81dfa4
0081db19 8b8e14020000             mov       ecx, dword ptr [esi + 0x214]
0081db1f 85c9                     test      ecx, ecx
0081db21 8d8614020000             lea       eax, [esi + 0x214]
0081db27 0f8477040000             je        0x81dfa4
0081db2d 8b8e18020000             mov       ecx, dword ptr [esi + 0x218]
0081db33 85c9                     test      ecx, ecx
0081db35 0f8469040000             je        0x81dfa4
0081db3b 8b8efc010000             mov       ecx, dword ptr [esi + 0x1fc]
0081db41 83f901                   cmp       ecx, 1
0081db44 0f85de000000             jne       0x81dc28
0081db4a 8bf8                     mov       edi, eax
0081db4c 897de8                   mov       dword ptr [ebp - 0x18], edi
0081db4f c745e402000000           mov       dword ptr [ebp - 0x1c], 2
0081db56 eb08                     jmp       0x81db60
0081db58 8b5dd0                   mov       ebx, dword ptr [ebp - 0x30]
0081db5b 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081db5e 8bff                     mov       edi, edi
0081db60 8b0f                     mov       ecx, dword ptr [edi]
0081db62 8b01                     mov       eax, dword ptr [ecx]
0081db64 6a1e                     push      0x1e
0081db66 52                       push      edx
0081db67 53                       push      ebx
0081db68 ff5028                   call      dword ptr [eax + 0x28]
0081db6b 8b0f                     mov       ecx, dword ptr [edi]
0081db6d 8b11                     mov       edx, dword ptr [ecx]
0081db6f 8d45d4                   lea       eax, [ebp - 0x2c]
0081db72 50                       push      eax
0081db73 ff525c                   call      dword ptr [edx + 0x5c]
0081db76 6a00                     push      0
0081db78 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081db7b 51                       push      ecx
0081db7c 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081db82 6a00                     push      0
0081db84 6a02                     push      2
0081db86 56                       push      esi
0081db87 c745fc06000000           mov       dword ptr [ebp - 4], 6
0081db8e e8cd04cfff               call      0x50e060
0081db93 33db                     xor       ebx, ebx
0081db95 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
0081db98 33ff                     xor       edi, edi
0081db9a 3bcf                     cmp       ecx, edi
0081db9c 7452                     je        0x81dbf0
0081db9e 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
0081dba1 2bc1                     sub       eax, ecx
0081dba3 c1f802                   sar       eax, 2
0081dba6 3bd8                     cmp       ebx, eax
0081dba8 7346                     jae       0x81dbf0
0081dbaa 8b0c99                   mov       ecx, dword ptr [ecx + ebx*4]
0081dbad 8b11                     mov       edx, dword ptr [ecx]
0081dbaf 57                       push      edi
0081dbb0 ff92f4000000             call      dword ptr [edx + 0xf4]
0081dbb6 8bc8                     mov       ecx, eax
0081dbb8 e8d3802000               call      0xa25c90
0081dbbd 85c0                     test      eax, eax
0081dbbf 742c                     je        0x81dbed
0081dbc1 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081dbc4 8b0c98                   mov       ecx, dword ptr [eax + ebx*4]
0081dbc7 8b11                     mov       edx, dword ptr [ecx]
0081dbc9 8bbe1c020000             mov       edi, dword ptr [esi + 0x21c]
0081dbcf 6a00                     push      0
0081dbd1 ff92f4000000             call      dword ptr [edx + 0xf4]
0081dbd7 8bc8                     mov       ecx, eax
0081dbd9 e8b2802000               call      0xa25c90
0081dbde 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
0081dbe4 83c030                   add       eax, 0x30
0081dbe7 33fa                     xor       edi, edx
0081dbe9 03f8                     add       edi, eax
0081dbeb 8938                     mov       dword ptr [eax], edi
0081dbed 43                       inc       ebx
0081dbee eba5                     jmp       0x81db95
0081dbf0 3bcf                     cmp       ecx, edi
0081dbf2 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081dbf9 7409                     je        0x81dc04
0081dbfb 51                       push      ecx
0081dbfc e8dc233e00               call      0xbfffdd
0081dc01 83c404                   add       esp, 4
0081dc04 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
0081dc07 897dd8                   mov       dword ptr [ebp - 0x28], edi
0081dc0a 897ddc                   mov       dword ptr [ebp - 0x24], edi
0081dc0d 897de0                   mov       dword ptr [ebp - 0x20], edi
0081dc10 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
0081dc13 83c704                   add       edi, 4
0081dc16 48                       dec       eax
0081dc17 897de8                   mov       dword ptr [ebp - 0x18], edi
0081dc1a 8945e4                   mov       dword ptr [ebp - 0x1c], eax
0081dc1d 0f8535ffffff             jne       0x81db58
0081dc23 e926040000               jmp       0x81e04e
0081dc28 3bcf                     cmp       ecx, edi
0081dc2a 0f85d7000000             jne       0x81dd07
0081dc30 897de8                   mov       dword ptr [ebp - 0x18], edi
0081dc33 8945ec                   mov       dword ptr [ebp - 0x14], eax
0081dc36 33ff                     xor       edi, edi
0081dc38 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081dc3b 8b5dec                   mov       ebx, dword ptr [ebp - 0x14]
0081dc3e 8b0b                     mov       ecx, dword ptr [ebx]
0081dc40 8b01                     mov       eax, dword ptr [ecx]
0081dc42 6a1e                     push      0x1e
0081dc44 52                       push      edx
0081dc45 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
0081dc48 52                       push      edx
0081dc49 ff5028                   call      dword ptr [eax + 0x28]
0081dc4c 8b0b                     mov       ecx, dword ptr [ebx]
0081dc4e 8b01                     mov       eax, dword ptr [ecx]
0081dc50 8d55d4                   lea       edx, [ebp - 0x2c]
0081dc53 52                       push      edx
0081dc54 ff505c                   call      dword ptr [eax + 0x5c]
0081dc57 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081dc5d 57                       push      edi
0081dc5e 8d45d4                   lea       eax, [ebp - 0x2c]
0081dc61 50                       push      eax
0081dc62 57                       push      edi
0081dc63 6a02                     push      2
0081dc65 56                       push      esi
0081dc66 c745fc07000000           mov       dword ptr [ebp - 4], 7
0081dc6d e8ee03cfff               call      0x50e060
0081dc72 33db                     xor       ebx, ebx
0081dc74 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
0081dc77 3bcf                     cmp       ecx, edi
0081dc79 7454                     je        0x81dccf
0081dc7b 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
0081dc7e 2bc1                     sub       eax, ecx
0081dc80 c1f802                   sar       eax, 2
0081dc83 3bd8                     cmp       ebx, eax
0081dc85 7348                     jae       0x81dccf
0081dc87 8b0c99                   mov       ecx, dword ptr [ecx + ebx*4]
0081dc8a 8b11                     mov       edx, dword ptr [ecx]
0081dc8c 57                       push      edi
0081dc8d ff92f4000000             call      dword ptr [edx + 0xf4]
0081dc93 8bc8                     mov       ecx, eax
0081dc95 e8f67f2000               call      0xa25c90
0081dc9a 85c0                     test      eax, eax
0081dc9c 742e                     je        0x81dccc
0081dc9e 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081dca1 8b0c98                   mov       ecx, dword ptr [eax + ebx*4]
0081dca4 8b11                     mov       edx, dword ptr [ecx]
0081dca6 8bbe1c020000             mov       edi, dword ptr [esi + 0x21c]
0081dcac 6a00                     push      0
0081dcae ff92f4000000             call      dword ptr [edx + 0xf4]
0081dcb4 8bc8                     mov       ecx, eax
0081dcb6 e8d57f2000               call      0xa25c90
0081dcbb 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
0081dcc1 83c030                   add       eax, 0x30
0081dcc4 33fa                     xor       edi, edx
0081dcc6 03f8                     add       edi, eax
0081dcc8 8938                     mov       dword ptr [eax], edi
0081dcca 33ff                     xor       edi, edi
0081dccc 43                       inc       ebx
0081dccd eba5                     jmp       0x81dc74
0081dccf 3bcf                     cmp       ecx, edi
0081dcd1 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081dcd8 7409                     je        0x81dce3
0081dcda 51                       push      ecx
0081dcdb e8fd223e00               call      0xbfffdd
0081dce0 83c404                   add       esp, 4
0081dce3 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0081dce6 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
0081dce9 83c104                   add       ecx, 4
0081dcec 48                       dec       eax
0081dced 897dd8                   mov       dword ptr [ebp - 0x28], edi
0081dcf0 897ddc                   mov       dword ptr [ebp - 0x24], edi
0081dcf3 897de0                   mov       dword ptr [ebp - 0x20], edi
0081dcf6 894dec                   mov       dword ptr [ebp - 0x14], ecx
0081dcf9 8945e8                   mov       dword ptr [ebp - 0x18], eax
0081dcfc 0f8536ffffff             jne       0x81dc38
0081dd02 e947030000               jmp       0x81e04e
0081dd07 83f903                   cmp       ecx, 3
0081dd0a 0f85d7000000             jne       0x81dde7
0081dd10 897de8                   mov       dword ptr [ebp - 0x18], edi
0081dd13 8945ec                   mov       dword ptr [ebp - 0x14], eax
0081dd16 33ff                     xor       edi, edi
0081dd18 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081dd1b 8b5dec                   mov       ebx, dword ptr [ebp - 0x14]
0081dd1e 8b0b                     mov       ecx, dword ptr [ebx]
0081dd20 8b01                     mov       eax, dword ptr [ecx]
0081dd22 6a1e                     push      0x1e
0081dd24 52                       push      edx
0081dd25 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
0081dd28 52                       push      edx
0081dd29 ff5028                   call      dword ptr [eax + 0x28]
0081dd2c 8b0b                     mov       ecx, dword ptr [ebx]
0081dd2e 8b01                     mov       eax, dword ptr [ecx]
0081dd30 8d55d4                   lea       edx, [ebp - 0x2c]
0081dd33 52                       push      edx
0081dd34 ff505c                   call      dword ptr [eax + 0x5c]
0081dd37 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081dd3d 57                       push      edi
0081dd3e 8d45d4                   lea       eax, [ebp - 0x2c]
0081dd41 50                       push      eax
0081dd42 57                       push      edi
0081dd43 6a02                     push      2
0081dd45 56                       push      esi
0081dd46 c745fc08000000           mov       dword ptr [ebp - 4], 8
0081dd4d e80e03cfff               call      0x50e060
0081dd52 33db                     xor       ebx, ebx
0081dd54 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
0081dd57 3bcf                     cmp       ecx, edi
0081dd59 7454                     je        0x81ddaf
0081dd5b 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
0081dd5e 2bc1                     sub       eax, ecx
0081dd60 c1f802                   sar       eax, 2
0081dd63 3bd8                     cmp       ebx, eax
0081dd65 7348                     jae       0x81ddaf
0081dd67 8b0c99                   mov       ecx, dword ptr [ecx + ebx*4]
0081dd6a 8b11                     mov       edx, dword ptr [ecx]
0081dd6c 57                       push      edi
0081dd6d ff92f4000000             call      dword ptr [edx + 0xf4]
0081dd73 8bc8                     mov       ecx, eax
0081dd75 e8167f2000               call      0xa25c90
0081dd7a 85c0                     test      eax, eax
0081dd7c 742e                     je        0x81ddac
0081dd7e 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081dd81 8b0c98                   mov       ecx, dword ptr [eax + ebx*4]
0081dd84 8b11                     mov       edx, dword ptr [ecx]
0081dd86 8bbe1c020000             mov       edi, dword ptr [esi + 0x21c]
0081dd8c 6a00                     push      0
0081dd8e ff92f4000000             call      dword ptr [edx + 0xf4]
0081dd94 8bc8                     mov       ecx, eax
0081dd96 e8f57e2000               call      0xa25c90
0081dd9b 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
0081dda1 83c030                   add       eax, 0x30
0081dda4 33fa                     xor       edi, edx
0081dda6 03f8                     add       edi, eax
0081dda8 8938                     mov       dword ptr [eax], edi
0081ddaa 33ff                     xor       edi, edi
0081ddac 43                       inc       ebx
0081ddad eba5                     jmp       0x81dd54
0081ddaf 3bcf                     cmp       ecx, edi
0081ddb1 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081ddb8 7409                     je        0x81ddc3
0081ddba 51                       push      ecx
0081ddbb e81d223e00               call      0xbfffdd
0081ddc0 83c404                   add       esp, 4
0081ddc3 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0081ddc6 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
0081ddc9 83c104                   add       ecx, 4
0081ddcc 48                       dec       eax
0081ddcd 897dd8                   mov       dword ptr [ebp - 0x28], edi
0081ddd0 897ddc                   mov       dword ptr [ebp - 0x24], edi
0081ddd3 897de0                   mov       dword ptr [ebp - 0x20], edi
0081ddd6 894dec                   mov       dword ptr [ebp - 0x14], ecx
0081ddd9 8945e8                   mov       dword ptr [ebp - 0x18], eax
0081dddc 0f8536ffffff             jne       0x81dd18
0081dde2 e967020000               jmp       0x81e04e
0081dde7 83f904                   cmp       ecx, 4
0081ddea 0f85d7000000             jne       0x81dec7
0081ddf0 897de8                   mov       dword ptr [ebp - 0x18], edi
0081ddf3 8945ec                   mov       dword ptr [ebp - 0x14], eax
0081ddf6 33ff                     xor       edi, edi
0081ddf8 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081ddfb 8b5dec                   mov       ebx, dword ptr [ebp - 0x14]
0081ddfe 8b0b                     mov       ecx, dword ptr [ebx]
0081de00 8b01                     mov       eax, dword ptr [ecx]
0081de02 6a1e                     push      0x1e
0081de04 52                       push      edx
0081de05 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
0081de08 52                       push      edx
0081de09 ff5028                   call      dword ptr [eax + 0x28]
0081de0c 8b0b                     mov       ecx, dword ptr [ebx]
0081de0e 8b01                     mov       eax, dword ptr [ecx]
0081de10 8d55d4                   lea       edx, [ebp - 0x2c]
0081de13 52                       push      edx
0081de14 ff505c                   call      dword ptr [eax + 0x5c]
0081de17 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081de1d 57                       push      edi
0081de1e 8d45d4                   lea       eax, [ebp - 0x2c]
0081de21 50                       push      eax
0081de22 57                       push      edi
0081de23 6a02                     push      2
0081de25 56                       push      esi
0081de26 c745fc09000000           mov       dword ptr [ebp - 4], 9
0081de2d e82e02cfff               call      0x50e060
0081de32 33db                     xor       ebx, ebx
0081de34 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
0081de37 3bcf                     cmp       ecx, edi
0081de39 7454                     je        0x81de8f
0081de3b 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
0081de3e 2bc1                     sub       eax, ecx
0081de40 c1f802                   sar       eax, 2
0081de43 3bd8                     cmp       ebx, eax
0081de45 7348                     jae       0x81de8f
0081de47 8b0c99                   mov       ecx, dword ptr [ecx + ebx*4]
0081de4a 8b11                     mov       edx, dword ptr [ecx]
0081de4c 57                       push      edi
0081de4d ff92f4000000             call      dword ptr [edx + 0xf4]
0081de53 8bc8                     mov       ecx, eax
0081de55 e8367e2000               call      0xa25c90
0081de5a 85c0                     test      eax, eax
0081de5c 742e                     je        0x81de8c
0081de5e 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081de61 8b0c98                   mov       ecx, dword ptr [eax + ebx*4]
0081de64 8b11                     mov       edx, dword ptr [ecx]
0081de66 8bbe1c020000             mov       edi, dword ptr [esi + 0x21c]
0081de6c 6a00                     push      0
0081de6e ff92f4000000             call      dword ptr [edx + 0xf4]
0081de74 8bc8                     mov       ecx, eax
0081de76 e8157e2000               call      0xa25c90
0081de7b 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
0081de81 83c030                   add       eax, 0x30
0081de84 33fa                     xor       edi, edx
0081de86 03f8                     add       edi, eax
0081de88 8938                     mov       dword ptr [eax], edi
0081de8a 33ff                     xor       edi, edi
0081de8c 43                       inc       ebx
0081de8d eba5                     jmp       0x81de34
0081de8f 3bcf                     cmp       ecx, edi
0081de91 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081de98 7409                     je        0x81dea3
0081de9a 51                       push      ecx
0081de9b e83d213e00               call      0xbfffdd
0081dea0 83c404                   add       esp, 4
0081dea3 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0081dea6 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
0081dea9 83c104                   add       ecx, 4
0081deac 48                       dec       eax
0081dead 897dd8                   mov       dword ptr [ebp - 0x28], edi
0081deb0 897ddc                   mov       dword ptr [ebp - 0x24], edi
0081deb3 897de0                   mov       dword ptr [ebp - 0x20], edi
0081deb6 894dec                   mov       dword ptr [ebp - 0x14], ecx
0081deb9 8945e8                   mov       dword ptr [ebp - 0x18], eax
0081debc 0f8536ffffff             jne       0x81ddf8
0081dec2 e987010000               jmp       0x81e04e
0081dec7 83f905                   cmp       ecx, 5
0081deca 0f857e010000             jne       0x81e04e
0081ded0 8945ec                   mov       dword ptr [ebp - 0x14], eax
0081ded3 c745e802000000           mov       dword ptr [ebp - 0x18], 2
0081deda 8d9b00000000             lea       ebx, [ebx]
0081dee0 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
0081dee3 8b7dec                   mov       edi, dword ptr [ebp - 0x14]
0081dee6 8b0f                     mov       ecx, dword ptr [edi]
0081dee8 8b01                     mov       eax, dword ptr [ecx]
0081deea 6a1e                     push      0x1e
0081deec 52                       push      edx
0081deed 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
0081def0 52                       push      edx
0081def1 ff5028                   call      dword ptr [eax + 0x28]
0081def4 8b0f                     mov       ecx, dword ptr [edi]
0081def6 8b01                     mov       eax, dword ptr [ecx]
0081def8 8d55d4                   lea       edx, [ebp - 0x2c]
0081defb 52                       push      edx
0081defc ff505c                   call      dword ptr [eax + 0x5c]
0081deff 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081df05 6a00                     push      0
0081df07 8d45d4                   lea       eax, [ebp - 0x2c]
0081df0a 50                       push      eax
0081df0b 6a00                     push      0
0081df0d 6a02                     push      2
0081df0f 56                       push      esi
0081df10 c745fc0a000000           mov       dword ptr [ebp - 4], 0xa
0081df17 e84401cfff               call      0x50e060
0081df1c 33db                     xor       ebx, ebx
0081df1e 8bff                     mov       edi, edi
0081df20 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
0081df23 85c9                     test      ecx, ecx
0081df25 7453                     je        0x81df7a
0081df27 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
0081df2a 2bc1                     sub       eax, ecx
0081df2c c1f802                   sar       eax, 2
0081df2f 3bd8                     cmp       ebx, eax
0081df31 7347                     jae       0x81df7a
0081df33 8b0c99                   mov       ecx, dword ptr [ecx + ebx*4]
0081df36 8b11                     mov       edx, dword ptr [ecx]
0081df38 6a00                     push      0
0081df3a ff92f4000000             call      dword ptr [edx + 0xf4]
0081df40 8bc8                     mov       ecx, eax
0081df42 e8497d2000               call      0xa25c90
0081df47 85c0                     test      eax, eax
0081df49 742c                     je        0x81df77
0081df4b 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081df4e 8b0c98                   mov       ecx, dword ptr [eax + ebx*4]
0081df51 8b11                     mov       edx, dword ptr [ecx]
0081df53 8bbe1c020000             mov       edi, dword ptr [esi + 0x21c]
0081df59 6a00                     push      0
0081df5b ff92f4000000             call      dword ptr [edx + 0xf4]
0081df61 8bc8                     mov       ecx, eax
0081df63 e8287d2000               call      0xa25c90
0081df68 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
0081df6e 83c030                   add       eax, 0x30
0081df71 33fa                     xor       edi, edx
0081df73 03f8                     add       edi, eax
0081df75 8938                     mov       dword ptr [eax], edi
0081df77 43                       inc       ebx
0081df78 eba6                     jmp       0x81df20
0081df7a 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081df7d c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081df84 e8c76de2ff               call      0x644d50
0081df89 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0081df8c 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
0081df8f 83c104                   add       ecx, 4
0081df92 48                       dec       eax
0081df93 894dec                   mov       dword ptr [ebp - 0x14], ecx
0081df96 8945e8                   mov       dword ptr [ebp - 0x18], eax
0081df99 0f8541ffffff             jne       0x81dee0
0081df9f e9aa000000               jmp       0x81e04e
0081dfa4 8b8e10020000             mov       ecx, dword ptr [esi + 0x210]
0081dfaa 8b01                     mov       eax, dword ptr [ecx]
0081dfac 6a1e                     push      0x1e
0081dfae 52                       push      edx
0081dfaf 53                       push      ebx
0081dfb0 ff5028                   call      dword ptr [eax + 0x28]
0081dfb3 8b8e10020000             mov       ecx, dword ptr [esi + 0x210]
0081dfb9 8b11                     mov       edx, dword ptr [ecx]
0081dfbb 8d45d4                   lea       eax, [ebp - 0x2c]
0081dfbe 50                       push      eax
0081dfbf ff525c                   call      dword ptr [edx + 0x5c]
0081dfc2 6a00                     push      0
0081dfc4 8d4dd4                   lea       ecx, [ebp - 0x2c]
0081dfc7 51                       push      ecx
0081dfc8 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
0081dfce 6a00                     push      0
0081dfd0 57                       push      edi
0081dfd1 56                       push      esi
0081dfd2 c745fc0b000000           mov       dword ptr [ebp - 4], 0xb
0081dfd9 e88200cfff               call      0x50e060
0081dfde 33db                     xor       ebx, ebx
0081dfe0 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
0081dfe3 85c9                     test      ecx, ecx
0081dfe5 7453                     je        0x81e03a
0081dfe7 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
0081dfea 2bc1                     sub       eax, ecx
0081dfec c1f802                   sar       eax, 2
0081dfef 3bd8                     cmp       ebx, eax
0081dff1 7347                     jae       0x81e03a
0081dff3 8b0c99                   mov       ecx, dword ptr [ecx + ebx*4]
0081dff6 8b11                     mov       edx, dword ptr [ecx]
0081dff8 6a00                     push      0
0081dffa ff92f4000000             call      dword ptr [edx + 0xf4]
0081e000 8bc8                     mov       ecx, eax
0081e002 e8897c2000               call      0xa25c90
0081e007 85c0                     test      eax, eax
0081e009 742c                     je        0x81e037
0081e00b 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
0081e00e 8b0c98                   mov       ecx, dword ptr [eax + ebx*4]
0081e011 8b11                     mov       edx, dword ptr [ecx]
0081e013 8bbe1c020000             mov       edi, dword ptr [esi + 0x21c]
0081e019 6a00                     push      0
0081e01b ff92f4000000             call      dword ptr [edx + 0xf4]
0081e021 8bc8                     mov       ecx, eax
0081e023 e8687c2000               call      0xa25c90
0081e028 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
0081e02e 83c030                   add       eax, 0x30
0081e031 33fa                     xor       edi, edx
0081e033 03f8                     add       edi, eax
0081e035 8938                     mov       dword ptr [eax], edi
0081e037 43                       inc       ebx
0081e038 eba6                     jmp       0x81dfe0
0081e03a 85c9                     test      ecx, ecx
0081e03c c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0081e043 7409                     je        0x81e04e
0081e045 51                       push      ecx
0081e046 e8921f3e00               call      0xbfffdd
0081e04b 83c404                   add       esp, 4
0081e04e a148280001               mov       eax, dword ptr [0x1002848]
0081e053 83b8a819000002           cmp       dword ptr [eax + 0x19a8], 2
0081e05a 0f8565000000             jne       0x81e0c5
0081e060 8b8614020000             mov       eax, dword ptr [esi + 0x214]
0081e066 85c0                     test      eax, eax
0081e068 8d9e14020000             lea       ebx, [esi + 0x214]
0081e06e 7455                     je        0x81e0c5
0081e070 8b8618020000             mov       eax, dword ptr [esi + 0x218]
0081e076 85c0                     test      eax, eax
0081e078 744b                     je        0x81e0c5
0081e07a c645f200                 mov       byte ptr [ebp - 0xe], 0
0081e07e c645f300                 mov       byte ptr [ebp - 0xd], 0
0081e082 33ff                     xor       edi, edi
0081e084 8b0b                     mov       ecx, dword ptr [ebx]
0081e086 8b11                     mov       edx, dword ptr [ecx]
0081e088 ff5240                   call      dword ptr [edx + 0x40]
0081e08b 84c0                     test      al, al
0081e08d 7405                     je        0x81e094
0081e08f c6443df201               mov       byte ptr [ebp + edi - 0xe], 1
0081e094 47                       inc       edi
0081e095 83c304                   add       ebx, 4
0081e098 83ff02                   cmp       edi, 2
0081e09b 7ce7                     jl        0x81e084
0081e09d 8a45f2                   mov       al, byte ptr [ebp - 0xe]
0081e0a0 84c0                     test      al, al
0081e0a2 7444                     je        0x81e0e8
0081e0a4 8a45f3                   mov       al, byte ptr [ebp - 0xd]
0081e0a7 84c0                     test      al, al
0081e0a9 743d                     je        0x81e0e8
0081e0ab 8b06                     mov       eax, dword ptr [esi]
0081e0ad 6a00                     push      0
0081e0af 8bce                     mov       ecx, esi
0081e0b1 ff5060                   call      dword ptr [eax + 0x60]
0081e0b4 5f                       pop       edi
0081e0b5 5e                       pop       esi
0081e0b6 5b                       pop       ebx
0081e0b7 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
0081e0ba 64890d00000000           mov       dword ptr fs:[0], ecx
0081e0c1 8be5                     mov       esp, ebp
0081e0c3 5d                       pop       ebp
0081e0c4 c3                       ret       
0081e0c5 8b8e10020000             mov       ecx, dword ptr [esi + 0x210]
0081e0cb 8b11                     mov       edx, dword ptr [ecx]
0081e0cd ff5240                   call      dword ptr [edx + 0x40]
0081e0d0 ebd5                     jmp       0x81e0a7
0081e0d2 e8298e2e00               call      0xb06f00
0081e0d7 3b8608020000             cmp       eax, dword ptr [esi + 0x208]
0081e0dd 7c09                     jl        0x81e0e8
0081e0df 8b16                     mov       edx, dword ptr [esi]
0081e0e1 6a00                     push      0
0081e0e3 8bce                     mov       ecx, esi
0081e0e5 ff5260                   call      dword ptr [edx + 0x60]
0081e0e8 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
0081e0eb 5f                       pop       edi
0081e0ec 5e                       pop       esi
0081e0ed 5b                       pop       ebx
0081e0ee 64890d00000000           mov       dword ptr fs:[0], ecx
0081e0f5 8be5                     mov       esp, ebp
0081e0f7 5d                       pop       ebp
0081e0f8 c3                       ret       
