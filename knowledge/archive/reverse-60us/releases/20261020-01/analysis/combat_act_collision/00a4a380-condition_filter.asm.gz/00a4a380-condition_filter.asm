00a4a380 55                       push       ebp
00a4a381 8bec                     mov        ebp, esp
00a4a383 6aff                     push       -1
00a4a385 68cef5c800               push       0xc8f5ce
00a4a38a 64a100000000             mov        eax, dword ptr fs:[0]
00a4a390 50                       push       eax
00a4a391 64892500000000           mov        dword ptr fs:[0], esp
00a4a398 83ec3c                   sub        esp, 0x3c
00a4a39b 53                       push       ebx
00a4a39c 8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00a4a39f 33d2                     xor        edx, edx
00a4a3a1 3bda                     cmp        ebx, edx
00a4a3a3 894df0                   mov        dword ptr [ebp - 0x10], ecx
00a4a3a6 7513                     jne        0xa4a3bb
00a4a3a8 32c0                     xor        al, al
00a4a3aa 5b                       pop        ebx
00a4a3ab 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4a3ae 64890d00000000           mov        dword ptr fs:[0], ecx
00a4a3b5 8be5                     mov        esp, ebp
00a4a3b7 5d                       pop        ebp
00a4a3b8 c20800                   ret        8
00a4a3bb 56                       push       esi
00a4a3bc 57                       push       edi
00a4a3bd 8b7d08                   mov        edi, dword ptr [ebp + 8]
00a4a3c0 8b07                     mov        eax, dword ptr [edi]
00a4a3c2 83f805                   cmp        eax, 5
00a4a3c5 0f8521010000             jne        0xa4a4ec
00a4a3cb 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a3ce 2b4728                   sub        eax, dword ptr [edi + 0x28]
00a4a3d1 c1f802                   sar        eax, 2
00a4a3d4 83f802                   cmp        eax, 2
00a4a3d7 7323                     jae        0xa4a3fc
00a4a3d9 68f098e400               push       0xe498f0
00a4a3de ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a3e4 83c404                   add        esp, 4
00a4a3e7 5f                       pop        edi
00a4a3e8 5e                       pop        esi
00a4a3e9 32c0                     xor        al, al
00a4a3eb 5b                       pop        ebx
00a4a3ec 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4a3ef 64890d00000000           mov        dword ptr fs:[0], ecx
00a4a3f6 8be5                     mov        esp, ebp
00a4a3f8 5d                       pop        ebp
00a4a3f9 c20800                   ret        8
00a4a3fc 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4a3ff 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a402 0f84a0170000             je         0xa4bba8
00a4a408 8d4e04                   lea        ecx, [esi + 4]
00a4a40b 894d0c                   mov        dword ptr [ebp + 0xc], ecx
00a4a40e eb02                     jmp        0xa4a412
00a4a410 33d2                     xor        edx, edx
00a4a412 8b06                     mov        eax, dword ptr [esi]
00a4a414 8b4f28                   mov        ecx, dword ptr [edi + 0x28]
00a4a417 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4a41a 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a41d 2bc1                     sub        eax, ecx
00a4a41f c1f802                   sar        eax, 2
00a4a422 83f801                   cmp        eax, 1
00a4a425 7729                     ja         0xa4a450
00a4a427 50                       push       eax
00a4a428 6a01                     push       1
00a4a42a 685829cd00               push       0xcd2958
00a4a42f 68a0b3cb00               push       0xcbb3a0
00a4a434 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a43a 83c410                   add        esp, 0x10
00a4a43d 6a00                     push       0
00a4a43f 6a00                     push       0
00a4a441 6a00                     push       0
00a4a443 688c0000c0               push       0xc000008c
00a4a448 ff1528f04001             call       dword ptr [0x140f028]
00a4a44e 33d2                     xor        edx, edx
00a4a450 8b4f28                   mov        ecx, dword ptr [edi + 0x28]
00a4a453 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a456 2bc1                     sub        eax, ecx
00a4a458 c1f802                   sar        eax, 2
00a4a45b 3bc2                     cmp        eax, edx
00a4a45d 894d08                   mov        dword ptr [ebp + 8], ecx
00a4a460 7727                     ja         0xa4a489
00a4a462 50                       push       eax
00a4a463 6a00                     push       0
00a4a465 685829cd00               push       0xcd2958
00a4a46a 68a0b3cb00               push       0xcbb3a0
00a4a46f ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a475 83c410                   add        esp, 0x10
00a4a478 6a00                     push       0
00a4a47a 6a00                     push       0
00a4a47c 6a00                     push       0
00a4a47e 688c0000c0               push       0xc000008c
00a4a483 ff1528f04001             call       dword ptr [0x140f028]
00a4a489 8b5508                   mov        edx, dword ptr [ebp + 8]
00a4a48c 8b4a04                   mov        ecx, dword ptr [edx + 4]
00a4a48f 8b4728                   mov        eax, dword ptr [edi + 0x28]
00a4a492 8b10                     mov        edx, dword ptr [eax]
00a4a494 51                       push       ecx
00a4a495 8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00a4a498 8b01                     mov        eax, dword ptr [ecx]
00a4a49a 52                       push       edx
00a4a49b ff909c000000             call       dword ptr [eax + 0x9c]
00a4a4a1 50                       push       eax
00a4a4a2 e8294fb2ff               call       0x56f3d0
00a4a4a7 83c40c                   add        esp, 0xc
00a4a4aa 84c0                     test       al, al
00a4a4ac 7524                     jne        0xa4a4d2
00a4a4ae 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4a4b1 8b4b08                   mov        ecx, dword ptr [ebx + 8]
00a4a4b4 2bc8                     sub        ecx, eax
00a4a4b6 c1f902                   sar        ecx, 2
00a4a4b9 c1e102                   shl        ecx, 2
00a4a4bc 51                       push       ecx
00a4a4bd 50                       push       eax
00a4a4be 56                       push       esi
00a4a4bf e8cc551b00               call       0xbffa90
00a4a4c4 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4a4c7 83c40c                   add        esp, 0xc
00a4a4ca 83c0fc                   add        eax, -4
00a4a4cd 894308                   mov        dword ptr [ebx + 8], eax
00a4a4d0 eb0c                     jmp        0xa4a4de
00a4a4d2 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4a4d5 83c604                   add        esi, 4
00a4a4d8 83c004                   add        eax, 4
00a4a4db 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4a4de 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a4e1 0f8529ffffff             jne        0xa4a410
00a4a4e7 e9bc160000               jmp        0xa4bba8
00a4a4ec 83f802                   cmp        eax, 2
00a4a4ef 0f8586010000             jne        0xa4a67b
00a4a4f5 8b572c                   mov        edx, dword ptr [edi + 0x2c]
00a4a4f8 2b5728                   sub        edx, dword ptr [edi + 0x28]
00a4a4fb c1fa02                   sar        edx, 2
00a4a4fe 3bd0                     cmp        edx, eax
00a4a500 7323                     jae        0xa4a525
00a4a502 68a098e400               push       0xe498a0
00a4a507 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a50d 83c404                   add        esp, 4
00a4a510 5f                       pop        edi
00a4a511 5e                       pop        esi
00a4a512 32c0                     xor        al, al
00a4a514 5b                       pop        ebx
00a4a515 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4a518 64890d00000000           mov        dword ptr fs:[0], ecx
00a4a51f 8be5                     mov        esp, ebp
00a4a521 5d                       pop        ebp
00a4a522 c20800                   ret        8
00a4a525 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4a528 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a52b 0f8477160000             je         0xa4bba8
00a4a531 8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00a4a534 8d4604                   lea        eax, [esi + 4]
00a4a537 894508                   mov        dword ptr [ebp + 8], eax
00a4a53a 8d9b00000000             lea        ebx, [ebx]
00a4a540 8b0e                     mov        ecx, dword ptr [esi]
00a4a542 6a00                     push       0
00a4a544 687c28f400               push       0xf4287c
00a4a549 681009f400               push       0xf40910
00a4a54e 6a00                     push       0
00a4a550 51                       push       ecx
00a4a551 c7450c00000000           mov        dword ptr [ebp + 0xc], 0
00a4a558 e8ae671b00               call       0xc00d0b
00a4a55d 83c414                   add        esp, 0x14
00a4a560 85c0                     test       eax, eax
00a4a562 741c                     je         0xa4a580
00a4a564 8b10                     mov        edx, dword ptr [eax]
00a4a566 8bc8                     mov        ecx, eax
00a4a568 ff5248                   call       dword ptr [edx + 0x48]
00a4a56b 8b08                     mov        ecx, dword ptr [eax]
00a4a56d 85c9                     test       ecx, ecx
00a4a56f 7503                     jne        0xa4a574
00a4a571 8d4808                   lea        ecx, [eax + 8]
00a4a574 8b01                     mov        eax, dword ptr [ecx]
00a4a576 6a00                     push       0
00a4a578 ff5008                   call       dword ptr [eax + 8]
00a4a57b d95d0c                   fstp       dword ptr [ebp + 0xc]
00a4a57e eb2d                     jmp        0xa4a5ad
00a4a580 685098e400               push       0xe49850
00a4a585 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a58b 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a58e 8b4b08                   mov        ecx, dword ptr [ebx + 8]
00a4a591 2bc8                     sub        ecx, eax
00a4a593 c1f902                   sar        ecx, 2
00a4a596 c1e102                   shl        ecx, 2
00a4a599 51                       push       ecx
00a4a59a 50                       push       eax
00a4a59b 56                       push       esi
00a4a59c e8ef541b00               call       0xbffa90
00a4a5a1 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4a5a4 83c410                   add        esp, 0x10
00a4a5a7 83c0fc                   add        eax, -4
00a4a5aa 894308                   mov        dword ptr [ebx + 8], eax
00a4a5ad 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a5b0 2b4728                   sub        eax, dword ptr [edi + 0x28]
00a4a5b3 c1f802                   sar        eax, 2
00a4a5b6 83f801                   cmp        eax, 1
00a4a5b9 7727                     ja         0xa4a5e2
00a4a5bb 50                       push       eax
00a4a5bc 6a01                     push       1
00a4a5be 685829cd00               push       0xcd2958
00a4a5c3 68a0b3cb00               push       0xcbb3a0
00a4a5c8 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a5ce 83c410                   add        esp, 0x10
00a4a5d1 6a00                     push       0
00a4a5d3 6a00                     push       0
00a4a5d5 6a00                     push       0
00a4a5d7 688c0000c0               push       0xc000008c
00a4a5dc ff1528f04001             call       dword ptr [0x140f028]
00a4a5e2 8b5728                   mov        edx, dword ptr [edi + 0x28]
00a4a5e5 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a5e8 8bca                     mov        ecx, edx
00a4a5ea 2bc1                     sub        eax, ecx
00a4a5ec c1f802                   sar        eax, 2
00a4a5ef 85c0                     test       eax, eax
00a4a5f1 8955e8                   mov        dword ptr [ebp - 0x18], edx
00a4a5f4 7727                     ja         0xa4a61d
00a4a5f6 50                       push       eax
00a4a5f7 6a00                     push       0
00a4a5f9 685829cd00               push       0xcd2958
00a4a5fe 68a0b3cb00               push       0xcbb3a0
00a4a603 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a609 83c410                   add        esp, 0x10
00a4a60c 6a00                     push       0
00a4a60e 6a00                     push       0
00a4a610 6a00                     push       0
00a4a612 688c0000c0               push       0xc000008c
00a4a617 ff1528f04001             call       dword ptr [0x140f028]
00a4a61d 8b45e8                   mov        eax, dword ptr [ebp - 0x18]
00a4a620 db4004                   fild       dword ptr [eax + 4]
00a4a623 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4a626 51                       push       ecx
00a4a627 8b4f28                   mov        ecx, dword ptr [edi + 0x28]
00a4a62a 8b11                     mov        edx, dword ptr [ecx]
00a4a62c d91c24                   fstp       dword ptr [esp]
00a4a62f 52                       push       edx
00a4a630 50                       push       eax
00a4a631 e8fa4cb2ff               call       0x56f330
00a4a636 83c40c                   add        esp, 0xc
00a4a639 84c0                     test       al, al
00a4a63b 7524                     jne        0xa4a661
00a4a63d 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a640 8b4b08                   mov        ecx, dword ptr [ebx + 8]
00a4a643 2bc8                     sub        ecx, eax
00a4a645 c1f902                   sar        ecx, 2
00a4a648 c1e102                   shl        ecx, 2
00a4a64b 51                       push       ecx
00a4a64c 50                       push       eax
00a4a64d 56                       push       esi
00a4a64e e83d541b00               call       0xbffa90
00a4a653 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4a656 83c40c                   add        esp, 0xc
00a4a659 83c0fc                   add        eax, -4
00a4a65c 894308                   mov        dword ptr [ebx + 8], eax
00a4a65f eb0c                     jmp        0xa4a66d
00a4a661 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a664 83c604                   add        esi, 4
00a4a667 83c004                   add        eax, 4
00a4a66a 894508                   mov        dword ptr [ebp + 8], eax
00a4a66d 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a670 0f85cafeffff             jne        0xa4a540
00a4a676 e92d150000               jmp        0xa4bba8
00a4a67b 83f803                   cmp        eax, 3
00a4a67e 0f85f1000000             jne        0xa4a775
00a4a684 8b572c                   mov        edx, dword ptr [edi + 0x2c]
00a4a687 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4a68a 83c724                   add        edi, 0x24
00a4a68d 2bd6                     sub        edx, esi
00a4a68f c1fa02                   sar        edx, 2
00a4a692 83fa02                   cmp        edx, 2
00a4a695 7323                     jae        0xa4a6ba
00a4a697 680098e400               push       0xe49800
00a4a69c ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a6a2 83c404                   add        esp, 4
00a4a6a5 5f                       pop        edi
00a4a6a6 5e                       pop        esi
00a4a6a7 32c0                     xor        al, al
00a4a6a9 5b                       pop        ebx
00a4a6aa 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4a6ad 64890d00000000           mov        dword ptr fs:[0], ecx
00a4a6b4 8be5                     mov        esp, ebp
00a4a6b6 5d                       pop        ebp
00a4a6b7 c20800                   ret        8
00a4a6ba 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4a6bd 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a6c0 0f84e2140000             je         0xa4bba8
00a4a6c6 8b06                     mov        eax, dword ptr [esi]
00a4a6c8 6a00                     push       0
00a4a6ca 687c28f400               push       0xf4287c
00a4a6cf 681009f400               push       0xf40910
00a4a6d4 6a00                     push       0
00a4a6d6 50                       push       eax
00a4a6d7 c7450800000000           mov        dword ptr [ebp + 8], 0
00a4a6de e828661b00               call       0xc00d0b
00a4a6e3 83c414                   add        esp, 0x14
00a4a6e6 85c0                     test       eax, eax
00a4a6e8 741c                     je         0xa4a706
00a4a6ea 8b10                     mov        edx, dword ptr [eax]
00a4a6ec 8bc8                     mov        ecx, eax
00a4a6ee ff5248                   call       dword ptr [edx + 0x48]
00a4a6f1 8b08                     mov        ecx, dword ptr [eax]
00a4a6f3 85c9                     test       ecx, ecx
00a4a6f5 7503                     jne        0xa4a6fa
00a4a6f7 8d4808                   lea        ecx, [eax + 8]
00a4a6fa 8b01                     mov        eax, dword ptr [ecx]
00a4a6fc 6a01                     push       1
00a4a6fe ff5008                   call       dword ptr [eax + 8]
00a4a701 d95d08                   fstp       dword ptr [ebp + 8]
00a4a704 eb1d                     jmp        0xa4a723
00a4a706 68b097e400               push       0xe497b0
00a4a70b ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a711 83c404                   add        esp, 4
00a4a714 56                       push       esi
00a4a715 8d4de4                   lea        ecx, [ebp - 0x1c]
00a4a718 51                       push       ecx
00a4a719 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4a71c e88fe7a1ff               call       0x468eb0
00a4a721 8b30                     mov        esi, dword ptr [eax]
00a4a723 6a01                     push       1
00a4a725 8bcf                     mov        ecx, edi
00a4a727 e85440ffff               call       0xa3e780
00a4a72c 6a00                     push       0
00a4a72e 8bcf                     mov        ecx, edi
00a4a730 8bd8                     mov        ebx, eax
00a4a732 e84940ffff               call       0xa3e780
00a4a737 db03                     fild       dword ptr [ebx]
00a4a739 8b10                     mov        edx, dword ptr [eax]
00a4a73b 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a73e 51                       push       ecx
00a4a73f d91c24                   fstp       dword ptr [esp]
00a4a742 52                       push       edx
00a4a743 50                       push       eax
00a4a744 e8e74bb2ff               call       0x56f330
00a4a749 83c40c                   add        esp, 0xc
00a4a74c 84c0                     test       al, al
00a4a74e 7511                     jne        0xa4a761
00a4a750 56                       push       esi
00a4a751 8d4de8                   lea        ecx, [ebp - 0x18]
00a4a754 51                       push       ecx
00a4a755 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4a758 e853e7a1ff               call       0x468eb0
00a4a75d 8b30                     mov        esi, dword ptr [eax]
00a4a75f eb03                     jmp        0xa4a764
00a4a761 83c604                   add        esi, 4
00a4a764 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4a767 3b7208                   cmp        esi, dword ptr [edx + 8]
00a4a76a 0f8556ffffff             jne        0xa4a6c6
00a4a770 e933140000               jmp        0xa4bba8
00a4a775 83f804                   cmp        eax, 4
00a4a778 0f85f1000000             jne        0xa4a86f
00a4a77e 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a781 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4a784 83c724                   add        edi, 0x24
00a4a787 2bc6                     sub        eax, esi
00a4a789 c1f802                   sar        eax, 2
00a4a78c 83f802                   cmp        eax, 2
00a4a78f 7323                     jae        0xa4a7b4
00a4a791 686097e400               push       0xe49760
00a4a796 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a79c 83c404                   add        esp, 4
00a4a79f 5f                       pop        edi
00a4a7a0 5e                       pop        esi
00a4a7a1 32c0                     xor        al, al
00a4a7a3 5b                       pop        ebx
00a4a7a4 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4a7a7 64890d00000000           mov        dword ptr fs:[0], ecx
00a4a7ae 8be5                     mov        esp, ebp
00a4a7b0 5d                       pop        ebp
00a4a7b1 c20800                   ret        8
00a4a7b4 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4a7b7 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a7ba 0f84e8130000             je         0xa4bba8
00a4a7c0 8b0e                     mov        ecx, dword ptr [esi]
00a4a7c2 6a00                     push       0
00a4a7c4 687c28f400               push       0xf4287c
00a4a7c9 681009f400               push       0xf40910
00a4a7ce 6a00                     push       0
00a4a7d0 51                       push       ecx
00a4a7d1 c7450800000000           mov        dword ptr [ebp + 8], 0
00a4a7d8 e82e651b00               call       0xc00d0b
00a4a7dd 83c414                   add        esp, 0x14
00a4a7e0 85c0                     test       eax, eax
00a4a7e2 741c                     je         0xa4a800
00a4a7e4 8b10                     mov        edx, dword ptr [eax]
00a4a7e6 8bc8                     mov        ecx, eax
00a4a7e8 ff5248                   call       dword ptr [edx + 0x48]
00a4a7eb 8b08                     mov        ecx, dword ptr [eax]
00a4a7ed 85c9                     test       ecx, ecx
00a4a7ef 7503                     jne        0xa4a7f4
00a4a7f1 8d4808                   lea        ecx, [eax + 8]
00a4a7f4 8b01                     mov        eax, dword ptr [ecx]
00a4a7f6 6a02                     push       2
00a4a7f8 ff5008                   call       dword ptr [eax + 8]
00a4a7fb d95d08                   fstp       dword ptr [ebp + 8]
00a4a7fe eb1d                     jmp        0xa4a81d
00a4a800 681097e400               push       0xe49710
00a4a805 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a80b 83c404                   add        esp, 4
00a4a80e 56                       push       esi
00a4a80f 8d4de4                   lea        ecx, [ebp - 0x1c]
00a4a812 51                       push       ecx
00a4a813 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4a816 e895e6a1ff               call       0x468eb0
00a4a81b 8b30                     mov        esi, dword ptr [eax]
00a4a81d 6a01                     push       1
00a4a81f 8bcf                     mov        ecx, edi
00a4a821 e85a3fffff               call       0xa3e780
00a4a826 6a00                     push       0
00a4a828 8bcf                     mov        ecx, edi
00a4a82a 8bd8                     mov        ebx, eax
00a4a82c e84f3fffff               call       0xa3e780
00a4a831 db03                     fild       dword ptr [ebx]
00a4a833 8b10                     mov        edx, dword ptr [eax]
00a4a835 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a838 51                       push       ecx
00a4a839 d91c24                   fstp       dword ptr [esp]
00a4a83c 52                       push       edx
00a4a83d 50                       push       eax
00a4a83e e8ed4ab2ff               call       0x56f330
00a4a843 83c40c                   add        esp, 0xc
00a4a846 84c0                     test       al, al
00a4a848 7511                     jne        0xa4a85b
00a4a84a 56                       push       esi
00a4a84b 8d4de8                   lea        ecx, [ebp - 0x18]
00a4a84e 51                       push       ecx
00a4a84f 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4a852 e859e6a1ff               call       0x468eb0
00a4a857 8b30                     mov        esi, dword ptr [eax]
00a4a859 eb03                     jmp        0xa4a85e
00a4a85b 83c604                   add        esi, 4
00a4a85e 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4a861 3b7208                   cmp        esi, dword ptr [edx + 8]
00a4a864 0f8556ffffff             jne        0xa4a7c0
00a4a86a e939130000               jmp        0xa4bba8
00a4a86f 83f817                   cmp        eax, 0x17
00a4a872 0f8588020000             jne        0xa4ab00
00a4a878 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4a87b 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4a87e 83c724                   add        edi, 0x24
00a4a881 2bc6                     sub        eax, esi
00a4a883 c1f802                   sar        eax, 2
00a4a886 83f803                   cmp        eax, 3
00a4a889 7323                     jae        0xa4a8ae
00a4a88b 68c896e400               push       0xe496c8
00a4a890 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a896 83c404                   add        esp, 4
00a4a899 5f                       pop        edi
00a4a89a 5e                       pop        esi
00a4a89b 32c0                     xor        al, al
00a4a89d 5b                       pop        ebx
00a4a89e 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4a8a1 64890d00000000           mov        dword ptr fs:[0], ecx
00a4a8a8 8be5                     mov        esp, ebp
00a4a8aa 5d                       pop        ebp
00a4a8ab c20800                   ret        8
00a4a8ae 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4a8b1 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4a8b4 897508                   mov        dword ptr [ebp + 8], esi
00a4a8b7 0f84eb120000             je         0xa4bba8
00a4a8bd 8b0e                     mov        ecx, dword ptr [esi]
00a4a8bf 8b11                     mov        edx, dword ptr [ecx]
00a4a8c1 8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00a4a8c4 6a21                     push       0x21
00a4a8c6 ff522c                   call       dword ptr [edx + 0x2c]
00a4a8c9 84c0                     test       al, al
00a4a8cb 7525                     jne        0xa4a8f2
00a4a8cd 8b0e                     mov        ecx, dword ptr [esi]
00a4a8cf 8b01                     mov        eax, dword ptr [ecx]
00a4a8d1 6a11                     push       0x11
00a4a8d3 ff502c                   call       dword ptr [eax + 0x2c]
00a4a8d6 84c0                     test       al, al
00a4a8d8 7518                     jne        0xa4a8f2
00a4a8da 687896e400               push       0xe49678
00a4a8df ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a8e5 83c404                   add        esp, 4
00a4a8e8 56                       push       esi
00a4a8e9 8d4de4                   lea        ecx, [ebp - 0x1c]
00a4a8ec 51                       push       ecx
00a4a8ed e9f1010000               jmp        0xa4aae3
00a4a8f2 8b0e                     mov        ecx, dword ptr [esi]
00a4a8f4 8b11                     mov        edx, dword ptr [ecx]
00a4a8f6 6a21                     push       0x21
00a4a8f8 ff522c                   call       dword ptr [edx + 0x2c]
00a4a8fb 84c0                     test       al, al
00a4a8fd 0f841a010000             je         0xa4aa1d
00a4a903 8b06                     mov        eax, dword ptr [esi]
00a4a905 6a00                     push       0
00a4a907 68a028f400               push       0xf428a0
00a4a90c 681009f400               push       0xf40910
00a4a911 6a00                     push       0
00a4a913 50                       push       eax
00a4a914 e8f2631b00               call       0xc00d0b
00a4a919 8bd8                     mov        ebx, eax
00a4a91b 83c414                   add        esp, 0x14
00a4a91e 85db                     test       ebx, ebx
00a4a920 0f84c9010000             je         0xa4aaef
00a4a926 8b13                     mov        edx, dword ptr [ebx]
00a4a928 8bcb                     mov        ecx, ebx
00a4a92a ff9234020000             call       dword ptr [edx + 0x234]
00a4a930 6a02                     push       2
00a4a932 8bcf                     mov        ecx, edi
00a4a934 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4a937 e8443effff               call       0xa3e780
00a4a93c 833807                   cmp        dword ptr [eax], 7
00a4a93f 6a01                     push       1
00a4a941 8bcf                     mov        ecx, edi
00a4a943 7529                     jne        0xa4a96e
00a4a945 e8363effff               call       0xa3e780
00a4a94a 8bf0                     mov        esi, eax
00a4a94c 8b03                     mov        eax, dword ptr [ebx]
00a4a94e 8bcb                     mov        ecx, ebx
00a4a950 ff9038020000             call       dword ptr [eax + 0x238]
00a4a956 8bc8                     mov        ecx, eax
00a4a958 0faf0e                   imul       ecx, dword ptr [esi]
00a4a95b b81f85eb51               mov        eax, 0x51eb851f
00a4a960 f7e9                     imul       ecx
00a4a962 c1fa05                   sar        edx, 5
00a4a965 8bf2                     mov        esi, edx
00a4a967 c1ee1f                   shr        esi, 0x1f
00a4a96a 03f2                     add        esi, edx
00a4a96c eb07                     jmp        0xa4a975
00a4a96e e80d3effff               call       0xa3e780
00a4a973 8b30                     mov        esi, dword ptr [eax]
00a4a975 6a00                     push       0
00a4a977 8bcf                     mov        ecx, edi
00a4a979 e8023effff               call       0xa3e780
00a4a97e 8b08                     mov        ecx, dword ptr [eax]
00a4a980 8b55e8                   mov        edx, dword ptr [ebp - 0x18]
00a4a983 56                       push       esi
00a4a984 51                       push       ecx
00a4a985 52                       push       edx
00a4a986 e8454ab2ff               call       0x56f3d0
00a4a98b 83c40c                   add        esp, 0xc
00a4a98e 84c0                     test       al, al
00a4a990 751c                     jne        0xa4a9ae
00a4a992 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a995 50                       push       eax
00a4a996 8d4de0                   lea        ecx, [ebp - 0x20]
00a4a999 51                       push       ecx
00a4a99a 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4a99d e80ee5a1ff               call       0x468eb0
00a4a9a2 8b10                     mov        edx, dword ptr [eax]
00a4a9a4 895508                   mov        dword ptr [ebp + 8], edx
00a4a9a7 8bf2                     mov        esi, edx
00a4a9a9 e941010000               jmp        0xa4aaef
00a4a9ae 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4a9b1 83c004                   add        eax, 4
00a4a9b4 8d8b08020000             lea        ecx, [ebx + 0x208]
00a4a9ba 894508                   mov        dword ptr [ebp + 8], eax
00a4a9bd 894df0                   mov        dword ptr [ebp - 0x10], ecx
00a4a9c0 e82b870000               call       0xa530f0
00a4a9c5 6a00                     push       0
00a4a9c7 8bcf                     mov        ecx, edi
00a4a9c9 8945ec                   mov        dword ptr [ebp - 0x14], eax
00a4a9cc e8af3dffff               call       0xa3e780
00a4a9d1 8b00                     mov        eax, dword ptr [eax]
00a4a9d3 8b5de8                   mov        ebx, dword ptr [ebp - 0x18]
00a4a9d6 8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00a4a9d9 56                       push       esi
00a4a9da 50                       push       eax
00a4a9db 53                       push       ebx
00a4a9dc 51                       push       ecx
00a4a9dd 684496e400               push       0xe49644
00a4a9e2 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4a9e8 8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00a4a9eb 83c414                   add        esp, 0x14
00a4a9ee e8fd860000               call       0xa530f0
00a4a9f3 6a00                     push       0
00a4a9f5 8bcf                     mov        ecx, edi
00a4a9f7 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4a9fa e8813dffff               call       0xa3e780
00a4a9ff 8b10                     mov        edx, dword ptr [eax]
00a4aa01 8b45e8                   mov        eax, dword ptr [ebp - 0x18]
00a4aa04 56                       push       esi
00a4aa05 52                       push       edx
00a4aa06 53                       push       ebx
00a4aa07 50                       push       eax
00a4aa08 681496e400               push       0xe49614
00a4aa0d e82ea90c00               call       0xb15340
00a4aa12 8b7508                   mov        esi, dword ptr [ebp + 8]
00a4aa15 83c414                   add        esp, 0x14
00a4aa18 e9d2000000               jmp        0xa4aaef
00a4aa1d 8b0e                     mov        ecx, dword ptr [esi]
00a4aa1f 8b11                     mov        edx, dword ptr [ecx]
00a4aa21 6a11                     push       0x11
00a4aa23 ff522c                   call       dword ptr [edx + 0x2c]
00a4aa26 84c0                     test       al, al
00a4aa28 0f84a2000000             je         0xa4aad0
00a4aa2e 8b06                     mov        eax, dword ptr [esi]
00a4aa30 6a00                     push       0
00a4aa32 686c52f500               push       0xf5526c
00a4aa37 681009f400               push       0xf40910
00a4aa3c 6a00                     push       0
00a4aa3e 50                       push       eax
00a4aa3f e8c7621b00               call       0xc00d0b
00a4aa44 8bd8                     mov        ebx, eax
00a4aa46 83c414                   add        esp, 0x14
00a4aa49 85db                     test       ebx, ebx
00a4aa4b 0f849e000000             je         0xa4aaef
00a4aa51 8b13                     mov        edx, dword ptr [ebx]
00a4aa53 8bcb                     mov        ecx, ebx
00a4aa55 ff9234020000             call       dword ptr [edx + 0x234]
00a4aa5b 6a02                     push       2
00a4aa5d 8bcf                     mov        ecx, edi
00a4aa5f 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4aa62 e8193dffff               call       0xa3e780
00a4aa67 833807                   cmp        dword ptr [eax], 7
00a4aa6a 6a01                     push       1
00a4aa6c 8bcf                     mov        ecx, edi
00a4aa6e 752d                     jne        0xa4aa9d
00a4aa70 e80b3dffff               call       0xa3e780
00a4aa75 894508                   mov        dword ptr [ebp + 8], eax
00a4aa78 8b03                     mov        eax, dword ptr [ebx]
00a4aa7a 8bcb                     mov        ecx, ebx
00a4aa7c ff9038020000             call       dword ptr [eax + 0x238]
00a4aa82 8b5508                   mov        edx, dword ptr [ebp + 8]
00a4aa85 8bc8                     mov        ecx, eax
00a4aa87 0faf0a                   imul       ecx, dword ptr [edx]
00a4aa8a b81f85eb51               mov        eax, 0x51eb851f
00a4aa8f f7e9                     imul       ecx
00a4aa91 c1fa05                   sar        edx, 5
00a4aa94 8bda                     mov        ebx, edx
00a4aa96 c1eb1f                   shr        ebx, 0x1f
00a4aa99 03da                     add        ebx, edx
00a4aa9b eb07                     jmp        0xa4aaa4
00a4aa9d e8de3cffff               call       0xa3e780
00a4aaa2 8b18                     mov        ebx, dword ptr [eax]
00a4aaa4 6a00                     push       0
00a4aaa6 8bcf                     mov        ecx, edi
00a4aaa8 e8d33cffff               call       0xa3e780
00a4aaad 8b00                     mov        eax, dword ptr [eax]
00a4aaaf 8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00a4aab2 53                       push       ebx
00a4aab3 50                       push       eax
00a4aab4 51                       push       ecx
00a4aab5 e81649b2ff               call       0x56f3d0
00a4aaba 83c40c                   add        esp, 0xc
00a4aabd 84c0                     test       al, al
00a4aabf 750a                     jne        0xa4aacb
00a4aac1 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4aac4 56                       push       esi
00a4aac5 8d55dc                   lea        edx, [ebp - 0x24]
00a4aac8 52                       push       edx
00a4aac9 eb1a                     jmp        0xa4aae5
00a4aacb 83c604                   add        esi, 4
00a4aace eb1c                     jmp        0xa4aaec
00a4aad0 68d095e400               push       0xe495d0
00a4aad5 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4aadb 83c404                   add        esp, 4
00a4aade 56                       push       esi
00a4aadf 8d45d4                   lea        eax, [ebp - 0x2c]
00a4aae2 50                       push       eax
00a4aae3 8bcb                     mov        ecx, ebx
00a4aae5 e8c6e3a1ff               call       0x468eb0
00a4aaea 8b30                     mov        esi, dword ptr [eax]
00a4aaec 897508                   mov        dword ptr [ebp + 8], esi
00a4aaef 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4aaf2 3b7108                   cmp        esi, dword ptr [ecx + 8]
00a4aaf5 0f85c2fdffff             jne        0xa4a8bd
00a4aafb e9a8100000               jmp        0xa4bba8
00a4ab00 83f818                   cmp        eax, 0x18
00a4ab03 0f854c010000             jne        0xa4ac55
00a4ab09 8b572c                   mov        edx, dword ptr [edi + 0x2c]
00a4ab0c 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4ab0f 83c724                   add        edi, 0x24
00a4ab12 2bd6                     sub        edx, esi
00a4ab14 c1fa02                   sar        edx, 2
00a4ab17 83fa03                   cmp        edx, 3
00a4ab1a 897d08                   mov        dword ptr [ebp + 8], edi
00a4ab1d 7323                     jae        0xa4ab42
00a4ab1f 688895e400               push       0xe49588
00a4ab24 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4ab2a 83c404                   add        esp, 4
00a4ab2d 5f                       pop        edi
00a4ab2e 5e                       pop        esi
00a4ab2f 32c0                     xor        al, al
00a4ab31 5b                       pop        ebx
00a4ab32 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4ab35 64890d00000000           mov        dword ptr fs:[0], ecx
00a4ab3c 8be5                     mov        esp, ebp
00a4ab3e 5d                       pop        ebp
00a4ab3f c20800                   ret        8
00a4ab42 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4ab45 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4ab48 0f845a100000             je         0xa4bba8
00a4ab4e 8bff                     mov        edi, edi
00a4ab50 8b0e                     mov        ecx, dword ptr [esi]
00a4ab52 8b01                     mov        eax, dword ptr [ecx]
00a4ab54 6a11                     push       0x11
00a4ab56 ff502c                   call       dword ptr [eax + 0x2c]
00a4ab59 84c0                     test       al, al
00a4ab5b 751c                     jne        0xa4ab79
00a4ab5d 683895e400               push       0xe49538
00a4ab62 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4ab68 83c404                   add        esp, 4
00a4ab6b 56                       push       esi
00a4ab6c 8d4dd4                   lea        ecx, [ebp - 0x2c]
00a4ab6f 51                       push       ecx
00a4ab70 8bcb                     mov        ecx, ebx
00a4ab72 e839e3a1ff               call       0x468eb0
00a4ab77 8b30                     mov        esi, dword ptr [eax]
00a4ab79 8b0e                     mov        ecx, dword ptr [esi]
00a4ab7b 8b11                     mov        edx, dword ptr [ecx]
00a4ab7d 6a11                     push       0x11
00a4ab7f ff522c                   call       dword ptr [edx + 0x2c]
00a4ab82 84c0                     test       al, al
00a4ab84 0f84a1000000             je         0xa4ac2b
00a4ab8a 8b06                     mov        eax, dword ptr [esi]
00a4ab8c 6a00                     push       0
00a4ab8e 686c52f500               push       0xf5526c
00a4ab93 681009f400               push       0xf40910
00a4ab98 6a00                     push       0
00a4ab9a 50                       push       eax
00a4ab9b e86b611b00               call       0xc00d0b
00a4aba0 8bf8                     mov        edi, eax
00a4aba2 83c414                   add        esp, 0x14
00a4aba5 85ff                     test       edi, edi
00a4aba7 0f849a000000             je         0xa4ac47
00a4abad 8b17                     mov        edx, dword ptr [edi]
00a4abaf 8bcf                     mov        ecx, edi
00a4abb1 ff9234020000             call       dword ptr [edx + 0x234]
00a4abb7 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4abba 6a02                     push       2
00a4abbc 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4abbf e8bc3bffff               call       0xa3e780
00a4abc4 833807                   cmp        dword ptr [eax], 7
00a4abc7 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4abca 6a01                     push       1
00a4abcc 752c                     jne        0xa4abfa
00a4abce e8ad3bffff               call       0xa3e780
00a4abd3 8bd8                     mov        ebx, eax
00a4abd5 8b07                     mov        eax, dword ptr [edi]
00a4abd7 8bcf                     mov        ecx, edi
00a4abd9 ff90fc030000             call       dword ptr [eax + 0x3fc]
00a4abdf 8bc8                     mov        ecx, eax
00a4abe1 0faf0b                   imul       ecx, dword ptr [ebx]
00a4abe4 8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00a4abe7 b81f85eb51               mov        eax, 0x51eb851f
00a4abec f7e9                     imul       ecx
00a4abee c1fa05                   sar        edx, 5
00a4abf1 8bfa                     mov        edi, edx
00a4abf3 c1ef1f                   shr        edi, 0x1f
00a4abf6 03fa                     add        edi, edx
00a4abf8 eb07                     jmp        0xa4ac01
00a4abfa e8813bffff               call       0xa3e780
00a4abff 8b38                     mov        edi, dword ptr [eax]
00a4ac01 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4ac04 6a00                     push       0
00a4ac06 e8753bffff               call       0xa3e780
00a4ac0b 8b08                     mov        ecx, dword ptr [eax]
00a4ac0d 8b55e8                   mov        edx, dword ptr [ebp - 0x18]
00a4ac10 57                       push       edi
00a4ac11 51                       push       ecx
00a4ac12 52                       push       edx
00a4ac13 e8b847b2ff               call       0x56f3d0
00a4ac18 83c40c                   add        esp, 0xc
00a4ac1b 84c0                     test       al, al
00a4ac1d 7507                     jne        0xa4ac26
00a4ac1f 56                       push       esi
00a4ac20 8d45dc                   lea        eax, [ebp - 0x24]
00a4ac23 50                       push       eax
00a4ac24 eb18                     jmp        0xa4ac3e
00a4ac26 83c604                   add        esi, 4
00a4ac29 eb1c                     jmp        0xa4ac47
00a4ac2b 68d095e400               push       0xe495d0
00a4ac30 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4ac36 83c404                   add        esp, 4
00a4ac39 56                       push       esi
00a4ac3a 8d4de0                   lea        ecx, [ebp - 0x20]
00a4ac3d 51                       push       ecx
00a4ac3e 8bcb                     mov        ecx, ebx
00a4ac40 e86be2a1ff               call       0x468eb0
00a4ac45 8b30                     mov        esi, dword ptr [eax]
00a4ac47 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4ac4a 0f8500ffffff             jne        0xa4ab50
00a4ac50 e9530f0000               jmp        0xa4bba8
00a4ac55 83f81b                   cmp        eax, 0x1b
00a4ac58 7565                     jne        0xa4acbf
00a4ac5a 6a01                     push       1
00a4ac5c 8bcf                     mov        ecx, edi
00a4ac5e e89d84aeff               call       0x533100
00a4ac63 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4ac66 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4ac69 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4ac6c 0f84360f0000             je         0xa4bba8
00a4ac72 83c724                   add        edi, 0x24
00a4ac75 6a00                     push       0
00a4ac77 8bcf                     mov        ecx, edi
00a4ac79 e8023bffff               call       0xa3e780
00a4ac7e 8b55f0                   mov        edx, dword ptr [ebp - 0x10]
00a4ac81 8b4a7c                   mov        ecx, dword ptr [edx + 0x7c]
00a4ac84 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4ac87 8b00                     mov        eax, dword ptr [eax]
00a4ac89 52                       push       edx
00a4ac8a 8b11                     mov        edx, dword ptr [ecx]
00a4ac8c 50                       push       eax
00a4ac8d 8b06                     mov        eax, dword ptr [esi]
00a4ac8f 6a00                     push       0
00a4ac91 50                       push       eax
00a4ac92 ff5208                   call       dword ptr [edx + 8]
00a4ac95 50                       push       eax
00a4ac96 e83547b2ff               call       0x56f3d0
00a4ac9b 83c40c                   add        esp, 0xc
00a4ac9e 84c0                     test       al, al
00a4aca0 7510                     jne        0xa4acb2
00a4aca2 56                       push       esi
00a4aca3 8d4d08                   lea        ecx, [ebp + 8]
00a4aca6 51                       push       ecx
00a4aca7 8bcb                     mov        ecx, ebx
00a4aca9 e802e2a1ff               call       0x468eb0
00a4acae 8b30                     mov        esi, dword ptr [eax]
00a4acb0 eb03                     jmp        0xa4acb5
00a4acb2 83c604                   add        esi, 4
00a4acb5 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4acb8 75bb                     jne        0xa4ac75
00a4acba e9e90e0000               jmp        0xa4bba8
00a4acbf 83f81c                   cmp        eax, 0x1c
00a4acc2 0f85a8000000             jne        0xa4ad70
00a4acc8 6a00                     push       0
00a4acca 8bcf                     mov        ecx, edi
00a4accc e82f84aeff               call       0x533100
00a4acd1 8b55f0                   mov        edx, dword ptr [ebp - 0x10]
00a4acd4 8b750c                   mov        esi, dword ptr [ebp + 0xc]
00a4acd7 8b7e04                   mov        edi, dword ptr [esi + 4]
00a4acda 6a00                     push       0
00a4acdc 8bd8                     mov        ebx, eax
00a4acde 8b427c                   mov        eax, dword ptr [edx + 0x7c]
00a4ace1 687c28f400               push       0xf4287c
00a4ace6 4b                       dec        ebx
00a4ace7 681009f400               push       0xf40910
00a4acec f7db                     neg        ebx
00a4acee 1adb                     sbb        bl, bl
00a4acf0 6a00                     push       0
00a4acf2 50                       push       eax
00a4acf3 fec3                     inc        bl
00a4acf5 e811601b00               call       0xc00d0b
00a4acfa 894508                   mov        dword ptr [ebp + 8], eax
00a4acfd 8b4608                   mov        eax, dword ptr [esi + 8]
00a4ad00 83c414                   add        esp, 0x14
00a4ad03 3bf8                     cmp        edi, eax
00a4ad05 0f849d0e0000             je         0xa4bba8
00a4ad0b eb03                     jmp        0xa4ad10
00a4ad0d 8d4900                   lea        ecx, [ecx]
00a4ad10 8b0f                     mov        ecx, dword ptr [edi]
00a4ad12 6a00                     push       0
00a4ad14 687c28f400               push       0xf4287c
00a4ad19 681009f400               push       0xf40910
00a4ad1e 6a00                     push       0
00a4ad20 51                       push       ecx
00a4ad21 e8e55f1b00               call       0xc00d0b
00a4ad26 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4ad29 83c414                   add        esp, 0x14
00a4ad2c 85c9                     test       ecx, ecx
00a4ad2e 7428                     je         0xa4ad58
00a4ad30 85c0                     test       eax, eax
00a4ad32 7424                     je         0xa4ad58
00a4ad34 8bd1                     mov        edx, ecx
00a4ad36 8b32                     mov        esi, dword ptr [edx]
00a4ad38 8b10                     mov        edx, dword ptr [eax]
00a4ad3a 8bc8                     mov        ecx, eax
00a4ad3c ff9294000000             call       dword ptr [edx + 0x94]
00a4ad42 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4ad45 50                       push       eax
00a4ad46 ff96d8000000             call       dword ptr [esi + 0xd8]
00a4ad4c 3ac3                     cmp        al, bl
00a4ad4e 8b750c                   mov        esi, dword ptr [ebp + 0xc]
00a4ad51 7405                     je         0xa4ad58
00a4ad53 83c704                   add        edi, 4
00a4ad56 eb0e                     jmp        0xa4ad66
00a4ad58 57                       push       edi
00a4ad59 8d45d4                   lea        eax, [ebp - 0x2c]
00a4ad5c 50                       push       eax
00a4ad5d 8bce                     mov        ecx, esi
00a4ad5f e84ce1a1ff               call       0x468eb0
00a4ad64 8b38                     mov        edi, dword ptr [eax]
00a4ad66 3b7e08                   cmp        edi, dword ptr [esi + 8]
00a4ad69 75a5                     jne        0xa4ad10
00a4ad6b e9380e0000               jmp        0xa4bba8
00a4ad70 83f812                   cmp        eax, 0x12
00a4ad73 0f858b000000             jne        0xa4ae04
00a4ad79 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4ad7c 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4ad7f 89750c                   mov        dword ptr [ebp + 0xc], esi
00a4ad82 0f84200e0000             je         0xa4bba8
00a4ad88 eb06                     jmp        0xa4ad90
00a4ad8a 8d9b00000000             lea        ebx, [ebx]
00a4ad90 8b0e                     mov        ecx, dword ptr [esi]
00a4ad92 6a00                     push       0
00a4ad94 687c28f400               push       0xf4287c
00a4ad99 681009f400               push       0xf40910
00a4ad9e 6a00                     push       0
00a4ada0 51                       push       ecx
00a4ada1 e8655f1b00               call       0xc00d0b
00a4ada6 83c414                   add        esp, 0x14
00a4ada9 85c0                     test       eax, eax
00a4adab 894508                   mov        dword ptr [ebp + 8], eax
00a4adae 742c                     je         0xa4addc
00a4adb0 8b7718                   mov        esi, dword ptr [edi + 0x18]
00a4adb3 3b771c                   cmp        esi, dword ptr [edi + 0x1c]
00a4adb6 7421                     je         0xa4add9
00a4adb8 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4adbb 81c108020000             add        ecx, 0x208
00a4adc1 e82a830000               call       0xa530f0
00a4adc6 56                       push       esi
00a4adc7 50                       push       eax
00a4adc8 e86365aeff               call       0x531330
00a4adcd 83c408                   add        esp, 8
00a4add0 84c0                     test       al, al
00a4add2 751b                     jne        0xa4adef
00a4add4 83c61c                   add        esi, 0x1c
00a4add7 ebda                     jmp        0xa4adb3
00a4add9 8b750c                   mov        esi, dword ptr [ebp + 0xc]
00a4addc 56                       push       esi
00a4addd 8d55d4                   lea        edx, [ebp - 0x2c]
00a4ade0 52                       push       edx
00a4ade1 8bcb                     mov        ecx, ebx
00a4ade3 e8c8e0a1ff               call       0x468eb0
00a4ade8 8b30                     mov        esi, dword ptr [eax]
00a4adea 89750c                   mov        dword ptr [ebp + 0xc], esi
00a4aded eb0b                     jmp        0xa4adfa
00a4adef 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4adf2 83c004                   add        eax, 4
00a4adf5 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4adf8 8bf0                     mov        esi, eax
00a4adfa 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4adfd 7591                     jne        0xa4ad90
00a4adff e9a40d0000               jmp        0xa4bba8
00a4ae04 83f815                   cmp        eax, 0x15
00a4ae07 0f85d2000000             jne        0xa4aedf
00a4ae0d 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4ae10 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4ae13 8b4b08                   mov        ecx, dword ptr [ebx + 8]
00a4ae16 2bc6                     sub        eax, esi
00a4ae18 c1f802                   sar        eax, 2
00a4ae1b 8945ec                   mov        dword ptr [ebp - 0x14], eax
00a4ae1e 8b4304                   mov        eax, dword ptr [ebx + 4]
00a4ae21 3bc1                     cmp        eax, ecx
00a4ae23 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4ae26 0f847c0d0000             je         0xa4bba8
00a4ae2c 8d642400                 lea        esp, [esp]
00a4ae30 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4ae33 8b08                     mov        ecx, dword ptr [eax]
00a4ae35 6a00                     push       0
00a4ae37 682829f400               push       0xf42928
00a4ae3c 681009f400               push       0xf40910
00a4ae41 6a00                     push       0
00a4ae43 51                       push       ecx
00a4ae44 e8c25e1b00               call       0xc00d0b
00a4ae49 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4ae4c 6a00                     push       0
00a4ae4e 68a028f400               push       0xf428a0
00a4ae53 681009f400               push       0xf40910
00a4ae58 8bf0                     mov        esi, eax
00a4ae5a 8b02                     mov        eax, dword ptr [edx]
00a4ae5c 6a00                     push       0
00a4ae5e 50                       push       eax
00a4ae5f e8a75e1b00               call       0xc00d0b
00a4ae64 83c428                   add        esp, 0x28
00a4ae67 85f6                     test       esi, esi
00a4ae69 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4ae6c 7504                     jne        0xa4ae72
00a4ae6e 85c0                     test       eax, eax
00a4ae70 7442                     je         0xa4aeb4
00a4ae72 8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00a4ae75 85c0                     test       eax, eax
00a4ae77 c7450800000000           mov        dword ptr [ebp + 8], 0
00a4ae7e 7e34                     jle        0xa4aeb4
00a4ae80 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4ae83 51                       push       ecx
00a4ae84 8bcf                     mov        ecx, edi
00a4ae86 e87582aeff               call       0x533100
00a4ae8b 85f6                     test       esi, esi
00a4ae8d 7408                     je         0xa4ae97
00a4ae8f 398604020000             cmp        dword ptr [esi + 0x204], eax
00a4ae95 7433                     je         0xa4aeca
00a4ae97 8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00a4ae9a 85c9                     test       ecx, ecx
00a4ae9c 7408                     je         0xa4aea6
00a4ae9e 398168080000             cmp        dword ptr [ecx + 0x868], eax
00a4aea4 7424                     je         0xa4aeca
00a4aea6 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4aea9 8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00a4aeac 40                       inc        eax
00a4aead 3bc1                     cmp        eax, ecx
00a4aeaf 894508                   mov        dword ptr [ebp + 8], eax
00a4aeb2 7ccc                     jl         0xa4ae80
00a4aeb4 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4aeb7 52                       push       edx
00a4aeb8 8d45d4                   lea        eax, [ebp - 0x2c]
00a4aebb 50                       push       eax
00a4aebc 8bcb                     mov        ecx, ebx
00a4aebe e8eddfa1ff               call       0x468eb0
00a4aec3 8b08                     mov        ecx, dword ptr [eax]
00a4aec5 894d0c                   mov        dword ptr [ebp + 0xc], ecx
00a4aec8 eb04                     jmp        0xa4aece
00a4aeca 83450c04                 add        dword ptr [ebp + 0xc], 4
00a4aece 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4aed1 3b5308                   cmp        edx, dword ptr [ebx + 8]
00a4aed4 0f8556ffffff             jne        0xa4ae30
00a4aeda e9c90c0000               jmp        0xa4bba8
00a4aedf 83f816                   cmp        eax, 0x16
00a4aee2 0f8526010000             jne        0xa4b00e
00a4aee8 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4aeeb 8b5728                   mov        edx, dword ptr [edi + 0x28]
00a4aeee 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4aef1 6a00                     push       0
00a4aef3 2bc2                     sub        eax, edx
00a4aef5 687c28f400               push       0xf4287c
00a4aefa c1f802                   sar        eax, 2
00a4aefd 681009f400               push       0xf40910
00a4af02 8945f0                   mov        dword ptr [ebp - 0x10], eax
00a4af05 8b417c                   mov        eax, dword ptr [ecx + 0x7c]
00a4af08 6a00                     push       0
00a4af0a 50                       push       eax
00a4af0b 897508                   mov        dword ptr [ebp + 8], esi
00a4af0e e8f85d1b00               call       0xc00d0b
00a4af13 8945ec                   mov        dword ptr [ebp - 0x14], eax
00a4af16 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4af19 83c414                   add        esp, 0x14
00a4af1c 3bf0                     cmp        esi, eax
00a4af1e 0f84840c0000             je         0xa4bba8
00a4af24 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4af27 8b11                     mov        edx, dword ptr [ecx]
00a4af29 6a00                     push       0
00a4af2b 687c28f400               push       0xf4287c
00a4af30 681009f400               push       0xf40910
00a4af35 6a00                     push       0
00a4af37 52                       push       edx
00a4af38 e8ce5d1b00               call       0xc00d0b
00a4af3d 8bf0                     mov        esi, eax
00a4af3f 83c414                   add        esp, 0x14
00a4af42 85f6                     test       esi, esi
00a4af44 0f84b1000000             je         0xa4affb
00a4af4a 8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00a4af4d 85c0                     test       eax, eax
00a4af4f c745e800000000           mov        dword ptr [ebp - 0x18], 0
00a4af56 0f8e9f000000             jle        0xa4affb
00a4af5c 8d642400                 lea        esp, [esp]
00a4af60 8b45e8                   mov        eax, dword ptr [ebp - 0x18]
00a4af63 50                       push       eax
00a4af64 8bcf                     mov        ecx, edi
00a4af66 e89581aeff               call       0x533100
00a4af6b 85c0                     test       eax, eax
00a4af6d 751b                     jne        0xa4af8a
00a4af6f 8b16                     mov        edx, dword ptr [esi]
00a4af71 8bce                     mov        ecx, esi
00a4af73 ff92c4010000             call       dword ptr [edx + 0x1c4]
00a4af79 8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00a4af7c 8bd8                     mov        ebx, eax
00a4af7e 8b01                     mov        eax, dword ptr [ecx]
00a4af80 ff90c4010000             call       dword ptr [eax + 0x1c4]
00a4af86 3bd8                     cmp        ebx, eax
00a4af88 eb5a                     jmp        0xa4afe4
00a4af8a 83f801                   cmp        eax, 1
00a4af8d 7537                     jne        0xa4afc6
00a4af8f 8b16                     mov        edx, dword ptr [esi]
00a4af91 8bce                     mov        ecx, esi
00a4af93 ff92c4010000             call       dword ptr [edx + 0x1c4]
00a4af99 8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00a4af9c 8bd8                     mov        ebx, eax
00a4af9e 8b01                     mov        eax, dword ptr [ecx]
00a4afa0 ff90c4010000             call       dword ptr [eax + 0x1c4]
00a4afa6 3bd8                     cmp        ebx, eax
00a4afa8 743c                     je         0xa4afe6
00a4afaa 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4afad 8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00a4afb0 83c004                   add        eax, 4
00a4afb3 8bc8                     mov        ecx, eax
00a4afb5 894508                   mov        dword ptr [ebp + 8], eax
00a4afb8 3b4b08                   cmp        ecx, dword ptr [ebx + 8]
00a4afbb 0f8563ffffff             jne        0xa4af24
00a4afc1 e9e20b0000               jmp        0xa4bba8
00a4afc6 83f802                   cmp        eax, 2
00a4afc9 750d                     jne        0xa4afd8
00a4afcb 8bce                     mov        ecx, esi
00a4afcd e8ded4a3ff               call       0x4884b0
00a4afd2 84c0                     test       al, al
00a4afd4 75d4                     jne        0xa4afaa
00a4afd6 eb0e                     jmp        0xa4afe6
00a4afd8 83f803                   cmp        eax, 3
00a4afdb 750c                     jne        0xa4afe9
00a4afdd 83be9804000064           cmp        dword ptr [esi + 0x498], 0x64
00a4afe4 74c4                     je         0xa4afaa
00a4afe6 8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00a4afe9 8b45e8                   mov        eax, dword ptr [ebp - 0x18]
00a4afec 8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00a4afef 40                       inc        eax
00a4aff0 3bc1                     cmp        eax, ecx
00a4aff2 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4aff5 0f8c65ffffff             jl         0xa4af60
00a4affb 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4affe 51                       push       ecx
00a4afff 8d55d4                   lea        edx, [ebp - 0x2c]
00a4b002 52                       push       edx
00a4b003 8bcb                     mov        ecx, ebx
00a4b005 e8a6dea1ff               call       0x468eb0
00a4b00a 8b00                     mov        eax, dword ptr [eax]
00a4b00c eba5                     jmp        0xa4afb3
00a4b00e 83f813                   cmp        eax, 0x13
00a4b011 0f85d8000000             jne        0xa4b0ef
00a4b017 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4b01a 8b5728                   mov        edx, dword ptr [edi + 0x28]
00a4b01d 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4b020 2bc2                     sub        eax, edx
00a4b022 c1f802                   sar        eax, 2
00a4b025 8945ec                   mov        dword ptr [ebp - 0x14], eax
00a4b028 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4b02b 89750c                   mov        dword ptr [ebp + 0xc], esi
00a4b02e 0f84740b0000             je         0xa4bba8
00a4b034 8b16                     mov        edx, dword ptr [esi]
00a4b036 6a00                     push       0
00a4b038 682829f400               push       0xf42928
00a4b03d 681009f400               push       0xf40910
00a4b042 6a00                     push       0
00a4b044 52                       push       edx
00a4b045 e8c15c1b00               call       0xc00d0b
00a4b04a 6a00                     push       0
00a4b04c 68a028f400               push       0xf428a0
00a4b051 681009f400               push       0xf40910
00a4b056 894508                   mov        dword ptr [ebp + 8], eax
00a4b059 8b06                     mov        eax, dword ptr [esi]
00a4b05b 6a00                     push       0
00a4b05d 50                       push       eax
00a4b05e e8a85c1b00               call       0xc00d0b
00a4b063 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4b066 83c428                   add        esp, 0x28
00a4b069 85c9                     test       ecx, ecx
00a4b06b 8945e8                   mov        dword ptr [ebp - 0x18], eax
00a4b06e 7504                     jne        0xa4b074
00a4b070 85c0                     test       eax, eax
00a4b072 744c                     je         0xa4b0c0
00a4b074 8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00a4b077 33f6                     xor        esi, esi
00a4b079 85c0                     test       eax, eax
00a4b07b 7e43                     jle        0xa4b0c0
00a4b07d 8d4900                   lea        ecx, [ecx]
00a4b080 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4b083 85c0                     test       eax, eax
00a4b085 7415                     je         0xa4b09c
00a4b087 56                       push       esi
00a4b088 8bcf                     mov        ecx, edi
00a4b08a e87180aeff               call       0x533100
00a4b08f 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4b092 50                       push       eax
00a4b093 e868cfa1ff               call       0x468000
00a4b098 84c0                     test       al, al
00a4b09a 753a                     jne        0xa4b0d6
00a4b09c 8b45e8                   mov        eax, dword ptr [ebp - 0x18]
00a4b09f 85c0                     test       eax, eax
00a4b0a1 7415                     je         0xa4b0b8
00a4b0a3 56                       push       esi
00a4b0a4 8bcf                     mov        ecx, edi
00a4b0a6 e85580aeff               call       0x533100
00a4b0ab 8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00a4b0ae 50                       push       eax
00a4b0af e84ccfa1ff               call       0x468000
00a4b0b4 84c0                     test       al, al
00a4b0b6 751e                     jne        0xa4b0d6
00a4b0b8 8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00a4b0bb 46                       inc        esi
00a4b0bc 3bf0                     cmp        esi, eax
00a4b0be 7cc0                     jl         0xa4b080
00a4b0c0 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4b0c3 51                       push       ecx
00a4b0c4 8d55d4                   lea        edx, [ebp - 0x2c]
00a4b0c7 52                       push       edx
00a4b0c8 8bcb                     mov        ecx, ebx
00a4b0ca e8e1dda1ff               call       0x468eb0
00a4b0cf 8b30                     mov        esi, dword ptr [eax]
00a4b0d1 89750c                   mov        dword ptr [ebp + 0xc], esi
00a4b0d4 eb0b                     jmp        0xa4b0e1
00a4b0d6 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4b0d9 83c004                   add        eax, 4
00a4b0dc 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4b0df 8bf0                     mov        esi, eax
00a4b0e1 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4b0e4 0f854affffff             jne        0xa4b034
00a4b0ea e9b90a0000               jmp        0xa4bba8
00a4b0ef 83f814                   cmp        eax, 0x14
00a4b0f2 0f85ee000000             jne        0xa4b1e6
00a4b0f8 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4b0fb 2b4728                   sub        eax, dword ptr [edi + 0x28]
00a4b0fe c1f802                   sar        eax, 2
00a4b101 894508                   mov        dword ptr [ebp + 8], eax
00a4b104 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4b107 8b5804                   mov        ebx, dword ptr [eax + 4]
00a4b10a 3b5808                   cmp        ebx, dword ptr [eax + 8]
00a4b10d 0f84950a0000             je         0xa4bba8
00a4b113 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4b116 33f6                     xor        esi, esi
00a4b118 85c0                     test       eax, eax
00a4b11a 0f8eb5000000             jle        0xa4b1d5
00a4b120 56                       push       esi
00a4b121 8bcf                     mov        ecx, edi
00a4b123 e8d87faeff               call       0x533100
00a4b128 85c0                     test       eax, eax
00a4b12a 750f                     jne        0xa4b13b
00a4b12c 8b0b                     mov        ecx, dword ptr [ebx]
00a4b12e 8b01                     mov        eax, dword ptr [ecx]
00a4b130 ff5030                   call       dword ptr [eax + 0x30]
00a4b133 83f801                   cmp        eax, 1
00a4b136 e98c000000               jmp        0xa4b1c7
00a4b13b 83f801                   cmp        eax, 1
00a4b13e 750c                     jne        0xa4b14c
00a4b140 8b0b                     mov        ecx, dword ptr [ebx]
00a4b142 8b11                     mov        edx, dword ptr [ecx]
00a4b144 ff5230                   call       dword ptr [edx + 0x30]
00a4b147 83f811                   cmp        eax, 0x11
00a4b14a eb7b                     jmp        0xa4b1c7
00a4b14c 83f802                   cmp        eax, 2
00a4b14f 750e                     jne        0xa4b15f
00a4b151 8b0b                     mov        ecx, dword ptr [ebx]
00a4b153 8b01                     mov        eax, dword ptr [ecx]
00a4b155 ff5030                   call       dword ptr [eax + 0x30]
00a4b158 3d11010000               cmp        eax, 0x111
00a4b15d eb68                     jmp        0xa4b1c7
00a4b15f 83f803                   cmp        eax, 3
00a4b162 750e                     jne        0xa4b172
00a4b164 8b0b                     mov        ecx, dword ptr [ebx]
00a4b166 8b11                     mov        edx, dword ptr [ecx]
00a4b168 ff5230                   call       dword ptr [edx + 0x30]
00a4b16b 3d11020000               cmp        eax, 0x211
00a4b170 eb55                     jmp        0xa4b1c7
00a4b172 83f804                   cmp        eax, 4
00a4b175 751b                     jne        0xa4b192
00a4b177 8b0b                     mov        ecx, dword ptr [ebx]
00a4b179 8b01                     mov        eax, dword ptr [ecx]
00a4b17b ff5034                   call       dword ptr [eax + 0x34]
00a4b17e 84c0                     test       al, al
00a4b180 7447                     je         0xa4b1c9
00a4b182 83c304                   add        ebx, 4
00a4b185 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4b188 3b5908                   cmp        ebx, dword ptr [ecx + 8]
00a4b18b 7586                     jne        0xa4b113
00a4b18d e9160a0000               jmp        0xa4bba8
00a4b192 83f805                   cmp        eax, 5
00a4b195 750c                     jne        0xa4b1a3
00a4b197 8b0b                     mov        ecx, dword ptr [ebx]
00a4b199 8b11                     mov        edx, dword ptr [ecx]
00a4b19b ff5230                   call       dword ptr [edx + 0x30]
00a4b19e 83f821                   cmp        eax, 0x21
00a4b1a1 eb24                     jmp        0xa4b1c7
00a4b1a3 83f806                   cmp        eax, 6
00a4b1a6 750e                     jne        0xa4b1b6
00a4b1a8 8b0b                     mov        ecx, dword ptr [ebx]
00a4b1aa 8b01                     mov        eax, dword ptr [ecx]
00a4b1ac ff5030                   call       dword ptr [eax + 0x30]
00a4b1af 3d21020000               cmp        eax, 0x221
00a4b1b4 eb11                     jmp        0xa4b1c7
00a4b1b6 83f807                   cmp        eax, 7
00a4b1b9 750e                     jne        0xa4b1c9
00a4b1bb 8b0b                     mov        ecx, dword ptr [ebx]
00a4b1bd 8b11                     mov        edx, dword ptr [ecx]
00a4b1bf ff5230                   call       dword ptr [edx + 0x30]
00a4b1c2 3d21040000               cmp        eax, 0x421
00a4b1c7 74b9                     je         0xa4b182
00a4b1c9 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4b1cc 46                       inc        esi
00a4b1cd 3bf0                     cmp        esi, eax
00a4b1cf 0f8c4bffffff             jl         0xa4b120
00a4b1d5 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4b1d8 53                       push       ebx
00a4b1d9 8d45d4                   lea        eax, [ebp - 0x2c]
00a4b1dc 50                       push       eax
00a4b1dd e8cedca1ff               call       0x468eb0
00a4b1e2 8b18                     mov        ebx, dword ptr [eax]
00a4b1e4 eb9f                     jmp        0xa4b185
00a4b1e6 83f81a                   cmp        eax, 0x1a
00a4b1e9 0f84b9090000             je         0xa4bba8
00a4b1ef 83f81e                   cmp        eax, 0x1e
00a4b1f2 0f857b020000             jne        0xa4b473
00a4b1f8 8955cc                   mov        dword ptr [ebp - 0x34], edx
00a4b1fb 8955d0                   mov        dword ptr [ebp - 0x30], edx
00a4b1fe 8955d4                   mov        dword ptr [ebp - 0x2c], edx
00a4b201 8955fc                   mov        dword ptr [ebp - 4], edx
00a4b204 8955bc                   mov        dword ptr [ebp - 0x44], edx
00a4b207 8955c0                   mov        dword ptr [ebp - 0x40], edx
00a4b20a 8955c4                   mov        dword ptr [ebp - 0x3c], edx
00a4b20d 8b572c                   mov        edx, dword ptr [edi + 0x2c]
00a4b210 2b5728                   sub        edx, dword ptr [edi + 0x28]
00a4b213 c1fa02                   sar        edx, 2
00a4b216 33db                     xor        ebx, ebx
00a4b218 85d2                     test       edx, edx
00a4b21a c645fc01                 mov        byte ptr [ebp - 4], 1
00a4b21e 0f86ce000000             jbe        0xa4b2f2
00a4b224 c7450c01000000           mov        dword ptr [ebp + 0xc], 1
00a4b22b eb03                     jmp        0xa4b230
00a4b22d 8d4900                   lea        ecx, [ecx]
00a4b230 53                       push       ebx
00a4b231 8bcf                     mov        ecx, edi
00a4b233 e8c87eaeff               call       0x533100
00a4b238 8bf0                     mov        esi, eax
00a4b23a 83fe02                   cmp        esi, 2
00a4b23d 897508                   mov        dword ptr [ebp + 8], esi
00a4b240 7514                     jne        0xa4b256
00a4b242 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4b245 50                       push       eax
00a4b246 8bcf                     mov        ecx, edi
00a4b248 e8b37eaeff               call       0x533100
00a4b24d 83f805                   cmp        eax, 5
00a4b250 0f8e9c000000             jle        0xa4b2f2
00a4b256 8d4d08                   lea        ecx, [ebp + 8]
00a4b259 51                       push       ecx
00a4b25a 8d4dc8                   lea        ecx, [ebp - 0x38]
00a4b25d e8bebe9bff               call       0x407120
00a4b262 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4b265 8bcf                     mov        ecx, edi
00a4b267 52                       push       edx
00a4b268 e8937eaeff               call       0x533100
00a4b26d 83fe02                   cmp        esi, 2
00a4b270 7552                     jne        0xa4b2c4
00a4b272 83f808                   cmp        eax, 8
00a4b275 7509                     jne        0xa4b280
00a4b277 c7450800000000           mov        dword ptr [ebp + 8], 0
00a4b27e eb47                     jmp        0xa4b2c7
00a4b280 83f809                   cmp        eax, 9
00a4b283 750d                     jne        0xa4b292
00a4b285 8d4d08                   lea        ecx, [ebp + 8]
00a4b288 c7450801000000           mov        dword ptr [ebp + 8], 1
00a4b28f 51                       push       ecx
00a4b290 eb39                     jmp        0xa4b2cb
00a4b292 83f80a                   cmp        eax, 0xa
00a4b295 750d                     jne        0xa4b2a4
00a4b297 8d5508                   lea        edx, [ebp + 8]
00a4b29a c7450802000000           mov        dword ptr [ebp + 8], 2
00a4b2a1 52                       push       edx
00a4b2a2 eb27                     jmp        0xa4b2cb
00a4b2a4 83f80b                   cmp        eax, 0xb
00a4b2a7 7509                     jne        0xa4b2b2
00a4b2a9 c7450803000000           mov        dword ptr [ebp + 8], 3
00a4b2b0 eb15                     jmp        0xa4b2c7
00a4b2b2 83f80c                   cmp        eax, 0xc
00a4b2b5 751c                     jne        0xa4b2d3
00a4b2b7 8d4d08                   lea        ecx, [ebp + 8]
00a4b2ba c7450804000000           mov        dword ptr [ebp + 8], 4
00a4b2c1 51                       push       ecx
00a4b2c2 eb07                     jmp        0xa4b2cb
00a4b2c4 894508                   mov        dword ptr [ebp + 8], eax
00a4b2c7 8d4508                   lea        eax, [ebp + 8]
00a4b2ca 50                       push       eax
00a4b2cb 8d4dc8                   lea        ecx, [ebp - 0x38]
00a4b2ce e84dbe9bff               call       0x407120
00a4b2d3 8b4f2c                   mov        ecx, dword ptr [edi + 0x2c]
00a4b2d6 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4b2d9 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4b2dc 2bce                     sub        ecx, esi
00a4b2de 83c302                   add        ebx, 2
00a4b2e1 83c002                   add        eax, 2
00a4b2e4 c1f902                   sar        ecx, 2
00a4b2e7 3bd9                     cmp        ebx, ecx
00a4b2e9 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4b2ec 0f823effffff             jb         0xa4b230
00a4b2f2 8d5301                   lea        edx, [ebx + 1]
00a4b2f5 52                       push       edx
00a4b2f6 8bcf                     mov        ecx, edi
00a4b2f8 e8037eaeff               call       0x533100
00a4b2fd 8b4f28                   mov        ecx, dword ptr [edi + 0x28]
00a4b300 8bf0                     mov        esi, eax
00a4b302 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4b305 2bc1                     sub        eax, ecx
00a4b307 83c302                   add        ebx, 2
00a4b30a c1f802                   sar        eax, 2
00a4b30d 3bd8                     cmp        ebx, eax
00a4b30f 8975e8                   mov        dword ptr [ebp - 0x18], esi
00a4b312 0f83cd000000             jae        0xa4b3e5
00a4b318 8d4b01                   lea        ecx, [ebx + 1]
00a4b31b 894d0c                   mov        dword ptr [ebp + 0xc], ecx
00a4b31e 8bff                     mov        edi, edi
00a4b320 53                       push       ebx
00a4b321 8bcf                     mov        ecx, edi
00a4b323 e8d87daeff               call       0x533100
00a4b328 8bf0                     mov        esi, eax
00a4b32a 83fe02                   cmp        esi, 2
00a4b32d 897508                   mov        dword ptr [ebp + 8], esi
00a4b330 7514                     jne        0xa4b346
00a4b332 8b550c                   mov        edx, dword ptr [ebp + 0xc]
00a4b335 52                       push       edx
00a4b336 8bcf                     mov        ecx, edi
00a4b338 e8c37daeff               call       0x533100
00a4b33d 83f805                   cmp        eax, 5
00a4b340 0f8e9c000000             jle        0xa4b3e2
00a4b346 8d4508                   lea        eax, [ebp + 8]
00a4b349 50                       push       eax
00a4b34a 8d4db8                   lea        ecx, [ebp - 0x48]
00a4b34d e8cebd9bff               call       0x407120
00a4b352 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4b355 51                       push       ecx
00a4b356 8bcf                     mov        ecx, edi
00a4b358 e8a37daeff               call       0x533100
00a4b35d 83fe02                   cmp        esi, 2
00a4b360 7552                     jne        0xa4b3b4
00a4b362 83f808                   cmp        eax, 8
00a4b365 7509                     jne        0xa4b370
00a4b367 c7450800000000           mov        dword ptr [ebp + 8], 0
00a4b36e eb47                     jmp        0xa4b3b7
00a4b370 83f809                   cmp        eax, 9
00a4b373 750d                     jne        0xa4b382
00a4b375 8d4508                   lea        eax, [ebp + 8]
00a4b378 c7450801000000           mov        dword ptr [ebp + 8], 1
00a4b37f 50                       push       eax
00a4b380 eb39                     jmp        0xa4b3bb
00a4b382 83f80a                   cmp        eax, 0xa
00a4b385 750d                     jne        0xa4b394
00a4b387 8d4d08                   lea        ecx, [ebp + 8]
00a4b38a c7450802000000           mov        dword ptr [ebp + 8], 2
00a4b391 51                       push       ecx
00a4b392 eb27                     jmp        0xa4b3bb
00a4b394 83f80b                   cmp        eax, 0xb
00a4b397 7509                     jne        0xa4b3a2
00a4b399 c7450803000000           mov        dword ptr [ebp + 8], 3
00a4b3a0 eb15                     jmp        0xa4b3b7
00a4b3a2 83f80c                   cmp        eax, 0xc
00a4b3a5 751c                     jne        0xa4b3c3
00a4b3a7 8d4508                   lea        eax, [ebp + 8]
00a4b3aa c7450804000000           mov        dword ptr [ebp + 8], 4
00a4b3b1 50                       push       eax
00a4b3b2 eb07                     jmp        0xa4b3bb
00a4b3b4 894508                   mov        dword ptr [ebp + 8], eax
00a4b3b7 8d5508                   lea        edx, [ebp + 8]
00a4b3ba 52                       push       edx
00a4b3bb 8d4db8                   lea        ecx, [ebp - 0x48]
00a4b3be e85dbd9bff               call       0x407120
00a4b3c3 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4b3c6 8b7728                   mov        esi, dword ptr [edi + 0x28]
00a4b3c9 83c002                   add        eax, 2
00a4b3cc 89450c                   mov        dword ptr [ebp + 0xc], eax
00a4b3cf 8b472c                   mov        eax, dword ptr [edi + 0x2c]
00a4b3d2 2bc6                     sub        eax, esi
00a4b3d4 83c302                   add        ebx, 2
00a4b3d7 c1f802                   sar        eax, 2
00a4b3da 3bd8                     cmp        ebx, eax
00a4b3dc 0f823effffff             jb         0xa4b320
00a4b3e2 8b75e8                   mov        esi, dword ptr [ebp - 0x18]
00a4b3e5 8b4dcc                   mov        ecx, dword ptr [ebp - 0x34]
00a4b3e8 85c9                     test       ecx, ecx
00a4b3ea 7462                     je         0xa4b44e
00a4b3ec 8b45d0                   mov        eax, dword ptr [ebp - 0x30]
00a4b3ef 2bc1                     sub        eax, ecx
00a4b3f1 c1f802                   sar        eax, 2
00a4b3f4 85c0                     test       eax, eax
00a4b3f6 7456                     je         0xa4b44e
00a4b3f8 8b4dbc                   mov        ecx, dword ptr [ebp - 0x44]
00a4b3fb 85c9                     test       ecx, ecx
00a4b3fd 744f                     je         0xa4b44e
00a4b3ff 8b45c0                   mov        eax, dword ptr [ebp - 0x40]
00a4b402 2bc1                     sub        eax, ecx
00a4b404 c1f802                   sar        eax, 2
00a4b407 85c0                     test       eax, eax
00a4b409 7443                     je         0xa4b44e
00a4b40b 85f6                     test       esi, esi
00a4b40d 7c3f                     jl         0xa4b44e
00a4b40f 8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
00a4b412 57                       push       edi
00a4b413 8d4db8                   lea        ecx, [ebp - 0x48]
00a4b416 51                       push       ecx
00a4b417 8bcb                     mov        ecx, ebx
00a4b419 e85267feff               call       0xa31b70
00a4b41e 50                       push       eax
00a4b41f 56                       push       esi
00a4b420 57                       push       edi
00a4b421 8d55c8                   lea        edx, [ebp - 0x38]
00a4b424 52                       push       edx
00a4b425 8bcb                     mov        ecx, ebx
00a4b427 e84467feff               call       0xa31b70
00a4b42c 50                       push       eax
00a4b42d e89e3fb2ff               call       0x56f3d0
00a4b432 83c40c                   add        esp, 0xc
00a4b435 84c0                     test       al, al
00a4b437 8d4db8                   lea        ecx, [ebp - 0x48]
00a4b43a 7415                     je         0xa4b451
00a4b43c e80f99bfff               call       0x644d50
00a4b441 8d4dc8                   lea        ecx, [ebp - 0x38]
00a4b444 e80799bfff               call       0x644d50
00a4b449 e95a070000               jmp        0xa4bba8
00a4b44e 8d4db8                   lea        ecx, [ebp - 0x48]
00a4b451 e8fa98bfff               call       0x644d50
00a4b456 8d4dc8                   lea        ecx, [ebp - 0x38]
00a4b459 e8f298bfff               call       0x644d50
00a4b45e 5f                       pop        edi
00a4b45f 5e                       pop        esi
00a4b460 32c0                     xor        al, al
00a4b462 5b                       pop        ebx
00a4b463 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4b466 64890d00000000           mov        dword ptr fs:[0], ecx
00a4b46d 8be5                     mov        esp, ebp
00a4b46f 5d                       pop        ebp
00a4b470 c20800                   ret        8
00a4b473 83f82e                   cmp        eax, 0x2e
00a4b476 751f                     jne        0xa4b497
00a4b478 8b417c                   mov        eax, dword ptr [ecx + 0x7c]
00a4b47b 6a00                     push       0
00a4b47d 68f49df500               push       0xf59df4
00a4b482 681009f400               push       0xf40910
00a4b487 6a00                     push       0
00a4b489 50                       push       eax
00a4b48a e87c581b00               call       0xc00d0b
00a4b48f 83c414                   add        esp, 0x14
00a4b492 e911070000               jmp        0xa4bba8
00a4b497 83f81f                   cmp        eax, 0x1f
00a4b49a 757f                     jne        0xa4b51b
00a4b49c 8b497c                   mov        ecx, dword ptr [ecx + 0x7c]
00a4b49f 6a00                     push       0
00a4b4a1 68f49df500               push       0xf59df4
00a4b4a6 681009f400               push       0xf40910
00a4b4ab 6a00                     push       0
00a4b4ad 51                       push       ecx
00a4b4ae e858581b00               call       0xc00d0b
00a4b4b3 83c414                   add        esp, 0x14
00a4b4b6 6a00                     push       0
00a4b4b8 8d4f24                   lea        ecx, [edi + 0x24]
00a4b4bb 8bd8                     mov        ebx, eax
00a4b4bd e8be32ffff               call       0xa3e780
00a4b4c2 833801                   cmp        dword ptr [eax], 1
00a4b4c5 7528                     jne        0xa4b4ef
00a4b4c7 85db                     test       ebx, ebx
00a4b4c9 740f                     je         0xa4b4da
00a4b4cb 8bcb                     mov        ecx, ebx
00a4b4cd e8bedacfff               call       0x748f90
00a4b4d2 85c0                     test       eax, eax
00a4b4d4 0f85ce060000             jne        0xa4bba8
00a4b4da 5f                       pop        edi
00a4b4db 5e                       pop        esi
00a4b4dc 32c0                     xor        al, al
00a4b4de 5b                       pop        ebx
00a4b4df 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4b4e2 64890d00000000           mov        dword ptr fs:[0], ecx
00a4b4e9 8be5                     mov        esp, ebp
00a4b4eb 5d                       pop        ebp
00a4b4ec c20800                   ret        8
00a4b4ef 85db                     test       ebx, ebx
00a4b4f1 0f84b1060000             je         0xa4bba8
00a4b4f7 8bcb                     mov        ecx, ebx
00a4b4f9 e892dacfff               call       0x748f90
00a4b4fe 85c0                     test       eax, eax
00a4b500 0f84a2060000             je         0xa4bba8
00a4b506 5f                       pop        edi
00a4b507 5e                       pop        esi
00a4b508 32c0                     xor        al, al
00a4b50a 5b                       pop        ebx
00a4b50b 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4b50e 64890d00000000           mov        dword ptr fs:[0], ecx
00a4b515 8be5                     mov        esp, ebp
00a4b517 5d                       pop        ebp
00a4b518 c20800                   ret        8
00a4b51b 83f823                   cmp        eax, 0x23
00a4b51e 756b                     jne        0xa4b58b
00a4b520 6a00                     push       0
00a4b522 8bcf                     mov        ecx, edi
00a4b524 e8d77baeff               call       0x533100
00a4b529 8b7304                   mov        esi, dword ptr [ebx + 4]
00a4b52c 48                       dec        eax
00a4b52d f7d8                     neg        eax
00a4b52f 1ac0                     sbb        al, al
00a4b531 fec0                     inc        al
00a4b533 88450f                   mov        byte ptr [ebp + 0xf], al
00a4b536 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4b539 0f8469060000             je         0xa4bba8
00a4b53f 90                       nop        
00a4b540 8b16                     mov        edx, dword ptr [esi]
00a4b542 6a00                     push       0
00a4b544 687c28f400               push       0xf4287c
00a4b549 681009f400               push       0xf40910
00a4b54e 6a00                     push       0
00a4b550 52                       push       edx
00a4b551 e8b5571b00               call       0xc00d0b
00a4b556 83c414                   add        esp, 0x14
00a4b559 85c0                     test       eax, eax
00a4b55b 7416                     je         0xa4b573
00a4b55d 8b10                     mov        edx, dword ptr [eax]
00a4b55f 6a00                     push       0
00a4b561 8bc8                     mov        ecx, eax
00a4b563 ff92f0020000             call       dword ptr [edx + 0x2f0]
00a4b569 3a450f                   cmp        al, byte ptr [ebp + 0xf]
00a4b56c 7505                     jne        0xa4b573
00a4b56e 83c604                   add        esi, 4
00a4b571 eb0e                     jmp        0xa4b581
00a4b573 56                       push       esi
00a4b574 8d4508                   lea        eax, [ebp + 8]
00a4b577 50                       push       eax
00a4b578 8bcb                     mov        ecx, ebx
00a4b57a e831d9a1ff               call       0x468eb0
00a4b57f 8b30                     mov        esi, dword ptr [eax]
00a4b581 3b7308                   cmp        esi, dword ptr [ebx + 8]
00a4b584 75ba                     jne        0xa4b540
00a4b586 e91d060000               jmp        0xa4bba8
00a4b58b 83f822                   cmp        eax, 0x22
00a4b58e 0f858b020000             jne        0xa4b81f
00a4b594 6a00                     push       0
00a4b596 8bcf                     mov        ecx, edi
00a4b598 e8637baeff               call       0x533100
00a4b59d 6a01                     push       1
00a4b59f 8bcf                     mov        ecx, edi
00a4b5a1 894508                   mov        dword ptr [ebp + 8], eax
00a4b5a4 e8577baeff               call       0x533100
00a4b5a9 8bcb                     mov        ecx, ebx
00a4b5ab 8bf0                     mov        esi, eax
00a4b5ad e8deb1a1ff               call       0x466790
00a4b5b2 85c0                     test       eax, eax
00a4b5b4 0f86e6020000             jbe        0xa4b8a0
00a4b5ba 83fe09                   cmp        esi, 9
00a4b5bd 7544                     jne        0xa4b603
00a4b5bf 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4b5c2 8b4b04                   mov        ecx, dword ptr [ebx + 4]
00a4b5c5 50                       push       eax
00a4b5c6 51                       push       ecx
00a4b5c7 e8e4060000               call       0xa4bcb0
00a4b5cc 83c408                   add        esp, 8
00a4b5cf 8bcb                     mov        ecx, ebx
00a4b5d1 e8bab1a1ff               call       0x466790
00a4b5d6 8b7508                   mov        esi, dword ptr [ebp + 8]
00a4b5d9 3bf0                     cmp        esi, eax
00a4b5db 0f83c7050000             jae        0xa4bba8
00a4b5e1 8bcb                     mov        ecx, ebx
00a4b5e3 e8a8b1a1ff               call       0x466790
00a4b5e8 2bc6                     sub        eax, esi
00a4b5ea 85c0                     test       eax, eax
00a4b5ec 0f8eb6050000             jle        0xa4bba8
00a4b5f2 8bf0                     mov        esi, eax
00a4b5f4 8bcb                     mov        ecx, ebx
00a4b5f6 e895060000               call       0xa4bc90
00a4b5fb 4e                       dec        esi
00a4b5fc 75f6                     jne        0xa4b5f4
00a4b5fe e9a5050000               jmp        0xa4bba8
00a4b603 83fe05                   cmp        esi, 5
00a4b606 0f85e3000000             jne        0xa4b6ef
00a4b60c 8d4dbc                   lea        ecx, [ebp - 0x44]
00a4b60f e88cbd9bff               call       0x4073a0
00a4b614 8b750c                   mov        esi, dword ptr [ebp + 0xc]
00a4b617 8b5e04                   mov        ebx, dword ptr [esi + 4]
00a4b61a 3b5e08                   cmp        ebx, dword ptr [esi + 8]
00a4b61d c745fc02000000           mov        dword ptr [ebp - 4], 2
00a4b624 7432                     je         0xa4b658
00a4b626 8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00a4b629 8b0b                     mov        ecx, dword ptr [ebx]
00a4b62b 8b407c                   mov        eax, dword ptr [eax + 0x7c]
00a4b62e 8b11                     mov        edx, dword ptr [ecx]
00a4b630 6a00                     push       0
00a4b632 50                       push       eax
00a4b633 ff5208                   call       dword ptr [edx + 8]
00a4b636 8b0b                     mov        ecx, dword ptr [ebx]
00a4b638 894dd4                   mov        dword ptr [ebp - 0x2c], ecx
00a4b63b 8d4dd0                   lea        ecx, [ebp - 0x30]
00a4b63e 51                       push       ecx
00a4b63f 8d55d8                   lea        edx, [ebp - 0x28]
00a4b642 52                       push       edx
00a4b643 8d4dbc                   lea        ecx, [ebp - 0x44]
00a4b646 8945d0                   mov        dword ptr [ebp - 0x30], eax
00a4b649 e8a212a5ff               call       0x49c8f0
00a4b64e 8b4608                   mov        eax, dword ptr [esi + 8]
00a4b651 83c304                   add        ebx, 4
00a4b654 3bd8                     cmp        ebx, eax
00a4b656 75ce                     jne        0xa4b626
00a4b658 6a02                     push       2
00a4b65a 8bcf                     mov        ecx, edi
00a4b65c e89f7aaeff               call       0x533100
00a4b661 8bce                     mov        ecx, esi
00a4b663 8bf8                     mov        edi, eax
00a4b665 e8e696bfff               call       0x644d50
00a4b66a 83ff0a                   cmp        edi, 0xa
00a4b66d 8b45c0                   mov        eax, dword ptr [ebp - 0x40]
00a4b670 7547                     jne        0xa4b6b9
00a4b672 3b00                     cmp        eax, dword ptr [eax]
00a4b674 8bd8                     mov        ebx, eax
00a4b676 895d0c                   mov        dword ptr [ebp + 0xc], ebx
00a4b679 7460                     je         0xa4b6db
00a4b67b 8b7d08                   mov        edi, dword ptr [ebp + 8]
00a4b67e 8bff                     mov        edi, edi
00a4b680 8d4d0c                   lea        ecx, [ebp + 0xc]
00a4b683 e868080000               call       0xa4bef0
00a4b688 83c004                   add        eax, 4
00a4b68b 50                       push       eax
00a4b68c 8bce                     mov        ecx, esi
00a4b68e e85d2ea4ff               call       0x48e4f0
00a4b693 8bce                     mov        ecx, esi
00a4b695 e8f6b0a1ff               call       0x466790
00a4b69a 3bc7                     cmp        eax, edi
00a4b69c 733d                     jae        0xa4b6db
00a4b69e 8b45c0                   mov        eax, dword ptr [ebp - 0x40]
00a4b6a1 3b18                     cmp        ebx, dword ptr [eax]
00a4b6a3 75db                     jne        0xa4b680
00a4b6a5 8d4dbc                   lea        ecx, [ebp - 0x44]
00a4b6a8 c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00a4b6af e8acbc9bff               call       0x407360
00a4b6b4 e9ef040000               jmp        0xa4bba8
00a4b6b9 8b18                     mov        ebx, dword ptr [eax]
00a4b6bb 3bd8                     cmp        ebx, eax
00a4b6bd 741c                     je         0xa4b6db
00a4b6bf 8d7b10                   lea        edi, [ebx + 0x10]
00a4b6c2 57                       push       edi
00a4b6c3 8bce                     mov        ecx, esi
00a4b6c5 e8262ea4ff               call       0x48e4f0
00a4b6ca 8bce                     mov        ecx, esi
00a4b6cc e8bfb0a1ff               call       0x466790
00a4b6d1 3b4508                   cmp        eax, dword ptr [ebp + 8]
00a4b6d4 7305                     jae        0xa4b6db
00a4b6d6 3b5dc0                   cmp        ebx, dword ptr [ebp - 0x40]
00a4b6d9 75e7                     jne        0xa4b6c2
00a4b6db 8d4dbc                   lea        ecx, [ebp - 0x44]
00a4b6de c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00a4b6e5 e876bc9bff               call       0x407360
00a4b6ea e9b9040000               jmp        0xa4bba8
00a4b6ef 83fe06                   cmp        esi, 6
00a4b6f2 755d                     jne        0xa4b751
00a4b6f4 6a02                     push       2
00a4b6f6 8bcf                     mov        ecx, edi
00a4b6f8 e8037aaeff               call       0x533100
00a4b6fd 8bcb                     mov        ecx, ebx
00a4b6ff 8bf0                     mov        esi, eax
00a4b701 e88ab0a1ff               call       0x466790
00a4b706 83fe0a                   cmp        esi, 0xa
00a4b709 8b4b04                   mov        ecx, dword ptr [ebx + 4]
00a4b70c 8bf8                     mov        edi, eax
00a4b70e 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4b711 7507                     jne        0xa4b71a
00a4b713 682088a400               push       0xa48820
00a4b718 eb05                     jmp        0xa4b71f
00a4b71a 689088a400               push       0xa48890
00a4b71f 50                       push       eax
00a4b720 51                       push       ecx
00a4b721 e8da090000               call       0xa4c100
00a4b726 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4b729 83c40c                   add        esp, 0xc
00a4b72c 3bcf                     cmp        ecx, edi
00a4b72e 0f8d74040000             jge        0xa4bba8
00a4b734 8bc7                     mov        eax, edi
00a4b736 2bc1                     sub        eax, ecx
00a4b738 85c0                     test       eax, eax
00a4b73a 0f8e68040000             jle        0xa4bba8
00a4b740 8bf0                     mov        esi, eax
00a4b742 8bcb                     mov        ecx, ebx
00a4b744 e847050000               call       0xa4bc90
00a4b749 4e                       dec        esi
00a4b74a 75f6                     jne        0xa4b742
00a4b74c e957040000               jmp        0xa4bba8
00a4b751 83fe07                   cmp        esi, 7
00a4b754 755d                     jne        0xa4b7b3
00a4b756 6a02                     push       2
00a4b758 8bcf                     mov        ecx, edi
00a4b75a e8a179aeff               call       0x533100
00a4b75f 8bcb                     mov        ecx, ebx
00a4b761 8bf0                     mov        esi, eax
00a4b763 e828b0a1ff               call       0x466790
00a4b768 83fe0a                   cmp        esi, 0xa
00a4b76b 8b4b04                   mov        ecx, dword ptr [ebx + 4]
00a4b76e 8bf8                     mov        edi, eax
00a4b770 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4b773 7507                     jne        0xa4b77c
00a4b775 680089a400               push       0xa48900
00a4b77a eb05                     jmp        0xa4b781
00a4b77c 687089a400               push       0xa48970
00a4b781 50                       push       eax
00a4b782 51                       push       ecx
00a4b783 e878090000               call       0xa4c100
00a4b788 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4b78b 83c40c                   add        esp, 0xc
00a4b78e 3bcf                     cmp        ecx, edi
00a4b790 0f8d12040000             jge        0xa4bba8
00a4b796 8bc7                     mov        eax, edi
00a4b798 2bc1                     sub        eax, ecx
00a4b79a 85c0                     test       eax, eax
00a4b79c 0f8e06040000             jle        0xa4bba8
00a4b7a2 8bf0                     mov        esi, eax
00a4b7a4 8bcb                     mov        ecx, ebx
00a4b7a6 e8e5040000               call       0xa4bc90
00a4b7ab 4e                       dec        esi
00a4b7ac 75f6                     jne        0xa4b7a4
00a4b7ae e9f5030000               jmp        0xa4bba8
00a4b7b3 83fe08                   cmp        esi, 8
00a4b7b6 0f85ec030000             jne        0xa4bba8
00a4b7bc 6a02                     push       2
00a4b7be 8bcf                     mov        ecx, edi
00a4b7c0 e83b79aeff               call       0x533100
00a4b7c5 8bcb                     mov        ecx, ebx
00a4b7c7 8bf0                     mov        esi, eax
00a4b7c9 e8c2afa1ff               call       0x466790
00a4b7ce 83fe0a                   cmp        esi, 0xa
00a4b7d1 8b4b04                   mov        ecx, dword ptr [ebx + 4]
00a4b7d4 8bf8                     mov        edi, eax
00a4b7d6 8b4308                   mov        eax, dword ptr [ebx + 8]
00a4b7d9 7507                     jne        0xa4b7e2
00a4b7db 68e089a400               push       0xa489e0
00a4b7e0 eb05                     jmp        0xa4b7e7
00a4b7e2 68508aa400               push       0xa48a50
00a4b7e7 50                       push       eax
00a4b7e8 51                       push       ecx
00a4b7e9 e812090000               call       0xa4c100
00a4b7ee 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4b7f1 83c40c                   add        esp, 0xc
00a4b7f4 3bcf                     cmp        ecx, edi
00a4b7f6 0f8dac030000             jge        0xa4bba8
00a4b7fc 8bc7                     mov        eax, edi
00a4b7fe 2bc1                     sub        eax, ecx
00a4b800 85c0                     test       eax, eax
00a4b802 0f8ea0030000             jle        0xa4bba8
00a4b808 8bf0                     mov        esi, eax
00a4b80a 8d9b00000000             lea        ebx, [ebx]
00a4b810 8bcb                     mov        ecx, ebx
00a4b812 e879040000               call       0xa4bc90
00a4b817 4e                       dec        esi
00a4b818 75f6                     jne        0xa4b810
00a4b81a e989030000               jmp        0xa4bba8
00a4b81f 83f824                   cmp        eax, 0x24
00a4b822 0f8580030000             jne        0xa4bba8
00a4b828 03f8                     add        edi, eax
00a4b82a 6a00                     push       0
00a4b82c 8bcf                     mov        ecx, edi
00a4b82e e84d2fffff               call       0xa3e780
00a4b833 8b18                     mov        ebx, dword ptr [eax]
00a4b835 83fb06                   cmp        ebx, 6
00a4b838 895de8                   mov        dword ptr [ebp - 0x18], ebx
00a4b83b be01000000               mov        esi, 1
00a4b840 c7450800000000           mov        dword ptr [ebp + 8], 0
00a4b847 740a                     je         0xa4b853
00a4b849 83fb08                   cmp        ebx, 8
00a4b84c 7405                     je         0xa4b853
00a4b84e 83fb0a                   cmp        ebx, 0xa
00a4b851 7513                     jne        0xa4b866
00a4b853 6a01                     push       1
00a4b855 8bcf                     mov        ecx, edi
00a4b857 e8242fffff               call       0xa3e780
00a4b85c 8b08                     mov        ecx, dword ptr [eax]
00a4b85e 894d08                   mov        dword ptr [ebp + 8], ecx
00a4b861 be02000000               mov        esi, 2
00a4b866 56                       push       esi
00a4b867 8bcf                     mov        ecx, edi
00a4b869 e8122fffff               call       0xa3e780
00a4b86e 8b10                     mov        edx, dword ptr [eax]
00a4b870 46                       inc        esi
00a4b871 56                       push       esi
00a4b872 8bcf                     mov        ecx, edi
00a4b874 8955ec                   mov        dword ptr [ebp - 0x14], edx
00a4b877 e8042fffff               call       0xa3e780
00a4b87c 83fb03                   cmp        ebx, 3
00a4b87f 8b00                     mov        eax, dword ptr [eax]
00a4b881 8945e4                   mov        dword ptr [ebp - 0x1c], eax
00a4b884 7572                     jne        0xa4b8f8
00a4b886 83e800                   sub        eax, 0
00a4b889 744e                     je         0xa4b8d9
00a4b88b 48                       dec        eax
00a4b88c 7427                     je         0xa4b8b5
00a4b88e 8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00a4b891 50                       push       eax
00a4b892 68b894e400               push       0xe494b8
00a4b897 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4b89d 83c408                   add        esp, 8
00a4b8a0 5f                       pop        edi
00a4b8a1 5e                       pop        esi
00a4b8a2 32c0                     xor        al, al
00a4b8a4 5b                       pop        ebx
00a4b8a5 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4b8a8 64890d00000000           mov        dword ptr fs:[0], ecx
00a4b8af 8be5                     mov        esp, ebp
00a4b8b1 5d                       pop        ebp
00a4b8b2 c20800                   ret        8
00a4b8b5 8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00a4b8b8 51                       push       ecx
00a4b8b9 8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00a4b8bc e87f29feff               call       0xa2e240
00a4b8c1 f6d8                     neg        al
00a4b8c3 5f                       pop        edi
00a4b8c4 5e                       pop        esi
00a4b8c5 5b                       pop        ebx
00a4b8c6 1bc0                     sbb        eax, eax
00a4b8c8 40                       inc        eax
00a4b8c9 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4b8cc 64890d00000000           mov        dword ptr fs:[0], ecx
00a4b8d3 8be5                     mov        esp, ebp
00a4b8d5 5d                       pop        ebp
00a4b8d6 c20800                   ret        8
00a4b8d9 8b55ec                   mov        edx, dword ptr [ebp - 0x14]
00a4b8dc 8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00a4b8df 52                       push       edx
00a4b8e0 e85b29feff               call       0xa2e240
00a4b8e5 5f                       pop        edi
00a4b8e6 5e                       pop        esi
00a4b8e7 5b                       pop        ebx
00a4b8e8 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4b8eb 64890d00000000           mov        dword ptr fs:[0], ecx
00a4b8f2 8be5                     mov        esp, ebp
00a4b8f4 5d                       pop        ebp
00a4b8f5 c20800                   ret        8
00a4b8f8 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4b8fb 8b7004                   mov        esi, dword ptr [eax + 4]
00a4b8fe 3b7008                   cmp        esi, dword ptr [eax + 8]
00a4b901 0f84a1020000             je         0xa4bba8
00a4b907 33ff                     xor        edi, edi
00a4b909 83fb04                   cmp        ebx, 4
00a4b90c 7530                     jne        0xa4b93e
00a4b90e 8b06                     mov        eax, dword ptr [esi]
00a4b910 57                       push       edi
00a4b911 686c52f500               push       0xf5526c
00a4b916 681009f400               push       0xf40910
00a4b91b 57                       push       edi
00a4b91c 50                       push       eax
00a4b91d e8e9531b00               call       0xc00d0b
00a4b922 83c414                   add        esp, 0x14
00a4b925 85c0                     test       eax, eax
00a4b927 0f84e3010000             je         0xa4bb10
00a4b92d 8b10                     mov        edx, dword ptr [eax]
00a4b92f 8bc8                     mov        ecx, eax
00a4b931 ff9294030000             call       dword ptr [edx + 0x394]
00a4b937 8bf8                     mov        edi, eax
00a4b939 e9cb010000               jmp        0xa4bb09
00a4b93e 83fb05                   cmp        ebx, 5
00a4b941 7532                     jne        0xa4b975
00a4b943 8b06                     mov        eax, dword ptr [esi]
00a4b945 6a00                     push       0
00a4b947 686c52f500               push       0xf5526c
00a4b94c 681009f400               push       0xf40910
00a4b951 6a00                     push       0
00a4b953 50                       push       eax
00a4b954 e8b2531b00               call       0xc00d0b
00a4b959 83c414                   add        esp, 0x14
00a4b95c 85c0                     test       eax, eax
00a4b95e 0f84ac010000             je         0xa4bb10
00a4b964 8b10                     mov        edx, dword ptr [eax]
00a4b966 8bc8                     mov        ecx, eax
00a4b968 ff9290030000             call       dword ptr [edx + 0x390]
00a4b96e 8bf8                     mov        edi, eax
00a4b970 e994010000               jmp        0xa4bb09
00a4b975 83fb06                   cmp        ebx, 6
00a4b978 7536                     jne        0xa4b9b0
00a4b97a 8b06                     mov        eax, dword ptr [esi]
00a4b97c 6a00                     push       0
00a4b97e 686c52f500               push       0xf5526c
00a4b983 681009f400               push       0xf40910
00a4b988 6a00                     push       0
00a4b98a 50                       push       eax
00a4b98b e87b531b00               call       0xc00d0b
00a4b990 83c414                   add        esp, 0x14
00a4b993 85c0                     test       eax, eax
00a4b995 0f8475010000             je         0xa4bb10
00a4b99b 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4b99e 8b10                     mov        edx, dword ptr [eax]
00a4b9a0 51                       push       ecx
00a4b9a1 8bc8                     mov        ecx, eax
00a4b9a3 ff929c030000             call       dword ptr [edx + 0x39c]
00a4b9a9 8bf8                     mov        edi, eax
00a4b9ab e959010000               jmp        0xa4bb09
00a4b9b0 83fb07                   cmp        ebx, 7
00a4b9b3 7532                     jne        0xa4b9e7
00a4b9b5 8b16                     mov        edx, dword ptr [esi]
00a4b9b7 6a00                     push       0
00a4b9b9 686c52f500               push       0xf5526c
00a4b9be 681009f400               push       0xf40910
00a4b9c3 6a00                     push       0
00a4b9c5 52                       push       edx
00a4b9c6 e840531b00               call       0xc00d0b
00a4b9cb 83c414                   add        esp, 0x14
00a4b9ce 85c0                     test       eax, eax
00a4b9d0 0f843a010000             je         0xa4bb10
00a4b9d6 8b10                     mov        edx, dword ptr [eax]
00a4b9d8 8bc8                     mov        ecx, eax
00a4b9da ff9298030000             call       dword ptr [edx + 0x398]
00a4b9e0 8bf8                     mov        edi, eax
00a4b9e2 e922010000               jmp        0xa4bb09
00a4b9e7 83fb08                   cmp        ebx, 8
00a4b9ea 7536                     jne        0xa4ba22
00a4b9ec 8b06                     mov        eax, dword ptr [esi]
00a4b9ee 6a00                     push       0
00a4b9f0 686c52f500               push       0xf5526c
00a4b9f5 681009f400               push       0xf40910
00a4b9fa 6a00                     push       0
00a4b9fc 50                       push       eax
00a4b9fd e809531b00               call       0xc00d0b
00a4ba02 83c414                   add        esp, 0x14
00a4ba05 85c0                     test       eax, eax
00a4ba07 0f8403010000             je         0xa4bb10
00a4ba0d 8b4d08                   mov        ecx, dword ptr [ebp + 8]
00a4ba10 8b10                     mov        edx, dword ptr [eax]
00a4ba12 51                       push       ecx
00a4ba13 8bc8                     mov        ecx, eax
00a4ba15 ff92b0030000             call       dword ptr [edx + 0x3b0]
00a4ba1b 8bf8                     mov        edi, eax
00a4ba1d e9e7000000               jmp        0xa4bb09
00a4ba22 83fb09                   cmp        ebx, 9
00a4ba25 7532                     jne        0xa4ba59
00a4ba27 8b16                     mov        edx, dword ptr [esi]
00a4ba29 6a00                     push       0
00a4ba2b 686c52f500               push       0xf5526c
00a4ba30 681009f400               push       0xf40910
00a4ba35 6a00                     push       0
00a4ba37 52                       push       edx
00a4ba38 e8ce521b00               call       0xc00d0b
00a4ba3d 83c414                   add        esp, 0x14
00a4ba40 85c0                     test       eax, eax
00a4ba42 0f84c8000000             je         0xa4bb10
00a4ba48 8b10                     mov        edx, dword ptr [eax]
00a4ba4a 8bc8                     mov        ecx, eax
00a4ba4c ff92a0030000             call       dword ptr [edx + 0x3a0]
00a4ba52 8bf8                     mov        edi, eax
00a4ba54 e9b0000000               jmp        0xa4bb09
00a4ba59 83fb0a                   cmp        ebx, 0xa
00a4ba5c 7561                     jne        0xa4babf
00a4ba5e 8b06                     mov        eax, dword ptr [esi]
00a4ba60 6a00                     push       0
00a4ba62 686c52f500               push       0xf5526c
00a4ba67 681009f400               push       0xf40910
00a4ba6c 6a00                     push       0
00a4ba6e 50                       push       eax
00a4ba6f e897521b00               call       0xc00d0b
00a4ba74 8b0e                     mov        ecx, dword ptr [esi]
00a4ba76 6a00                     push       0
00a4ba78 68a028f400               push       0xf428a0
00a4ba7d 681009f400               push       0xf40910
00a4ba82 6a00                     push       0
00a4ba84 51                       push       ecx
00a4ba85 8bd8                     mov        ebx, eax
00a4ba87 e87f521b00               call       0xc00d0b
00a4ba8c 83c428                   add        esp, 0x28
00a4ba8f 85db                     test       ebx, ebx
00a4ba91 8945f0                   mov        dword ptr [ebp - 0x10], eax
00a4ba94 7410                     je         0xa4baa6
00a4ba96 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4ba99 8b13                     mov        edx, dword ptr [ebx]
00a4ba9b 50                       push       eax
00a4ba9c 8bcb                     mov        ecx, ebx
00a4ba9e ff92b4030000             call       dword ptr [edx + 0x3b4]
00a4baa4 8bf8                     mov        edi, eax
00a4baa6 8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00a4baa9 85c0                     test       eax, eax
00a4baab 745c                     je         0xa4bb09
00a4baad 8bc8                     mov        ecx, eax
00a4baaf 8b4508                   mov        eax, dword ptr [ebp + 8]
00a4bab2 8b11                     mov        edx, dword ptr [ecx]
00a4bab4 50                       push       eax
00a4bab5 ff9250030000             call       dword ptr [edx + 0x350]
00a4babb 8bf8                     mov        edi, eax
00a4babd eb4a                     jmp        0xa4bb09
00a4babf 83fb0b                   cmp        ebx, 0xb
00a4bac2 754c                     jne        0xa4bb10
00a4bac4 8b0e                     mov        ecx, dword ptr [esi]
00a4bac6 6a00                     push       0
00a4bac8 686c52f500               push       0xf5526c
00a4bacd 681009f400               push       0xf40910
00a4bad2 6a00                     push       0
00a4bad4 51                       push       ecx
00a4bad5 e831521b00               call       0xc00d0b
00a4bada 8b16                     mov        edx, dword ptr [esi]
00a4badc 6a00                     push       0
00a4bade 68a028f400               push       0xf428a0
00a4bae3 681009f400               push       0xf40910
00a4bae8 6a00                     push       0
00a4baea 52                       push       edx
00a4baeb 8bd8                     mov        ebx, eax
00a4baed e819521b00               call       0xc00d0b
00a4baf2 83c428                   add        esp, 0x28
00a4baf5 85db                     test       ebx, ebx
00a4baf7 7406                     je         0xa4baff
00a4baf9 8bbb4c010000             mov        edi, dword ptr [ebx + 0x14c]
00a4baff 85c0                     test       eax, eax
00a4bb01 7406                     je         0xa4bb09
00a4bb03 8bb84c010000             mov        edi, dword ptr [eax + 0x14c]
00a4bb09 85ff                     test       edi, edi
00a4bb0b 7514                     jne        0xa4bb21
00a4bb0d 8b5de8                   mov        ebx, dword ptr [ebp - 0x18]
00a4bb10 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4bb13 56                       push       esi
00a4bb14 8d45d4                   lea        eax, [ebp - 0x2c]
00a4bb17 50                       push       eax
00a4bb18 e893d3a1ff               call       0x468eb0
00a4bb1d 8b30                     mov        esi, dword ptr [eax]
00a4bb1f eb7b                     jmp        0xa4bb9c
00a4bb21 8bcf                     mov        ecx, edi
00a4bb23 e8f81cffff               call       0xa3d820
00a4bb28 8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00a4bb2b 3bc1                     cmp        eax, ecx
00a4bb2d 7f11                     jg         0xa4bb40
00a4bb2f 56                       push       esi
00a4bb30 8d4ddc                   lea        ecx, [ebp - 0x24]
00a4bb33 51                       push       ecx
00a4bb34 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4bb37 e874d3a1ff               call       0x468eb0
00a4bb3c 8b30                     mov        esi, dword ptr [eax]
00a4bb3e eb59                     jmp        0xa4bb99
00a4bb40 8b45e4                   mov        eax, dword ptr [ebp - 0x1c]
00a4bb43 83e800                   sub        eax, 0
00a4bb46 51                       push       ecx
00a4bb47 7431                     je         0xa4bb7a
00a4bb49 48                       dec        eax
00a4bb4a 741f                     je         0xa4bb6b
00a4bb4c 68b894e400               push       0xe494b8
00a4bb51 ff15bc2eff00             call       dword ptr [0xff2ebc]
00a4bb57 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4bb5a 83c408                   add        esp, 8
00a4bb5d 56                       push       esi
00a4bb5e 8d55e0                   lea        edx, [ebp - 0x20]
00a4bb61 52                       push       edx
00a4bb62 e849d3a1ff               call       0x468eb0
00a4bb67 8b30                     mov        esi, dword ptr [eax]
00a4bb69 eb2e                     jmp        0xa4bb99
00a4bb6b 8bcf                     mov        ecx, edi
00a4bb6d e8ce26feff               call       0xa2e240
00a4bb72 f6d8                     neg        al
00a4bb74 1ac0                     sbb        al, al
00a4bb76 fec0                     inc        al
00a4bb78 eb07                     jmp        0xa4bb81
00a4bb7a 8bcf                     mov        ecx, edi
00a4bb7c e8bf26feff               call       0xa2e240
00a4bb81 84c0                     test       al, al
00a4bb83 7511                     jne        0xa4bb96
00a4bb85 8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00a4bb88 56                       push       esi
00a4bb89 8d55e0                   lea        edx, [ebp - 0x20]
00a4bb8c 52                       push       edx
00a4bb8d e81ed3a1ff               call       0x468eb0
00a4bb92 8b30                     mov        esi, dword ptr [eax]
00a4bb94 eb03                     jmp        0xa4bb99
00a4bb96 83c604                   add        esi, 4
00a4bb99 8b5de8                   mov        ebx, dword ptr [ebp - 0x18]
00a4bb9c 8b450c                   mov        eax, dword ptr [ebp + 0xc]
00a4bb9f 3b7008                   cmp        esi, dword ptr [eax + 8]
00a4bba2 0f855ffdffff             jne        0xa4b907
00a4bba8 8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00a4bbab 5f                       pop        edi
00a4bbac 5e                       pop        esi
00a4bbad b001                     mov        al, 1
00a4bbaf 5b                       pop        ebx
00a4bbb0 64890d00000000           mov        dword ptr fs:[0], ecx
00a4bbb7 8be5                     mov        esp, ebp
00a4bbb9 5d                       pop        ebp
00a4bbba c20800                   ret        8
