
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_007307b0(wchar_t *param_1,int *param_2,int *param_3,int *param_4)

{
  short sVar1;
  char cVar2;
  undefined1 uVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  undefined4 uVar8;
  float *pfVar9;
  wchar_t **ppwVar10;
  undefined4 *puVar11;
  float fVar12;
  undefined4 *puVar13;
  uint3 extraout_var;
  int iVar14;
  int *in_ECX;
  int iVar15;
  int iVar16;
  undefined4 *unaff_FS_OFFSET;
  bool bVar17;
  float10 fVar18;
  wchar_t *pwVar19;
  undefined4 in_stack_fffffe98;
  undefined4 uVar20;
  float fVar21;
  int **ppiVar22;
  float fVar23;
  undefined4 uVar24;
  float fVar25;
  undefined4 uVar26;
  undefined4 uVar27;
  undefined4 uVar28;
  undefined4 uVar29;
  undefined4 uVar30;
  undefined4 uVar31;
  float fVar32;
  float fVar33;
  undefined4 uVar34;
  wchar_t *pwVar35;
  undefined **ppuVar36;
  undefined **ppuVar37;
  undefined4 uVar38;
  undefined1 auStack_ac [4];
  undefined4 local_a8;
  undefined4 local_98;
  uint local_94;
  undefined4 uStack_8c;
  undefined4 uStack_7c;
  uint uStack_78;
  undefined1 auStack_74 [8];
  undefined1 auStack_6c [8];
  undefined1 auStack_64 [8];
  undefined1 auStack_5c [8];
  undefined4 uStack_54;
  wchar_t *apwStack_50 [6];
  wchar_t *pwStack_38;
  wchar_t *pwStack_34;
  char cStack_2d;
  int *piStack_2c;
  int *piStack_28;
  int *local_24;
  wchar_t *pwStack_20;
  float *pfStack_1c;
  void *pvStack_18;
  int *piStack_14;
  undefined4 local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_00c71a9c;
  local_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &local_10;
  piVar4 = (int *)FUN_00402060();
  local_94 = 7;
  local_98 = 0;
  local_a8 = (void *)((uint)local_a8._2_2_ << 0x10);
  local_8._0_1_ = 0;
  local_8._1_3_ = 0;
  local_24 = piVar4;
  switch(piVar4) {
  case (int *)0x7:
    *(undefined1 *)(in_ECX + 0xad7) = 0;
    *(undefined1 *)((int)in_ECX + 0x2b5e) = 1;
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xad6]);
    piVar4 = in_ECX + 0xad0;
    iVar16 = 2;
    do {
      (**(code **)(*in_ECX + 0xfc))(piVar4[-2]);
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      (**(code **)(*in_ECX + 0xfc))(piVar4[2]);
      (**(code **)(*in_ECX + 0xfc))(piVar4[4]);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    break;
  case (int *)0x8:
    iVar16 = FUN_00402060();
    if (iVar16 == 0x2e) {
      if ((char)in_ECX[0xaaf] == '\0') {
        (**(code **)(*in_ECX + 0x2e0))(0,0);
        *(undefined1 *)(in_ECX + 0xaaf) = 1;
      }
      piVar4 = in_ECX + 0xceb;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    else {
      iVar16 = FUN_00402060();
      if (iVar16 == 0x43) {
        piVar4 = in_ECX + 0xab3;
        iVar16 = 6;
        do {
          (**(code **)(*in_ECX + 0xfc))(*piVar4);
          piVar4 = piVar4 + 1;
          iVar16 = iVar16 + -1;
        } while (iVar16 != 0);
        iVar16 = FUN_00402060();
        if (iVar16 < 3) {
          iVar16 = 0;
          do {
            iVar15 = *in_ECX;
            iVar5 = FUN_00402060();
            (**(code **)(iVar15 + 0xfc))(in_ECX[iVar16 + iVar5 * 6 + 0xab9]);
            iVar16 = iVar16 + 1;
          } while (iVar16 < 6);
        }
        if ((char)in_ECX[0xab2] != '\0') {
          (**(code **)(*in_ECX + 0x14c))(0,0,1,2);
          (**(code **)(*in_ECX + 0x2e0))(0,0);
        }
      }
    }
    if ((char)in_ECX[0xca0] != '\0') {
      iVar16 = *in_ECX;
      iVar15 = FUN_00402060();
      (**(code **)(iVar16 + 0xfc))(in_ECX[iVar15 + 0xca1]);
    }
    if ((char)in_ECX[0xc24] != '\0') {
      iVar16 = 0;
      do {
        iVar15 = *in_ECX;
        iVar5 = FUN_00402060();
        (**(code **)(iVar15 + 0xfc))(in_ECX[iVar16 + iVar5 * 4 + 0xc25]);
        iVar16 = iVar16 + 1;
      } while (iVar16 < 4);
    }
    if (param_1 != (wchar_t *)0x8) {
      if (in_ECX[0xab1] != -1) {
        iVar16 = *in_ECX;
        uVar8 = (**(code **)(iVar16 + 0x64c))(0x43,0xffffffff);
        (**(code **)(iVar16 + 0x72c))(0x43,uVar8);
      }
      in_ECX[0xab0] = -1;
      in_ECX[0xab1] = -1;
      *(undefined1 *)(in_ECX + 0xc24) = 0;
      *(undefined1 *)(in_ECX + 0xca0) = 0;
      piStack_14 = (int *)0xffffffff;
      FUN_00404560(&piStack_14);
    }
    break;
  case (int *)0xa:
    if (in_ECX[0x90a] == 0) {
      iVar16 = FUN_00402060();
      if (iVar16 == 0x17) {
        if (param_1 != (wchar_t *)0xa) {
          piVar4 = in_ECX + 0xbec;
          iVar16 = 2;
          do {
            (**(code **)(*in_ECX + 0xfc))(piVar4[-2]);
            (**(code **)(*in_ECX + 0xfc))(*piVar4);
            piVar4 = piVar4 + 1;
            iVar16 = iVar16 + -1;
          } while (iVar16 != 0);
        }
      }
      else {
        iVar16 = FUN_00402060();
        if (iVar16 == 0x20) {
          if (param_1 != (wchar_t *)0xa) {
            piVar4 = in_ECX + 0xbee;
            iVar16 = 2;
            do {
              (**(code **)(*in_ECX + 0xfc))(*piVar4);
              piVar4 = piVar4 + 1;
              iVar16 = iVar16 + -1;
            } while (iVar16 != 0);
            (**(code **)(*in_ECX + 0x2e0))(0,0);
          }
        }
        else {
          iVar16 = FUN_00402060();
          if (iVar16 == 0x2f) {
            iVar16 = FUN_00402060();
            if ((iVar16 == 0) &&
               ((**(code **)(*in_ECX + 0xfc))(in_ECX[0xbf1]), param_1 != (wchar_t *)0xa)) {
              iVar16 = *in_ECX;
              uVar8 = (**(code **)(iVar16 + 0x64c))(0x2f,0xffffffff);
              (**(code **)(iVar16 + 0x72c))(0x2f,uVar8);
            }
          }
          else {
            iVar16 = FUN_00402060();
            if (iVar16 == 0x1e) {
              iVar16 = FUN_00402060();
              if (iVar16 == 1) {
                piVar4 = in_ECX + 0xcee;
                iVar16 = 5;
                do {
                  (**(code **)(*in_ECX + 0xfc))(*piVar4);
                  piVar4 = piVar4 + 1;
                  iVar16 = iVar16 + -1;
                } while (iVar16 != 0);
              }
            }
            else {
              iVar16 = FUN_00402060();
              if (iVar16 == 0x18) {
                if (param_1 != (wchar_t *)0x0) {
                  piVar4 = in_ECX;
                  (**(code **)(*in_ECX + 0x67c))(0x18);
                  FUN_0054e8e0(piVar4);
                }
              }
              else {
                iVar16 = FUN_00402060();
                if (iVar16 == 0x2c) {
                  iVar16 = FUN_00402060();
                  if ((iVar16 == 1) && (iVar16 = FUN_00402060(), iVar16 == 1)) {
                    (**(code **)(*in_ECX + 0x2e0))(0,0);
                  }
                }
                else {
                  iVar16 = FUN_00402060();
                  if (iVar16 == 0x4a) {
                    iVar16 = FUN_00402060();
                    if (iVar16 == 0) {
                      FUN_0071ba00();
                    }
                    else {
                      iVar16 = FUN_00402060();
                      if ((iVar16 == 1) &&
                         ((**(code **)(*in_ECX + 0x2e0))(0,0), param_1 != (wchar_t *)0x29)) {
                        FUN_0071b9a0();
                        piVar4 = in_ECX + 0xbfa;
                        iVar16 = 3;
                        do {
                          (**(code **)(*in_ECX + 0xfc))(*piVar4);
                          piVar4 = piVar4 + 1;
                          iVar16 = iVar16 + -1;
                        } while (iVar16 != 0);
                        goto LAB_00730df4;
                      }
                    }
                  }
                  else {
                    iVar16 = FUN_00402060();
                    if (iVar16 == 0x4c) {
                      iVar16 = *in_ECX;
                      iVar15 = FUN_00402060();
                      (**(code **)(iVar16 + 0xfc))(in_ECX[iVar15 + 0xc22]);
                      iVar16 = FUN_00402060();
                      if ((iVar16 == 0) && (param_1 != (wchar_t *)0xa)) {
                        iVar16 = *in_ECX;
                        uVar8 = (**(code **)(iVar16 + 0x64c))(0x4c,0xffffffff);
                        (**(code **)(iVar16 + 0x72c))(0x4c,uVar8);
                      }
                    }
                    else {
                      FUN_00402060();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    break;
  case (int *)0x13:
    if (param_1 != (wchar_t *)0x13) {
      (**(code **)(*in_ECX + 0x10c))(u_SWD_GUARD_END_00d7f9c4,0xffffffff,0,0);
      (**(code **)(*(int *)in_ECX[0xbb5] + 0x5c))(0);
    }
    break;
  case (int *)0x14:
    iVar16 = in_ECX[0xbbb];
    if (iVar16 == 1) {
      if (*(char *)((int)in_ECX + 0x2ef9) == '\0') {
        piVar4 = in_ECX + 0xbc1;
        iVar16 = 2;
        do {
          (**(code **)(*in_ECX + 0xfc))(*piVar4);
          piVar4 = piVar4 + 1;
          iVar16 = iVar16 + -1;
        } while (iVar16 != 0);
      }
      else {
        FUN_00498e60(0xffff);
      }
    }
    else if ((iVar16 == 0) || (iVar16 == 2)) {
      piVar4 = in_ECX + 0xbbf;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    else if (iVar16 == 3) {
      piVar4 = in_ECX + 0xbc4;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    break;
  case (int *)0x16:
    if (param_1 != (wchar_t *)0x16) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x64c))(8,0xffffffff);
      (**(code **)(iVar16 + 0x72c))(8,uVar8);
    }
    (**(code **)(*in_ECX + 0xfc))(in_ECX[in_ECX[0xbc7] + 0xbc9]);
    uVar6 = in_ECX[0xbc7] & 0x80000001;
    iVar15 = *in_ECX;
    if ((int)uVar6 < 0) {
      uVar6 = (uVar6 - 1 | 0xfffffffe) + 1;
    }
    iVar16 = in_ECX[uVar6 + 0xbce];
LAB_0073189e:
    (**(code **)(iVar15 + 0xfc))(iVar16);
    break;
  case (int *)0x17:
    piVar4 = in_ECX + 0xbd3;
    iVar16 = 8;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    break;
  case (int *)0x18:
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xbe0]);
    (**(code **)(*in_ECX + 0x558))();
    break;
  case (int *)0x19:
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc15]);
    (**(code **)(*in_ECX + 0x2e0))(0,0);
    break;
  case (int *)0x1a:
    if (in_ECX[0xca4] == 1) {
      uVar8 = 1;
      (**(code **)(*in_ECX + 0x2d8))(1);
      FUN_00721800();
      iVar16 = in_ECX[0xcad];
      (**(code **)(*in_ECX + 0xfc))(iVar16);
      FUN_00a6ad50(0,1,0);
      (**(code **)(*in_ECX + 0x67c))(0x1f,1);
      uVar8 = FUN_0054ff60(iVar16,uVar8);
      FUN_00a6ad20(0,0,0,uVar8);
    }
    break;
  case (int *)0x1b:
    iVar16 = in_ECX[0xcae];
    if (iVar16 == 0) {
      (**(code **)(*in_ECX + 0x558))();
    }
    else if (iVar16 == 1) {
      if ((char)in_ECX[0xcb1] == '\0') {
        piVar4 = in_ECX + 0xcb3;
        iVar16 = 2;
        do {
          (**(code **)(*in_ECX + 0xfc))(*piVar4);
          piVar4 = piVar4 + 1;
          iVar16 = iVar16 + -1;
        } while (iVar16 != 0);
      }
      else {
        FUN_00498e60(0xffff);
      }
      (**(code **)(*in_ECX + 0x110))(0x13);
      (**(code **)(*in_ECX + 0x110))(0x17);
    }
    else if (iVar16 == 2) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xcb2]);
    }
    if ((param_1 != (wchar_t *)0x1b) && ((**(code **)(*in_ECX + 0x2d0))(1), in_ECX[0xcae] != 2)) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x64c))(0x32,0xffffffff);
      (**(code **)(iVar16 + 0x72c))(0x32,uVar8);
    }
    break;
  case (int *)0x1e:
    piVar4 = in_ECX + 0xceb;
    iVar16 = 2;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    break;
  case (int *)0x1f:
    if (in_ECX[0xae8] == 0) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xae9]);
      (**(code **)(*in_ECX + 0x558))();
    }
    else if (in_ECX[0xae8] == 1) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xaea]);
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xaeb]);
      FUN_00499db0(0,0);
    }
    break;
  case (int *)0x20:
    if (param_1 != (wchar_t *)0x20) {
      piVar4 = in_ECX + 0xb15;
      iVar16 = 3;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    if (in_ECX[0xb12] == 1) {
      uVar34 = 1;
      (**(code **)(*in_ECX + 0x2d8))(1);
      uVar8 = 1;
      (**(code **)(*in_ECX + 0x2d0))(1);
      FUN_00721990();
      FUN_00a6ad50(0,1,0);
      (**(code **)(*in_ECX + 0x67c))(0x3a,0);
      uVar8 = FUN_0054ff60(uVar8,uVar34);
      FUN_00a6ad20(0,0,0,uVar8);
    }
    break;
  case (int *)0x21:
    if (param_1 != (wchar_t *)0x21) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xafe]);
      FUN_0071fb90();
      if (((int *)in_ECX[0xc1d] != (int *)0x0) &&
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc1d] + 0x60))(), cVar2 != '\0')) {
        FUN_005a2dd0(0);
      }
      if (in_ECX[0xaff] != 0) {
        if (*(int *)(in_ECX[0xaff] + 0x1fc) != 3) {
          FUN_0071b280(1,200);
        }
        in_ECX[0xaff] = 0;
      }
    }
    break;
  case (int *)0x22:
    if (in_ECX[0xb00] == 0) {
      (**(code **)(*(int *)in_ECX[0xb09] + 0x5c))(0);
      (**(code **)(*(int *)in_ECX[0xb0a] + 0x5c))(0);
      piVar4 = in_ECX + 0xb0b;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
      iVar16 = in_ECX[0xb11];
LAB_0073189b:
      iVar15 = *in_ECX;
      goto LAB_0073189e;
    }
    if (in_ECX[0xb00] == 1) {
      piVar4 = in_ECX + 0xb0f;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(piVar4[-2]);
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    break;
  case (int *)0x23:
    piVar4 = in_ECX + 0xb19;
    iVar16 = 2;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    break;
  case (int *)0x24:
    if (in_ECX[0xb29] != 1) break;
    piVar7 = in_ECX + 0xb31;
    pfStack_1c = (float *)0x2;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar7);
      piVar7 = piVar7 + 1;
      pfStack_1c = (float *)((int)pfStack_1c + -1);
    } while (pfStack_1c != (float *)0x0);
    if (param_1 != (wchar_t *)0x0) break;
    FUN_00a6ad50(0,1,0);
    uVar8 = 0xc;
    piVar7 = in_ECX;
    (**(code **)(*in_ECX + 0x67c))(0x41,0xc);
    uVar8 = FUN_0054ff60(uVar8,piVar7);
    FUN_00a6ad20(0,0,0,uVar8);
    goto LAB_007318c3;
  case (int *)0x25:
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xcbc]);
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xcbd]);
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xcbb]);
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xcba]);
    piVar4 = in_ECX + 0xcbe;
    iVar16 = 2;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    break;
  case (int *)0x26:
    in_ECX[0xcf4] = -1;
    FUN_0071b940();
    (**(code **)(*in_ECX + 0x558))();
    piVar4 = in_ECX + 0xcf5;
    iVar16 = 2;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    break;
  case (int *)0x27:
    if (param_1 != (wchar_t *)0x27) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x64c))(0x48,0xffffffff);
      (**(code **)(iVar16 + 0x72c))(0x48,uVar8);
      if (in_ECX[0xb3f] != 0) {
        FUN_00598d30();
      }
      (**(code **)(**(int **)(DAT_0100316c + 0x15b0) + 0x10))(0);
    }
    if (in_ECX[0xb38] == 1) {
      piVar4 = in_ECX + 0xb42;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(piVar4[-2]);
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    piVar4 = in_ECX + 0xb44;
    pfStack_1c = (float *)0x4;
    do {
      iVar16 = 6;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
      pfStack_1c = (float *)((int)pfStack_1c + -1);
    } while (pfStack_1c != (float *)0x0);
    pfStack_1c = (float *)0x0;
    break;
  case (int *)0x28:
    if ((param_1 != (wchar_t *)0x28) && (in_ECX[0x40] != 0)) {
      iVar15 = 0;
      iVar16 = FUN_00404380();
      if (0 < iVar16) {
        do {
          uVar38 = 0;
          ppuVar37 = &PTR_PTR_00f6a8e8;
          ppuVar36 = &PTR_PTR_00f4287c;
          uVar34 = 0;
          uVar8 = FUN_00405400(iVar15);
          piVar4 = (int *)FUN_00c00d0b(uVar8,uVar34,ppuVar36,ppuVar37,uVar38);
          if ((piVar4 != (int *)0x0) &&
             (piVar7 = (int *)(**(code **)(*piVar4 + 0x18c))(), piVar7 == in_ECX)) {
            (**(code **)(*piVar4 + 0x164))(0);
          }
          iVar15 = iVar15 + 1;
          iVar16 = FUN_00404380();
        } while (iVar15 < iVar16);
      }
    }
    if (in_ECX[0xb5c] == 1) {
      piVar4 = in_ECX + 0xb60;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    break;
  case (int *)0x29:
    FUN_0071b9a0();
    piVar4 = in_ECX + 0xbfa;
    iVar16 = 3;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
LAB_00730df4:
    FUN_0071fd10();
    (**(code **)(*in_ECX + 0x110))(0x18);
    break;
  case (int *)0x2a:
    if (param_1 != (wchar_t *)0x2a) {
      piVar4 = in_ECX + 0xcca;
      iVar16 = 3;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    break;
  case (int *)0x2b:
    if (param_1 != (wchar_t *)0x2b) {
      piVar4 = in_ECX + 0xb83;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(piVar4[-2]);
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        (**(code **)(*in_ECX + 0xfc))(piVar4[2]);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
      FUN_0071ff70(0);
      (**(code **)(*in_ECX + 0x110))(0x19);
    }
    if (in_ECX[0xb64] == 1) {
      piVar4 = in_ECX + 0xb89;
      iVar16 = 4;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    break;
  case (int *)0x2c:
    iVar16 = in_ECX[0xb8e];
    if (iVar16 == 0) {
      piVar4 = in_ECX + 0xba9;
      iVar16 = 4;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    else if (iVar16 == 1) {
      piVar4 = in_ECX + 0xbad;
      iVar16 = 2;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar4);
        piVar4 = piVar4 + 1;
        iVar16 = iVar16 + -1;
      } while (iVar16 != 0);
    }
    else if (iVar16 == 2) {
      cVar2 = FUN_0071baa0();
      if (cVar2 != '\0') {
        (**(code **)(*(int *)in_ECX[0xb90] + 0x5c))(0);
      }
      piVar4 = in_ECX + 0xb91;
      pfStack_1c = (float *)0x4;
      do {
        iVar16 = 6;
        do {
          (**(code **)(*in_ECX + 0xfc))(*piVar4);
          piVar4 = piVar4 + 1;
          iVar16 = iVar16 + -1;
        } while (iVar16 != 0);
        pfStack_1c = (float *)((int)pfStack_1c + -1);
      } while (pfStack_1c != (float *)0x0);
      pfStack_1c = (float *)0x0;
    }
    break;
  case (int *)0x2d:
    if (in_ECX[0xb1b] == 0) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xb20]);
      iVar16 = in_ECX[0xb21];
      goto LAB_0073189b;
    }
    if (in_ECX[0xb1b] == 1) {
      piVar7 = in_ECX + 0xb20;
      pfStack_1c = (float *)0x7;
      do {
        (**(code **)(*in_ECX + 0xfc))(*piVar7);
        piVar7 = piVar7 + 1;
        pfStack_1c = (float *)((int)pfStack_1c + -1);
      } while (pfStack_1c != (float *)0x0);
      if (param_1 == (wchar_t *)0x0) {
        FUN_00a6ad50(0,1,0);
        uVar8 = 2;
        piVar7 = in_ECX;
        (**(code **)(*in_ECX + 0x67c))(0x51,2);
        uVar8 = FUN_0054ff60(uVar8,piVar7);
        FUN_00a6ad20(0,0,0,uVar8);
        goto LAB_007318c3;
      }
    }
    break;
  case (int *)0x2e:
    if ((int *)in_ECX[0xc35] != (int *)0x0) {
      (**(code **)(*(int *)in_ECX[0xc35] + 0x5c))(0);
    }
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc37]);
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc38]);
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc39]);
    *(undefined1 *)(in_ECX + 0x90) = 1;
    in_ECX[0xc3b] = 0;
    break;
  case (int *)0x2f:
    *(undefined1 *)(in_ECX + 0x90) = 1;
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc5a]);
    if (param_1 != (wchar_t *)0x30) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x9c))(200,0,3);
      uVar8 = (**(code **)(*in_ECX + 0x9c))(in_ECX[0xc3c],in_ECX[0xc3d],uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
      (**(code **)(iVar16 + 0xb4))(uVar8);
    }
    break;
  case (int *)0x30:
    if ((param_1 != (wchar_t *)0x30) && (param_1 != (wchar_t *)0x31)) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x9c))(200,0,3);
      uVar8 = (**(code **)(*in_ECX + 0x9c))(in_ECX[0xc3c],in_ECX[0xc3d],uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
      (**(code **)(iVar16 + 0xb4))(uVar8);
      (**(code **)(*in_ECX + 0x140))(0,0);
    }
    break;
  case (int *)0x31:
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x9c))(200,0,3);
    uVar8 = (**(code **)(*in_ECX + 0x9c))(in_ECX[0xc3c],in_ECX[0xc3d],uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
    (**(code **)(iVar16 + 0xb4))(uVar8);
    piVar4 = in_ECX + 0xc87;
    iVar16 = 3;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    piVar4 = in_ECX + 0xc8a;
    iVar16 = 4;
    do {
      (**(code **)(*in_ECX + 0xfc))(*piVar4);
      piVar4 = piVar4 + 1;
      iVar16 = iVar16 + -1;
    } while (iVar16 != 0);
    *(undefined1 *)(in_ECX + 0x90) = 1;
    break;
  case (int *)0x32:
    if (in_ECX[0xc97] == 0) {
      (**(code **)(*in_ECX + 0x558))();
    }
    else if (in_ECX[0xc97] == 1) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc99]);
    }
    break;
  case (int *)0x33:
    if (in_ECX[0xc9a] == 0) {
      (**(code **)(*in_ECX + 0x558))();
    }
    break;
  case (int *)0x35:
    if (param_1 != (wchar_t *)0x0) {
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc9e]);
      iVar16 = in_ECX[0xc9f];
      goto LAB_0073189b;
    }
  }
  piVar4 = local_24;
  if ((param_1 == (wchar_t *)0x1c) && (param_1 = (wchar_t *)0x8, local_24 == (int *)0x8)) {
    piVar4 = (int *)0x1c;
    local_24 = (int *)0x1c;
  }
LAB_007318c3:
  switch(param_1) {
  case (wchar_t *)0x8:
    FUN_0044e950(in_ECX + 0x60c);
    uVar6 = FUN_00466790();
    if (uVar6 < 2) {
      pfStack_1c = (float *)0xffffffff;
    }
    else {
      puVar13 = (undefined4 *)FUN_006db690(1);
      pfStack_1c = (float *)*puVar13;
    }
    FUN_00404560(&pfStack_1c);
    iVar16 = FUN_00402060();
    if (iVar16 == 0x2e) {
      FUN_0040eb40(u_SM_UPPER_SLASH_00d7f9a4);
    }
    if ((piVar4 != (int *)0x8) && (iVar16 = FUN_00402060(), iVar16 == -1)) {
      cVar2 = FUN_0071bd50();
      if (cVar2 == '\0') {
        cVar2 = FUN_0071ba30();
        if (cVar2 != '\0') {
          *(undefined1 *)(in_ECX + 0xc24) = 1;
        }
      }
      else {
        *(undefined1 *)(in_ECX + 0xca0) = 1;
      }
    }
    break;
  case (wchar_t *)0x13:
    if (piVar4 != (int *)&DAT_00000013) {
      (**(code **)(*in_ECX + 0x10c))(u_SWD_GUARD_00d7f990,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_SM_GUARD_00d7f97c,0xffffffff,0,0);
      in_ECX[0xbba] = 0;
    }
    in_ECX[0xbb0] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0xb8))(*(undefined4 *)(*(int *)((int)param_2 + 4) + 0xc));
    piStack_2c = (int *)(**(code **)(*in_ECX + 0x67c))(1);
    pfStack_1c = (float *)(**(code **)(*in_ECX + 0x64c))(1);
    if (in_ECX[0xbb0] == 0) {
      (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
      (**(code **)(*in_ECX + 0x49c))(4,4,0);
    }
    else {
      piVar4 = (int *)FUN_006db690(2);
      cStack_2d = *piVar4 == 1;
      piVar4 = (int *)FUN_006db690(2);
      if (*piVar4 == 2) {
        in_ECX[0xbba] = 1;
        iVar16 = FUN_00b06f00();
        in_ECX[3000] = iVar16;
      }
      (**(code **)(*in_ECX + 0x10c))(u_SWD_GUARDED_00d6a420,0xffffffff,0,0);
      iVar16 = 0;
      in_ECX[0xbb2] = 100;
      if (cStack_2d == '\0') {
        iVar16 = FUN_00550080(0,pfStack_1c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        iVar15 = FUN_00550080(1,pfStack_1c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        in_ECX[0xbb2] = iVar15;
      }
      else {
        uVar8 = 0xffffffff;
        piVar4 = in_ECX;
        (**(code **)(*in_ECX + 0x67c))(2);
        FUN_0054e880(piVar4,uVar8);
        FUN_00721b20(1,0,1);
      }
      (**(code **)(*in_ECX + 0x488))(0,iVar16,iVar16,0,(iVar16 * -1000) / in_ECX[0xbb2],1);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
      uVar8 = FUN_00447960(uVar8);
      (**(code **)(iVar16 + 0x49c))(uVar8);
      piVar4 = (int *)FUN_006db690(1);
      if ((*piVar4 < 0x17) || (piVar4 = (int *)FUN_006db690(1), *piVar4 < 0x47)) {
        piVar4 = (int *)FUN_006db690(1);
        if (*piVar4 < 0x17) {
          iVar16 = 0x16;
        }
        else {
          piVar4 = (int *)FUN_006db690(1);
          iVar16 = *piVar4;
        }
      }
      else {
        iVar16 = 0x47;
      }
      iVar15 = FUN_00473f20(0x17,6,iVar16 + -0x16,0x31);
      iVar5 = (**(code **)(*in_ECX + 0xc0))();
      if (iVar5 == 0) {
        iVar5 = (**(code **)(*in_ECX + 0x94))();
        piStack_28 = (int *)(iVar5 - iVar15);
      }
      else {
        iVar5 = (**(code **)(*in_ECX + 0x94))();
        piStack_28 = (int *)(iVar15 + iVar5);
      }
      pwStack_20 = (wchar_t *)(**(code **)(*in_ECX + 0x98))();
      iVar15 = (**(code **)(*in_ECX + 0x9c))();
      piStack_14 = (int *)(iVar16 + iVar15);
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 1;
      if (pvStack_18 == (void *)0x0) {
        uVar8 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_Guard_Spark_ani_00d7f938;
        uVar8 = FUN_004334b0(u_Effect_Animation_Guard_Spark_ani_00d7f938,1);
        uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      pvStack_18 = (void *)FUN_00403c50(0x1fc);
      local_8._0_1_ = 2;
      if (pvStack_18 == (void *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        piVar4 = (int *)FUN_004abd20(uVar8,1);
      }
      local_8._0_1_ = 0;
      FUN_0050dd70(in_ECX,2,0,piVar4,in_ECX,0,0);
      iVar16 = *piVar4;
      uVar8 = (**(code **)(*in_ECX + 0xc0))();
      (**(code **)(iVar16 + 0xbc))(uVar8);
      (**(code **)(*piVar4 + 0x88))(piStack_28,pwStack_20,piStack_14);
      *(undefined1 *)(in_ECX + 0xbb4) = 0;
      piVar4 = local_24;
    }
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    FUN_004ba360(in_ECX[0xbb0] != 0);
    FUN_00a28110(1);
    param_4 = (int *)((uint)param_4 & 0xffffff00);
    in_ECX[0xbb1] = 0;
    if (piVar4 != (int *)&DAT_00000013) {
      if (in_ECX[0xbb0] == 0) {
        iVar16 = FUN_0054ff60(0,in_ECX);
        in_ECX[0xbb1] = iVar16;
      }
      if (in_ECX[0xbb0] == 1) {
        in_ECX[0xbb3] = -1;
      }
      else {
        uVar8 = 0;
        piVar4 = in_ECX;
        (**(code **)(*in_ECX + 0x67c))(2,0);
        iVar16 = FUN_0054ff60(uVar8,piVar4);
        iVar15 = FUN_00b06f00();
        in_ECX[0xbb3] = iVar16 + iVar15;
      }
      in_ECX[0xbb9] = -1;
      if ((in_ECX[0xbb0] != 1) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if ((iVar16 == 3) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0xe), 0 < iVar16)) {
          (**(code **)(*in_ECX + 0x67c))(0xe);
          iVar16 = FUN_0054ff60(0,in_ECX);
          uVar8 = 0xe;
        }
        else {
          iVar16 = (**(code **)(*in_ECX + 0x620))();
          if ((iVar16 != 0) || (iVar16 = (**(code **)(*in_ECX + 0x64c))(0xc), iVar16 < 1))
          goto LAB_00731e72;
          (**(code **)(*in_ECX + 0x67c))(0xc);
          iVar16 = FUN_0054ff60(1,in_ECX);
          uVar8 = 0xc;
        }
        iVar15 = (**(code **)(*in_ECX + 0x64c))(uVar8);
        if (iVar16 <= iVar15) {
          iVar16 = FUN_00b06f00();
          iVar15 = FUN_0054ff60(1,in_ECX);
          in_ECX[0xbb9] = iVar16 + iVar15;
        }
      }
LAB_00731e72:
      if (in_ECX[0xbb5] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x8c);
        local_8._0_1_ = 3;
        if (pvStack_18 == (void *)0x0) {
          piVar4 = (int *)0x0;
        }
        else {
          piVar4 = (int *)FUN_004796f0(0xc,0,0xffffffff);
        }
        in_ECX[0xbb5] = (int)piVar4;
        local_8._0_1_ = 0;
        iVar16 = (**(code **)(*piVar4 + 0x50))();
        *(undefined1 *)(iVar16 + 0x48) = 0;
      }
      uVar8 = FUN_00550080(4,pfStack_1c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      FUN_00478650();
      FUN_0058d050(0xc,uVar8);
      (**(code **)(*(int *)in_ECX[0xbb5] + 0x48))();
    }
    goto LAB_007329a9;
  case (wchar_t *)0x14:
    in_ECX[0xbbb] = **(int **)((int)param_2 + 4);
    if ((piVar4 != (int *)&DAT_00000014) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(6), 0 < iVar16)
       ) {
      uVar8 = 1;
      piVar4 = in_ECX;
      (**(code **)(*in_ECX + 0x67c))(6,1);
      iVar16 = FUN_0054ff60(uVar8,piVar4);
      in_ECX[0xbbc] = iVar16;
    }
    if (in_ECX[0xbbb] == 0) {
      (**(code **)(*in_ECX + 0x10c))(&DAT_00d7f924,0x12,0,0);
    }
    else if (in_ECX[0xbbb] == 1) {
      (**(code **)(*in_ECX + 0x10c))(u_SM_GUE_CHARGE_00d7f908,0x13,0,0);
    }
    else {
      (**(code **)(*in_ECX + 0x110))(0x13);
      (**(code **)(*in_ECX + 0x10c))(&DAT_00d7f924,0x12,0,0);
      *(undefined1 *)(in_ECX + 0xbc3) = 0;
    }
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(1);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(0);
    (**(code **)(iVar16 + 0x198))(uVar8);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,2,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    if ((in_ECX[0xbbb] == 0) || (in_ECX[0xbbb] == 2)) {
      uVar38 = 5;
      (**(code **)(*in_ECX + 0x67c))(5);
      piStack_28 = (int *)(**(code **)(*in_ECX + 0x64c))(5);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(0,piStack_28,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
      iVar16 = FUN_004caa20(1,piStack_28,in_ECX,uVar8,uVar38);
      iVar15 = FUN_00402060();
      piStack_14 = (int *)(float)((iVar16 * 100) / (iVar15 + 100));
      FUN_00404560(&piStack_14);
    }
    if (in_ECX[0xbbb] == 2) {
      uVar29 = 0;
      uVar28 = 0;
      uVar27 = 0xc;
      uVar26 = 0xffffffff;
      uVar24 = 0xffffffff;
      uVar20 = 6;
      piVar4 = in_ECX;
      uVar8 = (**(code **)(*in_ECX + 0x64c))(6);
      uVar38 = 0;
      uVar34 = 6;
      (**(code **)(*in_ECX + 0x67c))(6,0,uVar8);
      uVar8 = FUN_00550080(uVar34,uVar38,uVar8,uVar20,piVar4,uVar24,uVar26,uVar27);
      piVar4 = (int *)FUN_006db690(1);
      iVar16 = *piVar4;
      in_ECX[0xbbd] = iVar16;
      iVar16 = FUN_00473f20(0,uVar8,iVar16,in_ECX[0xbbc],uVar28,uVar29);
      iVar15 = FUN_00402060();
      piStack_14 = (int *)(((iVar15 + 100) * (iVar16 + 100)) / 100 + -100);
      FUN_00404560(&piStack_14);
    }
    if (in_ECX[0xbbb] == 3) {
      (**(code **)(*in_ECX + 0x67c))(6);
      piStack_2c = (int *)(**(code **)(*in_ECX + 0x64c))(6);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x11);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x14);
      (**(code **)(iVar16 + 0x198))(uVar8);
      piStack_14 = (int *)FUN_0054ff60(2,in_ECX);
      iVar16 = *in_ECX;
      uVar34 = 1;
      uVar8 = FUN_0054ff60(3,in_ECX);
      (**(code **)(iVar16 + 0x488))(0,piStack_14,piStack_14,0,uVar8,uVar34);
      (**(code **)(*in_ECX + 0x494))(0,2,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
      (**(code **)(iVar16 + 0x49c))(uVar8);
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 4;
      if (pvStack_18 == (void *)0x0) {
        uVar8 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_HardAttackCharg_00d7f8a8;
        uVar8 = FUN_004334b0(u_Effect_Animation_HardAttackCharg_00d7f8a8,1);
        uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      pvStack_18 = (void *)FUN_00403c50(0x1fc);
      local_8._0_1_ = 5;
      if (pvStack_18 == (void *)0x0) {
        pfVar9 = (float *)0x0;
      }
      else {
        pfVar9 = (float *)FUN_004abd20(uVar8,1);
      }
      local_8._0_1_ = 0;
      pfStack_1c = pfVar9;
      FUN_0050dd70(in_ECX,2,0,pfVar9,in_ECX,0,0);
      piStack_14 = (int *)*pfVar9;
      uVar8 = (**(code **)(*in_ECX + 0xc0))();
      (*(code *)piStack_14[0x2f])(uVar8);
      fVar12 = *pfVar9;
      uVar8 = (**(code **)(*in_ECX + 0x98))(0);
      uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
      (**(code **)((int)fVar12 + 0x88))(uVar8);
      if (in_ECX[0xbc4] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 6;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_wave_down_ani_00d7f864;
          uVar8 = FUN_004334b0(u_Effect_Animation_wave_down_ani_00d7f864,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbc4] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 7;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_wave_up_ani_00d7f828;
          uVar8 = FUN_004334b0(u_Effect_Animation_wave_up_ani_00d7f828,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbc5] = iVar16;
      }
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbc4],0,0,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xbc5],0,0,0,0,0,0,0,1);
      DAT_00f5478c = 0;
      FUN_004e2780(*(undefined2 *)((int)in_ECX + 0x2f0e));
      sVar1 = *(short *)((int)in_ECX + 0x2f0e);
      if (sVar1 == 0x19) {
        uVar28 = 0;
        uVar27 = 0;
        uVar26 = 0xffffffff;
        pwVar19 = u_GHOST_DRIVE_KHAZAN_00d7f800;
        (**(code **)(*in_ECX + 0x10c))(u_GHOST_DRIVE_KHAZAN_00d7f800,0xffffffff,0,0);
        uVar34 = 0xc;
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
        piVar4 = piStack_2c;
        uVar8 = FUN_004caa20(1,piStack_2c,in_ECX,uVar8,uVar34);
        FUN_004e2780(uVar8);
        uVar24 = 0;
        uVar20 = 0;
        uVar38 = 0xc;
        uVar34 = 0xffffffff;
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
        uVar8 = FUN_00550080(4,piVar4,in_ECX,uVar8,uVar34,uVar38,uVar20,uVar24);
        FUN_004e2780(uVar8);
        uVar24 = 0;
        uVar20 = 0;
        uVar38 = 0xc;
        uVar34 = 0xffffffff;
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
        uVar8 = FUN_00550080(5,piVar4,in_ECX,uVar8,uVar34,uVar38,uVar20,uVar24);
        FUN_004e2780(uVar8);
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
        uVar34 = 6;
LAB_00732601:
        uVar8 = FUN_00550080(uVar34,piVar4,in_ECX,uVar8,pwVar19,uVar26,uVar27,uVar28);
        FUN_004e2780(uVar8);
      }
      else {
        if (sVar1 == 0x24) {
          uVar28 = 0;
          uVar27 = 0;
          uVar26 = 0xffffffff;
          pwVar19 = u_GHOST_DRIVE_SAYA_00d7f7dc;
          (**(code **)(*in_ECX + 0x10c))(u_GHOST_DRIVE_SAYA_00d7f7dc,0xffffffff,0,0);
          uVar34 = 0xc;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
          piVar4 = piStack_2c;
          uVar8 = FUN_004caa20(2,piStack_2c,in_ECX,uVar8,uVar34);
          FUN_004e2780(uVar8);
          uVar24 = 0;
          uVar20 = 0;
          uVar38 = 0xc;
          uVar34 = 0xffffffff;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar8 = FUN_00550080(7,piVar4,in_ECX,uVar8,uVar34,uVar38,uVar20,uVar24);
          FUN_004e2780(uVar8);
          uVar24 = 0;
          uVar20 = 0;
          uVar38 = 0xc;
          uVar34 = 0xffffffff;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar8 = FUN_00550080(8,piVar4,in_ECX,uVar8,uVar34,uVar38,uVar20,uVar24);
          FUN_004e2780(uVar8);
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar34 = 9;
          goto LAB_00732601;
        }
        if (sVar1 == 0x29) {
          uVar28 = 0;
          uVar27 = 0;
          uVar26 = 0xffffffff;
          pwVar19 = u_GHOST_DRIVE_BREMEN_00d7f7b4;
          (**(code **)(*in_ECX + 0x10c))(u_GHOST_DRIVE_BREMEN_00d7f7b4,0xffffffff,0,0);
          uVar34 = 0xc;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
          piVar4 = piStack_2c;
          uVar8 = FUN_004caa20(3,piStack_2c,in_ECX,uVar8,uVar34);
          FUN_004e2780(uVar8);
          uVar24 = 0;
          uVar20 = 0;
          uVar38 = 0xc;
          uVar34 = 0xffffffff;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar8 = FUN_00550080(10,piVar4,in_ECX,uVar8,uVar34,uVar38,uVar20,uVar24);
          FUN_004e2780(uVar8);
          uVar24 = 0;
          uVar20 = 0;
          uVar38 = 0xc;
          uVar34 = 0xffffffff;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar8 = FUN_00550080(0xb,piVar4,in_ECX,uVar8,uVar34,uVar38,uVar20,uVar24);
          FUN_004e2780(uVar8);
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar34 = 0xc;
          goto LAB_00732601;
        }
      }
      (**(code **)(*in_ECX + 0x2b8))(0x4e37,0,0,0,0,1,1,4);
    }
    iVar16 = in_ECX[0xbbb];
    if (iVar16 == 1) {
      if (in_ECX[0xbc1] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 8;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_HardAttackOnCha_00d7f760;
          uVar8 = FUN_004334b0(u_Effect_Animation_HardAttackOnCha_00d7f760,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbc1] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 9;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_HardAttackOnCha_00d7f708;
          uVar8 = FUN_004334b0(u_Effect_Animation_HardAttackOnCha_00d7f708,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbc2] = iVar16;
      }
      *(undefined1 *)(in_ECX + 0xbbe) = 0;
    }
    else if ((iVar16 == 0) || (iVar16 == 2)) {
      piVar4 = in_ECX + 0xbbf;
      if (in_ECX[0xbbf] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 10;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_HardAttack1_ani_00d7f6c0;
          uVar8 = FUN_004334b0(u_Effect_Animation_HardAttack1_ani_00d7f6c0,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        *piVar4 = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0xb;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_HardAttack2_ani_00d7f678;
          uVar8 = FUN_004334b0(u_Effect_Animation_HardAttack2_ani_00d7f678,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbc0] = iVar16;
      }
      uVar8 = 0;
      piVar7 = in_ECX;
      (**(code **)(*in_ECX + 0x67c))(5,0);
      iVar16 = FUN_0054ff60(uVar8,piVar7);
      iVar15 = 0;
      piStack_14 = (int *)((float)iVar16 * _DAT_00cc10ac);
      do {
        FUN_00a25900(piStack_14,piStack_14);
        iVar15 = iVar15 + 1;
        (**(code **)(*in_ECX + 0xf8))(iVar15,*piVar4,0x28,0,0,0,0,0,0,1);
        piVar4 = piVar4 + 1;
      } while (iVar15 < 2);
    }
    if (in_ECX[0xbbb] == 1) {
      FUN_004ba360(0);
      uVar8 = 1;
LAB_0073281b:
      FUN_00a28110(uVar8);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
    }
    else if (in_ECX[0xbbb] == 2) {
      FUN_004ba360(1);
      uVar8 = 0;
      goto LAB_0073281b;
    }
    if (in_ECX[0xbbb] != 2) {
      *(undefined1 *)((int)in_ECX + 0x2ef9) = 0;
    }
    if ((in_ECX[0xbbb] == 0) || (in_ECX[0xbbb] == 2)) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
      (**(code **)(iVar16 + 0x10c))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x694))(2);
      FUN_0040eb40(uVar8);
    }
    break;
  case (wchar_t *)0x15:
    (**(code **)(*in_ECX + 0x10c))(u_SM_HITBACK_00d7f65c,0xffffffff,0,0);
    (**(code **)(*in_ECX + 0xb8))(**(undefined4 **)((int)param_2 + 4));
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(2);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(1);
    (**(code **)(iVar16 + 0x198))(uVar8);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,2,1000,1000,0x3f800000,0x3f800000);
    uVar26 = 0;
    uVar24 = 4;
    uVar20 = 4;
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    iVar16 = *in_ECX;
    uVar38 = 0;
    uVar34 = 0;
    uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
    (**(code **)(iVar16 + 0x10c))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x694))(2);
    FUN_0040eb40(uVar8);
    (**(code **)(*in_ECX + 0x1d0))(0xc);
    uVar8 = (**(code **)(*in_ECX + 0x64c))(7);
    (**(code **)(*in_ECX + 0x67c))(7,1,uVar8);
    iVar16 = FUN_004caa20(uVar34,uVar38,uVar20,uVar24,uVar26);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
LAB_007329a9:
    piVar4 = (int *)FUN_0041ffe0();
    (**(code **)(*piVar4 + 0xc))(2,0);
    FUN_004ba0c0(2,0);
    break;
  case (wchar_t *)0x16:
    in_ECX[0xbc7] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0xb8))(*(undefined4 *)(*(int *)((int)param_2 + 4) + 4));
    in_ECX[0xbc8] = 3;
    piStack_2c = (int *)0x0;
    iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b);
    if (0 < iVar16) {
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      piVar4 = in_ECX;
      if ((iVar16 == 5) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(4), 0 < iVar16)) {
        (**(code **)(*in_ECX + 0x67c))(4);
        iVar16 = FUN_0054ff60(1,in_ECX);
        iVar15 = (**(code **)(*in_ECX + 0x64c))(4);
        if (iVar16 <= iVar15) {
          uVar27 = 0;
          uVar26 = 0;
          uVar24 = 0xc;
          uVar20 = 0xffffffff;
          uVar38 = 0xffffffff;
          in_ECX[0xbc8] = 5;
          uVar8 = (**(code **)(*in_ECX + 0x64c))(4);
          uVar34 = 3;
LAB_00732af0:
          piStack_2c = (int *)FUN_00550080(uVar34,uVar8,piVar4,uVar38,uVar20,uVar24,uVar26,uVar27);
        }
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if ((iVar16 == 1) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0xd), 0 < iVar16)) {
          (**(code **)(*in_ECX + 0x67c))(0xd);
          iVar16 = FUN_0054ff60(0,in_ECX);
          iVar15 = (**(code **)(*in_ECX + 0x64c))(0xd);
          if (iVar16 <= iVar15) {
            uVar27 = 0;
            uVar26 = 0;
            uVar24 = 0xc;
            uVar20 = 0xffffffff;
            uVar38 = 0xffffffff;
            in_ECX[0xbc8] = 5;
            uVar8 = (**(code **)(*in_ECX + 0x64c))(0xd);
            uVar34 = 2;
            goto LAB_00732af0;
          }
        }
      }
    }
    (**(code **)(*in_ECX + 0x67c))(8);
    piStack_28 = (int *)(**(code **)(*in_ECX + 0x64c))(8);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(in_ECX[0xbc7] + 3);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    if ((in_ECX[0xbc8] == 3) && (in_ECX[0xbc7] == 2)) {
      iVar16 = 7;
    }
    else {
      iVar16 = in_ECX[0xbc7] + 2;
    }
    iVar15 = *in_ECX;
    uVar8 = FUN_005270f0(iVar16);
    (**(code **)(iVar15 + 0x198))(uVar8);
    if ((in_ECX[0xbc8] == 3) && (in_ECX[0xbc7] < 3)) {
      apwStack_50[2] = (wchar_t *)0x0;
      apwStack_50[3] = (wchar_t *)0x0;
      apwStack_50[4] = (wchar_t *)0x1;
      pfStack_1c = (float *)apwStack_50[in_ECX[0xbc7] + 2];
    }
    else {
      apwStack_50[0] = (wchar_t *)0x0;
      apwStack_50[1] = (wchar_t *)0x0;
      apwStack_50[2] = (wchar_t *)0x0;
      apwStack_50[3] = (wchar_t *)0x1;
      apwStack_50[4] = (wchar_t *)0x2;
      pfStack_1c = (float *)apwStack_50[in_ECX[0xbc7]];
    }
    apwStack_50[2] = (wchar_t *)0x0;
    uVar34 = 0xc;
    uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
    iVar16 = FUN_004caa20(pfStack_1c,piStack_28,in_ECX,uVar8,uVar34);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
    uVar34 = 0;
    uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
    iVar16 = FUN_004caa20((int)pfStack_1c + 3,piStack_28,in_ECX,uVar8,uVar34);
    piStack_14 = (int *)(iVar16 * 100);
    iVar16 = FUN_00402060();
    piStack_14 = (int *)(float)((int)piStack_14 / (iVar16 + 100));
    FUN_00404560(&piStack_14);
    if ((in_ECX[0xbc8] == 5) && (in_ECX[0xbc7] == 4)) {
      piStack_14 = piStack_2c;
      FUN_00404560(&piStack_14);
    }
    uVar8 = FUN_0054ff60(0,in_ECX);
    uVar34 = FUN_0054ff60(1,in_ECX);
    (**(code **)(*in_ECX + 0x488))(0,uVar8,uVar8,0,uVar34,1);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
    (**(code **)(iVar16 + 0x49c))(uVar8);
    in_ECX[0xbd0] = -200;
    if (in_ECX[0xbc7] == in_ECX[0xbc8] - 1U) {
      pwVar19 = u_SM_TRIPLE3_00d7f644;
LAB_00732d2d:
      (**(code **)(*in_ECX + 0x10c))(pwVar19,0xffffffff,0,0);
    }
    else {
      uVar6 = in_ECX[0xbc7] & 0x80000001;
      bVar17 = uVar6 == 0;
      if ((int)uVar6 < 0) {
        bVar17 = (uVar6 - 1 | 0xfffffffe) == 0xffffffff;
      }
      if (!bVar17) {
        pwVar19 = u_SM_TRIPLE2_00d7f614;
        goto LAB_00732d2d;
      }
      (**(code **)(*in_ECX + 0x10c))(u_SM_TRIPLE1_00d7f62c,0xffffffff,0,0);
    }
    (**(code **)(*in_ECX + 0x10c))(u_R_TSLASH_00d7be38,0xffffffff,0,0);
    if (in_ECX[0xbc9] == 0) {
      iVar16 = 0;
      piStack_28 = in_ECX + 0xbc9;
      do {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0xc;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_TripleSlash_Sla_00d7f5c0,iVar16 + 1,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        *piStack_28 = iVar15;
        iVar16 = iVar16 + 1;
        piStack_28 = piStack_28 + 1;
        local_8._0_1_ = 0;
      } while (iVar16 < 5);
      pfStack_1c = (float *)(in_ECX + 0xbce);
      iVar16 = 0;
      do {
        local_8._0_1_ = 0;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0xd;
        if (pvStack_18 == (void *)0x0) {
          fVar12 = 0.0;
        }
        else {
          if ((uint)in_ECX[0x97] < 8) {
            piStack_28 = in_ECX + 0x92;
          }
          else {
            piStack_28 = (int *)in_ECX[0x92];
          }
          uVar34 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_TripleSlash_Mov_00d7f570,iVar16 + 1,1);
          fVar12 = (float)FUN_00472a60(piStack_28,uVar8,uVar34);
        }
        *pfStack_1c = fVar12;
        iVar16 = iVar16 + 1;
        pfStack_1c = pfStack_1c + 1;
        local_8._0_1_ = 0;
      } while (iVar16 < 2);
    }
    (**(code **)(*in_ECX + 0xf8))(2,in_ECX[in_ECX[0xbc7] + 0xbc9],0,0,0,0,1,0,0,1);
    uVar6 = in_ECX[0xbc7] & 0x80000001;
    if ((int)uVar6 < 0) {
      uVar6 = (uVar6 - 1 | 0xfffffffe) + 1;
    }
    (**(code **)(*in_ECX + 0xf8))(1,in_ECX[uVar6 + 0xbce],0,0,0,0,1,0,0,1);
    break;
  case (wchar_t *)0x17:
    if ((param_2 == (int *)0x0) || (cVar2 = FUN_004e2560(), cVar2 != '\0')) {
      iVar16 = 0;
    }
    else {
      iVar16 = 1;
    }
    in_ECX[0xbdc] = iVar16;
    iVar16 = *in_ECX;
    uVar34 = 8;
    uVar8 = (**(code **)(iVar16 + 0x38c))(8);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(8);
    (**(code **)(iVar16 + 0x198))(uVar8);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,2,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    *(undefined1 *)(in_ECX + 0xbdb) = 0;
    if (in_ECX[0xbd3] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0xe;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f4f0;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f4f0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd3] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0xf;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f460;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f460,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd4] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x10;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f3e0;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f3e0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd5] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x11;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f350;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f350,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd6] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x12;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f2c0;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f2c0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd7] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x13;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f230;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f230,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd8] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x14;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f1a8;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f1a8,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbd9] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x15;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar38 = 1;
        pwVar19 = u_Effect_Animation_MomentarySlash__00d7f120;
        uVar8 = FUN_004334b0(u_Effect_Animation_MomentarySlash__00d7f120,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar38);
      }
      local_8._0_1_ = 0;
      in_ECX[0xbda] = iVar16;
    }
    (**(code **)(*in_ECX + 0x10c))(u_SM_BAL_READY_00d7f104,0xffffffff,0,0);
    *(undefined1 *)(in_ECX + 0xbd1) = 0;
    *(undefined1 *)((int)in_ECX + 0x2f45) = 0;
    uVar8 = (**(code **)(*in_ECX + 0x694))(2);
    FUN_0040eb40(uVar8);
    (**(code **)(*in_ECX + 0x67c))(9);
    uVar8 = (**(code **)(*in_ECX + 0x64c))(9);
    uVar38 = (**(code **)(*in_ECX + 0x1d0))(0xc);
    iVar16 = FUN_004caa20(0,uVar8,in_ECX,uVar38,uVar34);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
    if (in_ECX[0xbdc] != 0) {
      FUN_004ba360(1);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
      in_ECX[0xd3] = 2;
      piStack_14 = (int *)0x42c80000;
      FUN_00404560(&piStack_14);
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 1) {
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
        uVar24 = 0xd;
        piVar4 = in_ECX;
        uVar34 = (**(code **)(*in_ECX + 0x64c))(0xd);
        uVar20 = 4;
        uVar38 = 0xd;
        (**(code **)(*in_ECX + 0x67c))(0xd,4,uVar34);
        iVar16 = FUN_004caa20(uVar38,uVar20,uVar34,uVar24,piVar4);
        piStack_14 = (int *)(iVar16 + -100);
        FUN_00404560(&piStack_14);
        (**(code **)(*in_ECX + 0x67c))(0xd,uVar8);
        uVar8 = (**(code **)(*in_ECX + 0x64c))(0xd);
        in_ECX[0xaa] = 0xb;
        iVar16 = FUN_00550080(5,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        piStack_14 = (int *)((float)iVar16 * _DAT_00cc8830);
        FUN_00404560(&piStack_14);
        piStack_14 = (int *)FUN_00550080(6,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        FUN_00404560(&piStack_14);
        piStack_14 = (int *)FUN_00550080(7,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        FUN_00404560(&piStack_14);
        FUN_00434a80();
        piStack_14 = (int *)FUN_00550080(8,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        FUN_00402150(&piStack_14);
        local_8._0_1_ = 0x16;
        FUN_0046d0b0(auStack_6c);
        local_8._0_1_ = 0;
        FUN_00402010();
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 5) {
          uVar26 = 4;
          (**(code **)(*in_ECX + 0x67c))(4);
          uVar24 = 4;
          uVar8 = (**(code **)(*in_ECX + 0x64c))(4);
          uVar20 = 0xc;
          uVar34 = (**(code **)(*in_ECX + 0x1d0))(0xc);
          piVar4 = in_ECX;
          uVar38 = (**(code **)(*in_ECX + 0x64c))(4);
          (**(code **)(*in_ECX + 0x67c))(4,8,uVar38);
          iVar16 = FUN_004caa20(piVar4,uVar34,uVar20,uVar24,uVar26);
          piStack_14 = (int *)(iVar16 + -100);
          FUN_00404560(&piStack_14);
          in_ECX[0xaa] = 6;
          iVar16 = FUN_00550080(9,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          piStack_14 = (int *)((float)iVar16 * _DAT_00cc8830);
          FUN_00404560(&piStack_14);
          piStack_14 = (int *)FUN_00550080(10,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_00404560(&piStack_14);
          piStack_14 = (int *)FUN_00550080(0xb,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_00404560(&piStack_14);
          FUN_00434a80();
          piStack_14 = (int *)FUN_00550080(0xc,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_00402150(&piStack_14);
          local_8._0_1_ = 0x17;
          FUN_0046d0b0(auStack_64);
          local_8._0_1_ = 0;
          FUN_00402010();
        }
      }
    }
    break;
  case (wchar_t *)0x18:
    in_ECX[0xbdd] = **(int **)((int)param_2 + 4);
    piStack_14 = (int *)0x0;
    FUN_00404560(&piStack_14);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(9);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,4,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    uVar8 = (**(code **)(*in_ECX + 0x64c))(in_ECX[0xbdd]);
    iVar16 = in_ECX[0xbdd];
    piVar4 = in_ECX;
    (**(code **)(*in_ECX + 0x67c))(iVar16);
    pwVar19 = (wchar_t *)FUN_00468430(iVar16,piVar4);
    pwStack_20 = pwVar19;
    (**(code **)(*in_ECX + 0x554))(pwVar19,1,uVar8);
    in_ECX[0xbe3] = (int)pwVar19;
    iVar16 = 1;
    do {
      iVar15 = FUN_00a25c90(iVar16);
      iVar16 = iVar16 + 1;
      in_ECX[0xbe3] = in_ECX[0xbe3] - (*(int *)(iVar15 + 0x30) - (iVar15 + 0x30) ^ DAT_010d3ef8);
    } while (iVar16 < 4);
    iVar16 = FUN_00402060();
    iVar15 = 0;
    in_ECX[0xbe3] = (in_ECX[0xbe3] * 1000) / iVar16;
    in_ECX[0xbe5] = 4;
    uStack_78 = 7;
    uStack_7c = 0;
    uStack_8c = (undefined4 *)((uint)uStack_8c._2_2_ << 0x10);
    iVar16 = in_ECX[0xbdd];
    local_8._0_1_ = 0x18;
    uVar3 = (undefined1)local_8;
    local_8._0_1_ = 0x18;
    if (iVar16 == 0x14) {
      if (in_ECX[0xbe7] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x19;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_NormalWaveSlash_00d7f0b8;
          uVar8 = FUN_004334b0(u_Effect_Animation_NormalWaveSlash_00d7f0b8,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        in_ECX[0xbe7] = iVar16;
      }
      local_8._0_1_ = 0x18;
      piStack_14 = (int *)0x4e21;
      FUN_00404560(&piStack_14);
      in_ECX[0xbe0] = in_ECX[0xbe7];
      *(undefined1 *)(in_ECX + 0xbe6) = 0;
      in_ECX[0xbe5] = 3;
      uVar20 = 0x14;
      (**(code **)(*in_ECX + 0x67c))(0x14);
      uVar8 = FUN_0054ff60(1,0);
      uVar34 = FUN_0054ff60(2,0);
      uVar38 = 1;
      (**(code **)(*in_ECX + 0x488))(0,uVar8,uVar8,0,uVar34,1);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
      (**(code **)(iVar16 + 0x49c))(uVar8);
      FUN_0040eb40(u_HADOUKEN_00d7f0a0);
      (**(code **)(*in_ECX + 0x67c))(in_ECX[0xbdd],0);
      iVar15 = FUN_0054ff60(uVar38,uVar20);
      pwVar19 = pwStack_20;
LAB_007338f3:
      puVar13 = uStack_8c;
      if (uStack_78 < 8) goto LAB_00733901;
    }
    else {
      piVar4 = in_ECX;
      local_8._0_1_ = uVar3;
      if (iVar16 == 0x15) {
        if (in_ECX[0xbe8] == 0) {
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x1a;
          if (pvStack_18 == (void *)0x0) {
            iVar16 = 0;
          }
          else {
            uVar34 = 1;
            pwVar35 = u_Effect_Animation_IceWave_ani_00d7f064;
            uVar8 = FUN_004334b0(u_Effect_Animation_IceWave_ani_00d7f064,1);
            iVar16 = FUN_00472a60(uVar8,pwVar35,uVar34);
          }
          in_ECX[0xbe8] = iVar16;
        }
        local_8._0_1_ = 0x18;
        in_ECX[0xbe0] = in_ECX[0xbe8];
        piStack_14 = (int *)0x4e22;
        FUN_00404560(&piStack_14);
        FUN_0040eb40(u_SM_ICEWAVE_00d7f04c);
        uVar8 = 1;
        (**(code **)(*in_ECX + 0x67c))(in_ECX[0xbdd],1);
LAB_007338ec:
        iVar15 = FUN_0054ff60(uVar8,piVar4);
        goto LAB_007338f3;
      }
      if (iVar16 == 0x16) {
        if (in_ECX[0xbe9] == 0) {
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x1b;
          if (pvStack_18 == (void *)0x0) {
            iVar16 = 0;
          }
          else {
            uVar34 = 1;
            pwVar35 = u_Effect_Animation_FireWaveBig_Swo_00d7eff0;
            uVar8 = FUN_004334b0(u_Effect_Animation_FireWaveBig_Swo_00d7eff0,1);
            iVar16 = FUN_00472a60(uVar8,pwVar35,uVar34);
          }
          in_ECX[0xbe9] = iVar16;
        }
        local_8._0_1_ = 0x18;
        piStack_14 = (int *)0x4e38;
        FUN_00404560(&piStack_14);
        in_ECX[0xbe0] = in_ECX[0xbe9];
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 3) {
          pfStack_1c = (float *)0x3f800000;
        }
        else {
          iVar16 = (**(code **)(*in_ECX + 0x620))();
          pfStack_1c = (float *)0x3f4ccccd;
          if (iVar16 != 0) {
            pfStack_1c = (float *)0x3f666666;
          }
        }
        FUN_00a25900(pfStack_1c,pfStack_1c);
        FUN_0040eb40(u_SM_FIREWAVE_00d7efd8);
        uVar8 = 0;
        (**(code **)(*in_ECX + 0x67c))(in_ECX[0xbdd],0);
        goto LAB_007338ec;
      }
LAB_00733901:
      puVar13 = &uStack_8c;
    }
    (**(code **)(*in_ECX + 0x10c))(puVar13,0x14,0,0);
    iVar16 = FUN_00402060();
    local_8._0_1_ = 0;
    in_ECX[0xbe4] = ((int)pwVar19 * 1000) / iVar16 + iVar15;
    FUN_00b8e070();
    break;
  case (wchar_t *)0x19:
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 900))();
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = FUN_00493660();
    FUN_004ba360(iVar16 + -1);
    FUN_00a28110(0);
    param_4 = (int *)((uint)param_4 & 0xffffff00);
    (**(code **)(*in_ECX + 0x494))(2,0,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    FUN_004ba0c0(0,0);
    FUN_00511040(2,0);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
    (**(code **)(iVar16 + 0x49c))(uVar8);
    FUN_0043f540(0);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(10);
    (**(code **)(iVar16 + 0x198))(uVar8);
    (**(code **)(*in_ECX + 0x67c))(0x10);
    uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
    uVar38 = 0x10;
    piVar4 = in_ECX;
    uVar34 = (**(code **)(*in_ECX + 0x64c))(0x10);
    iVar16 = FUN_004caa20(0,uVar34,uVar38,piVar4,uVar8);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
    piStack_14 = (int *)FUN_0054ff60(0,in_ECX);
    FUN_00404560(&piStack_14);
    piStack_14 = (int *)FUN_0054ff60(1,in_ECX);
    FUN_00404560(&piStack_14);
    piStack_14 = (int *)FUN_0054ff60(2,in_ECX);
    FUN_00404560(&piStack_14);
    iVar16 = (**(code **)(*in_ECX + 0x620))();
    if ((iVar16 == 3) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) {
      uVar34 = 1;
      uVar8 = 0xe;
      (**(code **)(*in_ECX + 0x67c))(0xe,1);
      iVar16 = FUN_0054ff60(uVar8,uVar34);
      iVar15 = (**(code **)(*in_ECX + 0x64c))(0xe);
      if (iVar15 < iVar16) goto code_r0x00733b3f;
      uVar20 = 1;
      uVar38 = 1;
      (**(code **)(*in_ECX + 0x2e0))(1,1);
      uVar34 = 0;
      uVar26 = 0;
      uVar24 = 4;
      uVar8 = 0xe;
      piVar4 = in_ECX;
      (**(code **)(*in_ECX + 0x67c))(0xe,4);
      FUN_0054ff60(uVar8,uVar24);
      (**(code **)(*in_ECX + 0x67c))(0xe,3);
      uVar8 = FUN_0054ff60(piVar4,uVar26);
    }
    else {
code_r0x00733b3f:
      uVar20 = 1;
      uVar38 = 1;
      uVar34 = 0;
      uVar8 = 0;
    }
    FUN_00a51f50(uVar8,uVar34,uVar38,uVar20);
    FUN_00a51f70();
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x694))(1,0xffffffff,0,0);
    (**(code **)(iVar16 + 0x10c))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x694))(3);
    FUN_0040eb40(uVar8);
    piStack_14 = (int *)0x0;
    FUN_00404560(&piStack_14);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x9c))();
    FUN_00404560(&piStack_14);
    piStack_14 = (int *)0x0;
    FUN_00404560(&piStack_14);
    pwVar19 = u_SKYRADE_SWING_00d68358;
    goto LAB_0073a15e;
  case (wchar_t *)0x1a:
    in_ECX[0xca4] = **(int **)((int)param_2 + 4);
    in_ECX[0xca5] = *(int *)(*(int *)((int)param_2 + 4) + 4);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(1,3,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    FUN_004ba0c0(2,0);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(10);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    if (in_ECX[0xca4] == 0) {
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0xc);
      (**(code **)(iVar16 + 0x198))(uVar8);
      FUN_004ba360(3);
      FUN_00a28110(0);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
    }
    else if (in_ECX[0xca4] == 1) {
      puVar13 = (undefined4 *)FUN_006db690(2);
      uVar38 = 0;
      ppuVar37 = &PTR_PTR_00f5526c;
      ppuVar36 = &PTR_PTR_00f40910;
      uVar34 = 0;
      uVar8 = FUN_0050b8b0(*puVar13);
      piVar4 = (int *)FUN_00c00d0b(uVar8,uVar34,ppuVar36,ppuVar37,uVar38);
      in_ECX[0xca6] = (int)piVar4;
      if (piVar4 != (int *)0x0) {
        iVar16 = (**(code **)(*piVar4 + 0x94))();
        in_ECX[0xca7] = iVar16;
        iVar16 = (**(code **)(*(int *)in_ECX[0xca6] + 0x98))();
        in_ECX[0xca8] = iVar16;
        iVar16 = (**(code **)(*(int *)in_ECX[0xca6] + 0x9c))();
        in_ECX[0xca9] = iVar16;
      }
      if (in_ECX[0xca6] != 0) {
        if (in_ECX[0xcac] == 0) {
          pvStack_18 = (void *)FUN_00403c50(0x8c);
          local_8._0_1_ = 0x1c;
          if (pvStack_18 == (void *)0x0) {
            iVar16 = 0;
          }
          else {
            iVar16 = FUN_0073de20(in_ECX);
          }
          local_8._0_1_ = 0;
          in_ECX[0xcac] = iVar16;
        }
        (**(code **)(*(int *)in_ECX[0xcac] + 0x48))(in_ECX[0xca6]);
      }
      (**(code **)(*in_ECX + 0x67c))(in_ECX[0xca5]);
      piStack_14 = (int *)(**(code **)(*in_ECX + 0x64c))(in_ECX[0xca5]);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(10);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      if (in_ECX[0xca5] == 0x1f) {
        FUN_004ba360(0x10);
        FUN_00a28110(0);
        param_4 = (int *)((uint)param_4 & 0xffffff00);
        if (in_ECX[0xcad] == 0) {
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x1d;
          if (pvStack_18 == (void *)0x0) {
            iVar16 = 0;
          }
          else {
            uVar34 = 1;
            pwVar19 = u_Effect_Animation_GrabBlastBlood__00d7ef90;
            uVar8 = FUN_004334b0(u_Effect_Animation_GrabBlastBlood__00d7ef90,1);
            iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
          }
          local_8._0_1_ = 0;
          in_ECX[0xcad] = iVar16;
        }
        (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xcad],0x2b,0xffffffa6,0,0,1,0,0,1);
        iVar16 = FUN_0054ff60(0,in_ECX);
        in_ECX[0xcaa] = iVar16;
        in_ECX[0xcab] = 0;
        iVar16 = *in_ECX;
        uVar8 = FUN_005270f0(0xd);
        (**(code **)(iVar16 + 0x198))(uVar8);
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
        piStack_14 = (int *)FUN_004caa20(0,piStack_14,in_ECX,uVar8,in_stack_fffffe98);
        pwStack_20 = (wchar_t *)(float)(int)piStack_14;
        iVar16 = FUN_0073d5f0();
        piStack_14 = (int *)((float)iVar16 * (float)pwStack_20 * _DAT_00cc10ac);
        FUN_00404560(&piStack_14);
        pwVar19 = u_BLOODR_GET_00d7ef78;
        goto LAB_0073a15e;
      }
    }
    break;
  case (wchar_t *)0x1b:
    in_ECX[0xcae] = **(int **)((int)param_2 + 4);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(1);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,4,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    (**(code **)(*in_ECX + 0x2d0))(0);
    if (in_ECX[0xcae] == 1) {
      (**(code **)(*in_ECX + 0x10c))(u_SM_GUE_CHARGE_00d7f908,0x13,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_AIR_SWORD_READY_00d7ddb0,0x17,0,0);
    }
    else if (in_ECX[0xcae] == 2) {
      piVar4 = (int *)FUN_006db690(1);
      iVar16 = *piVar4;
      in_ECX[0xcb0] = iVar16;
      if (in_ECX[0xcaf] <= iVar16) {
        FUN_00721b20(1,0,1);
      }
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x64c))(0x32,0xffffffff);
      (**(code **)(iVar16 + 0x72c))(0x32,uVar8);
      if (in_ECX[0xcb0] < in_ECX[0xcaf]) {
        (**(code **)(*in_ECX + 0x10c))(u_SM_JINGONG_00d7dd78,0xffffffff,0,0);
      }
      else {
        (**(code **)(*in_ECX + 0x10c))(u_SM_SURA_JINGONG_00d7dd90);
      }
    }
    if (in_ECX[0xcae] == 1) {
      piVar4 = in_ECX + 0xcb3;
      if (in_ECX[0xcb3] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x52;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_grandWaveOnChar_00d7dd28;
          uVar8 = FUN_004334b0(u_Effect_Animation_grandWaveOnChar_00d7dd28,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        *piVar4 = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x53;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_grandWaveOnChar_00d7dcd8;
          uVar8 = FUN_004334b0(u_Effect_Animation_grandWaveOnChar_00d7dcd8,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcb4] = iVar16;
      }
      iVar16 = 0;
      do {
        iVar16 = iVar16 + 1;
        (**(code **)(*in_ECX + 0xf8))(iVar16,*piVar4,0,0,0,0,0,0,0,1);
        piVar4 = piVar4 + 1;
      } while (iVar16 < 2);
    }
    else if (in_ECX[0xcae] == 2) {
      if (in_ECX[0xcb2] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x54;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_grandWave_ani_00d7dc98;
          uVar8 = FUN_004334b0(u_Effect_Animation_grandWave_ani_00d7dc98,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcb2] = iVar16;
      }
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xcb2],0,0,0,0,0,0,0,1);
    }
    iVar16 = in_ECX[0xcae];
    if ((iVar16 == 0) || (iVar16 == 1)) {
      FUN_004ba360(0);
      FUN_00a28110(1);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
    }
    else if (iVar16 == 2) {
      FUN_004ba360(1);
      FUN_00a28110(0);
      iVar16 = *in_ECX;
      param_4 = (int *)((uint)param_4 & 0xffffff00);
      uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
      (**(code **)(iVar16 + 0x10c))(uVar8);
      *(undefined1 *)(in_ECX + 0xcb6) = 0;
    }
    if (in_ECX[0xcae] == 1) {
      *(undefined1 *)(in_ECX + 0xcb1) = 0;
    }
    if (in_ECX[0xcae] == 0) {
      uVar8 = (**(code **)(*in_ECX + 0x64c))(0x32);
      uVar34 = 0x32;
      piVar4 = in_ECX;
      (**(code **)(*in_ECX + 0x67c))(0x32);
      iVar16 = FUN_00468430(uVar34,piVar4);
      in_ECX[0xcb5] = iVar16;
      iVar16 = FUN_00402060(uVar8);
      iVar16 = (in_ECX[0xcb5] * 1000) / iVar16;
      in_ECX[0xcb5] = iVar16;
      (**(code **)(*in_ECX + 0x554))(iVar16,0);
    }
    if ((local_24 != (int *)0x1b) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x33), 0 < iVar16)) {
      uVar8 = 0;
      piVar4 = in_ECX;
      (**(code **)(*in_ECX + 0x67c))(0x33,0);
      iVar16 = FUN_0054ff60(uVar8,piVar4);
      in_ECX[0xcaf] = iVar16;
    }
    break;
  case (wchar_t *)0x1d:
    (**(code **)(*in_ECX + 0x67c))(0xb);
    pfStack_1c = (float *)(**(code **)(*in_ECX + 0x64c))(0xb);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0xb);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(0xe);
    (**(code **)(iVar16 + 0x198))(uVar8);
    uVar34 = 0xc;
    uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
    iVar16 = FUN_004caa20(0,pfStack_1c,in_ECX,uVar8,uVar34);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
    uVar34 = 0;
    uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
    iVar16 = FUN_004caa20(2,pfStack_1c,in_ECX,uVar8,uVar34);
    piStack_14 = (int *)(iVar16 * 100);
    iVar16 = FUN_00402060();
    piStack_14 = (int *)(float)((int)piStack_14 / (iVar16 + 100));
    FUN_00404560(&piStack_14);
    iVar16 = FUN_00550080(1,pfStack_1c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
    piStack_14 = (int *)((float)iVar16 * _DAT_00cc8830);
    FUN_004b53a0(&piStack_14);
    uVar8 = 0;
    pfStack_1c = (float *)0x0;
    cVar2 = FUN_0049c090();
    if (cVar2 != '\0') {
      piStack_14 = (int *)(**(code **)(*in_ECX + 0x644))(0);
      if (piStack_14 == (int *)&DAT_00000004) {
        uVar8 = FUN_0054ff60(0,in_ECX);
        uVar34 = 1;
      }
      else {
        piVar4 = (int *)(**(code **)(*in_ECX + 0xc0))();
        if (piStack_14 != piVar4) goto LAB_007385d8;
        uVar8 = FUN_0054ff60(2,in_ECX);
        uVar34 = 3;
      }
      pfStack_1c = (float *)FUN_0054ff60(uVar34,in_ECX);
    }
LAB_007385d8:
    (**(code **)(*in_ECX + 0x488))(0,uVar8,uVar8,0,pfStack_1c,1);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
    (**(code **)(iVar16 + 0x49c))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x694))(1,0xffffffff,0,0);
    (**(code **)(iVar16 + 0x10c))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x694))(3);
    FUN_0040eb40(uVar8);
    if (in_ECX[0xae5] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x5e;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_DashAttackMulti_00d7d870;
        uVar8 = FUN_004334b0(u_Effect_Animation_DashAttackMulti_00d7d870,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xae5] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x5f;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_DashAttackMulti_00d7d818;
        uVar8 = FUN_004334b0(u_Effect_Animation_DashAttackMulti_00d7d818,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xae6] = iVar16;
    }
    *(undefined1 *)(in_ECX + 0xae7) = 0;
    cVar2 = FUN_0049c090();
    if ((((cVar2 != '\0') && (iVar16 = (**(code **)(*in_ECX + 0x620))(), iVar16 == 5)) &&
        (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) &&
       (iVar16 = (**(code **)(*in_ECX + 0x64c))(4), 0 < iVar16)) {
      (**(code **)(*in_ECX + 0x67c))(4);
      iVar16 = FUN_0054ff60(0,in_ECX);
      iVar15 = (**(code **)(*in_ECX + 0x64c))(4);
      if (iVar16 <= iVar15) {
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
        uVar38 = 4;
        piVar4 = in_ECX;
        uVar34 = (**(code **)(*in_ECX + 0x64c))(4);
        iVar16 = FUN_004caa20(2,uVar34,uVar38,piVar4,uVar8);
        (**(code **)(*in_ECX + 0x2b8))(0x4e34,iVar16 + -100,0,0,0,1,1,4);
      }
    }
    break;
  case (wchar_t *)0x1e:
    uVar26 = 0;
    uVar24 = 0;
    uVar20 = 0xffffffff;
    pwVar35 = u_UPPER_SLASH_02_00d7be88;
    (**(code **)(*in_ECX + 0x10c))(u_UPPER_SLASH_02_00d7be88,0xffffffff,0,0);
    uVar38 = 0;
    uVar34 = 0;
    uVar8 = 0xffffffff;
    pwVar19 = u_SM_UPPERSLASH_ADD_00d7d7f4;
    (**(code **)(*in_ECX + 0x10c))(u_SM_UPPERSLASH_ADD_00d7d7f4,0xffffffff,0,0);
    *(undefined1 *)(in_ECX + 0xced) = 0;
    pfStack_1c = (float *)(**(code **)(*in_ECX + 0x67c))(0x2e);
    (**(code **)(*in_ECX + 0x64c))(0x2e);
    iVar16 = 0;
    iVar15 = 0;
    cVar2 = FUN_0049c090();
    if (cVar2 != '\0') {
      piStack_14 = (int *)(**(code **)(*in_ECX + 0x644))(0);
      if (piStack_14 == (int *)&DAT_00000004) {
        iVar16 = FUN_0054ff60(0,in_ECX);
        iVar15 = FUN_0054ff60(1,in_ECX);
      }
      else {
        piVar4 = (int *)(**(code **)(*in_ECX + 0xc0))();
        if (piStack_14 == piVar4) {
          iVar16 = FUN_0054ff60(2,in_ECX);
          iVar15 = FUN_0054ff60(0,in_ECX);
          iVar16 = iVar16 + iVar15;
          iVar15 = FUN_0054ff60(1,in_ECX);
          iVar5 = FUN_0054ff60(3,0);
          iVar15 = iVar15 + iVar5;
        }
      }
    }
    (**(code **)(*in_ECX + 0x488))(0,iVar16,iVar16,0,iVar15,1);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar27 = (**(code **)(iVar16 + 0xc0))(4,0);
    (**(code **)(iVar16 + 0x49c))(uVar27);
    iVar16 = *in_ECX;
    uVar27 = (**(code **)(iVar16 + 0x38c))(0x10);
    (**(code **)(iVar16 + 0xf0))(uVar27);
    iVar16 = *in_ECX;
    uVar27 = FUN_005270f0(0x13);
    (**(code **)(iVar16 + 0x198))(uVar27);
    (**(code **)(*in_ECX + 0x1d0))(0xc);
    uVar30 = 0xc;
    piVar4 = in_ECX;
    uVar27 = (**(code **)(*in_ECX + 0x64c))(0xc);
    uVar29 = 2;
    uVar28 = 0xc;
    (**(code **)(*in_ECX + 0x67c))(0xc,2,uVar27);
    iVar16 = FUN_004caa20(uVar28,uVar29,uVar27,uVar30,piVar4);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
    uVar27 = (**(code **)(*in_ECX + 0x64c))(0xc);
    (**(code **)(*in_ECX + 0x67c))(0xc,3,uVar27);
    piStack_14 = (int *)FUN_00550080(pwVar19,uVar8,uVar34,uVar38,pwVar35,uVar20,uVar24,uVar26);
    FUN_00404560(&piStack_14);
    break;
  case (wchar_t *)0x1f:
    in_ECX[0xae8] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x67c))(0x39);
    piStack_28 = (int *)(**(code **)(*in_ECX + 0x64c))(0x39);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    if (in_ECX[0xae9] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x1e;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_ShockWaveArea_C_00d7ef28;
        uVar8 = FUN_004334b0(u_Effect_Animation_ShockWaveArea_C_00d7ef28,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xae9] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x1f;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_ShockWaveArea_S_00d7eed0;
        uVar8 = FUN_004334b0(u_Effect_Animation_ShockWaveArea_S_00d7eed0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xaea] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x20;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_ShockWaveArea_A_00d7ee80;
        uVar8 = FUN_004334b0(u_Effect_Animation_ShockWaveArea_A_00d7ee80,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xaeb] = iVar16;
    }
    if (in_ECX[0xae8] == 0) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0xc);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      pwVar19 = (wchar_t *)FUN_00468430(in_ECX,piStack_28);
      piStack_14 = (int *)((float)*(int *)(in_ECX[0x41] + 0x90) / (float)(int)pwVar19);
      pwStack_20 = pwVar19;
      (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,piStack_14,piStack_14);
      iVar16 = *in_ECX;
      (**(code **)(iVar16 + 0x344))(3,0);
      iVar15 = FUN_004ba260();
      (**(code **)(iVar16 + 0x554))(((int)pwVar19 * 1000) / iVar15);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xae9],0,0,0,0,1,0,0,1);
      (**(code **)(*in_ECX + 0x10c))(u_SM_JAKYEOL_WAVE_01_00d7ee54,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_JAKYEOL_FLASH_00d7ee38,0xffffffff,0,0);
    }
    else if (in_ECX[0xae8] == 1) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0xd);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0xf);
      (**(code **)(iVar16 + 0x198))(uVar8);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      piVar4 = piStack_28;
      iVar16 = FUN_004caa20(0,piStack_28,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      iVar16 = FUN_00550080(4,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      piStack_14 = (int *)(iVar16 / 2);
      FUN_00404560(&piStack_14);
      piStack_14 = (int *)FUN_00402060();
      fVar12 = (float)(int)piStack_14 * _DAT_00d5dd98;
      piStack_14 = (int *)FUN_00402060(fVar12);
      FUN_00a25900((float)(int)piStack_14 * _DAT_00d5dd98,fVar12);
      uVar8 = FUN_008ac050(u_swa_area_offset_00d7a398);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xaea],uVar8,0,0,0,1,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xaeb],uVar8,0,0,1,1,0,0,1);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
      (**(code **)(iVar16 + 0x10c))(uVar8);
      (**(code **)(*in_ECX + 0x10c))(u_JAKYEOL_SWING_00d7ee1c,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_JAKYEOL_LAND_00d7ee00,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_SM_JAKYEOL_WAVE_02_00d7edd8,0xffffffff,0,0);
      in_ECX[0xaee] = -1;
    }
    break;
  case (wchar_t *)0x20:
    in_ECX[0xb12] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    FUN_004ba0c0(2,0);
    (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0xe);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    pwStack_20 = (wchar_t *)(**(code **)(*in_ECX + 0x67c))(0x3a);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x64c))(0x3a);
    if (in_ECX[0xb15] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x2d;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_VaneSlash_Upper_00d7ea80;
        uVar8 = FUN_004334b0(u_Effect_Animation_VaneSlash_Upper_00d7ea80,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb15] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x2e;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_VaneSlash_Dust__00d7ea38;
        uVar8 = FUN_004334b0(u_Effect_Animation_VaneSlash_Dust__00d7ea38,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb16] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x2f;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_VaneSlash_Smash_00d7e9e8;
        uVar8 = FUN_004334b0(u_Effect_Animation_VaneSlash_Smash_00d7e9e8,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb17] = iVar16;
    }
    if (in_ECX[0xb12] == 0) {
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x10);
      (**(code **)(iVar16 + 0x198))(uVar8);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb15],0,0,0,0,1,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xb16],0,0,0,0,1,0,0,1);
      pwStack_34 = (wchar_t *)0x3f666666;
      pwStack_38 = (wchar_t *)0x3fa66666;
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 3) {
        pwStack_34 = (wchar_t *)0x3f800000;
        pwStack_38 = (wchar_t *)0x3fb33333;
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 0) {
          pwStack_34 = (wchar_t *)0x3f4ccccd;
          pwStack_38 = (wchar_t *)0x3f8ccccd;
        }
      }
      FUN_00a25900(pwStack_34,pwStack_34);
      iVar15 = 0;
      iVar16 = FUN_00493660();
      if (0 < iVar16) {
        do {
          ppwVar10 = apwStack_50 + 7;
          if (2 < iVar15) {
            ppwVar10 = apwStack_50 + 6;
          }
          FUN_00a25c90(iVar15);
          FUN_00455c30(ppwVar10);
          if (iVar15 < 3) {
            pwStack_20 = pwStack_34;
          }
          else {
            pwStack_20 = (wchar_t *)((float)pwStack_38 * _DAT_00cc078c);
          }
          ppwVar10 = &pwStack_20;
          FUN_00a25c90(iVar15);
          FUN_00455c30(ppwVar10);
          iVar15 = iVar15 + 1;
          iVar16 = FUN_00493660();
        } while (iVar15 < iVar16);
      }
      (**(code **)(*in_ECX + 0x10c))(u_SM_YEOLPA_UP_00d7e9c8,0xffffffff,0,0);
      *(undefined1 *)(in_ECX + 0xaac) = 0;
    }
    else if (in_ECX[0xb12] == 1) {
      uVar20 = 0;
      (**(code **)(*in_ECX + 0x2d8))(0);
      (**(code **)(*in_ECX + 0x2d0))(0);
      puVar13 = (undefined4 *)FUN_006db690(1);
      uVar38 = 0;
      ppuVar37 = &PTR_PTR_00f5526c;
      ppuVar36 = &PTR_PTR_00f40910;
      uVar34 = 0;
      uVar8 = FUN_0050b8b0(*puVar13);
      piVar4 = (int *)FUN_00c00d0b(uVar8,uVar34,ppuVar36,ppuVar37,uVar38);
      in_ECX[0xca6] = (int)piVar4;
      if (piVar4 != (int *)0x0) {
        iVar16 = (**(code **)(*piVar4 + 0x94))();
        in_ECX[0xca7] = iVar16;
        iVar16 = (**(code **)(*(int *)in_ECX[0xca6] + 0x98))();
        in_ECX[0xca8] = iVar16;
        iVar16 = (**(code **)(*(int *)in_ECX[0xca6] + 0x9c))();
        in_ECX[0xca9] = iVar16;
      }
      if (in_ECX[0xca6] != 0) {
        if (in_ECX[0xb14] == 0) {
          pvStack_18 = (void *)FUN_00403c50(0xa8);
          local_8._0_1_ = 0x30;
          if (pvStack_18 == (void *)0x0) {
            iVar16 = 0;
          }
          else {
            iVar16 = FUN_0073df00(in_ECX);
          }
          local_8._0_1_ = 0;
          in_ECX[0xb14] = iVar16;
        }
        (**(code **)(*(int *)in_ECX[0xb14] + 0x48))(in_ECX[0xca6]);
      }
      puVar13 = (undefined4 *)FUN_006db690(2);
      FUN_00a28340(*puVar13);
      FUN_00a28110(0);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
      puVar13 = (undefined4 *)FUN_006db690(2);
      FUN_00a28340(*puVar13);
      puVar13 = (undefined4 *)FUN_006db690(2);
      FUN_00a28340(*puVar13);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x11);
      (**(code **)(iVar16 + 0x198))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(0,piStack_14,in_ECX,uVar8,uVar20);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      if ((in_ECX[0xca6] != 0) && (cVar2 = FUN_0049c090(), cVar2 != '\0')) {
        puVar13 = (undefined4 *)FUN_006db690(4);
        puVar11 = (undefined4 *)FUN_006db690(3);
        uVar8 = *puVar13;
        uVar34 = (**(code **)(*in_ECX + 0x98))(uVar8);
        FUN_00467330(*puVar11,uVar34,uVar8);
        local_8._0_1_ = 0x31;
        FUN_004eabf0();
        local_8._0_1_ = 0;
        FUN_00404300();
      }
      FUN_00721b20(1,0,1);
      *(undefined1 *)(in_ECX + 0xb13) = 0;
    }
    break;
  case (wchar_t *)0x21:
    in_ECX[0xaef] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x67c))(0x3c);
    (**(code **)(*in_ECX + 0x64c))(0x3c);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    FUN_004ba0c0(2,0);
    (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
    iVar16 = in_ECX[0xaef];
    if (iVar16 == 0) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x12);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      if (((int *)in_ECX[0xc1d] != (int *)0x0) &&
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc1d] + 0x60))(), cVar2 != '\0')) {
        FUN_005a2dd0(2);
      }
      iVar16 = FUN_004921a0(in_ECX);
      iVar15 = FUN_004921d0(in_ECX,0x3f800000);
      if ((((-1 < iVar16) && (iVar16 < 0x280)) && (-1 < iVar15)) && (iVar15 < 0x1e0)) {
        if ((int *)in_ECX[0xaff] != (int *)0x0) {
          (**(code **)(*(int *)in_ECX[0xaff] + 0x60))(0);
        }
        pvStack_18 = (void *)FUN_00403c50(0x210);
        local_8._0_1_ = 0x21;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          iVar16 = FUN_0073eb30();
        }
        in_ECX[0xaff] = iVar16;
        local_8._0_1_ = 0;
        FUN_0050dd70(in_ECX,2,0,iVar16,0,0,0);
      }
      pwVar19 = u_KEIGA_ATK_00d7edc4;
      goto LAB_0073a15e;
    }
    if (iVar16 == 1) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x13);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        (**(code **)(*in_ECX + 0x2b8))(0x4e3a,0,0,0,0,1,0,4,0,0,0,0,0);
      }
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x22;
      if (pvStack_18 == (void *)0x0) {
        uVar8 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_GhostStepSlash__00d7ed70;
        uVar8 = FUN_004334b0(u_Effect_Animation_GhostStepSlash__00d7ed70,1);
        uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      pvStack_18 = (void *)FUN_00403c50(0x1fc);
      local_8._0_1_ = 0x23;
      if (pvStack_18 == (void *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        piVar4 = (int *)FUN_004abd20(uVar8,1);
      }
      local_8._0_1_ = 0;
      FUN_0050dd70(in_ECX,2,0,piVar4,in_ECX,0,0);
      iVar16 = *piVar4;
      uVar8 = (**(code **)(*in_ECX + 0xc0))();
      (**(code **)(iVar16 + 0xbc))(uVar8);
      iVar16 = *piVar4;
      uVar8 = (**(code **)(*in_ECX + 0x9c))();
      uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
      (**(code **)(iVar16 + 0x88))(uVar8);
      iVar16 = (**(code **)(*in_ECX + 0xc0))();
      uVar34 = 0;
      uVar8 = 0x3c;
      if (iVar16 == 0) {
        (**(code **)(*in_ECX + 0x67c))();
        iVar15 = FUN_0054ff60(uVar8,uVar34);
        iVar16 = (**(code **)(*in_ECX + 0x94))();
        iVar16 = iVar16 - iVar15;
      }
      else {
        (**(code **)(*in_ECX + 0x67c))(0x3c,0);
        iVar16 = FUN_0054ff60(uVar8,uVar34);
        iVar15 = (**(code **)(*in_ECX + 0x94))();
        iVar16 = iVar16 + iVar15;
      }
      uVar8 = (**(code **)(*in_ECX + 0x94))(iVar16);
      iVar16 = FUN_004e7f10(0,uVar8,iVar16);
      iVar15 = (**(code **)(*in_ECX + 0x94))();
      in_ECX[0xaf0] = iVar16 - iVar15;
      (**(code **)(*in_ECX + 0x84))(0,iVar16);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x15);
      (**(code **)(iVar16 + 0x198))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      uVar24 = 0x3c;
      piVar4 = in_ECX;
      uVar34 = (**(code **)(*in_ECX + 0x64c))(0x3c);
      uVar20 = 0;
      uVar38 = 0x3c;
      (**(code **)(*in_ECX + 0x67c))(0x3c,0,uVar34);
      iVar16 = FUN_004caa20(uVar38,uVar20,uVar34,uVar24,piVar4);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      if (in_ECX[0xafe] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8,uVar8);
        local_8._0_1_ = 0x24;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_GhostStepSlash__00d7ed18;
          uVar8 = FUN_004334b0(u_Effect_Animation_GhostStepSlash__00d7ed18,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xafe] = iVar16;
      }
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xafe],0,0,0,0,1,0,0,1);
      if (((int *)in_ECX[0xc1d] != (int *)0x0) &&
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc1d] + 0x60))(), cVar2 != '\0')) {
        FUN_005a2dd0(3);
      }
    }
    else if (iVar16 == 2) {
      param_4 = (int *)((uint)param_4 & 0xffffff00);
      in_ECX[0xafb] = -1;
      FUN_0044d750(&local_24);
      pfStack_1c = (float *)in_ECX[0xaf3];
      cVar2 = FUN_00564560(&pfStack_1c);
      piVar4 = local_24;
      while (cVar2 != '\0') {
        piVar4 = (int *)piVar4[2];
        piStack_28 = piVar4;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x25;
        if (pvStack_18 == (void *)0x0) {
          uVar8 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_GhostStepSlash__00d7ecc0;
          uVar8 = FUN_004334b0(u_Effect_Animation_GhostStepSlash__00d7ecc0,1);
          uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        if (in_ECX[0xafb] == -1) {
          iVar16 = FUN_00a24ce0(3);
          in_ECX[0xafb] = iVar16;
        }
        pvStack_18 = (void *)FUN_00403c50(0x1fc);
        local_8._0_1_ = 0x26;
        if (pvStack_18 == (void *)0x0) {
          pfVar9 = (float *)0x0;
        }
        else {
          pfVar9 = (float *)FUN_004abd20(uVar8,1);
        }
        local_8._0_1_ = 0;
        pfStack_1c = pfVar9;
        FUN_0050dd70(in_ECX,2,0,pfVar9,piVar4,0,0);
        fVar12 = *pfVar9;
        uVar8 = (**(code **)(*in_ECX + 0xc0))();
        (**(code **)((int)fVar12 + 0xbc))(uVar8);
        piVar4 = piStack_28;
        fVar12 = *pfVar9;
        piStack_14 = (int *)(**(code **)(*piStack_28 + 0xe4))();
        iVar16 = (**(code **)(*piVar4 + 0x9c))();
        uVar8 = (**(code **)(*piVar4 + 0x98))((undefined1 *)((int)piStack_14 + iVar16));
        uVar8 = (**(code **)(*piVar4 + 0x94))(uVar8);
        (**(code **)((int)fVar12 + 0x88))(uVar8);
        pfStack_1c = (float *)in_ECX[0xaf3];
        piVar4 = (int *)*local_24;
        local_24 = piVar4;
        cVar2 = FUN_00564560(&pfStack_1c);
      }
      iVar16 = FUN_008ac050(u_gss_release_delay_00d7ec9c);
      in_ECX[0xafc] = iVar16 + in_ECX[0xafb];
      iVar16 = FUN_008ac050(u_gss_after_delay_00d7ec7c);
      in_ECX[0xafd] = iVar16 + in_ECX[0xafc];
      if (in_ECX[0xaff] != 0) {
        FUN_0071b280(2,in_ECX[0xafb]);
      }
    }
    break;
  case (wchar_t *)0x22:
    in_ECX[0xb00] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    FUN_004ba0c0(2,0);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x67c))(0x3e);
    pwStack_20 = (wchar_t *)(**(code **)(*in_ECX + 0x64c))(0x3e);
    if (in_ECX[0xb0b] == 0) {
      piStack_2c = in_ECX + 0xb0d;
      local_24 = (int *)0x1;
      piStack_28 = (int *)0x2;
      uVar3 = (undefined1)local_8;
      do {
        local_8._0_1_ = uVar3;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x27;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_StandAloneWave__00d7ec20,local_24,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar16 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        local_8._0_1_ = 0;
        piStack_2c[-2] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x28;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_StandAloneWave__00d7ebc8,local_24,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar16 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        local_8._0_1_ = 0;
        *piStack_2c = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x29;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_StandAloneWave__00d7eb70,local_24,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar16 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        piStack_2c[2] = iVar16;
        piStack_2c = piStack_2c + 1;
        local_24 = (int *)((int)local_24 + 1);
        piStack_28 = (int *)((int)piStack_28 + -1);
        local_8._0_1_ = 0;
        uVar3 = (undefined1)local_8;
        local_8._0_1_ = 0;
      } while (piStack_28 != (int *)0x0);
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x2a;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_StandAloneWave__00d7eb18;
        uVar8 = FUN_004334b0(u_Effect_Animation_StandAloneWave__00d7eb18,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb11] = iVar16;
      FUN_004e26f0(3);
    }
    if (in_ECX[0xb00] == 0) {
      (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x14);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      piStack_14 = (int *)0x0;
      FUN_00404560(&piStack_14);
      if (in_ECX[0xb09] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0xcc);
        local_8._0_1_ = 0x2b;
        if (pvStack_18 == (void *)0x0) {
          piVar4 = (int *)0x0;
        }
        else {
          piVar4 = (int *)FUN_004e5390(0,1);
        }
        in_ECX[0xb09] = (int)piVar4;
        local_8._0_1_ = 0;
        iVar16 = (**(code **)(*piVar4 + 0x50))();
        *(undefined1 *)(iVar16 + 0x48) = 0;
      }
      if (in_ECX[0xb0a] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0xb0);
        local_8._0_1_ = 0x2c;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          iVar16 = FUN_0065cd50();
        }
        in_ECX[0xb0a] = iVar16;
        local_8._0_1_ = 0;
        *(undefined1 *)(iVar16 + 0x4c) = 0;
      }
      (**(code **)(*(int *)in_ECX[0xb09] + 0x8c))();
      iVar16 = *(int *)in_ECX[0xb09];
      piStack_14 = (int *)FUN_00550080(3,pwStack_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      (**(code **)(iVar16 + 0x88))(5,0,(float)(int)piStack_14);
      (**(code **)(*(int *)in_ECX[0xb09] + 0x48))();
      uVar28 = 0xffffffff;
      uVar8 = FUN_0054ff60(0xd,in_ECX);
      uVar27 = 1;
      uVar26 = 0;
      uVar24 = 0;
      piStack_14 = (int *)FUN_0054ff60(0xc,in_ECX);
      fVar12 = (float)(int)piStack_14;
      piStack_14 = (int *)FUN_0054ff60(0xb,in_ECX);
      fVar21 = (float)(int)piStack_14;
      uVar20 = 0;
      uVar38 = 0;
      uVar34 = 0;
      piVar4 = in_ECX;
      iVar16 = FUN_0054ff60(10,in_ECX);
      FUN_0058c160(iVar16 / 2,piVar4,uVar34,uVar38,uVar20,fVar21,fVar12,uVar24,uVar26,uVar27,uVar8,
                   uVar28);
      (**(code **)(*(int *)in_ECX[0xb0a] + 0x48))();
      (**(code **)(*in_ECX + 0x10c))(u_SM_MUSSANG_START_00d7eaf0,0xffffffff,0,0);
      FUN_00a51f50(0xfa,0xffffffff,1,1);
      FUN_00a51f70();
      piStack_14 = (int *)FUN_0054ff60(10,in_ECX);
      piStack_28 = (int *)((float)(int)piStack_14 * _DAT_00d5af20);
      FUN_00a25900(piStack_28,(float)piStack_28 * _DAT_00d7eaec);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb11],0,0,0,1,0,0,0,1);
    }
    else if (in_ECX[0xb00] == 1) {
      uVar8 = 0x3f800000;
      (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
      puVar13 = (undefined4 *)FUN_006db690(1);
      piStack_14 = (int *)*puVar13;
      FUN_00404560(&piStack_14);
      iVar15 = FUN_00402060();
      iVar16 = *in_ECX;
      if (iVar15 == 0) {
        uVar34 = (**(code **)(iVar16 + 0x38c))(0x15);
        (**(code **)(iVar16 + 0xf0))(uVar34);
        (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb0d],0,0xffffff97,0,0,1,0,0,1);
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 3) {
          pfStack_1c = (float *)0x3f800000;
        }
        else {
          iVar16 = (**(code **)(*in_ECX + 0x620))();
          pfStack_1c = (float *)0x3f4ccccd;
          if (iVar16 != 0) {
            pfStack_1c = (float *)0x3f666666;
          }
        }
        FUN_00a25900(pfStack_1c,pfStack_1c);
        pwVar19 = u_SM_MUSSANG_WEAK_00d7eacc;
      }
      else {
        uVar34 = (**(code **)(iVar16 + 0x38c))(0x16);
        (**(code **)(iVar16 + 0xf0))(uVar34);
        (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xb0f],0,0,0,0,1,0,0,1);
        (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb10],0,0,0,0,1,0,0,1);
        (**(code **)(*in_ECX + 0xf8))(3,in_ECX[0xb0e],0,0,0,0,1,0,0,1);
        pwVar19 = u_MUSSANG_ATK_02_00d7bea8;
      }
      (**(code **)(*in_ECX + 0x10c))(pwVar19,0xffffffff,0,0);
      iVar16 = *in_ECX;
      uVar34 = FUN_005270f0(0x16);
      (**(code **)(iVar16 + 0x198))(uVar34);
      uVar34 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(0,pwStack_20,in_ECX,uVar34,uVar8);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      *(undefined1 *)(in_ECX + 0xaac) = 0;
      *(undefined1 *)(in_ECX + 0xb08) = 0;
    }
    break;
  case (wchar_t *)0x23:
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    FUN_004ba0c0(2,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x19);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(0x18);
    (**(code **)(iVar16 + 0x198))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
    uVar24 = 0x40;
    piVar4 = in_ECX;
    uVar34 = (**(code **)(*in_ECX + 0x64c))(0x40);
    uVar20 = 0;
    uVar38 = 0x40;
    (**(code **)(*in_ECX + 0x67c))(0x40,0,uVar34);
    iVar16 = FUN_004caa20(uVar38,uVar20,uVar34,uVar24,piVar4);
    iVar15 = FUN_0073d6b0(uVar8);
    piStack_14 = (int *)((iVar16 * iVar15) / 100 + -100);
    FUN_00404560(&piStack_14);
    in_ECX[0xb18] = 0;
    if (in_ECX[0xb19] == 0) {
      pwStack_20 = (wchar_t *)(in_ECX + 0xb19);
      iVar16 = 0;
      uVar3 = (undefined1)local_8;
      do {
        local_8._0_1_ = uVar3;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x32;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_GoreCross_Slash_00d7e978,iVar16 + 1,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        *(int *)pwStack_20 = iVar15;
        iVar16 = iVar16 + 1;
        pwStack_20 = pwStack_20 + 2;
        local_8._0_1_ = 0;
        uVar3 = (undefined1)local_8;
        local_8._0_1_ = 0;
      } while (iVar16 < 2);
    }
    (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb19],0,0,0,0,1,0,0,1);
    (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xb1a],0,0,0,0,1,0,0,1);
    (**(code **)(*in_ECX + 0x10c))(u_R_TSLASH_00d7be38,0xffffffff,0,0);
    (**(code **)(*in_ECX + 0x10c))(u_SM_GORECROSS_00d7e95c,0xffffffff,0,0);
    break;
  case (wchar_t *)0x24:
    in_ECX[0xb29] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x67c))(0x41);
    piStack_28 = (int *)(**(code **)(*in_ECX + 0x64c))(0x41);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    if (in_ECX[0xb29] == 0) {
      FUN_004ba0c0(2,0);
      (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x1a);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      in_ECX[0xb2c] = 0;
      iVar16 = FUN_0054ff60(0,in_ECX);
      in_ECX[0xb2a] = iVar16;
      iVar16 = FUN_0054ff60(1,in_ECX);
      in_ECX[0xb2b] = iVar16;
    }
    else if (in_ECX[0xb29] == 1) {
      piVar4 = (int *)FUN_006db690(1);
      in_ECX[0xb2c] = *piVar4;
      FUN_004ba0c0(0,0);
      iVar16 = in_ECX[0xb2c];
      uVar8 = 100;
      piStack_14 = (int *)FUN_0054ff60(7,in_ECX);
      fVar12 = (float)(int)piStack_14 * _DAT_00cc10ac;
      piStack_14 = (int *)FUN_0054ff60(6,in_ECX);
      fVar18 = (float10)FUN_00b099b0((float)(int)piStack_14 * _DAT_00cc10ac,fVar12,iVar16,uVar8);
      piStack_14 = (int *)(float)fVar18;
      (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,piStack_14,piStack_14);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x1b);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      iVar16 = (**(code **)(*in_ECX + 0x94))();
      uVar38 = 100;
      in_ECX[0xb2d] = iVar16;
      iVar16 = in_ECX[0xb2c];
      uVar8 = FUN_0054ff60(3,in_ECX);
      uVar34 = FUN_0054ff60(2,in_ECX);
      iVar16 = FUN_00473f20(uVar34,uVar8,iVar16,uVar38);
      uVar38 = 100;
      in_ECX[0xb2e] = iVar16;
      iVar16 = in_ECX[0xb2c];
      uVar8 = FUN_0054ff60(5,in_ECX);
      uVar34 = FUN_0054ff60(4,in_ECX);
      iVar16 = FUN_00473f20(uVar34,uVar8,iVar16,uVar38);
      in_ECX[0xb2f] = iVar16;
      uVar38 = 100;
      *(undefined1 *)(in_ECX + 0xb30) = 0;
      iVar16 = in_ECX[0xb2c];
      uVar8 = FUN_0054ff60(9,in_ECX);
      uVar34 = FUN_0054ff60(8,in_ECX);
      iVar16 = FUN_00473f20(uVar34,uVar8,iVar16,uVar38);
      pwStack_20 = (wchar_t *)FUN_00a24ce0(3);
      iVar15 = FUN_00a24ce0(5);
      FUN_00a51f50((iVar15 - (int)pwStack_20) / iVar16,iVar16 + -1,0,0);
      FUN_00a51f80(pwStack_20);
      piStack_14 = (int *)*in_ECX;
      uVar8 = FUN_005270f0(0x1a - (uint)(iVar16 != 1));
      (*(code *)piStack_14[0x66])(uVar8);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(0,piStack_28,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      uVar8 = (**(code **)(*in_ECX + 0x694))(2);
      FUN_0040eb40(uVar8);
      if (in_ECX[0xb31] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x3a;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_HopSmash_Sword__00d7e5f0;
          uVar8 = FUN_004334b0(u_Effect_Animation_HopSmash_Sword__00d7e5f0,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xb31] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x3b;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_HopSmash_Smash__00d7e5a8;
          uVar8 = FUN_004334b0(u_Effect_Animation_HopSmash_Smash__00d7e5a8,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xb32] = iVar16;
      }
      piStack_28 = (int *)0x2;
      do {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        pwStack_20 = (wchar_t *)0x3f99999a;
        if (iVar16 != 3) {
          pwStack_20 = (wchar_t *)0x3f800000;
        }
        FUN_00a25900(pwStack_20,0x3f800000);
        piStack_28 = (int *)((int)piStack_28 + -1);
      } while (piStack_28 != (int *)0x0);
      fVar18 = (float10)FUN_00b099b0(0x3f800000,0x3fe00000,in_ECX[0xb2c],100);
      piStack_14 = (int *)(float)fVar18;
      ppiVar22 = &piStack_14;
      FUN_00a25c90(1);
      FUN_00455c30(ppiVar22);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb31],0,0,0,0,1,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xb32],0,0,0,0,1,0,0,1);
      *(undefined1 *)(in_ECX + 0xaac) = 0;
    }
    break;
  case (wchar_t *)0x25:
    piVar4 = (int *)FUN_006db690(0);
    in_ECX[0xcb9] = *piVar4;
    (**(code **)(*in_ECX + 0x67c))(0x44);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x64c))(0x44);
    iVar16 = in_ECX[0xcb9];
    if (iVar16 == 0) {
      (**(code **)(*in_ECX + 0x10c))(u_SM_CHARGE_CRASH_00d7dc78,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_CCRASH_MOVING_00d7dc5c,0xffffffff,0,0);
      *(undefined1 *)((int)in_ECX + 0x331e) = 0;
      *(undefined1 *)(in_ECX + 0xcc7) = 0;
      *(undefined1 *)((int)in_ECX + 0x331d) = 0;
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x2b);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x2a);
      (**(code **)(iVar16 + 0x198))(uVar8);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(0,piStack_14,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      uVar8 = FUN_0054ff60(0,0);
      uVar34 = FUN_0054ff60(1,0);
      (**(code **)(*in_ECX + 0x488))(0,uVar8,uVar8,0,uVar34,1);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
      (**(code **)(iVar16 + 0x49c))(uVar8);
      uVar20 = 0;
      uVar38 = 0;
      uVar34 = 0xffffffff;
      uVar8 = FUN_0054ff60(2,0);
      FUN_00a51f50(uVar8,uVar34,uVar38,uVar20);
      FUN_00a51f80(0);
      if (in_ECX[0xcba] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x55;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_ChargeCrash_das_00d7dc10;
          uVar8 = FUN_004334b0(u_Effect_Animation_ChargeCrash_das_00d7dc10,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcba] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x56;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_ChargeCrash_up__00d7dbb8;
          uVar8 = FUN_004334b0(u_Effect_Animation_ChargeCrash_up__00d7dbb8,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcbb] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x57;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_ChargeCrash_dow_00d7db60;
          uVar8 = FUN_004334b0(u_Effect_Animation_ChargeCrash_dow_00d7db60,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcbd] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x58;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_ChargeCrash_cha_00d7db10;
          uVar8 = FUN_004334b0(u_Effect_Animation_ChargeCrash_cha_00d7db10,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcbc] = iVar16;
      }
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 3) {
        pfStack_1c = (float *)0x3fa66666;
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        pfStack_1c = (float *)0x3f99999a;
        if (iVar16 != 0) {
          pfStack_1c = (float *)0x3fa00000;
        }
      }
      FUN_00a25900(pfStack_1c,pfStack_1c);
      if (in_ECX[0xcbe] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x59;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_ChargeCrash_dus_00d7dab8;
          uVar8 = FUN_004334b0(u_Effect_Animation_ChargeCrash_dus_00d7dab8,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcbe] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x5a;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_ChargeCrash_dus_00d7da58;
          uVar8 = FUN_004334b0(u_Effect_Animation_ChargeCrash_dus_00d7da58,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcbf] = iVar16;
      }
      *(undefined1 *)((int)in_ECX + 0x331f) = 1;
      *(undefined1 *)(in_ECX + 0xcc8) = 0;
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xcba],0,0,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xcbe],0,0,0,0,0,0,0,1);
    }
    else if (iVar16 == 1) {
      uVar34 = 0;
      (**(code **)(*in_ECX + 0x10c))(u_SM_CHARGE_CRASH_UP_00d7da30,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x2c);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x2b);
      (**(code **)(iVar16 + 0x198))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(1,piStack_14,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
    }
    else if (iVar16 == 2) {
      (**(code **)(*in_ECX + 0x10c))(u_CCRASH_GET_00d7da18,0xffffffff,0,0);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x2d);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      FUN_004ba360(0);
      FUN_00a28110(1);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
      iVar16 = FUN_0054ff60(3,in_ECX);
      in_ECX[0xcc6] = iVar16;
      iVar15 = FUN_00493660();
      piStack_14 = (int *)(iVar16 / iVar15);
      iVar15 = 0;
      iVar16 = FUN_00493660();
      if (0 < iVar16) {
        do {
          ppiVar22 = &piStack_14;
          FUN_00a25c90(iVar15);
          FUN_00455c10(ppiVar22);
          iVar15 = iVar15 + 1;
          iVar16 = FUN_00493660();
        } while (iVar15 < iVar16);
      }
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xcbc],0xffffffc9,0xffffff7e,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0x344))(3);
      iVar16 = FUN_004b55a0();
      in_ECX[0xcc6] = (in_ECX[0xcc6] * 1000) / iVar16;
    }
    else if (iVar16 == 3) {
      piVar4 = (int *)FUN_006db690(1);
      in_ECX[0xcc5] = *piVar4;
      (**(code **)(*in_ECX + 0x10c))(u_SM_CHARGE_CRASH_DOWN_00d7d9ec,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_JAKYEOL_SWING_00d7ee1c,0xffffffff,0,0);
      param_4 = (int *)((uint)param_4 & 0xffffff00);
      FUN_004ba360(3);
      FUN_00a28110(0);
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xcbc]);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x2c);
      (**(code **)(iVar16 + 0x198))(uVar8);
      uVar8 = 0;
      uVar34 = 0;
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 3) {
        uVar27 = 0xc;
        uVar26 = 0xffffffff;
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
        uVar24 = 0xe;
        piVar4 = in_ECX;
        uVar34 = (**(code **)(*in_ECX + 0x64c))(0xe);
        uVar20 = 8;
        uVar38 = 0xe;
        (**(code **)(*in_ECX + 0x67c))(0xe,8,uVar34);
        uVar8 = FUN_00550080(uVar38,uVar20,uVar34,uVar24,piVar4,uVar8,uVar26,uVar27);
        uVar29 = 0xc;
        uVar28 = 0xffffffff;
        uVar34 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
        uVar26 = 0xe;
        piVar7 = in_ECX;
        uVar38 = (**(code **)(*in_ECX + 0x64c))(0xe);
        uVar20 = 9;
        piVar4 = (int *)&DAT_0000000e;
        (**(code **)(*in_ECX + 0x67c))(0xe,9,uVar38);
LAB_00737fb5:
        uVar34 = FUN_00550080(piVar4,uVar20,uVar38,uVar26,piVar7,uVar34,uVar28,uVar29);
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 2) {
          uVar29 = 0;
          uVar28 = 0;
          uVar27 = 0xc;
          uVar26 = 0xffffffff;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          uVar24 = 0xf;
          piVar4 = in_ECX;
          uVar34 = (**(code **)(*in_ECX + 0x64c))(0xf);
          uVar20 = 5;
          uVar38 = 0xf;
          (**(code **)(*in_ECX + 0x67c))(0xf,5,uVar34);
          uVar8 = FUN_00550080(uVar38,uVar20,uVar34,uVar24,piVar4,uVar8,uVar26,uVar27);
          uVar34 = 0;
          piVar7 = (int *)0x0;
          uVar26 = 0xc;
          uVar38 = 0xffffffff;
          uVar20 = (**(code **)(*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          piVar4 = in_ECX;
          uVar24 = (**(code **)(*in_ECX + 0x64c))(0xf);
          (**(code **)(*in_ECX + 0x67c))(0xf,6,uVar24);
          goto LAB_00737fb5;
        }
      }
      iVar16 = FUN_00473f20(uVar8,uVar34,in_ECX[0xcc5],in_ECX[0xcc6]);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      *(bool *)((int)in_ECX + 0x331e) = in_ECX[0xcc6] <= in_ECX[0xcc5];
    }
    break;
  case (wchar_t *)0x26:
    *(undefined1 *)((int)in_ECX + 0x33df) = 0;
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    *(undefined2 *)(in_ECX + 0xcf7) = 0;
    *(undefined1 *)((int)in_ECX + 0x33de) = 0;
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x2e);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    FUN_004ba360(0);
    FUN_00a28110(1);
    param_4 = (int *)((uint)param_4 & 0xffffff00);
    (**(code **)(*in_ECX + 0x67c))(2);
    (**(code **)(*in_ECX + 0x64c))(2);
    uVar8 = (**(code **)(*in_ECX + 0x64c))(2);
    iVar16 = FUN_00468430(in_ECX,uVar8);
    iVar15 = FUN_00b06f00();
    in_ECX[0xcf4] = iVar15 + iVar16;
    FUN_0071b900(iVar16);
    (**(code **)(*in_ECX + 0x554))(iVar16,1);
    if (in_ECX[0xcf5] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x60;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_ReflectGuard_ch_00d7d7a0;
        uVar8 = FUN_004334b0(u_Effect_Animation_ReflectGuard_ch_00d7d7a0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xcf5] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x61;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_ReflectGuard_sl_00d7d750;
        uVar8 = FUN_004334b0(u_Effect_Animation_ReflectGuard_sl_00d7d750,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xcf6] = iVar16;
    }
    *(undefined1 *)(in_ECX + 0xcf7) = 1;
    (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xcf5],0xffffffdd,0xffffffbc,0,0,0,0,0,1);
    break;
  case (wchar_t *)0x27:
    (**(code **)(*in_ECX + 0x67c))(0x48);
    piStack_28 = (int *)(**(code **)(*in_ECX + 0x64c))(0x48);
    in_ECX[0xb38] = **(int **)((int)param_2 + 4);
    pwStack_20 = *(wchar_t **)(*(int *)((int)param_2 + 4) + 4);
    cStack_2d = '\0';
    iVar16 = (**(code **)(*in_ECX + 0x620))();
    if (((iVar16 == 5) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) &&
       (iVar16 = (**(code **)(*in_ECX + 0x64c))(4), 0 < iVar16)) {
      uVar34 = 2;
      uVar8 = 4;
      (**(code **)(*in_ECX + 0x67c))(4,2);
      iVar16 = FUN_0054ff60(uVar8,uVar34);
      iVar15 = (**(code **)(*in_ECX + 0x64c))(4);
      if (iVar16 <= iVar15) {
        cStack_2d = '\x01';
      }
    }
    iVar16 = in_ECX[0xb38];
    if (iVar16 == 0) {
      (**(code **)(*in_ECX + 0xb8))(pwStack_20);
      (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
      (**(code **)(*in_ECX + 0x49c))(4,4,0);
      piStack_14 = (int *)FUN_0054ff60(0,in_ECX);
      FUN_00404560(&piStack_14);
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (((iVar16 == 0) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) &&
         (iVar16 = (**(code **)(*in_ECX + 0x64c))(0xc), 0 < iVar16)) {
        (**(code **)(*in_ECX + 0x67c))(0xc);
        iVar16 = FUN_0054ff60(0,in_ECX);
        iVar15 = (**(code **)(*in_ECX + 0x64c))(0xc);
        if (iVar16 <= iVar15) {
          piStack_14 = (int *)0x1;
          FUN_0040fc10(&piStack_14);
        }
      }
      if (local_24 == (int *)&DAT_00000027) {
        FUN_0043f540(0);
      }
      else {
        piStack_14 = (int *)0x0;
        FUN_00404560(&piStack_14);
        (**(code **)(**(int **)(DAT_0100316c + 0x15b0) + 0x10))(1);
      }
      iVar15 = FUN_00402060();
      iVar5 = FUN_00402060();
      iVar16 = *in_ECX;
      if (iVar5 < iVar15 + -1) {
        uVar8 = 0x2f;
      }
      else {
        uVar8 = 0x30;
      }
      uVar8 = (**(code **)(iVar16 + 0x38c))(uVar8);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      if (in_ECX[0xb3f] != 0) {
        FUN_0071b2e0(1);
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0) {
        pwVar19 = u_SM_MENGRYONG_START_00d7e57c;
      }
      else {
        iVar16 = FUN_00402060();
        iVar15 = FUN_00402060();
        if (iVar15 < iVar16 + -1) {
          (**(code **)(*in_ECX + 0x10c))(u_R_SM_MENGRYONG_00d7e55c,0xffffffff,0,0);
          goto code_r0x00736612;
        }
        pwVar19 = u_SM_MENGRYONG_FIN_00d7e538;
      }
code_r0x0073660a:
      (**(code **)(*in_ECX + 0x10c))(pwVar19,0xffffffff,0,0);
    }
    else if (iVar16 == 1) {
      iVar15 = *in_ECX;
      uVar8 = FUN_0054ff60(3,in_ECX);
      uVar20 = 0;
      uVar34 = FUN_0054ff60(2,in_ECX);
      uVar38 = FUN_0054ff60(2,in_ECX);
      (**(code **)(iVar15 + 0x488))(0,uVar38,uVar34,uVar20,uVar8,iVar16);
      iVar16 = *in_ECX;
      uVar24 = 1;
      uVar8 = FUN_0054ff60(5,in_ECX);
      uVar20 = 0;
      uVar34 = FUN_0054ff60(4,in_ECX);
      uVar38 = FUN_0054ff60(4,in_ECX);
      (**(code **)(iVar16 + 0x488))(1,uVar38,uVar34,uVar20,uVar8,uVar24);
      (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0xc0))(pwStack_20,0);
      (**(code **)(iVar16 + 0x49c))(uVar8);
      iVar16 = FUN_00402060();
      piStack_14 = (int *)(iVar16 + -1);
      iVar15 = FUN_00402060();
      iVar16 = *in_ECX;
      bVar17 = (int)piStack_14 <= iVar15;
      if (bVar17) {
        uVar8 = (**(code **)(iVar16 + 0x38c))(0x32);
        (**(code **)(iVar16 + 0xf0))(uVar8);
        iVar16 = *in_ECX;
        uVar8 = FUN_005270f0(0x2e);
        (**(code **)(iVar16 + 0x198))(uVar8);
        uVar34 = 0xc;
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      }
      else {
        uVar8 = (**(code **)(iVar16 + 0x38c))(0x31);
        (**(code **)(iVar16 + 0xf0))(uVar8);
        iVar16 = *in_ECX;
        uVar8 = FUN_005270f0(0x2d);
        (**(code **)(iVar16 + 0x198))(uVar8);
        uVar34 = 0xc;
        uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      }
      iVar16 = FUN_004caa20(bVar17,piStack_28,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
      (**(code **)(iVar16 + 0x10c))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x694))(2);
      FUN_0040eb40(uVar8);
      piStack_14 = (int *)FUN_0054ff60(1,in_ECX);
      FUN_00404560(&piStack_14);
      if (cStack_2d != '\0') {
        (**(code **)(*in_ECX + 0x67c))(4);
        piStack_2c = (int *)(**(code **)(*in_ECX + 0x64c))(4);
        iVar16 = 0;
        piVar4 = in_ECX + 0xaa;
        do {
          if (*piVar4 == 0x12) {
            in_ECX[iVar16 + 0xaa] = 6;
            iVar16 = FUN_00550080(4,piStack_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            piStack_14 = (int *)((float)iVar16 * _DAT_00cc8830);
            FUN_00404560(&piStack_14);
            piStack_14 = (int *)FUN_00550080(5,piStack_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_00404560(&piStack_14);
            piStack_14 = (int *)FUN_00550080(6,piStack_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_00404560(&piStack_14);
            FUN_00434a80();
            piStack_14 = (int *)FUN_00550080(7,piStack_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_00402150(&piStack_14);
            local_8._0_1_ = 0x3c;
            FUN_0046d0b0(auStack_74);
            local_8._0_1_ = 0;
            FUN_00402010();
            break;
          }
          iVar16 = iVar16 + 1;
          piVar4 = piVar4 + 1;
        } while (iVar16 < 3);
      }
      if (in_ECX[0xb3f] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x104);
        local_8._0_1_ = 0x3d;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          iVar16 = FUN_006363e0();
        }
        local_8._0_1_ = 0;
        in_ECX[0xb3f] = iVar16;
        FUN_00598c30(0xf0,0x28,100,1,2,1,0xffc85014,&DAT_00c85014,2,2,2);
        FUN_00598c30(0xf0,0x28,100,0,2,1,0xffc85014,&DAT_00c85014,2,0,1);
        iVar16 = (**(code **)(*(int *)in_ECX[0xb3f] + 0x50))();
        *(undefined1 *)(iVar16 + 0x48) = 0;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0) {
        (**(code **)(*(int *)in_ECX[0xb3f] + 0x48))();
      }
      else {
        FUN_0071b2e0(0);
      }
      if (in_ECX[0xb40] == 0) {
        pfStack_1c = (float *)(in_ECX + 0xb42);
        iVar16 = 1;
        pwStack_20 = (wchar_t *)0x2;
        uVar3 = (undefined1)local_8;
        do {
          local_8._0_1_ = uVar3;
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x3e;
          if (pvStack_18 == (void *)0x0) {
            fVar12 = 0.0;
          }
          else {
            uVar38 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_RapidMoveSlash__00d7e4e0,iVar16,1);
            uVar34 = FUN_004334b0(uVar8);
            fVar12 = (float)FUN_00472a60(uVar34,uVar8,uVar38);
          }
          local_8._0_1_ = 0;
          pfStack_1c[-2] = fVar12;
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x3f;
          if (pvStack_18 == (void *)0x0) {
            fVar12 = 0.0;
          }
          else {
            uVar38 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_RapidMoveSlash__00d7e488,iVar16,1);
            uVar34 = FUN_004334b0(uVar8);
            fVar12 = (float)FUN_00472a60(uVar34,uVar8,uVar38);
          }
          *pfStack_1c = fVar12;
          pfStack_1c = pfStack_1c + 1;
          iVar16 = iVar16 + 1;
          pwStack_20 = (wchar_t *)((int)pwStack_20 + -1);
          local_8._0_1_ = 0;
          uVar3 = (undefined1)local_8;
          local_8._0_1_ = 0;
        } while (pwStack_20 != (wchar_t *)0x0);
      }
      (**(code **)(*in_ECX + 0xf8))(4,in_ECX[0xb40],0,0,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(6,in_ECX[0xb41],0,0,0,0,0,0,0,1);
      iVar16 = FUN_00402060();
      iVar15 = FUN_00402060();
      if (iVar15 < iVar16 + -1) {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 3) {
          uVar34 = 0x3f800000;
          uVar8 = 0x3f800000;
        }
        else {
          iVar16 = (**(code **)(*in_ECX + 0x620))();
          if (iVar16 == 0) {
            uVar34 = 0x3f59999a;
            uVar8 = 0x3f59999a;
          }
          else {
            uVar34 = 0x3f666666;
            uVar8 = 0x3f666666;
          }
        }
        FUN_00a25900(uVar8,uVar34);
        iVar16 = in_ECX[0xb42];
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 3) {
          uVar34 = 0x3f800000;
          uVar8 = 0x3f800000;
        }
        else {
          iVar16 = (**(code **)(*in_ECX + 0x620))();
          if (iVar16 == 0) {
            uVar34 = 0x3f451eb8;
            uVar8 = 0x3f451eb8;
          }
          else {
            uVar34 = 0x3f547ae1;
            uVar8 = 0x3f547ae1;
          }
        }
        FUN_00a25900(uVar8,uVar34);
        iVar16 = in_ECX[0xb43];
      }
      (**(code **)(*in_ECX + 0xf8))(5,iVar16,0,0,0,0,0,0,0,1);
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x40;
      if (pvStack_18 == (void *)0x0) {
        uVar8 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_RapidMoveSlash__00d7e430;
        uVar8 = FUN_004334b0(u_Effect_Animation_RapidMoveSlash__00d7e430,1);
        uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      pvStack_18 = (void *)FUN_00403c50(0x1fc);
      local_8._0_1_ = 0x41;
      if (pvStack_18 == (void *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        piVar4 = (int *)FUN_004abd20(uVar8,1);
      }
      local_8._0_1_ = 0;
      FUN_0050dd70(in_ECX,2,0,piVar4,in_ECX,0,0);
      iVar16 = *piVar4;
      uVar8 = (**(code **)(*in_ECX + 0xc0))();
      (**(code **)(iVar16 + 0xbc))(uVar8);
      iVar16 = *piVar4;
      uVar8 = (**(code **)(*in_ECX + 0x9c))();
      uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
      uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
      (**(code **)(iVar16 + 0x88))(uVar8);
      pwVar19 = u_MENGRYOUNG_ATK_00d7e40c;
      goto code_r0x0073660a;
    }
code_r0x00736612:
    if (cStack_2d != '\0') {
      piVar4 = in_ECX + 0xb44;
      if (in_ECX[0xb44] == 0) {
        apwStack_50[1] = u_LightReady1__00d7e3f0;
        apwStack_50[2] = u_LightReady2__00d7e3d4;
        apwStack_50[3] = u_LightMove1__00d7e3bc;
        apwStack_50[4] = u_LightMove2__00d7e3a4;
        pfStack_1c = (float *)0x0;
        uVar3 = (undefined1)local_8;
        do {
          local_8._0_1_ = uVar3;
          iVar16 = 0;
          piStack_28 = piVar4;
          uVar3 = (undefined1)local_8;
          do {
            local_8._0_1_ = uVar3;
            pvStack_18 = (void *)FUN_00403c50(0x1e8);
            local_8._0_1_ = 0x42;
            if (pvStack_18 == (void *)0x0) {
              iVar15 = 0;
            }
            else {
              if ((uint)in_ECX[0x97] < 8) {
                pwStack_20 = (wchar_t *)(in_ECX + 0x92);
              }
              else {
                pwStack_20 = (wchar_t *)in_ECX[0x92];
              }
              uVar34 = 1;
              uVar8 = FUN_00a52aa0(0,u_Effect_Animation_RapidMoveSlash__00d7e350,
                                   apwStack_50[(int)pfStack_1c + 1],iVar16 + 1,1);
              iVar15 = FUN_00472a60(pwStack_20,uVar8,uVar34);
            }
            *piStack_28 = iVar15;
            iVar16 = iVar16 + 1;
            piVar4 = piStack_28 + 1;
            local_8._0_1_ = 0;
            uVar3 = (undefined1)local_8;
            local_8._0_1_ = 0;
            piStack_28 = piVar4;
          } while (iVar16 < 6);
          pfStack_1c = (float *)((int)pfStack_1c + 1);
        } while ((int)pfStack_1c < 4);
      }
      uVar6 = -(uint)(in_ECX[0xb38] != 0) & 2;
      iVar16 = FUN_00402060();
      iVar15 = FUN_00402060();
      if (iVar15 == iVar16 + -1) {
        uVar6 = uVar6 + 1;
      }
      iVar16 = 0;
      piVar4 = in_ECX + uVar6 * 6 + 0xb44;
      do {
        if ((iVar16 == 2) || (iVar16 == 5)) {
          uVar8 = 1;
        }
        else {
          uVar8 = 0;
        }
        iVar15 = iVar16 + -3;
        if (2 < iVar16) {
          iVar15 = iVar16 + -2;
        }
        (**(code **)(*in_ECX + 0xf8))(iVar15,*piVar4,0,0,0,0,uVar8,0,0,1);
        iVar16 = iVar16 + 1;
        piVar4 = piVar4 + 1;
      } while (iVar16 < 6);
    }
    break;
  case (wchar_t *)0x28:
    in_ECX[0xb5c] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    if (in_ECX[0xb5c] == 0) {
      in_ECX[0xb5d] = 0;
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x33);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      in_ECX[0xb5e] = 0;
      in_ECX[0xb5f] = 0;
      FUN_006b5cb0();
      FUN_0071c9d0(0);
      (**(code **)(*in_ECX + 0x10c))(u_SM_HOANYOUNG_START_00d7e324,0xffffffff,0,0);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
      (**(code **)(iVar16 + 0x10c))(uVar8);
    }
    else if (in_ECX[0xb5c] == 1) {
      in_ECX[0xb5e] = in_ECX[0x41];
      iVar16 = *in_ECX;
      uVar34 = 0x37;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x37);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      if (in_ECX[0xb60] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x43;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar20 = 1;
          pwVar19 = u_Effect_Animation_IllusionSlash_U_00d7e2d0;
          uVar38 = FUN_004334b0(u_Effect_Animation_IllusionSlash_U_00d7e2d0,1);
          iVar16 = FUN_00472a60(uVar38,pwVar19,uVar20);
        }
        local_8._0_1_ = 0;
        in_ECX[0xb60] = iVar16;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x44;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar20 = 1;
          pwVar19 = u_Effect_Animation_IllusionSlash_S_00d7e278;
          uVar38 = FUN_004334b0(u_Effect_Animation_IllusionSlash_S_00d7e278,1);
          iVar16 = FUN_00472a60(uVar38,pwVar19,uVar20);
        }
        local_8._0_1_ = 0;
        in_ECX[0xb61] = iVar16;
      }
      in_ECX[0xb62] = 0;
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 3) {
        uVar20 = 0x3f800000;
        uVar38 = 0x3f800000;
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 0) {
          uVar20 = 0x3f59999a;
          uVar38 = 0x3f59999a;
        }
        else {
          uVar20 = 0x3f666666;
          uVar38 = 0x3f666666;
        }
      }
      FUN_00a25900(uVar38,uVar20);
      iVar16 = *in_ECX;
      uVar38 = FUN_005270f0(0x2f);
      (**(code **)(iVar16 + 0x198))(uVar38);
      uVar26 = 0xc;
      uVar20 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      uVar24 = (**(code **)(*in_ECX + 0x64c))(0x49);
      (**(code **)(*in_ECX + 0x67c))(0x49,0,uVar24);
      iVar16 = FUN_004caa20(uVar20,uVar26,uVar38,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      piVar4 = (int *)FUN_006db690(1);
      in_ECX[0xb63] = *piVar4;
    }
    break;
  case (wchar_t *)0x29:
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x38);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    *(undefined1 *)(in_ECX + 0xc07) = 0;
    pwVar19 = u_SM_BOODONG_EXLPOSION_00d7ddd0;
    goto LAB_0073a15e;
  case (wchar_t *)0x2a:
    piVar4 = (int *)FUN_006db690(0);
    in_ECX[0xcc9] = *piVar4;
    (**(code **)(*in_ECX + 0x67c))(0x4d);
    local_24 = (int *)(**(code **)(*in_ECX + 0x64c))(0x4d);
    iVar16 = FUN_0054ff60(0,0);
    piStack_2c = (int *)FUN_0054ff60(1,0);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x644))(0);
    if (piStack_14 != (int *)&DAT_00000004) {
      piVar4 = (int *)(**(code **)(*in_ECX + 0xc0))();
      if (piStack_14 == piVar4) {
        iVar15 = FUN_0054ff60(2,0);
        iVar16 = iVar16 + iVar15;
        iVar15 = FUN_0054ff60(3,0);
        piStack_2c = (int *)((int)piStack_2c + iVar15);
      }
      else {
        piVar4 = (int *)(**(code **)(*in_ECX + 0xc0))();
        if (piStack_14 != piVar4) {
          iVar16 = 0;
          piStack_2c = (int *)0x0;
        }
      }
    }
    (**(code **)(*in_ECX + 0x488))(0,iVar16,iVar16,0,piStack_2c,1);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0xc0))(4,0);
    (**(code **)(iVar16 + 0x49c))(uVar8);
    if (in_ECX[0xcca] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x5b;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_MoonlightSlash1_00d7d9a0;
        uVar8 = FUN_004334b0(u_Effect_Animation_MoonlightSlash1_00d7d9a0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xcca] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x5c;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_MoonlightSlash2_00d7d950;
        uVar8 = FUN_004334b0(u_Effect_Animation_MoonlightSlash2_00d7d950,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xccb] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x5d;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_MoonlightSlashF_00d7d900;
        uVar8 = FUN_004334b0(u_Effect_Animation_MoonlightSlashF_00d7d900,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xccc] = iVar16;
    }
    iVar16 = in_ECX[0xcc9];
    if (iVar16 == 0) {
      (**(code **)(*in_ECX + 0x10c))(u_MOON_ATK_01_00d73734,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_SM_MOON_ATK_00d7d8e4,0xffffffff,0,0);
      iVar15 = *in_ECX;
      uVar8 = FUN_005270f0(0x36);
      (**(code **)(iVar15 + 0x198))(uVar8);
      *(undefined1 *)(in_ECX + 0xccd) = 1;
      iVar15 = *in_ECX;
      uVar8 = (**(code **)(iVar15 + 0x38c))(0x3d);
      (**(code **)(iVar15 + 0xf0))(uVar8);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar15 = FUN_004caa20(0,local_24,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar15 + -100);
      FUN_00404560(&piStack_14);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
      iVar16 = FUN_004caa20(3,local_24,in_ECX,uVar8,iVar16);
      iVar15 = FUN_00402060();
      piStack_14 = (int *)(float)((iVar16 * 100) / (iVar15 + 100));
    }
    else if (iVar16 == 1) {
      uVar38 = 0;
      (**(code **)(*in_ECX + 0x10c))(u_MOON_ATK_02_00d7371c,0xffffffff,0,0);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x37);
      (**(code **)(iVar16 + 0x198))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x3e);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xccb],0,0,0,0,1,0,0,1);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(1,local_24,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
      iVar16 = FUN_004caa20(4,local_24,in_ECX,uVar8,uVar38);
      iVar15 = FUN_00402060();
      piStack_14 = (int *)(float)((iVar16 * 100) / (iVar15 + 100));
    }
    else {
      if (iVar16 != 2) break;
      uVar38 = 0;
      (**(code **)(*in_ECX + 0x10c))(u_SM_FULLMOON_ATK_00d7d8c4,0xffffffff,0,0);
      (**(code **)(*in_ECX + 0x10c))(u_MOON_ATK_02_00d7371c,0xffffffff,0,0);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x38);
      (**(code **)(iVar16 + 0x198))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x41);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xccc],0,0,0,0,1,0,0,1);
      uVar34 = 0xc;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(2,local_24,in_ECX,uVar8,uVar34);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
      iVar16 = FUN_004caa20(5,local_24,in_ECX,uVar8,uVar38);
      iVar15 = FUN_00402060();
      piStack_14 = (int *)(float)((iVar16 * 100) / (iVar15 + 100));
    }
    FUN_00404560(&piStack_14);
    break;
  case (wchar_t *)0x2b:
    in_ECX[0xb64] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x67c))(0x4f);
    local_24 = (int *)(**(code **)(*in_ECX + 0x64c))(0x4f);
    if (in_ECX[0xb81] == 0) {
      piStack_2c = in_ECX + 0xb83;
      iVar16 = 1;
      pwStack_20 = (wchar_t *)0x2;
      uVar3 = (undefined1)local_8;
      do {
        local_8._0_1_ = uVar3;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x45;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_BloodyRave_Star_00d7e228,iVar16,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        local_8._0_1_ = 0;
        piStack_2c[-2] = iVar15;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x46;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_BloodyRave_Loop_00d7e1d8,iVar16,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        local_8._0_1_ = 0;
        *piStack_2c = iVar15;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x47;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_BloodyRave_Line_00d7e188,iVar16,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        piStack_2c[2] = iVar15;
        piStack_2c = piStack_2c + 1;
        iVar16 = iVar16 + 1;
        pwStack_20 = (wchar_t *)((int)pwStack_20 + -1);
        local_8._0_1_ = 0;
        uVar3 = (undefined1)local_8;
        local_8._0_1_ = 0;
      } while (pwStack_20 != (wchar_t *)0x0);
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x48;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_BloodyRave_Typh_00d7e138;
        uVar8 = FUN_004334b0(u_Effect_Animation_BloodyRave_Typh_00d7e138,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb87] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x49;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_BloodyRave_End__00d7e0f0;
        uVar8 = FUN_004334b0(u_Effect_Animation_BloodyRave_End__00d7e0f0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      in_ECX[0xb88] = iVar16;
      pfStack_1c = (float *)(in_ECX + 0xb89);
      iVar16 = 0;
      do {
        local_8._0_1_ = 0;
        if ((*(int *)(DAT_01002848 + 0x19a8) == 1) || ((iVar16 != 1 && (iVar16 != 3)))) {
          pwStack_20 = u_Effect_Animation_BloodyRave_Swor_00d7e048;
        }
        else {
          pwStack_20 = u_Effect_Animation_BloodyRave__TN__00d7e098;
        }
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x4a;
        if (pvStack_18 == (void *)0x0) {
          fVar12 = 0.0;
        }
        else {
          if ((uint)in_ECX[0x97] < 8) {
            piStack_28 = in_ECX + 0x92;
          }
          else {
            piStack_28 = (int *)in_ECX[0x92];
          }
          uVar34 = 1;
          uVar8 = FUN_00a52aa0(0,pwStack_20,iVar16 + 1,1);
          fVar12 = (float)FUN_00472a60(piStack_28,uVar8,uVar34);
        }
        *pfStack_1c = fVar12;
        iVar16 = iVar16 + 1;
        pfStack_1c = pfStack_1c + 1;
        local_8._0_1_ = 0;
      } while (iVar16 < 4);
    }
    if (in_ECX[0xb64] == 0) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x3f);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x35);
      (**(code **)(iVar16 + 0x198))(uVar8);
      iVar16 = FUN_0054ff60(0,in_ECX);
      in_ECX[0xb65] = iVar16;
      iVar16 = FUN_0054ff60(1,in_ECX);
      in_ECX[0xb66] = iVar16;
      iVar16 = 0;
      piVar4 = in_ECX + 0xaa;
      do {
        if (*piVar4 == 0x12) {
          in_ECX[iVar16 + 0xaa] = 0xb;
          iVar16 = FUN_00550080(2,local_24,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          pwStack_20 = (wchar_t *)((float)iVar16 * _DAT_00cc8830);
          FUN_00404560(&pwStack_20);
          iVar16 = FUN_00550080(3,local_24,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          iVar15 = FUN_0071bdb0();
          pwStack_20 = (wchar_t *)(iVar16 + iVar15);
          FUN_00404560(&pwStack_20);
          piStack_14 = (int *)FUN_00550080(4,local_24,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_00404560(&piStack_14);
          FUN_00434a80();
          piStack_14 = (int *)FUN_00550080(5,local_24,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_00402150(&piStack_14);
          local_8._0_1_ = 0x4b;
          FUN_0046d0b0(auStack_5c);
          local_8._0_1_ = 0;
          FUN_00402010();
          break;
        }
        iVar16 = iVar16 + 1;
        piVar4 = piVar4 + 1;
      } while (iVar16 < 3);
      in_ECX[0xb69] = 0;
      iVar16 = FUN_00a24ce0(9);
      in_ECX[0xb6a] = iVar16;
      iVar16 = FUN_00550080(6,local_24,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      piStack_14 = (int *)((float)iVar16 * _DAT_00cc8830);
      FUN_00404560(&piStack_14);
      in_ECX[0xb8d] = 0;
      FUN_00a51f50(0x32,0xffffffff,1,1);
      FUN_00a51f70();
      uVar20 = 0;
      uVar38 = 0;
      uVar34 = 0xffffffff;
      uVar8 = FUN_0054ff60(5,in_ECX);
      FUN_00a51f50(uVar8,uVar34,uVar38,uVar20);
      FUN_00a51f70();
      (**(code **)(*in_ECX + 0x10c))(u_SM_BLOOD_RAVE_STORM_00d7e01c,0xffffffff,0,0);
    }
    else if (in_ECX[0xb64] == 1) {
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x40);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      FUN_0071ff70(1);
      iVar16 = 0;
      piVar4 = in_ECX + 0xb89;
      do {
        if ((iVar16 == 1) || (iVar16 == 3)) {
          uVar8 = 1;
        }
        else {
          uVar8 = 0;
        }
        iVar15 = iVar16 + -2;
        if (1 < iVar16) {
          iVar15 = iVar16 + -1;
        }
        (**(code **)(*in_ECX + 0xf8))(iVar15,*piVar4,0,0,0,0,uVar8,0,0,1);
        iVar16 = iVar16 + 1;
        piVar4 = piVar4 + 1;
      } while (iVar16 < 4);
      *(undefined1 *)(in_ECX + 0xb80) = 0;
    }
    break;
  case (wchar_t *)0x2c:
    in_ECX[0xb8e] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x67c))(0x52);
    (**(code **)(*in_ECX + 0x64c))(0x52);
    iVar16 = in_ECX[0xb8e];
    if (iVar16 == 0) {
      (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
      (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
      (**(code **)(*in_ECX + 0x49c))(4,4,0);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x44);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      *(undefined1 *)(in_ECX + 0xb8f) = 0;
      if (in_ECX[0xba9] == 0) {
        piStack_14 = in_ECX + 0xba9;
        iVar16 = 0;
        uVar3 = (undefined1)local_8;
        do {
          local_8._0_1_ = uVar3;
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x4c;
          if (pvStack_18 == (void *)0x0) {
            iVar15 = 0;
          }
          else {
            uVar38 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_Land_d_an_00d7dfd8,iVar16 + 1,1);
            uVar34 = FUN_004334b0(uVar8);
            iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
          }
          *piStack_14 = iVar15;
          iVar16 = iVar16 + 1;
          piStack_14 = piStack_14 + 1;
          local_8._0_1_ = 0;
          uVar3 = (undefined1)local_8;
          local_8._0_1_ = 0;
        } while (iVar16 < 4);
      }
      iVar16 = 0;
      piVar4 = in_ECX + 0xba9;
      do {
        iVar15 = iVar16 + -2;
        if (1 < iVar16) {
          iVar15 = iVar16 + -1;
        }
        (**(code **)(*in_ECX + 0xf8))(iVar15,*piVar4,0,0,0,0,1,0,0,1);
        iVar16 = iVar16 + 1;
        piVar4 = piVar4 + 1;
      } while (iVar16 < 4);
      pwVar19 = u_SM_KALRA_ATK_00d7dfbc;
    }
    else {
      if (iVar16 != 1) {
        if (iVar16 == 2) {
          (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
          (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
          (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
          (**(code **)(*in_ECX + 0x49c))(4,4,0);
          iVar16 = *in_ECX;
          uVar8 = (**(code **)(iVar16 + 0x38c))(0x46);
          (**(code **)(iVar16 + 0xf0))(uVar8);
          if (in_ECX[0xb91] == 0) {
            iVar16 = 0;
            piStack_14 = in_ECX + 0xb91;
            do {
              pvStack_18 = (void *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x4e;
              if (pvStack_18 == (void *)0x0) {
                iVar15 = 0;
              }
              else {
                uVar38 = 1;
                uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_FinishRea_00d7df20,iVar16 + 1,1);
                uVar34 = FUN_004334b0(uVar8);
                iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
              }
              *piStack_14 = iVar15;
              iVar16 = iVar16 + 1;
              piStack_14 = piStack_14 + 1;
              local_8._0_1_ = 0;
            } while (iVar16 < 4);
            piStack_14 = in_ECX + 0xb97;
            iVar16 = 0;
            do {
              local_8._0_1_ = 0;
              pvStack_18 = (void *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x4f;
              if (pvStack_18 == (void *)0x0) {
                iVar15 = 0;
              }
              else {
                uVar38 = 1;
                uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_Finish1___00d7ded0,iVar16 + 1,1);
                uVar34 = FUN_004334b0(uVar8);
                iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
              }
              *piStack_14 = iVar15;
              iVar16 = iVar16 + 1;
              piStack_14 = piStack_14 + 1;
            } while (iVar16 < 4);
            pwStack_20 = (wchar_t *)(in_ECX + 0xb9d);
            iVar16 = 0;
            do {
              local_8._0_1_ = 0;
              pvStack_18 = (void *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x50;
              if (pvStack_18 == (void *)0x0) {
                iVar15 = 0;
              }
              else {
                if ((uint)in_ECX[0x97] < 8) {
                  piStack_14 = in_ECX + 0x92;
                }
                else {
                  piStack_14 = (int *)in_ECX[0x92];
                }
                uVar34 = 1;
                uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_Finish2___00d7de80,iVar16 + 1,1);
                iVar15 = FUN_00472a60(piStack_14,uVar8,uVar34);
              }
              *(int *)pwStack_20 = iVar15;
              iVar16 = iVar16 + 1;
              pwStack_20 = pwStack_20 + 2;
            } while (iVar16 < 4);
            pwStack_20 = (wchar_t *)(in_ECX + 0xba3);
            iVar16 = 0;
            do {
              local_8._0_1_ = 0;
              pvStack_18 = (void *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x51;
              if (pvStack_18 == (void *)0x0) {
                iVar15 = 0;
              }
              else {
                if ((uint)in_ECX[0x97] < 8) {
                  piStack_14 = in_ECX + 0x92;
                }
                else {
                  piStack_14 = (int *)in_ECX[0x92];
                }
                uVar34 = 1;
                uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_Finish3___00d7de30,iVar16 + 1,1);
                iVar15 = FUN_00472a60(piStack_14,uVar8,uVar34);
              }
              *(int *)pwStack_20 = iVar15;
              iVar16 = iVar16 + 1;
              pwStack_20 = pwStack_20 + 2;
              local_8._0_1_ = 0;
            } while (iVar16 < 6);
          }
          iVar16 = 0;
          do {
            iVar15 = iVar16;
            if (iVar16 == 0) {
              iVar15 = -1;
            }
            (**(code **)(*in_ECX + 0xf8))(iVar15,in_ECX[iVar16 + 0xb91],0,0,0,0,0,0,0,1);
            iVar16 = iVar16 + 1;
          } while (iVar16 < 4);
          *(undefined1 *)(in_ECX + 0xbaf) = 0;
          if ((int *)in_ECX[0xb90] != (int *)0x0) {
            ppiVar22 = &piStack_14;
            piStack_14 = (int *)0x0;
            (**(code **)(*(int *)in_ECX[0xb90] + 0x50))(ppiVar22);
            FUN_00404560(ppiVar22);
          }
          (**(code **)(*in_ECX + 0x10c))(u_SM_KALRA_FIN_00d7de14,0xffffffff,0,0);
          (**(code **)(*in_ECX + 0x10c))(u_KALA_READY_00d7ddfc,0xffffffff,0,0);
        }
        break;
      }
      (**(code **)(*in_ECX + 0x494))(1,4,1000,1000,0x3f800000,0x3f800000);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x45);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      *(undefined1 *)(in_ECX + 0xb8f) = 0;
      FUN_0043f540(0);
      if (in_ECX[0xbad] == 0) {
        piStack_14 = in_ECX + 0xbad;
        iVar16 = 0;
        uVar3 = (undefined1)local_8;
        do {
          local_8._0_1_ = uVar3;
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x4d;
          if (pvStack_18 == (void *)0x0) {
            iVar15 = 0;
          }
          else {
            uVar38 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_Air_d_ani_00d7df78,iVar16 + 1,1);
            uVar34 = FUN_004334b0(uVar8);
            iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
          }
          *piStack_14 = iVar15;
          iVar16 = iVar16 + 1;
          piStack_14 = piStack_14 + 1;
          local_8._0_1_ = 0;
          uVar3 = (undefined1)local_8;
          local_8._0_1_ = 0;
        } while (iVar16 < 2);
      }
      iVar16 = 0;
      piVar4 = in_ECX + 0xbad;
      do {
        iVar16 = iVar16 + 1;
        (**(code **)(*in_ECX + 0xf8))(iVar16,*piVar4,0,0,0,0,1,0,0,1);
        piVar4 = piVar4 + 1;
      } while (iVar16 < 2);
      pwVar19 = u_SM_KALRA_ATK_00d7dfbc;
    }
    goto LAB_0073a15e;
  case (wchar_t *)0x2d:
    in_ECX[0xb1b] = **(int **)((int)param_2 + 4);
    (**(code **)(*in_ECX + 0x67c))(0x51);
    (**(code **)(*in_ECX + 0x64c))(0x51);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    (**(code **)(*in_ECX + 0x494))(2,2,1000,1000,0x3f800000,0x3f800000);
    if (in_ECX[0xb20] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x33;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e8f0;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e8f0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb20] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x34;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e888;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e888,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb21] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x35;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e818;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e818,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb22] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x36;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e7b0;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e7b0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb23] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x37;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e738;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e738,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb24] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x38;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e6c0;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e6c0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb25] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x39;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_OutRageBreak_sw_00d7e658;
        uVar8 = FUN_004334b0(u_Effect_Animation_OutRageBreak_sw_00d7e658,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xb26] = iVar16;
    }
    if (in_ECX[0xb1b] == 0) {
      (**(code **)(*in_ECX + 0x10c))(u_OUTRAGE_READY_00d7e638,0xffffffff,0,0);
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x42);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb20],0,0,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xb21],0,0,0,0,0,0,0,1);
    }
    else if (in_ECX[0xb1b] == 1) {
      *(undefined1 *)(in_ECX + 0xb27) = 0;
      iVar16 = *in_ECX;
      uVar8 = (**(code **)(iVar16 + 0x38c))(0x43);
      (**(code **)(iVar16 + 0xf0))(uVar8);
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0x39);
      (**(code **)(iVar16 + 0x198))(uVar8);
      (**(code **)(*in_ECX + 0x67c))(0x51);
      uVar8 = (**(code **)(*in_ECX + 0x64c))(0x51);
      uVar38 = 0xc;
      uVar34 = (**(code **)(*in_ECX + 0x1d0))(0xc);
      iVar16 = FUN_004caa20(0,uVar8,in_ECX,uVar34,uVar38);
      piStack_14 = (int *)(iVar16 + -100);
      FUN_00404560(&piStack_14);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xb22],0,0,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xb23],0,0,0,0,0,0,0,1);
      FUN_004ba0c0(0,0);
      iVar16 = (**(code **)(*in_ECX + 0x94))();
      in_ECX[0xb1c] = iVar16;
      iVar16 = FUN_0054ff60(0,0);
      in_ECX[0xb1d] = iVar16;
      iVar16 = FUN_0054ff60(1,0);
      in_ECX[0xb1e] = iVar16;
      *(undefined1 *)(in_ECX + 0xb1f) = 0;
    }
    break;
  case (wchar_t *)0x2e:
    (**(code **)(*in_ECX + 0x67c))(0x55);
    piStack_14 = (int *)(**(code **)(*in_ECX + 0x64c))(0x55);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(3,3,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x4a);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(0x3d);
    (**(code **)(iVar16 + 0x198))(uVar8);
    if (in_ECX[0xc35] != 0) {
      uVar8 = FUN_0073d710(*(undefined4 *)(in_ECX[0xc35] + 0x80));
      uVar34 = 0;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0,uVar8);
      piVar4 = piStack_14;
      uVar8 = FUN_004caa20(1,piStack_14,in_ECX,uVar8,uVar34);
      uVar34 = 0;
      uVar8 = (**(code **)(*in_ECX + 0x1d0))(0,uVar8);
      uVar8 = FUN_004caa20(0,piVar4,in_ECX,uVar8,uVar34);
      iVar16 = FUN_00473f20(uVar8);
      piStack_14 = (int *)(float)iVar16;
      FUN_00404560(&piStack_14);
    }
    if (in_ECX[0xc37] == 0) {
      piStack_14 = in_ECX + 0xc37;
      iVar16 = 0;
      uVar3 = (undefined1)local_8;
      do {
        local_8._0_1_ = uVar3;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x62;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_Hellbenter_Fini_00d7d6f8,iVar16 + 1,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        *piStack_14 = iVar15;
        iVar16 = iVar16 + 1;
        piStack_14 = piStack_14 + 1;
        local_8._0_1_ = 0;
        uVar3 = (undefined1)local_8;
        local_8._0_1_ = 0;
      } while (iVar16 < 3);
    }
    (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xc37],0,0,0,0,1,0,0,1);
    (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xc38],0,0,0,0,1,0,0,1);
    if (0 < DAT_010c0774) {
      (**(code **)(*in_ECX + 0xf8))(3,in_ECX[0xc39],0,0,0,0,1,0,0,1);
    }
    *(undefined1 *)(in_ECX + 0xc3a) = 0;
    *(undefined1 *)(in_ECX + 0x90) = 0;
    in_ECX[0xc3b] = 0;
    break;
  case (wchar_t *)0x2f:
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(3,3,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    puVar13 = (undefined4 *)FUN_006db690(0);
    (**(code **)(*in_ECX + 0xbc))(*puVar13);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x4b);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = (**(code **)(*in_ECX + 0x94))();
    in_ECX[0xc3c] = iVar16;
    iVar16 = (**(code **)(*in_ECX + 0x98))();
    in_ECX[0xc3d] = iVar16;
    iVar16 = (**(code **)(*in_ECX + 0xc0))();
    uVar34 = 0;
    uVar8 = 0x56;
    if (iVar16 == 0) {
      (**(code **)(*in_ECX + 0x67c))();
      piStack_14 = (int *)FUN_0054ff60(uVar8,uVar34);
      iVar16 = (**(code **)(*in_ECX + 0x94))();
      iVar16 = iVar16 - (int)piStack_14;
    }
    else {
      (**(code **)(*in_ECX + 0x67c))(0x56,0);
      iVar16 = FUN_0054ff60(uVar8,uVar34);
      iVar15 = (**(code **)(*in_ECX + 0x94))();
      iVar16 = iVar16 + iVar15;
    }
    in_ECX[0xc3e] = iVar16;
    iVar16 = (**(code **)(*in_ECX + 0x98))();
    in_ECX[0xc3f] = iVar16;
    iVar16 = (**(code **)(*in_ECX + 0xc0))();
    in_ECX[0xc40] = iVar16;
    in_ECX[0xc41] = 0;
    in_ECX[0xc42] = 0;
    in_ECX[0xc43] = 0;
    in_ECX[0xc44] = 0;
    in_ECX[0xc45] = 0;
    in_ECX[0xc46] = 0;
    in_ECX[0xc47] = 0;
    in_ECX[0xc48] = 0;
    in_ECX[0xc49] = 0;
    in_ECX[0xc4a] = 0;
    in_ECX[0xc4b] = 0;
    in_ECX[0xc4c] = 0;
    in_ECX[0xc4d] = 0;
    in_ECX[0xc4e] = 0;
    in_ECX[0xc4f] = 0;
    in_ECX[0xc50] = 0;
    in_ECX[0xc51] = 0;
    in_ECX[0xc52] = 0;
    in_ECX[0xc53] = 0;
    in_ECX[0xc54] = 0;
    in_ECX[0xc55] = 0;
    in_ECX[0xc56] = 0;
    in_ECX[0xc57] = 0;
    in_ECX[0xc58] = 0;
    in_ECX[0xc59] = 0;
    in_ECX[0xc5c] = 0;
    *(undefined1 *)(in_ECX + 0x90) = 0;
    if (in_ECX[0xc5a] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 99;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_HundredSword_Re_00d7d6a8;
        uVar8 = FUN_004334b0(u_Effect_Animation_HundredSword_Re_00d7d6a8,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xc5a] = iVar16;
    }
    (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xc5a],0,0,0,0,1,0,0,1);
    *(undefined1 *)(in_ECX + 0xc5b) = 0;
    break;
  case (wchar_t *)0x30:
    (**(code **)(*in_ECX + 0x67c))(0x56);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    FUN_004ba0c0(0,0);
    piVar7 = (int *)FUN_0041ffe0();
    (**(code **)(*piVar7 + 0xc))(2,0);
    if (piVar4 == (int *)0x2f) {
      FUN_00725640(2);
      pvStack_18 = (void *)FUN_00403c50(0x228);
      local_8._0_1_ = 100;
      if (pvStack_18 == (void *)0x0) {
        piVar4 = (int *)0x0;
      }
      else {
        piVar4 = (int *)FUN_0073ef20(in_ECX);
      }
      in_ECX[0xc5c] = (int)piVar4;
      piVar7 = (int *)in_ECX[0xc48];
      local_8._0_1_ = 0;
      if (piVar7 != (int *)0x0) {
        iVar16 = *piVar4;
        piStack_14 = piVar7;
        iVar15 = (**(code **)(*piVar7 + 0x98))(0);
        uVar8 = (**(code **)(*piStack_14 + 0x94))(iVar15 + 10);
        (**(code **)(iVar16 + 0x88))(uVar8);
      }
      FUN_0050dd70(in_ECX,2,0,in_ECX[0xc5c],0,0,0);
      in_ECX[0xc5d] = 0;
    }
    else {
      in_ECX[0xc5d] = in_ECX[0xc5d] + 1;
    }
    iVar15 = FUN_0054ff60(3,in_ECX);
    iVar16 = in_ECX[0xc5d];
    iVar15 = iVar15 + -1;
    uVar8 = FUN_0054ff60(2,in_ECX);
    uVar34 = FUN_0054ff60(1,in_ECX);
    iVar16 = FUN_00473f20(uVar34,uVar8,iVar16,iVar15);
    (**(code **)(*in_ECX + 0x494))(0,0,1000,(iVar16 * 1000) / 100,0x3f800000,0x3f800000);
    iVar16 = in_ECX[*(int *)(&DAT_00d79920 + in_ECX[0xc5d] * 4) + 0xc42];
    if (iVar16 != 0) {
      FUN_0061afe0(4);
    }
    piStack_14 = (int *)0x0;
    local_24 = (int *)0x0;
    piStack_2c = (int *)0x0;
    FUN_0071bbb0(&piStack_14,&local_24,&piStack_2c,in_ECX[0xc5d]);
    piVar4 = piStack_14;
    if (in_ECX[0xc5d] != 0) {
      if ((iVar16 == 0) || (*(char *)(iVar16 + 0x218) == '\0')) {
        iVar16 = (uint)extraout_var << 8;
      }
      else {
        iVar16 = CONCAT31(extraout_var,1);
      }
      FUN_00730340(in_ECX[0xc5e],piStack_14,local_24,piStack_2c,iVar16);
    }
    pfStack_1c = *(float **)(&DAT_00d798c0 + *(int *)(&DAT_00d79920 + in_ECX[0xc5d] * 4) * 4);
    iVar16 = *(int *)(&DAT_00d79980 + (int)pfStack_1c * 4);
    in_ECX[0xc5e] = iVar16;
    iVar15 = *in_ECX;
    uVar8 = (**(code **)(iVar15 + 0x38c))(iVar16 + 0x4c);
    (**(code **)(iVar15 + 0xf0))(uVar8);
    (**(code **)(*in_ECX + 0x88))(piVar4,(int)local_24 + -1,piStack_2c);
    piStack_14 = (int *)0x0;
    piStack_28 = (int *)0x0;
    pwStack_20 = (wchar_t *)0x0;
    FUN_0071bbb0(&piStack_14,&piStack_28,&pwStack_20,in_ECX[0xc5d] + 1);
    piVar7 = piStack_14;
    (**(code **)(*in_ECX + 0xbc))((int)piVar4 < (int)piStack_14);
    piStack_14 = (int *)FUN_0050aa00(piVar4,1);
    iVar16 = FUN_0050aa40(local_24,piStack_2c,1,0x3f800000);
    iVar15 = FUN_0050aa00(piVar7,1);
    iVar5 = FUN_0050aa40(piStack_28,pwStack_20,1,0x3f800000);
    uVar6 = iVar15 - (int)piStack_14 >> 0x1f;
    fVar18 = (float10)fpatan((float10)(iVar16 - iVar5),
                             (float10)(int)((iVar15 - (int)piStack_14 ^ uVar6) - uVar6));
    piStack_14 = (int *)(float)fVar18;
    (**(code **)(*in_ECX + 0x140))(1,piStack_14);
    if (in_ECX[in_ECX[0xc5e] * 4 + 0xc5f] == 0) {
      pwStack_20 = (wchar_t *)(&DAT_00d79998 + (int)pfStack_1c * 4);
      iVar16 = 0;
      if (0 < *(int *)(&DAT_00d79998 + (int)pfStack_1c * 4)) {
        piStack_14 = (int *)(&DAT_00d799b0 + (int)pfStack_1c * 0x10);
        do {
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x65;
          if (pvStack_18 == (void *)0x0) {
            iVar15 = 0;
          }
          else {
            pwVar19 = u_Normal_00d58bec;
            if (1 < iVar16) {
              pwVar19 = u_Dodge_00d7d69c;
            }
            uVar38 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_HundredSword_We_00d7d638,in_ECX[0xc5e] + 1,
                                 pwVar19,1);
            uVar34 = FUN_004334b0(uVar8);
            iVar15 = FUN_00472b80(iVar16,0,uVar34,uVar8,uVar38);
          }
          local_8._0_1_ = 0;
          in_ECX[iVar16 + in_ECX[0xc5e] * 4 + 0xc5f] = iVar15;
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x66;
          if (pvStack_18 == (void *)0x0) {
            iVar15 = 0;
          }
          else {
            pwVar19 = u_Normal_00d58bec;
            if (1 < iVar16) {
              pwVar19 = u_Dodge_00d7d69c;
            }
            uVar38 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_HundredSword_We_00d7d5d0,in_ECX[0xc5e] + 1,
                                 pwVar19,1);
            uVar34 = FUN_004334b0(uVar8);
            iVar15 = FUN_00472b80(iVar16,0,uVar34,uVar8,uVar38);
          }
          piVar4 = piStack_14;
          in_ECX[iVar16 + in_ECX[0xc5e] * 4 + 0xc73] = iVar15;
          iVar15 = in_ECX[iVar16 + in_ECX[0xc5e] * 4 + 0xc5f];
          iVar5 = *piStack_14;
          iVar14 = in_ECX[0xc5e] + 0x4c;
          local_8._0_1_ = 0;
          (**(code **)(*in_ECX + 0x38c))(iVar14,iVar5,iVar15);
          FUN_00a29d70(iVar14,iVar5);
          iVar5 = in_ECX[iVar16 + in_ECX[0xc5e] * 4 + 0xc73];
          (**(code **)(*in_ECX + 0x38c))(in_ECX[0xc5e] + 0x51,*piVar4,iVar5);
          FUN_00a29d70(iVar5,iVar15);
          iVar16 = iVar16 + 1;
          piStack_14 = piVar4 + 1;
        } while (iVar16 < *(int *)pwStack_20);
      }
    }
    break;
  case (wchar_t *)0x31:
    FUN_004ba0c0(1,0);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x56);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(0x3e);
    (**(code **)(iVar16 + 0x198))(uVar8);
    (**(code **)(*in_ECX + 0x1d0))(0);
    uVar20 = 0x56;
    piVar4 = in_ECX;
    uVar8 = (**(code **)(*in_ECX + 0x64c))(0x56);
    uVar38 = 2;
    uVar34 = 0x56;
    (**(code **)(*in_ECX + 0x67c))(0x56,2,uVar8);
    iVar16 = FUN_004caa20(uVar34,uVar38,uVar8,uVar20,piVar4);
    piStack_14 = (int *)(float)iVar16;
    FUN_00404560(&piStack_14);
    iVar16 = in_ECX[0xc5d];
    in_ECX[0xc5d] = iVar16 + 1;
    piStack_28 = (int *)0x0;
    pwStack_20 = (wchar_t *)0x0;
    piStack_14 = (int *)0x0;
    FUN_0071bbb0(&piStack_28,&pwStack_20,&piStack_14,iVar16 + 1);
    pwVar19 = pwStack_20;
    piVar4 = piStack_28;
    FUN_00730340(in_ECX[0xc5e],piStack_28,pwStack_20,piStack_14,1);
    (**(code **)(*in_ECX + 0xbc))(in_ECX[0xc40]);
    (**(code **)(*in_ECX + 0x88))(piVar4,pwVar19,0);
    (**(code **)(*in_ECX + 0x140))(0,0);
    if (in_ECX[0xc87] == 0) {
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x67;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_HundredSword_Fi_00d7d570;
        uVar8 = FUN_004334b0(u_Effect_Animation_HundredSword_Fi_00d7d570,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xc87] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x68;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_HundredSword_Fi_00d7d510;
        uVar8 = FUN_004334b0(u_Effect_Animation_HundredSword_Fi_00d7d510,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      local_8._0_1_ = 0;
      in_ECX[0xc88] = iVar16;
      pvStack_18 = (void *)FUN_00403c50(0x1e8);
      local_8._0_1_ = 0x69;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        uVar34 = 1;
        pwVar19 = u_Effect_Animation_HundredSword_Fi_00d7d4b0;
        uVar8 = FUN_004334b0(u_Effect_Animation_HundredSword_Fi_00d7d4b0,1);
        iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
      }
      piStack_14 = in_ECX + 0xc8a;
      in_ECX[0xc89] = iVar16;
      iVar16 = 0;
      do {
        local_8._0_1_ = 0;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x6a;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_HundredSword_Fi_00d7d448,iVar16 + 1,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        *piStack_14 = iVar15;
        iVar16 = iVar16 + 1;
        piStack_14 = piStack_14 + 1;
        local_8._0_1_ = 0;
      } while (iVar16 < 4);
      pvStack_18 = (void *)FUN_00403c50(0x1b4);
      local_8._0_1_ = 0x6b;
      if (pvStack_18 == (void *)0x0) {
        iVar16 = 0;
      }
      else {
        pwVar19 = u_Effect_Particle_HundredSwordFini_00d7d3f8;
        piVar4 = in_ECX;
        uVar8 = FUN_004334b0(u_Effect_Particle_HundredSwordFini_00d7d3f8);
        iVar16 = FUN_004a3440(uVar8,pwVar19,piVar4);
      }
      in_ECX[0xc8f] = iVar16;
      local_24 = in_ECX + 0xc90;
      local_8._0_1_ = 0;
      piStack_14 = (int *)0x7;
      do {
        pvStack_18 = operator_new(0x34);
        local_8._0_1_ = 0x6c;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          iVar16 = FUN_00613690(1,1,1,0x1e);
        }
        local_8._0_1_ = 0;
        *local_24 = iVar16;
        piStack_2c = (int *)0x0;
        do {
          pvStack_18 = (void *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x6d;
          if (pvStack_18 == (void *)0x0) {
            uVar8 = 0;
          }
          else {
            if ((uint)in_ECX[0x97] < 8) {
              piVar4 = in_ECX + 0x92;
            }
            else {
              piVar4 = (int *)in_ECX[0x92];
            }
            uVar34 = 1;
            uVar8 = FUN_00a52aa0(0,u_Effect_Animation_HundredSword_Fi_00d7d398,
                                 (int)piStack_2c / 6 + 1,1);
            uVar8 = FUN_00472a60(piVar4,uVar8,uVar34);
          }
          local_8._0_1_ = 0;
          iVar16 = FUN_00a25c90(0);
          piStack_28 = (int *)FUN_00a25c90(0);
          pwStack_20 = (wchar_t *)FUN_00a25c90(0);
          FUN_00b099b0(0x437f0000,0x42c80000,piStack_2c,0x17);
          uVar3 = FUN_00c01544();
          pwStack_20 = (wchar_t *)
                       CONCAT31(CONCAT21(CONCAT11(uVar3,(char)pwStack_20[0xf]),
                                         *(undefined1 *)((int)piStack_28 + 0x1d)),
                                *(undefined1 *)(iVar16 + 0x1c));
          iVar16 = FUN_00a25c90(0);
          *(wchar_t **)(iVar16 + 0x1c) = pwStack_20;
          (**(code **)(*(int *)*local_24 + 4))(uVar8,10);
          piStack_2c = (int *)((int)piStack_2c + 1);
        } while ((int)piStack_2c < 0x18);
        local_24 = local_24 + 1;
        piStack_14 = (int *)((int)piStack_14 + -1);
      } while (piStack_14 != (int *)0x0);
    }
    uVar26 = 2;
    uVar24 = 0;
    uVar20 = 0xff000000;
    *(undefined1 *)(in_ECX + 0xc8e) = 0;
    uVar38 = 0x80;
    *(undefined1 *)(in_ECX + 0x90) = 0;
    iVar16 = FUN_00a24ce0(2);
    iVar15 = FUN_00a24bb0(0);
    iVar15 = iVar15 - iVar16;
    uVar34 = 0;
    uVar8 = FUN_00a24ce0(2);
    (**(code **)(*in_ECX + 0x9c))(0x140,100,uVar8,uVar34,iVar15,uVar38,uVar20,uVar24,uVar26);
    FUN_005db2e0();
    break;
  case (wchar_t *)0x32:
    piVar4 = (int *)FUN_006db690(0);
    in_ECX[0xc97] = *piVar4;
    (**(code **)(*in_ECX + 0x67c))(0x57);
    uVar8 = (**(code **)(*in_ECX + 0x64c))(0x57);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    if (in_ECX[0xc97] == 0) {
      local_24 = (int *)*in_ECX;
      uVar34 = (*(code *)local_24[0xe3])(0x57);
      (*(code *)local_24[0x3c])(uVar34);
      pwVar19 = (wchar_t *)FUN_00468430(in_ECX,uVar8);
      piStack_14 = *(int **)(in_ECX[0x41] + 0x90);
LAB_00739c6d:
      piStack_14 = (int *)((float)(int)piStack_14 / (float)(int)pwVar19);
      pwStack_20 = pwVar19;
      (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,piStack_14,piStack_14);
      iVar16 = *in_ECX;
      (**(code **)(iVar16 + 0x344))(3,0);
      iVar15 = FUN_004ba260();
      (**(code **)(iVar16 + 0x554))(((int)pwVar19 * 1000) / iVar15);
    }
    else if (in_ECX[0xc97] == 1) {
      local_24 = (int *)*in_ECX;
      uVar34 = (*(code *)local_24[0xe3])(0x58);
      (*(code *)local_24[0x3c])(uVar34);
      (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        DAT_00f5478c = 0;
        uVar34 = FUN_0054ff60(7,in_ECX);
        FUN_004e2780(uVar34);
        uVar34 = FUN_0054ff60(8,in_ECX);
        FUN_004e2780(uVar34);
        iVar16 = FUN_0054ff60(2,in_ECX);
        FUN_004e2780(iVar16 / 2);
        uVar34 = FUN_0054ff60(5,in_ECX);
        FUN_004e2780(uVar34);
        uVar34 = FUN_0054ff60(6,in_ECX);
        FUN_004e2780(uVar34);
        iVar16 = FUN_00550080(0,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        FUN_004e2780(-iVar16);
        piStack_14 = (int *)FUN_00550080(1,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        FUN_005b8030((float)(int)piStack_14 * _DAT_00cc8830);
        uVar8 = FUN_0054ff60(0x10,in_ECX);
        FUN_005b3550(uVar8);
        uVar8 = FUN_0054ff60(0x11,in_ECX);
        FUN_005b3550(uVar8);
        uVar8 = FUN_0054ff60(0x12,in_ECX);
        FUN_005b3550(uVar8);
        iVar16 = *in_ECX;
        uVar31 = 0;
        uVar30 = 0;
        uVar29 = 0;
        uVar28 = 4;
        uVar27 = 0;
        uVar26 = 0xffffffff;
        uVar8 = DAT_00f5478c;
        uVar34 = DAT_00f54788;
        uVar38 = FUN_008ac050(u_blc_x_offset_00d7b980);
        uVar24 = 0;
        uVar20 = 0;
        iVar15 = FUN_0054ff60(4,in_ECX);
        (**(code **)(iVar16 + 0x2b8))
                  (0x4e55,iVar15 / 2,uVar20,uVar24,uVar38,uVar26,uVar27,uVar28,uVar29,uVar8,uVar34,
                   uVar30,uVar31);
      }
      iVar16 = FUN_0054ff60(3,in_ECX);
      in_ECX[0xc98] = iVar16;
      if (in_ECX[0xc99] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x6e;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_Blache_Smash_an_00d7d350;
          uVar8 = FUN_004334b0(u_Effect_Animation_Blache_Smash_an_00d7d350,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xc99] = iVar16;
      }
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xc99],0,0,0,0,1,0,0,1);
    }
    break;
  case (wchar_t *)0x33:
    piVar4 = (int *)FUN_006db690(0);
    in_ECX[0xc9a] = *piVar4;
    (**(code **)(*in_ECX + 0x67c))(0x58);
    uVar8 = (**(code **)(*in_ECX + 0x64c))(0x58);
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    if (in_ECX[0xc9a] == 0) {
      local_24 = (int *)*in_ECX;
      uVar34 = (*(code *)local_24[0xe3])(0x59);
      (*(code *)local_24[0x3c])(uVar34);
      pwVar19 = (wchar_t *)FUN_00468430(in_ECX,uVar8);
      piStack_14 = *(int **)(in_ECX[0x41] + 0x90);
      goto LAB_00739c6d;
    }
    if (in_ECX[0xc9a] == 1) {
      local_24 = (int *)*in_ECX;
      uVar34 = (*(code *)local_24[0xe3])(0x5a);
      (*(code *)local_24[0x3c])(uVar34);
      (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
      if (in_ECX[0xc9b] == 0) {
        pvStack_18 = (void *)FUN_00403c50(0xac);
        local_8._0_1_ = 0x6f;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          iVar16 = FUN_0073f340();
        }
        in_ECX[0xc9b] = iVar16;
        local_8._0_1_ = 0;
        *(undefined1 *)(iVar16 + 0x4c) = 0;
        pvStack_18 = (void *)FUN_00403c50(0x9c);
        local_8._0_1_ = 0x70;
        if (pvStack_18 == (void *)0x0) {
          iVar16 = 0;
        }
        else {
          iVar16 = FUN_006b6e80();
        }
        in_ECX[0xc9c] = iVar16;
        local_8._0_1_ = 0;
        *(undefined1 *)(iVar16 + 0x4c) = 0;
      }
      piStack_14 = (int *)FUN_0054ff60(0,in_ECX);
      ppiVar22 = &piStack_14;
      (**(code **)(*(int *)in_ECX[0xc9b] + 0x50))(ppiVar22);
      FUN_00404560(ppiVar22);
      piStack_14 = (int *)FUN_00550080(0,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      fVar12 = (float)(int)piStack_14 * _DAT_00cc8830;
      iVar16 = FUN_0054ff60(1,in_ECX);
      FUN_005a7ea0(iVar16 / 2,fVar12);
      (**(code **)(*(int *)in_ECX[0xc9b] + 0x48))();
      piStack_14 = (int *)FUN_0054ff60(5,in_ECX);
      fVar12 = (float)(int)piStack_14 * _DAT_00cc10ac;
      piStack_14 = (int *)FUN_0054ff60(4,in_ECX);
      fVar21 = (float)(int)piStack_14 * _DAT_00cc10ac;
      piStack_14 = (int *)FUN_0054ff60(3,in_ECX);
      fVar25 = (float)(int)piStack_14 * _DAT_00cc10ac;
      piStack_14 = (int *)FUN_00550080(1,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      fVar23 = (float)(int)piStack_14 * _DAT_00cc8830;
      iVar16 = FUN_0054ff60(2,in_ECX);
      FUN_005a7f80(iVar16 / 2,fVar23,fVar25,fVar21,fVar12);
      (**(code **)(*(int *)in_ECX[0xc9c] + 0x48))();
    }
    break;
  case (wchar_t *)0x34:
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x5e);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    *(undefined1 *)(in_ECX + 0xc9d) = 0;
    break;
  case (wchar_t *)0x35:
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x5f);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    iVar16 = *in_ECX;
    uVar8 = FUN_005270f0(0x42);
    (**(code **)(iVar16 + 0x198))(uVar8);
    (**(code **)(*in_ECX + 0x1d0))(0xc);
    uVar20 = 0x58;
    piVar4 = in_ECX;
    uVar8 = (**(code **)(*in_ECX + 0x64c))(0x58);
    uVar38 = 6;
    uVar34 = 0x58;
    (**(code **)(*in_ECX + 0x67c))(0x58,6,uVar8);
    iVar16 = FUN_004caa20(uVar34,uVar38,uVar8,uVar20,piVar4);
    piStack_14 = (int *)(iVar16 + -100);
    FUN_00404560(&piStack_14);
    if (in_ECX[0xc9e] == 0) {
      piStack_14 = in_ECX + 0xc9e;
      iVar16 = 0;
      uVar3 = (undefined1)local_8;
      do {
        local_8._0_1_ = uVar3;
        pvStack_18 = (void *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x71;
        if (pvStack_18 == (void *)0x0) {
          iVar15 = 0;
        }
        else {
          uVar38 = 1;
          uVar8 = FUN_00a52aa0(0,u_Effect_Animation_WaveEye_Wing_d__00d7d308,iVar16 + 1,1);
          uVar34 = FUN_004334b0(uVar8);
          iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
        }
        *piStack_14 = iVar15;
        iVar16 = iVar16 + 1;
        piStack_14 = piStack_14 + 1;
        local_8._0_1_ = 0;
        uVar3 = (undefined1)local_8;
        local_8._0_1_ = 0;
      } while (iVar16 < 2);
    }
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc9e]);
    (**(code **)(*in_ECX + 0xfc))(in_ECX[0xc9f]);
    (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xc9e],0,0xffffffb0,0,0,1,0,0,1);
    (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xc9f],0,0xffffffb0,0,0,1,0,0,1);
    break;
  case (wchar_t *)0x36:
    (**(code **)(*in_ECX + 0x488))(0,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x488))(1,0,0,0,0,0);
    (**(code **)(*in_ECX + 0x49c))(4,4,0);
    (**(code **)(*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x38c))(0x60);
    (**(code **)(iVar16 + 0xf0))(uVar8);
    FUN_0071e7f0();
    pwVar19 = u_A_FIREWAVE_00d7d2f0;
LAB_0073a15e:
    (**(code **)(*in_ECX + 0x10c))(pwVar19,0xffffffff,0,0);
  }
  FUN_004c5730(param_1,param_2,param_3,param_4);
  switch(param_1) {
  case (wchar_t *)0x6:
    iVar16 = FUN_00402060();
    if ((iVar16 == 1) && (iVar16 = FUN_00402060(), iVar16 < 1)) {
      in_ECX[0xacd] = -1;
      *(undefined1 *)((int)in_ECX + 0x2b5e) = 0;
    }
    break;
  case (wchar_t *)0x7:
    puVar13 = *(undefined4 **)((int)param_2 + 4);
    if ((puVar13 == (undefined4 *)0x0) || (*(int *)((int)param_2 + 8) - (int)puVar13 >> 2 == 0)) {
      param_4 = (int *)0xffffffff;
    }
    else {
      param_4 = (int *)*puVar13;
    }
    FUN_00404560(&param_4);
    iVar16 = (**(code **)(*in_ECX + 0x64c))(0x2b);
    if (0 < iVar16) {
      uVar8 = (**(code **)(*in_ECX + 0x64c))(0x2b,0);
      uVar20 = 1;
      uVar38 = 0;
      uVar34 = 0x2b;
      (**(code **)(*in_ECX + 0x67c))(0x2b,0,1,uVar8);
      FUN_00550020(uVar34,uVar38,uVar20,uVar8);
      iVar16 = *in_ECX;
      param_4 = (int *)FUN_00402060(0x3f800000,0x3f800000);
      uVar8 = FUN_00c01544();
      uVar8 = FUN_00402060(uVar8);
      (**(code **)(iVar16 + 0x494))(0,0,uVar8);
    }
    iVar16 = FUN_00402060();
    if ((iVar16 == -1) || (iVar16 = FUN_00402060(), iVar16 == 0x31)) {
      *(undefined1 *)(in_ECX + 0xad8) = 1;
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if ((iVar16 == 2) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) {
        (**(code **)(*in_ECX + 0x67c))(0xf);
        iVar16 = (**(code **)(*in_ECX + 0x64c))(0xf);
        iVar15 = FUN_00402060();
        if (iVar15 == -1) {
          iVar15 = FUN_0054ff60(2,in_ECX);
          if (iVar15 <= iVar16) {
            param_4 = (int *)FUN_00550080(7,iVar16,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            param_1 = (wchar_t *)FUN_0054ff60(3,in_ECX);
            piVar4 = (int *)0x0;
            uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
            uVar34 = 8;
code_r0x0073a3b3:
            iVar16 = FUN_004caa20(uVar34,iVar16,in_ECX,uVar8,piVar4);
            in_ECX[0xad9] = iVar16;
            *(undefined1 *)(in_ECX + 0xad8) = 0;
            in_ECX[0xada] = -1;
            FUN_006dd0e0();
            param_3 = (int *)0x1;
            FUN_00404560(&param_3);
            FUN_00404560(&param_4);
            param_4 = (int *)param_1;
            FUN_00404560(&param_4);
          }
        }
        else {
          iVar15 = FUN_00402060();
          if ((iVar15 == 0x31) && (iVar15 = FUN_0054ff60(0,in_ECX), iVar15 <= iVar16)) {
            param_4 = (int *)FUN_00550080(2,iVar16,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            uVar34 = 0;
            uVar8 = 0x31;
            piVar4 = in_ECX;
            (**(code **)(*in_ECX + 0x67c))(0x31,0);
            param_1 = (wchar_t *)FUN_0054ff60(uVar8,uVar34);
            uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
            uVar34 = 3;
            goto code_r0x0073a3b3;
          }
        }
      }
      iVar16 = (**(code **)(*in_ECX + 0x64c))(0x11);
      if (0 < iVar16) {
        *(undefined1 *)(in_ECX + 0xad7) = 1;
      }
      if (in_ECX[0xad6] == 0) {
        param_4 = (int *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x72;
        if (param_4 == (int *)0x0) {
          iVar16 = 0;
        }
        else if ((uint)in_ECX[0x97] < 8) {
          iVar16 = FUN_00472a60(in_ECX + 0x92,u_Effect_Animation_JumpAttackMulti_00d7d260,1);
        }
        else {
          iVar16 = FUN_00472a60(in_ECX[0x92],u_Effect_Animation_JumpAttackMulti_00d7d260,1);
        }
        local_8._0_1_ = 0;
        in_ECX[0xad6] = iVar16;
      }
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 3) {
        param_4 = (int *)0x3f800000;
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        param_4 = (int *)0x3f4ccccd;
        if (iVar16 != 0) {
          param_4 = (int *)0x3f666666;
        }
      }
      FUN_00a25900(param_4,param_4);
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 1) {
        *(undefined1 *)((int)in_ECX + 0x2b5e) = 1;
      }
    }
    iVar16 = FUN_00402060();
    if (iVar16 == 0x11) {
      (**(code **)(*in_ECX + 0x67c))(0x11);
      uVar8 = (**(code **)(*in_ECX + 0x64c))(0x11);
      uVar34 = (**(code **)(*in_ECX + 0x1d0))();
      (**(code **)(*in_ECX + 0x67c))(0x11);
      iVar16 = FUN_00550150(0,uVar8,in_ECX,uVar34,uVar34,0xc);
      param_4 = (int *)(iVar16 + -100);
      FUN_00404560(&param_4);
      *(undefined1 *)(in_ECX + 0xad7) = 1;
      *(undefined1 *)((int)in_ECX + 0x2b5d) = 0;
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if ((iVar16 == 1) && (iVar16 = (**(code **)(*in_ECX + 0x64c))(0x1b), 0 < iVar16)) {
        uVar34 = 1;
        uVar8 = 0xd;
        (**(code **)(*in_ECX + 0x67c))(0xd,1,0);
        iVar16 = FUN_0054ff60(uVar8,uVar34);
        iVar15 = (**(code **)(*in_ECX + 0x64c))(0xd);
        if (iVar16 <= iVar15) {
          *(undefined1 *)((int)in_ECX + 0x2b5d) = 1;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(0xc);
          uVar24 = 0xd;
          piVar4 = in_ECX;
          uVar34 = (**(code **)(*in_ECX + 0x64c))(0xd);
          uVar20 = 3;
          uVar38 = 0xd;
          (**(code **)(*in_ECX + 0x67c))(0xd,3,uVar34);
          iVar16 = FUN_004caa20(uVar38,uVar20,uVar34,uVar24,piVar4);
          param_4 = (int *)(iVar16 + -100);
          FUN_0040fc10(&param_4);
          iVar16 = *(int *)(*(int *)((int)param_2 + 4) + 4);
          in_ECX[0xacd] = iVar16;
          if (iVar16 == 0) {
            piVar4 = in_ECX + 0xad0;
            iVar16 = 2;
            do {
              (**(code **)(*in_ECX + 0xfc))(piVar4[-2]);
              (**(code **)(*in_ECX + 0xfc))(*piVar4);
              piVar4 = piVar4 + 1;
              iVar16 = iVar16 + -1;
            } while (iVar16 != 0);
            iVar16 = *in_ECX;
            uVar8 = (**(code **)(iVar16 + 0x38c))(0x17);
            (**(code **)(iVar16 + 0xf0))(uVar8);
            if (in_ECX[0xace] == 0) {
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x73;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7d1d0;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7d1d0,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xace] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x74;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7d140;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7d140,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xacf] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x75;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7d0b0;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7d0b0,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xad0] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x76;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7d020;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7d020,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xad1] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x77;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7cf90;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7cf90,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xad2] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x78;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7cf00;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7cf00,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xad3] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x79;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7ce70;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7ce70,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xad4] = iVar16;
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x7a;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_JumpAttackMulti_00d7cde0;
                uVar8 = FUN_004334b0(u_Effect_Animation_JumpAttackMulti_00d7cde0,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xad5] = iVar16;
            }
            iVar16 = (**(code **)(*in_ECX + 0x620))();
            if (iVar16 == 3) {
              param_4 = (int *)0x3f800000;
            }
            else {
              iVar16 = (**(code **)(*in_ECX + 0x620))();
              param_4 = (int *)0x3f4ccccd;
              if (iVar16 != 0) {
                param_4 = (int *)0x3f666666;
              }
            }
            piVar4 = param_4;
            param_1 = (wchar_t *)0x2;
            do {
              FUN_00a25900(piVar4,piVar4);
              FUN_00a25900(piVar4,piVar4);
              FUN_00a25900(piVar4,piVar4);
              FUN_00a25900(piVar4,piVar4);
              param_1 = (wchar_t *)((int)param_1 + -1);
            } while (param_1 != (wchar_t *)0x0);
            (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xace],0,0,0,0,0,0,0,1);
            iVar16 = in_ECX[0xacf];
          }
          else {
            iVar16 = *in_ECX;
            uVar8 = (**(code **)(iVar16 + 0x38c))(0x18,uVar8);
            (**(code **)(iVar16 + 0xf0))(uVar8);
            (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xad0],0,0,0,0,0,0,0,1);
            iVar16 = in_ECX[0xad1];
          }
          (**(code **)(*in_ECX + 0xf8))(1,iVar16,0,0,0,0,0,0,0,1);
          FUN_00a27360();
        }
      }
    }
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
    (**(code **)(iVar16 + 0x10c))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x694))(2);
    uVar34 = FUN_00bffdcd(uVar8);
    FUN_00402e80(uVar8,uVar34);
    *(undefined1 *)((int)in_ECX + 0x2b5f) = 1;
    break;
  case (wchar_t *)0x8:
    FUN_00402d60(auStack_ac,0,0xffffffff);
    iVar16 = FUN_00402060();
    if ((iVar16 != -1) && (iVar16 = FUN_00402060(), iVar16 != 0x43)) {
      (**(code **)(*in_ECX + 0x774))(0);
    }
    in_ECX[0x906] = -1;
    *(undefined1 *)(in_ECX + 0xab2) = 0;
    iVar16 = FUN_00402060();
    if (iVar16 == 0x2e) {
      iVar16 = *in_ECX;
      uVar8 = FUN_005270f0(0xb);
      (**(code **)(iVar16 + 0x198))(uVar8);
      (**(code **)(*in_ECX + 0x67c))(0x2e);
      uVar8 = (**(code **)(*in_ECX + 0x64c))(0x2e);
      (**(code **)(*in_ECX + 0x10c))(u_UPPER_SLASH_01_00d736cc,0xffffffff,0,0);
      if (in_ECX[0xceb] == 0) {
        param_4 = (int *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x7b;
        if (param_4 == (int *)0x0) {
          iVar16 = 0;
        }
        else if ((uint)in_ECX[0x97] < 8) {
          iVar16 = FUN_00472a60(in_ECX + 0x92,u_Effect_Animation_UpperSlash1_ani_00d7cd98,1);
        }
        else {
          iVar16 = FUN_00472a60(in_ECX[0x92],u_Effect_Animation_UpperSlash1_ani_00d7cd98,1);
        }
        local_8._0_1_ = 0;
        in_ECX[0xceb] = iVar16;
        param_4 = (int *)FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x7c;
        if (param_4 == (int *)0x0) {
          iVar16 = 0;
        }
        else if ((uint)in_ECX[0x97] < 8) {
          iVar16 = FUN_00472a60(in_ECX + 0x92,u_Effect_Animation_UpperSlash2_ani_00d7cd50,1);
        }
        else {
          iVar16 = FUN_00472a60(in_ECX[0x92],u_Effect_Animation_UpperSlash2_ani_00d7cd50,1);
        }
        local_8._0_1_ = 0;
        in_ECX[0xcec] = iVar16;
      }
      *(undefined1 *)(in_ECX + 0xced) = 0;
      uVar34 = (**(code **)(*in_ECX + 0x1d0))();
      iVar16 = FUN_00550150(0,uVar8,in_ECX,uVar34,uVar34,0xc);
      param_4 = (int *)(iVar16 + -100);
      FUN_00404560(&param_4);
      uVar34 = (**(code **)(*in_ECX + 0x1d0))();
      iVar16 = FUN_00550150(3,uVar8,in_ECX,uVar34,uVar34,0);
      param_4 = (int *)(iVar16 * 100);
      iVar16 = FUN_00402060();
      param_4 = (int *)(float)((int)param_4 / (iVar16 + 100));
      FUN_00404560(&param_4);
      iVar16 = (**(code **)(*in_ECX + 0x620))();
      if (iVar16 == 3) {
        param_4 = (int *)0x3f800000;
      }
      else {
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 0) {
          param_4 = (int *)0x3f4ccccd;
        }
        else {
          iVar16 = (**(code **)(*in_ECX + 0x620))();
          param_4 = (int *)0x3f8ccccd;
          if (iVar16 != 5) {
            param_4 = (int *)0x3f666666;
          }
        }
      }
      param_2 = (int *)0x2;
      do {
        FUN_00a25900(param_4,param_4);
        param_2 = (int *)((int)param_2 + -1);
      } while (param_2 != (int *)0x0);
      param_4 = (int *)FUN_00550080(1,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      FUN_00404560(&param_4);
      param_4 = (int *)FUN_00550080(2,uVar8,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      FUN_00404560(&param_4);
      *(undefined1 *)(in_ECX + 0xaaf) = 0;
      (**(code **)(*in_ECX + 0x2e0))(1,1);
    }
    else {
      iVar16 = FUN_00402060();
      if (iVar16 == 0x43) {
        iVar16 = FUN_00402060();
        in_ECX[0xab1] = iVar16;
        in_ECX[0x906] = in_ECX[0xab0] + 1;
        iVar16 = (**(code **)(*in_ECX + 0x620))();
        if (iVar16 == 0) {
          iVar16 = FUN_00402060();
          if (iVar16 == 2) {
            if (in_ECX[0xab3] == 0) {
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x7d;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_WeaponCombo_Sho_00d7cd00;
                uVar8 = FUN_004334b0(u_Effect_Animation_WeaponCombo_Sho_00d7cd00,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xab3] = iVar16;
            }
            (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xab3],0,0,0,0,1,0,0,1);
          }
        }
        else if (iVar16 == 1) {
          iVar16 = FUN_00402060();
          if (iVar16 == 3) {
            if (in_ECX[0xab4] == 0) {
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x7e;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_WeaponCombo_Bla_00d7ccb0;
                uVar8 = FUN_004334b0(u_Effect_Animation_WeaponCombo_Bla_00d7ccb0,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xab4] = iVar16;
            }
            (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xab4],0,0,0,0,1,0,0,1);
          }
        }
        else if (iVar16 == 2) {
          iVar16 = FUN_00402060();
          if (iVar16 == 3) {
            if (in_ECX[0xab5] == 0) {
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x7f;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_WeaponCombo_Blu_00d7cc60;
                uVar8 = FUN_004334b0(u_Effect_Animation_WeaponCombo_Blu_00d7cc60,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xab5] = iVar16;
            }
            (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xab5],0,0,0,0,1,0,0,1);
          }
        }
        else if (iVar16 == 3) {
          iVar16 = FUN_00402060();
          if (iVar16 == 1) {
            if (in_ECX[0xab6] == 0) {
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x80;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_WeaponCombo_Hea_00d7cc10;
                uVar8 = FUN_004334b0(u_Effect_Animation_WeaponCombo_Hea_00d7cc10,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xab6] = iVar16;
            }
            uVar34 = 1;
            uVar8 = 0;
            (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xab6],0,0,0,0,1,0,0,1);
            (**(code **)(*in_ECX + 0x67c))(0x43,0);
            iVar16 = FUN_0054ff60(uVar8,uVar34);
            if (iVar16 == 1) {
              *(undefined1 *)(in_ECX + 0xab2) = 1;
            }
          }
        }
        else if (iVar16 == 5) {
          iVar16 = FUN_00402060();
          if (iVar16 == 2) {
            if (in_ECX[0xab8] == 0) {
              param_4 = (int *)FUN_00403c50(0x1e8);
              local_8._0_1_ = 0x81;
              if (param_4 == (int *)0x0) {
                iVar16 = 0;
              }
              else {
                uVar34 = 1;
                pwVar19 = u_Effect_Animation_WeaponCombo_Lig_00d7cbc0;
                uVar8 = FUN_004334b0(u_Effect_Animation_WeaponCombo_Lig_00d7cbc0,1);
                iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
              }
              local_8._0_1_ = 0;
              in_ECX[0xab8] = iVar16;
            }
            (**(code **)(*in_ECX + 0xf8))(4,in_ECX[0xab8],0,0,0,0,1,0,0,1);
          }
          iVar16 = FUN_00402060();
          if (iVar16 < 4) {
            iVar16 = FUN_00402060();
            if (in_ECX[iVar16 * 6 + 0xab9] == 0) {
              iVar16 = 0;
              do {
                param_4 = (int *)FUN_00403c50(0x1e8);
                local_8._0_1_ = 0x82;
                if (param_4 == (int *)0x0) {
                  iVar15 = 0;
                }
                else {
                  uVar38 = 1;
                  iVar15 = FUN_00402060(iVar16 + 1,1);
                  uVar8 = FUN_00a52aa0(0,u_Effect_Animation_WeaponCombo_Lig_00d7cb68,iVar15 + 1);
                  uVar34 = FUN_004334b0(uVar8);
                  iVar15 = FUN_00472a60(uVar34,uVar8,uVar38);
                }
                local_8._0_1_ = 0;
                iVar5 = FUN_00402060();
                iVar5 = iVar16 + iVar5 * 6;
                iVar16 = iVar16 + 1;
                in_ECX[iVar5 + 0xab9] = iVar15;
              } while (iVar16 < 6);
            }
            iVar16 = 0;
            do {
              if ((iVar16 == 2) || (iVar16 == 5)) {
                uVar8 = 1;
              }
              else {
                uVar8 = 0;
              }
              if (iVar16 < 3) {
                param_4 = (int *)(iVar16 + -3);
              }
              else {
                param_4 = (int *)(iVar16 + -2);
              }
              iVar15 = *in_ECX;
              iVar5 = FUN_00402060(0,0,0,0,uVar8,0,0,1);
              (**(code **)(iVar15 + 0xf8))(param_4,in_ECX[iVar16 + iVar5 * 6 + 0xab9]);
              iVar16 = iVar16 + 1;
            } while (iVar16 < 6);
          }
        }
      }
      else {
        iVar16 = FUN_00402060();
        if (iVar16 == -1) {
          iVar16 = FUN_00402060();
          in_ECX[0xab0] = iVar16;
          if ((char)in_ECX[0xca0] == '\0') {
            if ((char)in_ECX[0xc24] != '\0') {
              if (in_ECX[0xc25] == 0) {
                param_4 = (int *)0x0;
                uVar3 = (undefined1)local_8;
                do {
                  local_8._0_1_ = uVar3;
                  iVar16 = 0;
                  param_3 = in_ECX + (int)param_4 * 4 + 0xc25;
                  uVar3 = (undefined1)local_8;
                  do {
                    local_8._0_1_ = uVar3;
                    if ((*(int *)(DAT_01002848 + 0x19a8) == 1) || ((iVar16 != 1 && (iVar16 != 3))))
                    {
                      param_1 = u_Effect_Animation_Frenzy_Sword_d__00d7ca70;
                    }
                    else {
                      param_1 = u_Effect_Animation_Frenzy__TN_Swor_00d7cac0;
                    }
                    pvStack_18 = (void *)FUN_00403c50(0x1e8);
                    local_8._0_1_ = 0x84;
                    if (pvStack_18 == (void *)0x0) {
                      iVar15 = 0;
                    }
                    else {
                      if ((uint)in_ECX[0x97] < 8) {
                        param_2 = in_ECX + 0x92;
                      }
                      else {
                        param_2 = (int *)in_ECX[0x92];
                      }
                      uVar34 = 1;
                      uVar8 = FUN_00a52aa0(0,param_1,(int)param_4 + 1,iVar16 + 1,1);
                      iVar15 = FUN_00472a60(param_2,uVar8,uVar34);
                    }
                    *param_3 = iVar15;
                    iVar16 = iVar16 + 1;
                    param_3 = param_3 + 1;
                    local_8._0_1_ = 0;
                    uVar3 = (undefined1)local_8;
                    local_8._0_1_ = 0;
                  } while (iVar16 < 4);
                  param_4 = (int *)((int)param_4 + 1);
                } while ((int)param_4 < 4);
              }
              iVar16 = 0;
              do {
                if ((iVar16 == 1) || (iVar16 == 3)) {
                  uVar8 = 1;
                }
                else {
                  uVar8 = 0;
                }
                if (iVar16 < 2) {
                  param_4 = (int *)(iVar16 + -2);
                }
                else {
                  param_4 = (int *)(iVar16 + -1);
                }
                iVar15 = *in_ECX;
                iVar5 = FUN_00402060(0,0,0,0,uVar8,0,0,1);
                (**(code **)(iVar15 + 0xf8))(param_4,in_ECX[iVar16 + iVar5 * 4 + 0xc25]);
                iVar16 = iVar16 + 1;
              } while (iVar16 < 4);
              uVar34 = 2;
              uVar8 = 0x4c;
              piVar7 = in_ECX;
              (**(code **)(*in_ECX + 0x67c))(0x4c,2);
              iVar16 = FUN_0054ff60(uVar8,uVar34);
              iVar15 = FUN_00402060();
              param_4 = (int *)((iVar16 * (iVar15 + 100)) / 100 + -100);
              FUN_00404560(&param_4);
              piVar4 = in_ECX;
              (**(code **)(*in_ECX + 0x67c))(0x4c,3);
              iVar16 = FUN_0054ff60(piVar4,piVar7);
              param_4 = (int *)(float)iVar16;
              fVar18 = (float10)FUN_004333b0();
              param_4 = (int *)(float)(fVar18 * (float10)(float)param_4 * (float10)_DAT_00cc10ac);
              FUN_00404560(&param_4);
            }
          }
          else {
            iVar16 = FUN_00402060();
            if (iVar16 == 2) {
              *(undefined1 *)((int)in_ECX + 0x3281) = 0;
            }
            param_1 = (wchar_t *)(in_ECX + 0xca1);
            if (in_ECX[0xca1] == 0) {
              iVar16 = 0;
              uVar3 = (undefined1)local_8;
              do {
                local_8._0_1_ = uVar3;
                iVar15 = FUN_00403c50(0x1e8);
                local_8._0_1_ = 0x83;
                if (iVar15 == 0) {
                  iVar15 = 0;
                }
                else {
                  if ((uint)in_ECX[0x97] < 8) {
                    param_4 = in_ECX + 0x92;
                  }
                  else {
                    param_4 = (int *)in_ECX[0x92];
                  }
                  uVar34 = 1;
                  uVar8 = FUN_00a52aa0(0,u_Effect_Animation_WaveEye_Attack__00d7cb18,iVar16 + 1,1);
                  iVar15 = FUN_00472a60(param_4,uVar8,uVar34);
                }
                *(int *)param_1 = iVar15;
                iVar16 = iVar16 + 1;
                param_1 = (wchar_t *)((int)param_1 + 4);
                local_8._0_1_ = 0;
                uVar3 = (undefined1)local_8;
                local_8._0_1_ = 0;
              } while (iVar16 < 3);
            }
            iVar16 = *in_ECX;
            iVar15 = FUN_00402060(0,0,0,0,1,0,0,1);
            (**(code **)(iVar16 + 0xf8))(1,in_ECX[iVar15 + 0xca1]);
          }
        }
      }
    }
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x694))(0,0xffffffff,0,0);
    (**(code **)(iVar16 + 0x10c))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x694))(2);
    goto LAB_0073b40f;
  case (wchar_t *)0xa:
    if (in_ECX[0x90a] != 0) break;
    iVar16 = *in_ECX;
    uVar8 = FUN_00402060();
    (**(code **)(iVar16 + 0x67c))(uVar8);
    param_4 = (int *)*in_ECX;
    uVar8 = FUN_00402060();
    piVar4 = (int *)(**(code **)((int)param_4 + 0x64c))(uVar8);
    param_4 = piVar4;
    iVar16 = FUN_00402060();
    if (iVar16 == 0x17) {
      if (in_ECX[0xbea] == 0) {
        iVar16 = FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x85;
        if (iVar16 == 0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_GiveBloodCharge_00d7ca20;
          uVar8 = FUN_004334b0(u_Effect_Animation_GiveBloodCharge_00d7ca20,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbea] = iVar16;
        iVar16 = FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x86;
        if (iVar16 == 0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_GiveBloodCharge_00d7c9d0;
          uVar8 = FUN_004334b0(u_Effect_Animation_GiveBloodCharge_00d7c9d0,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbeb] = iVar16;
        iVar16 = FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x87;
        if (iVar16 == 0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_GiveBloodShoot1_00d7c980;
          uVar8 = FUN_004334b0(u_Effect_Animation_GiveBloodShoot1_00d7c980,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbec] = iVar16;
        iVar16 = FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x88;
        if (iVar16 == 0) {
          iVar16 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_GiveBloodShoot2_00d7c930;
          uVar8 = FUN_004334b0(u_Effect_Animation_GiveBloodShoot2_00d7c930,1);
          iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        in_ECX[0xbed] = iVar16;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0) {
        iVar16 = *in_ECX;
        uVar8 = FUN_005270f0(9);
        (**(code **)(iVar16 + 0x198))(uVar8);
        (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbea],0,0,0,0,0,0,0,1);
        (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xbeb],0,0,0,0,0,0,0,1);
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 != 1) break;
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xbea]);
      (**(code **)(*in_ECX + 0xfc))(in_ECX[0xbeb]);
      (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbec],0,0,0,0,0,0,0,1);
      (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xbed],0,0,0,0,0,0,0,1);
      if (in_ECX[0x916] != 0) {
        iVar16 = FUN_00403c50(0xcc);
        local_8._0_1_ = 0x89;
        if (iVar16 == 0) {
          piVar4 = (int *)0x0;
        }
        else {
          uVar34 = 1;
          uVar8 = FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          piVar4 = (int *)FUN_004e5390(uVar8,uVar34);
        }
        local_8._0_1_ = 0;
        iVar15 = FUN_00402120();
        iVar16 = in_ECX[0x916];
        param_3 = (int *)*piVar4;
        uVar8 = 0;
        if (iVar15 == 4) {
          uVar38 = 0xc;
          uVar34 = (**(code **)(*in_ECX + 0x1d0))(iVar16,0xc);
          iVar16 = FUN_005b3f80(1,param_4,in_ECX,uVar34,iVar16,uVar38,uVar8);
        }
        else {
          uVar38 = 3;
          uVar34 = (**(code **)(*in_ECX + 0x1d0))(iVar16,3,0);
          iVar16 = FUN_005b3f80(1,param_4,in_ECX,uVar34,iVar16,uVar38,uVar8);
        }
        (*(code *)param_3[0x22])(0,0,(float)iVar16);
        iVar16 = (**(code **)(*in_ECX + 0x64c))(0x3f);
        if (0 < iVar16) {
          param_3 = (int *)*piVar4;
          iVar16 = FUN_00550080(3,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          (**(code **)((int)param_3 + 0x88))(10,0,(float)iVar16);
          param_3 = (int *)*piVar4;
          iVar16 = FUN_00550080(4,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          (**(code **)((int)param_3 + 0x88))(0xb,0,(float)iVar16);
          iVar16 = in_ECX[0x916];
          param_3 = (int *)*piVar4;
          uVar38 = 0;
          uVar34 = 1;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(iVar16,1,0);
          iVar16 = FUN_005b3f80(5,param_4,in_ECX,uVar8,iVar16,uVar34,uVar38);
          (**(code **)((int)param_3 + 0x88))(5,1,(float)-iVar16);
          iVar16 = in_ECX[0x916];
          param_3 = (int *)*piVar4;
          uVar38 = 0;
          uVar34 = 1;
          uVar8 = (**(code **)(*in_ECX + 0x1d0))(iVar16,1,0);
          iVar16 = FUN_005b3f80(6,param_4,in_ECX,uVar8,iVar16,uVar34,uVar38);
          (*(code *)param_3[0x22])(0x20,1,(float)-iVar16);
        }
        (**(code **)(*piVar4 + 0x48))(in_ECX[0x916]);
        (**(code **)(*(int *)in_ECX[0x916] + 0x10c))(u_SACRIFICE_CURED_00d7c910,0xffffffff,0,0);
        if ((int *)in_ECX[0x916] != in_ECX) {
          iVar16 = FUN_0054ff60(0,in_ECX);
          iVar15 = (**(code **)(*in_ECX + 0x238))();
          iVar5 = FUN_00550080(0,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          param_4 = (int *)((iVar5 * ((iVar16 * iVar15) / 100)) / 100);
          iVar16 = FUN_00403c50(0x100);
          local_8._0_1_ = 0x8a;
          if (iVar16 == 0) {
            piVar4 = (int *)0x0;
          }
          else {
            piVar4 = (int *)FUN_00469bb0((float)(int)param_4,500,0,1);
          }
          local_8._0_1_ = 0;
          (**(code **)(*piVar4 + 0x48))(in_ECX[0x916]);
        }
      }
      (**(code **)(*in_ECX + 0x10c))(u_SM_SACRIFICE_CAST_00d7c8ec,0xffffffff,0,0);
      pwVar19 = u_SACRIFICE_BEGIN_00d7c8cc;
    }
    else {
      iVar16 = FUN_00402060();
      if (iVar16 == 0x18) {
        iVar16 = FUN_00402060();
        if (iVar16 == 0) {
          iVar15 = iVar16;
          (**(code **)(*in_ECX + 0x10c))(u_SM_BLOOD_CAST_00d7c8b0,0xffffffff,0,0);
          FUN_00402060();
          (**(code **)(*in_ECX + 0x67c))(0x18);
          FUN_0054e880(iVar16,iVar15);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
            uVar24 = 0x18;
            piVar4 = in_ECX;
            uVar34 = (**(code **)(*in_ECX + 0x64c))(0x18);
            uVar20 = 0;
            uVar38 = 0x18;
            (**(code **)(*in_ECX + 0x67c))(0x18,0,uVar34);
            iVar16 = FUN_004caa20(uVar38,uVar20,uVar34,uVar24,piVar4);
            iVar15 = FUN_0073d650(uVar8);
            iVar16 = (iVar16 * iVar15) / 100;
            (**(code **)(*in_ECX + 0x2b8))(0x4e2a,iVar16,0,0,0,0,0,4,0,0,0,0,0);
            (**(code **)(*in_ECX + 0x2b8))(0x4e29,iVar16,0,0,0,0x32,0,4,0,0,0,0,0);
            uVar8 = (**(code **)(*in_ECX + 0x1d0))(0);
            uVar24 = 0x18;
            piVar4 = in_ECX;
            uVar34 = (**(code **)(*in_ECX + 0x64c))(0x18);
            uVar20 = 2;
            uVar38 = 0x18;
            (**(code **)(*in_ECX + 0x67c))(0x18,2,uVar34);
            iVar16 = FUN_004caa20(uVar38,uVar20,uVar34,uVar24,piVar4);
            iVar15 = FUN_0073d650(uVar8);
            (**(code **)(*in_ECX + 0x2b8))(0x4e3f,(iVar16 * iVar15) / 100,0,0,0,0,0,4,0,0,0,0,0);
          }
        }
        else {
          iVar16 = FUN_00402060();
          if (iVar16 == 1) {
            FUN_0049c090();
          }
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x22) {
        iVar16 = FUN_00402060();
        if ((iVar16 == 0) || (iVar16 = FUN_00402060(), iVar16 != 1)) break;
        iVar16 = FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x8b;
        if (iVar16 == 0) {
          uVar8 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_PinchHpRegen1_a_00d7c868;
          uVar8 = FUN_004334b0(u_Effect_Animation_PinchHpRegen1_a_00d7c868,1);
          uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        iVar16 = FUN_00403c50(0x1fc);
        local_8._0_1_ = 0x8c;
        if (iVar16 == 0) {
          piVar4 = (int *)0x0;
        }
        else {
          piVar4 = (int *)FUN_004abd20(uVar8,1);
        }
        local_8._0_1_ = 0;
        FUN_0050dd70(in_ECX,2,0,piVar4,in_ECX,0,0);
        iVar16 = *piVar4;
        uVar8 = (**(code **)(*in_ECX + 0xc0))();
        (**(code **)(iVar16 + 0xbc))(uVar8);
        iVar16 = *piVar4;
        uVar8 = (**(code **)(*in_ECX + 0x9c))();
        uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
        uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
        (**(code **)(iVar16 + 0x88))(uVar8);
        piVar7 = in_ECX;
        (**(code **)(*piVar4 + 0x48))();
        FUN_00510e80(piVar7);
        iVar16 = FUN_00403c50(0x1e8);
        local_8._0_1_ = 0x8d;
        if (iVar16 == 0) {
          uVar8 = 0;
        }
        else {
          uVar34 = 1;
          pwVar19 = u_Effect_Animation_PinchHpRegen2_a_00d7c820;
          uVar8 = FUN_004334b0(u_Effect_Animation_PinchHpRegen2_a_00d7c820,1);
          uVar8 = FUN_00472a60(uVar8,pwVar19,uVar34);
        }
        local_8._0_1_ = 0;
        iVar16 = FUN_00403c50(0x1fc);
        local_8._0_1_ = 0x8e;
        if (iVar16 == 0) {
          piVar4 = (int *)0x0;
        }
        else {
          piVar4 = (int *)FUN_004abd20(uVar8,1);
        }
        local_8._0_1_ = 0;
        FUN_0050dd70(in_ECX,2,0,piVar4,in_ECX,0,0);
        iVar16 = *piVar4;
        uVar8 = (**(code **)(*in_ECX + 0xc0))();
        (**(code **)(iVar16 + 0xbc))(uVar8);
        iVar16 = *piVar4;
        uVar8 = (**(code **)(*in_ECX + 0x9c))();
        uVar8 = (**(code **)(*in_ECX + 0x98))(uVar8);
        uVar8 = (**(code **)(*in_ECX + 0x94))(uVar8);
        (**(code **)(iVar16 + 0x88))(uVar8);
        piVar7 = in_ECX;
        (**(code **)(*piVar4 + 0x48))();
        FUN_00510e80(piVar7);
        piVar4 = param_4;
        iVar16 = FUN_00550080(0,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        param_4 = (int *)FUN_00550080(1,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        iVar15 = FUN_00403c50(0x100);
        local_8._0_1_ = 0x8f;
        if (iVar15 == 0) {
          piVar7 = (int *)0x0;
        }
        else {
          piVar7 = (int *)FUN_00469bb0((float)iVar16,param_4,1,0);
        }
        local_8._0_1_ = 0;
        (**(code **)(*piVar7 + 0x48))();
        param_4 = (int *)FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        iVar16 = FUN_00550080(3,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        if (in_ECX[0xcea] == 0) {
          iVar15 = FUN_00403c50(0xcc);
          local_8._0_1_ = 0x90;
          if (iVar15 == 0) {
            iVar15 = 0;
          }
          else {
            iVar15 = FUN_004e5390(0,1);
          }
          in_ECX[0xcea] = iVar15;
          local_8._0_1_ = 0;
          *(undefined1 *)(iVar15 + 0x4c) = 0;
        }
        (**(code **)(*(int *)in_ECX[0xcea] + 0x8c))();
        (**(code **)(*(int *)in_ECX[0xcea] + 0x88))(5,0,(float)(int)param_4);
        (**(code **)(*(int *)in_ECX[0xcea] + 0x88))(0x22,0,(float)iVar16);
        uVar8 = FUN_00550080(4,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        FUN_004e2df0(uVar8);
        piVar4 = (int *)in_ECX[0xcea];
LAB_0073c488:
        (**(code **)(*piVar4 + 0x48))();
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x19) {
        iVar16 = FUN_00402060();
        if (iVar16 == 1) {
          *(undefined2 *)((int)in_ECX + 0x2f0e) = 0x19;
          (**(code **)(*in_ECX + 0x10c))(u_SM_GHOST_KAZHAN_00d7c800,0xffffffff,0,0);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            iVar16 = *in_ECX;
            uVar8 = (**(code **)(iVar16 + 0x64c))(0x19,0,0,0x7a,0,0,4,0,0,0,0,0);
            (**(code **)(iVar16 + 0x2b8))(0x4e2b,uVar8);
          }
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x24) {
        iVar16 = FUN_00402060();
        if (iVar16 == 1) {
          *(undefined2 *)((int)in_ECX + 0x2f0e) = 0x24;
          (**(code **)(*in_ECX + 0x10c))(u_SM_GHOST_SAYA_00d7c7e4,0xffffffff,0,0);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            iVar16 = *in_ECX;
            uVar8 = (**(code **)(iVar16 + 0x64c))(0x24,0,0,0x7a,0,0,4,0,0,0,0,0);
            (**(code **)(iVar16 + 0x2b8))(0x4e2c,uVar8);
          }
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x29) {
        iVar16 = FUN_00402060();
        if (iVar16 == 1) {
          *(undefined2 *)((int)in_ECX + 0x2f0e) = 0x29;
          (**(code **)(*in_ECX + 0x10c))(u_SM_GHOST_BREMEN_00d7c7c4,0xffffffff,0,0);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            iVar16 = *in_ECX;
            uVar8 = (**(code **)(iVar16 + 0x64c))(0x29,0,0,0x7a,0,0,4,0,0,0,0,0);
            (**(code **)(iVar16 + 0x2b8))(0x4e2d,uVar8);
          }
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x4b) {
        iVar16 = FUN_00402060();
        if (iVar16 == 1) {
          (**(code **)(*in_ECX + 0x10c))(u_SM_RASA_00d7c7b4,0xffffffff,0,0);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            DAT_00f5478c = 0;
            uVar8 = (**(code **)(*in_ECX + 0x3c))();
            FUN_004e2780(uVar8);
            uVar8 = (**(code **)(*in_ECX + 0x40))();
            FUN_004e2780(uVar8);
            iVar16 = *in_ECX;
            uVar8 = (**(code **)(iVar16 + 0x64c))
                              (0x4b,0,0,0x7a,0,0,4,0,DAT_00f5478c,DAT_00f54788,0,0);
            (**(code **)(iVar16 + 0x2b8))(0x4e48,uVar8);
          }
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x2c) {
        iVar16 = FUN_00402060();
        if (iVar16 == 0) {
          (**(code **)(*in_ECX + 0x10c))(u_SM_STONE_SHOWER_00d7c794,0xffffffff,0,0);
        }
        else {
          iVar16 = FUN_00402060();
          if (iVar16 == 1) {
            *(undefined1 *)(in_ECX + 0x6a1) = 1;
            cVar2 = FUN_0049c090();
            if (cVar2 != '\0') {
              iVar16 = *in_ECX;
              uVar8 = (**(code **)(iVar16 + 0x64c))(0x2c,0,0,0,0,0,4,0,0,0,0,0);
              (**(code **)(iVar16 + 0x2b8))(0x4e2e,uVar8);
            }
          }
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x20) {
        iVar16 = FUN_00402060();
        if (iVar16 == 0) {
          (**(code **)(*in_ECX + 0x558))();
          if (in_ECX[0xbee] == 0) {
            param_4 = (int *)FUN_00403c50(0x1e8);
            local_8._0_1_ = 0x91;
            if (param_4 == (int *)0x0) {
              iVar16 = 0;
            }
            else {
              uVar34 = 1;
              pwVar19 = u_Effect_Animation_ReleaseWave1_an_00d7c750;
              uVar8 = FUN_004334b0(u_Effect_Animation_ReleaseWave1_an_00d7c750,1);
              iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
            }
            local_8._0_1_ = 0;
            in_ECX[0xbee] = iVar16;
            param_4 = (int *)FUN_00403c50(0x1e8);
            local_8._0_1_ = 0x92;
            if (param_4 == (int *)0x0) {
              iVar16 = 0;
            }
            else {
              uVar34 = 1;
              pwVar19 = u_Effect_Animation_ReleaseWave2_an_00d7c708;
              uVar8 = FUN_004334b0(u_Effect_Animation_ReleaseWave2_an_00d7c708,1);
              iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
            }
            local_8._0_1_ = 0;
            in_ECX[0xbef] = iVar16;
          }
          (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbee],0,0,0,0,0,0,0,1);
          (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xbef],0,0,0,0,0,0,0,1);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            param_4 = (int *)(**(code **)(*in_ECX + 0x67c))(0x20);
            iVar16 = (**(code **)(*in_ECX + 0x64c))(0x20);
            if (iVar16 < 2) {
              uVar8 = 1;
            }
            else {
              uVar8 = (**(code **)(*in_ECX + 0x64c))(0x20);
            }
            iVar16 = *in_ECX;
            uVar38 = 0;
            uVar34 = (**(code **)(iVar16 + 0x1d0))(0,0,0,0,0,0,4,0,0,0,0,0);
            uVar8 = FUN_004caa20(0,uVar8,in_ECX,uVar34,uVar38);
            (**(code **)(iVar16 + 0x2b8))(0x4e32,uVar8);
          }
          (**(code **)(*in_ECX + 0x2e0))(1,1);
        }
        break;
      }
      iVar16 = FUN_00402060();
      if (iVar16 == 0x2f) {
        iVar16 = FUN_00402060();
        if (iVar16 != 0) {
          iVar16 = FUN_00402060();
          if (iVar16 != 1) break;
          if (in_ECX[0xbf3] == 0) {
            param_4 = (int *)FUN_00403c50(0x8c);
            local_8._0_1_ = 0x94;
            if (param_4 == (int *)0x0) {
              iVar16 = 0;
            }
            else {
              iVar16 = FUN_0073e0c0();
            }
            in_ECX[0xbf3] = iVar16;
            local_8._0_1_ = 0;
            *(undefined1 *)(iVar16 + 0x4c) = 0;
          }
          uVar8 = FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_0073d7b0(uVar8);
          piVar4 = (int *)in_ECX[0xbf3];
          goto LAB_0073c488;
        }
        if (in_ECX[0xbf1] == 0) {
          param_4 = (int *)FUN_00403c50(0x1e8);
          local_8._0_1_ = 0x93;
          if (param_4 == (int *)0x0) {
            iVar16 = 0;
          }
          else {
            uVar34 = 1;
            pwVar19 = u_Effect_Animation_WaveMark_Cast_a_00d7c6c0;
            uVar8 = FUN_004334b0(u_Effect_Animation_WaveMark_Cast_a_00d7c6c0,1);
            iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
          }
          local_8._0_1_ = 0;
          in_ECX[0xbf1] = iVar16;
        }
        iVar16 = FUN_00402060();
        iVar15 = FUN_00402060();
        iVar5 = FUN_00493660();
        param_4 = (int *)(((iVar16 * iVar15) / 1000) / iVar5);
        iVar15 = 0;
        iVar16 = FUN_00493660();
        if (0 < iVar16) {
          do {
            puVar13 = &param_4;
            FUN_00a25c90(iVar15);
            FUN_00455c10(puVar13);
            iVar15 = iVar15 + 1;
            iVar16 = FUN_00493660();
          } while (iVar15 < iVar16);
        }
        (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbf1],0,0,0,0,1,0,0,1);
        (**(code **)(*in_ECX + 0x10c))(u_SM_WAVE_CARVING_00d7c6a0,0xffffffff,0,0);
        pwVar19 = u_WAVE_CARVING_GET_00d7c67c;
      }
      else {
        iVar16 = FUN_00402060();
        if (iVar16 == 0x12) {
          iVar16 = FUN_00402060();
          if (iVar16 != 0) {
            iVar16 = FUN_00402060();
            if (iVar16 == 1) {
              if (in_ECX[0xc1d] == 0) {
                param_4 = (int *)FUN_00403c50(0xd8);
                local_8._0_1_ = 0x95;
                if (param_4 == (int *)0x0) {
                  piVar7 = (int *)0x0;
                }
                else {
                  piVar7 = (int *)FUN_0073e1b0();
                }
                in_ECX[0xc1d] = (int)piVar7;
                local_8._0_1_ = 0;
                iVar16 = (**(code **)(*piVar7 + 0x50))();
                *(undefined1 *)(iVar16 + 0x48) = 0;
              }
              param_4 = (int *)FUN_00550080(0,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
              puVar13 = &param_4;
              (**(code **)(*(int *)in_ECX[0xc1d] + 0x50))(puVar13);
              FUN_00404560(puVar13);
              uVar8 = FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
              uVar34 = FUN_00550080(1,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
              uVar38 = FUN_0054ff60(1,in_ECX);
              FUN_0073d800(uVar38,uVar34,uVar8);
              iVar16 = *(int *)in_ECX[0xc1d];
              pwVar19 = u_Common_CommonEffect_BuffIcon_img_00cd0a58;
              (**(code **)(*DAT_010030d8 + 0x10))
                        (u_Common_CommonEffect_BuffIcon_img_00cd0a58,0x14,0,0xffffffff,0);
              FUN_00af23d0(pwVar19);
              (**(code **)(iVar16 + 0x48))();
            }
            break;
          }
          pwVar19 = (wchar_t *)&DAT_00d7c668;
        }
        else {
          iVar16 = FUN_00402060();
          if (iVar16 == 0x1e) {
            iVar16 = FUN_00402060();
            if (iVar16 != 0) {
              iVar16 = FUN_00402060();
              if (iVar16 == 1) {
                if (in_ECX[0xcee] == 0) {
                  param_4 = (int *)FUN_00403c50(0x1e8);
                  local_8._0_1_ = 0x96;
                  if (param_4 == (int *)0x0) {
                    iVar16 = 0;
                  }
                  else {
                    uVar34 = 1;
                    pwVar19 = u_Effect_Animation_mooncurtain_flo_00d7c5f8;
                    uVar8 = FUN_004334b0(u_Effect_Animation_mooncurtain_flo_00d7c5f8,1);
                    iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                  }
                  local_8._0_1_ = 0;
                  in_ECX[0xcee] = iVar16;
                  param_4 = (int *)FUN_00403c50(0x1e8);
                  local_8._0_1_ = 0x97;
                  if (param_4 == (int *)0x0) {
                    iVar16 = 0;
                  }
                  else {
                    uVar34 = 1;
                    pwVar19 = u_Effect_Animation_mooncurtain_eff_00d7c5a0;
                    uVar8 = FUN_004334b0(u_Effect_Animation_mooncurtain_eff_00d7c5a0,1);
                    iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                  }
                  local_8._0_1_ = 0;
                  in_ECX[0xcef] = iVar16;
                  param_4 = (int *)FUN_00403c50(0x1e8);
                  local_8._0_1_ = 0x98;
                  if (param_4 == (int *)0x0) {
                    iVar16 = 0;
                  }
                  else {
                    uVar34 = 1;
                    pwVar19 = u_Effect_Animation_mooncurtain_eff_00d7c548;
                    uVar8 = FUN_004334b0(u_Effect_Animation_mooncurtain_eff_00d7c548,1);
                    iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                  }
                  local_8._0_1_ = 0;
                  in_ECX[0xcf0] = iVar16;
                  param_4 = (int *)FUN_00403c50(0x1e8);
                  local_8._0_1_ = 0x99;
                  if (param_4 == (int *)0x0) {
                    iVar16 = 0;
                  }
                  else {
                    uVar34 = 1;
                    pwVar19 = u_Effect_Animation_mooncurtain_und_00d7c4f8;
                    uVar8 = FUN_004334b0(u_Effect_Animation_mooncurtain_und_00d7c4f8,1);
                    iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                  }
                  local_8._0_1_ = 0;
                  in_ECX[0xcf1] = iVar16;
                  param_4 = (int *)FUN_00403c50(0x1e8);
                  local_8._0_1_ = 0x9a;
                  if (param_4 == (int *)0x0) {
                    iVar16 = 0;
                  }
                  else {
                    uVar34 = 1;
                    pwVar19 = u_Effect_Animation_mooncurtain_upp_00d7c4a8;
                    uVar8 = FUN_004334b0(u_Effect_Animation_mooncurtain_upp_00d7c4a8,1);
                    iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                  }
                  local_8._0_1_ = 0;
                  in_ECX[0xcf2] = iVar16;
                }
                (**(code **)(*in_ECX + 0xf8))(0xfffffffd,in_ECX[0xcee],0,0,0,1,1,0,0,1);
                (**(code **)(*in_ECX + 0xf8))(0xfffffffe,in_ECX[0xcef],0,0,0,0,1,0,0,1);
                (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xcf1],0,0,0,0,1,0,0,1);
                (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xcf0],0,0,0,0,1,0,0,1);
                (**(code **)(*in_ECX + 0xf8))(2,in_ECX[0xcf2],0,0,0,0,1,0,0,1);
                iVar16 = FUN_0054ff60(1,in_ECX);
                piVar4 = (int *)((float)(iVar16 / 2) * _DAT_00d7c4a0);
                param_4 = piVar4;
                FUN_00a25900(piVar4,piVar4);
                FUN_00a25900(piVar4,piVar4);
                FUN_00a25900(piVar4,piVar4);
                cVar2 = FUN_0049c090();
                if (cVar2 != '\0') {
                  apwStack_50[5] = (wchar_t *)0x0;
                  uVar8 = FUN_004d7a60(apwStack_50 + 5,0x11,iVar16 / 2,1,1,1,0,0xffffffff);
                  FUN_005a1f10(0x1e,uVar8,apwStack_50[5],1);
                }
              }
              break;
            }
            pwVar19 = u_SM_MOON_CURTAIN_00d7c648;
          }
          else {
            iVar16 = FUN_00402060();
            if (iVar16 == 0x54) {
              iVar16 = FUN_00402060();
              if ((iVar16 != 0) && (iVar16 = FUN_00402060(), iVar16 == 1)) {
                if (in_ECX[0xc1e] == 0) {
                  param_4 = (int *)FUN_00403c50(200);
                  local_8._0_1_ = 0x9b;
                  if (param_4 == (int *)0x0) {
                    iVar16 = 0;
                  }
                  else {
                    iVar16 = FUN_0073e390();
                  }
                  in_ECX[0xc1e] = iVar16;
                  local_8._0_1_ = 0;
                  *(undefined1 *)(iVar16 + 0x4c) = 0;
                }
                uVar8 = FUN_00550080(4,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                param_4 = (int *)FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                fVar12 = (float)(int)param_4 * _DAT_00cc8830;
                param_4 = (int *)FUN_00550080(1,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                fVar21 = (float)(int)param_4 * _DAT_00cc10ac;
                param_4 = (int *)FUN_00550080(0,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                FUN_0073d9f0((float)(int)param_4 * _DAT_00cc10ac,fVar21,fVar12,uVar8);
                param_4 = (int *)FUN_00550080(3,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                puVar13 = &param_4;
                (**(code **)(*(int *)in_ECX[0xc1e] + 0x50))(puVar13);
                FUN_00404560(puVar13);
                (**(code **)(*(int *)in_ECX[0xc1e] + 0x48))();
              }
              break;
            }
            iVar16 = FUN_00402060();
            if (iVar16 == 0x4a) {
              iVar16 = FUN_00402060();
              if (iVar16 == 0) {
                FUN_0071b9d0();
                (**(code **)(*in_ECX + 0x10c))(u_SM_BOODONG_START_00d7c47c,0xffffffff,0,0);
              }
              else {
                iVar16 = FUN_00402060();
                if (iVar16 == 1) {
                  FUN_0071b970();
                  *(undefined1 *)(in_ECX + 0xbf4) = 0;
                  FUN_006b5cb0();
                  FUN_00a51f50(0xfa,0xffffffff,1,0);
                  FUN_00a51f70();
                  iVar16 = FUN_0054ff60(4,in_ECX);
                  param_4 = (int *)(iVar16 / 2);
                  cVar2 = FUN_0049c090();
                  if (cVar2 != '\0') {
                    uStack_54 = 0;
                    uVar8 = FUN_0054ff60(5,in_ECX);
                    uVar8 = FUN_004d7a60(&uStack_54,0x11,iVar16 / 2,0,0,1,1,uVar8);
                    DAT_00f5478c = 0;
                    FUN_005b3550(1);
                    FUN_005b8070(uVar8,uStack_54);
                    FUN_005a1f10(0x4a,DAT_00f54788,DAT_00f5478c,1);
                  }
                  if (in_ECX[0xbfa] == 0) {
                    iVar16 = FUN_00403c50(0x1e8);
                    local_8._0_1_ = 0x9c;
                    if (iVar16 == 0) {
                      iVar16 = 0;
                    }
                    else {
                      uVar34 = 1;
                      pwVar19 = u_Effect_Animation_WaveSpinArea_Ci_00d7c428;
                      uVar8 = FUN_004334b0(u_Effect_Animation_WaveSpinArea_Ci_00d7c428,1);
                      iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                    }
                    local_8._0_1_ = 0;
                    in_ECX[0xbfa] = iVar16;
                    FUN_004e26f0(3);
                    iVar16 = FUN_00403c50(0x1e8);
                    local_8._0_1_ = 0x9d;
                    if (iVar16 == 0) {
                      iVar16 = 0;
                    }
                    else {
                      uVar34 = 1;
                      pwVar19 = u_Effect_Animation_WaveSpinArea_Ci_00d7c3c8;
                      uVar8 = FUN_004334b0(u_Effect_Animation_WaveSpinArea_Ci_00d7c3c8,1);
                      iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                    }
                    local_8._0_1_ = 0;
                    in_ECX[0xbfb] = iVar16;
                    FUN_004e26f0(1);
                    iVar16 = FUN_00403c50(0x1e8);
                    local_8._0_1_ = 0x9e;
                    if (iVar16 == 0) {
                      iVar16 = 0;
                    }
                    else {
                      uVar34 = 1;
                      pwVar19 = u_Effect_Animation_WaveSpinArea_Ci_00d7c368;
                      uVar8 = FUN_004334b0(u_Effect_Animation_WaveSpinArea_Ci_00d7c368,1);
                      iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                    }
                    local_8._0_1_ = 0;
                    in_ECX[0xbfc] = iVar16;
                    FUN_004e26f0(1);
                  }
                  (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbfa],0,0,0,1,0,0,0,1);
                  (**(code **)(*in_ECX + 0xf8))(1,in_ECX[0xbfb],0,0,0,0,0,0,0,1);
                  (**(code **)(*in_ECX + 0xf8))(0xffffffff,in_ECX[0xbfc],0,0,0,0,0,0,0,1);
                  fVar12 = (float)(int)param_4;
                  param_4 = (int *)0x3;
                  fVar12 = fVar12 * _DAT_00d7c364;
                  do {
                    FUN_00a25900(fVar12,fVar12);
                    param_4 = (int *)((int)param_4 + -1);
                  } while (param_4 != (int *)0x0);
                  (**(code **)(*in_ECX + 0x10c))(u_BOODONG_CIRCLE_LOOP_00d60030,0x18,0,0);
                }
              }
              break;
            }
            iVar16 = FUN_00402060();
            if (iVar16 == 0x4c) {
              if (in_ECX[0xc22] == 0) {
                iVar16 = FUN_00403c50(0x1e8);
                local_8._0_1_ = 0x9f;
                if (iVar16 == 0) {
                  iVar16 = 0;
                }
                else {
                  uVar34 = 1;
                  pwVar19 = u_Effect_Animation_Frenzy_Cast_ani_00d7c320;
                  uVar8 = FUN_004334b0(u_Effect_Animation_Frenzy_Cast_ani_00d7c320,1);
                  iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                }
                local_8._0_1_ = 0;
                in_ECX[0xc22] = iVar16;
                iVar16 = FUN_00403c50(0x1e8);
                local_8._0_1_ = 0xa0;
                if (iVar16 == 0) {
                  iVar16 = 0;
                }
                else {
                  uVar34 = 1;
                  pwVar19 = u_Effect_Animation_Frenzy_Blast_an_00d7c2d8;
                  uVar8 = FUN_004334b0(u_Effect_Animation_Frenzy_Blast_an_00d7c2d8,1);
                  iVar16 = FUN_00472a60(uVar8,pwVar19,uVar34);
                }
                local_8._0_1_ = 0;
                in_ECX[0xc23] = iVar16;
              }
              iVar16 = *in_ECX;
              iVar15 = FUN_00402060(0,0,0,0,0,0,0,1);
              (**(code **)(iVar16 + 0xf8))(1,in_ECX[iVar15 + 0xc22]);
              iVar16 = FUN_00402060();
              if (iVar16 != 0) {
                iVar16 = FUN_00402060();
                if (iVar16 == 1) {
                  if (in_ECX[0xc21] == 0) {
                    iVar16 = FUN_00403c50(0xe4);
                    local_8._0_1_ = 0xa1;
                    if (iVar16 == 0) {
                      piVar4 = (int *)0x0;
                    }
                    else {
                      piVar4 = (int *)FUN_0073e760();
                    }
                    in_ECX[0xc21] = (int)piVar4;
                    local_8._0_1_ = 0;
                    iVar16 = (**(code **)(*piVar4 + 0x50))();
                    *(undefined1 *)(iVar16 + 0x48) = 0;
                  }
                  iVar16 = FUN_00402120();
                  piVar4 = param_4;
                  if (iVar16 == 4) {
                    uVar8 = FUN_00550080(4,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    param_4 = (int *)FUN_00550080(3,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    fVar12 = (float)(int)param_4 * _DAT_00cc8830;
                    iVar16 = FUN_00550080(0xf,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    param_4 = (int *)(float)iVar16;
                    FUN_00448480(2);
                    uVar34 = FUN_00c01544(fVar12,uVar8);
                    param_4 = (int *)FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    fVar21 = (float)(int)param_4 * _DAT_00cc46c8;
                    iVar16 = FUN_00550080(1,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    param_4 = (int *)(float)iVar16;
                    fVar18 = (float10)FUN_00448480(2);
                    fVar18 = fVar18 * (float10)(float)param_4;
                  }
                  else {
                    uVar8 = FUN_00550080(4,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    param_4 = (int *)FUN_00550080(3,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    fVar12 = (float)(int)param_4 * _DAT_00cc8830;
                    iVar16 = FUN_00550080(0xf,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    param_4 = (int *)(float)iVar16;
                    FUN_00448c10();
                    uVar34 = FUN_00c01544(fVar12,uVar8);
                    param_4 = (int *)FUN_00550080(2,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    fVar21 = (float)(int)param_4 * _DAT_00cc46c8;
                    iVar16 = FUN_00550080(1,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                    param_4 = (int *)(float)iVar16;
                    fVar18 = (float10)FUN_00448c10();
                    fVar18 = fVar18 * (float10)(float)param_4;
                  }
                  FUN_0073d890((float)(fVar18 * (float10)_DAT_00cc8830),fVar21,uVar34,fVar12,uVar8);
                  (**(code **)(*(int *)in_ECX[0xc21] + 0x48))();
                  (**(code **)(*in_ECX + 0x10c))(u_FLENSE_CHARGE_00d7c2a4,0xffffffff,0,0);
                }
                break;
              }
              iVar16 = FUN_00402060();
              iVar15 = FUN_00402060();
              iVar5 = FUN_00493660();
              param_4 = (int *)(((iVar16 * iVar15) / 1000) / iVar5);
              iVar15 = 0;
              iVar16 = FUN_00493660();
              if (0 < iVar16) {
                do {
                  puVar13 = &param_4;
                  FUN_00a25c90(iVar15);
                  FUN_00455c10(puVar13);
                  iVar15 = iVar15 + 1;
                  iVar16 = FUN_00493660();
                } while (iVar15 < iVar16);
              }
              (**(code **)(*in_ECX + 0x10c))(u_SM_FLENSE_00d7c2c0,0xffffffff,0,0);
              pwVar19 = u_FLENSE_GET_00d53284;
            }
            else {
              iVar16 = FUN_00402060();
              if (iVar16 == 0x55) {
                iVar16 = FUN_00402060();
                if ((iVar16 != 0) && (iVar16 = FUN_00402060(), iVar16 == 1)) {
                  if (in_ECX[0xc35] == 0) {
                    iVar16 = FUN_00403c50(0x110);
                    local_8._0_1_ = 0xa2;
                    if (iVar16 == 0) {
                      iVar16 = 0;
                    }
                    else {
                      iVar16 = FUN_0073e500();
                    }
                    in_ECX[0xc35] = iVar16;
                    local_8._0_1_ = 0;
                    *(undefined1 *)(iVar16 + 0x4c) = 0;
                    iVar16 = FUN_00403c50(0xcc);
                    local_8._0_1_ = 0xa3;
                    if (iVar16 == 0) {
                      iVar16 = 0;
                    }
                    else {
                      iVar16 = FUN_004e5390(0,0);
                    }
                    in_ECX[0xc36] = iVar16;
                    local_8._0_1_ = 0;
                    *(undefined1 *)(iVar16 + 0x4c) = 0;
                  }
                  uVar8 = FUN_0054ff60(0xc,in_ECX);
                  uVar34 = FUN_0054ff60(0xb,in_ECX);
                  uVar38 = FUN_0054ff60(10,in_ECX);
                  iVar16 = FUN_0054ff60(9,in_ECX);
                  fVar12 = (float)iVar16 * _DAT_00cc10ac;
                  iVar16 = FUN_0054ff60(8,in_ECX);
                  fVar21 = (float)iVar16 * _DAT_00cc10ac;
                  iVar16 = FUN_0054ff60(7,in_ECX);
                  fVar25 = (float)iVar16 * _DAT_00cc10ac;
                  iVar16 = FUN_0054ff60(6,in_ECX);
                  fVar23 = (float)iVar16 * _DAT_00cc10ac;
                  iVar16 = FUN_0054ff60(5,in_ECX);
                  fVar33 = (float)iVar16 * _DAT_00cc10ac;
                  iVar16 = FUN_0054ff60(4,in_ECX);
                  fVar32 = (float)iVar16 * _DAT_00cc10ac;
                  uVar20 = FUN_0054ff60(3,in_ECX);
                  uVar24 = FUN_0054ff60(2,in_ECX);
                  FUN_0071b2f0(uVar24,uVar20,fVar32,fVar33,fVar23,fVar25,fVar21,fVar12,uVar38,uVar34
                               ,uVar8);
                  (**(code **)(*(int *)in_ECX[0xc35] + 0x48))();
                  (**(code **)(*(int *)in_ECX[0xc36] + 0x8c))();
                  iVar16 = *(int *)in_ECX[0xc36];
                  iVar15 = FUN_00550080(6,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                  (**(code **)(iVar16 + 0x88))(10,0,(float)iVar15);
                  iVar16 = *(int *)in_ECX[0xc36];
                  param_4 = (int *)FUN_00550080(8,param_4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                  (**(code **)(iVar16 + 0x88))(0xb,0,(float)(int)param_4);
                  (**(code **)(*(int *)in_ECX[0xc36] + 0x48))();
                }
                break;
              }
              iVar16 = FUN_00402060();
              if (iVar16 != 0x52) break;
              iVar16 = FUN_00402060();
              if (iVar16 != 0) {
                iVar16 = FUN_00402060();
                if (iVar16 == 1) {
                  if (in_ECX[0xb90] == 0) {
                    param_4 = (int *)FUN_00403c50(0x90);
                    local_8._0_1_ = 0xa4;
                    if (param_4 == (int *)0x0) {
                      iVar16 = 0;
                    }
                    else {
                      iVar16 = FUN_0073e2c0();
                    }
                    in_ECX[0xb90] = iVar16;
                    local_8._0_1_ = 0;
                    *(undefined1 *)(iVar16 + 0x4c) = 0;
                  }
                  param_4 = (int *)FUN_00550080(0,piVar4,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
                  puVar13 = &param_4;
                  (**(code **)(*(int *)in_ECX[0xb90] + 0x50))(puVar13);
                  FUN_00404560(puVar13);
                  (**(code **)(*(int *)in_ECX[0xb90] + 0x48))();
                  (**(code **)(*in_ECX + 0x10c))(&DAT_00d7c274,0xffffffff,0,0);
                  (**(code **)(*in_ECX + 0x10c))(u_KALA_SUMMON_00d7c25c,0xffffffff,0,0);
                }
                break;
              }
              pwVar19 = (wchar_t *)&DAT_00d7c28c;
            }
          }
        }
      }
    }
    goto LAB_0073d413;
  case (wchar_t *)0xc:
    iVar16 = *in_ECX;
    uVar8 = (**(code **)(iVar16 + 0x694))(1,0xffffffff,0,0);
    (**(code **)(iVar16 + 0x10c))(uVar8);
    uVar8 = (**(code **)(*in_ECX + 0x694))(3);
LAB_0073b40f:
    uVar34 = FUN_00bffdcd(uVar8);
    FUN_00402e80(uVar8,uVar34);
    break;
  case (wchar_t *)0xe:
    iVar16 = in_ECX[0x93a];
    if (iVar16 == 0xb0) {
      pwVar19 = u_SM_ANCIENT_MEMORY_00d7c238;
    }
    else {
      if (iVar16 == 0xaf) {
        (**(code **)(*in_ECX + 0x10c))(u_SM_LEAP_BUFF_00d7c21c,0xffffffff,0,0);
        break;
      }
      if (iVar16 == 0x28) {
        pwVar19 = u_SM_CONGESTION_00d7c200;
      }
      else {
        if (iVar16 == 0x26) {
          (**(code **)(*in_ECX + 0x10c))(u_SM_OVERDRIVE_00d7c1e4,0xffffffff,0,0);
          break;
        }
        if (iVar16 != 0x34) break;
        pwVar19 = u_SM_KILL_WAVE_00d7c1c8;
      }
    }
LAB_0073d413:
    (**(code **)(*in_ECX + 0x10c))(pwVar19,0xffffffff,0,0);
  }
  if (7 < local_94) {
    _free(local_a8);
  }
  *unaff_FS_OFFSET = local_10;
  return;
}

