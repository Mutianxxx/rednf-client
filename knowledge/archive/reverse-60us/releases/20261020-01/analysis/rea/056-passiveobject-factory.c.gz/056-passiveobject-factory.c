
int FUN_005e8500(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *unaff_FS_OFFSET;
  bool bVar2;
  bool bVar3;
  undefined4 uVar4;
  undefined4 local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_10 = *unaff_FS_OFFSET;
  local_8 = 0xffffffff;
  puStack_c = &LAB_00c674c7;
  *unaff_FS_OFFSET = &local_10;
  if (0x59ee < param_1) {
    if (param_1 < 0x5dc2) {
      if (param_1 == 0x5dc1) {
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x130;
        if (iVar1 != 0) {
          iVar1 = FUN_005d21f0(0x5dc1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x59ef:
        iVar1 = FUN_00403c50(0x880);
        local_8 = 0x10c;
        if (iVar1 != 0) {
          iVar1 = FUN_005d57f0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f0:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x10d;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f1:
        iVar1 = FUN_00403c50(0x8b4);
        local_8 = 0x10e;
        if (iVar1 != 0) {
          iVar1 = FUN_005d5690(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f2:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x10f;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f3:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0x110;
        if (iVar1 != 0) {
          iVar1 = FUN_005d58d0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f4:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x111;
        if (iVar1 != 0) {
          iVar1 = FUN_005d5a30(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f5:
LAB_005f067d:
        iVar1 = FUN_00403c50(0x8bc);
        local_8 = 0x210;
        if (iVar1 != 0) {
          iVar1 = FUN_005cb800(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f6:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x112;
        if (iVar1 != 0) {
          iVar1 = FUN_005d5c50(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f7:
      case 0x59f8:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x113;
        if (iVar1 != 0) {
          iVar1 = FUN_005d5e80(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59f9:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0x114;
        if (iVar1 != 0) {
          iVar1 = FUN_005d3450(param_1,param_2,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59fa:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0x115;
        if (iVar1 != 0) {
          iVar1 = FUN_005d3450(param_1,param_2,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59fb:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0x116;
        if (iVar1 != 0) {
          iVar1 = FUN_005d3450(param_1,param_2,3);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59fc:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0x117;
        if (iVar1 != 0) {
          iVar1 = FUN_005d3450(param_1,param_2,2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59fd:
        iVar1 = FUN_00403c50(0x8dc);
        local_8 = 0x118;
        if (iVar1 != 0) {
          iVar1 = FUN_005cea30(param_1,param_2,4,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59fe:
      case 0x59ff:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x119;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a00:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x11a;
        if (iVar1 != 0) {
          iVar1 = FUN_005d8e40(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a01:
        iVar1 = FUN_00403c50(0x8d8);
        local_8 = 0x11b;
        if (iVar1 != 0) {
          iVar1 = FUN_005d9440(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a02:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x11c;
        if (iVar1 != 0) {
          iVar1 = FUN_005d95b0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a03:
        iVar1 = FUN_00403c50(0x938);
        local_8 = 0x11d;
        if (iVar1 != 0) {
          iVar1 = FUN_005d9270(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a04:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0x11e;
        if (iVar1 != 0) {
          iVar1 = FUN_005d9690(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a05:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x11f;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a06:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x120;
        if (iVar1 != 0) {
          iVar1 = FUN_005d97f0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a07:
        iVar1 = FUN_00403c50(0x89c);
        local_8 = 0x121;
        if (iVar1 != 0) {
          iVar1 = FUN_005d98d0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a08:
        iVar1 = FUN_00403c50(0x8bc);
        local_8 = 0x122;
        if (iVar1 != 0) {
          iVar1 = FUN_005cb980(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a09:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x123;
        if (iVar1 != 0) {
          iVar1 = FUN_005d99b0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a0a:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x124;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a0b:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x125;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a0c:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x126;
        if (iVar1 != 0) {
          iVar1 = FUN_005d9a70(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a0d:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x127;
        if (iVar1 != 0) {
          iVar1 = FUN_005d9bb0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a0e:
        iVar1 = FUN_00403c50(0x9d8);
        local_8 = 0x128;
        if (iVar1 != 0) {
          iVar1 = FUN_005d9fe0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a0f:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x129;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a10:
        iVar1 = FUN_00403c50(0x8c8);
        local_8 = 0x12a;
        if (iVar1 != 0) {
          iVar1 = FUN_005da230(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a11:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 299;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a12:
        iVar1 = FUN_00403c50(0x898);
        local_8 = 300;
        if (iVar1 != 0) {
          iVar1 = FUN_005da3b0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a13:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0x12d;
        if (iVar1 != 0) {
          iVar1 = FUN_005da490(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a14:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0x12e;
        if (iVar1 != 0) {
          iVar1 = FUN_005da490(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5a15:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x12f;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      default:
        goto LAB_005e89b9;
      }
      goto LAB_005f15f0;
    }
    if (param_1 < 0x7534) {
      if (param_1 == 0x7533) {
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x145;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc5e0(0x7533,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x5dc2:
        iVar1 = FUN_00403c50(0x8b0);
        local_8 = 0x131;
        if (iVar1 != 0) {
          iVar1 = FUN_005d2510(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc3:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0x132;
        if (iVar1 != 0) {
          iVar1 = FUN_005d26b0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc4:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0x133;
        if (iVar1 != 0) {
          iVar1 = FUN_005d2ae0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc5:
        iVar1 = FUN_00403c50(0x8b0);
        local_8 = 0x134;
        if (iVar1 != 0) {
          iVar1 = FUN_005d2bc0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc6:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x135;
        if (iVar1 != 0) {
          iVar1 = FUN_005d2fd0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc7:
        iVar1 = FUN_00403c50(0x8b4);
        local_8 = 0x136;
        if (iVar1 != 0) {
          iVar1 = FUN_005d3da0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc8:
        iVar1 = FUN_00403c50(0x8cc);
        local_8 = 0x137;
        if (iVar1 != 0) {
          iVar1 = FUN_005d3ee0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dc9:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0x138;
        if (iVar1 != 0) {
          iVar1 = FUN_005d2ec0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dca:
        iVar1 = FUN_00403c50(0x8e8);
        local_8 = 0x139;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4170(param_1,param_2,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dcb:
        iVar1 = FUN_00403c50(0x8e8);
        local_8 = 0x13a;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4170(param_1,param_2,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dcc:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x13b;
LAB_005f056c:
        if (iVar1 != 0) {
          iVar1 = FUN_005c95e0(param_1,param_2,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dcd:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x13c;
LAB_005ef9a9:
        if (iVar1 != 0) {
          iVar1 = FUN_005c95e0(param_1,param_2,2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dce:
        iVar1 = FUN_00403c50(0x8a8);
        local_8 = 0x13d;
        if (iVar1 != 0) {
          iVar1 = FUN_005d2d70(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dcf:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x13e;
        if (iVar1 != 0) {
          iVar1 = FUN_005d22f0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dd0:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x13f;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4840(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dd1:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x140;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4940(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dd2:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x141;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4a10(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dd3:
        iVar1 = FUN_00403c50(0x908);
        local_8 = 0x142;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4ab0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dd4:
        iVar1 = FUN_00403c50(0x8cc);
        local_8 = 0x143;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4c30(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5dd5:
        iVar1 = FUN_00403c50(0x89c);
        local_8 = 0x144;
        if (iVar1 != 0) {
          iVar1 = FUN_005d4d60(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      default:
        goto LAB_005e89b9;
      }
      goto LAB_005f15f0;
    }
    if (0x759e < param_1) {
      if (0x7766 < param_1) {
        if (param_1 < 0x7775) {
          if (param_1 == 0x7774) {
            iVar1 = FUN_00403c50(0x870);
            local_8 = 0x253;
            if (iVar1 != 0) {
              iVar1 = FUN_005e74a0(0x7774,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          switch(param_1) {
          case 0x7767:
            iVar1 = FUN_00403c50(0x898);
            local_8 = 0x1f1;
            if (iVar1 != 0) {
              iVar1 = FUN_005e0d80(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x7768:
            iVar1 = FUN_00403c50(0x888);
            local_8 = 0x1f2;
            if (iVar1 != 0) {
              iVar1 = FUN_005cece0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x7769:
            iVar1 = FUN_00403c50(0x890);
            local_8 = 499;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9360(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x776a:
            iVar1 = FUN_00403c50(0x888);
            local_8 = 0x1bd;
            if (iVar1 != 0) {
              iVar1 = FUN_005cc350(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x776b:
            iVar1 = FUN_00403c50(0x880);
            local_8 = 0x1be;
            if (iVar1 != 0) {
              iVar1 = FUN_005ca830(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          default:
            goto LAB_005e89b9;
          }
          goto LAB_005f15f0;
        }
        if (param_1 < 0xa413) {
          if (42000 < param_1) {
            iVar1 = FUN_00403c50(0x878);
            local_8 = 0x1e5;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9500(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          switch(param_1) {
          case 0x9c41:
            iVar1 = FUN_00403c50(0x87c);
            local_8 = 0x1dc;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9280(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x9c42:
          case 0x9c49:
            goto LAB_005f0431;
          case 0x9c43:
LAB_005efce4:
            iVar1 = FUN_00403c50(0x894);
            local_8 = 0x1de;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9be0(param_1,param_2,500,1,0);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x9c44:
            iVar1 = FUN_00403c50(0x87c);
            local_8 = 0x1df;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9cd0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x9c45:
            iVar1 = FUN_00403c50(0x88c);
            local_8 = 0x1e0;
LAB_005f0742:
            if (iVar1 != 0) {
              iVar1 = FUN_005c9db0(param_1,param_2,0);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x9c46:
            iVar1 = FUN_00403c50(0x894);
            local_8 = 0x1e1;
            goto LAB_005efd94;
          case 0x9c47:
            iVar1 = FUN_00403c50(0x878);
            local_8 = 0x1e3;
            if (iVar1 != 0) {
              iVar1 = FUN_005cad10(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0x9c48:
            iVar1 = FUN_00403c50(0x88c);
            local_8 = 0x1e4;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9db0(param_1,param_2,1);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          default:
            goto LAB_005e89b9;
          }
          goto LAB_005f15f0;
        }
        if (param_1 < 0xbbbd) {
          if (param_1 == 0xbbbc) {
            iVar1 = FUN_00403c50(0x890);
            local_8 = 0x1fe;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9360(0xbbbc,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (0xbb97 < param_1) {
            switch(param_1) {
            case 0xbb98:
              iVar1 = FUN_00403c50(0x8a0);
              local_8 = 0x214;
              if (iVar1 != 0) {
                iVar1 = FUN_005cb6f0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb99:
              iVar1 = FUN_00403c50(0x880);
              local_8 = 0x20d;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9970(param_1,param_2,5);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb9a:
              iVar1 = FUN_00403c50(0x878);
              local_8 = 0x20e;
              if (iVar1 != 0) {
                iVar1 = FUN_005e7c40(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb9b:
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x20f;
              if (iVar1 != 0) {
                iVar1 = FUN_005e7ba0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb9c:
              goto LAB_005f067d;
            case 0xbb9d:
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x211;
              if (iVar1 != 0) {
                iVar1 = FUN_005dcab0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb9e:
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x212;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9cd0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb9f:
              iVar1 = FUN_00403c50(0x88c);
              local_8 = 0x213;
              goto LAB_005f0742;
            case 0xbba0:
              iVar1 = FUN_00403c50(0x874);
              local_8 = 0x15e;
              if (iVar1 != 0) {
                iVar1 = FUN_005dcbf0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbba1:
            case 0xbba2:
            case 0xbba3:
            case 0xbba4:
            case 0xbba5:
            case 0xbba6:
            case 0xbba7:
            case 0xbba8:
            case 0xbba9:
            case 0xbbaa:
            case 0xbbb2:
code_r0x005efeec:
              iVar1 = FUN_00403c50(0x870);
              local_8 = 0x204;
              if (iVar1 != 0) {
                iVar1 = FUN_005cafb0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbab:
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x21b;
              if (iVar1 != 0) {
                iVar1 = FUN_005e7870(param_1,param_2,1);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbac:
              goto LAB_005f0431;
            case 0xbbad:
            case 0xbbb1:
            case 0xbbb5:
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x21f;
              if (iVar1 != 0) {
                iVar1 = FUN_005de960(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbae:
            case 0xbbaf:
            case 0xbbb0:
              iVar1 = FUN_00403c50(0x878);
              local_8 = 0x220;
              if (iVar1 != 0) {
                iVar1 = FUN_005dea40(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbb3:
              iVar1 = FUN_00403c50(0x884);
              local_8 = 0x221;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9890(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbb4:
              iVar1 = FUN_00403c50(0x890);
              local_8 = 0x222;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9360(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbb6:
              iVar1 = FUN_00403c50(0x890);
              local_8 = 0x1fb;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9360(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbb7:
              iVar1 = FUN_00403c50(0x874);
              local_8 = 0x1fa;
              if (iVar1 != 0) {
                iVar1 = FUN_005dcbf0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbb8:
              iVar1 = FUN_00403c50(0x878);
              local_8 = 0x1f9;
              if (iVar1 != 0) {
                iVar1 = FUN_005c95e0(param_1,param_2,0);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbb9:
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x1fc;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9cd0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbba:
LAB_005f0591:
              iVar1 = FUN_00403c50(0x880);
              local_8 = 0x207;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9970(param_1,param_2,0);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbbbb:
              iVar1 = FUN_00403c50(0x878);
              local_8 = 0x1fd;
              goto LAB_005f056c;
            default:
              goto LAB_005e89b9;
            }
            goto LAB_005f15f0;
          }
          if (param_1 == 0xbb97) {
            iVar1 = FUN_00403c50(0x880);
            local_8 = 0x20c;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9970(0xbb97,param_2,5);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (0xbb89 < param_1) {
            switch(param_1) {
            case 0xbb8a:
            case 0xbb8e:
              iVar1 = FUN_00403c50(0x874);
              local_8 = 0x218;
              if (iVar1 != 0) {
                iVar1 = FUN_005cadf0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb8b:
              goto code_r0x005efeec;
            case 0xbb8c:
              iVar1 = FUN_00403c50(0x8f4);
              local_8 = 0x219;
              if (iVar1 != 0) {
                iVar1 = FUN_005caed0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb8d:
              iVar1 = FUN_00403c50(0x8a0);
              local_8 = 0x21a;
              if (iVar1 != 0) {
                iVar1 = FUN_005cb090(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            default:
              goto LAB_005e89b9;
            case 0xbb90:
              iVar1 = FUN_00403c50(0x888);
              local_8 = 0x21c;
              if (iVar1 != 0) {
                iVar1 = FUN_005e7550(param_1,param_2,0);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb91:
              iVar1 = FUN_00403c50(0x894);
              local_8 = 0x21d;
              if (iVar1 != 0) {
                iVar1 = FUN_005e7760(param_1,param_2,0);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb92:
              iVar1 = FUN_00403c50(0x888);
              local_8 = 0x21e;
              if (iVar1 != 0) {
                iVar1 = FUN_005e7660(param_1,param_2,0);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb93:
              iVar1 = FUN_00403c50(0x880);
              local_8 = 0x208;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9970(param_1,param_2,1);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb94:
              iVar1 = FUN_00403c50(0x880);
              local_8 = 0x209;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9970(param_1,param_2,2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb95:
              iVar1 = FUN_00403c50(0x880);
              local_8 = 0x20a;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9970(param_1,param_2,3);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb96:
              iVar1 = FUN_00403c50(0x880);
              local_8 = 0x20b;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9970(param_1,param_2,4);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
            }
            goto LAB_005f15f0;
          }
          if (param_1 == 0xbb89) {
            iVar1 = FUN_00403c50(0x874);
            local_8 = 0x217;
            if (iVar1 != 0) {
              iVar1 = FUN_005cac70(0xbb89,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (0xb3b4 < param_1) {
            switch(param_1) {
            case 0xbb81:
              iVar1 = FUN_00403c50(0x888);
              local_8 = 0x205;
              if (iVar1 != 0) {
                iVar1 = FUN_005c97b0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb82:
              iVar1 = FUN_00403c50(0x884);
              local_8 = 0x206;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9890(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb83:
              goto LAB_005f0591;
            case 0xbb84:
              iVar1 = FUN_00403c50(0x88c);
              local_8 = 0x215;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9a60(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            case 0xbb85:
            case 0xbb86:
            case 0xbb87:
            case 0xbb88:
              iVar1 = FUN_00403c50(0x870);
              local_8 = 0x216;
              if (iVar1 != 0) {
                iVar1 = FUN_005c9b40(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              break;
            default:
              goto LAB_005e89b9;
            }
            goto LAB_005f15f0;
          }
          if (param_1 == 0xb3b4) goto LAB_005f0431;
          if (param_1 < 0xb3b2) {
            if (param_1 == 0xb3b1) {
LAB_005eff32:
              iVar1 = FUN_00403c50(0x878);
              local_8 = 500;
              if (iVar1 != 0) {
                iVar1 = FUN_005c95e0(param_1,param_2,1);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              goto LAB_005f15f0;
            }
            if (param_1 < 0xabe2) {
              if (param_1 == 0xabe1) goto LAB_005f0431;
              if ((0xa412 < param_1) && (param_1 < 0xa417)) goto code_r0x005efeec;
            }
            else if (param_1 == 0xabe2) goto LAB_005eff32;
          }
          else {
            if (param_1 == 0xb3b2) {
              iVar1 = FUN_00403c50(0x870);
              local_8 = 0x1f5;
              if (iVar1 != 0) {
                iVar1 = FUN_005cafb0(0xb3b2,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              goto LAB_005f15f0;
            }
            if (param_1 == 0xb3b3) goto code_r0x005eff7e;
          }
          goto LAB_005e89b9;
        }
        if (param_1 < 0xc355) {
          if (50000 < param_1) {
            iVar1 = FUN_00403c50(0x878);
            local_8 = 0x223;
            if (iVar1 != 0) {
              iVar1 = FUN_005cb2b0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          switch(param_1) {
          case 0xbbbd:
            iVar1 = FUN_00403c50(0x890);
            local_8 = 0x1ff;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9360(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xbbbe:
            iVar1 = FUN_00403c50(0x884);
            local_8 = 0x200;
            if (iVar1 != 0) {
              iVar1 = FUN_005cf690(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xbbbf:
LAB_005f0931:
            iVar1 = FUN_00403c50(0x89c);
            local_8 = 0x5e;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1d50(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xbbc0:
            iVar1 = FUN_00403c50(0x890);
            local_8 = 0x201;
            if (iVar1 != 0) {
              iVar1 = FUN_005c9360(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xbbc1:
          case 0xbbc2:
          case 0xbbc3:
          case 0xbbc4:
          case 0xbbc5:
            goto code_r0x005efeec;
          default:
            goto LAB_005e89b9;
          }
          goto LAB_005f15f0;
        }
        if (param_1 < 0xc87d) {
          if (param_1 == 0xc87c) {
            iVar1 = FUN_00403c50(0x960);
            local_8 = 0x23b;
            if (iVar1 != 0) {
              iVar1 = FUN_005e0150(0xc87c,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (param_1 < 0xc676) {
            if (0xc66f < param_1) {
              iVar1 = FUN_00403c50(0x878);
              local_8 = 0x231;
              if (iVar1 != 0) {
                iVar1 = FUN_005ca700(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              goto LAB_005f15f0;
            }
            if (0xc595 < param_1) {
              switch(param_1) {
              case 0xc59e:
                iVar1 = FUN_00403c50(0x870);
                local_8 = 0x22c;
                if (iVar1 != 0) {
                  iVar1 = FUN_005cabd0(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                break;
              default:
                goto LAB_005e89b9;
              case 0xc5a8:
              case 0xc5a9:
              case 0xc5aa:
              case 0xc5ab:
              case 0xc5ac:
              case 0xc5ad:
                goto LAB_005f0c9c;
              case 0xc60c:
              case 0xc60d:
              case 0xc60e:
              case 0xc60f:
              case 0xc610:
              case 0xc611:
              case 0xc612:
                iVar1 = FUN_00403c50(0x878);
                local_8 = 0x22e;
                if (iVar1 != 0) {
                  iVar1 = FUN_005caae0(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                break;
              case 0xc63e:
              case 0xc63f:
              case 0xc640:
              case 0xc641:
              case 0xc642:
                iVar1 = FUN_00403c50(0x894);
                local_8 = 0x22f;
                if (iVar1 != 0) {
                  iVar1 = FUN_005e2890(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                break;
              case 0xc643:
              case 0xc644:
                iVar1 = FUN_00403c50(0x894);
                local_8 = 0x230;
                if (iVar1 != 0) {
                  iVar1 = FUN_005e2990(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
              }
              goto LAB_005f15f0;
            }
            if (0xc593 < param_1) {
              iVar1 = FUN_00403c50(0x878);
              local_8 = 0x22b;
              if (iVar1 != 0) {
                iVar1 = FUN_005caae0(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              goto LAB_005f15f0;
            }
            if (param_1 < 0xc482) {
              if (0xc47b < param_1) goto LAB_005f0b3e;
              switch(param_1) {
              case 0xc3b4:
              case 0xc3b5:
              case 0xc3b6:
              case 0xc3b7:
              case 0xc3b8:
                iVar1 = FUN_00403c50(0x874);
                local_8 = 0x224;
                if (iVar1 != 0) {
                  iVar1 = FUN_005dc7c0(param_1,param_1 + 100);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                break;
              default:
                goto LAB_005e89b9;
              case 0xc418:
              case 0xc419:
              case 0xc41a:
              case 0xc41b:
              case 0xc41c:
                iVar1 = FUN_00403c50(0x878);
                local_8 = 0x225;
                if (iVar1 != 0) {
                  iVar1 = FUN_005dc820(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
              }
              goto LAB_005f15f0;
            }
            switch(param_1) {
            case 0xc4e0:
            case 0xc4e1:
            case 0xc4e2:
            case 0xc4e3:
            case 0xc4e4:
              goto LAB_005f0b95;
            case 0xc544:
            case 0xc545:
            case 0xc546:
            case 0xc547:
              iVar1 = FUN_00403c50(0x870);
              local_8 = 0x22a;
              if (iVar1 != 0) {
                iVar1 = FUN_005ca150(param_1,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              goto LAB_005f15f0;
            }
          }
          else {
            if (0xc800 < param_1) {
              switch(param_1) {
              case 0xc801:
                iVar1 = FUN_00403c50(0x878);
                local_8 = 0x237;
                if (iVar1 != 0) {
                  iVar1 = FUN_005e7ac0(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                break;
              default:
                goto LAB_005e89b9;
              case 0xc878:
              case 0xc87a:
                iVar1 = FUN_00403c50(0x9dc);
                local_8 = 0x238;
                if (iVar1 != 0) {
                  iVar1 = FUN_005e8040(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                break;
              case 0xc879:
                iVar1 = FUN_00403c50(0x878);
                local_8 = 0x239;
                if (iVar1 != 0) {
                  iVar1 = FUN_005e0010(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
              }
              goto LAB_005f15f0;
            }
            if (param_1 == 0xc800) {
              iVar1 = FUN_00403c50(0x87c);
              local_8 = 0x236;
              if (iVar1 != 0) {
                iVar1 = FUN_005e79e0(0xc800,param_2);
                *unaff_FS_OFFSET = local_10;
                return iVar1;
              }
              goto LAB_005f15f0;
            }
            if (param_1 < 0xc707) {
              if (param_1 == 0xc706) goto LAB_005f0e76;
              if (0xc675 < param_1) {
                if (param_1 < 0xc67b) {
                  iVar1 = FUN_00403c50(0x888);
                  local_8 = 0x229;
                  if (iVar1 != 0) {
                    iVar1 = FUN_005caa10(param_1,param_2);
                    *unaff_FS_OFFSET = local_10;
                    return iVar1;
                  }
                  goto LAB_005f15f0;
                }
                if (param_1 == 0xc6d4) {
                  iVar1 = FUN_00403c50(0x870);
                  local_8 = 0x232;
                  if (iVar1 != 0) {
                    iVar1 = FUN_005cb420(0xc6d4,param_2);
                    *unaff_FS_OFFSET = local_10;
                    return iVar1;
                  }
                  goto LAB_005f15f0;
                }
              }
            }
            else {
              if (param_1 == 51000) {
                iVar1 = FUN_00403c50(0x874);
                local_8 = 0x234;
                if (iVar1 != 0) {
                  iVar1 = FUN_00681b40(51000,0xc79c);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                goto LAB_005f15f0;
              }
              if (param_1 == 0xc79c) {
                iVar1 = FUN_00403c50(0x878);
                local_8 = 0x235;
                if (iVar1 != 0) {
                  iVar1 = FUN_005cb600(0xc79c,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                goto LAB_005f15f0;
              }
            }
          }
          goto LAB_005e89b9;
        }
        if (0xea69 < param_1) {
          switch(param_1) {
          case 0xea6a:
LAB_005f13a5:
            iVar1 = FUN_00403c50(0x87c);
            local_8 = 0x241;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1000(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          default:
            goto LAB_005e89b9;
          case 0xea6c:
            iVar1 = FUN_00403c50(0x870);
            local_8 = 0x248;
            if (iVar1 != 0) {
              iVar1 = FUN_005e13c0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea6e:
            iVar1 = FUN_00403c50(0x8ac);
            local_8 = 0x249;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1460(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea6f:
            iVar1 = FUN_00403c50(0x8ac);
            local_8 = 0x24a;
            if (iVar1 != 0) {
              iVar1 = FUN_005e15b0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea73:
            iVar1 = FUN_00403c50(0x89c);
            local_8 = 0x24b;
            if (iVar1 != 0) {
              iVar1 = FUN_005e16f0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea74:
            iVar1 = FUN_00403c50(0x88c);
            local_8 = 0x24c;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1870(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea76:
            iVar1 = FUN_00403c50(0x87c);
            local_8 = 0x24d;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1990(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea77:
            iVar1 = FUN_00403c50(0x894);
            local_8 = 0x24e;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1a70(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea79:
            iVar1 = FUN_00403c50(0x88c);
            local_8 = 0x24f;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1b50(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea7b:
            iVar1 = FUN_00403c50(0x884);
            local_8 = 0x250;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1c70(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
          }
          goto LAB_005f15f0;
        }
        if (param_1 == 0xea69) {
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0x247;
          if (iVar1 != 0) {
            iVar1 = FUN_005e1330(0xea69,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        if (0xea63 < param_1) {
          switch(param_1) {
          case 0xea64:
            iVar1 = FUN_00403c50(0x878);
            local_8 = 0x242;
            if (iVar1 != 0) {
              iVar1 = FUN_005caae0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea65:
            iVar1 = FUN_00403c50(0x870);
            local_8 = 0x243;
            if (iVar1 != 0) {
              iVar1 = FUN_005e10a0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea66:
            iVar1 = FUN_00403c50(0x878);
            local_8 = 0x244;
            if (iVar1 != 0) {
              iVar1 = FUN_005caae0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea67:
            iVar1 = FUN_00403c50(0x870);
            local_8 = 0x245;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1160(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xea68:
            iVar1 = FUN_00403c50(0x880);
            local_8 = 0x246;
            if (iVar1 != 0) {
              iVar1 = FUN_005e1200(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          default:
            goto LAB_005e89b9;
          }
          goto LAB_005f15f0;
        }
        if (param_1 == 0xea63) goto LAB_005f13a5;
        if (param_1 < 0xc880) {
          if (param_1 == 0xc87f) {
            iVar1 = FUN_00403c50(0x8bc);
            local_8 = 0x23e;
            if (iVar1 != 0) {
              iVar1 = FUN_005e0350(0xc87f,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (param_1 == 0xc87d) {
            iVar1 = FUN_00403c50(0x960);
            local_8 = 0x23c;
            if (iVar1 != 0) {
              iVar1 = FUN_005e01b0(0xc87d,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (param_1 == 0xc87e) {
            iVar1 = FUN_00403c50(0x974);
            local_8 = 0x23d;
            if (iVar1 != 0) {
              iVar1 = FUN_005e0250(0xc87e,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
        }
        else {
          if (param_1 == 0xea61) {
            iVar1 = FUN_00403c50(0x880);
            local_8 = 0x23f;
            if (iVar1 != 0) {
              iVar1 = FUN_005e0ed0(0xea61,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          if (param_1 == 0xea62) {
            iVar1 = FUN_00403c50(0x898);
            local_8 = 0x240;
            if (iVar1 != 0) {
              iVar1 = FUN_005e0f70(0xea62,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
        }
        goto LAB_005e89b9;
      }
      if (param_1 == 0x7766) {
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x1f0;
        if (iVar1 != 0) {
          iVar1 = FUN_005e0ca0(0x7766,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      if (param_1 - 0x75f8U < 0x16e) {
                    /* WARNING (jumptable): Sanity check requires truncation of jumptable */
                    /* WARNING: Could not find normalized switch variable to match jumptable */
        switch((&LAB_005eb0a0)[param_1]) {
        case 0:
          iVar1 = FUN_00403c50(0x880);
          local_8 = 0x194;
          if (iVar1 != 0) {
            iVar1 = FUN_005dd8b0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 1:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x195;
          if (iVar1 != 0) {
            iVar1 = FUN_005dda40(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 2:
          goto LAB_005f067d;
        case 3:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x199;
          if (iVar1 != 0) {
            iVar1 = FUN_006834e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 4:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x19a;
          if (iVar1 != 0) {
            iVar1 = FUN_005ddc30(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 5:
          goto LAB_005ee5cc;
        case 6:
          goto LAB_005ee56c;
        case 7:
          goto LAB_005ee5a6;
        case 8:
          iVar1 = FUN_00403c50(0x8c0);
          local_8 = 0x196;
          if (iVar1 != 0) {
            iVar1 = FUN_005ddab0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 9:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x197;
          if (iVar1 != 0) {
            iVar1 = FUN_006833a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 10:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x198;
          if (iVar1 != 0) {
            iVar1 = FUN_00683480(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0xb:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x19b;
          if (iVar1 != 0) {
            iVar1 = FUN_006835c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0xc:
          iVar1 = FUN_00403c50(0x994);
          local_8 = 0x19c;
          if (iVar1 != 0) {
            iVar1 = FUN_005cbb70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0xd:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x19d;
          if (iVar1 != 0) {
            iVar1 = FUN_005c95e0(param_1,param_2,3);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0xe:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x19e;
          if (iVar1 != 0) {
            iVar1 = FUN_005cafb0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0xf:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x19f;
          if (iVar1 != 0) {
            iVar1 = FUN_005cafb0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x10:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x1a0;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x11:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1a1;
          if (iVar1 != 0) {
            iVar1 = FUN_005cad10(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x12:
          iVar1 = FUN_00403c50(0x894);
          local_8 = 0x1a2;
          if (iVar1 != 0) {
            iVar1 = FUN_005e2a00(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x13:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1a3;
          if (iVar1 != 0) {
            iVar1 = FUN_005caae0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x14:
          iVar1 = FUN_00403c50(0x8b4);
          local_8 = 0x1a4;
          if (iVar1 != 0) {
            iVar1 = FUN_005e7ce0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x15:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1a5;
          if (iVar1 != 0) {
            iVar1 = FUN_005e7de0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x16:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1a6;
          if (iVar1 != 0) {
            iVar1 = FUN_005e7f60(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x17:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x1a7;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x18:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x1a8;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9cd0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x19:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x1a9;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9db0(param_1,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x1a:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x1aa;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9a60(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x1b:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1c0;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9b40(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x1c:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1c1;
          if (iVar1 != 0) {
            iVar1 = FUN_005dc7c0(param_1,0x76a3);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x1d:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1c2;
          if (iVar1 != 0) {
            iVar1 = FUN_005dc820(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x1e:
          goto LAB_005ee606;
        case 0x1f:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x186;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x20:
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 0x187;
          if (iVar1 != 0) {
            iVar1 = FUN_005de010(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x21:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x188;
          if (iVar1 != 0) {
            iVar1 = FUN_005ddf70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x22:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x189;
          if (iVar1 != 0) {
            iVar1 = FUN_005de240(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x23:
          iVar1 = FUN_00403c50(0x8a4);
          local_8 = 0x18b;
          if (iVar1 != 0) {
            iVar1 = FUN_005de3b0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x24:
          iVar1 = FUN_00403c50(0x8b4);
          local_8 = 0x18c;
          if (iVar1 != 0) {
            iVar1 = FUN_005de5e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x25:
          iVar1 = FUN_00403c50(0x8c4);
          local_8 = 0x18d;
          if (iVar1 != 0) {
            iVar1 = FUN_005de6e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x26:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x18e;
          if (iVar1 != 0) {
            iVar1 = FUN_005ddbc0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x27:
          iVar1 = FUN_00403c50(0x8c8);
          local_8 = 0x18a;
          if (iVar1 != 0) {
            iVar1 = FUN_005de110(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x28:
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 399;
          if (iVar1 != 0) {
            iVar1 = FUN_005de2b0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x29:
          iVar1 = FUN_00403c50(0x894);
          local_8 = 0x1e2;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9be0(param_1,param_2,0x5dc,1,1);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x2a:
LAB_005f0e76:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x233;
          if (iVar1 != 0) {
            iVar1 = FUN_005cb510(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x2b:
LAB_005f0b3e:
          iVar1 = FUN_00403c50(0x880);
          local_8 = 0x226;
          if (iVar1 != 0) {
            iVar1 = FUN_005ca830(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x2c:
LAB_005f0b95:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0x227;
          if (iVar1 != 0) {
            iVar1 = FUN_005ca920(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x2d:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1c3;
          if (iVar1 != 0) {
            iVar1 = FUN_005de820(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x2e:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1c5;
          if (iVar1 != 0) {
            iVar1 = FUN_005dfb00(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x2f:
          iVar1 = FUN_00403c50(0x8b4);
          local_8 = 0x1c6;
          if (iVar1 != 0) {
            iVar1 = FUN_005dfb80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x30:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1cc;
          if (iVar1 != 0) {
            iVar1 = FUN_005dfcf0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x31:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1cd;
          if (iVar1 != 0) {
            iVar1 = FUN_005ca150(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x32:
code_r0x005ea1eb:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1ce;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce3a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x33:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x1cf;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x34:
          iVar1 = FUN_00403c50(0x888);
          local_8 = 0x228;
          if (iVar1 != 0) {
            iVar1 = FUN_005caa70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x35:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x1ab;
          if (iVar1 != 0) {
            iVar1 = FUN_005dfa20(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x36:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1ac;
          if (iVar1 != 0) {
            iVar1 = FUN_005df940(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x37:
          iVar1 = FUN_00403c50(0x914);
          local_8 = 0x1ad;
          if (iVar1 != 0) {
            iVar1 = FUN_005df8a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x38:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1ae;
          if (iVar1 != 0) {
            iVar1 = FUN_005df7c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x39:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1af;
          if (iVar1 != 0) {
            iVar1 = FUN_005df6e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x3a:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x1b0;
          if (iVar1 != 0) {
            iVar1 = FUN_005debc0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x3b:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x1b1;
          if (iVar1 != 0) {
            iVar1 = FUN_005deca0(param_1,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x3c:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1b2;
          if (iVar1 != 0) {
            iVar1 = FUN_005deb20(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x3d:
          iVar1 = FUN_00403c50(0x8c4);
          local_8 = 0x1b3;
          if (iVar1 != 0) {
            iVar1 = FUN_005ded90(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x3e:
          goto LAB_005ee3a6;
        case 0x3f:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0x1b4;
          if (iVar1 != 0) {
            iVar1 = FUN_005deed0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x40:
          iVar1 = FUN_00403c50(0x968);
          local_8 = 0x1b5;
          if (iVar1 != 0) {
            iVar1 = FUN_005defb0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x41:
          iVar1 = FUN_00403c50(0x888);
          local_8 = 0x2e;
          if (iVar1 != 0) {
            iVar1 = FUN_005e3a80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x42:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0x2f;
          if (iVar1 != 0) {
            iVar1 = FUN_005de500(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x43:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x30;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x44:
          iVar1 = FUN_00403c50(0x8b8);
          local_8 = 0x1b8;
          if (iVar1 != 0) {
            iVar1 = FUN_005df090(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x45:
          iVar1 = FUN_00403c50(0x8dc);
          local_8 = 0x1b9;
          if (iVar1 != 0) {
            iVar1 = FUN_005df100(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x46:
          iVar1 = FUN_00403c50(0x904);
          local_8 = 0x1ba;
          if (iVar1 != 0) {
            iVar1 = FUN_005df190(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x47:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1bb;
          if (iVar1 != 0) {
            iVar1 = FUN_005cc190(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x48:
          iVar1 = FUN_00403c50(0x8e0);
          local_8 = 0x1d0;
          if (iVar1 != 0) {
            iVar1 = FUN_005dfd90(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x49:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x32;
          if (iVar1 != 0) {
            iVar1 = FUN_005df220(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4a:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x33;
          if (iVar1 != 0) {
            iVar1 = FUN_005df300(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4b:
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 0x34;
          if (iVar1 != 0) {
            iVar1 = FUN_005df3e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4c:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x1d2;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4d:
          goto LAB_005f0c9c;
        case 0x4e:
          iVar1 = FUN_00403c50(0x8c0);
          local_8 = 0x1b6;
          if (iVar1 != 0) {
            iVar1 = FUN_005df4e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4f:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1c4;
          if (iVar1 != 0) {
            iVar1 = FUN_005de8c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x50:
          iVar1 = FUN_00403c50(0x8c4);
          local_8 = 0x1b7;
          if (iVar1 != 0) {
            iVar1 = FUN_005df5e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x51:
          iVar1 = FUN_00403c50(0x9d8);
          local_8 = 0x1d3;
          if (iVar1 != 0) {
            iVar1 = FUN_005c8b50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x52:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1d4;
          if (iVar1 != 0) {
            iVar1 = FUN_005de8c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x53:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1d5;
          if (iVar1 != 0) {
            iVar1 = FUN_005de8c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x54:
          iVar1 = FUN_00403c50(0x9d8);
          local_8 = 0x1d6;
          if (iVar1 != 0) {
            iVar1 = FUN_005c8b50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x55:
          iVar1 = FUN_00403c50(0x954);
          local_8 = 0x1d7;
          if (iVar1 != 0) {
            iVar1 = FUN_005c8a70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1c7;
          if (iVar1 != 0) {
            iVar1 = FUN_005dfc80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x57:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1d8;
          if (iVar1 != 0) {
            iVar1 = FUN_005d19f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x58:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1c8;
          if (iVar1 != 0) {
            iVar1 = FUN_005ca3f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x59:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x1cb;
          if (iVar1 != 0) {
            iVar1 = FUN_005dff70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5a:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1bc;
          if (iVar1 != 0) {
            iVar1 = FUN_005cc270(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5b:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1bf;
          if (iVar1 != 0) {
            iVar1 = FUN_005cc430(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5c:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1c9;
          if (iVar1 != 0) {
            iVar1 = FUN_005ca1e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5d:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1ca;
          if (iVar1 != 0) {
            iVar1 = FUN_005ca1e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5e:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1d9;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0450(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5f:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1da;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0530(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x60:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x31;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9490(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x61:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1db;
          if (iVar1 != 0) {
            iVar1 = FUN_005dc820(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x62:
          goto LAB_005f0431;
        case 99:
          iVar1 = FUN_00403c50(0x8a0);
          local_8 = 0x1e6;
          if (iVar1 != 0) {
            iVar1 = FUN_005cbd00(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 100:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0x1e7;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0610(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x65:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1e8;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0840(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x66:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0x1e9;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0720(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x67:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1ea;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0a00(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x68:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x1eb;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0920(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x69:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x1ec;
          goto LAB_005ef9a9;
        case 0x6a:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x1ed;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x6b:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1ee;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0ae0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x6c:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x1ef;
          if (iVar1 != 0) {
            iVar1 = FUN_005e0bc0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x6d:
          goto LAB_005e89b9;
        }
      }
      else {
LAB_005e89b9:
        iVar1 = FUN_00434670(param_1);
        if (iVar1 == 0) {
          (*(code *)PTR_FUN_00ff2ebc)(&DAT_00d514f8,param_1);
        }
        else {
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x254;
          if (iVar1 != 0) {
            iVar1 = FUN_005c85a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
        }
      }
      goto LAB_005f15f0;
    }
    if (param_1 == 0x759e) {
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x193;
      if (iVar1 != 0) {
        iVar1 = FUN_005ddd10(0x759e,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      goto LAB_005f15f0;
    }
    switch(param_1) {
    case 0x7534:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x146;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc680(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7535:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x147;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc720(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7536:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x148;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc7c0(param_1,0x7538);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    default:
      goto LAB_005e89b9;
    case 0x7538:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x149;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7539:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x152;
      if (iVar1 != 0) {
        iVar1 = FUN_005dcb50(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x753a:
    case 0x753b:
      iVar1 = FUN_00403c50(0x89c);
      local_8 = 0x153;
      if (iVar1 != 0) {
        iVar1 = FUN_005dca10(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x753c:
      iVar1 = FUN_00403c50(0x89c);
      local_8 = 0x154;
      if (iVar1 != 0) {
        iVar1 = FUN_005dca70(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x753d:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x155;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc910(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x753e:
    case 0x7559:
    case 0x755a:
LAB_005f0c9c:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x22d;
      if (iVar1 != 0) {
        iVar1 = FUN_005ca700(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x753f:
    case 0x7554:
code_r0x005eff7e:
      iVar1 = FUN_00403c50(0x87c);
      local_8 = 0x1f6;
      if (iVar1 != 0) {
        iVar1 = FUN_005dcab0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7540:
    case 0x7541:
    case 0x7595:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x156;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc5e0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7542:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x157;
      if (iVar1 != 0) {
        iVar1 = FUN_005dcf10(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7543:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x158;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc7c0(param_1,0x7544);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7544:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x159;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7545:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x15a;
      if (iVar1 != 0) {
        iVar1 = FUN_005caae0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7546:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x15b;
      if (iVar1 != 0) {
        iVar1 = FUN_005cabd0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7547:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x15c;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc7c0(param_1,0x7548);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7548:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x15d;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7549:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x15f;
      if (iVar1 != 0) {
        iVar1 = FUN_005dcbf0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x754a:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x160;
      if (iVar1 != 0) {
        iVar1 = FUN_005dccd0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x754c:
      iVar1 = FUN_00403c50(0x8a4);
      local_8 = 0x1f7;
      if (iVar1 != 0) {
        iVar1 = FUN_005dceb0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x754d:
      iVar1 = FUN_00403c50(0x880);
      local_8 = 0x1f8;
      if (iVar1 != 0) {
        iVar1 = FUN_005dce50(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x754e:
    case 0x754f:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x161;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd220(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7550:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x162;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7551:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x163;
      if (iVar1 != 0) {
        iVar1 = FUN_00490720(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7552:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x164;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd4e0(param_1,param_2,0x7553,0);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7553:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x165;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7555:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x166;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd4e0(param_1,param_2,0x755e,5);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7556:
    case 0x7557:
    case 0x7558:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x167;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd400(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x755b:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x168;
      if (iVar1 != 0) {
        iVar1 = FUN_005cb2b0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x755c:
      iVar1 = FUN_00403c50(0x890);
      local_8 = 0x169;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9360(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x755d:
      iVar1 = FUN_00403c50(0x890);
      local_8 = 0x16a;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9360(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x755e:
      iVar1 = FUN_00403c50(0x894);
      local_8 = 0x16b;
      goto LAB_005efd94;
    case 0x755f:
    case 0x7561:
LAB_005ee56c:
      iVar1 = FUN_00403c50(0x87c);
      local_8 = 0x16c;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9280(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7560:
    case 0x7562:
LAB_005ee5a6:
      iVar1 = FUN_00403c50(0x894);
      local_8 = 0x16d;
      if (iVar1 == 0) break;
      uVar4 = 0;
      goto LAB_005efd9e;
    case 0x7563:
      iVar1 = FUN_00403c50(0x894);
      local_8 = 0x16e;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9be0(param_1,param_2,500,1,0);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7564:
      iVar1 = FUN_00403c50(0x894);
      local_8 = 0x16f;
LAB_005efd94:
      if (iVar1 != 0) {
        uVar4 = 1;
LAB_005efd9e:
        iVar1 = FUN_005c9be0(param_1,param_2,500,1,uVar4);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7565:
    case 0x7566:
      iVar1 = FUN_00403c50(0x884);
      local_8 = 0x170;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9890(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7567:
    case 0x7568:
      iVar1 = FUN_00403c50(0x890);
      local_8 = 0x171;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9360(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7569:
    case 0x756a:
LAB_005ee5cc:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x172;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9500(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x756b:
      iVar1 = FUN_00403c50(0x88c);
      local_8 = 0x173;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9a60(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x756c:
    case 0x756d:
    case 0x756e:
    case 0x756f:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x174;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9b40(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7570:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x175;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7571:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x176;
      if (iVar1 != 0) {
        iVar1 = FUN_005cad10(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7572:
      iVar1 = FUN_00403c50(0x87c);
      local_8 = 0x177;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9cd0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7573:
      iVar1 = FUN_00403c50(0x88c);
      local_8 = 0x178;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9db0(param_1,param_2,0);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7574:
    case 0x7575:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x179;
      if (iVar1 != 0) {
        iVar1 = FUN_005cac70(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7576:
    case 0x7577:
    case 0x7578:
    case 0x7579:
    case 0x757a:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x17a;
      if (iVar1 != 0) {
        iVar1 = FUN_005c95e0(param_1,param_2,0);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x757d:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x17b;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc7c0(param_1,0x757e);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x757e:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x17c;
      if (iVar1 != 0) {
        iVar1 = FUN_005dc820(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7580:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x17d;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd5e0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7581:
      iVar1 = FUN_00403c50(0x8b4);
      local_8 = 0x17e;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd660(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7584:
      iVar1 = FUN_00403c50(0x88c);
      local_8 = 0x17f;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9a60(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7585:
    case 0x7586:
    case 0x7587:
    case 0x7588:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x180;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9b40(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7589:
    case 0x758f:
      iVar1 = FUN_00403c50(0x8dc);
      local_8 = 0x181;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd760(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x758a:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x182;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd7a0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x758b:
      iVar1 = FUN_00403c50(0x894);
      local_8 = 0x183;
      if (iVar1 == 0) break;
      uVar4 = 0;
      goto LAB_005efd9e;
    case 0x758c:
    case 0x758d:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x184;
      if (iVar1 != 0) {
        iVar1 = FUN_006760a0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x758e:
LAB_005ee606:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x185;
      if (iVar1 != 0) {
        iVar1 = FUN_005dcbf0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7590:
      iVar1 = FUN_00403c50(0x87c);
      local_8 = 400;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9f80(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7591:
      iVar1 = FUN_00403c50(0x88c);
      local_8 = 0x191;
      if (iVar1 != 0) {
        iVar1 = FUN_005ca060(param_1,param_2,0);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x7594:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x192;
      if (iVar1 != 0) {
        iVar1 = FUN_005dd840(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
    }
    goto LAB_005f15f0;
  }
  if (param_1 == 0x59ee) {
    iVar1 = FUN_00403c50(0x874);
    local_8 = 0x10b;
    if (iVar1 != 0) {
      iVar1 = FUN_005d54a0(0x59ee,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    goto LAB_005f15f0;
  }
  if (0x1132 < param_1) {
    if (0x5219 < param_1) {
      if (param_1 < 0x5600) {
        if (22000 < param_1) {
          iVar1 = FUN_00403c50(0x908);
          local_8 = 200;
          if (iVar1 != 0) {
            iVar1 = FUN_005cdbd0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 0x521a:
          iVar1 = FUN_00403c50(0x968);
          local_8 = 0xc2;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1380(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x521b:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0xc3;
          if (iVar1 != 0) {
            iVar1 = FUN_005d15e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x521c:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xc4;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1790(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x521d:
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0xc5;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1800(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x521e:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xc6;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1910(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x521f:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 199;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9890(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5220:
        case 0x5221:
        case 0x5222:
        case 0x5223:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0xa8;
          if (iVar1 != 0) {
            iVar1 = FUN_005d4e70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5224:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xa9;
          if (iVar1 != 0) {
            iVar1 = FUN_005d4f50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5225:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xaa;
          if (iVar1 != 0) {
            iVar1 = FUN_005d5030(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        case 0x5227:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xab;
          if (iVar1 != 0) {
            iVar1 = FUN_005d80f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5228:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xac;
          if (iVar1 != 0) {
            iVar1 = FUN_005d80f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5229:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xad;
          if (iVar1 != 0) {
            iVar1 = FUN_005d87f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x522a:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0xae;
          if (iVar1 != 0) {
            iVar1 = FUN_005d81d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x522e:
          iVar1 = FUN_00403c50(0x90c);
          local_8 = 0xaf;
          if (iVar1 != 0) {
            iVar1 = FUN_005d82f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x522f:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xb0;
          if (iVar1 != 0) {
            iVar1 = FUN_005ccb60(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5230:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xb1;
          if (iVar1 != 0) {
            iVar1 = FUN_005ccc40(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5231:
          iVar1 = FUN_00403c50(0x90c);
          local_8 = 0xb2;
          if (iVar1 != 0) {
            iVar1 = FUN_005d8500(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5232:
        case 0x5233:
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0xb3;
          if (iVar1 != 0) {
            iVar1 = FUN_005d86e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
        }
        goto LAB_005f15f0;
      }
      if (param_1 < 0x56e9) {
        if (param_1 == 0x56e8) {
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xe1;
          if (iVar1 != 0) {
            iVar1 = FUN_005db970(0x56e8,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 0x5600:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xc9;
          if (iVar1 != 0) {
            iVar1 = FUN_005cde70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x5601:
          iVar1 = FUN_00403c50(0x880);
          local_8 = 0xca;
          if (iVar1 != 0) {
            iVar1 = FUN_005cdfd0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        case 0x56b8:
        case 0x56b9:
        case 0x56ba:
        case 0x56bb:
        case 0x56bc:
        case 0x56c9:
          iVar1 = FUN_00403c50(0x8d4);
          local_8 = 0xcb;
          if (iVar1 != 0) {
            iVar1 = FUN_005cdd40(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56bd:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0xf0;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce3a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56be:
          iVar1 = FUN_00403c50(0x880);
          local_8 = 0xf1;
          if (iVar1 != 0) {
            iVar1 = FUN_005dc500(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56bf:
          iVar1 = FUN_00403c50(0x8b4);
          local_8 = 0xf2;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce480(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56c0:
        case 0x56c5:
        case 0x56c6:
        case 0x56c7:
        case 0x56c8:
        case 0x56ca:
        case 0x56ce:
        case 0x56d2:
        case 0x56d3:
          goto LAB_005f0431;
        case 0x56c1:
          iVar1 = FUN_00403c50(0x8cc);
          local_8 = 0xf3;
          if (iVar1 != 0) {
            iVar1 = FUN_005d08c0(param_1,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56c2:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xf4;
          if (iVar1 != 0) {
            iVar1 = FUN_005d0a40(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56c3:
          iVar1 = FUN_00403c50(0x8e4);
          local_8 = 0xf5;
          if (iVar1 != 0) {
            iVar1 = FUN_005d2030(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56cb:
        case 0x56cc:
        case 0x56cd:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0xcc;
          if (iVar1 != 0) {
            iVar1 = FUN_005d19f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56cf:
          iVar1 = FUN_00403c50(0x8d4);
          local_8 = 0xcd;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1ad0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56d0:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xce;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1c70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56d1:
          iVar1 = FUN_00403c50(0x8b4);
          local_8 = 0xcf;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1f50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56d4:
          iVar1 = FUN_00403c50(0x8a8);
          local_8 = 0xd0;
          if (iVar1 != 0) {
            iVar1 = FUN_005d4060(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56d5:
          iVar1 = FUN_00403c50(0x99c);
          local_8 = 0xd1;
          if (iVar1 != 0) {
            iVar1 = FUN_005d4350(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56d6:
        case 0x56d7:
        case 0x56d8:
        case 0x56d9:
          iVar1 = FUN_00403c50(0x8a8);
          local_8 = 0xd2;
          if (iVar1 != 0) {
            iVar1 = FUN_005d44f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56da:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xd3;
          if (iVar1 != 0) {
            iVar1 = FUN_005d46d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56db:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xd4;
          if (iVar1 != 0) {
            iVar1 = FUN_005d45f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56dc:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xd5;
          if (iVar1 != 0) {
            iVar1 = FUN_005d47a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56dd:
          iVar1 = FUN_00403c50(0x8d8);
          local_8 = 0xd6;
          if (iVar1 != 0) {
            iVar1 = FUN_005da590(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56de:
          iVar1 = FUN_00403c50(0x880);
          local_8 = 0xd7;
          if (iVar1 != 0) {
            iVar1 = FUN_005da710(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56df:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0xd8;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e0:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0xd9;
          if (iVar1 != 0) {
            iVar1 = FUN_005daac0(param_1,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e1:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0xda;
          if (iVar1 != 0) {
            iVar1 = FUN_005dabb0(param_1,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e2:
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0xdb;
          if (iVar1 != 0) {
            iVar1 = FUN_005daca0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e3:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0xdc;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e4:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0xdd;
          if (iVar1 != 0) {
            iVar1 = FUN_005dada0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e5:
          iVar1 = FUN_00403c50(0x8b4);
          local_8 = 0xde;
          if (iVar1 != 0) {
            iVar1 = FUN_005dae80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e6:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xdf;
          if (iVar1 != 0) {
            iVar1 = FUN_005dafa0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56e7:
          iVar1 = FUN_00403c50(0x8cc);
          local_8 = 0xe0;
          if (iVar1 != 0) {
            iVar1 = FUN_005db7f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
        }
        goto LAB_005f15f0;
      }
      if (param_1 < 0x59da) {
        if (param_1 == 0x59d9) {
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0xf6;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce950(0x59d9,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 0x56e9:
          iVar1 = FUN_00403c50(0x8b8);
          local_8 = 0xe2;
          if (iVar1 != 0) {
            iVar1 = FUN_005dba50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56ea:
          iVar1 = FUN_00403c50(0x8bc);
          local_8 = 0xe3;
          if (iVar1 != 0) {
            iVar1 = FUN_005dbba0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56eb:
          iVar1 = FUN_00403c50(0x8c8);
          local_8 = 0xe4;
          if (iVar1 != 0) {
            iVar1 = FUN_005dbcb0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56ec:
          iVar1 = FUN_00403c50(0x8dc);
          local_8 = 0xe5;
          if (iVar1 != 0) {
            iVar1 = FUN_005dbdd0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56ed:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0xe6;
          if (iVar1 != 0) {
            iVar1 = FUN_005dbee0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56ee:
          iVar1 = FUN_00403c50(0x8c8);
          local_8 = 0xe7;
          if (iVar1 != 0) {
            iVar1 = FUN_005db6c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56ef:
          iVar1 = FUN_00403c50(0x8d0);
          local_8 = 0xe8;
          if (iVar1 != 0) {
            iVar1 = FUN_005dc2b0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f0:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0xe9;
          if (iVar1 != 0) {
            iVar1 = FUN_005dc420(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f1:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0xea;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f2:
          iVar1 = FUN_00403c50(0x8cc);
          local_8 = 0xeb;
          if (iVar1 != 0) {
            iVar1 = FUN_005d08c0(param_1,param_2,1);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f3:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0xec;
          if (iVar1 != 0) {
            iVar1 = FUN_005d0a40(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f4:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0xed;
          if (iVar1 != 0) {
            iVar1 = FUN_005daac0(param_1,param_2,1);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f5:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0xee;
          if (iVar1 != 0) {
            iVar1 = FUN_005dabb0(param_1,param_2,1);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x56f6:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0xef;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x59da:
        iVar1 = FUN_00403c50(0x8dc);
        local_8 = 0xf7;
        if (iVar1 != 0) {
          iVar1 = FUN_005cea30(param_1,param_2,4,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59db:
        iVar1 = FUN_00403c50(0x8dc);
        local_8 = 0xf8;
        if (iVar1 != 0) {
          iVar1 = FUN_005cea30(param_1,param_2,0,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59dc:
        iVar1 = FUN_00403c50(0x8dc);
        local_8 = 0xf9;
        if (iVar1 != 0) {
          iVar1 = FUN_005cea30(param_1,param_2,1,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59dd:
        iVar1 = FUN_00403c50(0x8dc);
        local_8 = 0xfa;
        if (iVar1 != 0) {
          iVar1 = FUN_005cea30(param_1,param_2,2,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59de:
        iVar1 = FUN_00403c50(0x8dc);
        local_8 = 0xfb;
        if (iVar1 != 0) {
          iVar1 = FUN_005cea30(param_1,param_2,3,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59df:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0xfc;
        if (iVar1 != 0) {
          iVar1 = FUN_005ceb20(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e0:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0xfd;
        if (iVar1 != 0) {
          iVar1 = FUN_005cec00(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e1:
        iVar1 = FUN_00403c50(0x888);
        local_8 = 0xfe;
        if (iVar1 != 0) {
          iVar1 = FUN_005cedc0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e2:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0xff;
        if (iVar1 != 0) {
          iVar1 = FUN_005ceea0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e3:
        iVar1 = FUN_00403c50(0x898);
        local_8 = 0x100;
        if (iVar1 != 0) {
          iVar1 = FUN_005cf5b0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e4:
        iVar1 = FUN_00403c50(0x884);
        local_8 = 0x101;
        if (iVar1 != 0) {
          iVar1 = FUN_005cf690(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e5:
        iVar1 = FUN_00403c50(0x87c);
        local_8 = 0x102;
        if (iVar1 != 0) {
          iVar1 = FUN_005cfac0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e6:
        iVar1 = FUN_00403c50(0x880);
        local_8 = 0x103;
        if (iVar1 != 0) {
          iVar1 = FUN_005cfba0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e7:
        iVar1 = FUN_00403c50(0x880);
        local_8 = 0x104;
        if (iVar1 != 0) {
          iVar1 = FUN_005cfc80(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e8:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0x105;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59e9:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x106;
        if (iVar1 != 0) {
          iVar1 = FUN_005d03d0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59ea:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x107;
        if (iVar1 != 0) {
          iVar1 = FUN_005d0b80(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59eb:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x108;
        if (iVar1 != 0) {
          iVar1 = FUN_005c95e0(param_1,param_2,2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59ec:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x109;
        if (iVar1 != 0) {
          iVar1 = FUN_005d5110(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x59ed:
        iVar1 = FUN_00403c50(0x89c);
        local_8 = 0x10a;
        if (iVar1 != 0) {
          iVar1 = FUN_005d5370(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      default:
        goto LAB_005e89b9;
      }
      goto LAB_005f15f0;
    }
    if (param_1 == 0x5219) {
      iVar1 = FUN_00403c50(0x930);
      local_8 = 0xc1;
      if (iVar1 != 0) {
        iVar1 = FUN_005d0d40(0x5219,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      goto LAB_005f15f0;
    }
    if (0x4e39 < param_1) {
      if (param_1 < 0x520a) {
        if (param_1 == 0x5209) {
          iVar1 = FUN_00403c50(0x8a0);
          local_8 = 0xa5;
          if (iVar1 != 0) {
            iVar1 = FUN_005cc930(0x5209,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 0x4e3a:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x88;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6240(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e3b:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x89;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6330(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e3c:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x8a;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6440(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e3d:
          iVar1 = FUN_00403c50(0x880);
          local_8 = 0x8b;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6c70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e3e:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x8c;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6da0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e3f:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x8d;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd4e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e40:
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0x8e;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7070(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e41:
        case 0x4e42:
        case 0x4e43:
        case 0x4e44:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x8f;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6e80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e45:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x90;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6f60(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e46:
          iVar1 = FUN_00403c50(0x89c);
          local_8 = 0x91;
          if (iVar1 != 0) {
            iVar1 = FUN_005d07e0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e47:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x92;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7770(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e48:
          iVar1 = FUN_00403c50(0x89c);
          local_8 = 0x93;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7940(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e49:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x94;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7ba0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e4a:
          iVar1 = FUN_00403c50(0x900);
          local_8 = 0x95;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7a50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e4b:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x96;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7ea0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e4c:
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0x97;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7fc0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e4d:
        case 0x4e4e:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x98;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7c50(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e4f:
          iVar1 = FUN_00403c50(0x898);
          local_8 = 0x99;
          if (iVar1 != 0) {
            iVar1 = FUN_005d7d90(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e50:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x9a;
          if (iVar1 != 0) {
            iVar1 = FUN_005c9360(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e51:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x9b;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce660(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e52:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x9c;
          if (iVar1 != 0) {
            iVar1 = FUN_005d67a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e53:
          iVar1 = FUN_00403c50(0x888);
          local_8 = 0x9d;
          if (iVar1 != 0) {
            iVar1 = FUN_005d88d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e54:
          iVar1 = FUN_00403c50(0x8f4);
          local_8 = 0x9e;
          if (iVar1 != 0) {
            iVar1 = FUN_005d8d10(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e55:
          iVar1 = FUN_00403c50(0x930);
          local_8 = 0x9f;
          if (iVar1 != 0) {
            iVar1 = FUN_005d89d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e56:
          iVar1 = FUN_00403c50(0x8a0);
          local_8 = 0xa0;
          if (iVar1 != 0) {
            iVar1 = FUN_005d8bf0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e57:
          iVar1 = FUN_00403c50(0x894);
          local_8 = 0xa1;
          if (iVar1 != 0) {
            iVar1 = FUN_005d10a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e58:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0xa2;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1180(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e59:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0xa3;
          if (iVar1 != 0) {
            iVar1 = FUN_005d1270(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e5a:
          iVar1 = FUN_00403c50(0xac8);
          local_8 = 0xa4;
          if (iVar1 != 0) {
            iVar1 = FUN_005d0f90(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x520a:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0xb4;
        if (iVar1 != 0) {
          iVar1 = FUN_005ccd20(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x520b:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0xb5;
        if (iVar1 != 0) {
          iVar1 = FUN_005cc930(param_1,param_2,3);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x520c:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0xb6;
        if (iVar1 != 0) {
          iVar1 = FUN_005cce00(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x520d:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0xb7;
        if (iVar1 != 0) {
          iVar1 = FUN_005ccee0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x520e:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0xb8;
        if (iVar1 != 0) {
          iVar1 = FUN_005cd1b0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x520f:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0xb9;
        if (iVar1 != 0) {
          iVar1 = FUN_005cd990(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5210:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0xa6;
        if (iVar1 != 0) {
          iVar1 = FUN_005cc930(param_1,param_2,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5211:
        iVar1 = FUN_00403c50(0x880);
        local_8 = 0xba;
        if (iVar1 != 0) {
          iVar1 = FUN_005cdaa0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5212:
        iVar1 = FUN_00403c50(0x8e8);
        local_8 = 0xbb;
        if (iVar1 != 0) {
          iVar1 = FUN_005ce070(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5213:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0xbc;
        if (iVar1 != 0) {
          iVar1 = FUN_005c95e0(param_1,param_2,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5214:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0xbd;
        if (iVar1 != 0) {
          iVar1 = FUN_005cca80(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5215:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0xbe;
        if (iVar1 != 0) {
          iVar1 = FUN_005d0c60(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5216:
        iVar1 = FUN_00403c50(0x890);
        local_8 = 0xbf;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9360(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5217:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0xc0;
        if (iVar1 != 0) {
          iVar1 = FUN_005cf310(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x5218:
        iVar1 = FUN_00403c50(0x8a0);
        local_8 = 0xa7;
        if (iVar1 != 0) {
          iVar1 = FUN_005cc930(param_1,param_2,2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      default:
        goto LAB_005e89b9;
      }
      goto LAB_005f15f0;
    }
    if (param_1 == 0x4e39) {
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x87;
      if (iVar1 != 0) {
        iVar1 = FUN_005cd8b0(0x4e39,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      goto LAB_005f15f0;
    }
    if (0x2130 < param_1) {
      if (0x4e2e < param_1) {
        switch(param_1) {
        case 0x4e2f:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x7d;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce2c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e30:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x7e;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce580(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e31:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x7f;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce660(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e32:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x80;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce740(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e33:
          iVar1 = FUN_00403c50(0x89c);
          local_8 = 0x81;
          if (iVar1 != 0) {
            iVar1 = FUN_005ce810(param_1,param_2,0);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e34:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x82;
          if (iVar1 != 0) {
            iVar1 = FUN_005d5f80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e35:
          iVar1 = FUN_00403c50(0x89c);
          local_8 = 0x83;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6020(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e36:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x84;
          if (iVar1 != 0) {
            iVar1 = FUN_005d6130(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e37:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x85;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd6f0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e38:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x86;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd7d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        }
        goto LAB_005f15f0;
      }
      if (param_1 == 0x4e2e) {
        iVar1 = FUN_00403c50(0x888);
        local_8 = 0x7c;
        if (iVar1 != 0) {
          iVar1 = FUN_005ce1e0(0x4e2e,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      if (0x4e28 < param_1) {
        switch(param_1) {
        case 0x4e29:
          iVar1 = FUN_00403c50(0x890);
          local_8 = 0x77;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd2c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e2a:
          iVar1 = FUN_00403c50(0x888);
          local_8 = 0x78;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd3d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e2b:
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 0x79;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd5c0(param_1,param_2,0x19);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e2c:
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 0x7a;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd5c0(param_1,param_2,0x24);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x4e2d:
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 0x7b;
          if (iVar1 != 0) {
            iVar1 = FUN_005cd5c0(param_1,param_2,0x29);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        }
        goto LAB_005f15f0;
      }
      if (param_1 == 0x4e28) {
        iVar1 = FUN_00403c50(0x89c);
        local_8 = 0x76;
        if (iVar1 != 0) {
          iVar1 = FUN_005ce810(0x4e28,param_2,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      if (param_1 < 0x218d) {
        if (param_1 == 0x218c) {
          iVar1 = FUN_00403c50(0x8e0);
          local_8 = 0x1d1;
          if (iVar1 != 0) {
            iVar1 = FUN_005dff00(0x218c,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        if ((0x2175 < param_1) && ((param_1 < 0x2178 || (param_1 == 0x217d)))) {
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 100;
          if (iVar1 != 0) {
            iVar1 = FUN_005e2430(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
      }
      else {
        if (param_1 == 0x4e21) {
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x74;
          if (iVar1 != 0) {
            iVar1 = FUN_005cc5f0(0x4e21,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        if ((0x4e21 < param_1) && (param_1 < 0x4e28)) {
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0x75;
          if (iVar1 != 0) {
            iVar1 = FUN_005cc850(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
      }
      goto LAB_005e89b9;
    }
    if (param_1 == 0x2130) goto LAB_005ea448;
    if (0x1fef < param_1) {
      switch(param_1) {
      case 0x1ff0:
        goto LAB_005efce4;
      default:
        goto LAB_005e89b9;
      case 0x2006:
        goto LAB_005f0431;
      case 0x2093:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x14a;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc7c0(param_1,0x2094);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x2094:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x14b;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc820(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x2095:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x14c;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc7c0(param_1,0x2096);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x2096:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x14d;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc820(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x2097:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x14e;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc7c0(param_1,0x2098);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x2098:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x14f;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc820(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x2099:
        iVar1 = FUN_00403c50(0x874);
        local_8 = 0x150;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc7c0(param_1,0x209a);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x209a:
        iVar1 = FUN_00403c50(0x878);
        local_8 = 0x151;
        if (iVar1 != 0) {
          iVar1 = FUN_005dc820(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
      }
      goto LAB_005f15f0;
    }
    if (param_1 == 0x1fef) {
LAB_005f0431:
      iVar1 = FUN_00403c50(0x890);
      local_8 = 0x1dd;
      if (iVar1 != 0) {
        iVar1 = FUN_005c9360(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      goto LAB_005f15f0;
    }
    if (param_1 < 0x122d) {
      if (0x1229 < param_1) {
        iVar1 = FUN_00403c50(0x8d0);
        local_8 = 0x5d;
        if (iVar1 != 0) {
          iVar1 = FUN_005e6f80(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x113a:
      case 0x113b:
      case 0x113c:
      case 0x1194:
      case 0x1195:
      case 0x1196:
      case 0x119e:
      case 0x119f:
      case 0x11a0:
      case 0x11f8:
      case 0x11f9:
      case 0x11fa:
      case 0x1202:
      case 0x1203:
      case 0x1204:
      case 0x1205:
        goto LAB_005ea080;
      }
    }
    else if (param_1 < 0x13f5) {
      if (param_1 == 0x13f4) {
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x252;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9ea0(0x13f4,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x13ec:
      case 0x13ed:
      case 0x13ee:
        iVar1 = FUN_00403c50(0x870);
        local_8 = 0x251;
        if (iVar1 != 0) {
          iVar1 = FUN_005cc510(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      case 0x13f0:
      case 0x13f1:
      case 0x13f2:
      case 0x13f3:
        goto LAB_005ea123;
      }
    }
    else if (0x157b < param_1) {
      if (param_1 < 0x15ae) {
LAB_005ea225:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0x73;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9150(param_1,param_2);
          goto LAB_005e8635;
        }
        goto LAB_005e8633;
      }
      if (param_1 == 0x1fec) goto code_r0x005ea1eb;
    }
    goto LAB_005e89b9;
  }
  if (0x112f < param_1) goto LAB_005ea080;
  if (0x37a < param_1) {
    if (0x41f < param_1) {
      if (param_1 < 0x7d3) {
        if (1999 < param_1) {
LAB_005e9b35:
          iVar1 = FUN_00403c50(0x994);
          local_8 = 0x4a;
          if (iVar1 != 0) {
            iVar1 = FUN_005e60c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 0x420:
          iVar1 = FUN_00403c50(0x9a0);
          local_8 = 0x46;
          if (iVar1 != 0) {
            iVar1 = FUN_005e2cf0(param_1,param_2,9,8);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x421:
          iVar1 = FUN_00403c50(0x9a0);
          local_8 = 0x23;
          if (iVar1 != 0) {
            iVar1 = FUN_005e2d60(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x422:
        case 0x423:
        case 0x424:
          iVar1 = FUN_00403c50(0x954);
          local_8 = 0xe;
          if (iVar1 != 0) {
            iVar1 = FUN_005c88b0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x425:
          iVar1 = FUN_00403c50(0x950);
          local_8 = 0xf;
          if (iVar1 != 0) {
            iVar1 = FUN_005c8c80(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x426:
          iVar1 = FUN_00403c50(0x994);
          local_8 = 0x10;
          if (iVar1 != 0) {
            iVar1 = FUN_005c8d60(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x427:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x11;
          if (iVar1 != 0) {
            iVar1 = FUN_005e5150(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x428:
        case 0x429:
          iVar1 = FUN_00403c50(0x8dc);
          local_8 = 0x202;
          if (iVar1 != 0) {
            iVar1 = FUN_005e5230(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x42a:
        case 0x42b:
        case 0x42c:
          iVar1 = FUN_00403c50(0x874);
          local_8 = 0x203;
          if (iVar1 != 0) {
            iVar1 = FUN_005e53a0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x42d:
          goto LAB_005e99ae;
        case 0x42e:
          goto LAB_005f0431;
        case 0x42f:
          iVar1 = FUN_00403c50(0x8c8);
          local_8 = 0x70;
          if (iVar1 != 0) {
            iVar1 = FUN_005e3770(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x430:
          goto LAB_005e9974;
        default:
          goto LAB_005e89b9;
        }
        goto LAB_005f15f0;
      }
      if (param_1 < 0xaa6) {
        if (param_1 == 0xaa5) {
          iVar1 = FUN_00403c50(0x994);
          local_8 = 0x54;
          if (iVar1 != 0) {
            iVar1 = FUN_005e6e70(0xaa5,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        if (0x96c < param_1) {
          switch(param_1) {
          case 0x9c4:
          case 0x9c5:
          case 0x9c6:
          case 0x9ce:
          case 0x9cf:
          case 0x9d0:
            iVar1 = FUN_00403c50(0x994);
            local_8 = 0x4f;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6430(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          default:
            goto LAB_005e89b9;
          case 0xa28:
          case 0xa29:
          case 0xa2a:
          case 0xa32:
          case 0xa33:
          case 0xa34:
            iVar1 = FUN_00403c50(0x994);
            local_8 = 0x50;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6380(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xaa2:
            iVar1 = FUN_00403c50(0x8c0);
            local_8 = 0x51;
            if (iVar1 != 0) {
              iVar1 = FUN_005e83e0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xaa3:
            iVar1 = FUN_00403c50(0x994);
            local_8 = 0x52;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6e10(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xaa4:
            iVar1 = FUN_00403c50(0x994);
            local_8 = 0x53;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6e40(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
          }
          goto LAB_005f15f0;
        }
        if (param_1 < 0x96a) {
          if (param_1 < 0x8a5) {
            if (param_1 < 0x8a2) {
              switch(param_1) {
              case 0x7da:
              case 0x7db:
              case 0x7dc:
                goto LAB_005e9b35;
              default:
                goto LAB_005e89b9;
              case 0x834:
              case 0x835:
              case 0x836:
              case 0x83e:
              case 0x83f:
              case 0x840:
                iVar1 = FUN_00403c50(0x994);
                local_8 = 0x4b;
                if (iVar1 != 0) {
                  iVar1 = FUN_005e6170(param_1,param_2);
                  *unaff_FS_OFFSET = local_10;
                  return iVar1;
                }
                goto LAB_005f15f0;
              case 0x898:
              case 0x899:
              case 0x89a:
                break;
              }
            }
            iVar1 = FUN_00403c50(0x994);
            local_8 = 0x4c;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6220(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          }
          switch(param_1) {
          case 0x8fc:
          case 0x8fd:
          case 0x8fe:
          case 0x906:
          case 0x907:
          case 0x908:
            iVar1 = FUN_00403c50(0x994);
            local_8 = 0x4d;
            if (iVar1 != 0) {
              iVar1 = FUN_005e62d0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            goto LAB_005f15f0;
          default:
            goto LAB_005e89b9;
          case 0x960:
          case 0x961:
          case 0x962:
            break;
          }
        }
        iVar1 = FUN_00403c50(0x994);
        local_8 = 0x4e;
        if (iVar1 != 0) {
          iVar1 = FUN_005e64e0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        goto LAB_005f15f0;
      }
      if (param_1 < 0xfa3) {
        if (param_1 < 4000) {
          switch(param_1) {
          case 0xb86:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x55;
            if (iVar1 != 0) {
              iVar1 = FUN_005e66d0(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xb87:
          case 0xb88:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x56;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6780(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xb89:
          case 0xb8a:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x57;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6870(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xb8b:
          case 0xb8c:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x58;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6970(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xb8d:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x59;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6c60(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xb8e:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x5a;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6a60(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          case 0xb8f:
            iVar1 = FUN_00403c50(0x9a8);
            local_8 = 0x5b;
            if (iVar1 != 0) {
              iVar1 = FUN_005e6b60(param_1,param_2);
              *unaff_FS_OFFSET = local_10;
              return iVar1;
            }
            break;
          default:
            goto LAB_005e89b9;
          }
          goto LAB_005f15f0;
        }
      }
      else {
        if (0x106a < param_1) {
          switch(param_1) {
          case 0x1072:
          case 0x1073:
          case 0x1074:
          case 0x10cc:
          case 0x10cd:
          case 0x10ce:
          case 0x10d6:
          case 0x10d7:
          case 0x10d8:
            goto LAB_005ea080;
          default:
            goto LAB_005e89b9;
          }
        }
        if (param_1 < 0x1068) {
          switch(param_1) {
          case 0xfaa:
          case 0xfab:
          case 0xfac:
          case 0x1004:
          case 0x1005:
          case 0x1006:
          case 0x100e:
          case 0x100f:
          case 0x1010:
            break;
          default:
            goto LAB_005e89b9;
          }
        }
      }
LAB_005ea080:
      iVar1 = FUN_00403c50(0x880);
      local_8 = 0x5c;
      if (iVar1 != 0) {
        iVar1 = FUN_005e6ea0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      goto LAB_005f15f0;
    }
    if (param_1 == 0x41f) {
      iVar1 = FUN_00403c50(0x96c);
      local_8 = 0x45;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4c00(0x41f,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      goto LAB_005f15f0;
    }
    switch(param_1) {
    case 0x37b:
LAB_005e9738:
      iVar1 = FUN_00403c50(0x888);
      local_8 = 99;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2140(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    default:
      goto LAB_005e89b9;
    case 0x385:
    case 0x386:
    case 0x387:
    case 0x388:
    case 0x389:
    case 0x38a:
    case 0x38b:
    case 0x38c:
    case 0x38d:
    case 0x38e:
    case 0x38f:
    case 0x390:
    case 0x391:
    case 0x392:
    case 0x393:
    case 0x394:
    case 0x395:
    case 0x396:
    case 0x397:
    case 0x398:
    case 0x399:
    case 0x39a:
    case 0x3b6:
    case 0x3b7:
    case 0x3b8:
    case 0x3b9:
    case 0x3ba:
    case 0x3bb:
    case 0x3bc:
    case 0x3bd:
    case 0x3be:
    case 0x3bf:
    case 0x3c0:
    case 0x3c1:
      goto LAB_005ea123;
    case 0x39b:
    case 0x39c:
    case 0x39d:
    case 0x39e:
    case 0x39f:
    case 0x3a0:
    case 0x3a1:
    case 0x3a2:
    case 0x3a3:
    case 0x3a4:
    case 0x3a5:
    case 0x3a6:
    case 0x3a7:
    case 0x3a8:
    case 0x3a9:
    case 0x3aa:
      goto LAB_005e97ac;
    case 1000:
      iVar1 = FUN_00403c50(0x968);
      local_8 = 0x1b;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2770(param_1,param_2);
        goto LAB_005e8635;
      }
      goto LAB_005e8633;
    case 0x3e9:
    case 0x3ea:
    case 0x3eb:
    case 0x3ec:
    case 0x3ed:
      iVar1 = FUN_00403c50(0x954);
      local_8 = 0x1f;
      if (iVar1 != 0) {
        iVar1 = FUN_005e71b0(param_1,0,param_1 + -0x3e9);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3ee:
    case 0x3ef:
      iVar1 = FUN_00403c50(0x8c8);
      local_8 = 0x20;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2a70(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3f0:
    case 0x3f1:
    case 0x3f2:
      iVar1 = FUN_00403c50(0x9a0);
      local_8 = 0x21;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2b70(param_1,param_2,0x12,2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3f3:
    case 0x3f4:
    case 0x3f5:
    case 0x419:
      iVar1 = FUN_00403c50(0x9a0);
      local_8 = 0x22;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2b70(param_1,param_2,2,3);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3f6:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x24;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2e00(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3f7:
LAB_005ea448:
      iVar1 = FUN_00403c50(0x96c);
      local_8 = 0x25;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2ea0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3f8:
      iVar1 = FUN_00403c50(0x88c);
      local_8 = 0x26;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2fe0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3f9:
    case 0x3fa:
    case 0x3fb:
LAB_005e96fe:
      iVar1 = FUN_00403c50(0x8a0);
      local_8 = 0x5f;
      if (iVar1 != 0) {
        iVar1 = FUN_005e1ee0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3fc:
LAB_005e9772:
      iVar1 = FUN_00403c50(0x894);
      local_8 = 0x65;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2560(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x3fd:
      goto LAB_005e904d;
    case 0x3ff:
      iVar1 = FUN_00403c50(0x8cc);
      local_8 = 0x27;
      if (iVar1 != 0) {
        iVar1 = FUN_005e31a0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x400:
      iVar1 = FUN_00403c50(0x8b4);
      local_8 = 0x28;
      if (iVar1 != 0) {
        iVar1 = FUN_005e33c0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x401:
LAB_005e9974:
      iVar1 = FUN_00403c50(0x880);
      local_8 = 0x29;
      if (iVar1 != 0) {
        iVar1 = FUN_005e34c0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x402:
      iVar1 = FUN_00403c50(0x958);
      local_8 = 0x2a;
      if (iVar1 != 0) {
        iVar1 = FUN_005e35f0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x403:
      iVar1 = FUN_00403c50(0x870);
      local_8 = 0x2b;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3690(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x404:
      iVar1 = FUN_00403c50(0x878);
      local_8 = 0x2c;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3940(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x405:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x2d;
      if (iVar1 != 0) {
        iVar1 = FUN_005e39e0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x406:
      iVar1 = FUN_00403c50(0x88c);
      local_8 = 0x35;
      if (iVar1 != 0) {
        iVar1 = FUN_005e32d0(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x407:
      iVar1 = FUN_00403c50(0x9a0);
      local_8 = 0x36;
      if (iVar1 != 0) {
        iVar1 = FUN_005e2c80(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x408:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x37;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3550(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x409:
      iVar1 = FUN_00403c50(0x880);
      local_8 = 0x39;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3b60(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x40a:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x38;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3550(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x40b:
      iVar1 = FUN_00403c50(0x94c);
      local_8 = 0x1a;
      if (iVar1 != 0) {
        iVar1 = FUN_005e42f0(param_1,param_2);
        goto LAB_005e8635;
      }
      goto LAB_005e8633;
    case 0x40c:
    case 0x410:
    case 0x414:
LAB_005e99ae:
      iVar1 = FUN_00403c50(0x958);
      local_8 = 0x3a;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3d30(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x40d:
    case 0x411:
      iVar1 = FUN_00403c50(0x96c);
      local_8 = 0x3b;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3e10(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x40e:
    case 0x412:
      iVar1 = FUN_00403c50(0x960);
      local_8 = 0x3c;
      if (iVar1 != 0) {
        iVar1 = FUN_005e3f50(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x40f:
    case 0x413:
      iVar1 = FUN_00403c50(0x96c);
      local_8 = 0x3d;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4030(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x415:
      iVar1 = FUN_00403c50(0x96c);
      local_8 = 0x3e;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4110(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x416:
      iVar1 = FUN_00403c50(0x964);
      local_8 = 0x3f;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4210(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x417:
      iVar1 = FUN_00403c50(0x96c);
      local_8 = 0x40;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4280(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x41a:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x41;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4390(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x41b:
      iVar1 = FUN_00403c50(0x880);
      local_8 = 0x42;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4470(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x41d:
      iVar1 = FUN_00403c50(0x874);
      local_8 = 0x43;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4550(param_1,param_2);
        *unaff_FS_OFFSET = local_10;
        return iVar1;
      }
      break;
    case 0x41e:
      iVar1 = FUN_00403c50(0x954);
      local_8 = 0x44;
      if (iVar1 != 0) {
        iVar1 = FUN_005e4b20(param_1,param_2);
        goto LAB_005e8635;
      }
      goto LAB_005e8633;
    }
    goto LAB_005f15f0;
  }
  if (param_1 == 0x37a) {
    iVar1 = FUN_00403c50(0x88c);
    local_8 = 0x1e;
    if (iVar1 != 0) {
      iVar1 = FUN_005e2270(0x37a,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    goto LAB_005f15f0;
  }
  if (param_1 < 0x30e) {
    if (0x301 < param_1) goto LAB_005e904d;
    if (0x11e < param_1) {
      if (param_1 < 0x159) {
        if (param_1 == 0x158) {
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x6b;
          if (iVar1 != 0) {
            iVar1 = FUN_005ddf70(0x158,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 0x123:
        case 0x124:
        case 0x125:
        case 0x126:
        case 0x127:
        case 0x128:
        case 0x12d:
        case 0x12e:
        case 0x12f:
        case 0x130:
        case 0x131:
        case 0x132:
        case 0x133:
        case 0x134:
        case 0x135:
        case 0x136:
        case 0x137:
        case 0x138:
        case 0x139:
        case 0x13a:
        case 0x13b:
        case 0x13c:
        case 0x152:
        case 0x153:
          goto LAB_005ea123;
        default:
          goto LAB_005e89b9;
        case 300:
          goto LAB_005e904d;
        case 0x13f:
        case 0x140:
        case 0x141:
        case 0x142:
        case 0x143:
        case 0x146:
        case 0x147:
        case 0x148:
        case 0x149:
        case 0x14a:
        case 0x14d:
        case 0x14e:
        case 0x14f:
        case 0x150:
        case 0x151:
          goto LAB_005e8a6f;
        case 0x154:
          iVar1 = FUN_00403c50(0x884);
          local_8 = 0x67;
          if (iVar1 != 0) {
            iVar1 = FUN_005e5560(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x155:
          iVar1 = FUN_00403c50(0x888);
          local_8 = 0x68;
          if (iVar1 != 0) {
            iVar1 = FUN_005e5650(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x156:
          iVar1 = FUN_00403c50(0x8d8);
          local_8 = 0x69;
          if (iVar1 != 0) {
            iVar1 = FUN_005e57d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        case 0x157:
          iVar1 = FUN_00403c50(0x878);
          local_8 = 0x6a;
          if (iVar1 != 0) {
            iVar1 = FUN_005e5a20(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
        }
        goto LAB_005f15f0;
      }
      if (param_1 < 0x2c3) {
        if (0x2bd < param_1) {
LAB_005e8a6f:
          iVar1 = FUN_00403c50(0x88c);
          local_8 = 0x6e;
          if (iVar1 != 0) {
            iVar1 = FUN_005e7900(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        if (param_1 < 0x28f) {
          if (0x27f < param_1) goto LAB_005e904d;
          if (param_1 < 0x279) {
            if (600 < param_1) goto LAB_005ea225;
            if (0x168 < param_1) {
              bVar3 = SBORROW4(param_1,500);
              iVar1 = param_1 + -500;
              bVar2 = param_1 == 500;
              goto LAB_005e89b3;
            }
          }
        }
        else {
          if (param_1 == 0x294) {
            iVar1 = FUN_00403c50(0x96c);
            local_8 = 0xd;
            if (iVar1 != 0) {
              iVar1 = FUN_005c8e60(0x294,param_2);
              goto LAB_005e8635;
            }
            goto LAB_005e8633;
          }
          if (0x29e < param_1) {
            bVar3 = SBORROW4(param_1,0x2a8);
            iVar1 = param_1 + -0x2a8;
            bVar2 = iVar1 == 0;
LAB_005e89b3:
            if (bVar2 || bVar3 != iVar1 < 0) goto LAB_005ea225;
          }
        }
      }
      else {
        switch(param_1) {
        case 0x2c5:
        case 0x2c6:
        case 0x2c7:
        case 0x2c8:
        case 0x2c9:
        case 0x2cc:
        case 0x2cd:
        case 0x2ce:
        case 0x2cf:
        case 0x2d0:
          goto LAB_005e8a6f;
        case 0x2d1:
          iVar1 = FUN_00403c50(0x870);
          local_8 = 0x6f;
          if (iVar1 != 0) {
            iVar1 = FUN_005e3c70(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        case 0x2df:
        case 0x2e0:
        case 0x2e1:
        case 0x2e2:
        case 0x2e3:
        case 0x2e4:
        case 0x2e5:
        case 0x2e6:
        case 0x2e7:
        case 0x2e8:
        case 0x2e9:
        case 0x2ea:
        case 0x2eb:
        case 0x2ec:
          goto LAB_005ea123;
        }
      }
      goto LAB_005e89b9;
    }
    if (param_1 < 0x119) {
      if (param_1 < 0xfb) {
        if (0xf0 < param_1) {
          iVar1 = FUN_00403c50(0x8b0);
          local_8 = 1;
          if (iVar1 != 0) {
            iVar1 = FUN_005c8660(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005f15f0;
        }
        switch(param_1) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xd:
        case 0xe:
        case 0xf:
        case 0x10:
        case 0x11:
        case 0x12:
        case 0x13:
        case 0x14:
        case 0x15:
        case 0x33:
        case 0x34:
          iVar1 = FUN_00403c50(0x87c);
          local_8 = 0;
          if (iVar1 != 0) {
            iVar1 = FUN_005c96d0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          break;
        default:
          goto LAB_005e89b9;
        case 0xdd:
        case 0xe7:
        case 0xeb:
        case 0xee:
        case 0xef:
          goto LAB_005e904d;
        case 0xde:
          goto LAB_005e8b00;
        case 0xdf:
        case 0xe0:
        case 0xe1:
        case 0xe2:
        case 0xe3:
        case 0xe4:
        case 0xe5:
        case 0xe6:
          iVar1 = FUN_00403c50(0x94c);
          local_8 = 8;
          if (iVar1 != 0) {
            iVar1 = FUN_005e70c0(param_1,param_2);
            *(undefined1 *)(iVar1 + 0x7d9) = 1;
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
          goto LAB_005e8633;
        case 0xec:
        case 0xed:
          goto LAB_005e8f00;
        case 0xf0:
          iVar1 = FUN_00403c50(0x954);
          local_8 = 0x1c;
          if (iVar1 != 0) {
            iVar1 = FUN_005e72c0(param_1,param_2);
            *unaff_FS_OFFSET = local_10;
            return iVar1;
          }
        }
        goto LAB_005f15f0;
      }
      switch(param_1) {
      case 0x102:
        iVar1 = FUN_00403c50(0x87c);
        local_8 = 2;
        if (iVar1 != 0) {
          iVar1 = FUN_005e30c0(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      default:
        goto LAB_005e89b9;
      case 0x105:
        goto LAB_005f0931;
      case 0x106:
      case 0x107:
      case 0x108:
        goto LAB_005e96fe;
      case 0x109:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0x60;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9be0(param_1,3,0x5dc,0,0);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x10a:
        iVar1 = FUN_00403c50(0x894);
        local_8 = 0x61;
        if (iVar1 != 0) {
          iVar1 = FUN_005c9be0(param_1,5,0x5dc,0,1);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x10b:
        iVar1 = FUN_00403c50(0x884);
        local_8 = 0x62;
        if (iVar1 != 0) {
          iVar1 = FUN_005e2060(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x10c:
        goto LAB_005e9738;
      case 0x10d:
        goto LAB_005e9772;
      case 0x10e:
        iVar1 = FUN_00403c50(0x88c);
        local_8 = 0x66;
        if (iVar1 != 0) {
          iVar1 = FUN_005e2690(param_1,param_2);
          *unaff_FS_OFFSET = local_10;
          return iVar1;
        }
        break;
      case 0x10f:
      case 0x110:
      case 0x111:
      case 0x112:
      case 0x113:
      case 0x114:
        goto LAB_005ea123;
      }
      goto LAB_005f15f0;
    }
LAB_005ea123:
    iVar1 = FUN_00403c50(0x870);
    local_8 = 0x6c;
    if (iVar1 != 0) {
      iVar1 = FUN_005c85a0(param_1,param_2);
      goto LAB_005e8635;
    }
    goto LAB_005e8633;
  }
  switch(param_1) {
  case 0x318:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 0x71;
    if (iVar1 != 0) {
      iVar1 = FUN_00490830(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x319:
    iVar1 = FUN_00403c50(0x8dc);
    local_8 = 0x72;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4d20(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  default:
    goto LAB_005e89b9;
  case 799:
    iVar1 = FUN_00403c50(0x878);
    local_8 = 9;
    if (iVar1 != 0) {
      iVar1 = FUN_005e5480(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 800:
  case 0x322:
  case 0x323:
  case 0x326:
  case 0x327:
  case 0x328:
  case 0x329:
  case 0x33a:
  case 0x33b:
  case 0x33c:
  case 0x343:
  case 0x344:
  case 0x34d:
  case 0x34e:
  case 0x350:
  case 0x352:
  case 0x354:
  case 0x355:
  case 0x356:
  case 0x357:
  case 0x358:
  case 0x35c:
  case 0x35d:
  case 0x35e:
  case 0x35f:
  case 0x360:
  case 0x374:
  case 0x375:
  case 0x376:
  case 0x377:
  case 0x378:
LAB_005e904d:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 10;
    if (iVar1 != 0) {
      iVar1 = FUN_00490830(param_1,param_2);
      goto LAB_005e8635;
    }
    goto LAB_005e8633;
  case 0x321:
  case 0x32a:
  case 0x32b:
  case 0x32c:
  case 0x32d:
  case 0x334:
  case 0x335:
  case 0x336:
  case 0x337:
  case 0x363:
  case 0x364:
  case 0x365:
    goto LAB_005ea123;
  case 0x324:
  case 0x325:
  case 0x348:
  case 0x349:
  case 0x34a:
  case 0x34b:
    iVar1 = FUN_00403c50(0x870);
    local_8 = 0x13;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4880(param_1,param_2);
      goto LAB_005e8635;
    }
    goto LAB_005e8633;
  case 0x32e:
    iVar1 = FUN_00403c50(0x878);
    local_8 = 0x47;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4630(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x32f:
  case 0x33e:
  case 0x351:
LAB_005e8b00:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 3;
    if (iVar1 != 0) {
      iVar1 = FUN_005c8f40(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x330:
  case 0x33f:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 4;
    if (iVar1 != 0) {
      iVar1 = FUN_005c90d0(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x331:
    iVar1 = FUN_00403c50(0x96c);
    local_8 = 0x15;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4710(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x332:
    iVar1 = FUN_00403c50(0x950);
    local_8 = 0x16;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4960(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x333:
    iVar1 = FUN_00403c50(0x968);
    local_8 = 0x17;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4a40(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x340:
  case 0x341:
    iVar1 = FUN_00403c50(0x99c);
    local_8 = 5;
    if (iVar1 != 0) {
      iVar1 = FUN_005cbe30(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x342:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 0x12;
    if (iVar1 != 0) {
      iVar1 = FUN_005cbf30(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x345:
  case 0x346:
    iVar1 = FUN_00403c50(0x9b8);
    local_8 = 6;
    if (iVar1 != 0) {
      iVar1 = FUN_005cc050(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x347:
    iVar1 = FUN_00403c50(0x870);
    local_8 = 7;
    if (iVar1 != 0) {
      iVar1 = FUN_005cbfe0(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x34c:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 0x14;
    if (iVar1 != 0) {
      iVar1 = FUN_00490830(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x34f:
LAB_005ee3a6:
    iVar1 = FUN_00403c50(0x958);
    local_8 = 0xc;
    if (iVar1 != 0) {
      iVar1 = FUN_005c87d0(param_1,param_2);
      goto LAB_005e8635;
    }
    goto LAB_005e8633;
  case 0x353:
    iVar1 = FUN_00403c50(0x94c);
    local_8 = 0xb;
    if (iVar1 != 0) {
      iVar1 = FUN_005c8990(param_1,param_2);
      goto LAB_005e8635;
    }
    goto LAB_005e8633;
  case 0x359:
    iVar1 = FUN_00403c50(0x8ac);
    local_8 = 0x18;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4e50(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x35a:
  case 0x361:
    iVar1 = FUN_00403c50(0x87c);
    local_8 = 0x19;
    if (iVar1 != 0) {
      iVar1 = FUN_005e4f30(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x35b:
LAB_005e8f00:
    iVar1 = FUN_00403c50(0x958);
    local_8 = 0x49;
    if (iVar1 != 0) {
      iVar1 = FUN_005e5b60(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x362:
  case 0x371:
  case 0x372:
  case 0x373:
    iVar1 = FUN_00403c50(0x890);
    local_8 = 0x48;
    if (iVar1 != 0) {
      iVar1 = FUN_005e5010(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x366:
  case 0x367:
  case 0x368:
  case 0x369:
  case 0x36a:
  case 0x36b:
  case 0x36c:
  case 0x36d:
  case 0x36e:
LAB_005e97ac:
    iVar1 = FUN_00403c50(0x870);
    local_8 = 0x6d;
    if (iVar1 != 0) {
      iVar1 = FUN_005c85a0(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
    break;
  case 0x36f:
  case 0x370:
    iVar1 = FUN_00403c50(0x954);
    local_8 = 0x23a;
    if (iVar1 != 0) {
      iVar1 = FUN_005e73b0(param_1,param_2);
      goto LAB_005e8635;
    }
LAB_005e8633:
    iVar1 = 0;
LAB_005e8635:
    *(undefined1 *)(iVar1 + 0x7d9) = 1;
    *unaff_FS_OFFSET = local_10;
    return iVar1;
  case 0x379:
    iVar1 = FUN_00403c50(0x87c);
    local_8 = 0x1d;
    if (iVar1 != 0) {
      iVar1 = FUN_005e2350(param_1,param_2);
      *unaff_FS_OFFSET = local_10;
      return iVar1;
    }
  }
LAB_005f15f0:
  *unaff_FS_OFFSET = local_10;
  return 0;
}

