
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_008c1a30(int ***param_1,int **param_2,int *param_3)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  undefined4 uVar6;
  int **ppiVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  int *in_ECX;
  byte bVar11;
  uint uVar12;
  undefined4 *unaff_FS_OFFSET;
  bool bVar13;
  float10 fVar14;
  int *piVar15;
  undefined1 *puVar16;
  int *piVar17;
  undefined4 uVar18;
  undefined **ppuVar19;
  undefined **ppuVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  int **ppiStack_b8c;
  int ***pppiStack_b88;
  undefined1 auStack_b5c [2048];
  undefined1 auStack_35c [256];
  undefined1 auStack_25c [408];
  undefined1 auStack_c4 [8];
  undefined4 local_bc;
  undefined1 auStack_b8 [4];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined1 auStack_a8 [20];
  undefined2 uStack_94;
  undefined4 uStack_92;
  undefined4 uStack_8e;
  undefined4 uStack_8a;
  undefined2 uStack_86;
  undefined2 uStack_84;
  undefined2 uStack_82;
  undefined2 uStack_80;
  undefined2 uStack_7e;
  undefined2 uStack_7c;
  undefined2 uStack_7a;
  int *piStack_78;
  int iStack_74;
  int *piStack_70;
  int *piStack_6c;
  int *piStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  int *piStack_54;
  byte bStack_4d;
  uint uStack_4c;
  uint *puStack_48;
  int *piStack_44;
  byte bStack_3f;
  char cStack_3e;
  char cStack_3d;
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int **ppiStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  undefined4 local_10;
  undefined1 *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_00c830ad;
  local_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &local_10;
  (**(code **)(*in_ECX + 0x48))();
  local_bc = FUN_00402060();
  FUN_008addb0();
  iVar3 = FUN_00a5e0c0();
  ppiVar7 = param_2;
  if (iVar3 != *(int *)((int)param_2 + 3)) {
    (*(code *)PTR_FUN_00ff2ebc)();
    *unaff_FS_OFFSET = local_10;
    return;
  }
  FUN_008c69b0();
  switch(*(undefined2 *)((int)ppiVar7 + 1)) {
  case 0:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_3 = (int *)((uint)param_3 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))();
    param_2 = (int **)((uint)param_2 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    pppiStack_b88 = (int ***)u__UDP_RECV___d__d__d__00e31394;
    ppiStack_b8c = (int **)0x8c1c4c;
    (*(code *)PTR_FUN_00ff2ebc)();
    if (param_3._3_1_ == '\0') {
      pppiStack_b88 = (int ***)0x8c1c69;
      FUN_008beba0();
      FUN_004b79d0();
      pppiStack_b88 = (int ***)u__UDP_REPLY_TO___d__State__d_Addr_00e31348;
    }
    else {
      if (param_3._3_1_ != '\x01') {
        if ((param_3._3_1_ == '\x02') &&
           (*(char *)(((uint)param_1 >> 0x18) + 0x10a0cf + (int)in_ECX) != '\0')) {
          iVar3 = FUN_004b79d0();
          if (iVar3 == 0) {
            FUN_00b83a80();
            iVar3 = FUN_00b86330();
            if (iVar3 <= (int)((uint)param_2 >> 0x18)) break;
          }
          if (param_2._3_1_ == '\x02') {
            *(undefined1 *)(param_1._3_1_ + 0x10a778 + (int)in_ECX) = 1;
            FUN_00b83a80();
            iVar3 = FUN_00b86330();
            if (iVar3 == -1) {
              piStack_18 = (int *)((uint)param_1 >> 0x18);
              FUN_00b83a80();
              FUN_00b862f0();
              pppiStack_b88 = (int ***)0x8c1e4e;
              FUN_008c0340();
            }
          }
          else {
            *(undefined1 *)(param_1._3_1_ + 0x10a778 + (int)in_ECX) = 0;
            piStack_18 = (int *)(uint)param_1._3_1_;
            FUN_00b83a80();
            FUN_00b862f0();
            iVar3 = FUN_004b79d0();
            if ((iVar3 == 0) &&
               (*(char *)((int)in_ECX + ((uint)param_1 >> 0x18) + 0x10a608) != '\0')) {
              *(undefined1 *)((int)in_ECX + ((uint)param_1 >> 0x18) + 0x10a5cc) = 0;
              iVar3 = 0;
              do {
                if (*(char *)((int)in_ECX + iVar3 + 0x10a5cc) != '\0') goto LAB_008c1ead;
                iVar3 = iVar3 + 1;
              } while (iVar3 < 8);
              FUN_00b84730();
            }
LAB_008c1ead:
            pppiStack_b88 = (int ***)0x8c1ebc;
            FUN_008c0340();
            *(undefined1 *)(((uint)param_1 >> 0x18) + 0x10a608 + (int)in_ECX) = 0;
          }
          FUN_004b7b80();
          FUN_004b79d0();
          pppiStack_b88 = (int ***)u__UDP_FINISH_FROM___d__State__d_A_00e312a8;
          ppiStack_b8c = (int **)0x8c1ef8;
          (*(code *)PTR_FUN_00ff2ebc)();
          *unaff_FS_OFFSET = local_10;
          return;
        }
        break;
      }
      iVar3 = FUN_004b79d0();
      if (iVar3 == 0) {
        FUN_00b83a80();
        iVar3 = FUN_00b86330();
        if (iVar3 <= (int)((uint)param_2 >> 0x18)) break;
      }
      if (param_2._3_1_ != '\x02') {
        *(undefined1 *)(param_1._3_1_ + 0x10a608 + (int)in_ECX) = 0;
      }
      piStack_18 = (int *)(uint)param_1._3_1_;
      FUN_00b83a80();
      FUN_00b862f0();
      pppiStack_b88 = (int ***)0x8c1cff;
      FUN_008c0340();
      if (param_2._3_1_ == '\x02') {
        *(undefined1 *)(param_1._3_1_ + 0x10a778 + (int)in_ECX) = 1;
      }
      else {
        *(undefined1 *)(param_1._3_1_ + 0x10a778 + (int)in_ECX) = 0;
      }
      iVar3 = FUN_00402060();
      if (iVar3 == 9) {
        pppiStack_b88 = (int ***)&LAB_008c1d47;
        FUN_008beba0();
      }
      FUN_004b7b80();
      FUN_004b79d0();
      pppiStack_b88 = (int ***)u__UDP_RETURN_FROM___d__State__d_A_00e312f8;
    }
    ppiStack_b8c = (int **)0x8c1d78;
    (*(code *)PTR_FUN_00ff2ebc)();
    *(undefined1 *)(((uint)param_1 >> 0x18) + 0x10a0cf + (int)in_ECX) = 1;
    *unaff_FS_OFFSET = local_10;
    return;
  case 2:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    uStack_30 = uStack_30 & 0xffffff;
    param_3 = (int *)((uint)param_3 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    iVar3 = *(int *)(DAT_01002848 + 0x1050);
    param_2 = (int **)((uint)param_2 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    *(uint *)(iVar3 + 0x21c) = (uint)param_2 >> 0x18;
    uStack_84 = 0;
    uStack_82 = 0;
    uStack_80 = 0;
    uStack_7e = 0;
    uStack_7c = 0;
    uStack_7a = 0;
    uStack_8 = 0;
    FUN_008c6820();
    piStack_1c = (int *)0x0;
    if (param_1._3_1_ != '\0') {
      do {
        ppiStack_20 = (int **)0x0;
        (**(code **)(*in_ECX + 0x54))();
        FUN_00abbbc0();
        piStack_18 = (int *)((uint)ppiStack_20 & 0xffff);
        FUN_00407120();
        piStack_1c = (int *)((int)piStack_1c + 1);
      } while ((int)piStack_1c < (int)((uint)param_1 >> 0x18));
    }
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))();
    pppiStack_b88 = (int ***)0x8c1fc9;
    FUN_00ab7d30();
    FUN_00abac20();
    FUN_00644d50();
    *unaff_FS_OFFSET = local_10;
    return;
  case 3:
    param_2 = (int **)((uint)param_2 & 0xffffff);
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))();
    FUN_00ab7d30();
    *unaff_FS_OFFSET = local_10;
    return;
  case 4:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_2 = (int **)((uint)param_2 & 0xffffff);
    param_3 = (int *)((uint)param_3 & 0xffffff);
    piStack_24 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piStack_34 = (int *)0x0;
    ppiStack_20 = (int **)0x0;
    (**(code **)(*in_ECX + 0x50))();
    piStack_28 = (int *)((uint)param_1 >> 0x18);
    if (piStack_28 != (int *)0x0) {
      do {
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x54))();
        pppiStack_b88 = (int ***)0x8c20a7;
        (**(code **)(*in_ECX + 0x50))();
        pppiStack_b88 = (int ***)((int)&param_3 + 3);
        ppiStack_b8c = (int **)0x8c20b2;
        (**(code **)(*in_ECX + 0x50))();
        ppiStack_b8c = &piStack_14;
        (**(code **)(*in_ECX + 0x5c))();
        if ((((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) &&
            ((piVar4 = (int *)FUN_0050b820(), piVar4 != (int *)0x0 &&
             (((uint)param_2 >> 0x18 == *(uint *)(in_ECX[0x42818] + 0xb8) &&
              ((uint)param_3 >> 0x18 == *(uint *)(in_ECX[0x42818] + 0xbc))))))) &&
           ((piStack_18 = (int *)(**(code **)(*piVar4 + 0x160))(), piStack_18 == (int *)0x0 ||
            ((uVar12 = (**(code **)(*piStack_18 + 0x3c))(), uVar12 == ((uint)piStack_34 & 0xffff) &&
             (uVar12 = (**(code **)(*piStack_18 + 0x40))(), uVar12 == ((uint)ppiStack_20 & 0xffff)))
            )))) {
          (**(code **)(*piVar4 + 0x48))();
          FUN_00510350();
        }
        piStack_28 = (int *)((int)piStack_28 - 1);
      } while (piStack_28 != (int *)0x0);
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 5:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    piStack_24 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piStack_6c = (int *)0x0;
    piStack_68 = (int *)0x0;
    uStack_64 = 0;
    uStack_8 = 1;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    uStack_b4 = 0;
    uStack_b0 = 0;
    uStack_ac = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_008c6290();
    iVar3 = 0;
    if ((short)param_3 != 0) {
      do {
        (**(code **)(*in_ECX + 0x50))();
        FUN_0041f890();
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)((uint)param_3 & 0xffff));
    }
    uStack_84 = 0;
    uStack_82 = 0;
    uStack_80 = 0;
    uStack_7e = 0;
    uStack_7c = 0;
    uStack_7a = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_008c6600();
    FUN_004ed490();
    if ((in_ECX[0x42818] == 0) || (*(int *)(in_ECX[0x42818] + 0xb0) == 0)) goto LAB_008c5875;
    pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
    ppiStack_b8c = (int **)0x0;
    uVar6 = FUN_0050b820((uint)piStack_24 & 0xffff,(uint)piStack_1c & 0xffff);
    piVar4 = (int *)FUN_00c00d0b(uVar6);
    if (piVar4 == (int *)0x0) goto LAB_008c5875;
    piVar8 = (int *)(**(code **)(*piVar4 + 0x124))();
    piStack_14 = piVar8;
    piStack_34 = (int *)(**(code **)(*piVar4 + 300))();
    uStack_3c = (**(code **)(*piVar4 + 0x128))();
    if (piVar8 != (int *)0x0) {
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)&LAB_008c22b6;
      (**(code **)(*piVar4 + 0x11c))();
    }
    FUN_00402d20();
    param_2 = (int **)0xffffffff;
    cVar1 = (**(code **)(*piVar4 + 0x2c))();
    if (cVar1 == '\0') {
      pppiStack_b88 = (int ***)0x8c22dd;
      cVar1 = (**(code **)(*piVar4 + 0x2c))();
      if (cVar1 != '\0') goto LAB_008c22f3;
      pppiStack_b88 = (int ***)0x8c22ed;
      cVar1 = (**(code **)(*piVar4 + 0x2c))();
      if (cVar1 != '\0') goto LAB_008c22f3;
    }
    else {
LAB_008c22f3:
      param_2 = (int **)(**(code **)(*piVar4 + 0x230))();
    }
    piStack_18 = (int *)FUN_00a530f0();
    pppiStack_b88 = (int ***)((uint)param_1 >> 0x18);
    ppiStack_b8c = param_2;
    uVar6 = (**(code **)(*piVar4 + 0x40))();
    FUN_00a52aa0(0,u_setState_Crash_Report_name__s_ui_00e31208,piStack_18,uVar6);
    pppiStack_b88 = (int ***)0x8c234e;
    FUN_0040eb40();
    for (uVar12 = 0;
        (piStack_6c != (int *)0x0 && (uVar12 < (uint)((int)piStack_68 - (int)piStack_6c >> 2)));
        uVar12 = uVar12 + 1) {
      ppiStack_b8c = (int **)u_datas__d_____d_00e311e4;
      pppiStack_b88 = (int ***)uVar12;
      FUN_00a52aa0(0);
      pppiStack_b88 = (int ***)0x8c2381;
      FUN_0040eb70();
    }
    pppiStack_b88 = (int ***)0x1;
    ppiStack_b8c = &piStack_70;
    (**(code **)(*piVar4 + 0x22c))((uint)param_1 >> 0x18);
    piVar8 = piStack_14;
    if ((piStack_14 != (int *)0x0) &&
       (((((cVar1 = (**(code **)(*piVar4 + 0x2c))(0x11), cVar1 == '\0' || (param_1._3_1_ == '\x03'))
          || (param_1._3_1_ == '\x04')) || ((param_1._3_1_ == '\x05' || (param_1._3_1_ == '\t'))))
        || ((piVar8 != (int *)0x1 || (piStack_34 == (int *)0xffffffff)))))) {
      (**(code **)(*piVar4 + 0x11c))(piVar8,piStack_34,uStack_3c);
    }
    uVar12 = (**(code **)(*piVar4 + 0x294))();
    if (uVar12 == (uint)param_1 >> 0x18) {
      (**(code **)(*piVar4 + 0x298))();
    }
    cVar1 = FUN_0049c090();
    if (cVar1 != '\0') {
      pppiStack_b88 = (int ***)0x8c2416;
      (**(code **)(*piVar4 + 0x48))();
      pppiStack_b88 = (int ***)0x8c241d;
      FUN_00511b70();
    }
LAB_008c5875:
    FUN_00644d50();
    FUN_00644d50();
    FUN_00644d50();
    *unaff_FS_OFFSET = local_10;
    return;
  case 6:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      iVar3 = FUN_0055bcd0();
      if ((iVar3 == 0) ||
         ((*(int *)(iVar3 + 0x204) == 0 || (cVar1 = FUN_0050b0d0(), cVar1 == '\0')))) {
        pppiStack_b88 = (int ***)&DAT_00e310b8;
        ppiStack_b8c = (int **)0x8c25e9;
        (*(code *)PTR_FUN_00ff2ebc)();
        *unaff_FS_OFFSET = local_10;
        return;
      }
      piVar4 = (int *)FUN_0050b820();
      if (piVar4 == (int *)0x0) {
        (*(code *)PTR_FUN_00ff2ebc)();
        *unaff_FS_OFFSET = local_10;
        return;
      }
      cVar1 = (**(code **)(*piVar4 + 0x2c))();
      if (cVar1 == '\0') {
        cVar1 = (**(code **)(*piVar4 + 0x2c))();
        if (cVar1 == '\0') break;
        pppiStack_b88 = (int ***)&PTR_PTR_00f4287c;
        ppiStack_b8c = (int **)0x0;
        piVar4 = (int *)FUN_00c00d0b(piVar4);
        if (piVar4 == (int *)0x0) {
          FUN_00a530f0();
          pppiStack_b88 = (int ***)((uint)param_2 & 0xffff);
          ppiStack_b8c = (int **)&DAT_00e31158;
          (*(code *)PTR_FUN_00ff2ebc)();
          *unaff_FS_OFFSET = local_10;
          return;
        }
      }
      else {
        pppiStack_b88 = (int ***)&PTR_PTR_00f4287c;
        ppiStack_b8c = (int **)0x0;
        piVar4 = (int *)FUN_00c00d0b(piVar4);
        if (piVar4 == (int *)0x0) {
          FUN_00a530f0();
          pppiStack_b88 = (int ***)((uint)param_2 & 0xffff);
          ppiStack_b8c = (int **)&DAT_00e311a0;
          (*(code *)PTR_FUN_00ff2ebc)();
          *unaff_FS_OFFSET = local_10;
          return;
        }
      }
      (**(code **)(*piVar4 + 0x328))();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 7:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)((uint)param_1 & 0xffff);
      ppiStack_b8c = (int **)((uint)param_2 & 0xffff);
      pppiStack_b88 = (int ***)FUN_0050b820();
      ppiStack_b8c = (int **)0x8c2717;
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x5e0))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 8:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    piStack_1c = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
      ppiStack_b8c = (int **)0x0;
      uVar6 = FUN_0050b820((uint)param_2 & 0xffff,(uint)param_1 & 0xffff);
      piStack_24 = (int *)FUN_00c00d0b(uVar6);
      if (piStack_24 != (int *)0x0) {
        iVar3 = 0;
        if ((short)param_3 != -1) {
          pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
          ppiStack_b8c = (int **)0x0;
          uVar6 = FUN_0050b820((uint)param_3 & 0xffff,(uint)piStack_1c & 0xffff);
          iVar3 = FUN_00c00d0b(uVar6);
        }
        (**(code **)(*piStack_24 + 0x344))();
        if (iVar3 != 0) {
          pppiStack_b88 = (int ***)piStack_24;
          ppiStack_b8c = (int **)0x8c2ac3;
          FUN_00448df0();
          *unaff_FS_OFFSET = local_10;
          return;
        }
      }
    }
    break;
  case 9:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    piStack_1c = (int *)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    if (((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) &&
       (piStack_34 = (int *)FUN_0050b820(), piStack_34 != (int *)0x0)) {
      piStack_24 = (int *)(**(code **)(*piStack_34 + 0x48))();
      if (param_1._3_1_ != '\0') {
        piVar4 = (int *)piStack_24[0x1e];
        param_2 = (int **)piVar4;
        if (piVar4 == (int *)0x0) {
          param_2 = (int **)FUN_00403c50();
          uStack_8 = 4;
          if (param_2 == (int **)0x0) {
            piVar4 = (int *)0x0;
          }
          else {
            piVar4 = (int *)FUN_00495ac0();
          }
          uStack_8 = 0xffffffff;
          param_2 = (int **)piVar4;
          FUN_00511f10();
        }
        piStack_18 = (int *)*in_ECX;
        (**(code **)(*piVar4 + 0x10))();
        (*(code *)piStack_18[0x19])();
        ppuVar19 = (undefined **)0x0;
        do {
          (**(code **)((int)*param_2 + 0x10))();
          ppiStack_b8c = (int **)0x8c2bc5;
          pppiStack_b88 = (int ***)ppuVar19;
          FUN_00510f50();
          ppuVar19 = (undefined **)((int)ppuVar19 + 1);
        } while ((int)ppuVar19 < 3);
        iVar3 = *piStack_34;
        (**(code **)((int)*param_2 + 0x10))();
        pppiStack_b88 = (int ***)0x8c2bec;
        (**(code **)(iVar3 + 0xbc))();
        pppiStack_b88 = &ppiStack_20;
        ppiStack_20 = (int **)0x0;
        ppiStack_b8c = (int **)0x8c2bfa;
        (**(code **)(*in_ECX + 0x5c))();
        ppiStack_b8c = ppiStack_20;
        (**(code **)((int)*param_2 + 4))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
      FUN_00511f10();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 10:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_2 = (int **)((uint)param_2 & 0xffffff);
    piStack_1c = (int *)0x0;
    piStack_2c = (int *)0x0;
    uStack_30 = 0;
    FUN_004570b0();
    uStack_92 = 0;
    uStack_8e = 0;
    uStack_8a = 0;
    uStack_86 = 0;
    uStack_84 = 0;
    uStack_82 = 0;
    uStack_80 = 0;
    uStack_7e = 0;
    uStack_7c = 0;
    uStack_8 = 5;
    ppiStack_20 = (int **)0x0;
    piStack_38 = (int *)0x0;
    piStack_28 = (int *)0x0;
    uStack_94 = 0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x5c))();
    (**(code **)(*in_ECX + 0x5c))();
    pppiStack_b88 = (int ***)0x8c2cc9;
    (**(code **)(*in_ECX + 0x5c))();
    pppiStack_b88 = (int ***)&uStack_3c;
    ppiStack_b8c = (int **)0x8c2cd4;
    (**(code **)(*in_ECX + 0x5c))();
    ppiStack_b8c = &piStack_44;
    (**(code **)(*in_ECX + 0x5c))();
    (**(code **)(*in_ECX + 0x5c))(&piStack_38);
    (**(code **)(*in_ECX + 0x5c))(&piStack_28);
    if ((param_1._3_1_ == '\x13') && (uStack_30 != -1)) {
      (**(code **)(*in_ECX + 0x6c))(&uStack_94);
      (**(code **)(*in_ECX + 0x50))((int)&param_2 + 3);
      (**(code **)(*in_ECX + 0x5c))(&ppiStack_20);
    }
    FUN_00410210(piStack_18);
    param_3 = piStack_14;
    FUN_00404560(&param_3);
    param_3 = (int *)uStack_3c;
    FUN_00404560(&param_3);
    param_3 = piStack_44;
    FUN_00404560(&param_3);
    param_3 = piStack_38;
    FUN_00404560(&param_3);
    param_3 = piStack_28;
    FUN_00404560(&param_3);
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      uVar21 = 0;
      ppuVar20 = &PTR_PTR_00f5526c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)piStack_1c & 0xffff,(uint)piStack_2c & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
      piStack_24 = (int *)FUN_00c00d0b(piVar4,0,&PTR_PTR_00f5526c,&PTR_PTR_00f5528c,0);
      if (piVar4 != (int *)0x0) {
        if (uStack_30 == -1) {
          iVar3 = (**(code **)(*piVar4 + 0x428))(param_1._3_1_);
          if ((iVar3 != 0) &&
             (piVar8 = (int *)(**(code **)(*piVar4 + 0x420))((uint)param_1 >> 0x18),
             piVar8 != (int *)0x0)) {
            (**(code **)(*piVar8 + 8))(1);
          }
          cVar1 = (**(code **)(*piVar4 + 0x2c))(0x111);
          if (cVar1 != '\0') {
            (**(code **)(*piVar4 + 0x610))((uint)param_1 >> 0x18);
          }
        }
        else {
          if (param_1._3_1_ == '\x13') {
            param_3 = (int *)FUN_005706f0(uStack_30);
            cVar1 = (**(code **)(*piVar4 + 0x2c))(0x111);
            if ((cVar1 != '\0') &&
               (piVar8 = (int *)FUN_00c00d0b(piVar4,0,&PTR_PTR_00f5526c,&PTR_PTR_00f5528c,0),
               piVar8 != (int *)0x0)) {
              if (param_2._3_1_ == '\x02') {
                FUN_004e1410(param_3);
              }
              else {
                FUN_004cade0(param_3,&uStack_94,param_2._3_1_ == '\x01');
              }
              if ((ppiStack_20 != (int **)0x0) &&
                 (iVar3 = (**(code **)(*piVar8 + 0x63c))(), iVar3 != 0)) {
                ppiVar7 = ppiStack_20;
                (**(code **)(*piVar8 + 0x63c))(ppiStack_20);
                FUN_00523630(ppiVar7);
              }
            }
          }
          uVar2 = FUN_00402060();
          param_3 = (int *)(CONCAT13(uVar2,param_3._0_3_) & 0x1fffffff);
          cVar1 = FUN_00402060();
          bVar11 = param_3._3_1_ | cVar1 << 5;
          param_3 = (int *)CONCAT31(param_3._1_3_,bVar11);
          uVar6 = FUN_00402060();
          uVar18 = FUN_00402060(piStack_38,piStack_28,1,0,&PTR_PTR_00f40950,&PTR_PTR_00f40968,0);
          uVar6 = FUN_0057f420(uStack_30,uVar6,param_3,0,uVar18);
          piVar8 = (int *)FUN_00c00d0b(uVar6);
          if (piVar8 == (int *)0x0) {
            (*(code *)PTR_FUN_00ff2ebc)(&DAT_00e3107c,uStack_30);
          }
          else {
            piVar4 = (int *)(**(code **)(*piVar4 + 0x418))(piVar8,0xffffffff);
            if (piVar4 != (int *)0x0) {
              (**(code **)(*piVar4 + 8))(1);
            }
            if (piStack_24 == (int *)0x0) goto LAB_008c307f;
            if (DAT_0104f1d4 == piStack_24) {
              (**(code **)(*piVar8 + 0x68))();
            }
          }
        }
        if (((piStack_24 != (int *)0x0) && (iVar3 = FUN_00402060(), iVar3 != 1)) &&
           (cVar1 = FUN_0045a5c0((uint)param_1 >> 0x18), cVar1 != '\0')) {
          iVar3 = FUN_0055bcd0(piStack_2c);
          *(uint *)(iVar3 + 0x30 + ((uint)param_1 >> 0x18) * 8) = uStack_30;
          iVar9 = FUN_0055bcd0(piStack_2c);
          if (*(int **)(iVar9 + 0x200) != (int *)0x0) {
            (**(code **)(**(int **)(iVar9 + 0x200) + 0x198))(iVar3 + 0x10,0);
          }
          uVar18 = 0;
          uVar6 = FUN_0055bcd0(piStack_2c);
          iVar3 = FUN_0047d1d0(uVar6,uVar18);
          uVar18 = 1;
          uVar6 = FUN_0055bcd0(piStack_2c);
          param_3 = (int *)FUN_0047d1d0(uVar6,uVar18);
          if (iVar3 != 0) {
            FUN_00435f80(iVar3);
          }
          if (param_3 != (int *)0x0) {
            FUN_00435fb0(param_3);
          }
        }
      }
    }
LAB_008c307f:
    uStack_8 = 0xffffffff;
    FUN_004043a0();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0xb:
    if (DAT_0104f1d4 != (int *)0x0) {
      param_1 = (int ***)((uint)param_1 & 0xffffff);
      param_3 = (int *)0x0;
      (**(code **)(*in_ECX + 0x50))();
      param_2 = (int **)0x0;
      do {
        (**(code **)(*in_ECX + 0x5c))();
        if (((*(char *)(((uint)param_1 >> 0x18) + 0x10a5f8 + (int)in_ECX) != '\x01') ||
            (DAT_01002848 == 0)) ||
           ((iVar3 = FUN_00402060(), iVar3 != 9 &&
            ((iVar3 = FUN_00402060(), iVar3 != 4 ||
             (*(int *)(*(int *)(DAT_01002848 + 0x1058) + 0x28) == 0)))))) {
          piVar4 = (int *)(**(code **)(*DAT_0104f1d4 + 0x428))();
          if (piVar4 == (int *)0x0) {
            iVar3 = -1;
          }
          else {
            iVar3 = (**(code **)(*piVar4 + 0x14))();
            iVar3 = *(int *)(iVar3 + 8);
          }
          if (param_3 != (int *)iVar3) {
            if (piVar4 == (int *)0x0) {
              (**(code **)(*DAT_0104f1d4 + 0x440))();
            }
            else {
              (**(code **)(*DAT_0104f1d4 + 0x43c))();
            }
          }
        }
        param_2 = (int **)((int)param_2 + 1);
      } while ((int)param_2 < 0x17);
      *(undefined1 *)(((uint)param_1 >> 0x18) + 0x10a5f8 + (int)in_ECX) = 1;
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0xc:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    piStack_18 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x5c))();
    (**(code **)(*in_ECX + 0x5c))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
      ppiStack_b8c = (int **)0x0;
      uVar6 = FUN_0050b820((uint)param_2 & 0xffff,(uint)param_1 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6);
      if (piVar4 != (int *)0x0) {
        pppiStack_b88 = (int ***)param_3;
        ppiStack_b8c = (int **)0x8c3238;
        (**(code **)(*piVar4 + 0x3ec))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0xd:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x5c))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_1 & 0xffff);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_2 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x3f4))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0xe:
    param_2 = (int **)((uint)param_2 & 0xffffff);
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    piStack_24 = (int *)0x0;
    piStack_1c = (int *)0x0;
    uStack_30 = 0;
    piStack_34 = (int *)0x0;
    ppiStack_20 = (int **)0x0;
    piStack_2c = (int *)0x0;
    piStack_28 = (int *)0x0;
    piStack_38 = (int *)0x0;
    piStack_6c = (int *)0x0;
    piStack_68 = (int *)0x0;
    uStack_64 = 0;
    uStack_8 = 6;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)0x8c3354;
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)&piStack_28;
    ppiStack_b8c = (int **)0x8c335f;
    (**(code **)(*in_ECX + 0x54))();
    ppiStack_b8c = &piStack_38;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))(&piStack_2c);
    (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
    iVar3 = 0;
    param_3 = (int *)0x0;
    if (param_1._3_1_ != '\0') {
      do {
        (**(code **)(*in_ECX + 0x54))(&param_3);
        piStack_18 = (int *)(int)(short)param_3;
        FUN_00402150(&piStack_18);
        uStack_8._0_1_ = 7;
        FUN_0046d0b0(auStack_c4);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        FUN_00402010();
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)((uint)param_1 >> 0x18));
    }
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      uVar21 = 0;
      ppuVar20 = &PTR_PTR_00f5526c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)piStack_24 & 0xffff,(uint)piStack_1c & 0xffff);
      piStack_18 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
      if (piStack_18 != (int *)0x0) {
        uVar6 = 0;
        if ((short)piStack_34 != -1) {
          uVar21 = 0;
          ppuVar20 = &PTR_PTR_00f4287c;
          ppuVar19 = &PTR_PTR_00f40910;
          uVar18 = 0;
          uVar6 = FUN_0050b820((uint)piStack_34 & 0xffff,(uint)ppiStack_20 & 0xffff);
          uVar6 = FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
        }
        uVar18 = uVar6;
        if ((short)piStack_28 != -1) {
          uVar22 = 0;
          ppuVar20 = &PTR_PTR_00f4287c;
          ppuVar19 = &PTR_PTR_00f40910;
          uVar21 = 0;
          uVar18 = FUN_0050b820((uint)piStack_28 & 0xffff,(uint)piStack_38 & 0xffff);
          uVar18 = FUN_00c00d0b(uVar18,uVar21,ppuVar19,ppuVar20,uVar22);
        }
        (**(code **)(*piStack_18 + 0x408))
                  ((uint)param_2 >> 0x18,uStack_30 & 0xffff,uVar6,0,(uint)piStack_2c & 0xffff,
                   &piStack_70,uVar18);
      }
    }
    piVar8 = piStack_68;
    uStack_8 = 0xffffffff;
    piVar4 = piStack_6c;
    if (piStack_6c != (int *)0x0) {
      for (; piStack_18 = piVar4, piVar4 != piVar8; piVar4 = piVar4 + 2) {
        uStack_8 = 8;
        FUN_00b173a0(piVar4);
        uStack_8 = 0xffffffff;
        FUN_00b17a80();
      }
      _free(piStack_6c);
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0xf:
    param_2 = (int **)((uint)param_2 & 0xffffff);
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    piStack_1c = (int *)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
      ppiStack_b8c = (int **)0x0;
      uVar6 = FUN_0050b820((uint)piStack_1c & 0xffff,(uint)param_3 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6);
      if (piVar4 != (int *)0x0) {
        piStack_18 = (int *)((uint)param_1 >> 0x18);
        pppiStack_b88 = (int ***)0x8c35c0;
        (**(code **)(*piVar4 + 0x344))();
        pppiStack_b88 = (int ***)0x8c35c7;
        FUN_00404560();
        pppiStack_b88 = (int ***)0x8c35d2;
        (**(code **)(*piVar4 + 0x348))();
        pppiStack_b88 = (int ***)0x0;
        ppiStack_b8c = (int **)&PTR_PTR_00f5528c;
        piVar4 = (int *)FUN_00c00d0b(piVar4,0,&PTR_PTR_00f5526c);
        if (piVar4 != (int *)0x0) {
          pppiStack_b88 = (int ***)param_3;
          ppiStack_b8c = (int **)0x8c3600;
          iVar3 = FUN_0055bcd0();
          if (iVar3 != 0) {
            if (param_2._3_1_ < param_1._3_1_) {
              if (DAT_0104f1d4 == piVar4) {
                pppiStack_b88 = (int ***)0x8c362d;
                cVar1 = FUN_0043a620();
                if ((cVar1 == '\0') ||
                   (((param_1._3_1_ != '\n' && (param_1._3_1_ != '\x14')) &&
                    (param_1._3_1_ != '\x1e')))) {
                  pppiStack_b88 = (int ***)0x0;
                  ppiStack_b8c = (int **)0x0;
                  (**(code **)(*piVar4 + 0x2b8))(0xbb81,0,0,0,0,0,0,4,0,0,0);
                }
                else {
                  pppiStack_b88 = (int ***)0x0;
                  ppiStack_b8c = (int **)0x0;
                  (**(code **)(*piVar4 + 0x2b8))(0xbb81,4,0,0,0,0,0,4,0,0,0);
                  pppiStack_b88 = (int ***)((uint)param_1 >> 0x18);
                  ppiStack_b8c = (int **)0xa43b;
                  ppiStack_b8c = (int **)FUN_00a51240();
                  FUN_00401df0(auStack_b5c,0x800);
                  pppiStack_b88 = (int ***)0x0;
                  ppiStack_b8c = (int **)0x0;
                  FUN_009bc710(auStack_b5c,0xff9bc8e6,0x1f);
                  pppiStack_b88 = (int ***)0x0;
                  ppiStack_b8c = (int **)0x0;
                  FUN_008cf9b0(0x94);
                }
                pppiStack_b88 = (int ***)0x1;
                ppiStack_b8c = (int **)0x8c36e4;
                FUN_008c5fc0();
              }
              pppiStack_b88 = (int ***)0x8c36ec;
              ppiStack_b8c = (int **)FUN_00a530f0();
              pppiStack_b88 = (int ***)((uint)param_1 >> 0x18);
              uVar6 = FUN_00a51240(0x1f6);
              FUN_00401df0(auStack_35c,0x200,uVar6);
              pppiStack_b88 = (int ***)0x0;
              ppiStack_b8c = (int **)0x0;
              FUN_009bc710(auStack_35c,0xff9bc8e6,0x1f);
            }
            piStack_18 = (int *)((uint)param_1 >> 0x18);
            pppiStack_b88 = (int ***)&piStack_18;
            ppiStack_b8c = (int **)0x8c3745;
            FUN_00404560();
            *unaff_FS_OFFSET = local_10;
            return;
          }
        }
      }
    }
    break;
  case 0x10:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x5c))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_1 & 0xffff);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_2 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        piStack_18 = (int *)(float)(int)param_3;
        (**(code **)(*piVar4 + 0x19c))();
        FUN_00466910();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x11:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_1 & 0xffff);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_2 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        piStack_18 = (int *)(int)(short)param_3;
        (**(code **)(*piVar4 + 0x19c))();
        FUN_0040fc10();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x12:
    iVar3 = 0;
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_2 = (int **)((uint)param_2 & 0xffffff);
    piStack_1c = (int *)0x0;
    param_3 = (int *)0x0;
    piStack_24 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f4287c;
      ppiStack_b8c = (int **)&PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)piStack_1c & 0xffff,(uint)param_3 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6,uVar18);
      if (piVar4 != (int *)0x0) {
        iVar9 = (**(code **)(*piVar4 + 0x19c))();
        piVar4 = (int *)(iVar9 + 0x48);
        do {
          if (*piVar4 == 0x12) {
            *(uint *)(iVar9 + 0x48 + iVar3 * 4) = (uint)param_1 >> 0x18;
            piStack_18 = (int *)((float)((uint)piStack_24 & 0xffff) * _DAT_00cc10ac);
            pppiStack_b88 = (int ***)0x8c3989;
            FUN_00404560();
            piStack_18 = (int *)((uint)param_2 >> 0x18);
            pppiStack_b88 = (int ***)0x8c399d;
            FUN_00404560();
            *unaff_FS_OFFSET = local_10;
            return;
          }
          iVar3 = iVar3 + 1;
          piVar4 = piVar4 + 1;
        } while (iVar3 < 3);
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x13:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    piStack_1c = (int *)0x0;
    piStack_34 = (int *)0x0;
    ppiStack_20 = (int **)0x0;
    param_3 = (int *)0x0;
    piStack_24 = (int *)0x0;
    FUN_004672b0();
    uStack_8 = 9;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)0x8c3a0f;
    (**(code **)(*in_ECX + 100))();
    pppiStack_b88 = (int ***)&piStack_18;
    ppiStack_b8c = (int **)0x8c3a1e;
    pppiStack_b88 = (int ***)FUN_0044d010();
    ppiStack_b8c = (int **)0x8c3a2a;
    FUN_004045b0();
    pppiStack_b88 = (int ***)0x8c3a35;
    FUN_00402010();
    pppiStack_b88 = (int ***)0x2;
    ppiStack_b8c = (int **)((int)&param_2 + 2);
    (**(code **)(*in_ECX + 100))();
    piStack_14 = (int *)(float)(int)param_2._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_2 + 2,2);
    piStack_14 = (int *)(float)(int)param_2._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_2 + 2,2);
    piStack_14 = (int *)(float)(int)param_2._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_2 + 2,2);
    piStack_14 = (int *)(float)(int)param_2._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_2 + 2,2);
    piStack_14 = (int *)(float)(int)param_2._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
    (**(code **)(*in_ECX + 0x54))(&piStack_24);
    uVar12 = (uint)piStack_1c & 0xffff;
    fVar14 = (float10)FUN_004333b0();
    piStack_14 = (int *)(float)fVar14;
    FUN_004333b0();
    piStack_14 = (int *)((uint)param_3 & 0xffff);
    iVar3 = FUN_00c01544();
    in_ECX[0x42972] = iVar3;
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      uVar21 = 0;
      ppuVar20 = &PTR_PTR_00f4287c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820(uVar12,(uint)piStack_34 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
      uVar21 = 0;
      ppuVar20 = &PTR_PTR_00f4287c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)ppiStack_20 & 0xffff,(uint)param_3 & 0xffff);
      piVar8 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
      if ((piVar4 != (int *)0x0) && (piVar8 != (int *)0x0)) {
        piVar4 = (int *)(**(code **)(*piVar4 + 0x1c8))();
        piVar8 = (int *)(**(code **)(*piVar8 + 0x1c8))();
        (**(code **)(*piVar4 + 0x250))(piVar8,auStack_a8,param_1._3_1_ != '\0');
        (**(code **)(*piVar8 + 0x25c))(piVar4,auStack_a8,param_1._3_1_ != '\0');
        (**(code **)(*piVar4 + 0x254))(piVar8,auStack_a8,param_1._3_1_ != '\0');
        (**(code **)(*piVar8 + 0x260))(piVar4,auStack_a8,param_1._3_1_ != '\0');
        (**(code **)(*piVar4 + 600))(piVar8,auStack_a8,param_1._3_1_ != '\0');
        (**(code **)(*piVar8 + 0x264))(piVar4,auStack_a8,param_1._3_1_ != '\0');
        cVar1 = (**(code **)(*piVar8 + 0x2c))(0x11);
        if (cVar1 != '\0') {
          uVar12 = (uint)(param_1._3_1_ != '\0');
          puVar16 = auStack_a8;
          piVar15 = piVar4;
          (**(code **)(*piVar8 + 0x3c4))(piVar4,puVar16,uVar12);
          FUN_008c60b0(piVar15,puVar16,uVar12);
        }
        iVar3 = (**(code **)(*piVar4 + 0x2a4))();
        if (iVar3 != 0) {
          piStack_14 = (int *)(**(code **)(*piVar4 + 0x2a4))();
          uVar12 = (uint)(param_1._3_1_ != '\0');
          puVar16 = auStack_a8;
          piVar15 = piVar4;
          piVar17 = piVar8;
          (**(code **)(*piStack_14 + 0x3c4))(piVar4,piVar8,puVar16,uVar12);
          FUN_008c6030(piVar15,piVar17,puVar16,uVar12);
          (**(code **)(*piStack_14 + 0x4a8))(piVar4,piVar8,auStack_a8,param_1._3_1_ != '\0');
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00404300();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x14:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_2 = (int **)((uint)param_2 & 0xffffff);
    piStack_24 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piStack_38 = (int *)0x0;
    piStack_34 = (int *)0x0;
    uStack_5c = 0;
    uStack_30 = 0;
    uStack_58 = 0;
    ppiStack_20 = (int **)0x0;
    FUN_004672b0();
    uStack_8 = 10;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)0x8c3e23;
    (**(code **)(*in_ECX + 100))();
    pppiStack_b88 = (int ***)&piStack_18;
    ppiStack_b8c = (int **)0x8c3e32;
    pppiStack_b88 = (int ***)FUN_0044d010();
    ppiStack_b8c = (int **)0x8c3e3e;
    FUN_004045b0();
    pppiStack_b88 = (int ***)0x8c3e49;
    FUN_00402010();
    pppiStack_b88 = (int ***)0x2;
    ppiStack_b8c = (int **)((int)&param_3 + 2);
    (**(code **)(*in_ECX + 100))();
    piStack_14 = (int *)(float)(int)param_3._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_3 + 2,2);
    piStack_14 = (int *)(float)(int)param_3._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_3 + 2,2);
    piStack_14 = (int *)(float)(int)param_3._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_3 + 2,2);
    piStack_14 = (int *)(float)(int)param_3._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 100))((int)&param_3 + 2,2);
    piStack_14 = (int *)(float)(int)param_3._2_2_;
    uVar6 = FUN_0044d010(&piStack_14);
    FUN_004045b0(uVar6);
    FUN_00402010();
    (**(code **)(*in_ECX + 0x5c))(&uStack_5c);
    (**(code **)(*in_ECX + 0x5c))(&uStack_30);
    (**(code **)(*in_ECX + 0x5c))(&uStack_58);
    (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
    (**(code **)(*in_ECX + 0x5c))(&ppiStack_20);
    (**(code **)(*in_ECX + 0x50))((int)&param_2 + 3);
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      uVar21 = 0;
      ppuVar20 = &PTR_PTR_00f4287c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)piStack_24 & 0xffff,(uint)piStack_1c & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
      piStack_28 = piVar4;
      piStack_14 = piVar4;
      if ((piVar4 != (int *)0x0) && (iVar3 = (**(code **)(*piVar4 + 0x2a4))(), iVar3 != 0)) {
        piVar8 = (int *)(**(code **)(*piVar4 + 0x2a4))();
        cVar1 = (**(code **)(*piVar8 + 0x2c))(0x111);
        if (cVar1 == '\x01') {
          piVar4 = (int *)(**(code **)(*piVar4 + 0x2a4))();
          piStack_28 = piVar4;
        }
      }
      uVar21 = 0;
      ppuVar20 = &PTR_PTR_00f5526c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)piStack_38 & 0xffff,(uint)piStack_34 & 0xffff);
      piStack_2c = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
      if (piStack_2c != (int *)0x0) {
        cVar1 = FUN_0049c090();
        if (cVar1 == '\0') {
          (**(code **)(*piStack_2c + 0x3ec))(uStack_58,piVar4,1);
        }
        iVar3 = FUN_008ae0f0(0,uStack_5c,
                             (DAT_0104f1d4 != piStack_2c) - 1U & 2 | DAT_0104f1d4 == piVar4 |
                             -(param_1._3_1_ != '\0') & 0x10U);
        iVar9 = FUN_004ee520();
        uVar6 = (**(code **)(*piStack_2c + 0x98))(iVar3 % 0x14 + 0x28 + iVar9);
        iVar3 = FUN_008ae0f0(0,uVar6);
        iVar9 = FUN_004ee4c0();
        piVar4 = piStack_2c;
        FUN_00498980(piStack_2c,iVar3 % 0x14 + -10 + iVar9);
        if (param_2._3_1_ != '\0') {
          (**(code **)(*piVar4 + 0x270))(piVar4,auStack_a8);
        }
        cVar1 = FUN_004ba310();
        iVar3 = uStack_30;
        if (cVar1 != '\0') {
          iVar3 = piVar4[0x597] + uStack_30;
        }
        FUN_004b9930(iVar3);
        FUN_004b9950(piVar4[0x59a] + uStack_30);
        if (piStack_28 != (int *)0x0) {
          if (param_1._3_1_ == '\x01') {
            (**(code **)(*piStack_28 + 0x268))(piStack_14,piVar4,auStack_a8);
          }
          if (ppiStack_20 != (int **)0x0) {
            puVar16 = auStack_a8;
            piVar8 = piVar4;
            (**(code **)(*piStack_28 + 0x26c))(piVar4,puVar16);
            (**(code **)(*in_ECX + 0x88))(piVar4,ppiStack_20);
            FUN_00538d60(piVar8,puVar16);
          }
          cVar1 = FUN_0043abf0(0xffffffff);
          if (((cVar1 != '\0') &&
              (piVar8 = (int *)(**(code **)(*piStack_28 + 0x2a8))(), piVar8 == DAT_0104f1d4)) &&
             (cVar1 = (**(code **)(*piVar4 + 0x2c))(0x111), cVar1 != '\0')) {
            uVar18 = 9;
            iVar3 = uStack_30;
            uVar6 = (**(code **)(*DAT_0104f1d4 + 0x40))(9,uStack_30);
            FUN_0051c2d0(uVar6,uVar18,iVar3);
          }
        }
      }
    }
    uStack_8 = 0xffffffff;
    FUN_00404300();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x15:
    ppiStack_20 = (int **)0x0;
    piStack_38 = (int *)0x0;
    uStack_5c = 0;
    uStack_58 = 0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    piStack_28 = (int *)0x0;
    pppiStack_b88 = (int ***)0x8c4293;
    piStack_18 = (int *)FUN_0043ac70();
    if (piStack_18 != (int *)0x0) {
      if ((short)ppiStack_20 != -1) {
        pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
        ppiStack_b8c = (int **)0x0;
        uVar6 = FUN_0050b820((uint)ppiStack_20 & 0xffff,(uint)piStack_38 & 0xffff);
        piStack_28 = (int *)FUN_00c00d0b(uVar6);
        if (((piStack_28 == (int *)0x0) && ((short)ppiStack_20 == 0x111)) &&
           (iVar3 = FUN_0055bcd0(), iVar3 != 0)) {
          piStack_28 = *(int **)(iVar3 + 0x204);
        }
      }
      piStack_44 = (int *)0x0;
      if ((short)uStack_5c != -1) {
        pppiStack_b88 = (int ***)0x8c4315;
        piStack_44 = (int *)FUN_0050b820();
      }
      uStack_30 = 0;
      (**(code **)(*in_ECX + 0x54))();
      piStack_14 = (int *)0x0;
      if ((short)uStack_30 != 0) {
        do {
          piStack_34 = (int *)0xffff;
          piStack_24 = (int *)0x0;
          piStack_2c = (int *)0x0;
          piStack_1c = (int *)0x0;
          pppiStack_b88 = (int ***)0x8c434f;
          (**(code **)(*in_ECX + 0x54))();
          pppiStack_b88 = (int ***)&piStack_1c;
          ppiStack_b8c = (int **)0x8c435a;
          (**(code **)(*in_ECX + 0x5c))();
          ppiStack_b8c = &piStack_24;
          (**(code **)(*in_ECX + 0x54))();
          (**(code **)(*in_ECX + 0x54))(&piStack_2c);
          if ((short)piStack_2c == -1) {
            uVar6 = FUN_00a51240(0x1f7);
            (*(code *)PTR_FUN_00ff2eb8)(uVar6);
          }
          else {
            puVar5 = (uint *)FUN_005e8500((uint)piStack_34 & 0xffff,piStack_1c);
            puStack_48 = puVar5;
            if (puVar5 == (uint *)0x0) {
              (*(code *)PTR_FUN_00ff2ebc)(&DAT_00e31020,(uint)piStack_34 & 0xffff);
              break;
            }
            (**(code **)(*puVar5 + 0x344))(piStack_28);
            FUN_0050dd70(0,(uint)piStack_24 & 0xffff,(uint)piStack_2c & 0xffff,puVar5,0,0,0);
            iVar3 = (**(code **)(*puVar5 + 0x104))();
            if (iVar3 != 0) {
              piVar4 = (int *)(**(code **)(*puVar5 + 0x104))();
              (**(code **)(*piVar4 + 0x10))(puVar5);
            }
            param_1 = (int ***)((uint)param_1 & 0xffffff);
            (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
            if (param_1._3_1_ == '\x01') {
              param_2 = (int **)FUN_00403c50(0xc4);
              uStack_8 = 0xb;
              if (param_2 == (int **)0x0) {
                param_2 = (int **)0x0;
              }
              else {
                param_2 = (int **)FUN_00495ac0();
              }
              uStack_8 = 0xffffffff;
              (**(code **)(*in_ECX + 0x5c))(&iStack_74);
              FUN_008bbf70(iStack_74);
              ppiVar7 = param_2;
              (**(code **)(*puVar5 + 0x48))(param_2);
              FUN_00511f10(ppiVar7);
              uStack_4c = *puVar5;
              iVar3 = (*(code *)(*param_2)[4])();
              puVar5 = puStack_48;
              (**(code **)(uStack_4c + 0xbc))(*(char *)(iVar3 + 0x58) == '\0');
              piStack_78 = (int *)0x0;
              (**(code **)(*in_ECX + 0x5c))(&piStack_78);
              (*(code *)(*param_2)[1])(piStack_78);
            }
            else {
              param_2 = (int **)((uint)param_2 & 0xffffff);
              puStack_48 = (uint *)0x0;
              uStack_4c = 0;
              uStack_60 = 0;
              (**(code **)(*in_ECX + 0x50))((int)&param_2 + 3);
              (**(code **)(*in_ECX + 0x54))(&puStack_48);
              (**(code **)(*in_ECX + 0x54))(&uStack_4c);
              (**(code **)(*in_ECX + 0x54))(&uStack_60);
              (**(code **)(*puVar5 + 0xbc))((uint)param_2 >> 0x18);
              (**(code **)(*puVar5 + 0x88))
                        ((int)(short)puStack_48,(int)(short)uStack_4c,(int)(short)uStack_60);
            }
            uVar6 = (**(code **)(*puVar5 + 0xc0))();
            (**(code **)(*puVar5 + 0x48))(uVar6);
            FUN_00511e30(uVar6);
            piVar4 = piStack_44;
            (**(code **)(*puVar5 + 0x48))(piStack_44);
            FUN_00510e80(piVar4);
            iVar3 = (**(code **)(*in_ECX + 0x68))(&DAT_010c0ba0);
            if (0 < iVar3) {
              (**(code **)(*puVar5 + 0x354))(&DAT_010c0ba0,iVar3);
            }
            uStack_3c = 0;
            (**(code **)(*in_ECX + 0x54))(&uStack_3c);
            if ((short)uStack_3c != 0) {
              puVar5[0x21b] = uStack_3c & 0xffff;
            }
            param_3 = (int *)((uint)param_3 & 0xffffff);
            (**(code **)(*in_ECX + 0x50))((int)&param_3 + 3);
            if (param_3._3_1_ != '\0') {
              pppiStack_b88 = &param_2;
              param_2 = (int **)0x3f800000;
              ppiStack_b8c = (int **)0x8c4594;
              (**(code **)(*in_ECX + 100))();
              pppiStack_b88 = (int ***)&LAB_008c459f;
              FUN_0049d450();
            }
            ppiStack_b8c = (int **)&LAB_008c45a9;
            pppiStack_b88 = (int ***)puVar5;
            FUN_00448df0();
          }
          piStack_14 = (int *)((int)piStack_14 + 1);
          if ((int)(uStack_30 & 0xffff) <= (int)piStack_14) {
            *(undefined1 *)(DAT_010030e4 + 0x21c) = 0;
            *unaff_FS_OFFSET = local_10;
            return;
          }
        } while( true );
      }
      *(undefined1 *)(DAT_010030e4 + 0x21c) = 0;
      *unaff_FS_OFFSET = local_10;
      return;
    }
    goto LAB_008c49f6;
  case 0x16:
    puStack_48 = (uint *)0xffff;
    piStack_44 = (int *)0xffff;
    param_2 = (int **)((uint)param_2 & 0xffffff);
    cStack_3e = '\0';
    uStack_4c = 0;
    uStack_60 = 0;
    piStack_14 = (int *)0x0;
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)0x8c49cf;
    (**(code **)(*in_ECX + 0x50))();
    if ((in_ECX[0x42818] == 0) || (*(int *)(in_ECX[0x42818] + 0xb0) == 0)) {
      param_2 = (int **)((uint)param_2 & 0xffffff);
    }
    pppiStack_b88 = (int ***)0x8c49f2;
    iVar3 = FUN_0043ac70();
    if (iVar3 != 0) {
      piStack_18 = (int *)0x0;
      if (param_2._3_1_ != '\0') {
        do {
          uStack_30 = uStack_30 & 0xffffff;
          bStack_3f = 0;
          param_1 = (int ***)((uint)param_1 & 0xffffff);
          param_3 = (int *)((uint)param_3 & 0xffffff);
          uStack_3c = 0;
          uStack_5c = 0;
          piStack_78 = (int *)0x0;
          ppiStack_20 = (int **)0x0;
          piStack_2c = (int *)0x0;
          piStack_28 = (int *)0x0;
          piStack_38 = (int *)0x0;
          piStack_24 = (int *)0x0;
          piStack_34 = (int *)0x0;
          (**(code **)(*in_ECX + 0x54))();
          pppiStack_b88 = (int ***)0x8c4a72;
          (**(code **)(*in_ECX + 0x50))();
          pppiStack_b88 = (int ***)&uStack_5c;
          ppiStack_b8c = (int **)0x8c4a7d;
          (**(code **)(*in_ECX + 0x54))();
          ppiStack_b8c = &piStack_78;
          (**(code **)(*in_ECX + 0x54))();
          (**(code **)(*in_ECX + 0x50))(&bStack_3f);
          (**(code **)(*in_ECX + 0x54))(&piStack_2c);
          piStack_28 = (int *)(int)(short)piStack_2c;
          (**(code **)(*in_ECX + 0x54))(&piStack_2c);
          piStack_38 = (int *)(int)(short)piStack_2c;
          (**(code **)(*in_ECX + 0x54))(&piStack_2c);
          piStack_54 = (int *)(int)(short)piStack_2c;
          (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
          (**(code **)(*in_ECX + 0x54))(&ppiStack_20);
          if ((short)ppiStack_20 != 0) {
            piStack_24 = operator_new((uint)ppiStack_20 & 0xffff);
            (**(code **)(*in_ECX + 100))(piStack_24,(uint)ppiStack_20 & 0xffff);
          }
          (**(code **)(*in_ECX + 0x50))((int)&param_3 + 3);
          if (param_3._3_1_ != '\0') {
            piStack_34 = operator_new(7);
            if (piStack_34 == (int *)0x0) {
              piStack_34 = (int *)0x0;
            }
            else {
              *(undefined1 *)piStack_34 = 0;
              *(undefined1 *)((int)piStack_34 + 1) = 0;
              *(undefined1 *)((int)piStack_34 + 2) = 0;
              *(undefined4 *)((int)piStack_34 + 3) = 0;
            }
            (**(code **)(*in_ECX + 100))(piStack_34,7);
          }
          (**(code **)(*in_ECX + 0x5c))(&piStack_14);
          uStack_58 = 0;
          (**(code **)(*in_ECX + 0x54))(&uStack_58);
          if (uStack_30._3_1_ == 0) {
            pppiStack_b88 = (int ***)0x1;
          }
          else {
            pppiStack_b88 = (int ***)(uint)uStack_30._3_1_;
          }
          ppiStack_b8c = (int **)(uStack_3c & 0xffff);
          piVar4 = (int *)FUN_0075fb70();
          if (piVar4 != (int *)0x0) {
            if (cStack_3e != '\0') {
              *(undefined1 *)(piVar4 + 0x92a) = 1;
            }
            pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
            ppiStack_b8c = (int **)0x0;
            uVar6 = FUN_0050b820((uint)puStack_48 & 0xffff,(uint)piStack_44 & 0xffff);
            piStack_1c = (int *)FUN_00c00d0b(uVar6);
            if ((piStack_1c != (int *)0x0) &&
               (cVar1 = (**(code **)(*piStack_1c + 0x2c))(), cVar1 != '\0')) {
              (**(code **)(*piVar4 + 0x354))();
            }
            pppiStack_b88 = (int ***)0x8c4bf6;
            (**(code **)(*piVar4 + 0x638))();
            pppiStack_b88 = (int ***)(uStack_60 & 0xffff);
            ppiStack_b8c = (int **)0x8c4c05;
            (**(code **)(*piVar4 + 0x1c0))();
            ppiStack_b8c = (int **)(uint)bStack_3f;
            (**(code **)(*piVar4 + 0xbc))();
            FUN_0050dd70(0,uStack_5c & 0xffff,(uint)piStack_78 & 0xffff,piVar4,0,0,0);
            iStack_74 = FUN_00a530f0();
            uVar6 = (**(code **)(*piVar4 + 0x40))();
            (*(code *)PTR_FUN_00ff2ebc)
                      (u__s____s__d__is_added_to_the_mana_00e30ed8,
                       u_CNRDUdpModule__HandlePacket_00e30f24,iStack_74,uVar6);
            cVar1 = (**(code **)(*piVar4 + 0xac))(piStack_28,piStack_38,0);
            if ((cVar1 == '\0') &&
               (cVar1 = (**(code **)(*piVar4 + 0xb0))
                                  (&piStack_28,&piStack_38,piStack_28,piStack_38,200,0xffffffff,3),
               cVar1 == '\0')) {
              (*(code *)PTR_FUN_00ff2ebc)(&DAT_00e30e90);
            }
            (**(code **)(*piVar4 + 0x88))(piStack_28,piStack_38,piStack_54);
            iVar3 = (**(code **)(*piVar4 + 0x204))();
            if ((0 < iVar3) && (param_1._3_1_ == '\x01')) {
              param_1 = (int ***)((uint)param_1 & 0xffffff);
            }
            (**(code **)(*piVar4 + 0x5f8))
                      ((uint)param_1 >> 0x18,piStack_24,(uint)ppiStack_20 & 0xffff);
            pppiStack_b88 = (int ***)0x8c4cfc;
            FUN_00448df0();
            piVar4[0x944] = uStack_58 & 0xffff;
          }
          _free(piStack_24);
          pppiStack_b88 = (int ***)0x8c4d1b;
          _free(piStack_34);
          piStack_18 = (int *)((int)piStack_18 + 1);
        } while ((int)piStack_18 < (int)((uint)param_2 >> 0x18));
      }
      *(undefined1 *)(DAT_010030e0 + 0x21c) = 0;
      *(undefined1 *)(DAT_010030f8 + 0x21c) = 0;
      *(undefined1 *)(DAT_010030fc + 0x21c) = 0;
      *(undefined1 *)(DAT_010030e4 + 0x21c) = 0;
      *unaff_FS_OFFSET = local_10;
      return;
    }
LAB_008c49f6:
    FUN_00402060();
    pppiStack_b88 = (int ***)0x8c4a13;
    (*(code *)PTR_FUN_00ff2ebc)();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x17:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if (((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) &&
       (piVar4 = (int *)FUN_0050b820(), piVar4 != (int *)0x0)) {
      (**(code **)(*piVar4 + 0x60))();
      cVar1 = (**(code **)(*piVar4 + 0x2c))();
      if (cVar1 == '\x01') {
        FUN_00a530f0();
        pppiStack_b88 = (int ***)u_CNRDUdpModule__HandlePacket_00e30f24;
        ppiStack_b8c = (int **)u__s___recv_UDP_destroy__s__d__00e30e50;
        (*(code *)PTR_FUN_00ff2ebc)();
        *unaff_FS_OFFSET = local_10;
        return;
      }
      cVar1 = (**(code **)(*piVar4 + 0x2c))();
      if (cVar1 != '\0') {
        iVar3 = (**(code **)(*DAT_01003164 + 0x88))();
        iVar3 = *(int *)(iVar3 + 0xb4);
        pppiStack_b88 = (int ***)0x8c4e46;
        pppiStack_b88 = (int ***)FUN_00488820();
        ppiStack_b8c = *(int ***)(iVar3 + 0x34);
        FUN_00542790();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x18:
    param_3 = (int *)0x0;
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    piStack_18 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x5c))();
    (**(code **)(*in_ECX + 0x5c))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
      ppiStack_b8c = (int **)0x0;
      uVar6 = FUN_0050b820((uint)param_3 & 0xffff,(uint)param_2 & 0xffff);
      ppiVar7 = (int **)FUN_00c00d0b(uVar6);
      if (ppiVar7 != (int **)0x0) {
        pppiStack_b88 = (int ***)0x0;
        ppiStack_b8c = (int **)0xffffffff;
        piVar4 = (int *)FUN_0057f420(param_1,1,0,0);
        if (piVar4 != (int *)0x0) {
          cVar1 = (**(code **)(*piVar4 + 0x18))();
          if (cVar1 != '\0') {
            pppiStack_b88 = (int ***)0x1;
            ppiStack_b8c = ppiVar7;
            (**(code **)(*piVar4 + 0xb4))();
          }
          pppiStack_b88 = (int ***)&LAB_008c4f30;
          (**(code **)(*piVar4 + 8))();
        }
        (*(code *)(*ppiVar7)[0x120])();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x19:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_2 = (int **)((uint)param_2 & 0xffffff);
    piStack_14 = (int *)0x0;
    piStack_18 = (int *)0x0;
    uStack_3c = 0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x5c))();
    param_3 = (int *)((uint)param_3 & 0xffffff);
    pppiStack_b88 = (int ***)0x8c4fa7;
    (**(code **)(*in_ECX + 0x50))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)&PTR_PTR_00f5526c;
      ppuVar19 = &PTR_PTR_00f40910;
      uVar18 = 0;
      uVar6 = FUN_0050b820((uint)piStack_14 & 0xffff,(uint)piStack_18 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19);
      if (piVar4 != (int *)0x0) {
        pppiStack_b88 = (int ***)((uint)param_2 >> 0x18);
        ppiStack_b8c = (int **)((uint)param_1 >> 0x18);
        (**(code **)(*piVar4 + 0x4ac))();
        cVar1 = FUN_0049c090();
        if (cVar1 == '\0') {
          (**(code **)(*piVar4 + 0x3f4))(uStack_3c,1);
        }
        if (((param_3._3_1_ != '\0') &&
            (piVar4 = (int *)FUN_00c00d0b(piVar4,0,&PTR_PTR_00f5526c,&PTR_PTR_00f5528c,0),
            piVar4 != (int *)0x0)) &&
           (iVar3 = (**(code **)(*piVar4 + 0x67c))((uint)param_1 >> 0x18), iVar3 != 0)) {
          iVar3 = (**(code **)(*piVar4 + 0x67c))((uint)param_1 >> 0x18);
          piVar4[0x9ed] = iVar3;
          uVar12 = (uint)param_1 >> 0x18;
          (**(code **)(*piVar4 + 0x67c))(uVar12,0);
          FUN_00559630(uVar12);
          FUN_004e1820();
          *unaff_FS_OFFSET = local_10;
          return;
        }
      }
    }
    break;
  case 0x1a:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_3 = (int *)0x0;
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x68))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
      ppiStack_b8c = (int **)0x0;
      uVar6 = FUN_0050b820((uint)param_3 & 0xffff,(uint)param_2 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6);
      if (piVar4 != (int *)0x0) {
        pppiStack_b88 = (int ***)((uint)param_1 >> 0x18);
        ppiStack_b8c = (int **)0x8c513c;
        (**(code **)(*piVar4 + 0x29c))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x1b:
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] == 0) || (*(int *)(in_ECX[0x42818] + 0xb0) == 0)) {
      param_2 = (int **)0x0;
    }
    uStack_3c = 0;
    if ((short)param_2 != 0) {
      do {
        param_1 = (int ***)((uint)param_1 & 0xffffff);
        piStack_14 = (int *)0x0;
        piStack_18 = (int *)0x0;
        param_3 = (int *)0x0;
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x50))();
        (**(code **)(*in_ECX + 0x5c))();
        piVar4 = (int *)FUN_0050b820();
        if ((piVar4 != (int *)0x0) &&
           ((iVar3 = (**(code **)(*piVar4 + 0x124))(), iVar3 == 0 ||
            ((uVar12 = (**(code **)(*piVar4 + 0x124))(), uVar12 == (uint)param_1 >> 0x18 &&
             (uVar12 = (**(code **)(*piVar4 + 0x130))(), uVar12 < param_3)))))) {
          (**(code **)(*piVar4 + 0x11c))();
        }
        uStack_3c = uStack_3c + 1;
      } while ((int)uStack_3c < (int)((uint)param_2 & 0xffff));
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x1c:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    param_3 = (int *)0x0;
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_2 & 0xffff);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_3 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b();
      if ((piVar4 != (int *)0x0) &&
         (((piVar8 = (int *)(**(code **)(*piVar4 + 0x428))(), piVar8 != (int *)0x0 &&
           (cVar1 = (**(code **)(*piVar8 + 0xfc))(), cVar1 != '\0')) && (DAT_0104f1d4 == piVar4))))
      {
        pppiStack_b88 = (int ***)0xffffffff;
        ppiStack_b8c = (int **)u_ITEM_BREAK_00e30e38;
        FUN_004479b0();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x1d:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)((uint)param_1 & 0xffff);
      ppiStack_b8c = (int **)((uint)param_2 & 0xffff);
      pppiStack_b88 = (int ***)FUN_0050b820();
      ppiStack_b8c = (int **)0x8c2838;
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x5c4))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x1e:
    param_1 = (int ***)0x0;
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    iVar3 = FUN_0055bcd0();
    iVar9 = FUN_0055bcd0();
    if ((iVar3 != 0) && (iVar9 != 0)) {
      if (*(int **)(iVar3 + 0x204) != (int *)0x0) {
        (**(code **)(**(int **)(iVar3 + 0x204) + 0x6fc))();
      }
      FUN_00a530f0();
      if (iVar3 == iVar9) {
        FUN_00a51240();
        pppiStack_b88 = (int ***)0x8c53a2;
        FUN_00401df0();
      }
      else {
        FUN_00a530f0();
        FUN_00a51240();
        pppiStack_b88 = (int ***)auStack_25c;
        ppiStack_b8c = (int **)0x8c53d2;
        FUN_00401df0();
      }
      pppiStack_b88 = (int ***)auStack_25c;
      ppiStack_b8c = (int **)0x8c53f3;
      FUN_009bc710();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x1f:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_2 >> 0x10);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_3 >> 0x10);
      piVar4 = (int *)FUN_00c00d0b();
      if ((piVar4 != (int *)0x0) &&
         (piVar4 = (int *)(**(code **)(*piVar4 + 0x428))(), piVar4 != (int *)0x0)) {
        (**(code **)(*piVar4 + 0x15c))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x20:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    piStack_1c = (int *)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)&PTR_PTR_00f40910;
      ppiStack_b8c = (int **)0x0;
      uVar6 = FUN_0050b820((uint)param_2 & 0xffff,(uint)param_1 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b(uVar6);
      if (piVar4 != (int *)0x0) {
        iVar3 = *piVar4;
        pppiStack_b88 = (int ***)0x8c26a0;
        FUN_0050b820();
        (**(code **)(iVar3 + 0x62c))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x21:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)((uint)param_1 & 0xffff);
      ppiStack_b8c = (int **)((uint)param_2 & 0xffff);
      pppiStack_b88 = (int ***)FUN_0050b820();
      ppiStack_b8c = (int **)0x8c5503;
      iVar3 = FUN_00c00d0b();
      if (iVar3 != 0) {
        FUN_0050bb20();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x22:
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      FUN_0050bce0();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x23:
    FUN_0051c820();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x24:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    FUN_00aafe40();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x25:
    param_2 = (int **)0xffff;
    param_3 = (int *)0xffff;
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    iVar3 = FUN_00402060();
    if (iVar3 != 6) {
      pppiStack_b88 = (int ***)&DAT_00e30de8;
      ppiStack_b8c = (int **)0x8c5620;
      (*(code *)PTR_FUN_00ff2ebc)();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_3 & 0xffff);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_2 & 0xffff);
      iVar3 = FUN_00c00d0b();
      if (iVar3 != 0) {
        FUN_004cbf20();
        *unaff_FS_OFFSET = local_10;
        return;
      }
      pppiStack_b88 = (int ***)&DAT_00e30d98;
      ppiStack_b8c = (int **)0x8c56b3;
      (*(code *)PTR_FUN_00ff2ebc)();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x26:
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    iVar3 = FUN_0055bcd0();
    if ((((iVar3 != 0) && (piVar4 = *(int **)(iVar3 + 0x204), piVar4 != (int *)0x0)) &&
        (iVar3 = (**(code **)(*piVar4 + 0x63c))(), iVar3 != 0)) && (param_1._3_1_ == '\x03')) {
      iVar3 = (**(code **)(*piVar4 + 0x63c))();
      (**(code **)(*(int *)(iVar3 + 0x520) + 0xc))();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x27:
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x5c))();
    (*(code *)**(undefined4 **)in_ECX[0x15])();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x28:
    (**(code **)(*(int *)in_ECX[0x15] + 4))();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x29:
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x5c))();
    (**(code **)(*(int *)in_ECX[0x15] + 8))();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x2a:
    FUN_00b885d0();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x2b:
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x68))();
    (**(code **)(*(int *)in_ECX[0x15] + 0xc))();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x2c:
    param_2 = (int **)0x0;
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    (**(code **)(*in_ECX + 0x5c))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*(int *)in_ECX[0x15] + 0x10))();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x2d:
    piStack_28 = (int *)0xffff;
    ppiStack_20 = (int **)0xffff;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if (*(int *)(in_ECX[0x42818] + 0xb0) != 0) {
      pppiStack_b88 = (int ***)((uint)ppiStack_20 & 0xffff);
      ppiStack_b8c = (int **)((uint)piStack_28 & 0xffff);
      pppiStack_b88 = (int ***)FUN_0050b820();
      ppiStack_b8c = (int **)0x8c5721;
      piStack_54 = (int *)FUN_00c00d0b();
      if (piStack_54 != (int *)0x0) {
        piStack_6c = (int *)0x0;
        piStack_68 = (int *)0x0;
        uStack_64 = 0;
        uStack_8 = 0xc;
        (**(code **)(*in_ECX + 0x50))();
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x54))();
        pppiStack_b88 = (int ***)&PTR_PTR_00f4287c;
        ppiStack_b8c = (int **)&PTR_PTR_00f40910;
        uVar18 = 0;
        uVar6 = FUN_0050b820((uint)piStack_28 & 0xffff,(uint)ppiStack_20 & 0xffff);
        iStack_74 = FUN_00c00d0b(uVar6,uVar18);
        pppiStack_b88 = (int ***)0x8c579e;
        (**(code **)(*in_ECX + 0x50))();
        pppiStack_b88 = (int ***)((int)&param_3 + 3);
        ppiStack_b8c = (int **)0x8c57a9;
        (**(code **)(*in_ECX + 0x50))();
        ppiStack_b8c = &piStack_38;
        piStack_38 = (int *)0x0;
        (**(code **)(*in_ECX + 0x54))();
        uStack_b4 = 0;
        uStack_b0 = 0;
        uStack_ac = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
        FUN_008c6290((uint)piStack_38 & 0xffff);
        iVar3 = 0;
        if ((short)piStack_38 != 0) {
          do {
            (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
            FUN_0041f890((int)&param_1 + 3);
            iVar3 = iVar3 + 1;
          } while (iVar3 < (int)((uint)piStack_38 & 0xffff));
        }
        uStack_84 = 0;
        uStack_82 = 0;
        uStack_80 = 0;
        uStack_7e = 0;
        uStack_7c = 0;
        uStack_7a = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
        FUN_008c6600(auStack_b8);
        FUN_004ed490(&piStack_70);
        piVar4 = (int *)(**(code **)(*piStack_54 + 0x428))((uint)param_2 >> 0x18);
        if (piVar4 != (int *)0x0) {
          param_1 = &ppiStack_b8c;
          FUN_00406a70(&piStack_70);
          (**(code **)(*piVar4 + 0x1a0))(cStack_3d,iStack_74,(uint)param_3 >> 0x18);
        }
        goto LAB_008c5875;
      }
    }
    break;
  case 0x2e:
    uStack_3c = 0xffff;
    piStack_14 = (int *)0xffff;
    ppiStack_20 = (int **)0x0;
    puStack_48 = (uint *)0x0;
    uStack_4c = 0;
    param_3 = (int *)((uint)param_3 & 0xffffff);
    param_1 = (int ***)((uint)param_1 & 0xffffff);
    piStack_2c = (int *)0x0;
    piStack_24 = (int *)0x0;
    param_2 = (int **)((uint)param_2 & 0xffffff);
    piStack_1c = (int *)0x0;
    piStack_44 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    piStack_38 = (int *)(uStack_30 >> 0x10);
    pppiStack_b88 = (int ***)0x8c4682;
    (**(code **)(*in_ECX + 0x54))();
    piStack_28 = (int *)(uint)uStack_30._2_2_;
    pppiStack_b88 = (int ***)((int)&uStack_30 + 2);
    ppiStack_b8c = (int **)0x8c4694;
    (**(code **)(*in_ECX + 0x54))();
    piStack_18 = (int *)(uint)uStack_30._2_2_;
    ppiStack_b8c = (int **)&cStack_3e;
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))((int)&param_3 + 3);
    (**(code **)(*in_ECX + 0x54))(&uStack_3c);
    (**(code **)(*in_ECX + 0x54))(&piStack_14);
    (**(code **)(*in_ECX + 0x50))((int)&param_1 + 3);
    (**(code **)(*in_ECX + 0x54))(&piStack_2c);
    if ((short)piStack_2c != 0) {
      piStack_24 = operator_new((uint)piStack_2c & 0xffff);
      (**(code **)(*in_ECX + 100))(piStack_24,(uint)piStack_2c & 0xffff);
    }
    (**(code **)(*in_ECX + 0x54))(&piStack_44);
    (**(code **)(*in_ECX + 0x50))((int)&param_2 + 3);
    if (param_2._3_1_ != '\0') {
      piStack_1c = operator_new(7);
      if (piStack_1c == (int *)0x0) {
        piStack_1c = (int *)0x0;
      }
      else {
        *(undefined1 *)piStack_1c = 0;
        *(undefined1 *)((int)piStack_1c + 1) = 0;
        *(undefined1 *)((int)piStack_1c + 2) = 0;
        *(undefined4 *)((int)piStack_1c + 3) = 0;
      }
      (**(code **)(*in_ECX + 100))(piStack_1c,7);
    }
    if (((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) &&
       (uStack_60 = FUN_0043ac70(0,0xffffffff), uStack_60 != 0)) {
      piVar4 = (int *)FUN_007403d0((uint)ppiStack_20 & 0xffff);
      if (piVar4 != (int *)0x0) {
        if (param_3._3_1_ != '\0') {
          *(undefined1 *)(piVar4 + 0xa3a) = 1;
        }
        uVar21 = 0;
        ppuVar20 = &PTR_PTR_00f4287c;
        ppuVar19 = &PTR_PTR_00f40910;
        uVar18 = 0;
        uVar6 = FUN_0050b820(uStack_3c & 0xffff,(uint)piStack_14 & 0xffff);
        piStack_34 = (int *)FUN_00c00d0b(uVar6,uVar18,ppuVar19,ppuVar20,uVar21);
        if ((piStack_34 != (int *)0x0) &&
           (cVar1 = (**(code **)(*piStack_34 + 0x2c))(0x11), cVar1 != '\0')) {
          (**(code **)(*piVar4 + 0x354))(piStack_34);
        }
        (**(code **)(*piVar4 + 0x7b0))(piStack_1c,(int)(short)piStack_44);
        piVar4[0xa99] = (uint)bStack_3f;
        (**(code **)(*piVar4 + 0x1c0))((uint)puStack_48 & 0xffff);
        (**(code **)(*piVar4 + 0xbc))(cStack_3e);
        iStack_74 = *piVar4;
        uVar6 = (**(code **)(*in_ECX + 0x9c))();
        (**(code **)(iStack_74 + 0x328))(uVar6);
        FUN_0050dd70(0,0x111,uStack_4c & 0xffff,piVar4,0,0,0);
        cVar1 = (**(code **)(*piVar4 + 0xac))(piStack_38,piStack_28,0);
        if ((cVar1 == '\0') &&
           (cVar1 = (**(code **)(*piVar4 + 0xb0))
                              (&piStack_38,&piStack_28,piStack_38,piStack_28,200,0xffffffff,3),
           cVar1 == '\0')) {
          (*(code *)PTR_FUN_00ff2ebc)(&DAT_00e30fd8);
        }
        (**(code **)(*piVar4 + 0x88))(piStack_38,piStack_28,piStack_18);
        FUN_0050c2b0();
        iVar3 = (**(code **)(*piVar4 + 0x204))();
        if ((0 < iVar3) && (param_1._3_1_ == '\x01')) {
          param_1 = (int ***)((uint)param_1 & 0xffffff);
        }
        (**(code **)(*piVar4 + 0x7a0))((uint)param_1 >> 0x18,piStack_24,(uint)piStack_2c & 0xffff);
        FUN_00448df0(piVar4,piStack_34);
        if ((short)ppiStack_20 == 0x4fb4) {
          FUN_004479b0(u_PR_TIGHTEN_00e30fbc,0xffffffff,0,0);
        }
      }
      _free(piStack_24);
      _free(piStack_1c);
      *(undefined1 *)(DAT_0100311c + 0x21c) = 0;
      *(undefined1 *)(DAT_01003120 + 0x21c) = 0;
      *(undefined1 *)(DAT_01003124 + 0x21c) = 0;
      *(undefined1 *)(DAT_010030e8 + 0x21c) = 0;
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x2f:
    param_1._3_1_ = -1;
    (**(code **)(*in_ECX + 0x50))();
    if (param_1._3_1_ == '\0') {
      param_2 = (int **)0xffff;
      (**(code **)(*in_ECX + 0x54))();
      if ((((short)param_2 != -1) && (DAT_0100314c != 0)) && (iVar3 = FUN_00403e30(), iVar3 != 0)) {
        iVar3 = FUN_00403e30();
        if (*(int *)(iVar3 + 0x204) != 0) {
          FUN_004d13f0();
          *unaff_FS_OFFSET = local_10;
          return;
        }
LAB_008c5a64:
        pppiStack_b88 = (int ***)0x8c5a75;
        (*(code *)PTR_FUN_00ff2ebc)();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    else if (param_1._3_1_ == '\x01') {
      param_3 = (int *)0xffff;
      param_2 = (int **)CONCAT13(1,param_2._0_3_);
      (**(code **)(*in_ECX + 0x54))();
      (**(code **)(*in_ECX + 0x50))();
      if ((((short)param_3 != -1) && (DAT_0100314c != 0)) && (iVar3 = FUN_00403e30(), iVar3 != 0)) {
        iVar3 = FUN_00403e30();
        if (*(int *)(iVar3 + 0x204) == 0) goto LAB_008c5a64;
        iVar3 = FUN_00402060();
        if (iVar3 == -1) {
          piStack_18 = (int *)FUN_00b166b0();
          iVar3 = 0;
          do {
            pppiStack_b88 = (int ***)0x8c59df;
            FUN_008adba0();
            iVar3 = iVar3 + 1;
          } while (iVar3 < 4);
          piStack_54 = (int *)((uint)piStack_18 & 0xffff);
          FUN_00404560();
        }
        piStack_14 = (int *)FUN_00402060();
        cVar1 = FUN_008adbd0();
        if ((param_2._3_1_ == '\0') && (cVar1 == '\x01')) {
          pppiStack_b88 = (int ***)0x8c5a39;
          FUN_008adba0();
          piStack_54 = (int *)((uint)piStack_14 & 0xffff);
          FUN_00404560();
          *unaff_FS_OFFSET = local_10;
          return;
        }
      }
    }
    break;
  case 0x30:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      pppiStack_b88 = (int ***)((uint)param_1 & 0xffff);
      ppiStack_b8c = (int **)((uint)param_2 & 0xffff);
      pppiStack_b88 = (int ***)FUN_0050b820();
      ppiStack_b8c = (int **)0x8c29bc;
      iVar3 = FUN_00c00d0b();
      if (iVar3 != 0) {
        FUN_004f3930();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x31:
    param_1._3_1_ = 0xff;
    (**(code **)(*in_ECX + 0x50))();
    if ((param_1._3_1_ < 0x9c) && (cVar1 = FUN_004e2560(), cVar1 == '\0')) {
      uVar12 = 0;
      iVar3 = FUN_00466790();
      if (iVar3 != 0) {
        do {
          piVar4 = (int *)FUN_0041ee40();
          if ((int *)*piVar4 != (int *)0x0) {
            (**(code **)(*(int *)*piVar4 + 0x38))();
          }
          uVar12 = uVar12 + 1;
          uVar10 = FUN_00466790();
        } while (uVar12 < uVar10);
      }
    }
    iVar3 = FUN_00402060();
    if (iVar3 == 3) {
      FUN_00403e70();
    }
    iVar3 = FUN_00402060();
    if ((iVar3 == 10) && (FUN_00403e70(), param_1._3_1_ == 0x6a)) {
      (**(code **)(*DAT_01003164 + 0x88))();
      FUN_00439a50();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x32:
    param_1 = (int ***)0xffff;
    param_2 = (int **)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if (((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) && (DAT_0100313c != 0))
    {
      iVar3 = FUN_0055bcd0();
      if (iVar3 != 0) {
        FUN_0055b560();
        *unaff_FS_OFFSET = local_10;
        return;
      }
      (*(code *)PTR_FUN_00ff2ebc)();
      *unaff_FS_OFFSET = local_10;
      return;
    }
    (*(code *)PTR_FUN_00ff2ebc)();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x33:
    param_1 = (int ***)0x0;
    puStack_48 = (uint *)0x0;
    uStack_4c = 0;
    param_3 = (int *)0x0;
    param_2 = (int **)0x0;
    piStack_44 = (int *)0x0;
    uStack_3c = 0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)0x8c5cef;
    (**(code **)(*in_ECX + 0x54))();
    pppiStack_b88 = (int ***)&param_1;
    ppiStack_b8c = (int **)0x8c5cfa;
    (**(code **)(*in_ECX + 0x54))();
    piStack_6c = (int *)0x0;
    piStack_68 = (int *)0x0;
    uStack_64 = 0;
    iVar3 = 0;
    uStack_8 = 0xf;
    if ((short)param_1 != 0) {
      do {
        ppiStack_b8c = &piStack_14;
        piStack_14 = (int *)0x0;
        piStack_18 = (int *)0x0;
        (**(code **)(*in_ECX + 0x54))();
        (**(code **)(*in_ECX + 0x54))(&piStack_18);
        if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
          ppiStack_b8c = (int **)((uint)piStack_18 & 0xffff);
          piStack_54 = (int *)FUN_0050b820((uint)piStack_14 & 0xffff);
          if (piStack_54 != (int *)0x0) {
            ppiStack_b8c = &piStack_54;
            FUN_0048e4f0();
          }
        }
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)((uint)param_1 & 0xffff));
    }
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)(uStack_3c & 0xffff);
      piVar4 = (int *)FUN_0050b820((uint)piStack_44 & 0xffff);
      if ((piVar4 != (int *)0x0) &&
         ((piStack_6c != (int *)0x0 && ((int)piStack_68 - (int)piStack_6c >> 2 != 0)))) {
        ppiStack_b8c = (int **)((uint)param_2 & 0xffff);
        (**(code **)(*piVar4 + 0x178))((uint)puStack_48 & 0xffff,&piStack_70,(uint)param_3 & 0xffff)
        ;
        (**(code **)(*piVar4 + 0x17c))
                  ((uint)param_3 & 0xffff,(uint)param_2 & 0xffff,uStack_4c & 0xffff);
      }
    }
    ppiStack_b8c = (int **)0x8c5de7;
    FUN_00644d50();
    *unaff_FS_OFFSET = local_10;
    return;
  case 0x34:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if (((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) &&
       ((ppiStack_b8c = (int **)FUN_0050b820(), ppiStack_b8c != (int **)0x0 &&
        (cVar1 = (*(code *)(*ppiStack_b8c)[0xb])(), cVar1 != '\0')))) {
      pppiStack_b88 = (int ***)0x0;
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x1b0))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x35:
    (**(code **)(*in_ECX + 0x50))();
    bVar11 = 0;
    if (param_1._3_1_ != '\0') {
      do {
        (**(code **)(*in_ECX + 0x5c))();
        (**(code **)(*in_ECX + 0x50))();
        (**(code **)(*in_ECX + 0x50))();
        FUN_00493a60();
        bVar11 = bVar11 + 1;
      } while (bVar11 < param_1._3_1_);
      *unaff_FS_OFFSET = local_10;
      return;
    }
    break;
  case 0x36:
    param_2 = (int **)0x0;
    param_1 = (int ***)0x0;
    param_3 = (int *)0x0;
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    (**(code **)(*in_ECX + 0x54))();
    if ((in_ECX[0x42818] != 0) && (*(int *)(in_ECX[0x42818] + 0xb0) != 0)) {
      ppiStack_b8c = (int **)((uint)param_1 & 0xffff);
      pppiStack_b88 = (int ***)0x0;
      ppiStack_b8c = (int **)FUN_0050b820((uint)param_2 & 0xffff);
      piVar4 = (int *)FUN_00c00d0b();
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x1c0))();
        *unaff_FS_OFFSET = local_10;
        return;
      }
    }
    break;
  case 0x37:
    bStack_4d = 0xff;
    cStack_3d = '\x01';
    (**(code **)(*in_ECX + 0x50))();
    (**(code **)(*in_ECX + 0x50))();
    if (((bStack_4d != 0xffff) && (DAT_0100314c != 0)) && (iVar3 = FUN_00403e30(), iVar3 != 0)) {
      bVar13 = cStack_3d != '\0';
      iVar3 = FUN_00403e30();
      *(bool *)(iVar3 + 0x210) = bVar13;
    }
  }
  *unaff_FS_OFFSET = local_10;
  return;
}

