
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00726150(void)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  DWORD DVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piVar8;
  float fVar9;
  int iVar10;
  uint uVar11;
  float fVar12;
  undefined1 *puVar13;
  float *in_ECX;
  uint3 uVar14;
  float *pfVar15;
  undefined4 *unaff_FS_OFFSET;
  bool bVar16;
  float10 fVar17;
  wchar_t *pwVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  undefined4 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  undefined4 uVar26;
  undefined8 uVar27;
  float *pfVar28;
  undefined8 uVar29;
  longlong lVar30;
  ulonglong uVar31;
  double dVar32;
  undefined1 local_7a8 [256];
  undefined1 local_6a8 [352];
  undefined1 auStack_548 [96];
  undefined1 auStack_4e8 [16];
  undefined1 auStack_4d8 [16];
  undefined1 auStack_4c8 [16];
  undefined1 local_4b8 [16];
  undefined1 local_4a8 [16];
  undefined1 auStack_498 [8];
  undefined1 local_490 [16];
  undefined1 local_480 [16];
  undefined1 local_470 [16];
  undefined1 local_460 [16];
  undefined1 local_450 [16];
  undefined1 local_440 [16];
  undefined1 local_430 [16];
  undefined1 local_420 [16];
  undefined1 local_410 [4];
  undefined4 local_40c;
  undefined4 local_408;
  undefined4 local_404;
  undefined1 local_400 [4];
  undefined4 local_3fc;
  undefined4 local_3f8;
  undefined4 local_3f4;
  undefined1 local_3f0 [4];
  undefined4 local_3ec;
  undefined4 local_3e8;
  undefined4 local_3e4;
  undefined1 local_3e0 [4];
  undefined4 local_3dc;
  undefined4 local_3d8;
  undefined4 local_3d4;
  undefined1 local_3d0 [4];
  undefined4 local_3cc;
  undefined4 local_3c8;
  undefined4 local_3c4;
  undefined1 local_3c0 [16];
  undefined1 local_3b0 [4];
  undefined4 local_3ac;
  undefined4 local_3a8;
  undefined4 local_3a4;
  undefined1 auStack_3a0 [4];
  undefined4 uStack_39c;
  undefined4 uStack_398;
  undefined4 uStack_394;
  undefined1 local_390 [4];
  undefined4 local_38c;
  undefined4 local_388;
  undefined4 local_384;
  undefined1 local_380 [4];
  undefined4 local_37c;
  undefined4 local_378;
  undefined4 local_374;
  undefined1 local_370 [4];
  undefined4 local_36c;
  undefined4 local_368;
  undefined4 local_364;
  undefined1 local_360 [4];
  undefined4 local_35c;
  undefined4 local_358;
  undefined4 local_354;
  undefined1 local_350 [4];
  undefined4 local_34c;
  undefined4 local_348;
  undefined4 local_344;
  undefined1 local_340 [4];
  void *local_33c;
  undefined4 local_338;
  undefined4 local_334;
  undefined1 local_330 [4];
  undefined4 local_32c;
  undefined4 local_328;
  undefined4 local_324;
  undefined1 local_320 [4];
  void *local_31c;
  undefined4 local_318;
  undefined4 local_314;
  undefined1 local_310 [4];
  void *local_30c;
  undefined4 local_308;
  undefined4 local_304;
  undefined1 local_300 [4];
  void *local_2fc;
  undefined4 local_2f8;
  undefined4 local_2f4;
  undefined1 local_2f0 [4];
  void *local_2ec;
  undefined4 local_2e8;
  undefined4 local_2e4;
  undefined1 local_2e0 [4];
  void *local_2dc;
  undefined4 local_2d8;
  undefined4 local_2d4;
  undefined1 local_2d0 [4];
  void *local_2cc;
  undefined4 local_2c8;
  undefined4 local_2c4;
  undefined1 local_2c0 [4];
  void *local_2bc;
  undefined4 local_2b8;
  undefined4 local_2b4;
  undefined1 local_2b0 [4];
  void *local_2ac;
  undefined4 local_2a8;
  undefined4 local_2a4;
  undefined1 local_2a0 [4];
  void *local_29c;
  undefined4 local_298;
  undefined4 local_294;
  undefined1 local_290 [4];
  void *local_28c;
  undefined4 local_288;
  undefined4 local_284;
  undefined1 local_280 [4];
  void *local_27c;
  undefined4 local_278;
  undefined4 local_274;
  undefined1 local_270 [4];
  void *local_26c;
  undefined4 local_268;
  undefined4 local_264;
  undefined1 local_260 [4];
  void *local_25c;
  undefined4 local_258;
  undefined4 local_254;
  undefined1 local_250 [4];
  void *local_24c;
  undefined4 local_248;
  undefined4 local_244;
  undefined1 local_240 [4];
  void *local_23c;
  undefined4 local_238;
  undefined4 local_234;
  undefined1 local_230 [4];
  void *local_22c;
  undefined4 local_228;
  undefined4 local_224;
  undefined1 auStack_220 [4];
  undefined4 uStack_21c;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined1 local_210 [4];
  void *local_20c;
  undefined4 local_208;
  undefined4 local_204;
  undefined1 local_200 [4];
  void *local_1fc;
  undefined4 local_1f8;
  undefined4 local_1f4;
  undefined1 local_1f0 [4];
  void *local_1ec;
  undefined4 local_1e8;
  undefined4 local_1e4;
  undefined1 local_1e0 [4];
  void *local_1dc;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined1 local_1d0 [4];
  void *local_1cc;
  undefined4 local_1c8;
  undefined4 local_1c4;
  undefined1 local_1c0 [4];
  void *local_1bc;
  undefined4 local_1b8;
  undefined4 local_1b4;
  undefined1 local_1b0 [4];
  void *local_1ac;
  undefined4 local_1a8;
  undefined4 local_1a4;
  undefined1 local_1a0 [4];
  void *local_19c;
  undefined4 local_198;
  undefined4 local_194;
  undefined1 local_190 [4];
  void *local_18c;
  undefined4 local_188;
  undefined4 local_184;
  undefined1 local_180 [4];
  void *local_17c;
  undefined4 local_178;
  undefined4 local_174;
  undefined1 local_170 [4];
  void *local_16c;
  undefined4 local_168;
  undefined4 local_164;
  undefined1 local_160 [4];
  void *local_15c;
  undefined4 local_158;
  undefined4 local_154;
  undefined1 local_150 [16];
  undefined1 local_140 [16];
  undefined1 local_130 [4];
  void *local_12c;
  undefined4 local_128;
  undefined4 local_124;
  undefined1 local_120 [4];
  void *local_11c;
  undefined4 local_118;
  undefined4 local_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined1 local_108 [4];
  undefined4 local_104;
  undefined4 local_100;
  undefined4 local_fc;
  undefined1 local_f8 [4];
  undefined4 local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  undefined1 local_e8 [4];
  undefined4 local_e4;
  undefined4 local_e0;
  undefined4 local_dc;
  undefined1 local_d8 [4];
  undefined4 local_d4;
  undefined4 local_d0;
  undefined4 local_cc;
  undefined1 local_c8 [4];
  undefined4 local_c4;
  undefined4 local_c0;
  undefined4 local_bc;
  undefined1 local_b8 [4];
  undefined4 local_b4;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined1 local_a8 [4];
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined1 local_98 [4];
  undefined4 local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined1 local_88 [4];
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined1 local_78 [4];
  void *local_74;
  undefined4 local_70;
  undefined4 local_6c;
  int iStack_68;
  undefined1 local_64 [4];
  void *local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined1 local_54 [4];
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  int iStack_44;
  char local_3d;
  int *local_3c [2];
  float *local_34;
  float *local_30;
  int *local_2c;
  float *local_28;
  int *local_24;
  float *local_20;
  int iStack_1c;
  float local_18;
  float *local_14;
  undefined4 local_10;
  undefined1 *puStack_c;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  puStack_c = &LAB_00c71351;
  local_10 = *unaff_FS_OFFSET;
  *unaff_FS_OFFSET = &local_10;
  FUN_004bf9d0();
  fVar9 = in_ECX[0xad6];
  if ((fVar9 != 0.0) && (*(char *)((int)fVar9 + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0xfc))(fVar9);
  }
  FUN_0071ee30();
  iVar3 = (**(code **)((int)*in_ECX + 0x64c))(0x35);
  if (0 < iVar3) {
    FUN_00b06f00();
    cVar2 = FUN_00a51fb0();
    if (cVar2 != '\0') {
      FUN_007252d0();
    }
  }
  FUN_00721d20();
  uVar4 = FUN_00402060();
  switch(uVar4) {
  case 0:
    iVar3 = FUN_00402060();
    if (((iVar3 == 0) || ((int *)in_ECX[0xc1b] == (int *)0x0)) ||
       (cVar2 = (**(code **)(*(int *)in_ECX[0xc1b] + 0x60))(), cVar2 == '\0')) {
      if (*(char *)(in_ECX + 0xc1c) != '\0') {
        (**(code **)((int)*in_ECX + 0x110))();
        *(undefined1 *)(in_ECX + 0xc1c) = 0;
      }
    }
    else if (*(char *)(in_ECX + 0xc1c) == '\0') {
      (**(code **)((int)*in_ECX + 0x10c))(u_R_SM_MOANING_LOOP_00d7c130,0x16,0);
      *(undefined1 *)(in_ECX + 0xc1c) = 1;
    }
    break;
  case 7:
    if ((*(char *)(in_ECX + 0xad7) != '\0') && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      fVar9 = in_ECX[0xacd];
      if (fVar9 == -NAN) {
        if (*(char *)((int)in_ECX + 0x2b5e) == '\x01') {
          fVar9 = in_ECX[0xad6];
          uVar4 = 2;
          goto code_r0x00729fe8;
        }
      }
      else {
        if (fVar9 == 0.0) {
          (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xad2],0,0,0,0,0,0,0);
          fVar9 = in_ECX[0xad4];
        }
        else {
          if (fVar9 != 1.4013e-45) goto code_r0x00729ff2;
          (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xad3],0,0,0,0,0,0,0);
          fVar9 = in_ECX[0xad5];
        }
        uVar4 = 3;
code_r0x00729fe8:
        (**(code **)((int)*in_ECX + 0xf8))(uVar4,fVar9,0,0,0,0,0,0x100000000);
      }
code_r0x00729ff2:
      *(undefined1 *)(in_ECX + 0xad7) = 0;
    }
    break;
  case 8:
    iVar3 = FUN_00402060();
    if (iVar3 == 0x2e) {
      if ((*(char *)(in_ECX + 0xced) == '\0') && (2 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        *(undefined1 *)(in_ECX + 0xced) = 1;
        uVar4 = 0;
        local_14 = (float *)0x0;
        iVar3 = (**(code **)((int)*in_ECX + 0x620))();
        pfVar15 = local_14;
        if (iVar3 == 0) {
          uVar4 = 5;
          pfVar15 = (float *)0xffffffee;
        }
        (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xceb],uVar4,pfVar15,0,0,0,0,0);
      }
      if ((in_ECX[0xceb] != 0.0) && (*(char *)((int)in_ECX[0xceb] + 0x13a) != '\0')) {
        (**(code **)((int)*in_ECX + 0xfc))();
      }
      if ((*(char *)(in_ECX + 0xaaf) == '\0') && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        (**(code **)((int)*in_ECX + 0x2e0))(0);
        *(undefined1 *)(in_ECX + 0xaaf) = 1;
      }
    }
    else {
      iVar3 = FUN_00402060();
      if (iVar3 == -1) {
        if ((((*(char *)(in_ECX + 0xca0) != '\0') && (iVar3 = FUN_00402060(), iVar3 == 2)) &&
            (*(char *)((int)in_ECX + 0x3281) == '\0')) && (1 < *(int *)((int)in_ECX[0x41] + 0x124)))
        {
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            uVar19 = 0xc;
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
            uVar29 = CONCAT44(uVar19,uVar4);
            uVar27 = CONCAT44(in_ECX,0x58);
            uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x58);
            uVar22 = 8;
            uVar19 = 0x58;
            (**(code **)((int)*in_ECX + 0x67c))(0x58,8,uVar4,uVar27,uVar29);
            iVar3 = FUN_004caa20(uVar19,uVar22,uVar4,uVar27);
            fVar9 = *in_ECX;
            uVar27 = 0;
            uVar21 = 0;
            uVar20 = 0;
            uVar25 = 0;
            uVar24 = 4;
            local_14 = (float *)(iVar3 + -100);
            uVar4 = FUN_008ac050(u_we_wheel_z_offset_00d7c10c);
            uVar22 = 0;
            uVar19 = FUN_008ac050(u_we_wheel_x_offset_00d7c0e8);
            (**(code **)((int)fVar9 + 0x2b8))
                      (0x4e59,local_14,0,0,uVar19,uVar22,uVar4,uVar24,uVar25,uVar20,uVar21,uVar27);
          }
          *(undefined1 *)((int)in_ECX + 0x3281) = 1;
        }
      }
      else {
        iVar3 = FUN_00402060();
        if ((iVar3 == 0x43) && (*(char *)(in_ECX + 0xab2) != '\0')) {
          if ((*(char *)(in_ECX + 0x76) == '\0') || (in_ECX[0x77] != -1.7014636e+38)) {
            (**(code **)((int)*in_ECX + 0x14c))(1,0xff0000ff,1);
          }
          iVar3 = FUN_00402060();
          if (iVar3 != 1) {
            (**(code **)((int)*in_ECX + 0x2e0))(1);
          }
        }
      }
    }
    break;
  case 10:
    if (in_ECX[0x90a] != 0.0) break;
    iVar3 = FUN_00402060();
    if (iVar3 == 0x2c) {
      iVar3 = FUN_00402060();
      if (iVar3 == 1) {
        (**(code **)((int)*in_ECX + 0x2e0))(1);
      }
      break;
    }
    iVar3 = FUN_00402060();
    if (iVar3 == 0x20) {
      (**(code **)((int)*in_ECX + 0x2e0))(1);
      break;
    }
    iVar3 = FUN_00402060();
    if (((iVar3 != 0x4a) || (iVar3 = FUN_00402060(), iVar3 != 1)) ||
       ((**(code **)((int)*in_ECX + 0x2e0))(1), *(char *)(in_ECX + 0xbf4) != '\0')) break;
    if (((int *)in_ECX[0xbf2] != (int *)0x0) &&
       (cVar2 = (**(code **)(*(int *)in_ECX[0xbf2] + 0x60))(), cVar2 != '\0')) {
      cVar2 = func_0x005a9100();
      if (cVar2 != '\0') {
        cVar2 = FUN_0049c090();
        if (cVar2 != '\0') {
          local_34 = (float *)(**(code **)((int)*in_ECX + 0x67c))();
          local_24 = (int *)(**(code **)((int)*in_ECX + 0x64c))(0x4a);
          local_14 = (float *)FUN_0071b8d0();
          if (0 < (int)local_14) {
            local_28 = (float *)0x0;
            local_30 = local_14;
            do {
              DAT_00f5478c = 0;
              uVar19 = 0;
              uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
              FUN_004caa20(1,local_24,in_ECX,uVar4,uVar19);
              FUN_005b8030();
              FUN_008ae0f0();
              FUN_005b8030();
              FUN_004e2780();
              FUN_0054ff60(1,in_ECX);
              FUN_004e2780();
              FUN_0054ff60(0,in_ECX);
              FUN_00b06f00();
              FUN_004e2780();
              uVar19 = 0;
              uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
              uVar4 = FUN_004caa20(0,local_24,in_ECX,uVar4,uVar19);
              (**(code **)((int)*in_ECX + 0x2b8))
                        (0x4e46,uVar4,0,0,0,0,0x82,4,0,DAT_00f5478c,DAT_00f54788,0);
              local_28 = local_28 + 0x5a;
              local_30 = (float *)((int)local_30 + -1);
            } while (local_30 != (float *)0x0);
          }
        }
        *(undefined1 *)(in_ECX + 0xbf4) = 1;
      }
      break;
    }
    goto code_r0x00726f8c;
  case 0x13:
    if (in_ECX[0xbb0] == 1.4013e-45) {
      piVar8 = (int *)FUN_0041ffe0();
      fVar17 = (float10)(**(code **)(*piVar8 + 8))();
      if ((ABS(fVar17) < (float10)_DAT_00cc8170) && (*(char *)(in_ECX + 0xbb4) == '\0')) {
        local_18 = (float)FUN_00403c50();
        local_8 = 0;
        if (local_18 == 0.0) {
          uVar4 = 0;
        }
        else {
          FUN_004334b0(u_Effect_Animation_Guard_Dust_ani_00d7c0a8);
          uVar4 = FUN_00472a60();
        }
        local_8 = 0xffffffff;
        local_18 = (float)FUN_00403c50();
        local_8 = 1;
        if (local_18 == 0.0) {
          pfVar15 = (float *)0x0;
        }
        else {
          pfVar15 = (float *)FUN_004abd20(uVar4,1);
        }
        local_8 = 0xffffffff;
        local_28 = pfVar15;
        FUN_0050dd70(in_ECX,2,0,pfVar15,in_ECX,0,0);
        local_14 = (float *)*pfVar15;
        (**(code **)((int)*in_ECX + 0xc0))();
        (*(code *)local_14[0x2f])();
        iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
        if (iVar3 == 0) {
          iVar3 = (**(code **)((int)*in_ECX + 0x94))();
          local_14 = (float *)(iVar3 + 0x2d);
        }
        else {
          iVar3 = (**(code **)((int)*in_ECX + 0x94))();
          local_14 = (float *)(iVar3 + -0x2d);
        }
        fVar9 = *pfVar15;
        uVar4 = (**(code **)((int)*in_ECX + 0x9c))();
        uVar4 = (**(code **)((int)*in_ECX + 0x98))(uVar4);
        (**(code **)((int)fVar9 + 0x88))(local_14,uVar4);
        *(undefined1 *)(in_ECX + 0xbb4) = 1;
      }
      iVar3 = FUN_00b06f00();
      if ((int)in_ECX[0xbb2] <= iVar3) {
        if (in_ECX[0xbba] == 1.4013e-45) {
          pfVar15 = in_ECX;
          (**(code **)((int)*in_ECX + 0x67c))();
          iVar3 = FUN_0054ff60();
          uVar29 = CONCAT44(pfVar15,in_ECX);
          uVar27 = 0x200000001;
          (**(code **)((int)*in_ECX + 0x67c))(1,2);
          local_14 = (float *)FUN_0054ff60(uVar27);
          (**(code **)((int)*in_ECX + 0x488))
                    (0,iVar3,iVar3,0,(iVar3 * -1000) / (int)local_14,1,uVar29);
          fVar9 = *in_ECX;
          uVar4 = (**(code **)((int)fVar9 + 0xc0))(4,0);
          (**(code **)((int)fVar9 + 0x49c))(uVar4);
          in_ECX[0xbb2] = (float)((int)local_14 + (int)in_ECX[0xbb2] + 100);
          FUN_004ba360();
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            iVar3 = (**(code **)((int)*in_ECX + 0x620))();
            if ((iVar3 == 3) && (iVar3 = (**(code **)((int)*in_ECX + 0x64c))(), 0 < iVar3)) {
              iVar3 = (**(code **)((int)*in_ECX + 0x67c))();
              local_2c = (int *)(**(code **)((int)*in_ECX + 0x64c))(0xe);
              local_20 = (float *)0x3;
            }
            else {
              iVar3 = (**(code **)((int)*in_ECX + 0x620))();
              if ((iVar3 != 0) || (iVar3 = (**(code **)((int)*in_ECX + 0x64c))(), iVar3 < 1))
              goto code_r0x007267c8;
              iVar3 = (**(code **)((int)*in_ECX + 0x67c))();
              local_2c = (int *)(**(code **)((int)*in_ECX + 0x64c))(0xc);
              local_20 = (float *)&DAT_00000004;
            }
            if (iVar3 != 0) {
              uVar19 = 0xc;
              uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
              iVar3 = FUN_004caa20(local_20,local_2c,in_ECX,uVar4,uVar19);
              local_24 = (int *)(iVar3 + -100);
              DAT_00f5478c = 0;
              local_14 = (float *)FUN_00550080((char *)((int)local_20 + 1),local_2c,in_ECX,
                                               0xffffffff,0xffffffff,0xc,0,0);
              FUN_005b8030();
              FUN_00550080((char *)((int)local_20 + 2),local_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0
                          );
              FUN_004e2780();
              FUN_00550080((char *)((int)local_20 + 3),local_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0
                          );
              FUN_005b8030();
              (**(code **)((int)*in_ECX + 0x2b8))
                        (0x4e47,local_24,0,0,0,0,0,4,0,DAT_00f5478c,DAT_00f54788,0);
            }
          }
code_r0x007267c8:
          in_ECX[0xbba] = 2.8026e-45;
        }
        else {
          uStack_21c = 0;
          uStack_218 = 0;
          uStack_214 = 0;
          local_8 = 2;
          local_14 = (float *)0x0;
          FUN_00407120();
          local_14 = (float *)0x0;
          FUN_00407120();
          local_14 = (float *)0x0;
          FUN_00407120();
          local_14 = (float *)(**(code **)((int)*in_ECX + 0xc0))();
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x13,auStack_220,0,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
    }
    break;
  case 0x14:
    if (in_ECX[0xbbb] == 1.4013e-45) {
      local_14 = (float *)FUN_00a24ce0();
      iVar3 = FUN_00b06f00();
      pfVar15 = (float *)(iVar3 - (int)local_14);
      local_20 = pfVar15;
      if ((*(char *)(in_ECX + 0xbbe) == '\0') && (-1 < (int)pfVar15)) {
        local_28 = in_ECX + 0xbc1;
        local_14 = (float *)0x0;
        do {
          local_14 = (float *)((int)local_14 + 1);
          (**(code **)((int)*in_ECX + 0xf8))(local_14,*local_28,0,0,0,0,0,0,0);
          local_28 = local_28 + 1;
        } while ((int)local_14 < 2);
        *(undefined1 *)(in_ECX + 0xbbe) = 1;
      }
      if ((int)in_ECX[0xbbc] <= (int)pfVar15) {
        if (*(char *)((int)in_ECX + 0x2ef9) == '\0') {
          *(undefined1 *)((int)in_ECX + 0x2ef9) = 1;
          local_14 = (float *)0x2;
          do {
            (**(code **)((int)*in_ECX + 0xfc))();
            local_14 = (float *)((int)local_14 + -1);
          } while (local_14 != (float *)0x0);
          local_34 = (float *)(**(code **)((int)*in_ECX + 0x94))();
          local_30 = (float *)(**(code **)((int)*in_ECX + 0x98))();
          local_24 = (int *)(**(code **)((int)*in_ECX + 0x9c))();
          local_18 = (float)FUN_00403c50();
          local_8 = 3;
          if (local_18 == 0.0) {
            uVar4 = 0;
          }
          else {
            FUN_004334b0(u_Effect_Animation_HardAttackFullC_00d7c050);
            uVar4 = FUN_00472a60();
          }
          local_8 = 0xffffffff;
          local_18 = (float)FUN_00403c50();
          local_8 = 4;
          if (local_18 == 0.0) {
            pfVar15 = (float *)0x0;
          }
          else {
            pfVar15 = (float *)FUN_004abd20(uVar4,1);
          }
          local_8 = 0xffffffff;
          local_14 = pfVar15;
          FUN_0050dd70(in_ECX,2,0,pfVar15,in_ECX,0,0);
          local_28 = (float *)*pfVar15;
          (**(code **)((int)*in_ECX + 0xc0))();
          (**(code **)((int)local_28 + 0xbc))();
          (**(code **)((int)*pfVar15 + 0x88))(local_34,local_30,local_24);
          local_18 = (float)FUN_00403c50(0x1e8);
          local_8 = 5;
          if (local_18 == 0.0) {
            uVar4 = 0;
          }
          else {
            uVar19 = 1;
            pwVar18 = u_Effect_Animation_HardAttackFullC_00d7bff8;
            uVar4 = FUN_004334b0(u_Effect_Animation_HardAttackFullC_00d7bff8,1);
            uVar4 = FUN_00472a60(uVar4,pwVar18,uVar19);
          }
          local_8 = 0xffffffff;
          local_18 = (float)FUN_00403c50(0x1fc);
          local_8 = 6;
          if (local_18 == 0.0) {
            pfVar15 = (float *)0x0;
          }
          else {
            pfVar15 = (float *)FUN_004abd20(uVar4,1);
          }
          local_8 = 0xffffffff;
          local_14 = pfVar15;
          FUN_0050dd70(in_ECX,2,0,pfVar15,in_ECX,0,0);
          local_28 = (float *)*pfVar15;
          uVar4 = (**(code **)((int)*in_ECX + 0xc0))();
          (*(code *)local_28[0x2f])(uVar4);
          (**(code **)((int)*pfVar15 + 0x88))(local_34,local_30,local_24);
          (**(code **)((int)*in_ECX + 0x10c))(u_GHOSTSLASH_CHARGE_END_00d6e968,0xffffffff,0,0);
          pfVar15 = local_20;
        }
        if ((int)in_ECX[0xbbc] + 200 <= (int)pfVar15) {
          uVar11 = FUN_00495db0(0xff,0xdc,(char *)((int)pfVar15 + (-200 - (int)in_ECX[0xbbc])));
          FUN_004aba10(0xffff,(uVar11 & 0xff | 0xffff0000) << 8 | uVar11 & 0xff);
        }
      }
    }
    if (((in_ECX[0xbbb] == 2.8026e-45) && (2 < *(int *)((int)in_ECX[0x41] + 0x124))) &&
       (*(char *)(in_ECX + 0xbc3) == '\0')) {
      (**(code **)((int)*in_ECX + 0x10c))(u_GHOSTSLASH_CRY_00d7bfd8,0xffffffff,0);
      *(undefined1 *)(in_ECX + 0xbc3) = 1;
    }
    fVar9 = in_ECX[0xbbb];
    if ((fVar9 == 0.0) || (fVar9 == 4.2039e-45)) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
      if ((in_ECX[0xbc4] != 0.0) && (*(char *)((int)in_ECX[0xbc4] + 0x13a) != '\0')) {
        local_14 = (float *)0x2;
        do {
          (**(code **)((int)*in_ECX + 0xfc))();
          local_14 = (float *)((int)local_14 + -1);
        } while (local_14 != (float *)0x0);
        local_14 = (float *)0x0;
      }
      break;
    }
    if (fVar9 != 2.8026e-45) break;
    if (*(char *)((int)in_ECX + 0x2ef9) != '\0') {
      if ((8 < *(int *)((int)in_ECX[0x41] + 0x124)) && (cVar2 = FUN_0049c090(), cVar2 != '\0')) {
        uStack_39c = 0;
        uStack_398 = 0;
        uStack_394 = 0;
        local_8 = 7;
        local_14 = (float *)0x3;
        FUN_00407120();
        local_14 = (float *)0x0;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x14,auStack_3a0,1,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
      break;
    }
    cVar2 = *(char *)((int)in_ECX[0x41] + 0x13a);
    goto code_r0x00726f86;
  case 0x16:
    iVar3 = FUN_00b06f00();
    if ((int)in_ECX[0xbd0] + 200 <= iVar3) {
      iVar3 = (**(code **)((int)*in_ECX + 0x4d0))();
      piVar8 = (int *)(&DAT_01002e78)[iVar3];
      local_24 = piVar8;
      iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
      local_3d = '\x01' - (iVar3 != 0);
      if (local_3d == '\0') {
        iVar3 = (**(code **)((int)*in_ECX + 0x94))();
        local_14 = (float *)(iVar3 + -0x14);
      }
      else {
        iVar3 = (**(code **)((int)*in_ECX + 0x94))();
        local_14 = (float *)(iVar3 + 0x14);
      }
      local_30 = (float *)*piVar8;
      uVar4 = (**(code **)((int)*in_ECX + 0x9c))();
      uVar4 = (**(code **)((int)*in_ECX + 0x98))(uVar4);
      piVar8 = local_24;
      (*(code *)local_30[10])(local_14,uVar4);
      iVar3 = (**(code **)(*piVar8 + 0x1c))();
      *(char *)(iVar3 + 0x58) = local_3d;
      (**(code **)(*piVar8 + 0xc))(0);
      (**(code **)(*piVar8 + 0x5c))(auStack_4c8);
      local_8 = 8;
      FUN_0050e060(in_ECX,2,0,auStack_4c8,0);
      fVar9 = (float)FUN_00b06f00();
      in_ECX[0xbd0] = fVar9;
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
    break;
  case 0x17:
    if ((*(char *)(in_ECX + 0xbd1) == '\0') && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      (**(code **)((int)*in_ECX + 0x10c))(u_SM_BAL_SHOT_00d7bfc0,0xffffffff,0);
      fVar9 = *in_ECX;
      uVar4 = (**(code **)((int)fVar9 + 0x694))(0,0xffffffff,0,0);
      (**(code **)((int)fVar9 + 0x10c))(uVar4);
      *(undefined1 *)(in_ECX + 0xbd1) = 1;
    }
    if ((*(char *)((int)in_ECX + 0x2f45) == '\0') && (7 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      (**(code **)((int)*in_ECX + 0x10c))(u_SWD_BAL_END_00d7bfa8,0xffffffff,0);
      *(undefined1 *)((int)in_ECX + 0x2f45) = 1;
    }
    if (*(char *)(in_ECX + 0xbdb) == '\0') {
      if (1 < *(int *)((int)in_ECX[0x41] + 0x124)) {
        local_14 = (float *)0x8;
        do {
          (**(code **)((int)*in_ECX + 0xfc))();
          local_14 = (float *)((int)local_14 + -1);
        } while (local_14 != (float *)0x0);
        (**(code **)((int)*in_ECX + 0xf8))(0xfffffffe,in_ECX[0xbd3],0,0,0,0,0,0,0);
        (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xbd5],0,0,0,0,0,0,0,1);
        if (in_ECX[0xbdc] == 0.0) {
          (**(code **)((int)*in_ECX + 0xf8))(0xffffffff,in_ECX[0xbd4],0,0,0,0,0,0,0,1);
          fVar9 = in_ECX[0xbd6];
code_r0x00726f1d:
          (**(code **)((int)*in_ECX + 0xf8))(2,fVar9,0,0,0,0,0,0,0,1);
        }
        else {
          iVar3 = (**(code **)((int)*in_ECX + 0x620))();
          if (iVar3 == 5) {
            (**(code **)((int)*in_ECX + 0xf8))(0xffffffff,in_ECX[0xbd7],0,0,0,0,0,0,0,1);
            fVar9 = in_ECX[0xbd8];
            goto code_r0x00726f1d;
          }
          iVar3 = (**(code **)((int)*in_ECX + 0x620))();
          if (iVar3 == 1) {
            (**(code **)((int)*in_ECX + 0xf8))(0xffffffff,in_ECX[0xbd9],0,0,0,0,0,0,0);
            fVar9 = in_ECX[0xbda];
            goto code_r0x00726f1d;
          }
        }
        *(undefined1 *)(in_ECX + 0xbdb) = 1;
      }
      if (*(char *)(in_ECX + 0xbdb) == '\0') goto PTR_DAT_00726f7a;
    }
    if ((in_ECX[0xbd3] != 0.0) && (*(char *)((int)in_ECX[0xbd3] + 0x13a) != '\0')) {
      local_14 = (float *)0x8;
      do {
        (**(code **)((int)*in_ECX + 0xfc))();
        local_14 = (float *)((int)local_14 + -1);
      } while (local_14 != (float *)0x0);
    }
  case 0x15:
PTR_DAT_00726f7a:
    cVar2 = *(char *)((int)in_ECX[0x41] + 0x13a);
code_r0x00726f86:
    if (cVar2 != '\0') {
code_r0x00726f8c:
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
    break;
  case 0x18:
    if (*(char *)((int)in_ECX[0xbe0] + 0x13a) != '\0') {
      (**(code **)((int)*in_ECX + 0xfc))();
    }
    if ((*(int *)((int)in_ECX[0x41] + 0x124) == 0) &&
       (iVar3 = FUN_004caa00(), (int)in_ECX[0xbe3] <= iVar3)) {
      FUN_004ba360();
      if (in_ECX[0xbdd] == 2.8026e-44) {
        (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xbe0],0,0,0,0,0,0,0);
      }
      else {
        (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xbe0],0x3b);
      }
    }
    if (((int)in_ECX[0xbe5] <= *(int *)((int)in_ECX[0x41] + 0x124)) &&
       (iVar3 = FUN_00402060(), iVar3 == 0)) {
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        fVar9 = in_ECX[0xbdd];
        if ((fVar9 == 2.8026e-44) || (fVar9 == 3.08286e-44)) {
          fVar12 = *in_ECX;
          lVar30 = 0;
          uVar27 = 0;
          uVar23 = 0;
          uVar21 = 4;
          uVar20 = 0;
          uVar25 = 0;
          uVar24 = 0;
          uVar22 = 0;
          uVar19 = 0;
          uVar4 = (**(code **)((int)fVar12 + 0x64c))(fVar9,0,0,0,0,0,4,0,0,0,0);
        }
        else {
          if (fVar9 != 2.94273e-44) goto code_r0x007270af;
          uVar4 = (**(code **)((int)*in_ECX + 0x64c))();
          fVar12 = *in_ECX;
          lVar30 = (ulonglong)(uint)fVar9 << 0x20;
          uVar27 = 0;
          uVar23 = 0;
          uVar21 = 0;
          uVar20 = 4;
          uVar25 = 0;
          uVar24 = 0xfffffffc;
          uVar22 = 100;
          uVar19 = 0;
          fVar9 = 0.0;
        }
        uVar4 = FUN_00402060(uVar4,fVar9,uVar19,uVar22,uVar24,uVar25,uVar20,uVar21,uVar23,uVar27,
                             lVar30);
        (**(code **)((int)fVar12 + 0x2b8))(uVar4);
      }
code_r0x007270af:
      local_14 = (float *)0x1;
      FUN_00404560();
    }
    break;
  case 0x19:
    iVar3 = FUN_00b06f00();
    if ((199 < iVar3) && (iVar3 = FUN_00402060(), iVar3 == 0)) {
      (**(code **)((int)*in_ECX + 0x488))(0,0x1d6,0x1d6,0,0);
      local_14 = (float *)FUN_00402060();
      FUN_00511040(2,(float)(int)local_14 * fRam00d7bc20);
      if (in_ECX[0xc15] == 0.0) {
        local_18 = (float)FUN_00403c50(0x1e8);
        local_8 = 0x13;
        if (local_18 == 0.0) {
          fVar9 = 0.0;
        }
        else {
          uVar19 = 1;
          pwVar18 = u_Effect_Animation_JumpAttackHold__00d7bbd8;
          uVar4 = FUN_004334b0(u_Effect_Animation_JumpAttackHold__00d7bbd8,1);
          fVar9 = (float)FUN_00472a60(uVar4,pwVar18,uVar19);
        }
        local_8 = 0xffffffff;
        in_ECX[0xc15] = fVar9;
      }
      (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xc15],0,0,0,0,0,0,0,1);
      local_14 = (float *)0x1;
      FUN_00404560();
    }
    iVar3 = FUN_00402060();
    if (iVar3 != 0) {
      FUN_00b06f00();
      cVar2 = FUN_00a51fb0();
      if ((cVar2 != '\0') && ((**(code **)((int)*in_ECX + 0x1a0))(), in_ECX[0xc12] == 1.4013e-45)) {
        uVar19 = 0xc;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        uVar29 = CONCAT44(uVar19,uVar4);
        uVar27 = CONCAT44(in_ECX,0xe);
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0xe);
        (**(code **)((int)*in_ECX + 0x67c))(0xe,7,uVar4,uVar27,uVar29);
        iVar3 = FUN_004caa20(uVar4,uVar27,uVar29);
        local_14 = (float *)(iVar3 + -100);
        FUN_00404560();
      }
    }
    break;
  case 0x1a:
    if (in_ECX[0xca4] == 1.4013e-45) {
      (**(code **)((int)*in_ECX + 0x2d8))();
      if (((((int *)in_ECX[0xca6] != (int *)0x0) &&
           (iVar3 = (**(code **)(*(int *)in_ECX[0xca6] + 0x230))(), iVar3 != 9)) &&
          (iVar3 = (**(code **)(*(int *)in_ECX[0xca6] + 0x230))(), iVar3 != 5)) &&
         (cVar2 = FUN_0049c090(), cVar2 != '\0')) {
        (**(code **)(*(int *)in_ECX[0xca6] + 0x28c))(9,0,3,0);
        (**(code **)(*(int *)in_ECX[0xca6] + 0x290))();
      }
      if (in_ECX[0xcab] == 0.0) {
        iVar3 = FUN_00b06f00();
        if (99 < iVar3) {
          cVar2 = FUN_0049c090();
          if (((cVar2 != '\0') && ((int *)in_ECX[0xca6] != (int *)0x0)) &&
             (cVar2 = (**(code **)(*(int *)in_ECX[0xca6] + 0x3dc))(), cVar2 == '\0')) {
            iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
            if (iVar3 == 0) {
              (**(code **)((int)*in_ECX + 0x94))();
            }
            else {
              (**(code **)((int)*in_ECX + 0x94))();
            }
            (**(code **)((int)*in_ECX + 0x9c))();
            (**(code **)((int)*in_ECX + 0x98))();
            FUN_00467330();
            local_8 = 0x14;
            FUN_004eabf0();
            local_8 = 0xffffffff;
            FUN_00404300();
          }
          (**(code **)((int)*in_ECX + 0x10c))(u_BLOOD_SUCK_00d7bbbc,0xffffffff,0);
          in_ECX[0xcab] = 1.4013e-45;
        }
      }
      else if ((in_ECX[0xcab] == 1.4013e-45) && (iVar3 = FUN_00b06f00(), 0x2ed < iVar3)) {
        local_24 = (int *)(**(code **)((int)*in_ECX + 0x67c))();
        local_20 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x1f);
        cVar2 = FUN_0049c090();
        if (cVar2 != '\0') {
          uStack_110 = 0;
          local_14 = (float *)0x0;
          if (in_ECX[0xca6] != 0.0) {
            iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
            if (iVar3 == 0) {
              iVar3 = (**(code **)((int)*in_ECX + 0x94))();
              local_14 = (float *)(iVar3 + -0x2b);
            }
            else {
              iVar3 = (**(code **)((int)*in_ECX + 0x94))();
              local_14 = (float *)(iVar3 + 0x2b);
            }
            iVar3 = (**(code **)((int)*in_ECX + 0x9c))();
            iVar3 = iVar3 + 0x5a;
            uVar4 = (**(code **)((int)*in_ECX + 0x98))();
            FUN_00467330(local_14,uVar4,iVar3);
            local_8 = 0x15;
            local_14 = (float *)FUN_00679e40(&uStack_110,in_ECX[0xca6],auStack_548,1);
            local_8 = 0xffffffff;
            FUN_00404300();
          }
          uVar19 = 0;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
          local_34 = (float *)FUN_004caa20(1,local_20,in_ECX,uVar4,uVar19);
          if (((int *)in_ECX[0xca6] != (int *)0x0) &&
             (cVar2 = (**(code **)(*(int *)in_ECX[0xca6] + 0x410))(), cVar2 != '\0')) {
            uVar19 = 0;
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
            iVar3 = FUN_004caa20(4,local_20,in_ECX,uVar4,uVar19);
            local_34 = (float *)((int)local_34 + iVar3);
          }
          iVar3 = FUN_0073d5f0();
          iVar3 = iVar3 * (int)local_34;
          if ((int *)in_ECX[0xca6] == (int *)0x0) {
code_r0x00729797:
            uVar4 = 0x4e31;
          }
          else {
            cVar2 = (**(code **)(*(int *)in_ECX[0xca6] + 0x410))();
            uVar4 = 0x4e51;
            if (cVar2 == '\0') goto code_r0x00729797;
          }
          (**(code **)((int)*in_ECX + 0x2b8))
                    (uVar4,iVar3 / 100,0,0,0x2b,1,0x5a,4,0,uStack_110,local_14,0,0);
        }
        local_14 = (float *)FUN_00550080(2,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        if (((int *)in_ECX[0xca6] != (int *)0x0) &&
           (cVar2 = (**(code **)(*(int *)in_ECX[0xca6] + 0x410))(), cVar2 != '\0')) {
          local_14 = (float *)FUN_00550080(5,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        }
        local_24 = (int *)FUN_00550080(3,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        local_18 = (float)FUN_00403c50();
        local_8 = 0x16;
        if (local_18 == 0.0) {
          piVar8 = (int *)0x0;
        }
        else {
          piVar8 = (int *)FUN_0046d8a0(0,0,(float)(int)local_24,local_14,1);
        }
        local_8 = 0xffffffff;
        (**(code **)(*piVar8 + 0x48))();
        in_ECX[0xcab] = 2.8026e-45;
        (**(code **)((int)*in_ECX + 0x10c))(u_BLOODR_FIRE_00d7bba4,0xffffffff,0,0);
        FUN_00721800();
        FUN_0054e880(in_ECX,0xffffffff);
      }
    }
    break;
  case 0x1b:
    if ((in_ECX[0xcae] == 1.4013e-45) && (iVar3 = FUN_00b06f00(), (int)in_ECX[0xcaf] <= iVar3)) {
      if (*(char *)(in_ECX + 0xcb1) == '\0') {
        *(undefined1 *)(in_ECX + 0xcb1) = 1;
        local_14 = (float *)0x2;
        do {
          (**(code **)((int)*in_ECX + 0xfc))();
          local_14 = (float *)((int)local_14 + -1);
        } while (local_14 != (float *)0x0);
        local_34 = (float *)(**(code **)((int)*in_ECX + 0x94))();
        local_30 = (float *)(**(code **)((int)*in_ECX + 0x98))();
        local_24 = (int *)(**(code **)((int)*in_ECX + 0x9c))();
        local_18 = (float)FUN_00403c50();
        local_8 = 0x17;
        if (local_18 == 0.0) {
          uVar4 = 0;
        }
        else {
          FUN_004334b0(u_Effect_Animation_grandWaveFullCh_00d7bb50);
          uVar4 = FUN_00472a60();
        }
        local_8 = 0xffffffff;
        local_18 = (float)FUN_00403c50();
        local_8 = 0x18;
        if (local_18 == 0.0) {
          pfVar15 = (float *)0x0;
        }
        else {
          pfVar15 = (float *)FUN_004abd20(uVar4,1);
        }
        local_8 = 0xffffffff;
        local_14 = pfVar15;
        FUN_0050dd70(in_ECX,2,0,pfVar15,in_ECX,0,0);
        local_28 = (float *)*pfVar15;
        (**(code **)((int)*in_ECX + 0xc0))();
        (**(code **)((int)local_28 + 0xbc))();
        (**(code **)((int)*pfVar15 + 0x88))(local_34,local_30,local_24);
        local_18 = (float)FUN_00403c50(0x1e8);
        local_8 = 0x19;
        if (local_18 == 0.0) {
          uVar4 = 0;
        }
        else {
          uVar19 = 1;
          pwVar18 = u_Effect_Animation_grandWaveFullCh_00d7baf8;
          uVar4 = FUN_004334b0(u_Effect_Animation_grandWaveFullCh_00d7baf8,1);
          uVar4 = FUN_00472a60(uVar4,pwVar18,uVar19);
        }
        local_8 = 0xffffffff;
        local_18 = (float)FUN_00403c50(0x1fc);
        local_8 = 0x1a;
        if (local_18 == 0.0) {
          pfVar15 = (float *)0x0;
        }
        else {
          pfVar15 = (float *)FUN_004abd20(uVar4,1);
        }
        local_8 = 0xffffffff;
        local_14 = pfVar15;
        FUN_0050dd70(in_ECX,2,0,pfVar15,in_ECX,0,0);
        local_28 = (float *)*pfVar15;
        uVar4 = (**(code **)((int)*in_ECX + 0xc0))();
        (*(code *)local_28[0x2f])(uVar4);
        (**(code **)((int)*pfVar15 + 0x88))(local_34,local_30,local_24);
        (**(code **)((int)*in_ECX + 0x10c))(u_GHOSTSLASH_CHARGE_END_00d6e968,0xffffffff,0,0);
      }
      iVar3 = FUN_00b06f00();
      if ((int)in_ECX[0xcaf] + 200 <= iVar3) {
        iVar3 = FUN_00b06f00();
        uVar11 = FUN_00495db0(0xff,0xdc,iVar3 + (-200 - (int)in_ECX[0xcaf]));
        FUN_004aba10(0xffff,(uVar11 & 0xff | 0xffff0000) << 8 | uVar11 & 0xff);
      }
    }
    break;
  case 0x1d:
    if ((*(char *)(in_ECX + 0xae7) == '\0') && (0 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      (**(code **)((int)*in_ECX + 0xf8))(0xffffffff,in_ECX[0xae5],0,0,0,0,1,0,0);
      (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xae6],0,0,0,0,1,0,0,1);
      *(undefined1 *)(in_ECX + 0xae7) = 1;
    }
    break;
  case 0x1f:
    if (in_ECX[0xae8] == 1.4013e-45) {
      if (in_ECX[0xaee] == -NAN) {
        if (2 < *(int *)((int)in_ECX[0xaeb] + 0x124)) {
          local_14 = (float *)FUN_007207d0();
          iVar3 = FUN_00b06f00();
          iVar10 = FUN_008ac050();
          in_ECX[0xaee] = (float)((int)local_14 + iVar10 + iVar3);
        }
        if (in_ECX[0xaee] == -NAN) break;
      }
      DVar5 = timeGetTime();
      if ((DVar5 / 0x14 & 1) == 0) {
        FUN_00499db0(0xffffffff,0);
      }
      else {
        FUN_00499db0(1,0);
      }
    }
    break;
  case 0x20:
    if (in_ECX[0xb12] == 0.0) {
      if (*(char *)(in_ECX + 0xaac) == '\0') {
        (**(code **)((int)*in_ECX + 0x10c))(u_UPPER_SLASH_02_00d7be88,0xffffffff,0);
        *(undefined1 *)(in_ECX + 0xaac) = 1;
      }
    }
    else if (in_ECX[0xb12] == 1.4013e-45) {
      (**(code **)((int)*in_ECX + 0x2d8))();
      fVar9 = in_ECX[0x41];
      fVar12 = (float)(**(code **)((int)*in_ECX + 0x38c))(0xe);
      if (fVar9 == fVar12) {
        if (*(char *)((int)fVar9 + 0x13a) != '\0') {
          local_14 = (float *)(**(code **)((int)*in_ECX + 0x67c))();
          local_34 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x3a);
          fVar9 = *in_ECX;
          uVar4 = (**(code **)((int)fVar9 + 0x38c))();
          (**(code **)((int)fVar9 + 0xf0))(uVar4);
          FUN_00a27360();
          (**(code **)((int)*in_ECX + 0x494))(0,0,1000,1000,0x3f800000,0x3f800000);
          fVar9 = *in_ECX;
          uVar4 = FUN_005270f0(0x12);
          (**(code **)((int)fVar9 + 0x198))(uVar4);
          uVar19 = 0xc;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
          iVar3 = FUN_004caa20(1,local_34,in_ECX,uVar4,uVar19);
          local_14 = (float *)(iVar3 + -100);
          FUN_00404560(&local_14);
          (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xb17],0,0,0,0,1,0,0,1);
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            uVar19 = 0xc;
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
            iVar3 = FUN_004caa20(2,local_34,in_ECX,uVar4,uVar19);
            local_14 = (float *)(iVar3 + -100);
            uVar19 = 0;
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0);
            iVar3 = FUN_004caa20(3,local_34,in_ECX,uVar4,uVar19);
            DAT_00f5478c = 0;
            FUN_005b8030((iVar3 * 100) / (int)(local_14 + 0x19));
            uVar4 = FUN_0054ff60(1,in_ECX);
            FUN_005b3550(uVar4);
            uVar4 = 0xf;
            (**(code **)((int)*in_ECX + 0x38c))(0xf,0);
            uVar4 = FUN_00a24bb0(uVar4);
            FUN_004e2780(uVar4);
            fVar9 = *in_ECX;
            uVar24 = 4;
            uVar4 = FUN_008ac050(u_vs_hit_z_offset_00cec188);
            uVar22 = 1;
            uVar19 = FUN_008ac050(u_vs_hit_x_offset_00cec1a8);
            (**(code **)((int)fVar9 + 0x2b8))(0x4e36,local_14,0,0,uVar19,uVar22,uVar4,uVar24);
          }
          (**(code **)((int)*in_ECX + 0x10c))(u_SM_YEOLPA_DOWN_00d7be68,0xffffffff,0,0);
        }
      }
      else if ((*(char *)(in_ECX + 0xb13) == '\0') && (2 < *(int *)((int)fVar9 + 0x124))) {
        cVar2 = FUN_0049c090();
        if ((cVar2 != '\0') && (in_ECX[0xca6] != 0.0)) {
          iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
          if (iVar3 == 0) {
            iVar3 = FUN_008ac050();
            iVar10 = (**(code **)((int)*in_ECX + 0x94))();
            local_14 = (float *)(iVar10 - iVar3);
          }
          else {
            iVar3 = FUN_008ac050();
            iVar10 = (**(code **)((int)*in_ECX + 0x94))();
            local_14 = (float *)(iVar3 + iVar10);
          }
          FUN_008ac050();
          (**(code **)((int)*in_ECX + 0x9c))();
          (**(code **)((int)*in_ECX + 0x98))();
          FUN_00467330();
          local_8 = 0xd;
          FUN_004eabf0();
          local_8 = 0xffffffff;
          FUN_00404300();
        }
        (**(code **)((int)*in_ECX + 0x10c))(u_UPPER_SLASH01_00d7be4c,0xffffffff,0);
        *(undefined1 *)(in_ECX + 0xb13) = 1;
      }
    }
    break;
  case 0x21:
    if (in_ECX[0xaef] == 2.8026e-45) {
      if ((in_ECX[0xafb] != -NAN) && (iVar3 = FUN_00b06f00(), (int)in_ECX[0xafb] <= iVar3)) {
        local_34 = (float *)in_ECX[0xaf3];
        pfVar15 = (float *)*local_34;
        local_20 = pfVar15;
        cVar2 = FUN_00564560();
        while (cVar2 != '\0') {
          piVar8 = (int *)pfVar15[2];
          local_24 = piVar8;
          cVar2 = FUN_0049c090();
          if (cVar2 != '\0') {
            iVar3 = (**(code **)(*piVar8 + 0xe4))();
            local_14 = (float *)(iVar3 / 2);
            (**(code **)(*piVar8 + 0x9c))();
            uVar4 = (**(code **)(*piVar8 + 0x98))();
            (**(code **)(*piVar8 + 0x94))(uVar4);
            FUN_00467330();
            local_8 = 9;
            FUN_004eabf0();
            local_8 = 0xffffffff;
            FUN_00404300();
          }
          local_14 = (float *)FUN_00403c50();
          local_8 = 10;
          if (local_14 == (float *)0x0) {
            local_28 = (float *)0x0;
          }
          else {
            FUN_004334b0(u_Effect_Animation_GhostStepSlash__00d7bf30);
            local_28 = (float *)FUN_00472a60();
          }
          local_8 = 0xffffffff;
          local_14 = (float *)FUN_00403c50();
          local_8 = 0xb;
          if (local_14 == (float *)0x0) {
            local_34 = (float *)0x0;
          }
          else {
            FUN_004334b0(u_Effect_Animation_GhostStepSlash__00d7b760);
            local_34 = (float *)FUN_00472a60();
          }
          local_8 = 0xffffffff;
          iVar3 = (**(code **)(*piVar8 + 0xe4))();
          fVar17 = (float10)FUN_00b099b0(0x3f800000,0x40800000,iVar3 + -0x3c);
          local_14 = (float *)(float)fVar17;
          FUN_00a297b0();
          FUN_00a297b0();
          local_18 = (float)FUN_00403c50();
          local_8 = 0xc;
          if (local_18 == 0.0) {
            local_2c = (int *)0x0;
          }
          else {
            local_2c = (int *)FUN_004abd20(local_28,1);
          }
          local_8 = 0xffffffff;
          (**(code **)(*local_2c + 0xf8))(0xffffffff,local_34,0,0,0,0,1,1,0);
          FUN_0050dd70(in_ECX,2,0,local_2c,piVar8,0,0);
          local_14 = (float *)*local_2c;
          uVar4 = (**(code **)((int)*in_ECX + 0xc0))();
          piVar1 = local_2c;
          (*(code *)local_14[0x2f])(uVar4);
          iVar3 = *piVar1;
          iVar10 = (**(code **)(*piVar8 + 0xe4))();
          local_14 = (float *)(iVar10 / 2);
          iVar10 = (**(code **)(*piVar8 + 0x9c))();
          piVar8 = local_24;
          uVar4 = (**(code **)(*local_24 + 0x98))((undefined1 *)((int)local_14 + iVar10));
          uVar4 = (**(code **)(*piVar8 + 0x94))(uVar4);
          (**(code **)(iVar3 + 0x88))(uVar4);
          local_34 = (float *)in_ECX[0xaf3];
          pfVar15 = (float *)*local_20;
          local_20 = pfVar15;
          cVar2 = FUN_00564560();
        }
        if (in_ECX[0xaff] != 0.0) {
          FUN_0071b280(3,300);
        }
        in_ECX[0xafb] = -NAN;
      }
      if ((in_ECX[0xafc] != -NAN) && (iVar3 = FUN_00b06f00(), (int)in_ECX[0xafc] <= iVar3)) {
        FUN_0071fb90();
        in_ECX[0xafc] = -NAN;
      }
    }
    break;
  case 0x22:
    if (in_ECX[0xb00] == 0.0) {
      FUN_00b06f00();
      cVar2 = FUN_00a51fb0();
      if (cVar2 != '\0') {
        uVar27 = CONCAT44(in_ECX,4);
        (**(code **)((int)*in_ECX + 0x67c))();
        iVar3 = FUN_0054ff60(uVar27);
        iVar10 = FUN_0071ef60();
        if (iVar10 < iVar3) {
          pfVar15 = (float *)FUN_0071ef60();
        }
        else {
          uVar27 = CONCAT44(in_ECX,4);
          (**(code **)((int)*in_ECX + 0x67c))();
          pfVar15 = (float *)FUN_0054ff60(uVar27);
        }
        iVar3 = FUN_00402060();
        if ((iVar3 < 1) && (0 < (int)pfVar15)) {
          (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xb0b],0,0,0,0,0,0,0);
          (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xb0c],4,0xffffffa2,0,0,0,0,0,1);
code_r0x00727800:
          if (0 < (int)pfVar15) goto code_r0x00727804;
        }
        else {
          iVar3 = FUN_00402060();
          if (iVar3 < 1) goto code_r0x00727800;
          if ((int)pfVar15 < 1) {
            (**(code **)((int)*in_ECX + 0xfc))();
            (**(code **)((int)*in_ECX + 0xfc))(in_ECX[0xb0c]);
            goto code_r0x00727800;
          }
code_r0x00727804:
          fVar17 = (float10)FUN_008ac080();
          local_14 = (float *)(float)(fVar17 * (float10)(int)((int)pfVar15 + -1));
          fVar17 = (float10)FUN_008ac080();
          local_14 = (float *)(float)(fVar17 + (float10)(float)local_14);
          FUN_00a25900(local_14,local_14);
        }
        local_14 = pfVar15;
        FUN_00404560();
      }
      iVar3 = FUN_00402060();
      if ((0 < iVar3) && (*(char *)((int)in_ECX[0xb0c] + 0x13a) != '\0')) {
        FUN_004ba360();
      }
    }
    else if (in_ECX[0xb00] == 1.4013e-45) {
      if ((*(char *)(in_ECX + 0xaac) == '\0') && (0 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        fVar9 = *in_ECX;
        uVar4 = (**(code **)((int)fVar9 + 0x694))(0,0xffffffff,0);
        (**(code **)((int)fVar9 + 0x10c))(uVar4);
        iVar3 = FUN_00402060();
        if (iVar3 == 0) {
          (**(code **)((int)*in_ECX + 0x10c))(u_MUSSANG_ATK_01_00d7bec8);
        }
        else {
          (**(code **)((int)*in_ECX + 0x10c))(u_MUSSANG_ATK_02_00d7bea8,0xffffffff,0,0);
        }
        *(undefined1 *)(in_ECX + 0xaac) = 1;
      }
      if ((*(char *)(in_ECX + 0xb08) == '\0') && (0 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        iVar3 = FUN_00402060();
        if ((0 < iVar3) && (cVar2 = FUN_0049c090(), cVar2 != '\0')) {
          local_24 = (int *)(**(code **)((int)*in_ECX + 0x67c))();
          local_14 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x3e);
          uVar19 = 0xc;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
          iVar3 = FUN_004caa20(2,local_14,in_ECX,uVar4,uVar19);
          iVar10 = FUN_00402060();
          uVar19 = 0xc;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
          iVar6 = FUN_004caa20(1,local_14,in_ECX,uVar4,uVar19);
          local_14 = (float *)(iVar3 * (iVar10 + -1) + -100 + iVar6);
          local_34 = (float *)FUN_0054ff60(2,in_ECX);
          iVar3 = FUN_00402060();
          local_34 = (float *)((int)local_34 * (iVar3 + -1));
          FUN_0054ff60(1,in_ECX);
          DAT_00f5478c = 0;
          FUN_004e2780();
          (**(code **)((int)*in_ECX + 0x2b8))
                    (0x4e3b,local_14,0,0,0x1e,1,0x5e,4,0,DAT_00f5478c,DAT_00f54788,0,0);
        }
        *(undefined1 *)(in_ECX + 0xb08) = 1;
      }
    }
    break;
  case 0x23:
    if (in_ECX[0xb18] == 0.0) {
      if (5 < *(int *)((int)in_ECX[0x41] + 0x124)) {
        fVar9 = *in_ECX;
        FUN_005270f0();
        (**(code **)((int)fVar9 + 0x198))();
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
        uVar27 = CONCAT44(uVar4,in_ECX);
        uVar24 = 0x40;
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x40);
        uVar22 = 0;
        uVar19 = 0x40;
        (**(code **)((int)*in_ECX + 0x67c))(0x40,0,uVar4,uVar24,uVar27);
        iVar3 = FUN_004caa20(uVar19,uVar22,uVar4,uVar24);
        iVar10 = FUN_0073d6b0();
        local_14 = (float *)((iVar3 * iVar10) / 100 + -100);
        FUN_00404560(&local_14);
        (**(code **)((int)*in_ECX + 0x10c))(u_R_TSLASH_00d7be38,0xffffffff,0,0);
        in_ECX[0xb18] = 1.4013e-45;
      }
    }
    else if ((in_ECX[0xb18] == 1.4013e-45) && (*(char *)((int)in_ECX[0xb1a] + 0x13a) != '\0')) {
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        (**(code **)((int)*in_ECX + 0x67c))();
        local_2c = (int *)(**(code **)((int)*in_ECX + 0x64c))(0x40);
        uVar19 = 0xc;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        local_14 = (float *)FUN_004caa20(1,local_2c,in_ECX,uVar4,uVar19);
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        iVar3 = FUN_004caa20(7,local_2c,in_ECX,uVar4,uVar19);
        local_24 = (int *)((iVar3 * 100) / (int)local_14);
        iVar3 = FUN_0073d6b0();
        local_20 = (float *)((iVar3 * (int)local_14) / 100 + -100);
        local_14 = (float *)FUN_00550080(2,local_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        local_34 = (float *)((float)(int)local_14 * _DAT_00cc8830);
        local_14 = (float *)FUN_00550080(3,local_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        iVar3 = FUN_0071bdb0();
        local_30 = (float *)((int)local_14 + iVar3);
        local_28 = (float *)FUN_00550080(4,local_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        uVar4 = FUN_00550080(5,local_2c,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
        if (0 < iVar3) {
          uVar19 = 0;
          (**(code **)((int)*in_ECX + 0x67c))(0x3f,0);
          local_14 = (float *)FUN_0054ff60(uVar19);
          local_34 = (float *)((float)(int)local_14 * _DAT_00cc8830 + (float)local_34);
        }
        DAT_00f5478c = 0;
        FUN_005b8030(local_24);
        FUN_005b8030(local_34);
        FUN_004e2780(local_30);
        FUN_005b8030(local_28);
        FUN_005b8030(uVar4);
        fVar9 = *in_ECX;
        uVar4 = (**(code **)((int)fVar9 + 0x2c0))
                          (u_Particle_GoreCross_ptl_00d7be08,0,0x55,0,0x52,4,0,DAT_00f5478c,
                           DAT_00f54788,0,0);
        (**(code **)((int)fVar9 + 0x2b8))(0x4e3c,local_20,uVar4);
      }
      in_ECX[0xb18] = 2.8026e-45;
    }
    break;
  case 0x24:
    if (in_ECX[0xb29] == 1.4013e-45) {
      local_2c = (int *)FUN_004caa00();
      if (*(char *)(in_ECX + 0xb30) == '\0') {
        iVar3 = FUN_00a24ce0();
        iVar10 = FUN_00a24ce0();
        if ((int)local_2c < iVar3) {
          uVar4 = FUN_00c01544(local_2c);
          local_14 = (float *)FUN_00473f20(0,uVar4);
          (**(code **)((int)*in_ECX + 0xc0))();
          (**(code **)((int)*in_ECX + 0x94))();
          FUN_004e7f10();
          (**(code **)((int)*in_ECX + 0x84))(0);
          uVar4 = FUN_004caa50(0,in_ECX[0xb2f],local_2c,iVar3,1);
          (**(code **)((int)*in_ECX + 0x84))(2,uVar4);
        }
        else if ((int)local_2c < iVar10) {
          local_14 = (float *)in_ECX[0xb2e];
          local_24 = (int *)(iVar10 - iVar3);
          local_30 = (float *)((int)local_2c - iVar3);
          uVar27 = CONCAT44(local_24,local_30);
          pfVar15 = local_14;
          uVar4 = FUN_00c01544();
          FUN_00473f20(uVar4,pfVar15,uVar27);
          (**(code **)((int)*in_ECX + 0xc0))();
          (**(code **)((int)*in_ECX + 0x94))();
          FUN_004e7f10();
          (**(code **)((int)*in_ECX + 0x84))(0);
          uVar4 = FUN_004caa50(in_ECX[0xb2f],0,local_30,local_24,0);
          (**(code **)((int)*in_ECX + 0x84))(2,uVar4);
          if (*(char *)(in_ECX + 0xaac) == '\0') {
            fVar9 = *in_ECX;
            uVar4 = (**(code **)((int)fVar9 + 0x694))(0,0xffffffff,0);
            (**(code **)((int)fVar9 + 0x10c))(uVar4);
            (**(code **)((int)*in_ECX + 0x10c))(u_SM_BOONGSAN_00d7bd5c,0xffffffff,0,0);
            *(undefined1 *)(in_ECX + 0xaac) = 1;
          }
        }
        else {
          (**(code **)((int)*in_ECX + 0x84))(2);
          if (in_ECX[0xb34] == 0.0) {
            uVar27 = 0x6400000002;
          }
          else if (in_ECX[0xb34] == 1.4013e-45) {
            uVar27 = 0xc800000003;
          }
          else {
            uVar27 = 0x12c00000005;
          }
          FUN_00538900(uVar27);
          iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
          if ((0 < iVar3) && (cVar2 = FUN_0049c090(), cVar2 != '\0')) {
            local_24 = (int *)(**(code **)((int)*in_ECX + 0x67c))();
            local_20 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x41);
            DAT_00f5478c = 0;
            local_14 = (float *)FUN_00550080(2,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_005b8030();
            FUN_00550080(3,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_0071bdb0();
            FUN_004e2780();
            FUN_00550080(4,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_005b8030();
            FUN_00550080(5,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
            FUN_005b8030();
            uVar27 = CONCAT44((int)in_ECX[0xb2b] - (int)in_ECX[0xb2a],
                              (int)in_ECX[0xb2c] - (int)in_ECX[0xb2a]);
            uVar4 = FUN_0054ff60(0xb,in_ECX);
            uVar19 = FUN_0054ff60(10,in_ECX);
            FUN_00473f20(uVar19,uVar4,uVar27);
            FUN_004e2780();
            uVar19 = 0;
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
            uVar4 = FUN_004caa20(1,local_20,in_ECX,uVar4,uVar19);
            (**(code **)((int)*in_ECX + 0x2b8))
                      (0x4e52,uVar4,0,0,0x7b,1,0,4,0,DAT_00f5478c,DAT_00f54788,0,0);
          }
          *(undefined1 *)(in_ECX + 0xb30) = 1;
        }
      }
      cVar2 = FUN_00a51fb0();
      if (cVar2 != '\0') {
        cVar2 = FUN_0061d410();
        if (cVar2 == '\0') {
          (**(code **)((int)*in_ECX + 0x1a0))();
        }
        else {
          fVar9 = *in_ECX;
          FUN_005270f0();
          (**(code **)((int)fVar9 + 0x198))();
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
          uVar27 = CONCAT44(uVar4,in_ECX);
          uVar24 = 0x41;
          uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x41);
          uVar22 = 0;
          uVar19 = 0x41;
          (**(code **)((int)*in_ECX + 0x67c))(0x41,0,uVar4,uVar24,uVar27);
          iVar3 = FUN_004caa20(uVar19,uVar22,uVar4,uVar24);
          local_14 = (float *)(iVar3 + -100);
          FUN_00404560(&local_14);
          (**(code **)((int)*in_ECX + 0x694))(2);
          FUN_0040eb40();
        }
      }
    }
    break;
  case 0x25:
    fVar9 = in_ECX[0xcb9];
    if (fVar9 == 0.0) {
      if ((in_ECX[0xcba] != 0.0) && (*(char *)((int)in_ECX[0xcba] + 0x13a) != '\0')) {
        (**(code **)((int)*in_ECX + 0xfc))();
      }
      FUN_00b06f00();
      cVar2 = FUN_00a51fb0();
      if (cVar2 != '\0') {
        (**(code **)((int)*in_ECX + 0x1a0))();
      }
      if (((2 < *(int *)((int)in_ECX[0x41] + 0x124)) && (*(char *)((int)in_ECX + 0x331f) != '\0'))
         && ((*(char *)(in_ECX + 0xcc8) == '\0' && (in_ECX[0xcbf] != 0.0)))) {
        *(undefined1 *)(in_ECX + 0xcc8) = 1;
        (**(code **)((int)*in_ECX + 0xf8))(3,in_ECX[0xcbf],0,0,0,0,0,0,0);
      }
code_r0x00729de4:
      if (*(char *)(in_ECX + 0xcc7) != '\0') goto code_r0x00729dec;
    }
    else {
      if (fVar9 != 1.4013e-45) {
        if (fVar9 == 2.8026e-45) {
          if ((in_ECX[0xcbc] != 0.0) && (*(char *)((int)in_ECX[0xcbc] + 0x13a) != '\0')) {
            (**(code **)((int)*in_ECX + 0xfc))();
          }
        }
        else if (((fVar9 == 4.2039e-45) && (*(char *)((int)in_ECX + 0x331d) == '\0')) &&
                (2 < *(int *)((int)in_ECX[0x41] + 0x124))) {
          *(undefined1 *)((int)in_ECX + 0x331d) = 1;
          (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xcbd],0x87,10,0,0,0,0,0);
          FUN_00538900(8,500);
          (**(code **)((int)*in_ECX + 0x10c))(u_CCRASH_CRASH_00d7bdd0,0xffffffff,0,0);
          if ((*(char *)((int)in_ECX + 0x331e) != '\0') && (cVar2 = FUN_0049c090(), cVar2 != '\0'))
          {
            *(undefined1 *)((int)in_ECX + 0x331e) = 0;
            local_14 = (float *)0x0;
            (**(code **)((int)*in_ECX + 0x67c))();
            iVar3 = FUN_0054ff60();
            iVar10 = (**(code **)((int)*in_ECX + 0x64c))(0xe);
            if ((iVar10 < iVar3) || (iVar3 = (**(code **)((int)*in_ECX + 0x620))(), iVar3 != 3)) {
              uVar4 = 0xf;
              (**(code **)((int)*in_ECX + 0x67c))(0xf,1,0);
              iVar3 = FUN_0054ff60(uVar4);
              iVar10 = (**(code **)((int)*in_ECX + 0x64c))(0xf);
              pfVar15 = local_14;
              if ((iVar3 <= iVar10) &&
                 (iVar3 = (**(code **)((int)*in_ECX + 0x620))(), pfVar15 = local_14, iVar3 == 2)) {
                uVar24 = 0;
                uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0);
                uVar22 = 0xf;
                pfVar15 = in_ECX;
                uVar19 = (**(code **)((int)*in_ECX + 0x64c))(0xf);
                (**(code **)((int)*in_ECX + 0x67c))(0xf,4,uVar19);
                pfVar15 = (float *)FUN_004caa20(uVar19,uVar22,pfVar15,uVar4,uVar24);
              }
            }
            else {
              (**(code **)((int)*in_ECX + 0x1d0))();
              uVar24 = 0xe;
              pfVar15 = in_ECX;
              uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0xe);
              uVar22 = 2;
              uVar19 = 0xe;
              (**(code **)((int)*in_ECX + 0x67c))(0xe,2,uVar4);
              pfVar15 = (float *)FUN_004caa20(uVar19,uVar22,uVar4,uVar24,pfVar15);
            }
            (**(code **)((int)*in_ECX + 0x2b8))(0x4e3e,pfVar15,0,0,0x78,0,0,4,0,0,0,0,0);
          }
        }
        goto code_r0x00729de4;
      }
      if (*(char *)(in_ECX + 0xcc7) == '\0') {
        if (0 < *(int *)((int)in_ECX[0x41] + 0x124)) {
          *(undefined1 *)(in_ECX + 0xcc7) = 1;
          (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xcbb],0,0,0,0,0,0,0);
        }
        goto code_r0x00729de4;
      }
code_r0x00729dec:
      if ((in_ECX[0xcbb] != 0.0) && (*(char *)((int)in_ECX[0xcbb] + 0x13a) != '\0')) {
        (**(code **)((int)*in_ECX + 0xfc))();
      }
    }
    if (((*(char *)((int)in_ECX + 0x331d) != '\0') && (in_ECX[0xcbd] != 0.0)) &&
       (*(char *)((int)in_ECX[0xcbd] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0xfc))();
    }
    local_20 = (float *)((int)in_ECX + 0x331f);
    pfVar15 = in_ECX + 0xcbe;
    local_14 = (float *)0x2;
    do {
      if (((*(char *)local_20 != '\0') && (*pfVar15 != 0.0)) &&
         (*(char *)((int)*pfVar15 + 0x13a) != '\0')) {
        *(char *)local_20 = '\0';
        (**(code **)((int)*in_ECX + 0xfc))();
      }
      pfVar15 = pfVar15 + 1;
      local_20 = (float *)((int)local_20 + 1);
      local_14 = (float *)((int)local_14 + -1);
    } while (local_14 != (float *)0x0);
    local_14 = (float *)0x0;
    break;
  case 0x26:
    cVar2 = FUN_00498e40();
    if (((cVar2 != '\0') && (in_ECX[0xcf4] != -NAN)) &&
       (iVar3 = FUN_00b06f00(), (int)in_ECX[0xcf4] <= iVar3)) {
      FUN_00a28110();
    }
    iVar3 = *(int *)((int)in_ECX[0x41] + 0x124);
    if ((*(char *)((int)in_ECX + 0x33dd) == '\0') && (0 < iVar3)) {
      (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xcf6],0,0,0,0,0,0,0);
      *(undefined1 *)((int)in_ECX + 0x33dd) = 1;
    }
    if (3 < iVar3) {
      if (*(char *)((int)in_ECX + 0x33df) == '\0') {
        (**(code **)((int)*in_ECX + 0x10c))(u_GHOST_BALL_00d7bae0,0xffffffff,0);
        (**(code **)((int)*in_ECX + 0x10c))(u_SM_RETURN_DISK_00d7bac0,0xffffffff,0,0);
        *(undefined1 *)((int)in_ECX + 0x33df) = 1;
      }
      cVar2 = FUN_0049c090();
      if ((cVar2 != '\0') && (*(char *)((int)in_ECX + 0x33de) == '\0')) {
        (**(code **)((int)*in_ECX + 0x67c))();
        local_2c = (int *)(**(code **)((int)*in_ECX + 0x64c))(2);
        local_24 = (int *)(**(code **)((int)*in_ECX + 0x2c0))();
        uVar24 = 0;
        uVar22 = 0xc;
        uVar19 = 0xffffffff;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
        iVar3 = FUN_00550080(0,local_2c,in_ECX,uVar4,uVar19,uVar22,uVar24);
        *(int *)((int)local_24 + 0x59) = iVar3 + 300;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
        iVar3 = FUN_004caa20(1,local_2c,in_ECX,uVar4);
        local_14 = (float *)(iVar3 + -100);
        local_34 = (float *)FUN_0054ff60(2,0);
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
        local_28 = (float *)FUN_004caa20(2,local_2c,in_ECX,uVar4);
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
        iVar3 = FUN_004caa20(7,local_2c,in_ECX,uVar4);
        local_30 = (float *)(iVar3 + -100);
        iVar3 = FUN_0071b8d0();
        local_20 = (float *)(iVar3 + -1);
        if (0 < (int)local_20) {
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
          iVar3 = FUN_004caa20(3,local_2c,in_ECX,uVar4);
          uVar24 = 0;
          local_14 = (float *)((int)local_14 + iVar3 * (int)local_20);
          uVar22 = 0xc;
          uVar19 = 0xffffffff;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          iVar3 = FUN_00550080(4,local_2c,in_ECX,uVar4,uVar19,uVar22,uVar24);
          uVar24 = 0;
          uVar22 = 0xc;
          *(int *)((int)local_24 + 0x59) = *(int *)((int)local_24 + 0x59) + iVar3 * (int)local_20;
          uVar19 = 0xffffffff;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          iVar3 = FUN_00550080(5,local_2c,in_ECX,uVar4,uVar19,uVar22,uVar24);
          uVar24 = 0;
          local_34 = (float *)((int)local_34 + iVar3 * (int)local_20);
          uVar22 = 0xc;
          uVar19 = 0xffffffff;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xffffffff,0xc,0,0);
          iVar3 = FUN_00550080(6,local_2c,in_ECX,uVar4,uVar19,uVar22,uVar24);
          local_28 = (float *)((int)local_28 + iVar3 * (int)local_20);
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
          iVar3 = FUN_004caa20(8,local_2c,in_ECX,uVar4);
          local_30 = (float *)((int)local_30 + iVar3 * (int)local_20);
        }
        DAT_00f5478c = 0;
        uVar4 = FUN_0054ff60(1,in_ECX);
        FUN_004e2780(uVar4);
        FUN_004e2780(local_28);
        FUN_004e2780(local_34);
        FUN_004e2780(local_30);
        iVar3 = FUN_0054ff60(3,in_ECX);
        FUN_004e2780((iVar3 * (int)local_28) / 1000);
        fVar9 = *in_ECX;
        uVar4 = (**(code **)((int)fVar9 + 0xc0))(0,DAT_00f5478c,DAT_00f54788,0,0);
        (**(code **)((int)fVar9 + 0x2b8))(0x4e40,local_14,local_24,0,0x96,0,0x44,uVar4);
        *(undefined1 *)((int)in_ECX + 0x33de) = 1;
      }
    }
    local_14 = in_ECX + 0xcf5;
    iVar3 = 0;
    do {
      if (((*(char *)(iVar3 + 0x33dc + (int)in_ECX) != '\0') && (*local_14 != 0.0)) &&
         (*(char *)((int)*local_14 + 0x13a) != '\0')) {
        (**(code **)((int)*in_ECX + 0xfc))();
      }
      iVar3 = iVar3 + 1;
      local_14 = local_14 + 1;
    } while (iVar3 < 2);
    break;
  case 0x28:
    if (in_ECX[0xb5c] == 1.4013e-45) {
      if ((in_ECX[0xb62] == 0.0) && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xb60],0,0,0,0,1,0,0);
        in_ECX[0xb62] = 1.4013e-45;
      }
      if ((in_ECX[0xb62] == 1.4013e-45) && (5 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xb61],0,0,0,0,1,0,0);
        fVar9 = *in_ECX;
        uVar4 = FUN_005270f0(0x30);
        (**(code **)((int)fVar9 + 0x198))(uVar4);
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
        uVar25 = 0x49;
        pfVar15 = in_ECX;
        uVar19 = (**(code **)((int)*in_ECX + 0x64c))(0x49);
        uVar24 = 0;
        uVar22 = 0x49;
        (**(code **)((int)*in_ECX + 0x67c))(0x49,0,uVar19);
        iVar3 = FUN_004caa20(uVar22,uVar24,uVar19,uVar25,pfVar15);
        local_14 = (float *)(iVar3 + -100);
        FUN_00404560(&local_14);
        cVar2 = FUN_0049c090(uVar4);
        if (cVar2 != '\0') {
          (**(code **)((int)*in_ECX + 0x67c))(0x49);
          local_14 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x49);
          local_20 = (float *)(**(code **)((int)*in_ECX + 0x2c0))
                                        (u_Particle_IllusionSlash_ptl_00d5458c);
          uVar22 = 100;
          fVar9 = in_ECX[0xb63];
          uVar4 = FUN_0054ff60(0xe,in_ECX);
          uVar19 = FUN_0054ff60(0xd,in_ECX);
          uVar4 = FUN_00473f20(uVar19,uVar4,fVar9,uVar22);
          *(undefined4 *)((int)local_20 + 0x59) = uVar4;
          iVar3 = (**(code **)((int)*in_ECX + 0x644))(1);
          if (iVar3 == 2) {
            iVar3 = FUN_0054ff60(0xf,in_ECX);
            local_20[0x13] = (float)-iVar3;
          }
          else {
            iVar3 = (**(code **)((int)*in_ECX + 0x644))(1);
            if (iVar3 == 3) {
              fVar9 = (float)FUN_0054ff60(0xf,in_ECX);
              local_20[0x13] = fVar9;
            }
            else {
              local_20[0x13] = 0.0;
            }
          }
          uVar19 = 0xc;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc,in_ECX[0xb63],100);
          uVar4 = FUN_004caa20(2,local_14,in_ECX,uVar4,uVar19);
          uVar19 = 0xc;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc,uVar4);
          uVar4 = FUN_004caa20(1,local_14,in_ECX,uVar4,uVar19);
          iVar3 = FUN_00473f20(uVar4);
          fVar9 = in_ECX[0xb63];
          uVar22 = 100;
          local_14 = (float *)(iVar3 + -100);
          uVar4 = FUN_0054ff60(0x11,in_ECX);
          uVar19 = FUN_0054ff60(0x10,in_ECX);
          uVar4 = FUN_00473f20(uVar19,uVar4,fVar9,uVar22);
          DAT_00f5478c = 0;
          uVar19 = (**(code **)((int)*in_ECX + 0x644))(1);
          FUN_005b3550(uVar19);
          FUN_005b3550(uVar4);
          (**(code **)((int)*in_ECX + 0x2b8))
                    (0x4e45,local_14,local_20,0,0x41,0,0,4,0,DAT_00f5478c,DAT_00f54788,0,0);
        }
        (**(code **)((int)*in_ECX + 0x10c))(u_SM_HOANYOUNG_FIN_00d7bd38,0xffffffff,0,0);
        in_ECX[0xb62] = 2.8026e-45;
      }
    }
    break;
  case 0x29:
    if ((*(char *)(in_ECX + 0xc07) == '\0') && (5 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        local_20 = (float *)0x0;
        iVar3 = FUN_00404380();
        if (0 < iVar3) {
          do {
            uVar29 = 0xf6a074;
            uVar27 = 0xf4287c00000000;
            uVar4 = FUN_00405400(local_20);
            piVar8 = (int *)FUN_00c00d0b(uVar4,uVar27,uVar29);
            if ((piVar8 != (int *)0x0) && (iVar3 = (**(code **)(*piVar8 + 0x18c))(), iVar3 != 0)) {
              (**(code **)(*piVar8 + 0x28c))(4,0,0,0);
            }
            local_20 = (float *)((int)local_20 + 1);
            iVar3 = FUN_00404380();
          } while ((int)local_20 < iVar3);
        }
      }
      (**(code **)((int)*in_ECX + 0x110))();
      *(undefined1 *)(in_ECX + 0xc07) = 1;
    }
    break;
  case 0x2a:
    if ((((in_ECX[0xcc9] == 0.0) && (*(char *)(in_ECX + 0xccd) != '\0')) && (in_ECX[0xcca] != 0.0))
       && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      *(undefined1 *)(in_ECX + 0xccd) = 0;
      (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xcca],0,0,0,0,1,0,0);
    }
    break;
  case 0x2b:
    if ((in_ECX[0xb64] == 0.0) && (FUN_0071ccb0(), 8 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      FUN_00b06f00();
      cVar2 = FUN_00a51fb0();
      if (cVar2 != '\0') {
        local_34 = (float *)in_ECX[0xb78];
        pfVar15 = (float *)*local_34;
        local_28 = pfVar15;
        cVar2 = FUN_00564560();
        while (cVar2 != '\0') {
          local_24 = (int *)in_ECX[0xb70];
          iVar3 = FUN_00b06f00();
          if ((int)pfVar15[3] + (int)local_24 <= iVar3) {
            local_24 = (int *)pfVar15[2];
            FUN_004ee6d0(&local_14,local_3c + 6);
            local_24 = (int *)in_ECX[0x108];
            cVar2 = FUN_00564560();
            if (cVar2 != '\0') {
              FUN_00564580(&local_18,local_14);
            }
            fVar9 = (float)FUN_00b06f00();
            pfVar15[3] = fVar9;
          }
          local_34 = (float *)in_ECX[0xb78];
          pfVar15 = (float *)*pfVar15;
          local_28 = pfVar15;
          cVar2 = FUN_00564560();
        }
      }
      FUN_00b06f00();
      cVar2 = FUN_00a51fb0();
      if (cVar2 != '\0') {
        local_34 = (float *)in_ECX[0x108];
        pfVar15 = (float *)*local_34;
        local_20 = pfVar15;
        cVar2 = FUN_00564560();
        while (cVar2 != '\0') {
          cVar2 = (**(code **)(*(int *)pfVar15[2] + 0x2c))();
          if (cVar2 == '\0') {
code_r0x00728bf6:
            puVar7 = (undefined4 *)FUN_00564580(auStack_498,pfVar15);
            pfVar15 = (float *)*puVar7;
          }
          else {
            local_24 = (int *)pfVar15[2];
            local_14 = (float *)in_ECX[0xb78];
            FUN_004ee6d0();
            cVar2 = FUN_00564560();
            if (cVar2 == '\0') goto code_r0x00728bf6;
            pfVar15 = (float *)*pfVar15;
          }
          local_34 = (float *)in_ECX[0x108];
          local_20 = pfVar15;
          cVar2 = FUN_00564560();
        }
      }
    }
    break;
  case 0x2c:
    fVar9 = in_ECX[0xb8e];
    if ((fVar9 == 0.0) || (fVar9 == 1.4013e-45)) {
      iStack_1c = 3;
      local_18 = 2.8026e-45;
      if ((*(char *)(in_ECX + 0xb8f) == '\0') &&
         ((&iStack_1c)[(int)fVar9] <= *(int *)((int)in_ECX[0x41] + 0x124))) {
        cVar2 = FUN_0049c090();
        if (cVar2 != '\0') {
          (**(code **)((int)*in_ECX + 0x67c))();
          local_20 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x52);
          uVar19 = 0;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
          local_24 = (int *)FUN_004caa20(1,local_20,in_ECX,uVar4,uVar19);
          DAT_00f5478c = 0;
          FUN_00550080(5,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_005b3550();
          FUN_00550080(6,local_20,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
          FUN_004e2780();
          uVar19 = 0;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
          FUN_004caa20(7,local_20,in_ECX,uVar4,uVar19);
          FUN_005b8030();
          fVar9 = in_ECX[0xb8e];
          local_14 = (float *)((fVar9 != 0.0) - 1 & 0x35);
          uVar4 = (**(code **)((int)*in_ECX + 0x2c0))();
          (**(code **)((int)*in_ECX + 0x2b8))
                    ((in_ECX[0xb8e] != 0.0) + 0x4e4d,local_24,uVar4,0,
                     (-(uint)(fVar9 != 0.0) & 0xffffffe3) + 0x6e,0,local_14,4,0,DAT_00f5478c,
                     DAT_00f54788,0,0);
        }
        *(undefined1 *)(in_ECX + 0xb8f) = 1;
      }
    }
    else if (fVar9 == 2.8026e-45) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_2c = (int *)(**(code **)((int)*in_ECX + 0x67c))();
        local_34 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x52);
        fVar9 = (float)(**(code **)((int)*in_ECX + 0x38c))();
        if (in_ECX[0x41] == fVar9) {
          fVar9 = *in_ECX;
          uVar4 = (**(code **)((int)fVar9 + 0x38c))();
          (**(code **)((int)fVar9 + 0xf0))(uVar4);
          FUN_00a27360();
          fVar9 = *in_ECX;
          uVar4 = FUN_005270f0(0x3a);
          (**(code **)((int)fVar9 + 0x198))(uVar4);
          uVar19 = 0xc;
          uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
          iVar3 = FUN_004caa20(2,local_34,in_ECX,uVar4,uVar19);
          local_14 = (float *)(iVar3 + -100);
          FUN_00404560(&local_14);
          (**(code **)((int)*in_ECX + 0x10c))(u_KALA_ATK_12_00d7bd20,0xffffffff,0,0);
          iVar3 = 0;
          do {
            (**(code **)((int)*in_ECX + 0xfc))();
            iVar10 = iVar3;
            if (iVar3 == 0) {
              iVar10 = -1;
            }
            (**(code **)((int)*in_ECX + 0xf8))(iVar10,in_ECX[iVar3 + 0xb97],0,0,0,0,1 < iVar3,0,0,1)
            ;
            iVar3 = iVar3 + 1;
          } while (iVar3 < 4);
        }
        else {
          fVar9 = (float)(**(code **)((int)*in_ECX + 0x38c))(0x47);
          if (in_ECX[0x41] == fVar9) {
            fVar9 = *in_ECX;
            uVar4 = (**(code **)((int)fVar9 + 0x38c))();
            (**(code **)((int)fVar9 + 0xf0))(uVar4);
            FUN_00a27360();
            fVar9 = *in_ECX;
            uVar4 = FUN_005270f0(0x3b);
            (**(code **)((int)fVar9 + 0x198))(uVar4);
            uVar19 = 0xc;
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
            iVar3 = FUN_004caa20(3,local_34,in_ECX,uVar4,uVar19);
            local_14 = (float *)(iVar3 + -100);
            FUN_00404560(&local_14);
            (**(code **)((int)*in_ECX + 0x10c))(u_KALA_ATK_12_00d7bd20,0xffffffff,0,0);
            local_14 = (float *)0x2;
            do {
              (**(code **)((int)*in_ECX + 0xfc))();
              local_14 = (float *)((int)local_14 + -1);
            } while (local_14 != (float *)0x0);
            iVar3 = 0;
            local_14 = (float *)0x0;
            do {
              iVar10 = iVar3;
              if (iVar3 == 0) {
                iVar10 = -1;
              }
              (**(code **)((int)*in_ECX + 0xf8))(iVar10,in_ECX[iVar3 + 0xb9d],0,0,0,0,1 < iVar3,0,0)
              ;
              iVar3 = iVar3 + 1;
            } while (iVar3 < 4);
          }
          else {
            fVar9 = (float)(**(code **)((int)*in_ECX + 0x38c))(0x48);
            if (in_ECX[0x41] != fVar9) goto code_r0x00729006;
            fVar9 = *in_ECX;
            uVar4 = (**(code **)((int)fVar9 + 0x38c))();
            (**(code **)((int)fVar9 + 0xf0))(uVar4);
            FUN_00a27360();
            fVar9 = *in_ECX;
            FUN_005270f0();
            (**(code **)((int)fVar9 + 0x198))();
            uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0xc);
            iVar3 = FUN_004caa20(4,local_34,in_ECX,uVar4);
            local_14 = (float *)(iVar3 + -100);
            FUN_00404560(&local_14);
            (**(code **)((int)*in_ECX + 0x10c))(u_KALA_ATK_3_00d7bd08,0xffffffff,0,0);
            local_14 = (float *)0x2;
            do {
              (**(code **)((int)*in_ECX + 0xfc))();
              local_14 = (float *)((int)local_14 + -1);
            } while (local_14 != (float *)0x0);
            local_34 = in_ECX + 0xba3;
            iVar3 = 0;
            local_14 = (float *)0x0;
            do {
              uVar14 = (uint3)((uint)local_34 >> 8);
              if ((iVar3 == 0) || (iVar3 == 2)) {
                iVar10 = (uint)uVar14 << 8;
              }
              else {
                iVar10 = CONCAT31(uVar14,1);
              }
              iVar6 = iVar3 + -3;
              if (2 < iVar3) {
                iVar6 = iVar3 + -2;
              }
              (**(code **)((int)*in_ECX + 0xf8))(iVar6,*local_34,0,0,0,0,iVar10,0,0);
              iVar3 = iVar3 + 1;
              local_34 = local_34 + 1;
            } while (iVar3 < 6);
          }
        }
        cVar2 = FUN_0049c090();
        if (cVar2 != '\0') {
          uVar4 = 0;
          local_34 = (float *)0x0;
          local_14 = (float *)(**(code **)((int)*in_ECX + 0x644))();
          if (local_14 == (float *)&DAT_00000004) {
            uVar4 = FUN_0054ff60();
code_r0x00728f9c:
            local_34 = (float *)FUN_0054ff60();
          }
          else {
            pfVar15 = (float *)(**(code **)((int)*in_ECX + 0xc0))();
            if (local_14 == pfVar15) {
              uVar4 = FUN_0054ff60();
              goto code_r0x00728f9c;
            }
          }
          (**(code **)((int)*in_ECX + 0x488))(0,uVar4,uVar4,0,local_34,1);
          (**(code **)((int)*in_ECX + 0x488))(1,0,0,0,0,0);
          (**(code **)((int)*in_ECX + 0x494))(4,4,1000,1000,0x3f800000,0x3f800000);
          fVar9 = *in_ECX;
          uVar4 = (**(code **)((int)fVar9 + 0xc0))(4,0);
          (**(code **)((int)fVar9 + 0x49c))(uVar4);
        }
      }
code_r0x00729006:
      if (*(char *)(in_ECX + 0xbaf) == '\0') {
        fVar9 = in_ECX[0x41];
        fVar12 = (float)(**(code **)((int)*in_ECX + 0x38c))();
        if ((fVar9 == fVar12) && (1 < *(int *)((int)fVar9 + 0x124))) {
          local_18 = (float)FUN_00403c50();
          local_8 = 0x10;
          if (local_18 == 0.0) {
            uVar4 = 0;
          }
          else {
            FUN_004334b0(u_Effect_animation_Kalla_Exp1_ani_00d7bcc8);
            uVar4 = FUN_00472a60();
          }
          local_8 = 0xffffffff;
          local_18 = (float)FUN_00403c50();
          local_8 = 0x11;
          if (local_18 == 0.0) {
            pfVar15 = (float *)0x0;
          }
          else {
            pfVar15 = (float *)FUN_004abd20(uVar4,1);
          }
          local_8 = 0xffffffff;
          local_20 = (float *)0x1;
          local_14 = (float *)0x3;
          local_34 = pfVar15;
          do {
            local_24 = (int *)FUN_00403c50();
            local_8 = 0x12;
            if (local_24 == (int *)0x0) {
              uVar4 = 0;
            }
            else {
              uVar4 = FUN_00a52aa0(0,u_Effect_Animation_Kalla_Exp_d_ani_00d7bc80,
                                   (char *)((int)local_20 + 1));
              FUN_004334b0(uVar4);
              uVar4 = FUN_00472a60();
            }
            local_8 = 0xffffffff;
            (**(code **)((int)*pfVar15 + 0xf8))(local_20,uVar4,0,0,0,0,1,1,0);
            local_20 = (float *)((int)local_20 + 1);
            local_14 = (float *)((int)local_14 + -1);
          } while (local_14 != (float *)0x0);
          FUN_0050dd70(in_ECX,2,0,pfVar15,in_ECX,0,0);
          iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
          if (iVar3 == 0) {
            iVar3 = (**(code **)((int)*in_ECX + 0x94))();
            local_14 = (float *)(iVar3 + -0x59);
          }
          else {
            iVar3 = (**(code **)((int)*in_ECX + 0x94))();
            local_14 = (float *)(iVar3 + 0x59);
          }
          local_24 = (int *)*pfVar15;
          iVar3 = (**(code **)((int)*in_ECX + 0x9c))();
          iVar3 = iVar3 + 0x60;
          uVar4 = (**(code **)((int)*in_ECX + 0x98))();
          pfVar15 = local_34;
          uVar27 = CONCAT44(iVar3,uVar4);
          pfVar28 = local_14;
          (*(code *)local_24[0x22])();
          fVar9 = *pfVar15;
          uVar4 = (**(code **)((int)*in_ECX + 0xc0))();
          (**(code **)((int)fVar9 + 0xbc))(uVar4,pfVar28,uVar27);
          *(undefined1 *)(in_ECX + 0xbaf) = 1;
        }
      }
    }
    break;
  case 0x2d:
    if (in_ECX[0xb1b] == 1.4013e-45) {
      iVar3 = FUN_004caa00();
      if (*(char *)(in_ECX + 0xb1f) == '\0') {
        local_24 = (int *)FUN_00a24ce0();
        if (iVar3 < (int)local_24) {
          local_14 = (float *)FUN_00473f20(0,in_ECX[0xb1d],iVar3);
          (**(code **)((int)*in_ECX + 0xc0))();
          (**(code **)((int)*in_ECX + 0x94))();
          FUN_004e7f10();
          (**(code **)((int)*in_ECX + 0x84))(0);
          iVar10 = (int)local_24 / 2;
          bVar16 = iVar10 <= iVar3;
          if (bVar16) {
            fVar12 = in_ECX[0xb1e];
            iVar3 = iVar3 - iVar10;
            fVar9 = 0.0;
          }
          else {
            fVar9 = in_ECX[0xb1e];
            fVar12 = 0.0;
          }
          uVar4 = FUN_004caa50(fVar12,fVar9,iVar3,(ulonglong)CONCAT14(!bVar16,iVar10));
          (**(code **)((int)*in_ECX + 0x84))(2,uVar4);
        }
        else {
          (**(code **)((int)*in_ECX + 0x10c))(u_OUTRAGE_SWING_00d7bdec,0xffffffff,0);
          (**(code **)((int)*in_ECX + 0x10c))(u_CCRASH_CRASH_00d7bdd0,0xffffffff,0,0);
          (**(code **)((int)*in_ECX + 0x84))(2,0);
          *(undefined1 *)(in_ECX + 0xb1f) = 1;
          FUN_00538900(5,300);
          (**(code **)((int)*in_ECX + 0xf8))(3,in_ECX[0xb24],0,0,0,0,0,0,0,1);
          (**(code **)((int)*in_ECX + 0xf8))(4,in_ECX[0xb25],0,0,0,0,0,0,0,1);
          (**(code **)((int)*in_ECX + 0xf8))(6,in_ECX[0xb26],0x79,10,0,0,0,0,0,1);
          if (in_ECX[0xb28] == 0.0) {
            local_18 = (float)FUN_00403c50(0x1b4);
            local_8 = 0xe;
            if (local_18 == 0.0) {
              fVar9 = 0.0;
            }
            else {
              pwVar18 = u_effect_particle_outragebreak_sto_00d7bd78;
              pfVar15 = in_ECX;
              uVar4 = FUN_004334b0(u_effect_particle_outragebreak_sto_00d7bd78);
              fVar9 = (float)FUN_004a3440(uVar4,pwVar18,pfVar15);
            }
            local_8 = 0xffffffff;
            in_ECX[0xb28] = fVar9;
          }
          iVar3 = *(int *)in_ECX[0xb28];
          uVar4 = (**(code **)((int)*in_ECX + 0xc0))();
          (**(code **)(iVar3 + 0x68))(uVar4);
          (**(code **)(*(int *)in_ECX[0xb28] + 0xc))(0);
          if ((*(char *)(in_ECX + 0xb27) == '\0') && (4 < *(int *)((int)in_ECX[0x41] + 0x124))) {
            cVar2 = FUN_0049c090();
            if (cVar2 != '\0') {
              (**(code **)((int)*in_ECX + 0x67c))();
              local_14 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x51);
              uVar19 = 0;
              uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
              local_24 = (int *)FUN_004caa20(1,local_14,in_ECX,uVar4,uVar19);
              DAT_00f5478c = 0;
              uVar19 = 0;
              uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
              FUN_004caa20(2,local_14,in_ECX,uVar4,uVar19);
              FUN_005b8030();
              FUN_0054ff60(3,in_ECX);
              FUN_005b3550();
              fVar9 = *in_ECX;
              uVar4 = (**(code **)((int)fVar9 + 0xc0))(0,DAT_00f5478c,DAT_00f54788,0,0);
              (**(code **)((int)fVar9 + 0x2b8))(0x4e4b,local_24,0,0,0x96,0,0,uVar4);
            }
            *(undefined1 *)(in_ECX + 0xb27) = 1;
          }
        }
      }
      else {
        if (4 < *(int *)((int)in_ECX[0x41] + 0x124)) {
          iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
          if (iVar3 == 0) {
            iVar3 = (**(code **)((int)*in_ECX + 0x94))();
            local_14 = (float *)(iVar3 + -0x96);
          }
          else {
            iVar3 = (**(code **)((int)*in_ECX + 0x94))();
            local_14 = (float *)(iVar3 + 0x96);
          }
          iVar3 = *(int *)in_ECX[0xb28];
          uVar4 = (**(code **)((int)*in_ECX + 0x9c))();
          uVar19 = (**(code **)((int)*in_ECX + 0x98))();
          uVar27 = CONCAT44(uVar4,uVar19);
          pfVar15 = local_14;
          (**(code **)(iVar3 + 0x28))();
          (**(code **)(*(int *)in_ECX[0xb28] + 0x5c))(auStack_4d8,pfVar15,uVar27);
          local_8 = 0xf;
          FUN_0050e060(in_ECX,2,0,auStack_4d8,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
        if (4 < *(int *)((int)in_ECX[0xb24] + 0x124)) {
          (**(code **)((int)*in_ECX + 0xfc))();
          (**(code **)((int)*in_ECX + 0xfc))(in_ECX[0xb25]);
        }
      }
    }
    break;
  case 0x2e:
    if ((*(char *)(in_ECX + 0xc3a) == '\0') && (2 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      cVar2 = FUN_0049c090();
      if ((cVar2 != '\0') && (in_ECX[0xc35] != 0.0)) {
        (**(code **)((int)*in_ECX + 0x67c))();
        local_28 = (float *)(**(code **)((int)*in_ECX + 0x64c))(0x55);
        local_18 = (float)FUN_008ac050();
        uVar4 = *(undefined4 *)((int)in_ECX[0xc35] + 0x80);
        uVar19 = FUN_0073d710();
        uVar27 = CONCAT44(uVar4,uVar19);
        uVar4 = FUN_0054ff60(0xe,in_ECX);
        uVar19 = FUN_0054ff60(0xd,in_ECX);
        local_14 = (float *)FUN_00473f20(uVar19,uVar4,uVar27);
        uVar4 = FUN_0073d710();
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0,uVar4);
        uVar4 = FUN_004caa20(3,local_28,in_ECX,uVar4,uVar19);
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0,uVar4);
        uVar4 = FUN_004caa20(2,local_28,in_ECX,uVar4,uVar19);
        local_24 = (int *)FUN_00473f20(uVar4);
        uVar4 = FUN_0073d710();
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0,uVar4);
        uVar4 = FUN_004caa20(5,local_28,in_ECX,uVar4,uVar19);
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))(0,uVar4);
        uVar4 = FUN_004caa20(4,local_28,in_ECX,uVar4,uVar19);
        FUN_00473f20(uVar4);
        DAT_00f5478c = 0;
        FUN_005b8030();
        FUN_0054ff60(0xf,in_ECX);
        FUN_005b8030();
        FUN_0054ff60(0x10,in_ECX);
        FUN_005b3550();
        FUN_005b3550();
        FUN_0054ff60(0x11,in_ECX);
        FUN_004e2780();
        (**(code **)((int)*in_ECX + 0x2b8))
                  (0x4e54,local_24,0,0,local_18,0,0,4,0,DAT_00f5478c,DAT_00f54788,0,0);
      }
      (**(code **)((int)*in_ECX + 0x494))(0,0,1000,1000,0x3f800000);
      *(undefined1 *)(in_ECX + 0xc3a) = 1;
    }
    break;
  case 0x2f:
    if (10 < *(int *)((int)in_ECX[0x41] + 0x124)) {
      FUN_00725640();
    }
    if (3 < *(int *)((int)in_ECX[0x41] + 0x124)) {
      FUN_00725640();
    }
    if ((*(char *)(in_ECX + 0xc5b) == '\0') && (0x11 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        uVar29 = CONCAT44(uVar19,uVar4);
        uVar27 = CONCAT44(in_ECX,0x56);
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x56);
        uVar22 = 0;
        uVar19 = 0x56;
        (**(code **)((int)*in_ECX + 0x67c))(0x56,0,uVar4,uVar27,uVar29);
        FUN_004caa20(uVar19,uVar22,uVar4,uVar27);
        uVar19 = 0;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        uVar27 = CONCAT44(uVar19,uVar4);
        pfVar15 = in_ECX;
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x56);
        (**(code **)((int)*in_ECX + 0x67c))(0x56,1,uVar4);
        FUN_004caa20(pfVar15,uVar27,uVar29);
        DAT_00f5478c = 0;
        FUN_005b8030();
        FUN_004e9ea0();
      }
      *(undefined1 *)(in_ECX + 0xc5b) = 1;
    }
    local_24 = (int *)in_ECX[0xc3c];
    local_14 = (float *)in_ECX[0xc3d];
    if (0x15 < *(int *)((int)in_ECX[0x41] + 0x124)) {
      local_30 = (float *)0x0;
      local_34 = (float *)0x0;
      local_20 = (float *)0x0;
      FUN_0071bbb0(local_3c + 3,local_3c + 2,&local_20,0);
      local_2c = (int *)in_ECX[0x41];
      local_28 = (float *)FUN_00a24ce0();
      iVar3 = FUN_004caa00();
      local_18 = (float)(iVar3 - (int)local_28);
      iVar3 = FUN_00a24ce0();
      iVar10 = FUN_00a24bb0();
      fVar9 = local_18;
      local_28 = (float *)(iVar10 - iVar3);
      local_24 = (int *)FUN_00473f20(local_24,local_30,local_18);
      local_14 = (float *)FUN_00473f20(local_14,local_34,fVar9,local_28);
      FUN_00473f20(0,(char *)((int)local_20 + -0x32),fVar9,local_28);
    }
    (**(code **)((int)*in_ECX + 0x88))();
    break;
  case 0x31:
    if ((*(char *)(in_ECX + 0xc8e) == '\0') && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      (**(code **)((int)*in_ECX + 0xf8))(1,in_ECX[0xc87],0,0,0,0,1,0,0);
      (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xc88],0,0,0,0,1,0,0,1);
      (**(code **)((int)*in_ECX + 0xf8))(3,in_ECX[0xc89],0,0,0,1,1,0,0,1);
      if (0 < DAT_010c0774) {
        local_14 = in_ECX + 0xc8a;
        iVar3 = 0;
        do {
          (**(code **)((int)*in_ECX + 0xf8))(iVar3 + 2,*local_14,0,0,0,0,1,0,0,1);
          iVar3 = iVar3 + 1;
          local_14 = local_14 + 1;
        } while (iVar3 < 4);
      }
      (**(code **)(*(int *)in_ECX[0xc8f] + 0xc))(0);
      iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
      if (iVar3 == 0) {
        iVar3 = (**(code **)((int)*in_ECX + 0x94))();
        local_14 = (float *)(iVar3 + -0xb4);
      }
      else {
        iVar3 = (**(code **)((int)*in_ECX + 0x94))();
        local_14 = (float *)(iVar3 + 0xb4);
      }
      iVar3 = *(int *)in_ECX[0xc8f];
      uVar4 = (**(code **)((int)*in_ECX + 0x98))(0x14);
      (**(code **)(iVar3 + 0x28))(local_14,uVar4);
      (**(code **)(*(int *)in_ECX[0xc8f] + 0x5c))(auStack_4e8);
      local_8 = 0x1b;
      FUN_0050e060(in_ECX,2,0,auStack_4e8,0);
      (**(code **)((int)*in_ECX + 0x9c))(0x140,100,0x5a,0,0x32,0x96,0xffffffff,2,6);
      FUN_005db2e0();
      local_28 = in_ECX + 0xc90;
      piVar8 = &DAT_00d79a10;
      do {
        FUN_007437a0();
        iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
        if (iVar3 == 0) {
          iVar3 = (**(code **)((int)*in_ECX + 0x94))();
          local_14 = (float *)(iVar3 - *piVar8);
        }
        else {
          iVar3 = (**(code **)((int)*in_ECX + 0x94))();
          local_14 = (float *)(iVar3 + *piVar8);
        }
        local_18 = (float)(**(code **)((int)*in_ECX + 0x98))();
        iVar3 = (**(code **)((int)*in_ECX + 0x9c))();
        (**(code **)(*(int *)*local_28 + 0xc))(local_14,local_18,iVar3 + piVar8[1]);
        local_28 = local_28 + 1;
        piVar8 = piVar8 + 2;
      } while ((int)piVar8 < 0xd79a48);
      *(undefined1 *)(in_ECX + 0xc8e) = 1;
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
    break;
  case 0x34:
    if ((*(char *)(in_ECX + 0xc9d) == '\0') && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      cVar2 = FUN_0049c090();
      if (cVar2 != '\0') {
        iVar3 = (**(code **)((int)*in_ECX + 0xc0))();
        if (iVar3 == 0) {
          iVar3 = FUN_008ac050();
          iStack_44 = (**(code **)((int)*in_ECX + 0x94))();
          iStack_44 = iStack_44 - iVar3;
        }
        else {
          iVar3 = FUN_008ac050();
          iStack_44 = (**(code **)((int)*in_ECX + 0x94))();
          iStack_44 = iVar3 + iStack_44;
        }
        iVar3 = FUN_008ac050();
        iStack_68 = (**(code **)((int)*in_ECX + 0x98))();
        iStack_68 = iStack_68 - iVar3 / 2;
        uVar19 = 0xc;
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        uVar29 = CONCAT44(uVar19,uVar4);
        uVar27 = CONCAT44(in_ECX,0x58);
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x58);
        uVar22 = 5;
        uVar19 = 0x58;
        (**(code **)((int)*in_ECX + 0x67c))(0x58,5,uVar4,uVar27,uVar29);
        FUN_004caa20(uVar19,uVar22,uVar4,uVar27);
        DAT_00f5478c = 0;
        FUN_008ae0f0();
        FUN_005b3550();
        FUN_005b3550();
        FUN_008ac050();
        FUN_005b3550();
        FUN_004e2780();
        FUN_004e2780();
        uStack_10c = 100;
        FUN_00620d20(&iStack_44,&iStack_68,&uStack_10c);
        FUN_004e2780();
        (**(code **)((int)*in_ECX + 0xc0))(0,DAT_00f5478c,DAT_00f54788,0,0);
        FUN_004e9ea0();
      }
      *(undefined1 *)(in_ECX + 0xc9d) = 1;
    }
  }
  cVar2 = FUN_0049c090();
  if ((cVar2 == '\0') || (in_ECX[0x6c] == 2.8026e-45)) goto LAB_0073026f;
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) ||
     ((iVar3 = FUN_00402060(), iVar3 == 0xb || (iVar3 = FUN_00402060(), iVar3 == 8)))) {
    uVar27 = CONCAT44(in_ECX + 0x979,1);
    (**(code **)((int)*in_ECX + 0x73c))(1);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(1,1,1), cVar2 != '\0')) {
      local_32c = 0;
      local_328 = 0;
      local_324 = 0;
      local_8 = 0x1c;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      local_18 = (float)(**(code **)((int)*in_ECX + 0xc0))();
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x13,local_330,1,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0x13) && (in_ECX[0xbb0] == 0.0)) &&
     (iVar3 = FUN_00b06f00(), (int)in_ECX[0xbb1] <= iVar3)) {
    piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
    cVar2 = (**(code **)(*piVar8 + 0x38))();
    if (cVar2 == '\0') {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = CONCAT44(in_ECX + 0x979,5);
    (**(code **)((int)*in_ECX + 0x73c))(5);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(5,1,1), cVar2 != '\0')) {
      local_37c = 0;
      local_378 = 0;
      local_374 = 0;
      local_8 = 0x1d;
      iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
      local_18 = (float)(uint)(0 < iVar3);
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      (**(code **)((int)*in_ECX + 0x28c))(0x14,local_380,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x14) && (in_ECX[0xbbb] == 1.4013e-45)) {
    piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
    cVar2 = (**(code **)(*piVar8 + 0x38))();
    if (cVar2 == '\0') {
      local_38c = 0;
      local_388 = 0;
      local_384 = 0;
      local_8 = 0x1e;
      local_18 = 2.8026e-45;
      FUN_00407120();
      local_18 = (float)FUN_00a24ce0();
      fVar9 = (float)FUN_00b06f00();
      if (fVar9 == local_18 || (int)fVar9 - (int)local_18 < 0) {
        local_14 = (float *)0x0;
      }
      else {
        iVar3 = FUN_00a24ce0();
        iVar10 = FUN_00b06f00();
        local_14 = (float *)(iVar10 - iVar3);
      }
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x14,local_390,1,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 3;
    (**(code **)((int)*in_ECX + 0x73c))(3);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(3,1,1), cVar2 != '\0')) {
      local_3dc = 0;
      local_3d8 = 0;
      local_3d4 = 0;
      local_8 = 0x1f;
      local_18 = 4.2039e-45;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0xe,local_3e0,1,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 8;
    (**(code **)((int)*in_ECX + 0x73c))(8);
    local_14 = (float *)FUN_00559140(uVar27);
    if ((local_14 != (float *)0xffffffff) &&
       (cVar2 = (**(code **)((int)*in_ECX + 0x768))(8,1,1), cVar2 != '\0')) {
      local_35c = 0;
      local_358 = 0;
      local_354 = 0;
      local_8 = 0x20;
      local_18 = 0.0;
      FUN_00407120();
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x16,local_360,1,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x16) {
    if (((int)in_ECX[0xbc7] < (int)in_ECX[0xbc8] + -1) &&
       (*(int *)(&DAT_00d79744 + (int)in_ECX[0xbc7] * 4) <= *(int *)((int)in_ECX[0x41] + 0x124))) {
      uVar11 = 1;
      (**(code **)((int)*in_ECX + 0x67c))(8);
      FUN_0054f270();
      lVar30 = (ulonglong)uVar11 << 0x20;
      (**(code **)((int)*in_ECX + 0x73c))();
      local_14 = (float *)FUN_00559140(lVar30);
      if ((local_14 != (float *)0xffffffff) &&
         (cVar2 = (**(code **)((int)*in_ECX + 0x768))(8,1,1), cVar2 != '\0')) {
        local_3ac = 0;
        local_3a8 = 0;
        local_3a4 = 0;
        local_18 = (float)((int)in_ECX[0xbc7] + 1);
        local_8 = 0x21;
        FUN_00407120();
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x16,local_3b0,1,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
    if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 9;
    (**(code **)((int)*in_ECX + 0x73c))(9);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(9,1,1), cVar2 != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0x17,0,1,0);
    }
  }
  else {
    iVar3 = FUN_00402060();
    if (((iVar3 == 0x17) && (in_ECX[0xbdc] == 0.0)) && (7 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      (**(code **)((int)*in_ECX + 0x67c))();
      iVar3 = (**(code **)((int)*in_ECX + 0x64c))(0x1b);
      if (0 < iVar3) {
        (**(code **)((int)*in_ECX + 0x67c))();
        iVar3 = FUN_0054ff60();
        iVar10 = (**(code **)((int)*in_ECX + 0x64c))(0xd);
        if ((iVar10 < iVar3) || (iVar3 = (**(code **)((int)*in_ECX + 0x620))(), iVar3 != 1)) {
          (**(code **)((int)*in_ECX + 0x67c))();
          iVar3 = FUN_0054ff60();
          iVar10 = (**(code **)((int)*in_ECX + 0x64c))(4);
          if ((iVar10 < iVar3) || (iVar3 = (**(code **)((int)*in_ECX + 0x620))(), iVar3 != 5))
          goto LAB_0072b291;
        }
        uVar27 = 9;
        (**(code **)((int)*in_ECX + 0x73c))(9);
        iVar3 = FUN_00559140(uVar27);
        if (iVar3 == -1) {
          piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
          cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
          if (cVar2 == '\0') goto LAB_0072b291;
        }
        local_3fc = 0;
        local_3f8 = 0;
        local_3f4 = 0;
        local_8 = 0x22;
        local_18 = 1.4013e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x17,local_400,1,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
  }
LAB_0072b291:
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    local_3c[0] = (int *)0x35;
    local_3c[1] = (int *)0x34;
    local_34 = (float *)0x36;
    iVar3 = 0;
    do {
      uVar31 = (ulonglong)*(uint *)((int)&DAT_00f6e678 + iVar3);
      (**(code **)((int)*in_ECX + 0x73c))(*(uint *)((int)&DAT_00f6e678 + iVar3));
      iVar10 = FUN_00559140(uVar31);
      if (iVar10 != -1) {
        if (((int *)in_ECX[0xc9b] == (int *)0x0) ||
           (cVar2 = (**(code **)(*(int *)in_ECX[0xc9b] + 0x60))(), cVar2 == '\0')) {
          cVar2 = (**(code **)((int)*in_ECX + 0x768))
                            (*(undefined4 *)((int)&DAT_00f6e678 + iVar3),1,1);
          if (cVar2 != '\0') {
            local_3cc = 0;
            local_3c8 = 0;
            local_3c4 = 0;
            local_18 = *(float *)((int)&DAT_00f6e678 + iVar3);
            local_8 = 0x23;
            FUN_00407120();
            (**(code **)((int)*in_ECX + 0x28c))(0x18,local_3d0,1,0);
            local_8 = 0xffffffff;
            FUN_00644d50();
          }
        }
        else {
          cVar2 = (**(code **)((int)*in_ECX + 0x768))
                            (*(undefined4 *)((int)&DAT_00f6e678 + iVar3),1,0);
          if (cVar2 != '\0') {
            (**(code **)((int)*in_ECX + 0x28c))(*(undefined4 *)((int)local_3c + iVar3),0,1,0);
          }
        }
      }
      iVar3 = iVar3 + 4;
    } while (iVar3 < 0xc);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x18) && (iVar3 = FUN_00b06f00(), (int)in_ECX[0xbe4] <= iVar3)) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x17;
    (**(code **)((int)*in_ECX + 0x73c))(0x17);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      (**(code **)((int)*in_ECX + 0x67c))();
      local_18 = (float)FUN_0054ff60();
      iVar3 = (**(code **)((int)*in_ECX + 0x238))();
      local_14 = (float *)(((int)local_18 * iVar3) / 100);
      iVar3 = (**(code **)((int)*in_ECX + 0x234))();
      if ((int)local_14 < iVar3) {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x17,1,1);
        if (cVar2 != '\0') {
          local_18 = *in_ECX;
          (**(code **)((int)local_18 + 0x234))(1);
          (**(code **)((int)local_18 + 1000))();
          local_50 = 0;
          local_4c = 0;
          local_48 = 0;
          local_8 = 0x24;
          local_18 = 0.0;
          FUN_00407120(&local_18);
          local_18 = 0.0;
          FUN_00407120(&local_18);
          local_18 = 3.22299e-44;
          FUN_00407120(&local_18);
          uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x17);
          local_18 = (float)FUN_00468430(in_ECX,uVar4);
          FUN_00407120(&local_18);
          local_18 = (float)FUN_0054ff60(2,in_ECX);
          FUN_00407120(&local_18);
          local_18 = 0.0;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          local_18 = 1.4013e-42;
          FUN_00407120(&local_18);
          local_18 = 1.4013e-42;
          FUN_00407120(&local_18);
          iVar3 = FUN_0054ff60(1,in_ECX);
          local_18 = (float)(iVar3 / 2);
          FUN_00407120(&local_18);
          (**(code **)((int)*in_ECX + 0x28c))(10,local_54,1,0,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
      else {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(0xe0f,0xff9bc8e6,0x10,0);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 0x18;
    (**(code **)((int)*in_ECX + 0x73c))(0x18);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x18,1,1), cVar2 != '\0')) {
      (**(code **)((int)*in_ECX + 0x67c))();
      local_a4 = 0;
      local_a0 = 0;
      local_9c = 0;
      local_8 = 0x25;
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 3.36312e-44;
      FUN_00407120(&local_18);
      uVar27 = 0xc;
      uVar24 = 0xffffffff;
      uVar22 = 0xffffffff;
      uVar19 = 0x18;
      pfVar15 = in_ECX;
      uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x18);
      local_18 = (float)FUN_00550080(1,uVar4,uVar19,pfVar15,uVar22,uVar24,uVar27);
      FUN_00407120();
      local_18 = (float)FUN_0054ff60(3,in_ECX);
      FUN_00407120();
      local_18 = 1.4013e-45;
      FUN_00407120();
      local_18 = 4.2039e-45;
      FUN_00407120();
      local_18 = 4.2039e-45;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(10,local_a8,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x20;
    (**(code **)((int)*in_ECX + 0x73c))(0x20);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x20,1,1), cVar2 != '\0')) {
      local_f4 = 0;
      local_f0 = 0;
      local_ec = 0;
      local_8 = 0x26;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 4.48416e-44;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x67c))();
      local_18 = (float)FUN_0054ff60();
      FUN_00407120(&local_18);
      local_18 = 1.4013e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      (**(code **)((int)*in_ECX + 0x28c))(10,local_f8,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x4a;
    (**(code **)((int)*in_ECX + 0x73c))(0x4a);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      iVar3 = FUN_0071b8d0();
      if (iVar3 < 1) {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(0x1b62,0xff9bc8e6,0x10,0);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
      else {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x4a,1,1);
        if (cVar2 != '\0') {
          local_d4 = 0;
          local_d0 = 0;
          local_cc = 0;
          local_8 = 0x27;
          local_18 = 0.0;
          FUN_00407120();
          local_18 = 0.0;
          FUN_00407120();
          local_18 = 1.03696e-43;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x64c))();
          uVar27 = CONCAT44(in_ECX,0x4a);
          (**(code **)((int)*in_ECX + 0x67c))(0x4a);
          local_18 = (float)FUN_00468430(uVar27);
          FUN_00407120();
          uVar4 = 0x4a;
          (**(code **)((int)*in_ECX + 0x67c))(0x4a,0);
          iVar3 = FUN_0054ff60(uVar4);
          uVar4 = 0x38;
          (**(code **)((int)*in_ECX + 0x38c))(0x38,6);
          iVar10 = FUN_00a24ce0(uVar4);
          local_18 = (float)(iVar3 - iVar10);
          FUN_00407120(&local_18);
          local_18 = 1.4013e-45;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          local_18 = 0.0;
          FUN_00407120(&local_18);
          (**(code **)((int)*in_ECX + 0x28c))(10,local_d8,1,0,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((((iVar3 == 10) && (in_ECX[0x90a] == 0.0)) && (iVar3 = FUN_00402060(), iVar3 == 0x4a)) &&
     (iVar3 = FUN_00402060(), iVar3 == 1)) {
    piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
    cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
    if (cVar2 == '\0') {
      uVar27 = 0x4a;
      (**(code **)((int)*in_ECX + 0x73c))(0x4a);
      iVar3 = FUN_00559140(uVar27);
      if (iVar3 != -1) goto LAB_0072bb0d;
    }
    else {
LAB_0072bb0d:
      FUN_006b4b10();
    }
    FUN_00b06f00();
    cVar2 = FUN_00a51fb0();
    if (cVar2 != '\0') {
      (**(code **)((int)*in_ECX + 0x67c))();
      iVar3 = FUN_0054ff60(2,in_ECX);
      iVar3 = iVar3 * 1000;
      FUN_004d3bd0();
      uVar4 = FUN_00c01544();
      uVar27 = CONCAT44(iVar3,uVar4);
      local_18 = (float)FUN_0054ff60(3,in_ECX);
      fVar17 = (float10)FUN_00b099b0(0x3f800000,(float)(int)local_18 * _DAT_00cc10ac,uVar27);
      local_18 = (float)fVar17;
      DAT_00f5478c = 0;
      FUN_005b3550();
      FUN_005b8030();
      FUN_005a1f10(0x4a,DAT_00f54788,DAT_00f5478c,1);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x29) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x2f;
    (**(code **)((int)*in_ECX + 0x73c))(0x2f);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      (**(code **)((int)*in_ECX + 0x67c))();
      if (((int *)in_ECX[0xbf3] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xbf3] + 0x60))(), cVar2 == '\0')) {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x2f,1,1);
        if (cVar2 != '\0') {
          local_84 = 0;
          local_80 = 0;
          local_7c = 0;
          local_8 = 0x28;
          local_18 = 0.0;
          FUN_00407120();
          local_18 = 0.0;
          FUN_00407120();
          local_18 = 6.5861e-44;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x64c))();
          local_18 = (float)FUN_00468430();
          FUN_00407120(&local_18);
          local_18 = (float)FUN_0054ff60();
          FUN_00407120(&local_18);
          local_18 = 1.4013e-45;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          (**(code **)((int)*in_ECX + 0x28c))(10,local_88,1,0,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
      else {
        fVar9 = (float)FUN_0054ff60(3,in_ECX);
        local_18 = fVar9;
        iVar3 = FUN_00b06f00();
        if (iVar3 < (int)fVar9) {
          cVar2 = FUN_004cc7f0();
          if (cVar2 != '\0') {
            dVar32 = (double)((float)(int)local_18 * _DAT_00cc11f8);
            uVar4 = FUN_00a51240();
            FUN_00401df0(local_6a8,0x100,uVar4,dVar32);
            FUN_009bc710(local_6a8,0xff9bc8e6,0x10,0,0);
          }
        }
        else {
          (**(code **)((int)*in_ECX + 0x768))(0x2f,1,0);
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x12;
    (**(code **)((int)*in_ECX + 0x73c))(0x12);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x12,1,1), cVar2 != '\0')) {
      local_94 = 0;
      local_90 = 0;
      local_8c = 0;
      local_8 = 0x29;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 2.52234e-44;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x64c))();
      uVar27 = CONCAT44(in_ECX,0x12);
      (**(code **)((int)*in_ECX + 0x67c))(0x12);
      local_18 = (float)FUN_00468430(uVar27);
      FUN_00407120();
      uVar4 = 0x12;
      (**(code **)((int)*in_ECX + 0x67c))(0x12,0);
      local_18 = (float)FUN_0054ff60(uVar4);
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      (**(code **)((int)*in_ECX + 0x28c))(10,local_98,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x1e;
    (**(code **)((int)*in_ECX + 0x73c))(0x1e);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x1e,1,1), cVar2 != '\0')) {
      local_c4 = 0;
      local_c0 = 0;
      local_bc = 0;
      local_8 = 0x2a;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 4.2039e-44;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x64c))();
      uVar27 = CONCAT44(in_ECX,0x1e);
      (**(code **)((int)*in_ECX + 0x67c))(0x1e);
      local_18 = (float)FUN_00468430(uVar27);
      FUN_00407120();
      uVar4 = 0x1e;
      (**(code **)((int)*in_ECX + 0x67c))(0x1e,0);
      local_18 = (float)FUN_0054ff60(uVar4);
      FUN_00407120(&local_18);
      local_18 = 1.4013e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      (**(code **)((int)*in_ECX + 0x28c))(10,local_c8,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x54;
    (**(code **)((int)*in_ECX + 0x73c))(0x54);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x54,1,1), cVar2 != '\0')) {
      local_e4 = 0;
      local_e0 = 0;
      local_dc = 0;
      local_8 = 0x2b;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 1.17709e-43;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x64c))();
      uVar27 = CONCAT44(in_ECX,0x54);
      (**(code **)((int)*in_ECX + 0x67c))(0x54);
      local_18 = (float)FUN_00468430(uVar27);
      FUN_00407120();
      uVar4 = 0x54;
      (**(code **)((int)*in_ECX + 0x67c))(0x54,0);
      local_18 = (float)FUN_0054ff60(uVar4);
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      (**(code **)((int)*in_ECX + 0x28c))(10,local_e8,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar4 = 0;
    (**(code **)((int)*in_ECX + 0x67c))();
    piVar8 = (int *)FUN_0054ff60();
    local_24 = piVar8;
    if (*(char *)((int)in_ECX + 0x23af) == '\0') {
LAB_0072c2ae:
      uVar11 = (uint)piVar8 & 0xffffff00;
    }
    else {
      local_18 = (float)(**(code **)((int)*in_ECX + 0x234))();
      local_14 = (float *)((float)(int)local_18 * _DAT_00ccb9d8);
      local_18 = (float)(**(code **)((int)*in_ECX + 0x238))();
      fVar9 = (float)local_14 / (float)(int)local_18;
      fVar12 = (float)(int)local_24;
      piVar8 = (int *)CONCAT22((short)((uint)local_18 >> 0x10),
                               (ushort)(fVar12 < fVar9) << 8 |
                               (ushort)(NAN(fVar12) || NAN(fVar9)) << 10 |
                               (ushort)(fVar12 == fVar9) << 0xe);
      if (fVar12 < fVar9) goto LAB_0072c2ae;
      uVar11 = CONCAT31((int3)((uint)piVar8 >> 8),1);
    }
    uVar27 = CONCAT44(uVar4,uVar11);
    (**(code **)((int)*in_ECX + 0x67c))();
    FUN_0054f270();
    (**(code **)((int)*in_ECX + 0x73c))(0x22,0,uVar27);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x22,1,1), cVar2 != '\0')) {
      (**(code **)((int)*in_ECX + 0x67c))();
      local_104 = 0;
      local_100 = 0;
      local_fc = 0;
      local_8 = 0x2c;
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 4.76441e-44;
      FUN_00407120(&local_18);
      uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x22);
      local_18 = (float)FUN_00468430(in_ECX,uVar4);
      FUN_00407120();
      local_18 = (float)FUN_0054ff60(1,in_ECX);
      FUN_00407120();
      local_18 = 1.4013e-45;
      FUN_00407120();
      local_18 = 5.60519e-45;
      FUN_00407120();
      local_18 = 5.60519e-45;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(10,local_108,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x2c;
    (**(code **)((int)*in_ECX + 0x73c))(0x2c);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x2c,1,1), cVar2 != '\0')) {
      (**(code **)((int)*in_ECX + 0x67c))();
      local_b4 = 0;
      local_b0 = 0;
      local_ac = 0;
      local_8 = 0x2d;
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      local_18 = 6.16571e-44;
      FUN_00407120(&local_18);
      uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x2c);
      local_18 = (float)FUN_00468430(in_ECX,uVar4);
      FUN_00407120();
      uVar25 = 0xc;
      uVar24 = 0xffffffff;
      uVar22 = 0xffffffff;
      uVar19 = 0x2c;
      pfVar15 = in_ECX;
      uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x2c);
      local_18 = (float)FUN_00550080(1,uVar4,uVar19,pfVar15,uVar22,uVar24,uVar25);
      FUN_00407120(&local_18);
      local_18 = 1.4013e-45;
      FUN_00407120(&local_18);
      local_18 = 5.60519e-45;
      FUN_00407120(&local_18);
      local_18 = 0.0;
      FUN_00407120(&local_18);
      (**(code **)((int)*in_ECX + 0x28c))(10,local_b8,1,0,0);
      local_8 = 0xffffffff;
      FUN_00644d50();
    }
  }
  iVar3 = FUN_00402060();
  if ((((iVar3 == 10) && (in_ECX[0x90a] == 0.0)) && (iVar3 = FUN_00402060(), iVar3 == 1)) &&
     (iVar3 = FUN_00402060(), iVar3 == 0x2c)) {
    piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
    cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x697);
    if (cVar2 != '\0') {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,1,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    local_20 = (float *)&DAT_00f6e668;
    do {
      pfVar15 = local_20;
      uVar31 = (ulonglong)(uint)*local_20;
      (**(code **)((int)*in_ECX + 0x73c))(*local_20);
      iVar3 = FUN_00559140(uVar31);
      if ((iVar3 != -1) &&
         (cVar2 = (**(code **)((int)*in_ECX + 0x768))(*pfVar15,1,1), cVar2 != '\0')) {
        (**(code **)((int)*in_ECX + 0x67c))();
        local_60 = (void *)0x0;
        local_5c = 0;
        local_58 = 0;
        local_8 = 0x2e;
        local_18 = 0.0;
        FUN_00407120(&local_18);
        local_18 = 0.0;
        FUN_00407120(&local_18);
        local_18 = *local_20;
        FUN_00407120(&local_18);
        iVar3 = (**(code **)((int)*in_ECX + 0x64c))(*local_20);
        if (iVar3 == -1) {
          FUN_00402060();
        }
        local_18 = (float)FUN_00402060();
        FUN_00407120();
        local_18 = (float)FUN_0054ff60(0,in_ECX);
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        local_18 = 5.60519e-45;
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(10,local_64,1);
        local_8 = 0xffffffff;
        if (local_60 != (void *)0x0) {
          _free(local_60);
        }
        local_60 = (void *)0x0;
        local_5c = 0;
        local_58 = 0;
        pfVar15 = local_20;
      }
      local_20 = pfVar15 + 1;
    } while ((int)local_20 < 0xf6e678);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    pfVar15 = (float *)&DAT_00f6e660;
    do {
      uVar31 = (ulonglong)(uint)*pfVar15;
      (**(code **)((int)*in_ECX + 0x73c))(*pfVar15);
      iVar3 = FUN_00559140(uVar31);
      if ((iVar3 != -1) &&
         (cVar2 = (**(code **)((int)*in_ECX + 0x768))(*pfVar15,1,1), cVar2 != '\0')) {
        local_24c = (void *)0x0;
        local_248 = 0;
        local_244 = 0;
        local_18 = *pfVar15;
        local_8 = 0x2f;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0xe,local_250,1,0);
        local_8 = 0xffffffff;
        if (local_24c != (void *)0x0) {
          _free(local_24c);
        }
        local_24c = (void *)0x0;
        local_248 = 0;
        local_244 = 0;
      }
      pfVar15 = pfVar15 + 1;
    } while ((int)pfVar15 < 0xf6e668);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 6) && (iVar3 = FUN_00402060(), iVar3 == 1)) {
    uVar27 = 0x10;
    (**(code **)((int)*in_ECX + 0x73c))(0x10);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x10,1,1), cVar2 != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0x19,0,1,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x19) && (*(int *)((int)in_ECX[0x3e] + 0xf4) == 4)) {
    (**(code **)((int)*in_ECX + 0x67c))();
    iVar3 = FUN_0054ff60();
    iVar10 = FUN_00402060();
    if (iVar3 <= iVar10) {
      (**(code **)((int)*in_ECX + 0x67c))(0x10);
      local_14 = (float *)(**(code **)((int)*in_ECX + 0x64c))();
      uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
      local_18 = (float)FUN_00550150(1,local_14,in_ECX,uVar4,uVar4,0);
      DAT_00f5478c = 0;
      uVar4 = FUN_00550080(2,local_14,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
      FUN_004e2780(uVar4);
      (**(code **)((int)*in_ECX + 0x2b8))
                (0x4e30,local_18,0,0,0,0,0,4,0,DAT_00f5478c,DAT_00f54788,0,0);
    }
    (**(code **)((int)*in_ECX + 0x28c))(1,0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 6) && (iVar3 = FUN_00402060(), iVar3 == 1)) {
    uVar27 = 0x11;
    (**(code **)((int)*in_ECX + 0x73c))(0x11);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x11,1,1), cVar2 != '\0')) {
      local_11c = (void *)0x0;
      local_118 = 0;
      local_114 = 0;
      local_8 = 0x30;
      local_18 = 2.38221e-44;
      FUN_00407120();
      if ((in_ECX[0xacd] == -NAN) || (in_ECX[0xacd] != 0.0)) {
        local_18 = 0.0;
      }
      else {
        local_18 = 1.4013e-45;
      }
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(7,local_120,1,0);
      local_8 = 0xffffffff;
      if (local_11c != (void *)0x0) {
        _free(local_11c);
      }
      local_11c = (void *)0x0;
      local_118 = 0;
      local_114 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0xc) {
    if ((_DAT_01050310 & 1) == 0) {
      _DAT_01050310 = _DAT_01050310 | 1;
      local_8 = 0x31;
      DAT_0105030c = FUN_008ac050();
      local_8 = 0xffffffff;
    }
    iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
    if ((0 < iVar3) && (DAT_0105030c <= *(int *)((int)in_ECX[0x41] + 0x124))) {
      uVar11 = 1;
      (**(code **)((int)*in_ECX + 0x67c))(0xb);
      FUN_0054f270();
      lVar30 = (ulonglong)uVar11 << 0x20;
      (**(code **)((int)*in_ECX + 0x73c))();
      iVar3 = FUN_00559140(lVar30);
      if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0xb,1,1), cVar2 != '\0')) {
        (**(code **)((int)*in_ECX + 0x28c))(0x1d,0,1,0);
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x1d) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x39;
    (**(code **)((int)*in_ECX + 0x73c))(0x39);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x39,1,1), cVar2 != '\0')) {
      local_2cc = (void *)0x0;
      local_2c8 = 0;
      local_2c4 = 0;
      local_8 = 0x32;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x1f,local_2d0,1,0);
      local_8 = 0xffffffff;
      if (local_2cc != (void *)0x0) {
        _free(local_2cc);
      }
      local_2cc = (void *)0x0;
      local_2c8 = 0;
      local_2c4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x1f) {
    if (in_ECX[0xae8] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_26c = (void *)0x0;
        local_268 = 0;
        local_264 = 0;
        local_8 = 0x33;
        local_18 = 1.4013e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x1f,local_270,0,0);
        local_8 = 0xffffffff;
        if (local_26c != (void *)0x0) {
          _free(local_26c);
        }
        local_26c = (void *)0x0;
        local_268 = 0;
        local_264 = 0;
      }
    }
    else if (((in_ECX[0xae8] == 1.4013e-45) && (in_ECX[0xaee] != -NAN)) &&
            (iVar3 = FUN_00b06f00(), (int)in_ECX[0xaee] <= iVar3)) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0xb) {
    uVar11 = 0;
    if ((((int *)in_ECX[0xc1d] == (int *)0x0) ||
        (uVar11 = (**(code **)(*(int *)in_ECX[0xc1d] + 0x60))(), (char)uVar11 == '\0')) ||
       (*(int *)((int)in_ECX[0xc1d] + 0x90) != 1)) {
      uVar11 = uVar11 & 0xffffff00;
    }
    else {
      uVar11 = CONCAT31((int3)(uVar11 >> 8),1);
    }
    (**(code **)((int)*in_ECX + 0x67c))(0x3c);
    FUN_0054f270();
    lVar30 = (ulonglong)uVar11 << 0x20;
    (**(code **)((int)*in_ECX + 0x73c))();
    iVar3 = FUN_00559140(lVar30);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x3c,1,1), cVar2 != '\0')) {
      local_1fc = (void *)0x0;
      local_1f8 = 0;
      local_1f4 = 0;
      local_8 = 0x34;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x21,local_200,1,0);
      local_8 = 0xffffffff;
      if (local_1fc != (void *)0x0) {
        _free(local_1fc);
      }
      local_1fc = (void *)0x0;
      local_1f8 = 0;
      local_1f4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x21) {
    fVar9 = in_ECX[0xaef];
    if (fVar9 == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_30c = (void *)0x0;
        local_308 = 0;
        local_304 = 0;
        local_8 = 0x35;
        local_18 = 1.4013e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x21,local_310,0,0);
        local_8 = 0xffffffff;
        if (local_30c != (void *)0x0) {
          _free(local_30c);
        }
        local_30c = (void *)0x0;
        local_308 = 0;
        local_304 = 0;
      }
    }
    else if (fVar9 == 1.4013e-45) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        if (in_ECX[0xaf4] == 0.0) {
          (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
        }
        else {
          local_3ec = 0;
          local_3e8 = 0;
          local_3e4 = 0;
          local_8 = 0x36;
          local_18 = 2.8026e-45;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x21,local_3f0,0,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
    }
    else if ((fVar9 == 2.8026e-45) && (iVar3 = FUN_00b06f00(), (int)in_ECX[0xafd] <= iVar3)) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 3)) {
    uVar11 = 0x3e;
    (**(code **)((int)*in_ECX + 0x67c))();
    iVar3 = FUN_00402060();
    if ((iVar3 != 0) && (cVar2 = FUN_0071f0c0(), cVar2 == '\0')) {
      (**(code **)((int)*in_ECX + 0x67c))();
      FUN_0054f270();
    }
    lVar30 = (ulonglong)uVar11 << 0x20;
    (**(code **)((int)*in_ECX + 0x73c))();
    iVar3 = FUN_00559140(lVar30);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x3e,1,1), cVar2 != '\0')) {
      local_28c = (void *)0x0;
      local_288 = 0;
      local_284 = 0;
      local_8 = 0x37;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x22,local_290,1,0);
      local_8 = 0xffffffff;
      if (local_28c != (void *)0x0) {
        _free(local_28c);
      }
      local_28c = (void *)0x0;
      local_288 = 0;
      local_284 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x22) {
    if (in_ECX[0xb00] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) == '\0') {
        uVar27 = 0x3e;
        (**(code **)((int)*in_ECX + 0x73c))(0x3e);
        iVar3 = FUN_00559140(uVar27);
        if (iVar3 == -1) {
          piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
          cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
          if (cVar2 == '\0') goto LAB_0072d1a2;
        }
        lVar30 = ZEXT48(in_ECX) << 0x20;
        (**(code **)((int)*in_ECX + 0x67c))();
        iVar3 = FUN_0054ff60(lVar30);
        iVar10 = FUN_00b06f00();
        if (iVar10 < iVar3) goto LAB_0072d1a2;
      }
      local_19c = (void *)0x0;
      local_198 = 0;
      local_194 = 0;
      local_8 = 0x38;
      local_18 = 1.4013e-45;
      FUN_00407120();
      local_18 = (float)FUN_0071ef60();
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x22,local_1a0,1,0);
      local_8 = 0xffffffff;
      if (local_19c != (void *)0x0) {
        _free(local_19c);
      }
      local_19c = (void *)0x0;
      local_198 = 0;
      local_194 = 0;
    }
    else if ((in_ECX[0xb00] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
LAB_0072d1a2:
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 0x3a;
    (**(code **)((int)*in_ECX + 0x73c))(0x3a);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x3a,1,1), cVar2 != '\0')) {
      local_2ec = (void *)0x0;
      local_2e8 = 0;
      local_2e4 = 0;
      local_8 = 0x39;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x20,local_2f0,1,0);
      local_8 = 0xffffffff;
      if (local_2ec != (void *)0x0) {
        _free(local_2ec);
      }
      local_2ec = (void *)0x0;
      local_2e8 = 0;
      local_2e4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x20) {
    if (in_ECX[0xb12] == 0.0) {
      cVar2 = *(char *)((int)in_ECX[0x41] + 0x13a);
LAB_0072d2b5:
      if (cVar2 != '\0') {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
    else if (in_ECX[0xb12] == 1.4013e-45) {
      fVar9 = in_ECX[0x41];
      fVar12 = (float)(**(code **)((int)*in_ECX + 0x38c))();
      if (fVar9 == fVar12) {
        cVar2 = *(char *)((int)fVar9 + 0x13a);
        goto LAB_0072d2b5;
      }
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 0x40;
    (**(code **)((int)*in_ECX + 0x73c))(0x40);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      local_2c = (int *)0x0;
      iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
      if (0 < iVar3) {
        uVar27 = 0xc;
        uVar24 = 0xffffffff;
        uVar22 = 0xffffffff;
        uVar19 = 0x40;
        pfVar15 = in_ECX;
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x40);
        (**(code **)((int)*in_ECX + 0x67c))(0x40,6,uVar4);
        local_2c = (int *)FUN_00550080(uVar4,uVar19,pfVar15,uVar22,uVar24,uVar27);
      }
      iVar3 = FUN_00402060();
      if (iVar3 == 4) {
        FUN_00448480();
      }
      else {
        FUN_00448c10();
      }
      piVar8 = (int *)FUN_00c01544();
      local_2c = piVar8;
      iVar3 = (**(code **)((int)*in_ECX + 0x234))();
      if ((int)piVar8 < iVar3) {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x40,1,1);
        if (cVar2 != '\0') {
          if (0 < (int)piVar8) {
            fVar9 = *in_ECX;
            (**(code **)((int)fVar9 + 0x234))(1);
            (**(code **)((int)fVar9 + 1000))();
          }
          (**(code **)((int)*in_ECX + 0x28c))(0x23,0,0,0);
        }
      }
      else {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(0xe0f,0xff9bc8e6,0x10,0);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x23) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = CONCAT44(in_ECX + 0x979,0x41);
    (**(code **)((int)*in_ECX + 0x73c))(0x41);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x41,1,1), cVar2 != '\0')) {
      local_2ac = (void *)0x0;
      local_2a8 = 0;
      local_2a4 = 0;
      local_8 = 0x3a;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x24,local_2b0,1,0);
      local_8 = 0xffffffff;
      if (local_2ac != (void *)0x0) {
        _free(local_2ac);
      }
      local_2ac = (void *)0x0;
      local_2a8 = 0;
      local_2a4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x24) {
    if (in_ECX[0xb29] == 0.0) {
      if (*(int *)((int)in_ECX[0x41] + 0x188) == 0) {
        iVar3 = *(int *)((int)in_ECX[0x41] + 0x8c);
      }
      else {
        iVar3 = FUN_004caa00();
      }
      piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
      cVar2 = (**(code **)(*piVar8 + 0x38))();
      if ((cVar2 == '\0') || ((int)in_ECX[0xb2b] <= iVar3)) {
        FUN_00b099b0(0,0x42c80000,iVar3 - (int)in_ECX[0xb2a]);
        local_14 = (float *)FUN_00c01544();
        local_17c = (void *)0x0;
        local_178 = 0;
        local_174 = 0;
        local_8 = 0x3b;
        local_18 = 1.4013e-45;
        FUN_00407120();
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x24,local_180,0,0);
        local_8 = 0xffffffff;
        if (local_17c != (void *)0x0) {
          _free(local_17c);
        }
        local_17c = (void *)0x0;
        local_178 = 0;
        local_174 = 0;
      }
    }
    else if ((in_ECX[0xb29] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x48;
    (**(code **)((int)*in_ECX + 0x73c))(0x48);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x48,1,1), cVar2 != '\0')) {
      local_1bc = (void *)0x0;
      local_1b8 = 0;
      local_1b4 = 0;
      local_8 = 0x3c;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = (float)(**(code **)((int)*in_ECX + 0xc0))();
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x27,local_1c0,1,0);
      local_8 = 0xffffffff;
      if (local_1bc != (void *)0x0) {
        _free(local_1bc);
      }
      local_1bc = (void *)0x0;
      local_1b8 = 0;
      local_1b4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x27) {
    if (in_ECX[0xb38] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_15c = (void *)0x0;
        local_158 = 0;
        local_154 = 0;
        local_8 = 0x3d;
        local_18 = 1.4013e-45;
        FUN_00407120();
        local_18 = (float)(**(code **)((int)*in_ECX + 0x644))();
        FUN_00407120(&local_18);
        (**(code **)((int)*in_ECX + 0x28c))(0x27,local_160,0,0,0);
        local_8 = 0xffffffff;
        if (local_15c != (void *)0x0) {
          _free(local_15c);
        }
        local_15c = (void *)0x0;
        local_158 = 0;
        local_154 = 0;
      }
    }
    else if (in_ECX[0xb38] == 1.4013e-45) {
      iVar3 = FUN_00402060();
      iVar10 = FUN_00402060();
      if ((iVar10 < iVar3 + -1) && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        uVar11 = 1;
        (**(code **)((int)*in_ECX + 0x67c))(0x48);
        FUN_0054f270();
        lVar30 = (ulonglong)uVar11 << 0x20;
        (**(code **)((int)*in_ECX + 0x73c))();
        local_14 = (float *)FUN_00559140(lVar30);
        if ((local_14 != (float *)0xffffffff) &&
           (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x48,1,1), cVar2 != '\0')) {
          FUN_0048cf10();
          local_8 = 0x3e;
          local_18 = 0.0;
          FUN_00407120();
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x27,local_440,1,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x49;
    (**(code **)((int)*in_ECX + 0x73c))(0x49);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x49,1,1), cVar2 != '\0')) {
      local_20c = (void *)0x0;
      local_208 = 0;
      local_204 = 0;
      local_8 = 0x3f;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x28,local_210,1,0);
      local_8 = 0xffffffff;
      if (local_20c != (void *)0x0) {
        _free(local_20c);
      }
      local_20c = (void *)0x0;
      local_208 = 0;
      local_204 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x28) {
    if (in_ECX[0xb5c] == 0.0) {
      piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
      cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
      if (cVar2 == '\0') {
        uVar27 = 0x49;
        (**(code **)((int)*in_ECX + 0x73c))(0x49);
        iVar3 = FUN_00559140(uVar27);
        if (iVar3 != -1) goto LAB_0072d9f6;
      }
      else {
LAB_0072d9f6:
        local_18 = (float)FUN_00b06f00();
        FUN_004abb50();
      }
      if (2 < *(int *)((int)in_ECX[0x41] + 0x124)) {
        uVar4 = 0x49;
        local_14 = (float *)(**(code **)((int)*in_ECX + 0x67c))();
        FUN_004d3bd0();
        local_24 = (int *)FUN_00c01544();
        iVar3 = FUN_0054ff60();
        (**(code **)((int)*in_ECX + 0x620))();
        local_18 = (float)FUN_0054ff60();
        iVar10 = (**(code **)((int)*in_ECX + 0x620))();
        local_14 = (float *)FUN_0054ff60(iVar10 * 2 + 1,uVar4);
        FUN_00b099b0((float)(int)local_14,(float)(int)local_18,local_24);
        iVar10 = FUN_00c01544();
        if ((int)in_ECX[0xb5f] < iVar10 + -1) {
          FUN_0071c940();
        }
        else {
          local_36c = 0;
          local_368 = 0;
          local_364 = 0;
          local_8 = 0x40;
          local_18 = 1.4013e-45;
          FUN_00407120();
          pfVar15 = (float *)(((int)local_24 * 100) / (iVar3 * 1000));
          local_14 = (float *)0x64;
          if ((int)pfVar15 < 0x65) {
            local_14 = pfVar15;
          }
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x28,local_370,0,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
    }
    else if ((in_ECX[0xb5c] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = CONCAT44(in_ECX + 0x979,0x4f);
    (**(code **)((int)*in_ECX + 0x73c))(0x4f);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if (((int *)in_ECX[0xc21] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc21] + 0x60))(), cVar2 == '\0')) {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar4 = 0xdf3;
LAB_0072dc8d:
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(uVar4,0x10ff9bc8e6,0);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
      else {
        iVar3 = (**(code **)((int)*in_ECX + 0x234))();
        if (iVar3 < 2) {
          cVar2 = FUN_004cc7f0();
          if (cVar2 != '\0') {
            uVar4 = 0xe0f;
            goto LAB_0072dc8d;
          }
        }
        else {
          cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x4f,1,1);
          if (cVar2 != '\0') {
            local_40c = 0;
            local_408 = 0;
            local_404 = 0;
            local_8 = 0x41;
            local_18 = 0.0;
            FUN_00407120();
            (**(code **)((int)*in_ECX + 0x28c))(0x2b,local_410,1,0);
            local_8 = 0xffffffff;
            FUN_00644d50();
          }
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x2b) {
    if (in_ECX[0xb64] == 0.0) {
      if (*(int *)((int)in_ECX[0x41] + 0x188) == 0) {
        iVar3 = *(int *)((int)in_ECX[0x41] + 0x8c);
      }
      else {
        iVar3 = FUN_004caa00();
      }
      iVar10 = FUN_00a24ce0();
      if (iVar3 - iVar10 < (int)in_ECX[0xb65]) {
LAB_0072dd17:
        if ((iVar3 - iVar10 < (int)in_ECX[0xb66]) &&
           (iVar3 = (**(code **)((int)*in_ECX + 0x234))(), 1 < iVar3)) goto LAB_0072ddc7;
      }
      else {
        piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
        cVar2 = (**(code **)(*piVar8 + 0x38))();
        if (cVar2 != '\0') goto LAB_0072dd17;
      }
      local_23c = (void *)0x0;
      local_238 = 0;
      local_234 = 0;
      local_8 = 0x42;
      local_18 = 1.4013e-45;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x2b,local_240,0,0);
      local_8 = 0xffffffff;
      if (local_23c != (void *)0x0) {
        _free(local_23c);
      }
      local_23c = (void *)0x0;
      local_238 = 0;
      local_234 = 0;
    }
    else if ((in_ECX[0xb64] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
LAB_0072ddc7:
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x52;
    (**(code **)((int)*in_ECX + 0x73c))(0x52);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if (((int *)in_ECX[0xb90] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xb90] + 0x60))(), cVar2 == '\0')) {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x52,1,1);
        if (cVar2 != '\0') {
          local_74 = (void *)0x0;
          local_70 = 0;
          local_6c = 0;
          local_8 = 0x44;
          local_18 = 0.0;
          FUN_00407120();
          local_18 = 0.0;
          FUN_00407120();
          local_18 = 1.14906e-43;
          FUN_00407120();
          local_14 = (float *)(**(code **)((int)*in_ECX + 0x64c))();
          (**(code **)((int)*in_ECX + 0x67c))(0x52);
          if (local_14 == (float *)0xffffffff) {
            FUN_00402060();
          }
          local_18 = (float)FUN_00402060();
          FUN_00407120();
          uVar4 = 0x52;
          (**(code **)((int)*in_ECX + 0x67c))(0x52,0);
          local_18 = (float)FUN_0054ff60(uVar4);
          FUN_00407120(&local_18);
          local_18 = 0.0;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          local_18 = 5.60519e-45;
          FUN_00407120(&local_18);
          (**(code **)((int)*in_ECX + 0x28c))(10,local_78,1,0,0);
          local_8 = 0xffffffff;
          if (local_74 != (void *)0x0) {
            _free(local_74);
          }
          local_74 = (void *)0x0;
          local_70 = 0;
          local_6c = 0;
        }
      }
      else {
        local_25c = (void *)0x0;
        local_258 = 0;
        local_254 = 0;
        local_8 = 0x43;
        local_18 = 2.8026e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x2c,local_260,1,0);
        local_8 = 0xffffffff;
        if (local_25c != (void *)0x0) {
          _free(local_25c);
        }
        local_25c = (void *)0x0;
        local_258 = 0;
        local_254 = 0;
      }
    }
  }
  if (((int *)in_ECX[0xb90] != (int *)0x0) &&
     (cVar2 = (**(code **)(*(int *)in_ECX[0xb90] + 0x60))(), cVar2 != '\0')) {
    iVar3 = FUN_00402060();
    if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
      piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
      cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
      if ((cVar2 != '\0') && (in_ECX[0x128] != 1.82169e-44)) {
        local_27c = (void *)0x0;
        local_278 = 0;
        local_274 = 0;
        local_8 = 0x45;
        local_18 = 0.0;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x2c,local_280,1,0);
        local_8 = 0xffffffff;
        if (local_27c != (void *)0x0) {
          _free(local_27c);
        }
        local_27c = (void *)0x0;
        local_278 = 0;
        local_274 = 0;
      }
    }
    else {
      iVar3 = FUN_00402060();
      if (iVar3 == 6) {
        piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
        cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
        if (cVar2 != '\0') {
          FUN_0048cf10();
          local_8 = 0x46;
          local_18 = 1.4013e-45;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x2c,local_480,1,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x2c) {
    fVar9 = in_ECX[0xb8e];
    if (fVar9 == 0.0) {
      cVar2 = *(char *)((int)in_ECX[0x41] + 0x13a);
LAB_0072e29c:
      if (cVar2 != '\0') {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
    else if (fVar9 == 1.4013e-45) {
      if (*(int *)((int)in_ECX[0x3e] + 0xf4) == 4) {
        local_34c = 0;
        local_348 = 0;
        local_344 = 0;
        local_8 = 0x47;
        local_18 = 2.8026e-45;
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(6,local_350,0,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
      else if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        FUN_0048cf10();
        local_8 = 0x48;
        local_18 = 1.4013e-45;
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(6,local_3c0,0,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
    else if (fVar9 == 2.8026e-45) {
      fVar9 = in_ECX[0x41];
      fVar12 = (float)(**(code **)((int)*in_ECX + 0x38c))();
      if (fVar9 == fVar12) {
        cVar2 = *(char *)((int)fVar9 + 0x13a);
        goto LAB_0072e29c;
      }
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = CONCAT44(in_ECX + 0x979,0x44);
    (**(code **)((int)*in_ECX + 0x73c))(0x44);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x44,1,1), cVar2 != '\0')) {
      local_1dc = (void *)0x0;
      local_1d8 = 0;
      local_1d4 = 0;
      local_8 = 0x49;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x25,local_1e0,1,0);
      local_8 = 0xffffffff;
      if (local_1dc != (void *)0x0) {
        _free(local_1dc);
      }
      local_1dc = (void *)0x0;
      local_1d8 = 0;
      local_1d4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x25) {
    fVar9 = in_ECX[0xcb9];
    if (fVar9 == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_16c = (void *)0x0;
        local_168 = 0;
        local_164 = 0;
        local_8 = 0x4a;
        local_18 = 1.4013e-45;
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x25,local_170,0,0);
        local_8 = 0xffffffff;
        if (local_16c != (void *)0x0) {
          _free(local_16c);
        }
        local_16c = (void *)0x0;
        local_168 = 0;
        local_164 = 0;
      }
    }
    else if (fVar9 == 1.4013e-45) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
        cVar2 = (**(code **)(*piVar8 + 0x38))();
        if (cVar2 != '\0') {
          iVar3 = (**(code **)((int)*in_ECX + 0x620))();
          if (iVar3 == 3) {
            (**(code **)((int)*in_ECX + 0x67c))();
            iVar3 = FUN_0054ff60();
            iVar10 = (**(code **)((int)*in_ECX + 0x64c))(0xe);
            if (iVar10 < iVar3) goto LAB_0072e4c3;
LAB_0072e502:
            FUN_0048cf10();
            local_8 = 0x4b;
            local_18 = 2.8026e-45;
            FUN_00407120();
            (**(code **)((int)*in_ECX + 0x28c))(0x25,local_4a8,1,0);
            local_8 = 0xffffffff;
            FUN_00644d50();
            goto LAB_0072e628;
          }
LAB_0072e4c3:
          iVar3 = (**(code **)((int)*in_ECX + 0x620))();
          if (iVar3 == 2) {
            (**(code **)((int)*in_ECX + 0x67c))();
            iVar3 = FUN_0054ff60();
            iVar10 = (**(code **)((int)*in_ECX + 0x64c))(0xf);
            if (iVar3 <= iVar10) goto LAB_0072e502;
          }
        }
LAB_0072e619:
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
    else if (fVar9 == 2.8026e-45) {
      piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
      cVar2 = (**(code **)(*piVar8 + 0x38))();
      if ((cVar2 == '\0') || (iVar3 = FUN_00b06f00(), (int)in_ECX[0xcc6] <= iVar3)) {
        FUN_0048cf10();
        local_8 = 0x4c;
        local_18 = 4.2039e-45;
        FUN_00407120();
        local_18 = (float)FUN_00b06f00();
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x25,local_430,1,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
    else if ((fVar9 == 4.2039e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0'))
    goto LAB_0072e619;
  }
LAB_0072e628:
  iVar3 = FUN_00402060();
  if (iVar3 == 8) {
    if (*(char *)(in_ECX + 0x907) == '\0') {
LAB_0072e697:
      local_14 = (float *)((uint)local_14 & 0xffffff00);
    }
    else {
      local_18 = (float)(**(code **)((int)*in_ECX + 0x674))();
      iVar3 = FUN_00402060();
      if ((int)local_18 <= iVar3) goto LAB_0072e697;
      local_18 = *(float *)((int)in_ECX[0x41] + 0x124);
      fVar9 = *in_ECX;
      FUN_00402060();
      iVar3 = (**(code **)((int)fVar9 + 0x678))();
      if ((int)local_18 < iVar3) goto LAB_0072e697;
      local_14 = (float *)CONCAT31(local_14._1_3_,1);
      if (in_ECX[0x6c] != 0.0) goto LAB_0072e697;
    }
    (**(code **)((int)*in_ECX + 0x67c))(0x43);
    FUN_0054f270();
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 0x43;
    (**(code **)((int)*in_ECX + 0x73c))(0x43);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x43,1,1), cVar2 != '\0')) {
      local_18c = (void *)0x0;
      local_188 = 0;
      local_184 = 0;
      local_18 = (float)((int)in_ECX[0xab1] + 1);
      local_8 = 0x4d;
      FUN_00407120();
      local_18 = 9.3887e-44;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(8,local_190,1,0);
      local_8 = 0xffffffff;
      if (local_18c != (void *)0x0) {
        _free(local_18c);
      }
      local_18c = (void *)0x0;
      local_188 = 0;
      local_184 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 8) && (iVar3 = FUN_00402060(), iVar3 == 0x2e)) {
    local_18 = (float)(**(code **)((int)*in_ECX + 0x67c))();
    iVar3 = (**(code **)((int)*in_ECX + 0x620))();
    if ((iVar3 == 0) && (iVar3 = (**(code **)((int)*in_ECX + 0x64c))(), 0 < iVar3)) {
      (**(code **)((int)*in_ECX + 0x67c))();
      iVar3 = FUN_0054ff60();
      iVar10 = (**(code **)((int)*in_ECX + 0x64c))(0xc);
      if (iVar3 <= iVar10) {
        if ((_DAT_01050310 & 2) == 0) {
          _DAT_01050310 = _DAT_01050310 | 2;
          local_8 = 0x4e;
          DAT_01050308 = FUN_008ac050();
          local_8 = 0xffffffff;
        }
        iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
        if ((0 < iVar3) && (DAT_01050308 <= *(int *)((int)in_ECX[0x41] + 0x124))) {
          FUN_0054f270();
          uVar27 = 0x2e;
          (**(code **)((int)*in_ECX + 0x73c))(0x2e);
          iVar3 = FUN_00559140(uVar27);
          if (iVar3 == -1) {
            piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
            cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
            if (cVar2 == '\0') goto LAB_0072e8cb;
          }
          (**(code **)((int)*in_ECX + 0x28c))(0x1e,0,0,0);
        }
      }
    }
  }
LAB_0072e8cb:
  iVar3 = FUN_00402060();
  if ((((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
      (iVar3 = FUN_00402060(), iVar3 == 8)) && (iVar3 = FUN_00402060(), iVar3 != 0x2e)) {
    uVar27 = 0x2e;
    (**(code **)((int)*in_ECX + 0x73c))(0x2e);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x2e,1,1), cVar2 != '\0')) {
      local_1ac = (void *)0x0;
      local_1a8 = 0;
      local_1a4 = 0;
      local_8 = 0x4f;
      local_18 = 2.8026e-45;
      FUN_00407120();
      local_18 = 6.44597e-44;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x1c,local_1b0,1,0);
      local_8 = 0xffffffff;
      if (local_1ac != (void *)0x0) {
        _free(local_1ac);
      }
      local_1ac = (void *)0x0;
      local_1a8 = 0;
      local_1a4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x1e) {
    if ((*(char *)(in_ECX + 0xced) == '\0') && (1 < *(int *)((int)in_ECX[0x41] + 0x124))) {
      *(undefined1 *)(in_ECX + 0xced) = 1;
      (**(code **)((int)*in_ECX + 0xf8))(2,in_ECX[0xcec],0,0,0,0,0,0,0);
    }
    if ((in_ECX[0xcec] != 0.0) && (*(char *)((int)in_ECX[0xcec] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0xfc))();
    }
    if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 0x1f;
    (**(code **)((int)*in_ECX + 0x73c))(0x1f);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x1f,1,1), cVar2 != '\0')) {
      local_1cc = (void *)0x0;
      local_1c8 = 0;
      local_1c4 = 0;
      local_8 = 0x50;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 4.34403e-44;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x1a,local_1d0,1,0);
      local_8 = 0xffffffff;
      if (local_1cc != (void *)0x0) {
        _free(local_1cc);
      }
      local_1cc = (void *)0x0;
      local_1c8 = 0;
      local_1c4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x1a) {
    if (in_ECX[0xca4] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
    else {
      iVar3 = FUN_00b06f00();
      if (((int)in_ECX[0xcaa] <= iVar3) && (in_ECX[0xcab] == 2.8026e-45)) {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 6) && (iVar3 = FUN_00402060(), iVar3 != 0)) {
    iVar3 = FUN_00402060();
    iVar10 = FUN_00402060();
    if (iVar10 < iVar3) {
      uVar27 = 0x31;
      (**(code **)((int)*in_ECX + 0x73c))(0x31);
      iVar3 = FUN_00559140(uVar27);
      if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x31,1,1), cVar2 != '\0')) {
        FUN_0048cf10();
        local_8 = 0x51;
        local_18 = 6.86636e-44;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(7,local_460,1,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 2;
    (**(code **)((int)*in_ECX + 0x73c))(2);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if ((((int *)in_ECX[0xbf2] == (int *)0x0) ||
          (cVar2 = (**(code **)(*(int *)in_ECX[0xbf2] + 0x60))(), cVar2 == '\0')) ||
         (iVar3 = FUN_005a9780(), iVar3 < 1)) {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(0x1b62,0xff9bc8e6,0x10,0);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
      else {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(2,1,1);
        if (cVar2 != '\0') {
          (**(code **)((int)*in_ECX + 0x28c))(0x26,0,1,0);
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x26) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if (((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) ||
     (iVar3 = FUN_00402060(), iVar3 == 8)) {
    uVar27 = 0x4d;
    (**(code **)((int)*in_ECX + 0x73c))(0x4d);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x4d,1,1), cVar2 != '\0')) {
      local_29c = (void *)0x0;
      local_298 = 0;
      local_294 = 0;
      local_8 = 0x52;
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x2a,local_2a0,1,0);
      local_8 = 0xffffffff;
      if (local_29c != (void *)0x0) {
        _free(local_29c);
      }
      local_29c = (void *)0x0;
      local_298 = 0;
      local_294 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x2a) {
    fVar9 = in_ECX[0xcc9];
    if (fVar9 == 0.0) {
      uVar27 = 0x4d;
      (**(code **)((int)*in_ECX + 0x73c))(0x4d);
      iVar3 = FUN_00559140(uVar27);
      if (iVar3 == -1) {
        piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
        cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
        if (cVar2 != '\0') goto LAB_0072ee62;
      }
      else {
LAB_0072ee62:
        if (2 < *(int *)((int)in_ECX[0x41] + 0x124)) {
          local_2bc = (void *)0x0;
          local_2b8 = 0;
          local_2b4 = 0;
          local_8 = 0x53;
          local_18 = 1.4013e-45;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x2a,local_2c0,1,0);
          local_8 = 0xffffffff;
          if (local_2bc != (void *)0x0) {
            _free(local_2bc);
          }
          local_2bc = (void *)0x0;
          local_2b8 = 0;
          local_2b4 = 0;
        }
      }
      bVar16 = *(char *)((int)in_ECX[0x41] + 0x13a) == '\0';
    }
    else if (fVar9 == 1.4013e-45) {
      iVar3 = (**(code **)((int)*in_ECX + 0x64c))();
      if (0 < iVar3) {
        uVar27 = 0x4d;
        (**(code **)((int)*in_ECX + 0x73c))(0x4d);
        iVar3 = FUN_00559140(uVar27);
        if (iVar3 == -1) {
          piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
          cVar2 = (**(code **)(*piVar8 + 0x48))(in_ECX + 0x68c);
          if (cVar2 == '\0') goto LAB_0072efa9;
        }
        if (2 < *(int *)((int)in_ECX[0x41] + 0x124)) {
          FUN_0048cf10();
          local_8 = 0x54;
          local_18 = 2.8026e-45;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x2a,local_470,1,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
LAB_0072efa9:
      bVar16 = *(char *)((int)in_ECX[0x41] + 0x13a) == '\0';
    }
    else {
      if (fVar9 != 2.8026e-45) goto LAB_0072efd9;
      bVar16 = *(char *)((int)in_ECX[0x41] + 0x13a) == '\0';
    }
    if (!bVar16) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
LAB_0072efd9:
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x51;
    (**(code **)((int)*in_ECX + 0x73c))(0x51);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if (((int *)in_ECX[0xc21] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc21] + 0x60))(), cVar2 == '\0')) {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar4 = 0xdf3;
LAB_0072f135:
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(uVar4,0x10ff9bc8e6,0);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
      else {
        uVar29 = 0;
        uVar27 = 0xcffffffff;
        uVar25 = 0xffffffff;
        uVar24 = 0x51;
        pfVar15 = in_ECX;
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x51);
        uVar22 = 3;
        uVar19 = 0x51;
        (**(code **)((int)*in_ECX + 0x67c))(0x51,3,uVar4);
        fVar9 = (float)FUN_00550080(uVar19,uVar22,uVar4,uVar24,pfVar15,uVar25,uVar27);
        local_18 = fVar9;
        iVar3 = (**(code **)((int)*in_ECX + 0x234))(uVar29);
        if ((int)fVar9 < iVar3) {
          cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x51,1,1);
          if (cVar2 != '\0') {
            fVar9 = *in_ECX;
            (**(code **)((int)fVar9 + 0x234))(1);
            (**(code **)((int)fVar9 + 1000))();
            FUN_0048cf10(0);
            local_8 = 0x55;
            local_18 = 0.0;
            FUN_00407120(&local_18);
            (**(code **)((int)*in_ECX + 0x28c))(0x2d,local_490,1,0,0);
            local_8 = 0xffffffff;
            FUN_00644d50();
          }
        }
        else {
          cVar2 = FUN_004cc7f0();
          if (cVar2 != '\0') {
            uVar4 = 0xe0f;
            goto LAB_0072f135;
          }
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x2d) {
    if (in_ECX[0xb1b] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_2dc = (void *)0x0;
        local_2d8 = 0;
        local_2d4 = 0;
        local_8 = 0x56;
        local_18 = 1.4013e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x2d,local_2e0,1,0);
        local_8 = 0xffffffff;
        if (local_2dc != (void *)0x0) {
          _free(local_2dc);
        }
        local_2dc = (void *)0x0;
        local_2d8 = 0;
        local_2d4 = 0;
      }
    }
    else if ((in_ECX[0xb1b] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = CONCAT44(in_ECX + 0x979,0x32);
    (**(code **)((int)*in_ECX + 0x73c))(0x32);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x32,1,1), cVar2 != '\0')) {
      local_1ec = (void *)0x0;
      local_1e8 = 0;
      local_1e4 = 0;
      local_8 = 0x57;
      local_18 = 0.0;
      FUN_00407120();
      local_18 = 0.0;
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x1b,local_1f0,1,0);
      local_8 = 0xffffffff;
      if (local_1ec != (void *)0x0) {
        _free(local_1ec);
      }
      local_1ec = (void *)0x0;
      local_1e8 = 0;
      local_1e4 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x1b) {
    fVar9 = in_ECX[0xcae];
    if (fVar9 == 0.0) {
      iVar3 = FUN_00b06f00();
      if ((int)in_ECX[0xcb5] <= iVar3) {
        local_12c = (void *)0x0;
        local_128 = 0;
        local_124 = 0;
        local_8 = 0x58;
        piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
        cVar2 = (**(code **)(*piVar8 + 0x38))();
        if ((cVar2 == '\0') || (iVar3 = (**(code **)((int)*in_ECX + 0x64c))(0x33), iVar3 < 1)) {
          local_18 = 2.8026e-45;
        }
        else {
          local_18 = 1.4013e-45;
        }
        FUN_00407120();
        local_18 = 0.0;
        FUN_00407120(&local_18);
        (**(code **)((int)*in_ECX + 0x28c))(0x1b,local_130,0,0,0);
        local_8 = 0xffffffff;
        if (local_12c != (void *)0x0) {
          _free(local_12c);
        }
        local_12c = (void *)0x0;
        local_128 = 0;
        local_124 = 0;
      }
    }
    else if (fVar9 == 1.4013e-45) {
      piVar8 = (int *)(**(code **)((int)*in_ECX + 0x738))();
      cVar2 = (**(code **)(*piVar8 + 0x38))();
      if (cVar2 == '\0') {
        FUN_0048cf10();
        local_8 = 0x59;
        local_18 = 2.8026e-45;
        FUN_00407120();
        local_18 = (float)FUN_00b06f00();
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x1b,local_420,1,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
    else if (fVar9 == 2.8026e-45) {
      if ((*(char *)(in_ECX + 0xcb6) == '\0') && (3 < *(int *)((int)in_ECX[0x41] + 0x124))) {
        local_14 = (float *)(**(code **)((int)*in_ECX + 0x67c))();
        local_24 = (int *)(**(code **)((int)*in_ECX + 0x64c))(0x32);
        iVar3 = (**(code **)((int)*in_ECX + 0x2c0))();
        uVar4 = FUN_00550080(0,local_24,in_ECX,0xffffffff,0xffffffff,0xc,0,0);
        *(undefined4 *)(iVar3 + 0x59) = uVar4;
        local_3c[1] = *(int **)(iVar3 + 0x12);
        local_34 = *(float **)(iVar3 + 0x16);
        uVar4 = (**(code **)((int)*in_ECX + 0x1d0))();
        local_28 = (float *)FUN_00550150(1,local_24,in_ECX,uVar4,uVar4,0);
        local_3d = '\0';
        local_30 = (float *)0x64;
        local_24 = (int *)FUN_0054ff60(0,in_ECX);
        if (0 < (int)in_ECX[0xcb0]) {
          uVar19 = 2;
          uVar4 = 0x33;
          (**(code **)((int)*in_ECX + 0x67c))(0x33,2);
          local_18 = (float)FUN_0054ff60(uVar4,uVar19);
          FUN_00b099b0(0x3f800000,(float)(int)local_18 * _DAT_00cc10ac);
          local_14 = (float *)(iVar3 + 0x12);
          local_30 = (float *)0x2;
          do {
            fVar9 = (float)FUN_00c01544();
            *local_14 = fVar9;
            local_14 = local_14 + 1;
            local_30 = (float *)((int)local_30 + -1);
          } while (local_30 != (float *)0x0);
          uVar26 = 0;
          uVar23 = 0;
          uVar21 = 0xc;
          uVar20 = 0xffffffff;
          uVar25 = 0xffffffff;
          uVar24 = 0x33;
          pfVar15 = in_ECX;
          uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x33);
          uVar22 = 0;
          uVar19 = 0x33;
          (**(code **)((int)*in_ECX + 0x67c))(0x33,0,uVar4);
          uVar4 = FUN_00550080(uVar19,uVar22,uVar4,uVar24,pfVar15,uVar25,uVar20,uVar21);
          iVar10 = FUN_00473f20(0,uVar4,in_ECX[0xcb0],in_ECX[0xcaf],uVar23,uVar26);
          local_28 = (float *)((int)local_28 + (iVar10 * (int)local_28) / 100);
          uVar19 = 1;
          uVar4 = 0x33;
          (**(code **)((int)*in_ECX + 0x67c))(0x33,1);
          uVar4 = FUN_0054ff60(uVar4,uVar19);
          local_30 = (float *)FUN_00473f20(100,uVar4);
          uVar19 = 3;
          uVar4 = 0x33;
          (**(code **)((int)*in_ECX + 0x67c))(0x33,3);
          uVar4 = FUN_0054ff60(uVar4,uVar19);
          local_24 = (int *)FUN_00473f20(local_24,uVar4);
          local_3d = (int)in_ECX[0xcaf] <= (int)in_ECX[0xcb0];
        }
        DAT_00f5478c = 0;
        FUN_004e2780(local_30);
        FUN_004e2780(local_24);
        (**(code **)((int)*in_ECX + 0x2b8))
                  ((-(uint)(local_3d != '\0') & 0xfffffff5) + 0x4e33,local_28,iVar3,0,0x50,0,0,4,0,
                   DAT_00f5478c,DAT_00f54788,0,0);
        *(int **)(iVar3 + 0x12) = local_3c[1];
        *(float **)(iVar3 + 0x16) = local_34;
        *(undefined1 *)(in_ECX + 0xcb6) = 1;
      }
      if (0x10 < *(int *)((int)in_ECX[0x41] + 0x124)) {
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x34;
    (**(code **)((int)*in_ECX + 0x73c))(0x34);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if (((int *)in_ECX[0xc1f] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc1f] + 0x60))(), cVar2 == '\0')) {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x34,1,1);
        if (cVar2 != '\0') {
          local_2fc = (void *)0x0;
          local_2f8 = 0;
          local_2f4 = 0;
          local_8 = 0x5a;
          local_18 = 7.28675e-44;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0xe,local_300,1,0);
          local_8 = 0xffffffff;
          if (local_2fc != (void *)0x0) {
            _free(local_2fc);
          }
          local_2fc = (void *)0x0;
          local_2f8 = 0;
          local_2f4 = 0;
        }
      }
      else {
        (**(code **)((int)*in_ECX + 0x768))(0x34,1,0);
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    cVar2 = FUN_0071cea0();
    uVar27 = 0x55;
    if (cVar2 == '\0') {
      (**(code **)((int)*in_ECX + 0x73c))(0x55);
      iVar3 = FUN_00559140(uVar27);
      if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x55,1,1), cVar2 != '\0')) {
        (**(code **)((int)*in_ECX + 0x67c))();
        FUN_0048cf10(0);
        local_8 = 0x5b;
        local_18 = 0.0;
        FUN_00407120(&local_18);
        local_18 = 0.0;
        FUN_00407120(&local_18);
        local_18 = 1.1911e-43;
        FUN_00407120(&local_18);
        local_18 = (float)FUN_0054ff60();
        FUN_00407120(&local_18);
        local_18 = (float)FUN_0054ff60();
        FUN_00407120(&local_18);
        local_18 = 1.4013e-45;
        FUN_00407120(&local_18);
        local_18 = 4.2039e-45;
        FUN_00407120(&local_18);
        local_18 = 4.2039e-45;
        FUN_00407120(&local_18);
        (**(code **)((int)*in_ECX + 0x28c))(10,local_140,1,0,0);
        local_8 = 0xffffffff;
        FUN_00644d50();
      }
    }
    else {
      (**(code **)((int)*in_ECX + 0x73c))();
      iVar3 = FUN_00559140(uVar27);
      if ((iVar3 != -1) ||
         (fVar9 = in_ECX[0xc35], iVar3 = FUN_00b06f00(), *(int *)((int)fVar9 + 0x7c) <= iVar3)) {
        (**(code **)((int)*in_ECX + 0x28c))(0x2e,0,1,0);
      }
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x2e) {
    if ((int *)in_ECX[0xc3b] == (int *)0x0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
LAB_0072f9f1:
        (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
      }
    }
    else {
      iVar3 = (**(code **)(*(int *)in_ECX[0xc3b] + 0x230))();
      if (iVar3 == 4) {
        iVar3 = (**(code **)(*(int *)in_ECX[0xc3b] + 0xf4))();
        if (*(int *)(iVar3 + 0x188) == 0) {
          iVar3 = *(int *)(iVar3 + 0x8c);
        }
        else {
          iVar3 = FUN_004caa00();
        }
        if (199 < iVar3) goto LAB_0072f9f1;
      }
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x56;
    (**(code **)((int)*in_ECX + 0x73c))(0x56);
    iVar3 = FUN_00559140(uVar27);
    if ((iVar3 != -1) && (cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x56,1,1), cVar2 != '\0')) {
      local_31c = (void *)0x0;
      local_318 = 0;
      local_314 = 0;
      local_8 = 0x5c;
      local_18 = (float)(**(code **)((int)*in_ECX + 0xc0))();
      FUN_00407120();
      (**(code **)((int)*in_ECX + 0x28c))(0x2f,local_320,1,0);
      local_8 = 0xffffffff;
      if (local_31c != (void *)0x0) {
        _free(local_31c);
      }
      local_31c = (void *)0x0;
      local_318 = 0;
      local_314 = 0;
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x2f) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0x30,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x30) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    if (in_ECX[0xc5d] == 3.22299e-44) {
      (**(code **)((int)*in_ECX + 0x28c))(0x31);
    }
    else {
      (**(code **)((int)*in_ECX + 0x28c))(0x30,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0x31) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x57;
    (**(code **)((int)*in_ECX + 0x73c))(0x57);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      pfVar15 = in_ECX;
      (**(code **)((int)*in_ECX + 0x67c))();
      local_14 = (float *)FUN_0054ff60();
      uVar29 = CONCAT44(pfVar15,in_ECX);
      uVar27 = 0x200000057;
      (**(code **)((int)*in_ECX + 0x67c))(0x57,2);
      iVar3 = FUN_0054ff60(uVar27);
      local_24 = (int *)(iVar3 / 2);
      iVar3 = (**(code **)((int)*in_ECX + 0xc0))(uVar29);
      if (iVar3 == 0) {
        local_18 = (float)FUN_008ac050();
        (**(code **)((int)*in_ECX + 0x94))();
      }
      else {
        FUN_008ac050();
        (**(code **)((int)*in_ECX + 0x94))();
      }
      (**(code **)((int)*in_ECX + 0x98))(local_24,0);
      iVar3 = FUN_00611b20();
      if (iVar3 < (int)local_14) {
        cVar2 = FUN_004cc7f0();
        if (cVar2 != '\0') {
          uVar29 = 0;
          uVar27 = 0x10ff9bc8e6;
          uVar4 = FUN_00a51240(11000,local_14,0xff9bc8e6,0x10,0);
          uVar4 = FUN_00a52aa0(0,uVar4);
          FUN_009bc710(uVar4,uVar27,uVar29);
        }
      }
      else {
        cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x57,1,1);
        if (cVar2 != '\0') {
          FUN_0048cf10();
          local_8 = 0x5d;
          local_18 = 0.0;
          FUN_00407120();
          (**(code **)((int)*in_ECX + 0x28c))(0x32,local_450,1,0);
          local_8 = 0xffffffff;
          FUN_00644d50();
        }
      }
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x32) {
    if (in_ECX[0xc97] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_33c = (void *)0x0;
        local_338 = 0;
        local_334 = 0;
        local_8 = 0x5e;
        local_18 = 1.4013e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x32,local_340,0,0);
        local_8 = 0xffffffff;
        if (local_33c != (void *)0x0) {
          _free(local_33c);
        }
        local_33c = (void *)0x0;
        local_338 = 0;
        local_334 = 0;
      }
    }
    else if ((in_ECX[0xc97] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x58;
    (**(code **)((int)*in_ECX + 0x73c))(0x58);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if (((int *)in_ECX[0xc9b] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc9b] + 0x60))(), cVar2 == '\0')) {
        if (((int *)in_ECX[0xc1f] == (int *)0x0) ||
           (cVar2 = (**(code **)(*(int *)in_ECX[0xc1f] + 0x60))(), cVar2 == '\0')) {
          cVar2 = FUN_004cc7f0();
          if (cVar2 != '\0') {
            uVar29 = 0;
            uVar27 = 0x10ff9bc8e6;
            uVar4 = FUN_00a51240(0x2af9,0xff9bc8e6,0x10,0);
            FUN_009bc710(uVar4,uVar27,uVar29);
          }
        }
        else {
          cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x58,1,1);
          if (cVar2 != '\0') {
            FUN_0048cf10();
            local_8 = 0x5f;
            local_18 = 0.0;
            FUN_00407120();
            (**(code **)((int)*in_ECX + 0x28c))(0x33,local_4b8,1,0);
            local_8 = 0xffffffff;
            FUN_00644d50();
          }
        }
      }
      else {
        FUN_005a7a10();
      }
    }
  }
  iVar3 = FUN_00402060();
  if (iVar3 == 0x33) {
    if (in_ECX[0xc9a] == 0.0) {
      if (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0') {
        local_22c = (void *)0x0;
        local_228 = 0;
        local_224 = 0;
        local_8 = 0x60;
        local_18 = 1.4013e-45;
        FUN_00407120();
        (**(code **)((int)*in_ECX + 0x28c))(0x33,local_230,0,0);
        local_8 = 0xffffffff;
        if (local_22c != (void *)0x0) {
          _free(local_22c);
        }
        local_22c = (void *)0x0;
        local_228 = 0;
        local_224 = 0;
      }
    }
    else if ((in_ECX[0xc9a] == 1.4013e-45) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
      (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0,0);
    }
  }
  iVar3 = FUN_00402060();
  if ((((iVar3 == 0x34) || (iVar3 = FUN_00402060(), iVar3 == 0x35)) ||
      (iVar3 = FUN_00402060(), iVar3 == 0x36)) && (*(char *)((int)in_ECX[0x41] + 0x13a) != '\0')) {
    (**(code **)((int)*in_ECX + 0x28c))(0,0,0,0,0);
  }
  iVar3 = FUN_00402060();
  if ((iVar3 == 0) || (iVar3 = FUN_00402060(), iVar3 == 0xb)) {
    uVar27 = 0x4c;
    (**(code **)((int)*in_ECX + 0x73c))(0x4c,0);
    iVar3 = FUN_00559140(uVar27);
    if (iVar3 != -1) {
      if (((int *)in_ECX[0xc21] == (int *)0x0) ||
         (cVar2 = (**(code **)(*(int *)in_ECX[0xc21] + 0x60))(), cVar2 == '\0')) {
        uVar29 = 0;
        uVar27 = 0xcffffffff;
        uVar25 = 0xffffffff;
        uVar24 = 0x4c;
        pfVar15 = in_ECX;
        uVar4 = (**(code **)((int)*in_ECX + 0x64c))(0x4c);
        uVar22 = 0;
        uVar19 = 0x4c;
        (**(code **)((int)*in_ECX + 0x67c))(0x4c,0,uVar4);
        fVar9 = (float)FUN_00550080(uVar19,uVar22,uVar4,uVar24,pfVar15,uVar25,uVar27);
        local_18 = fVar9;
        iVar3 = (**(code **)((int)*in_ECX + 0x234))(uVar29);
        if ((int)fVar9 + 1 < iVar3) {
          cVar2 = (**(code **)((int)*in_ECX + 0x768))(0x4c,1,1,1);
          if (cVar2 != '\0') {
            fVar9 = *in_ECX;
            iVar3 = (**(code **)((int)fVar9 + 0x234))(1,0);
            (**(code **)((int)fVar9 + 1000))(iVar3 - (int)local_18);
            FUN_0048cf10(0);
            local_8 = 0x61;
            local_18 = 0.0;
            FUN_00407120(&local_18);
            local_18 = 0.0;
            FUN_00407120(&local_18);
            local_18 = 1.06499e-43;
            FUN_00407120(&local_18);
            (**(code **)((int)*in_ECX + 0x64c))(0x4c);
            uVar4 = 0x4c;
            pfVar15 = in_ECX;
            (**(code **)((int)*in_ECX + 0x67c))(0x4c);
            local_18 = (float)FUN_00468430(uVar4,pfVar15);
            FUN_00407120(&local_18);
            uVar19 = 0;
            uVar4 = 0x4c;
            (**(code **)((int)*in_ECX + 0x67c))(0x4c,0);
            local_18 = (float)FUN_0054ff60(uVar4,uVar19);
            FUN_00407120(&local_18);
            local_18 = 0.0;
            FUN_00407120(&local_18);
            local_18 = 5.60519e-45;
            FUN_00407120(&local_18);
            local_18 = 5.60519e-45;
            FUN_00407120(&local_18);
            (**(code **)((int)*in_ECX + 0x28c))(10,local_150,1,0,0);
            FUN_00644d50();
            *unaff_FS_OFFSET = local_10;
            return;
          }
          goto LAB_0073026f;
        }
        cVar2 = FUN_004cc7f0();
        if (cVar2 == '\0') goto LAB_0073026f;
        uVar27 = 0;
        uVar19 = 0x10;
        uVar4 = 0xff9bc8e6;
        puVar13 = (undefined1 *)FUN_00a51240(0xe0f,0xff9bc8e6,0x10,0,0);
      }
      else {
        uVar29 = CONCAT44(in_ECX,1);
        uVar27 = 0x4c007301d9;
        (**(code **)((int)*in_ECX + 0x67c))();
        fVar9 = (float)FUN_0054ff60(uVar27);
        local_18 = fVar9;
        iVar3 = FUN_00b06f00(uVar29);
        if ((int)fVar9 <= iVar3) {
          (**(code **)((int)*in_ECX + 0x768))(0x4c,1,0,0);
          *unaff_FS_OFFSET = local_10;
          return;
        }
        cVar2 = FUN_004cc7f0();
        if (cVar2 == '\0') goto LAB_0073026f;
        uVar4 = FUN_00a51240(0xdf2,(double)((float)(int)local_18 * _DAT_00cc11f8));
        FUN_00401df0(local_7a8,0x100,uVar4);
        uVar27 = 0;
        uVar19 = 0x10;
        uVar4 = 0xff9bc8e6;
        puVar13 = local_7a8;
      }
      FUN_009bc710(puVar13,uVar4,uVar19,uVar27);
    }
  }
LAB_0073026f:
  *unaff_FS_OFFSET = local_10;
  return;
}

