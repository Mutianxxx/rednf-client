0071ec70  55                       push       ebp
0071ec71  8bec                     mov        ebp, esp
0071ec73  56                       push       esi
0071ec74  8bf1                     mov        esi, ecx
0071ec76  8d8ea82a0000             lea        ecx, [esi + 0x2aa8]
0071ec7c  e8df33ceff               call       0x402060
0071ec81  83f843                   cmp        eax, 0x43
0071ec84  751c                     jne        0x71eca2
0071ec86  8b06                     mov        eax, dword ptr [esi]
0071ec88  8bce                     mov        ecx, esi
0071ec8a  ff9020060000             call       dword ptr [eax + 0x620]
0071ec90  8b4d08                   mov        ecx, dword ptr [ebp + 8]
0071ec93  8d1481                   lea        edx, [ecx + eax*4]
0071ec96  8b04951898d700           mov        eax, dword ptr [edx*4 + 0xd79818]
0071ec9d  5e                       pop        esi
0071ec9e  5d                       pop        ebp
0071ec9f  c20400                   ret        4
0071eca2  8a8690300000             mov        al, byte ptr [esi + 0x3090]
0071eca8  84c0                     test       al, al
0071ecaa  740f                     je         0x71ecbb
0071ecac  8b4508                   mov        eax, dword ptr [ebp + 8]
0071ecaf  8b0485b098d700           mov        eax, dword ptr [eax*4 + 0xd798b0]
0071ecb6  5e                       pop        esi
0071ecb7  5d                       pop        ebp
0071ecb8  c20400                   ret        4
0071ecbb  8b8ea4240000             mov        ecx, dword ptr [esi + 0x24a4]
0071ecc1  8b5508                   mov        edx, dword ptr [ebp + 8]
0071ecc4  8d0491                   lea        eax, [ecx + edx*4]
0071ecc7  8b00                     mov        eax, dword ptr [eax]
0071ecc9  5e                       pop        esi
0071ecca  5d                       pop        ebp
0071eccb  c20400                   ret        4
0071ecce  cc                       int3       
0071eccf  cc                       int3       
0071ecd0  55                       push       ebp
0071ecd1  8bec                     mov        ebp, esp
0071ecd3  83ec18                   sub        esp, 0x18
0071ecd6  8b4508                   mov        eax, dword ptr [ebp + 8]
0071ecd9  85c0                     test       eax, eax
0071ecdb  56                       push       esi
0071ecdc  57                       push       edi
0071ecdd  8bf9                     mov        edi, ecx
0071ecdf  897de8                   mov        dword ptr [ebp - 0x18], edi
0071ece2  7406                     je         0x71ecea
0071ece4  c700ffffffff             mov        dword ptr [eax], 0xffffffff
0071ecea  8b07                     mov        eax, dword ptr [edi]
0071ecec  33f6                     xor        esi, esi
0071ecee  6a35                     push       0x35
0071ecf0  8bcf                     mov        ecx, edi
0071ecf2  8975fc                   mov        dword ptr [ebp - 4], esi
0071ecf5  ff904c060000             call       dword ptr [eax + 0x64c]
0071ecfb  85c0                     test       eax, eax
0071ecfd  0f8e1a010000             jle        0x71ee1d
0071ed03  53                       push       ebx
0071ed04  33db                     xor        ebx, ebx
0071ed06  8b8fdc120000             mov        ecx, dword ptr [edi + 0x12dc]
0071ed0c  8b5104                   mov        edx, dword ptr [ecx + 4]
0071ed0f  85d2                     test       edx, edx
0071ed11  895df8                   mov        dword ptr [ebp - 8], ebx
0071ed14  7504                     jne        0x71ed1a
0071ed16  33c0                     xor        eax, eax
0071ed18  eb08                     jmp        0x71ed22
0071ed1a  8b4108                   mov        eax, dword ptr [ecx + 8]
0071ed1d  2bc2                     sub        eax, edx
0071ed1f  c1f802                   sar        eax, 2
0071ed22  3bd8                     cmp        ebx, eax
0071ed24  0f8de7000000             jge        0x71ee11
0071ed2a  8b5104                   mov        edx, dword ptr [ecx + 4]
0071ed2d  85d2                     test       edx, edx
0071ed2f  7411                     je         0x71ed42
0071ed31  8b4108                   mov        eax, dword ptr [ecx + 8]
0071ed34  2bc2                     sub        eax, edx
0071ed36  c1f802                   sar        eax, 2
0071ed39  3bd8                     cmp        ebx, eax
0071ed3b  7305                     jae        0x71ed42
0071ed3d  8b149a                   mov        edx, dword ptr [edx + ebx*4]
0071ed40  eb02                     jmp        0x71ed44
0071ed42  33d2                     xor        edx, edx
0071ed44  6a00                     push       0
0071ed46  68a852f500               push       0xf552a8
0071ed4b  68f451f500               push       0xf551f4
0071ed50  6a00                     push       0
0071ed52  52                       push       edx
0071ed53  e8b31f4e00               call       0xc00d0b
0071ed58  8bf0                     mov        esi, eax
0071ed5a  83c414                   add        esp, 0x14
0071ed5d  85f6                     test       esi, esi
0071ed5f  0f84a6000000             je         0x71ee0b
0071ed65  837e6c10                 cmp        dword ptr [esi + 0x6c], 0x10
0071ed69  0f859c000000             jne        0x71ee0b
0071ed6f  8b4dfc                   mov        ecx, dword ptr [ebp - 4]
0071ed72  8b4508                   mov        eax, dword ptr [ebp + 8]
0071ed75  41                       inc        ecx
0071ed76  85c0                     test       eax, eax
0071ed78  894dfc                   mov        dword ptr [ebp - 4], ecx
0071ed7b  0f848a000000             je         0x71ee0b
0071ed81  8bc8                     mov        ecx, eax
0071ed83  8b11                     mov        edx, dword ptr [ecx]
0071ed85  8b06                     mov        eax, dword ptr [esi]
0071ed87  8d5e08                   lea        ebx, [esi + 8]
0071ed8a  8bce                     mov        ecx, esi
0071ed8c  83c760                   add        edi, 0x60
0071ed8f  895dec                   mov        dword ptr [ebp - 0x14], ebx
0071ed92  8955f0                   mov        dword ptr [ebp - 0x10], edx
0071ed95  ff5050                   call       dword ptr [eax + 0x50]
0071ed98  8bc8                     mov        ecx, eax
0071ed9a  83c14c                   add        ecx, 0x4c
0071ed9d  e8be32ceff               call       0x402060
0071eda2  8bcb                     mov        ecx, ebx
0071eda4  8945f4                   mov        dword ptr [ebp - 0xc], eax
0071eda7  e854813e00               call       0xb06f00
0071edac  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
0071edaf  2bc8                     sub        ecx, eax
0071edb1  894df4                   mov        dword ptr [ebp - 0xc], ecx
0071edb4  8bcf                     mov        ecx, edi
0071edb6  e845813e00               call       0xb06f00
0071edbb  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
0071edbe  03c8                     add        ecx, eax
0071edc0  8b45f0                   mov        eax, dword ptr [ebp - 0x10]
0071edc3  3bc1                     cmp        eax, ecx
0071edc5  7e13                     jle        0x71edda
0071edc7  8b5df8                   mov        ebx, dword ptr [ebp - 8]
0071edca  8b7de8                   mov        edi, dword ptr [ebp - 0x18]
0071edcd  8bf0                     mov        esi, eax
0071edcf  8b4508                   mov        eax, dword ptr [ebp + 8]
0071edd2  8930                     mov        dword ptr [eax], esi
0071edd4  43                       inc        ebx
0071edd5  e92cffffff               jmp        0x71ed06
0071edda  8b16                     mov        edx, dword ptr [esi]
0071eddc  8bce                     mov        ecx, esi
0071edde  ff5250                   call       dword ptr [edx + 0x50]
0071ede1  8bc8                     mov        ecx, eax
0071ede3  83c14c                   add        ecx, 0x4c
0071ede6  e87532ceff               call       0x402060
0071edeb  8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
0071edee  8bf0                     mov        esi, eax
0071edf0  e80b813e00               call       0xb06f00
0071edf5  8bcf                     mov        ecx, edi
0071edf7  2bf0                     sub        esi, eax
0071edf9  e802813e00               call       0xb06f00
0071edfe  8b7de8                   mov        edi, dword ptr [ebp - 0x18]
0071ee01  8b5df8                   mov        ebx, dword ptr [ebp - 8]
0071ee04  03f0                     add        esi, eax
0071ee06  8b4508                   mov        eax, dword ptr [ebp + 8]
0071ee09  8930                     mov        dword ptr [eax], esi
0071ee0b  43                       inc        ebx
0071ee0c  e9f5feffff               jmp        0x71ed06
0071ee11  8b45fc                   mov        eax, dword ptr [ebp - 4]
0071ee14  5b                       pop        ebx
0071ee15  5f                       pop        edi
0071ee16  5e                       pop        esi
0071ee17  8be5                     mov        esp, ebp
0071ee19  5d                       pop        ebp
0071ee1a  c20400                   ret        4
0071ee1d  5f                       pop        edi
0071ee1e  8bc6                     mov        eax, esi
0071ee20  5e                       pop        esi
0071ee21  8be5                     mov        esp, ebp
0071ee23  5d                       pop        ebp
0071ee24  c20400                   ret        4
0071ee27  cc                       int3       
0071ee28  cc                       int3       
0071ee29  cc                       int3       
0071ee2a  cc                       int3       
0071ee2b  cc                       int3       
0071ee2c  cc                       int3       
0071ee2d  cc                       int3       
0071ee2e  cc                       int3       
0071ee2f  cc                       int3       
0071ee30  53                       push       ebx
0071ee31  8bd9                     mov        ebx, ecx
0071ee33  8b83782b0000             mov        eax, dword ptr [ebx + 0x2b78]
0071ee39  85c0                     test       eax, eax
0071ee3b  0f84f2000000             je         0x71ef33
0071ee41  8a83602b0000             mov        al, byte ptr [ebx + 0x2b60]
0071ee47  84c0                     test       al, al
0071ee49  0f85e4000000             jne        0x71ef33
0071ee4f  83bb682b0000ff           cmp        dword ptr [ebx + 0x2b68], -1
0071ee56  7424                     je         0x71ee7c
0071ee58  8d8ba0000000             lea        ecx, [ebx + 0xa0]
0071ee5e  e89d803e00               call       0xb06f00
0071ee63  8b8b682b0000             mov        ecx, dword ptr [ebx + 0x2b68]
0071ee69  81c1d0070000             add        ecx, 0x7d0
0071ee6f  3bc1                     cmp        eax, ecx
0071ee71  7c09                     jl         0x71ee7c
0071ee73  c683602b000001           mov        byte ptr [ebx + 0x2b60], 1
0071ee7a  5b                       pop        ebx
0071ee7b  c3                       ret        
0071ee7c  8b83742b0000             mov        eax, dword ptr [ebx + 0x2b74]
0071ee82  57                       push       edi
0071ee83  8b38                     mov        edi, dword ptr [eax]
0071ee85  3bf8                     cmp        edi, eax
0071ee87  0f84a5000000             je         0x71ef32
0071ee8d  56                       push       esi
0071ee8e  8bff                     mov        edi, edi
0071ee90  8b7708                   mov        esi, dword ptr [edi + 8]
0071ee93  56                       push       esi
0071ee94  8bcb                     mov        ecx, ebx
0071ee96  e8a5c9ffff               call       0x71b840
0071ee9b  84c0                     test       al, al
0071ee9d  8b470c                   mov        eax, dword ptr [edi + 0xc]
0071eea0  0f848f000000             je         0x71ef35
0071eea6  85c0                     test       eax, eax
0071eea8  0f8492000000             je         0x71ef40
0071eeae  8bcb                     mov        ecx, ebx
0071eeb0  e8dbd1d7ff               call       0x49c090
0071eeb5  84c0                     test       al, al
0071eeb7  7471                     je         0x71ef2a
0071eeb9  c7058c47f50000000000     mov        dword ptr [0xf5478c], 0
0071eec3  8b16                     mov        edx, dword ptr [esi]
0071eec5  8bce                     mov        ecx, esi
0071eec7  ff523c                   call       dword ptr [edx + 0x3c]
0071eeca  50                       push       eax
0071eecb  b98447f500               mov        ecx, 0xf54784
0071eed0  e8ab38dcff               call       0x4e2780
0071eed5  8b06                     mov        eax, dword ptr [esi]
0071eed7  8bce                     mov        ecx, esi
0071eed9  ff5040                   call       dword ptr [eax + 0x40]
0071eedc  50                       push       eax
0071eedd  b98447f500               mov        ecx, 0xf54784
0071eee2  e89938dcff               call       0x4e2780
0071eee7  8b0d8847f500             mov        ecx, dword ptr [0xf54788]
0071eeed  8b158c47f500             mov        edx, dword ptr [0xf5478c]
0071eef3  8b06                     mov        eax, dword ptr [esi]
0071eef5  6a00                     push       0
0071eef7  6a00                     push       0
0071eef9  51                       push       ecx
0071eefa  52                       push       edx
0071eefb  6a00                     push       0
0071eefd  6a04                     push       4
0071eeff  6a00                     push       0
0071ef01  8bce                     mov        ecx, esi
0071ef03  ff9098000000             call       dword ptr [eax + 0x98]
0071ef09  8b16                     mov        edx, dword ptr [esi]
0071ef0b  50                       push       eax
0071ef0c  8bce                     mov        ecx, esi
0071ef0e  ff9294000000             call       dword ptr [edx + 0x94]
0071ef14  50                       push       eax
0071ef15  8b83642b0000             mov        eax, dword ptr [ebx + 0x2b64]
0071ef1b  50                       push       eax
0071ef1c  68c65d0000               push       0x5dc6
0071ef21  53                       push       ebx
0071ef22  e879afdcff               call       0x4e9ea0
0071ef27  83c430                   add        esp, 0x30
0071ef2a  c683602b000001           mov        byte ptr [ebx + 0x2b60], 1
0071ef31  5e                       pop        esi
0071ef32  5f                       pop        edi
0071ef33  5b                       pop        ebx
0071ef34  c3                       ret        
0071ef35  85c0                     test       eax, eax
0071ef37  7507                     jne        0x71ef40
0071ef39  c7470c01000000           mov        dword ptr [edi + 0xc], 1
0071ef40  8b3f                     mov        edi, dword ptr [edi]
0071ef42  3bbb742b0000             cmp        edi, dword ptr [ebx + 0x2b74]
0071ef48  0f8542ffffff             jne        0x71ee90
0071ef4e  5e                       pop        esi
0071ef4f  5f                       pop        edi
0071ef50  5b                       pop        ebx
0071ef51  c3                       ret        
0071ef52  cc                       int3       
0071ef53  cc                       int3       
0071ef54  cc                       int3       
0071ef55  cc                       int3       
0071ef56  cc                       int3       
0071ef57  cc                       int3       
0071ef58  cc                       int3       
0071ef59  cc                       int3       
0071ef5a  cc                       int3       
0071ef5b  cc                       int3       
0071ef5c  cc                       int3       
0071ef5d  cc                       int3       
0071ef5e  cc                       int3       
0071ef5f  cc                       int3       
0071ef60  55                       push       ebp
0071ef61  8bec                     mov        ebp, esp
0071ef63  83ec10                   sub        esp, 0x10
0071ef66  53                       push       ebx
0071ef67  56                       push       esi
0071ef68  57                       push       edi
0071ef69  8bf9                     mov        edi, ecx
0071ef6b  8b07                     mov        eax, dword ptr [edi]
0071ef6d  6a3e                     push       0x3e
0071ef6f  ff907c060000             call       dword ptr [eax + 0x67c]
0071ef75  57                       push       edi
0071ef76  6a03                     push       3
0071ef78  8bc8                     mov        ecx, eax
0071ef7a  8945fc                   mov        dword ptr [ebp - 4], eax
0071ef7d  e8de0fe3ff               call       0x54ff60
0071ef82  99                       cdq        
0071ef83  2bc2                     sub        eax, edx
0071ef85  d1f8                     sar        eax, 1
0071ef87  33db                     xor        ebx, ebx
0071ef89  8945f0                   mov        dword ptr [ebp - 0x10], eax
0071ef8c  895df8                   mov        dword ptr [ebp - 8], ebx
0071ef8f  8b8f00010000             mov        ecx, dword ptr [edi + 0x100]
0071ef95  8b9190000000             mov        edx, dword ptr [ecx + 0x90]
0071ef9b  85d2                     test       edx, edx
0071ef9d  895df4                   mov        dword ptr [ebp - 0xc], ebx
0071efa0  7504                     jne        0x71efa6
0071efa2  33c0                     xor        eax, eax
0071efa4  eb0b                     jmp        0x71efb1
0071efa6  8b8194000000             mov        eax, dword ptr [ecx + 0x94]
0071efac  2bc2                     sub        eax, edx
0071efae  c1f802                   sar        eax, 2
0071efb1  3bd8                     cmp        ebx, eax
0071efb3  0f8df6000000             jge        0x71f0af
0071efb9  8b9190000000             mov        edx, dword ptr [ecx + 0x90]
0071efbf  85d2                     test       edx, edx
0071efc1  7419                     je         0x71efdc
0071efc3  8b8194000000             mov        eax, dword ptr [ecx + 0x94]
0071efc9  2bc2                     sub        eax, edx
0071efcb  c1f802                   sar        eax, 2
0071efce  3bd8                     cmp        ebx, eax
0071efd0  730a                     jae        0x71efdc
0071efd2  8bca                     mov        ecx, edx
0071efd4  8b3499                   mov        esi, dword ptr [ecx + ebx*4]
0071efd7  8d0499                   lea        eax, [ecx + ebx*4]
0071efda  eb02                     jmp        0x71efde
0071efdc  33f6                     xor        esi, esi
0071efde  56                       push       esi
0071efdf  8bcf                     mov        ecx, edi
0071efe1  e8ea9bdcff               call       0x4e8bd0
0071efe6  84c0                     test       al, al
0071efe8  0f84bb000000             je         0x71f0a9
0071efee  8b16                     mov        edx, dword ptr [esi]
0071eff0  6a11                     push       0x11
0071eff2  8bce                     mov        ecx, esi
0071eff4  ff522c                   call       dword ptr [edx + 0x2c]
0071eff7  84c0                     test       al, al
0071eff9  0f84aa000000             je         0x71f0a9
0071efff  8b07                     mov        eax, dword ptr [edi]
0071f001  6a00                     push       0
0071f003  56                       push       esi
0071f004  8bcf                     mov        ecx, edi
0071f006  ff5008                   call       dword ptr [eax + 8]
0071f009  3b45f0                   cmp        eax, dword ptr [ebp - 0x10]
0071f00c  0f8f97000000             jg         0x71f0a9
0071f012  8b16                     mov        edx, dword ptr [esi]
0071f014  8bce                     mov        ecx, esi
0071f016  ff92dc030000             call       dword ptr [edx + 0x3dc]
0071f01c  84c0                     test       al, al
0071f01e  0f8585000000             jne        0x71f0a9
0071f024  8b06                     mov        eax, dword ptr [esi]
0071f026  6811020000               push       0x211
0071f02b  8bce                     mov        ecx, esi
0071f02d  bb01000000               mov        ebx, 1
0071f032  ff502c                   call       dword ptr [eax + 0x2c]
0071f035  f6d8                     neg        al
0071f037  1bc0                     sbb        eax, eax
0071f039  23c6                     and        eax, esi
0071f03b  8bc8                     mov        ecx, eax
0071f03d  7420                     je         0x71f05f
0071f03f  8a811c1e0000             mov        al, byte ptr [ecx + 0x1e1c]
0071f045  84c0                     test       al, al
0071f047  7405                     je         0x71f04e
0071f049  57                       push       edi
0071f04a  6a08                     push       8
0071f04c  eb46                     jmp        0x71f094
0071f04e  8b11                     mov        edx, dword ptr [ecx]
0071f050  ff9208060000             call       dword ptr [edx + 0x608]
0071f056  84c0                     test       al, al
0071f058  7405                     je         0x71f05f
0071f05a  57                       push       edi
0071f05b  6a06                     push       6
0071f05d  eb35                     jmp        0x71f094
0071f05f  8b86e4190000             mov        eax, dword ptr [esi + 0x19e4]
0071f065  83f803                   cmp        eax, 3
0071f068  7405                     je         0x71f06f
0071f06a  83f808                   cmp        eax, 8
0071f06d  7505                     jne        0x71f074
0071f06f  57                       push       edi
0071f070  6a07                     push       7
0071f072  eb20                     jmp        0x71f094
0071f074  8bce                     mov        ecx, esi
0071f076  e875dad7ff               call       0x49caf0
0071f07b  84c0                     test       al, al
0071f07d  7405                     je         0x71f084
0071f07f  57                       push       edi
0071f080  6a05                     push       5
0071f082  eb10                     jmp        0x71f094
0071f084  6a12                     push       0x12
0071f086  8bce                     mov        ecx, esi
0071f088  e8738fd4ff               call       0x468000
0071f08d  84c0                     test       al, al
0071f08f  740d                     je         0x71f09e
0071f091  57                       push       edi
0071f092  6a09                     push       9
0071f094  8b4dfc                   mov        ecx, dword ptr [ebp - 4]
0071f097  e8c40ee3ff               call       0x54ff60
0071f09c  8bd8                     mov        ebx, eax
0071f09e  8b45f8                   mov        eax, dword ptr [ebp - 8]
0071f0a1  03c3                     add        eax, ebx
0071f0a3  8b5df4                   mov        ebx, dword ptr [ebp - 0xc]
0071f0a6  8945f8                   mov        dword ptr [ebp - 8], eax
0071f0a9  43                       inc        ebx
0071f0aa  e9e0feffff               jmp        0x71ef8f
0071f0af  8b45f8                   mov        eax, dword ptr [ebp - 8]
0071f0b2  5f                       pop        edi
0071f0b3  5e                       pop        esi
0071f0b4  5b                       pop        ebx
0071f0b5  8be5                     mov        esp, ebp
0071f0b7  5d                       pop        ebp
0071f0b8  c3                       ret        
0071f0b9  cc                       int3       
0071f0ba  cc                       int3       
0071f0bb  cc                       int3       
0071f0bc  cc                       int3       
0071f0bd  cc                       int3       
0071f0be  cc                       int3       
0071f0bf  cc                       int3       
0071f0c0  56                       push       esi
0071f0c1  8bf1                     mov        esi, ecx
0071f0c3  8b867c300000             mov        eax, dword ptr [esi + 0x307c]
0071f0c9  85c0                     test       eax, eax
0071f0cb  7435                     je         0x71f102
0071f0cd  8bc8                     mov        ecx, eax
0071f0cf  8b01                     mov        eax, dword ptr [ecx]
0071f0d1  ff5060                   call       dword ptr [eax + 0x60]
0071f0d4  84c0                     test       al, al
0071f0d6  742a                     je         0x71f102
0071f0d8  57                       push       edi
0071f0d9  6a00                     push       0
0071f0db  8bce                     mov        ecx, esi
0071f0dd  e8eefbffff               call       0x71ecd0
0071f0e2  8b16                     mov        edx, dword ptr [esi]
0071f0e4  56                       push       esi
0071f0e5  6a0e                     push       0xe
0071f0e7  6a3e                     push       0x3e
0071f0e9  8bce                     mov        ecx, esi
0071f0eb  8bf8                     mov        edi, eax
0071f0ed  ff927c060000             call       dword ptr [edx + 0x67c]
0071f0f3  8bc8                     mov        ecx, eax
0071f0f5  e8660ee3ff               call       0x54ff60
0071f0fa  3bf8                     cmp        edi, eax
0071f0fc  5f                       pop        edi
0071f0fd  0f9dc0                   setge      al
0071f100  5e                       pop        esi
0071f101  c3                       ret        
0071f102  32c0                     xor        al, al
0071f104  5e                       pop        esi
0071f105  c3                       ret        
0071f106  cc                       int3       
0071f107  cc                       int3       
0071f108  cc                       int3       
0071f109  cc                       int3       
0071f10a  cc                       int3       
0071f10b  cc                       int3       
0071f10c  cc                       int3       
0071f10d  cc                       int3       
0071f10e  cc                       int3       
0071f10f  cc                       int3       
0071f110  55                       push       ebp
0071f111  8bec                     mov        ebp, esp
0071f113  83ec14                   sub        esp, 0x14
0071f116  56                       push       esi
0071f117  8bf1                     mov        esi, ecx
0071f119  8b86d4300000             mov        eax, dword ptr [esi + 0x30d4]
0071f11f  85c0                     test       eax, eax
0071f121  0f843b020000             je         0x71f362
0071f127  8bc8                     mov        ecx, eax
0071f129  8b01                     mov        eax, dword ptr [ecx]
0071f12b  ff5060                   call       dword ptr [eax + 0x60]
0071f12e  84c0                     test       al, al
0071f130  0f842c020000             je         0x71f362
0071f136  8d8e5c150000             lea        ecx, [esi + 0x155c]
0071f13c  e81f2fceff               call       0x402060
0071f141  83f82e                   cmp        eax, 0x2e
0071f144  0f8418020000             je         0x71f362
0071f14a  8b86d4300000             mov        eax, dword ptr [esi + 0x30d4]
0071f150  57                       push       edi
0071f151  8bb880000000             mov        edi, dword ptr [eax + 0x80]
0071f157  8d88a8000000             lea        ecx, [eax + 0xa8]
0071f15d  e8fe2eceff               call       0x402060
0071f162  3bc7                     cmp        eax, edi
0071f164  0f8df7010000             jge        0x71f361
0071f16a  8b8ed4300000             mov        ecx, dword ptr [esi + 0x30d4]
0071f170  53                       push       ebx
0071f171  e89a5ae8ff               call       0x5a4c10
0071f176  8b16                     mov        edx, dword ptr [esi]
0071f178  6a55                     push       0x55
0071f17a  8bce                     mov        ecx, esi
0071f17c  ff927c060000             call       dword ptr [edx + 0x67c]
0071f182  8bf8                     mov        edi, eax
0071f184  8b06                     mov        eax, dword ptr [esi]
0071f186  6a55                     push       0x55
0071f188  8bce                     mov        ecx, esi
0071f18a  ff904c060000             call       dword ptr [eax + 0x64c]
0071f190  8bd8                     mov        ebx, eax
0071f192  8b86d4300000             mov        eax, dword ptr [esi + 0x30d4]
0071f198  8b8880000000             mov        ecx, dword ptr [eax + 0x80]
0071f19e  894dfc                   mov        dword ptr [ebp - 4], ecx
0071f1a1  8d88a8000000             lea        ecx, [eax + 0xa8]
0071f1a7  e8b42eceff               call       0x402060
0071f1ac  6a00                     push       0
0071f1ae  6a00                     push       0
0071f1b0  6a0c                     push       0xc
0071f1b2  6aff                     push       -1
0071f1b4  6aff                     push       -1
0071f1b6  56                       push       esi
0071f1b7  53                       push       ebx
0071f1b8  6a07                     push       7
0071f1ba  8bcf                     mov        ecx, edi
0071f1bc  8945f8                   mov        dword ptr [ebp - 8], eax
0071f1bf  e8bc0ee3ff               call       0x550080
0071f1c4  6a00                     push       0
0071f1c6  6a00                     push       0
0071f1c8  6a0c                     push       0xc
0071f1ca  6aff                     push       -1
0071f1cc  6aff                     push       -1
0071f1ce  56                       push       esi
0071f1cf  53                       push       ebx
0071f1d0  6a06                     push       6
0071f1d2  8bcf                     mov        ecx, edi
0071f1d4  8945f4                   mov        dword ptr [ebp - 0xc], eax
0071f1d7  e8a40ee3ff               call       0x550080
0071f1dc  db45f4                   fild       dword ptr [ebp - 0xc]
0071f1df  8b55fc                   mov        edx, dword ptr [ebp - 4]
0071f1e2  8945f0                   mov        dword ptr [ebp - 0x10], eax
0071f1e5  8b45f8                   mov        eax, dword ptr [ebp - 8]
0071f1e8  52                       push       edx
0071f1e9  50                       push       eax
0071f1ea  83ec08                   sub        esp, 8
0071f1ed  d95c2404                 fstp       dword ptr [esp + 4]
0071f1f1  db45f0                   fild       dword ptr [ebp - 0x10]
0071f1f4  d91c24                   fstp       dword ptr [esp]
0071f1f7  e8b4a73e00               call       0xb099b0
0071f1fc  83c410                   add        esp, 0x10
0071f1ff  e840234e00               call       0xc01544
0071f204  8945ec                   mov        dword ptr [ebp - 0x14], eax
0071f207  8b86d4300000             mov        eax, dword ptr [esi + 0x30d4]
0071f20d  8b8880000000             mov        ecx, dword ptr [eax + 0x80]
0071f213  894df0                   mov        dword ptr [ebp - 0x10], ecx
0071f216  8d88a8000000             lea        ecx, [eax + 0xa8]
0071f21c  e83f2eceff               call       0x402060
0071f221  6a00                     push       0
0071f223  6a00                     push       0
0071f225  6a0c                     push       0xc
0071f227  6aff                     push       -1
0071f229  6aff                     push       -1
0071f22b  56                       push       esi
0071f22c  53                       push       ebx
0071f22d  6a09                     push       9
0071f22f  8bcf                     mov        ecx, edi
0071f231  8945f4                   mov        dword ptr [ebp - 0xc], eax
0071f234  e8470ee3ff               call       0x550080
0071f239  6a00                     push       0
0071f23b  6a00                     push       0
0071f23d  6a0c                     push       0xc
0071f23f  6aff                     push       -1
0071f241  6aff                     push       -1
0071f243  56                       push       esi
0071f244  53                       push       ebx
0071f245  6a08                     push       8
0071f247  8bcf                     mov        ecx, edi
0071f249  8945f8                   mov        dword ptr [ebp - 8], eax
0071f24c  e82f0ee3ff               call       0x550080
0071f251  8b55f0                   mov        edx, dword ptr [ebp - 0x10]
0071f254  db45f8                   fild       dword ptr [ebp - 8]
0071f257  8945fc                   mov        dword ptr [ebp - 4], eax
0071f25a  8b45f4                   mov        eax, dword ptr [ebp - 0xc]
0071f25d  52                       push       edx
0071f25e  50                       push       eax
0071f25f  83ec08                   sub        esp, 8
0071f262  d95c2404                 fstp       dword ptr [esp + 4]
0071f266  db45fc                   fild       dword ptr [ebp - 4]
0071f269  d91c24                   fstp       dword ptr [esp]
0071f26c  e83fa73e00               call       0xb099b0
0071f271  83c410                   add        esp, 0x10
0071f274  e8cb224e00               call       0xc01544
0071f279  33db                     xor        ebx, ebx
0071f27b  8945f4                   mov        dword ptr [ebp - 0xc], eax
0071f27e  895dfc                   mov        dword ptr [ebp - 4], ebx
0071f281  8bbed8300000             mov        edi, dword ptr [esi + 0x30d8]
0071f287  8b8780000000             mov        eax, dword ptr [edi + 0x80]
0071f28d  85c0                     test       eax, eax
0071f28f  7419                     je         0x71f2aa
0071f291  8b8f84000000             mov        ecx, dword ptr [edi + 0x84]
0071f297  2bc8                     sub        ecx, eax
0071f299  b8abaaaa2a               mov        eax, 0x2aaaaaab
0071f29e  f7e9                     imul       ecx
0071f2a0  c1fa02                   sar        edx, 2
0071f2a3  8bc2                     mov        eax, edx
0071f2a5  c1e81f                   shr        eax, 0x1f
0071f2a8  03c2                     add        eax, edx
0071f2aa  3bd8                     cmp        ebx, eax
0071f2ac  0f8dae000000             jge        0x71f360
0071f2b2  8b8780000000             mov        eax, dword ptr [edi + 0x80]
0071f2b8  85c0                     test       eax, eax
0071f2ba  741d                     je         0x71f2d9
0071f2bc  8b8f84000000             mov        ecx, dword ptr [edi + 0x84]
0071f2c2  2bc8                     sub        ecx, eax
0071f2c4  b8abaaaa2a               mov        eax, 0x2aaaaaab
0071f2c9  f7e9                     imul       ecx
0071f2cb  c1fa02                   sar        edx, 2
0071f2ce  8bc2                     mov        eax, edx
0071f2d0  c1e81f                   shr        eax, 0x1f
0071f2d3  03c2                     add        eax, edx
0071f2d5  3bd8                     cmp        ebx, eax
0071f2d7  7204                     jb         0x71f2dd
0071f2d9  33ff                     xor        edi, edi
0071f2db  eb09                     jmp        0x71f2e6
0071f2dd  8bbf80000000             mov        edi, dword ptr [edi + 0x80]
0071f2e3  037dfc                   add        edi, dword ptr [ebp - 4]
0071f2e6  8bcf                     mov        ecx, edi
0071f2e8  e8732dceff               call       0x402060
0071f2ed  83f80a                   cmp        eax, 0xa
0071f2f0  7514                     jne        0x71f306
0071f2f2  8b15d8012101             mov        edx, dword ptr [0x12101d8]
0071f2f8  db45ec                   fild       dword ptr [ebp - 0x14]
0071f2fb  8b4f14                   mov        ecx, dword ptr [edi + 0x14]
0071f2fe  8b4244                   mov        eax, dword ptr [edx + 0x44]
0071f301  8d0488                   lea        eax, [eax + ecx*4]
0071f304  eb1e                     jmp        0x71f324
0071f306  8bcf                     mov        ecx, edi
0071f308  e8532dceff               call       0x402060
0071f30d  83f80b                   cmp        eax, 0xb
0071f310  753f                     jne        0x71f351
0071f312  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
0071f318  db45f4                   fild       dword ptr [ebp - 0xc]
0071f31b  8b4714                   mov        eax, dword ptr [edi + 0x14]
0071f31e  8b5144                   mov        edx, dword ptr [ecx + 0x44]
0071f321  8d0482                   lea        eax, [edx + eax*4]
0071f324  d95df0                   fstp       dword ptr [ebp - 0x10]
0071f327  8bd0                     mov        edx, eax
0071f329  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
0071f32c  33d1                     xor        edx, ecx
0071f32e  3315dc012101             xor        edx, dword ptr [0x12101dc]
0071f334  8910                     mov        dword ptr [eax], edx
0071f336  8b15d8012101             mov        edx, dword ptr [0x12101d8]
0071f33c  8b5248                   mov        edx, dword ptr [edx + 0x48]
0071f33f  8b4714                   mov        eax, dword ptr [edi + 0x14]
0071f342  8d0482                   lea        eax, [edx + eax*4]
0071f345  8bd0                     mov        edx, eax
0071f347  33d1                     xor        edx, ecx
0071f349  3315dc012101             xor        edx, dword ptr [0x12101dc]
0071f34f  8910                     mov        dword ptr [eax], edx
0071f351  8b45fc                   mov        eax, dword ptr [ebp - 4]
0071f354  43                       inc        ebx
0071f355  83c018                   add        eax, 0x18
0071f358  8945fc                   mov        dword ptr [ebp - 4], eax
0071f35b  e921ffffff               jmp        0x71f281
0071f360  5b                       pop        ebx
0071f361  5f                       pop        edi
0071f362  5e                       pop        esi
0071f363  8be5                     mov        esp, ebp
0071f365  5d                       pop        ebp
0071f366  c3                       ret        
0071f367  cc                       int3       
0071f368  cc                       int3       
0071f369  cc                       int3       
0071f36a  cc                       int3       
0071f36b  cc                       int3       
0071f36c  cc                       int3       
0071f36d  cc                       int3       
0071f36e  cc                       int3       
0071f36f  cc                       int3       
0071f370  56                       push       esi
0071f371  8bf1                     mov        esi, ecx
0071f373  e818cdd7ff               call       0x49c090
0071f378  84c0                     test       al, al
0071f37a  0f8490060000             je         0x71fa10
0071f380  8bce                     mov        ecx, esi
0071f382  e8e9e0daff               call       0x4cd470
0071f387  8a86af230000             mov        al, byte ptr [esi + 0x23af]
0071f38d  84c0                     test       al, al
0071f38f  0f847b060000             je         0x71fa10
0071f395  8d8e5c150000             lea        ecx, [esi + 0x155c]
0071f39b  e8c02cceff               call       0x402060
0071f3a0  83f82a                   cmp        eax, 0x2a
0071f3a3  0f8767060000             ja         0x71fa10
0071f3a9  0fb6803cfa7100           movzx      eax, byte ptr [eax + 0x71fa3c]
0071f3b0  57                       push       edi
0071f3b1  ff248514fa7100           jmp        dword ptr [eax*4 + 0x71fa14]
0071f3b8  8b16                     mov        edx, dword ptr [esi]
0071f3ba  6a01                     push       1
0071f3bc  6a01                     push       1
0071f3be  8bce                     mov        ecx, esi
0071f3c0  ff927c060000             call       dword ptr [edx + 0x67c]
0071f3c6  8bc8                     mov        ecx, eax
0071f3c8  e8a3fee2ff               call       0x54f270
0071f3cd  8b06                     mov        eax, dword ptr [esi]
0071f3cf  6a01                     push       1
0071f3d1  6a05                     push       5
0071f3d3  8bce                     mov        ecx, esi
0071f3d5  ff907c060000             call       dword ptr [eax + 0x67c]
0071f3db  8bc8                     mov        ecx, eax
0071f3dd  e88efee2ff               call       0x54f270
0071f3e2  8b16                     mov        edx, dword ptr [esi]
0071f3e4  6a01                     push       1
0071f3e6  6a08                     push       8
0071f3e8  8bce                     mov        ecx, esi
0071f3ea  ff927c060000             call       dword ptr [edx + 0x67c]
0071f3f0  8bc8                     mov        ecx, eax
0071f3f2  e879fee2ff               call       0x54f270
0071f3f7  8b06                     mov        eax, dword ptr [esi]
0071f3f9  6a01                     push       1
0071f3fb  6a09                     push       9
0071f3fd  8bce                     mov        ecx, esi
0071f3ff  ff907c060000             call       dword ptr [eax + 0x67c]
0071f405  8bc8                     mov        ecx, eax
0071f407  e864fee2ff               call       0x54f270
0071f40c  8b16                     mov        edx, dword ptr [esi]
0071f40e  6a01                     push       1
0071f410  6a14                     push       0x14
0071f412  8bce                     mov        ecx, esi
0071f414  ff927c060000             call       dword ptr [edx + 0x67c]
0071f41a  8bc8                     mov        ecx, eax
0071f41c  e84ffee2ff               call       0x54f270
0071f421  8b06                     mov        eax, dword ptr [esi]
0071f423  6a01                     push       1
0071f425  6a15                     push       0x15
0071f427  8bce                     mov        ecx, esi
0071f429  ff907c060000             call       dword ptr [eax + 0x67c]
0071f42f  8bc8                     mov        ecx, eax
0071f431  e83afee2ff               call       0x54f270
0071f436  8b16                     mov        edx, dword ptr [esi]
0071f438  6a01                     push       1
0071f43a  6a16                     push       0x16
0071f43c  8bce                     mov        ecx, esi
0071f43e  ff927c060000             call       dword ptr [edx + 0x67c]
0071f444  8bc8                     mov        ecx, eax
0071f446  e825fee2ff               call       0x54f270
0071f44b  8b06                     mov        eax, dword ptr [esi]
0071f44d  6a01                     push       1
0071f44f  6a17                     push       0x17
0071f451  8bce                     mov        ecx, esi
0071f453  ff907c060000             call       dword ptr [eax + 0x67c]
0071f459  8bc8                     mov        ecx, eax
0071f45b  e810fee2ff               call       0x54f270
0071f460  8b16                     mov        edx, dword ptr [esi]
0071f462  6a01                     push       1
0071f464  6a18                     push       0x18
0071f466  8bce                     mov        ecx, esi
0071f468  ff927c060000             call       dword ptr [edx + 0x67c]
0071f46e  8bc8                     mov        ecx, eax
0071f470  e8fbfde2ff               call       0x54f270
0071f475  8b06                     mov        eax, dword ptr [esi]
0071f477  6a01                     push       1
0071f479  6a19                     push       0x19
0071f47b  8bce                     mov        ecx, esi
0071f47d  ff907c060000             call       dword ptr [eax + 0x67c]
0071f483  8bc8                     mov        ecx, eax
0071f485  e8e6fde2ff               call       0x54f270
0071f48a  8b16                     mov        edx, dword ptr [esi]
0071f48c  6a01                     push       1
0071f48e  6a1e                     push       0x1e
0071f490  8bce                     mov        ecx, esi
0071f492  ff927c060000             call       dword ptr [edx + 0x67c]
0071f498  8bc8                     mov        ecx, eax
0071f49a  e8d1fde2ff               call       0x54f270
0071f49f  8b06                     mov        eax, dword ptr [esi]
0071f4a1  6a01                     push       1
0071f4a3  6a24                     push       0x24
0071f4a5  8bce                     mov        ecx, esi
0071f4a7  ff907c060000             call       dword ptr [eax + 0x67c]
0071f4ad  8bc8                     mov        ecx, eax
0071f4af  e8bcfde2ff               call       0x54f270
0071f4b4  8b16                     mov        edx, dword ptr [esi]
0071f4b6  6a01                     push       1
0071f4b8  6a26                     push       0x26
0071f4ba  8bce                     mov        ecx, esi
0071f4bc  ff927c060000             call       dword ptr [edx + 0x67c]
0071f4c2  8bc8                     mov        ecx, eax
0071f4c4  e8a7fde2ff               call       0x54f270
0071f4c9  8b06                     mov        eax, dword ptr [esi]
0071f4cb  6a01                     push       1
0071f4cd  6a28                     push       0x28
0071f4cf  8bce                     mov        ecx, esi
0071f4d1  ff907c060000             call       dword ptr [eax + 0x67c]
0071f4d7  8bc8                     mov        ecx, eax
0071f4d9  e892fde2ff               call       0x54f270
0071f4de  8b16                     mov        edx, dword ptr [esi]
0071f4e0  6a01                     push       1
0071f4e2  6a12                     push       0x12
0071f4e4  8bce                     mov        ecx, esi
0071f4e6  ff927c060000             call       dword ptr [edx + 0x67c]
0071f4ec  8bc8                     mov        ecx, eax
0071f4ee  e87dfde2ff               call       0x54f270
0071f4f3  8b06                     mov        eax, dword ptr [esi]
0071f4f5  6a01                     push       1
0071f4f7  6a29                     push       0x29
0071f4f9  8bce                     mov        ecx, esi
0071f4fb  ff907c060000             call       dword ptr [eax + 0x67c]
0071f501  8bc8                     mov        ecx, eax
0071f503  e868fde2ff               call       0x54f270
0071f508  8b16                     mov        edx, dword ptr [esi]
0071f50a  6a01                     push       1
0071f50c  6a2c                     push       0x2c
0071f50e  8bce                     mov        ecx, esi
0071f510  ff927c060000             call       dword ptr [edx + 0x67c]
0071f516  8bc8                     mov        ecx, eax
0071f518  e853fde2ff               call       0x54f270
0071f51d  8b06                     mov        eax, dword ptr [esi]
0071f51f  6a01                     push       1
0071f521  6a2e                     push       0x2e
0071f523  8bce                     mov        ecx, esi
0071f525  ff907c060000             call       dword ptr [eax + 0x67c]
0071f52b  8bc8                     mov        ecx, eax
0071f52d  e83efde2ff               call       0x54f270
0071f532  8b16                     mov        edx, dword ptr [esi]
0071f534  6a01                     push       1
0071f536  6a1f                     push       0x1f
0071f538  8bce                     mov        ecx, esi
0071f53a  ff927c060000             call       dword ptr [edx + 0x67c]
0071f540  8bc8                     mov        ecx, eax
0071f542  e829fde2ff               call       0x54f270
0071f547  8b06                     mov        eax, dword ptr [esi]
0071f549  6a01                     push       1
0071f54b  6a20                     push       0x20
0071f54d  8bce                     mov        ecx, esi
0071f54f  ff907c060000             call       dword ptr [eax + 0x67c]
0071f555  8bc8                     mov        ecx, eax
0071f557  e814fde2ff               call       0x54f270
0071f55c  8b16                     mov        edx, dword ptr [esi]
0071f55e  6a01                     push       1
0071f560  6a32                     push       0x32
0071f562  8bce                     mov        ecx, esi
0071f564  ff927c060000             call       dword ptr [edx + 0x67c]
0071f56a  8bc8                     mov        ecx, eax
0071f56c  e8fffce2ff               call       0x54f270
0071f571  8b06                     mov        eax, dword ptr [esi]
0071f573  6a01                     push       1
0071f575  6a34                     push       0x34
0071f577  8bce                     mov        ecx, esi
0071f579  ff907c060000             call       dword ptr [eax + 0x67c]
0071f57f  8bc8                     mov        ecx, eax
0071f581  e8eafce2ff               call       0x54f270
0071f586  8b16                     mov        edx, dword ptr [esi]
0071f588  6a01                     push       1
0071f58a  6a39                     push       0x39
0071f58c  8bce                     mov        ecx, esi
0071f58e  ff927c060000             call       dword ptr [edx + 0x67c]
0071f594  8bc8                     mov        ecx, eax
0071f596  e8d5fce2ff               call       0x54f270
0071f59b  6a01                     push       1
0071f59d  8b06                     mov        eax, dword ptr [esi]
0071f59f  6a3a                     push       0x3a
0071f5a1  8bce                     mov        ecx, esi
0071f5a3  ff907c060000             call       dword ptr [eax + 0x67c]
0071f5a9  8bc8                     mov        ecx, eax
0071f5ab  e8c0fce2ff               call       0x54f270
0071f5b0  8b16                     mov        edx, dword ptr [esi]
0071f5b2  6a01                     push       1
0071f5b4  6a40                     push       0x40
0071f5b6  8bce                     mov        ecx, esi
0071f5b8  ff927c060000             call       dword ptr [edx + 0x67c]
0071f5be  8bc8                     mov        ecx, eax
0071f5c0  e8abfce2ff               call       0x54f270
0071f5c5  8b06                     mov        eax, dword ptr [esi]
0071f5c7  6a01                     push       1
0071f5c9  6a41                     push       0x41
0071f5cb  8bce                     mov        ecx, esi
0071f5cd  ff907c060000             call       dword ptr [eax + 0x67c]
0071f5d3  8bc8                     mov        ecx, eax
0071f5d5  e896fce2ff               call       0x54f270
0071f5da  8b16                     mov        edx, dword ptr [esi]
0071f5dc  6a01                     push       1
0071f5de  6a03                     push       3
0071f5e0  8bce                     mov        ecx, esi
0071f5e2  ff927c060000             call       dword ptr [edx + 0x67c]
0071f5e8  8bc8                     mov        ecx, eax
0071f5ea  e881fce2ff               call       0x54f270
0071f5ef  8b06                     mov        eax, dword ptr [esi]
0071f5f1  6a01                     push       1
0071f5f3  6a43                     push       0x43
0071f5f5  8bce                     mov        ecx, esi
0071f5f7  ff907c060000             call       dword ptr [eax + 0x67c]
0071f5fd  8bc8                     mov        ecx, eax
0071f5ff  e86cfce2ff               call       0x54f270
0071f604  8b16                     mov        edx, dword ptr [esi]
0071f606  6a01                     push       1
0071f608  6a2f                     push       0x2f
0071f60a  8bce                     mov        ecx, esi
0071f60c  ff927c060000             call       dword ptr [edx + 0x67c]
0071f612  8bc8                     mov        ecx, eax
0071f614  e857fce2ff               call       0x54f270
0071f619  8b06                     mov        eax, dword ptr [esi]
0071f61b  6a01                     push       1
0071f61d  6a44                     push       0x44
0071f61f  8bce                     mov        ecx, esi
0071f621  ff907c060000             call       dword ptr [eax + 0x67c]
0071f627  8bc8                     mov        ecx, eax
0071f629  e842fce2ff               call       0x54f270
0071f62e  8b16                     mov        edx, dword ptr [esi]
0071f630  6a01                     push       1
0071f632  6a02                     push       2
0071f634  8bce                     mov        ecx, esi
0071f636  ff927c060000             call       dword ptr [edx + 0x67c]
0071f63c  8bc8                     mov        ecx, eax
0071f63e  e82dfce2ff               call       0x54f270
0071f643  8b06                     mov        eax, dword ptr [esi]
0071f645  6a01                     push       1
0071f647  6a48                     push       0x48
0071f649  8bce                     mov        ecx, esi
0071f64b  ff907c060000             call       dword ptr [eax + 0x67c]
0071f651  8bc8                     mov        ecx, eax
0071f653  e818fce2ff               call       0x54f270
0071f658  8b16                     mov        edx, dword ptr [esi]
0071f65a  6a01                     push       1
0071f65c  6a49                     push       0x49
0071f65e  8bce                     mov        ecx, esi
0071f660  ff927c060000             call       dword ptr [edx + 0x67c]
0071f666  8bc8                     mov        ecx, eax
0071f668  e803fce2ff               call       0x54f270
0071f66d  8b06                     mov        eax, dword ptr [esi]
0071f66f  6a01                     push       1
0071f671  6a4a                     push       0x4a
0071f673  8bce                     mov        ecx, esi
0071f675  ff907c060000             call       dword ptr [eax + 0x67c]
0071f67b  8bc8                     mov        ecx, eax
0071f67d  e8eefbe2ff               call       0x54f270
0071f682  8b16                     mov        edx, dword ptr [esi]
0071f684  6a01                     push       1
0071f686  6a4c                     push       0x4c
0071f688  8bce                     mov        ecx, esi
0071f68a  ff927c060000             call       dword ptr [edx + 0x67c]
0071f690  8bc8                     mov        ecx, eax
0071f692  e8d9fbe2ff               call       0x54f270
0071f697  8b06                     mov        eax, dword ptr [esi]
0071f699  6a01                     push       1
0071f69b  6a4b                     push       0x4b
0071f69d  8bce                     mov        ecx, esi
0071f69f  ff907c060000             call       dword ptr [eax + 0x67c]
0071f6a5  8bc8                     mov        ecx, eax
0071f6a7  e8c4fbe2ff               call       0x54f270
0071f6ac  8b16                     mov        edx, dword ptr [esi]
0071f6ae  6a01                     push       1
0071f6b0  6a4d                     push       0x4d
0071f6b2  8bce                     mov        ecx, esi
0071f6b4  ff927c060000             call       dword ptr [edx + 0x67c]
0071f6ba  8bc8                     mov        ecx, eax
0071f6bc  e8affbe2ff               call       0x54f270
0071f6c1  8b06                     mov        eax, dword ptr [esi]
0071f6c3  6a01                     push       1
0071f6c5  6a4f                     push       0x4f
0071f6c7  8bce                     mov        ecx, esi
0071f6c9  ff907c060000             call       dword ptr [eax + 0x67c]
0071f6cf  8bc8                     mov        ecx, eax
0071f6d1  e89afbe2ff               call       0x54f270
0071f6d6  8b16                     mov        edx, dword ptr [esi]
0071f6d8  6a01                     push       1
0071f6da  6a51                     push       0x51
0071f6dc  8bce                     mov        ecx, esi
0071f6de  ff927c060000             call       dword ptr [edx + 0x67c]
0071f6e4  8bc8                     mov        ecx, eax
0071f6e6  e885fbe2ff               call       0x54f270
0071f6eb  8b06                     mov        eax, dword ptr [esi]
0071f6ed  6a01                     push       1
0071f6ef  6a52                     push       0x52
0071f6f1  8bce                     mov        ecx, esi
0071f6f3  ff907c060000             call       dword ptr [eax + 0x67c]
0071f6f9  8bc8                     mov        ecx, eax
0071f6fb  e870fbe2ff               call       0x54f270
0071f700  8bce                     mov        ecx, esi
0071f702  e8b9f9ffff               call       0x71f0c0
0071f707  84c0                     test       al, al
0071f709  7415                     je         0x71f720
0071f70b  8b16                     mov        edx, dword ptr [esi]
0071f70d  6a01                     push       1
0071f70f  6a3e                     push       0x3e
0071f711  8bce                     mov        ecx, esi
0071f713  ff927c060000             call       dword ptr [edx + 0x67c]
0071f719  8bc8                     mov        ecx, eax
0071f71b  e850fbe2ff               call       0x54f270
0071f720  8b06                     mov        eax, dword ptr [esi]
0071f722  6a01                     push       1
0071f724  6a54                     push       0x54
0071f726  8bce                     mov        ecx, esi
0071f728  ff907c060000             call       dword ptr [eax + 0x67c]
0071f72e  8bc8                     mov        ecx, eax
0071f730  e83bfbe2ff               call       0x54f270
0071f735  8b16                     mov        edx, dword ptr [esi]
0071f737  6a01                     push       1
0071f739  6a55                     push       0x55
0071f73b  8bce                     mov        ecx, esi
0071f73d  ff927c060000             call       dword ptr [edx + 0x67c]
0071f743  8bc8                     mov        ecx, eax
0071f745  e826fbe2ff               call       0x54f270
0071f74a  8b06                     mov        eax, dword ptr [esi]
0071f74c  6a01                     push       1
0071f74e  6a56                     push       0x56
0071f750  8bce                     mov        ecx, esi
0071f752  ff907c060000             call       dword ptr [eax + 0x67c]
0071f758  8bc8                     mov        ecx, eax
0071f75a  e811fbe2ff               call       0x54f270
0071f75f  8b16                     mov        edx, dword ptr [esi]
0071f761  6a01                     push       1
0071f763  6a57                     push       0x57
0071f765  8bce                     mov        ecx, esi
0071f767  ff927c060000             call       dword ptr [edx + 0x67c]
0071f76d  8bc8                     mov        ecx, eax
0071f76f  e8fcfae2ff               call       0x54f270
0071f774  8b06                     mov        eax, dword ptr [esi]
0071f776  6a01                     push       1
0071f778  6a58                     push       0x58
0071f77a  8bce                     mov        ecx, esi
0071f77c  ff907c060000             call       dword ptr [eax + 0x67c]
0071f782  8bc8                     mov        ecx, eax
0071f784  e8e7fae2ff               call       0x54f270
0071f789  5f                       pop        edi
0071f78a  5e                       pop        esi
0071f78b  c3                       ret        
0071f78c  8d8e88170000             lea        ecx, [esi + 0x1788]
0071f792  e8c928ceff               call       0x402060
0071f797  83f801                   cmp        eax, 1
0071f79a  0f856f020000             jne        0x71fa0f
0071f7a0  8b16                     mov        edx, dword ptr [esi]
0071f7a2  50                       push       eax
0071f7a3  6a10                     push       0x10
0071f7a5  8bce                     mov        ecx, esi
0071f7a7  ff927c060000             call       dword ptr [edx + 0x67c]
0071f7ad  8bc8                     mov        ecx, eax
0071f7af  e8bcfae2ff               call       0x54f270
0071f7b4  8d8e90170000             lea        ecx, [esi + 0x1790]
0071f7ba  e8a128ceff               call       0x402060
0071f7bf  85c0                     test       eax, eax
0071f7c1  7e76                     jle        0x71f839
0071f7c3  8d8ef4170000             lea        ecx, [esi + 0x17f4]
0071f7c9  e89228ceff               call       0x402060
0071f7ce  85c0                     test       eax, eax
0071f7d0  7567                     jne        0x71f839
0071f7d2  8b06                     mov        eax, dword ptr [esi]
0071f7d4  8bce                     mov        ecx, esi
0071f7d6  ff9020060000             call       dword ptr [eax + 0x620]
0071f7dc  83f802                   cmp        eax, 2
0071f7df  7538                     jne        0x71f819
0071f7e1  8b16                     mov        edx, dword ptr [esi]
0071f7e3  6a1b                     push       0x1b
0071f7e5  8bce                     mov        ecx, esi
0071f7e7  ff924c060000             call       dword ptr [edx + 0x64c]
0071f7ed  85c0                     test       eax, eax
0071f7ef  7e28                     jle        0x71f819
0071f7f1  8b06                     mov        eax, dword ptr [esi]
0071f7f3  56                       push       esi
0071f7f4  6a02                     push       2
0071f7f6  6a0f                     push       0xf
0071f7f8  8bce                     mov        ecx, esi
0071f7fa  ff907c060000             call       dword ptr [eax + 0x67c]
0071f800  8bc8                     mov        ecx, eax
0071f802  e85907e3ff               call       0x54ff60
0071f807  8b16                     mov        edx, dword ptr [esi]
0071f809  6a0f                     push       0xf
0071f80b  8bce                     mov        ecx, esi
0071f80d  8bf8                     mov        edi, eax
0071f80f  ff924c060000             call       dword ptr [edx + 0x64c]
0071f815  3bc7                     cmp        eax, edi
0071f817  7d20                     jge        0x71f839
0071f819  8bce                     mov        ecx, esi
0071f81b  e880c2ffff               call       0x71baa0
0071f820  84c0                     test       al, al
0071f822  7515                     jne        0x71f839
0071f824  8b06                     mov        eax, dword ptr [esi]
0071f826  6a01                     push       1
0071f828  6a11                     push       0x11
0071f82a  8bce                     mov        ecx, esi
0071f82c  ff907c060000             call       dword ptr [eax + 0x67c]
0071f832  8bc8                     mov        ecx, eax
0071f834  e837fae2ff               call       0x54f270
0071f839  8bce                     mov        ecx, esi
0071f83b  e860c2ffff               call       0x71baa0
0071f840  84c0                     test       al, al
0071f842  7407                     je         0x71f84b
0071f844  c686581a000001           mov        byte ptr [esi + 0x1a58], 1
0071f84b  8d8ef4170000             lea        ecx, [esi + 0x17f4]
0071f851  e80a28ceff               call       0x402060
0071f856  85c0                     test       eax, eax
0071f858  0f84b1010000             je         0x71fa0f
0071f85e  8b16                     mov        edx, dword ptr [esi]
0071f860  6a01                     push       1
0071f862  6a31                     push       0x31
0071f864  8bce                     mov        ecx, esi
0071f866  ff927c060000             call       dword ptr [edx + 0x67c]
0071f86c  8bc8                     mov        ecx, eax
0071f86e  e8fdf9e2ff               call       0x54f270
0071f873  5f                       pop        edi
0071f874  5e                       pop        esi
0071f875  c3                       ret        
0071f876  8b06                     mov        eax, dword ptr [esi]
0071f878  6a1b                     push       0x1b
0071f87a  8bce                     mov        ecx, esi
0071f87c  ff904c060000             call       dword ptr [eax + 0x64c]
0071f882  85c0                     test       eax, eax
0071f884  0f8e85010000             jle        0x71fa0f
0071f88a  8b16                     mov        edx, dword ptr [esi]
0071f88c  6a00                     push       0
0071f88e  6a02                     push       2
0071f890  6a0e                     push       0xe
0071f892  8bce                     mov        ecx, esi
0071f894  ff927c060000             call       dword ptr [edx + 0x67c]
0071f89a  8bc8                     mov        ecx, eax
0071f89c  e8bf06e3ff               call       0x54ff60
0071f8a1  8bf8                     mov        edi, eax
0071f8a3  8b06                     mov        eax, dword ptr [esi]
0071f8a5  6a0e                     push       0xe
0071f8a7  8bce                     mov        ecx, esi
0071f8a9  ff904c060000             call       dword ptr [eax + 0x64c]
0071f8af  3bc7                     cmp        eax, edi
0071f8b1  7c0f                     jl         0x71f8c2
0071f8b3  8b16                     mov        edx, dword ptr [esi]
0071f8b5  8bce                     mov        ecx, esi
0071f8b7  ff9220060000             call       dword ptr [edx + 0x620]
0071f8bd  83f803                   cmp        eax, 3
0071f8c0  7440                     je         0x71f902
0071f8c2  8b06                     mov        eax, dword ptr [esi]
0071f8c4  6a00                     push       0
0071f8c6  6a01                     push       1
0071f8c8  6a0f                     push       0xf
0071f8ca  8bce                     mov        ecx, esi
0071f8cc  ff907c060000             call       dword ptr [eax + 0x67c]
0071f8d2  8bc8                     mov        ecx, eax
0071f8d4  e88706e3ff               call       0x54ff60
0071f8d9  8b16                     mov        edx, dword ptr [esi]
0071f8db  6a0f                     push       0xf
0071f8dd  8bce                     mov        ecx, esi
0071f8df  8bf8                     mov        edi, eax
0071f8e1  ff924c060000             call       dword ptr [edx + 0x64c]
0071f8e7  3bc7                     cmp        eax, edi
0071f8e9  0f8c20010000             jl         0x71fa0f
0071f8ef  8b06                     mov        eax, dword ptr [esi]
0071f8f1  8bce                     mov        ecx, esi
0071f8f3  ff9020060000             call       dword ptr [eax + 0x620]
0071f8f9  83f802                   cmp        eax, 2
0071f8fc  0f850d010000             jne        0x71fa0f
0071f902  6a01                     push       1
0071f904  6a44                     push       0x44
0071f906  8b16                     mov        edx, dword ptr [esi]
0071f908  8bce                     mov        ecx, esi
0071f90a  ff927c060000             call       dword ptr [edx + 0x67c]
0071f910  8bc8                     mov        ecx, eax
0071f912  e859f9e2ff               call       0x54f270
0071f917  5f                       pop        edi
0071f918  c686581a000001           mov        byte ptr [esi + 0x1a58], 1
0071f91f  5e                       pop        esi
0071f920  c3                       ret        
0071f921  8b8624330000             mov        eax, dword ptr [esi + 0x3324]
0071f927  85c0                     test       eax, eax
0071f929  7409                     je         0x71f934
0071f92b  83f801                   cmp        eax, 1
0071f92e  0f85db000000             jne        0x71fa0f
0071f934  8b06                     mov        eax, dword ptr [esi]
0071f936  6a01                     push       1
0071f938  6a4d                     push       0x4d
0071f93a  8bce                     mov        ecx, esi
0071f93c  ff907c060000             call       dword ptr [eax + 0x67c]
0071f942  8bc8                     mov        ecx, eax
0071f944  e827f9e2ff               call       0x54f270
0071f949  5f                       pop        edi
0071f94a  c686581a000001           mov        byte ptr [esi + 0x1a58], 1
0071f951  5e                       pop        esi
0071f952  c3                       ret        
0071f953  8b86702f0000             mov        eax, dword ptr [esi + 0x2f70]
0071f959  85c0                     test       eax, eax
0071f95b  0f85ae000000             jne        0x71fa0f
0071f961  6a01                     push       1
0071f963  6a09                     push       9
0071f965  eb9f                     jmp        0x71f906
0071f967  8b86002c0000             mov        eax, dword ptr [esi + 0x2c00]
0071f96d  85c0                     test       eax, eax
0071f96f  0f859a000000             jne        0x71fa0f
0071f975  8b06                     mov        eax, dword ptr [esi]
0071f977  6a01                     push       1
0071f979  6a3e                     push       0x3e
0071f97b  8bce                     mov        ecx, esi
0071f97d  ff907c060000             call       dword ptr [eax + 0x67c]
0071f983  8bc8                     mov        ecx, eax
0071f985  e8e6f8e2ff               call       0x54f270
0071f98a  5f                       pop        edi
0071f98b  c686581a000001           mov        byte ptr [esi + 0x1a58], 1
0071f992  5e                       pop        esi
0071f993  c3                       ret        
0071f994  8b86702d0000             mov        eax, dword ptr [esi + 0x2d70]
0071f99a  85c0                     test       eax, eax
0071f99c  7571                     jne        0x71fa0f
0071f99e  6a01                     push       1
0071f9a0  6a49                     push       0x49
0071f9a2  e95fffffff               jmp        0x71f906
0071f9a7  8b8628240000             mov        eax, dword ptr [esi + 0x2428]
0071f9ad  85c0                     test       eax, eax
0071f9af  755e                     jne        0x71fa0f
0071f9b1  8d8e2c240000             lea        ecx, [esi + 0x242c]
0071f9b7  e8a426ceff               call       0x402060
0071f9bc  83f84a                   cmp        eax, 0x4a
0071f9bf  754e                     jne        0x71fa0f
0071f9c1  8d8e20240000             lea        ecx, [esi + 0x2420]
0071f9c7  e89426ceff               call       0x402060
0071f9cc  83f801                   cmp        eax, 1
0071f9cf  753e                     jne        0x71fa0f
0071f9d1  50                       push       eax
0071f9d2  8b06                     mov        eax, dword ptr [esi]
0071f9d4  6a4a                     push       0x4a
0071f9d6  8bce                     mov        ecx, esi
0071f9d8  ff907c060000             call       dword ptr [eax + 0x67c]
0071f9de  8bc8                     mov        ecx, eax
0071f9e0  e88bf8e2ff               call       0x54f270
0071f9e5  5f                       pop        edi
0071f9e6  c686581a000001           mov        byte ptr [esi + 0x1a58], 1
0071f9ed  5e                       pop        esi
0071f9ee  c3                       ret        
0071f9ef  8bce                     mov        ecx, esi
0071f9f1  e8caf6ffff               call       0x71f0c0
0071f9f6  84c0                     test       al, al
0071f9f8  7415                     je         0x71fa0f
0071f9fa  8b16                     mov        edx, dword ptr [esi]
0071f9fc  6a01                     push       1
0071f9fe  6a3e                     push       0x3e
0071fa00  8bce                     mov        ecx, esi
0071fa02  ff927c060000             call       dword ptr [edx + 0x67c]
0071fa08  8bc8                     mov        ecx, eax
0071fa0a  e861f8e2ff               call       0x54f270
0071fa0f  5f                       pop        edi
0071fa10  5e                       pop        esi
0071fa11  c3                       ret        
0071fa12  8bff                     mov        edi, edi
0071fa14  b8f37100ef               mov        eax, 0xef0071f3
0071fa19  f9                       stc        
0071fa1a  7100                     jno        0x71fa1c
0071fa1c  8c                       .byte      0x8c
0071fa1d  f77100                   div        dword ptr [ecx]
0071fa20  a7                       cmpsd      dword ptr [esi], dword ptr es:[edi]
0071fa21  f9                       stc        
0071fa22  7100                     jno        0x71fa24
0071fa24  53                       push       ebx
0071fa25  f9                       stc        
0071fa26  7100                     jno        0x71fa28
0071fa28  67f9                     stc        
0071fa2a  7100                     jno        0x71fa2c
0071fa2c  76f8                     jbe        0x71fa26
0071fa2e  7100                     jno        0x71fa30
0071fa30  94                       xchg       esp, eax
0071fa31  f9                       stc        
0071fa32  7100                     jno        0x71fa34
0071fa34  21f9                     and        ecx, edi
0071fa36  7100                     jno        0x71fa38
0071fa38  0ffa7100                 psubd      mm6, qword ptr [ecx]
0071fa3c  0009                     add        byte ptr [ecx], cl
0071fa3e  0901                     or         dword ptr [ecx], eax
0071fa40  0909                     or         dword ptr [ecx], ecx
0071fa42  0209                     add        cl, byte ptr [ecx]
0071fa44  0909                     or         dword ptr [ecx], ecx
0071fa46  0300                     add        eax, dword ptr [eax]
0071fa48  0909                     or         dword ptr [ecx], ecx
0071fa4a  0909                     or         dword ptr [ecx], ecx
0071fa4c  0909                     or         dword ptr [ecx], ecx
0071fa4e  0909                     or         dword ptr [ecx], ecx
0071fa50  0909                     or         dword ptr [ecx], ecx
0071fa52  090409                   or         dword ptr [ecx + ecx], eax
0071fa55  0909                     or         dword ptr [ecx], ecx
0071fa57  0909                     or         dword ptr [ecx], ecx
0071fa59  0909                     or         dword ptr [ecx], ecx
0071fa5b  0909                     or         dword ptr [ecx], ecx
0071fa5d  090509090609             or         dword ptr [0x9060909], eax
0071fa63  0907                     or         dword ptr [edi], eax
0071fa65  0908                     or         dword ptr [eax], ecx
0071fa67  cc                       int3       
0071fa68  cc                       int3       
0071fa69  cc                       int3       
0071fa6a  cc                       int3       
0071fa6b  cc                       int3       
0071fa6c  cc                       int3       
0071fa6d  cc                       int3       
0071fa6e  cc                       int3       
0071fa6f  cc                       int3       
0071fa70  55                       push       ebp
0071fa71  8bec                     mov        ebp, esp
0071fa73  83ec08                   sub        esp, 8
0071fa76  56                       push       esi
0071fa77  8b7508                   mov        esi, dword ptr [ebp + 8]
0071fa7a  85f6                     test       esi, esi
0071fa7c  57                       push       edi
0071fa7d  8bf9                     mov        edi, ecx
0071fa7f  897df8                   mov        dword ptr [ebp - 8], edi
0071fa82  0f8400010000             je         0x71fb88
0071fa88  53                       push       ebx
0071fa89  8d4508                   lea        eax, [ebp + 8]
0071fa8c  50                       push       eax
0071fa8d  8d4dfc                   lea        ecx, [ebp - 4]
0071fa90  8d9fc42b0000             lea        ebx, [edi + 0x2bc4]
0071fa96  51                       push       ecx
0071fa97  8bcb                     mov        ecx, ebx
0071fa99  e842523400               call       0xa64ce0
0071fa9e  8b45fc                   mov        eax, dword ptr [ebp - 4]
0071faa1  3b87cc2b0000             cmp        eax, dword ptr [edi + 0x2bcc]
0071faa7  0f84da000000             je         0x71fb87
0071faad  50                       push       eax
0071faae  8d5508                   lea        edx, [ebp + 8]
0071fab1  52                       push       edx
0071fab2  8bcb                     mov        ecx, ebx
0071fab4  e8c74ae4ff               call       0x564580
0071fab9  8b06                     mov        eax, dword ptr [esi]
0071fabb  8bce                     mov        ecx, esi
0071fabd  ff5064                   call       dword ptr [eax + 0x64]
0071fac0  84c0                     test       al, al
0071fac2  0f84bf000000             je         0x71fb87
0071fac8  8b16                     mov        edx, dword ptr [esi]
0071faca  8bce                     mov        ecx, esi
0071facc  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fad2  85c0                     test       eax, eax
0071fad4  0f84ad000000             je         0x71fb87
0071fada  33db                     xor        ebx, ebx
0071fadc  8d642400                 lea        esp, [esp]
0071fae0  8b06                     mov        eax, dword ptr [esi]
0071fae2  8bce                     mov        ecx, esi
0071fae4  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071faea  8b4804                   mov        ecx, dword ptr [eax + 4]
0071faed  85c9                     test       ecx, ecx
0071faef  7504                     jne        0x71faf5
0071faf1  33c0                     xor        eax, eax
0071faf3  eb08                     jmp        0x71fafd
0071faf5  8b4008                   mov        eax, dword ptr [eax + 8]
0071faf8  2bc1                     sub        eax, ecx
0071fafa  c1f802                   sar        eax, 2
0071fafd  3bd8                     cmp        ebx, eax
0071faff  0f8d82000000             jge        0x71fb87
0071fb05  8b16                     mov        edx, dword ptr [esi]
0071fb07  8bce                     mov        ecx, esi
0071fb09  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fb0f  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fb12  85c9                     test       ecx, ecx
0071fb14  7411                     je         0x71fb27
0071fb16  8b4008                   mov        eax, dword ptr [eax + 8]
0071fb19  2bc1                     sub        eax, ecx
0071fb1b  c1f802                   sar        eax, 2
0071fb1e  3bd8                     cmp        ebx, eax
0071fb20  7305                     jae        0x71fb27
0071fb22  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071fb25  eb02                     jmp        0x71fb29
0071fb27  33c9                     xor        ecx, ecx
0071fb29  397104                   cmp        dword ptr [ecx + 4], esi
0071fb2c  754a                     jne        0x71fb78
0071fb2e  8b06                     mov        eax, dword ptr [esi]
0071fb30  53                       push       ebx
0071fb31  8bce                     mov        ecx, esi
0071fb33  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fb39  8bc8                     mov        ecx, eax
0071fb3b  e8609bd4ff               call       0x4696a0
0071fb40  8b10                     mov        edx, dword ptr [eax]
0071fb42  8bc8                     mov        ecx, eax
0071fb44  ff5250                   call       dword ptr [edx + 0x50]
0071fb47  397844                   cmp        dword ptr [eax + 0x44], edi
0071fb4a  752c                     jne        0x71fb78
0071fb4c  8b06                     mov        eax, dword ptr [esi]
0071fb4e  53                       push       ebx
0071fb4f  8bce                     mov        ecx, esi
0071fb51  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fb57  8bc8                     mov        ecx, eax
0071fb59  e8429bd4ff               call       0x4696a0
0071fb5e  8bf8                     mov        edi, eax
0071fb60  85ff                     test       edi, edi
0071fb62  7411                     je         0x71fb75
0071fb64  8b17                     mov        edx, dword ptr [edi]
0071fb66  8bcf                     mov        ecx, edi
0071fb68  ff5260                   call       dword ptr [edx + 0x60]
0071fb6b  84c0                     test       al, al
0071fb6d  7406                     je         0x71fb75
0071fb6f  837f6c34                 cmp        dword ptr [edi + 0x6c], 0x34
0071fb73  7409                     je         0x71fb7e
0071fb75  8b7df8                   mov        edi, dword ptr [ebp - 8]
0071fb78  43                       inc        ebx
0071fb79  e962ffffff               jmp        0x71fae0
0071fb7e  8b07                     mov        eax, dword ptr [edi]
0071fb80  6a00                     push       0
0071fb82  8bcf                     mov        ecx, edi
0071fb84  ff505c                   call       dword ptr [eax + 0x5c]
0071fb87  5b                       pop        ebx
0071fb88  5f                       pop        edi
0071fb89  5e                       pop        esi
0071fb8a  8be5                     mov        esp, ebp
0071fb8c  5d                       pop        ebp
0071fb8d  c20400                   ret        4
0071fb90  56                       push       esi
0071fb91  8bf1                     mov        esi, ecx
0071fb93  8b86d02b0000             mov        eax, dword ptr [esi + 0x2bd0]
0071fb99  85c0                     test       eax, eax
0071fb9b  7420                     je         0x71fbbd
0071fb9d  8d4900                   lea        ecx, [ecx]
0071fba0  8b86cc2b0000             mov        eax, dword ptr [esi + 0x2bcc]
0071fba6  8b08                     mov        ecx, dword ptr [eax]
0071fba8  8b5108                   mov        edx, dword ptr [ecx + 8]
0071fbab  52                       push       edx
0071fbac  8bce                     mov        ecx, esi
0071fbae  e8bdfeffff               call       0x71fa70
0071fbb3  8b86d02b0000             mov        eax, dword ptr [esi + 0x2bd0]
0071fbb9  85c0                     test       eax, eax
0071fbbb  75e3                     jne        0x71fba0
0071fbbd  5e                       pop        esi
0071fbbe  c3                       ret        
0071fbbf  cc                       int3       
0071fbc0  55                       push       ebp
0071fbc1  8bec                     mov        ebp, esp
0071fbc3  83ec08                   sub        esp, 8
0071fbc6  56                       push       esi
0071fbc7  57                       push       edi
0071fbc8  8bf9                     mov        edi, ecx
0071fbca  8d4508                   lea        eax, [ebp + 8]
0071fbcd  50                       push       eax
0071fbce  8d4dfc                   lea        ecx, [ebp - 4]
0071fbd1  8db7f42f0000             lea        esi, [edi + 0x2ff4]
0071fbd7  51                       push       ecx
0071fbd8  8bce                     mov        ecx, esi
0071fbda  897df8                   mov        dword ptr [ebp - 8], edi
0071fbdd  e8fe503400               call       0xa64ce0
0071fbe2  8b45fc                   mov        eax, dword ptr [ebp - 4]
0071fbe5  3b87fc2f0000             cmp        eax, dword ptr [edi + 0x2ffc]
0071fbeb  0f8408010000             je         0x71fcf9
0071fbf1  50                       push       eax
0071fbf2  8d55fc                   lea        edx, [ebp - 4]
0071fbf5  52                       push       edx
0071fbf6  8bce                     mov        ecx, esi
0071fbf8  e88349e4ff               call       0x564580
0071fbfd  8b7508                   mov        esi, dword ptr [ebp + 8]
0071fc00  85f6                     test       esi, esi
0071fc02  0f84f1000000             je         0x71fcf9
0071fc08  8b06                     mov        eax, dword ptr [esi]
0071fc0a  8bce                     mov        ecx, esi
0071fc0c  ff5064                   call       dword ptr [eax + 0x64]
0071fc0f  84c0                     test       al, al
0071fc11  0f84e2000000             je         0x71fcf9
0071fc17  8b16                     mov        edx, dword ptr [esi]
0071fc19  8bce                     mov        ecx, esi
0071fc1b  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fc21  85c0                     test       eax, eax
0071fc23  0f84d0000000             je         0x71fcf9
0071fc29  53                       push       ebx
0071fc2a  33db                     xor        ebx, ebx
0071fc2c  8d642400                 lea        esp, [esp]
0071fc30  8b06                     mov        eax, dword ptr [esi]
0071fc32  8bce                     mov        ecx, esi
0071fc34  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fc3a  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fc3d  85c9                     test       ecx, ecx
0071fc3f  7504                     jne        0x71fc45
0071fc41  33c0                     xor        eax, eax
0071fc43  eb08                     jmp        0x71fc4d
0071fc45  8b4008                   mov        eax, dword ptr [eax + 8]
0071fc48  2bc1                     sub        eax, ecx
0071fc4a  c1f802                   sar        eax, 2
0071fc4d  3bd8                     cmp        ebx, eax
0071fc4f  0f8da3000000             jge        0x71fcf8
0071fc55  8b16                     mov        edx, dword ptr [esi]
0071fc57  8bce                     mov        ecx, esi
0071fc59  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fc5f  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fc62  85c9                     test       ecx, ecx
0071fc64  7411                     je         0x71fc77
0071fc66  8b4008                   mov        eax, dword ptr [eax + 8]
0071fc69  2bc1                     sub        eax, ecx
0071fc6b  c1f802                   sar        eax, 2
0071fc6e  3bd8                     cmp        ebx, eax
0071fc70  7305                     jae        0x71fc77
0071fc72  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071fc75  eb02                     jmp        0x71fc79
0071fc77  33c9                     xor        ecx, ecx
0071fc79  397104                   cmp        dword ptr [ecx + 4], esi
0071fc7c  756b                     jne        0x71fce9
0071fc7e  8b06                     mov        eax, dword ptr [esi]
0071fc80  8bce                     mov        ecx, esi
0071fc82  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fc88  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fc8b  85c9                     test       ecx, ecx
0071fc8d  7411                     je         0x71fca0
0071fc8f  8b4008                   mov        eax, dword ptr [eax + 8]
0071fc92  2bc1                     sub        eax, ecx
0071fc94  c1f802                   sar        eax, 2
0071fc97  3bd8                     cmp        ebx, eax
0071fc99  7305                     jae        0x71fca0
0071fc9b  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071fc9e  eb02                     jmp        0x71fca2
0071fca0  33c9                     xor        ecx, ecx
0071fca2  8b11                     mov        edx, dword ptr [ecx]
0071fca4  ff5250                   call       dword ptr [edx + 0x50]
0071fca7  397844                   cmp        dword ptr [eax + 0x44], edi
0071fcaa  753d                     jne        0x71fce9
0071fcac  8b06                     mov        eax, dword ptr [esi]
0071fcae  6a00                     push       0
0071fcb0  6814e4f600               push       0xf6e414
0071fcb5  68f451f500               push       0xf551f4
0071fcba  6a00                     push       0
0071fcbc  53                       push       ebx
0071fcbd  8bce                     mov        ecx, esi
0071fcbf  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fcc5  8bc8                     mov        ecx, eax
0071fcc7  e8d499d4ff               call       0x4696a0
0071fccc  50                       push       eax
0071fccd  e839104e00               call       0xc00d0b
0071fcd2  8bf8                     mov        edi, eax
0071fcd4  83c414                   add        esp, 0x14
0071fcd7  85ff                     test       edi, edi
0071fcd9  740b                     je         0x71fce6
0071fcdb  8b17                     mov        edx, dword ptr [edi]
0071fcdd  8bcf                     mov        ecx, edi
0071fcdf  ff5260                   call       dword ptr [edx + 0x60]
0071fce2  84c0                     test       al, al
0071fce4  7509                     jne        0x71fcef
0071fce6  8b7df8                   mov        edi, dword ptr [ebp - 8]
0071fce9  43                       inc        ebx
0071fcea  e941ffffff               jmp        0x71fc30
0071fcef  8b07                     mov        eax, dword ptr [edi]
0071fcf1  6a00                     push       0
0071fcf3  8bcf                     mov        ecx, edi
0071fcf5  ff505c                   call       dword ptr [eax + 0x5c]
0071fcf8  5b                       pop        ebx
0071fcf9  5f                       pop        edi
0071fcfa  5e                       pop        esi
0071fcfb  8be5                     mov        esp, ebp
0071fcfd  5d                       pop        ebp
0071fcfe  c20400                   ret        4
0071fd01  cc                       int3       
0071fd02  cc                       int3       
0071fd03  cc                       int3       
0071fd04  cc                       int3       
0071fd05  cc                       int3       
0071fd06  cc                       int3       
0071fd07  cc                       int3       
0071fd08  cc                       int3       
0071fd09  cc                       int3       
0071fd0a  cc                       int3       
0071fd0b  cc                       int3       
0071fd0c  cc                       int3       
0071fd0d  cc                       int3       
0071fd0e  cc                       int3       
0071fd0f  cc                       int3       
0071fd10  56                       push       esi
0071fd11  8bf1                     mov        esi, ecx
0071fd13  8b8600300000             mov        eax, dword ptr [esi + 0x3000]
0071fd19  85c0                     test       eax, eax
0071fd1b  7420                     je         0x71fd3d
0071fd1d  8d4900                   lea        ecx, [ecx]
0071fd20  8b86fc2f0000             mov        eax, dword ptr [esi + 0x2ffc]
0071fd26  8b08                     mov        ecx, dword ptr [eax]
0071fd28  8b5108                   mov        edx, dword ptr [ecx + 8]
0071fd2b  52                       push       edx
0071fd2c  8bce                     mov        ecx, esi
0071fd2e  e88dfeffff               call       0x71fbc0
0071fd33  8b8600300000             mov        eax, dword ptr [esi + 0x3000]
0071fd39  85c0                     test       eax, eax
0071fd3b  75e3                     jne        0x71fd20
0071fd3d  5e                       pop        esi
0071fd3e  c3                       ret        
0071fd3f  cc                       int3       
0071fd40  55                       push       ebp
0071fd41  8bec                     mov        ebp, esp
0071fd43  83ec0c                   sub        esp, 0xc
0071fd46  57                       push       edi
0071fd47  8bf9                     mov        edi, ecx
0071fd49  8d4508                   lea        eax, [ebp + 8]
0071fd4c  50                       push       eax
0071fd4d  8d55f8                   lea        edx, [ebp - 8]
0071fd50  8d8fd82d0000             lea        ecx, [edi + 0x2dd8]
0071fd56  52                       push       edx
0071fd57  897dfc                   mov        dword ptr [ebp - 4], edi
0071fd5a  894df4                   mov        dword ptr [ebp - 0xc], ecx
0071fd5d  e87e4f3400               call       0xa64ce0
0071fd62  8b45f8                   mov        eax, dword ptr [ebp - 8]
0071fd65  3b87e02d0000             cmp        eax, dword ptr [edi + 0x2de0]
0071fd6b  0f84e9010000             je         0x71ff5a
0071fd71  53                       push       ebx
0071fd72  56                       push       esi
0071fd73  8b7508                   mov        esi, dword ptr [ebp + 8]
0071fd76  85f6                     test       esi, esi
0071fd78  0f84dd000000             je         0x71fe5b
0071fd7e  8b16                     mov        edx, dword ptr [esi]
0071fd80  8bce                     mov        ecx, esi
0071fd82  ff5264                   call       dword ptr [edx + 0x64]
0071fd85  84c0                     test       al, al
0071fd87  0f84ce000000             je         0x71fe5b
0071fd8d  8b06                     mov        eax, dword ptr [esi]
0071fd8f  8bce                     mov        ecx, esi
0071fd91  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fd97  85c0                     test       eax, eax
0071fd99  0f84bc000000             je         0x71fe5b
0071fd9f  33db                     xor        ebx, ebx
0071fda1  8b16                     mov        edx, dword ptr [esi]
0071fda3  8bce                     mov        ecx, esi
0071fda5  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fdab  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fdae  85c9                     test       ecx, ecx
0071fdb0  7504                     jne        0x71fdb6
0071fdb2  33c0                     xor        eax, eax
0071fdb4  eb08                     jmp        0x71fdbe
0071fdb6  8b4008                   mov        eax, dword ptr [eax + 8]
0071fdb9  2bc1                     sub        eax, ecx
0071fdbb  c1f802                   sar        eax, 2
0071fdbe  3bd8                     cmp        ebx, eax
0071fdc0  0f8d95000000             jge        0x71fe5b
0071fdc6  8b06                     mov        eax, dword ptr [esi]
0071fdc8  8bce                     mov        ecx, esi
0071fdca  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fdd0  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fdd3  85c9                     test       ecx, ecx
0071fdd5  7411                     je         0x71fde8
0071fdd7  8b4008                   mov        eax, dword ptr [eax + 8]
0071fdda  2bc1                     sub        eax, ecx
0071fddc  c1f802                   sar        eax, 2
0071fddf  3bd8                     cmp        ebx, eax
0071fde1  7305                     jae        0x71fde8
0071fde3  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071fde6  eb02                     jmp        0x71fdea
0071fde8  33c9                     xor        ecx, ecx
0071fdea  397104                   cmp        dword ptr [ecx + 4], esi
0071fded  755a                     jne        0x71fe49
0071fdef  8b16                     mov        edx, dword ptr [esi]
0071fdf1  8bce                     mov        ecx, esi
0071fdf3  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fdf9  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fdfc  85c9                     test       ecx, ecx
0071fdfe  7411                     je         0x71fe11
0071fe00  8b4008                   mov        eax, dword ptr [eax + 8]
0071fe03  2bc1                     sub        eax, ecx
0071fe05  c1f802                   sar        eax, 2
0071fe08  3bd8                     cmp        ebx, eax
0071fe0a  7305                     jae        0x71fe11
0071fe0c  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071fe0f  eb02                     jmp        0x71fe13
0071fe11  33c9                     xor        ecx, ecx
0071fe13  8b01                     mov        eax, dword ptr [ecx]
0071fe15  ff5050                   call       dword ptr [eax + 0x50]
0071fe18  397844                   cmp        dword ptr [eax + 0x44], edi
0071fe1b  752c                     jne        0x71fe49
0071fe1d  8b16                     mov        edx, dword ptr [esi]
0071fe1f  53                       push       ebx
0071fe20  8bce                     mov        ecx, esi
0071fe22  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fe28  8bc8                     mov        ecx, eax
0071fe2a  e87198d4ff               call       0x4696a0
0071fe2f  8bf8                     mov        edi, eax
0071fe31  85ff                     test       edi, edi
0071fe33  7411                     je         0x71fe46
0071fe35  8b07                     mov        eax, dword ptr [edi]
0071fe37  8bcf                     mov        ecx, edi
0071fe39  ff5060                   call       dword ptr [eax + 0x60]
0071fe3c  84c0                     test       al, al
0071fe3e  7406                     je         0x71fe46
0071fe40  837f6c38                 cmp        dword ptr [edi + 0x6c], 0x38
0071fe44  7409                     je         0x71fe4f
0071fe46  8b7dfc                   mov        edi, dword ptr [ebp - 4]
0071fe49  43                       inc        ebx
0071fe4a  e952ffffff               jmp        0x71fda1
0071fe4f  8b17                     mov        edx, dword ptr [edi]
0071fe51  6a00                     push       0
0071fe53  8bcf                     mov        ecx, edi
0071fe55  ff525c                   call       dword ptr [edx + 0x5c]
0071fe58  8b7dfc                   mov        edi, dword ptr [ebp - 4]
0071fe5b  8a450c                   mov        al, byte ptr [ebp + 0xc]
0071fe5e  84c0                     test       al, al
0071fe60  0f85f2000000             jne        0x71ff58
0071fe66  85f6                     test       esi, esi
0071fe68  0f84da000000             je         0x71ff48
0071fe6e  8b06                     mov        eax, dword ptr [esi]
0071fe70  8bce                     mov        ecx, esi
0071fe72  ff5064                   call       dword ptr [eax + 0x64]
0071fe75  84c0                     test       al, al
0071fe77  0f84cb000000             je         0x71ff48
0071fe7d  8b16                     mov        edx, dword ptr [esi]
0071fe7f  8bce                     mov        ecx, esi
0071fe81  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fe87  85c0                     test       eax, eax
0071fe89  0f84b9000000             je         0x71ff48
0071fe8f  33db                     xor        ebx, ebx
0071fe91  8b06                     mov        eax, dword ptr [esi]
0071fe93  8bce                     mov        ecx, esi
0071fe95  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fe9b  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fe9e  85c9                     test       ecx, ecx
0071fea0  7504                     jne        0x71fea6
0071fea2  33c0                     xor        eax, eax
0071fea4  eb08                     jmp        0x71feae
0071fea6  8b4008                   mov        eax, dword ptr [eax + 8]
0071fea9  2bc1                     sub        eax, ecx
0071feab  c1f802                   sar        eax, 2
0071feae  3bd8                     cmp        ebx, eax
0071feb0  0f8d92000000             jge        0x71ff48
0071feb6  8b16                     mov        edx, dword ptr [esi]
0071feb8  8bce                     mov        ecx, esi
0071feba  ff92c4030000             call       dword ptr [edx + 0x3c4]
0071fec0  8b4804                   mov        ecx, dword ptr [eax + 4]
0071fec3  85c9                     test       ecx, ecx
0071fec5  7411                     je         0x71fed8
0071fec7  8b4008                   mov        eax, dword ptr [eax + 8]
0071feca  2bc1                     sub        eax, ecx
0071fecc  c1f802                   sar        eax, 2
0071fecf  3bd8                     cmp        ebx, eax
0071fed1  7305                     jae        0x71fed8
0071fed3  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071fed6  eb02                     jmp        0x71feda
0071fed8  33c9                     xor        ecx, ecx
0071feda  397104                   cmp        dword ptr [ecx + 4], esi
0071fedd  755a                     jne        0x71ff39
0071fedf  8b06                     mov        eax, dword ptr [esi]
0071fee1  8bce                     mov        ecx, esi
0071fee3  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071fee9  8b4804                   mov        ecx, dword ptr [eax + 4]
0071feec  85c9                     test       ecx, ecx
0071feee  7411                     je         0x71ff01
0071fef0  8b4008                   mov        eax, dword ptr [eax + 8]
0071fef3  2bc1                     sub        eax, ecx
0071fef5  c1f802                   sar        eax, 2
0071fef8  3bd8                     cmp        ebx, eax
0071fefa  7305                     jae        0x71ff01
0071fefc  8b0c99                   mov        ecx, dword ptr [ecx + ebx*4]
0071feff  eb02                     jmp        0x71ff03
0071ff01  33c9                     xor        ecx, ecx
0071ff03  8b11                     mov        edx, dword ptr [ecx]
0071ff05  ff5250                   call       dword ptr [edx + 0x50]
0071ff08  397844                   cmp        dword ptr [eax + 0x44], edi
0071ff0b  752c                     jne        0x71ff39
0071ff0d  8b06                     mov        eax, dword ptr [esi]
0071ff0f  53                       push       ebx
0071ff10  8bce                     mov        ecx, esi
0071ff12  ff90c4030000             call       dword ptr [eax + 0x3c4]
0071ff18  8bc8                     mov        ecx, eax
0071ff1a  e88197d4ff               call       0x4696a0
0071ff1f  8bf8                     mov        edi, eax
0071ff21  85ff                     test       edi, edi
0071ff23  7411                     je         0x71ff36
0071ff25  8b17                     mov        edx, dword ptr [edi]
0071ff27  8bcf                     mov        ecx, edi
0071ff29  ff5260                   call       dword ptr [edx + 0x60]
0071ff2c  84c0                     test       al, al
0071ff2e  7406                     je         0x71ff36
0071ff30  837f6c37                 cmp        dword ptr [edi + 0x6c], 0x37
0071ff34  7409                     je         0x71ff3f
0071ff36  8b7dfc                   mov        edi, dword ptr [ebp - 4]
0071ff39  43                       inc        ebx
0071ff3a  e952ffffff               jmp        0x71fe91
0071ff3f  8b07                     mov        eax, dword ptr [edi]
0071ff41  6a00                     push       0
0071ff43  8bcf                     mov        ecx, edi
0071ff45  ff505c                   call       dword ptr [eax + 0x5c]
0071ff48  8b4df8                   mov        ecx, dword ptr [ebp - 8]
0071ff4b  51                       push       ecx
0071ff4c  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
0071ff4f  8d550c                   lea        edx, [ebp + 0xc]
0071ff52  52                       push       edx
0071ff53  e82846e4ff               call       0x564580
0071ff58  5e                       pop        esi
0071ff59  5b                       pop        ebx
0071ff5a  5f                       pop        edi
0071ff5b  8be5                     mov        esp, ebp
0071ff5d  5d                       pop        ebp
0071ff5e  c20800                   ret        8
0071ff61  cc                       int3       
0071ff62  cc                       int3       
0071ff63  cc                       int3       
0071ff64  cc                       int3       
0071ff65  cc                       int3       
0071ff66  cc                       int3       
0071ff67  cc                       int3       
0071ff68  cc                       int3       
0071ff69  cc                       int3       
0071ff6a  cc                       int3       
0071ff6b  cc                       int3       
0071ff6c  cc                       int3       
0071ff6d  cc                       int3       
0071ff6e  cc                       int3       
0071ff6f  cc                       int3       
0071ff70  55                       push       ebp
0071ff71  8bec                     mov        ebp, esp
0071ff73  53                       push       ebx
0071ff74  8b5d08                   mov        ebx, dword ptr [ebp + 8]
0071ff77  84db                     test       bl, bl
0071ff79  56                       push       esi
0071ff7a  57                       push       edi
0071ff7b  8bf1                     mov        esi, ecx
0071ff7d  742e                     je         0x71ffad
0071ff7f  8b86e02d0000             mov        eax, dword ptr [esi + 0x2de0]
0071ff85  8b38                     mov        edi, dword ptr [eax]
0071ff87  3bf8                     cmp        edi, eax
0071ff89  7454                     je         0x71ffdf
0071ff8b  eb03                     jmp        0x71ff90
0071ff8d  8d4900                   lea        ecx, [ecx]
0071ff90  8b4708                   mov        eax, dword ptr [edi + 8]
0071ff93  53                       push       ebx
0071ff94  50                       push       eax
0071ff95  8bce                     mov        ecx, esi
0071ff97  e8a4fdffff               call       0x71fd40
0071ff9c  8b3f                     mov        edi, dword ptr [edi]
0071ff9e  3bbee02d0000             cmp        edi, dword ptr [esi + 0x2de0]
0071ffa4  75ea                     jne        0x71ff90
0071ffa6  5f                       pop        edi
0071ffa7  5e                       pop        esi
0071ffa8  5b                       pop        ebx
0071ffa9  5d                       pop        ebp
0071ffaa  c20400                   ret        4
0071ffad  8b86e42d0000             mov        eax, dword ptr [esi + 0x2de4]
0071ffb3  85c0                     test       eax, eax
0071ffb5  7428                     je         0x71ffdf
0071ffb7  eb07                     jmp        0x71ffc0
0071ffb9  8da42400000000           lea        esp, [esp]
0071ffc0  8b8ee02d0000             mov        ecx, dword ptr [esi + 0x2de0]
0071ffc6  8b11                     mov        edx, dword ptr [ecx]
0071ffc8  8b4208                   mov        eax, dword ptr [edx + 8]
0071ffcb  6a00                     push       0
0071ffcd  50                       push       eax
0071ffce  8bce                     mov        ecx, esi
0071ffd0  e86bfdffff               call       0x71fd40
0071ffd5  8b86e42d0000             mov        eax, dword ptr [esi + 0x2de4]
0071ffdb  85c0                     test       eax, eax
0071ffdd  75e1                     jne        0x71ffc0
0071ffdf  5f                       pop        edi
0071ffe0  5e                       pop        esi
0071ffe1  5b                       pop        ebx
0071ffe2  5d                       pop        ebp
0071ffe3  c20400                   ret        4
0071ffe6  cc                       int3       
0071ffe7  cc                       int3       
0071ffe8  cc                       int3       
0071ffe9  cc                       int3       
0071ffea  cc                       int3       
0071ffeb  cc                       int3       
0071ffec  cc                       int3       
0071ffed  cc                       int3       
0071ffee  cc                       int3       
0071ffef  cc                       int3       
0071fff0  55                       push       ebp
0071fff1  8bec                     mov        ebp, esp
0071fff3  83ec14                   sub        esp, 0x14
0071fff6  53                       push       ebx
0071fff7  56                       push       esi
0071fff8  57                       push       edi
0071fff9  8bf1                     mov        esi, ecx
0071fffb  e890fdd8ff               call       0x4afd90
00720000  8dbe5c150000             lea        edi, [esi + 0x155c]
00720006  8bcf                     mov        ecx, edi
00720008  e85320ceff               call       0x402060
0072000d  83f827                   cmp        eax, 0x27
00720010  0f8590000000             jne        0x7200a6
00720016  83bee02c000001           cmp        dword ptr [esi + 0x2ce0], 1
0072001d  0f854d070000             jne        0x720770
00720023  8bbe04010000             mov        edi, dword ptr [esi + 0x104]
00720029  8b8f88010000             mov        ecx, dword ptr [edi + 0x188]
0072002f  85c9                     test       ecx, ecx
00720031  7409                     je         0x72003c
00720033  e8c8a9daff               call       0x4caa00
00720038  8bd8                     mov        ebx, eax
0072003a  eb06                     jmp        0x720042
0072003c  8b9f8c000000             mov        ebx, dword ptr [edi + 0x8c]
00720042  6a00                     push       0
00720044  8bcf                     mov        ecx, edi
00720046  e8654b3000               call       0xa24bb0
0072004b  8bc8                     mov        ecx, eax
0072004d  8bc3                     mov        eax, ebx
0072004f  69c010270000             imul       eax, eax, 0x2710
00720055  99                       cdq        
00720056  f7f9                     idiv       ecx
00720058  68a00f0000               push       0xfa0
0072005d  0590e8ffff               add        eax, 0xffffe890
00720062  50                       push       eax
00720063  6a00                     push       0
00720065  6800007f43               push       0x437f0000
0072006a  e841993e00               call       0xb099b0
0072006f  83c410                   add        esp, 0x10
00720072  e8cd144e00               call       0xc01544
00720077  8b8e002d0000             mov        ecx, dword ptr [esi + 0x2d00]
0072007d  8bd8                     mov        ebx, eax
0072007f  e8dc7e3000               call       0xa27f60
00720084  8b8e002d0000             mov        ecx, dword ptr [esi + 0x2d00]
0072008a  0fb6d3                   movzx      edx, bl
0072008d  c1e218                   shl        edx, 0x18
00720090  81caffffff00             or         edx, 0xffffff
00720096  52                       push       edx
00720097  68000000ff               push       0xff000000
0072009c  e82f573000               call       0xa257d0
007200a1  e9ca060000               jmp        0x720770
007200a6  8bcf                     mov        ecx, edi
007200a8  e8b31fceff               call       0x402060
007200ad  83f82b                   cmp        eax, 0x2b
007200b0  0f855e050000             jne        0x720614
007200b6  8b86902d0000             mov        eax, dword ptr [esi + 0x2d90]
007200bc  85c0                     test       eax, eax
007200be  0f8545010000             jne        0x720209
007200c4  8b8e04010000             mov        ecx, dword ptr [esi + 0x104]
007200ca  e8917e3000               call       0xa27f60
007200cf  8b86342e0000             mov        eax, dword ptr [esi + 0x2e34]
007200d5  85c0                     test       eax, eax
007200d7  7555                     jne        0x72012e
007200d9  8b8604010000             mov        eax, dword ptr [esi + 0x104]
007200df  83b82401000003           cmp        dword ptr [eax + 0x124], 3
007200e6  0f8cd0040000             jl         0x7205bc
007200ec  33c0                     xor        eax, eax
007200ee  8d9e042e0000             lea        ebx, [esi + 0x2e04]
007200f4  8b16                     mov        edx, dword ptr [esi]
007200f6  6a01                     push       1
007200f8  6a00                     push       0
007200fa  6a00                     push       0
007200fc  6a01                     push       1
007200fe  6a00                     push       0
00720100  6a00                     push       0
00720102  6aa0                     push       -0x60
00720104  8d7801                   lea        edi, [eax + 1]
00720107  8b03                     mov        eax, dword ptr [ebx]
00720109  6a37                     push       0x37
0072010b  50                       push       eax
0072010c  57                       push       edi
0072010d  8bce                     mov        ecx, esi
0072010f  ff92f8000000             call       dword ptr [edx + 0xf8]
00720115  8bc7                     mov        eax, edi
00720117  83c304                   add        ebx, 4
0072011a  83f802                   cmp        eax, 2
0072011d  7cd5                     jl         0x7200f4
0072011f  c786342e000001000000     mov        dword ptr [esi + 0x2e34], 1
00720129  e98e040000               jmp        0x7205bc
0072012e  83f801                   cmp        eax, 1
00720131  7556                     jne        0x720189
00720133  8b8e04010000             mov        ecx, dword ptr [esi + 0x104]
00720139  83b92401000006           cmp        dword ptr [ecx + 0x124], 6
00720140  0f8c76040000             jl         0x7205bc
00720146  33ff                     xor        edi, edi
00720148  8d9e0c2e0000             lea        ebx, [esi + 0x2e0c]
0072014e  8bff                     mov        edi, edi
00720150  8b03                     mov        eax, dword ptr [ebx]
00720152  8b16                     mov        edx, dword ptr [esi]
00720154  6a01                     push       1
00720156  6a00                     push       0
00720158  6a00                     push       0
0072015a  6a00                     push       0
0072015c  6a00                     push       0
0072015e  6a00                     push       0
00720160  6aa0                     push       -0x60
00720162  6a37                     push       0x37
00720164  50                       push       eax
00720165  8d4f03                   lea        ecx, [edi + 3]
00720168  51                       push       ecx
00720169  8bce                     mov        ecx, esi
0072016b  ff92f8000000             call       dword ptr [edx + 0xf8]
00720171  47                       inc        edi
00720172  83c304                   add        ebx, 4
00720175  83ff02                   cmp        edi, 2
00720178  7cd6                     jl         0x720150
0072017a  c786342e000002000000     mov        dword ptr [esi + 0x2e34], 2
00720184  e933040000               jmp        0x7205bc
00720189  83f802                   cmp        eax, 2
0072018c  0f852a040000             jne        0x7205bc
00720192  8b9604010000             mov        edx, dword ptr [esi + 0x104]
00720198  83ba2401000008           cmp        dword ptr [edx + 0x124], 8
0072019f  0f8c17040000             jl         0x7205bc
007201a5  33ff                     xor        edi, edi
007201a7  8d9e142e0000             lea        ebx, [esi + 0x2e14]
007201ad  8d4900                   lea        ecx, [ecx]
007201b0  8b0b                     mov        ecx, dword ptr [ebx]
007201b2  8b06                     mov        eax, dword ptr [esi]
007201b4  6a01                     push       1
007201b6  6a00                     push       0
007201b8  6a00                     push       0
007201ba  6a00                     push       0
007201bc  6a00                     push       0
007201be  6a00                     push       0
007201c0  6aa0                     push       -0x60
007201c2  6a37                     push       0x37
007201c4  51                       push       ecx
007201c5  8d5706                   lea        edx, [edi + 6]
007201c8  52                       push       edx
007201c9  8bce                     mov        ecx, esi
007201cb  ff90f8000000             call       dword ptr [eax + 0xf8]
007201d1  47                       inc        edi
007201d2  83c304                   add        ebx, 4
007201d5  83ff02                   cmp        edi, 2
007201d8  7cd6                     jl         0x7201b0
007201da  8b8e1c2e0000             mov        ecx, dword ptr [esi + 0x2e1c]
007201e0  e87b713000               call       0xa27360
007201e5  8b06                     mov        eax, dword ptr [esi]
007201e7  6a00                     push       0
007201e9  6a00                     push       0
007201eb  6a19                     push       0x19
007201ed  6868a3d700               push       0xd7a368
007201f2  8bce                     mov        ecx, esi
007201f4  ff900c010000             call       dword ptr [eax + 0x10c]
007201fa  c786342e000003000000     mov        dword ptr [esi + 0x2e34], 3
00720204  e9b3030000               jmp        0x7205bc
00720209  83f801                   cmp        eax, 1
0072020c  0f85aa030000             jne        0x7205bc
00720212  83be342e000003           cmp        dword ptr [esi + 0x2e34], 3
00720219  0f85d1000000             jne        0x7202f0
0072021f  8b8e04010000             mov        ecx, dword ptr [esi + 0x104]
00720225  e8367d3000               call       0xa27f60
0072022a  8b8e04010000             mov        ecx, dword ptr [esi + 0x104]
00720230  6a01                     push       1
00720232  e8a94a3000               call       0xa24ce0
00720237  8b8e04010000             mov        ecx, dword ptr [esi + 0x104]
0072023d  50                       push       eax
0072023e  e8bda7daff               call       0x4caa00
00720243  50                       push       eax
00720244  6a00                     push       0
00720246  68ff000000               push       0xff
0072024b  e8d03cd5ff               call       0x473f20
00720250  0fb6f8                   movzx      edi, al
00720253  c1e718                   shl        edi, 0x18
00720256  83c410                   add        esp, 0x10
00720259  8945f4                   mov        dword ptr [ebp - 0xc], eax
0072025c  81cfffffff00             or         edi, 0xffffff
00720262  8d9e142e0000             lea        ebx, [esi + 0x2e14]
00720268  c745f002000000           mov        dword ptr [ebp - 0x10], 2
0072026f  90                       nop        
00720270  8b0b                     mov        ecx, dword ptr [ebx]
00720272  e8e97c3000               call       0xa27f60
00720277  8b0b                     mov        ecx, dword ptr [ebx]
00720279  57                       push       edi
0072027a  68000000ff               push       0xff000000
0072027f  e84c553000               call       0xa257d0
00720284  8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00720287  83c304                   add        ebx, 4
0072028a  48                       dec        eax
0072028b  8945f0                   mov        dword ptr [ebp - 0x10], eax
0072028e  75e0                     jne        0x720270
00720290  8b45f4                   mov        eax, dword ptr [ebp - 0xc]
00720293  85c0                     test       eax, eax
00720295  7559                     jne        0x7202f0
00720297  8dbe142e0000             lea        edi, [esi + 0x2e14]
0072029d  bb02000000               mov        ebx, 2
007202a2  8b47f8                   mov        eax, dword ptr [edi - 8]
007202a5  8b16                     mov        edx, dword ptr [esi]
007202a7  50                       push       eax
007202a8  8bce                     mov        ecx, esi
007202aa  ff92fc000000             call       dword ptr [edx + 0xfc]
007202b0  8b07                     mov        eax, dword ptr [edi]
007202b2  8b16                     mov        edx, dword ptr [esi]
007202b4  50                       push       eax
007202b5  8bce                     mov        ecx, esi
007202b7  ff92fc000000             call       dword ptr [edx + 0xfc]
007202bd  83c704                   add        edi, 4
007202c0  4b                       dec        ebx
007202c1  75df                     jne        0x7202a2
007202c3  8b86202e0000             mov        eax, dword ptr [esi + 0x2e20]
007202c9  8b16                     mov        edx, dword ptr [esi]
007202cb  6a01                     push       1
007202cd  6a00                     push       0
007202cf  6a00                     push       0
007202d1  6a01                     push       1
007202d3  6a00                     push       0
007202d5  6a00                     push       0
007202d7  6aa0                     push       -0x60
007202d9  6a37                     push       0x37
007202db  50                       push       eax
007202dc  6a01                     push       1
007202de  8bce                     mov        ecx, esi
007202e0  ff92f8000000             call       dword ptr [edx + 0xf8]
007202e6  c786342e000004000000     mov        dword ptr [esi + 0x2e34], 4
007202f0  8a86002e0000             mov        al, byte ptr [esi + 0x2e00]
007202f6  84c0                     test       al, al
007202f8  0f85be020000             jne        0x7205bc
007202fe  8b8e04010000             mov        ecx, dword ptr [esi + 0x104]
00720304  83b92401000003           cmp        dword ptr [ecx + 0x124], 3
0072030b  0f8cab020000             jl         0x7205bc
00720311  8bce                     mov        ecx, esi
00720313  e878bdd7ff               call       0x49c090
00720318  84c0                     test       al, al
0072031a  0f8436020000             je         0x720556
00720320  8b16                     mov        edx, dword ptr [esi]
00720322  6a4f                     push       0x4f
00720324  8bce                     mov        ecx, esi
00720326  ff927c060000             call       dword ptr [edx + 0x67c]
0072032c  8945fc                   mov        dword ptr [ebp - 4], eax
0072032f  8b06                     mov        eax, dword ptr [esi]
00720331  6a4f                     push       0x4f
00720333  8bce                     mov        ecx, esi
00720335  ff904c060000             call       dword ptr [eax + 0x64c]
0072033b  8945ec                   mov        dword ptr [ebp - 0x14], eax
0072033e  8b86e02d0000             mov        eax, dword ptr [esi + 0x2de0]
00720344  8b18                     mov        ebx, dword ptr [eax]
00720346  3bd8                     cmp        ebx, eax
00720348  c745f000000000           mov        dword ptr [ebp - 0x10], 0
0072034f  895df4                   mov        dword ptr [ebp - 0xc], ebx
00720352  0f846b010000             je         0x7204c3
00720358  eb06                     jmp        0x720360
0072035a  8d9b00000000             lea        ebx, [ebx]
00720360  8b7b08                   mov        edi, dword ptr [ebx + 8]
00720363  85ff                     test       edi, edi
00720365  0f8447010000             je         0x7204b2
0072036b  8b17                     mov        edx, dword ptr [edi]
0072036d  8bcf                     mov        ecx, edi
0072036f  ff5264                   call       dword ptr [edx + 0x64]
00720372  84c0                     test       al, al
00720374  0f8438010000             je         0x7204b2
0072037a  8b07                     mov        eax, dword ptr [edi]
0072037c  8bcf                     mov        ecx, edi
0072037e  ff90c4030000             call       dword ptr [eax + 0x3c4]
00720384  85c0                     test       eax, eax
00720386  0f8426010000             je         0x7204b2
0072038c  33db                     xor        ebx, ebx
0072038e  8b17                     mov        edx, dword ptr [edi]
00720390  8bcf                     mov        ecx, edi
00720392  895df8                   mov        dword ptr [ebp - 8], ebx
00720395  ff92c4030000             call       dword ptr [edx + 0x3c4]
0072039b  8b4804                   mov        ecx, dword ptr [eax + 4]
0072039e  85c9                     test       ecx, ecx