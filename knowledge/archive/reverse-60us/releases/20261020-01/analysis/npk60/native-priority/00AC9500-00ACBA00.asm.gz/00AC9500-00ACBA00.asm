00ac9500  8b0f                     mov        ecx, dword ptr [edi]
00ac9502  6a00                     push       0
00ac9504  51                       push       ecx
00ac9505  50                       push       eax
00ac9506  e8a9911300               call       0xc026b4
00ac950b  83c40c                   add        esp, 0xc
00ac950e  33c9                     xor        ecx, ecx
00ac9510  8d460c                   lea        eax, [esi + 0xc]
00ac9513  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9516  6aff                     push       -1
00ac9518  894e14                   mov        dword ptr [esi + 0x14], ecx
00ac951b  51                       push       ecx
00ac951c  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac9523  66894e04                 mov        word ptr [esi + 4], cx
00ac9527  50                       push       eax
00ac9528  8bce                     mov        ecx, esi
00ac952a  e8319893ff               call       0x402d60
00ac952f  5f                       pop        edi
00ac9530  8bc6                     mov        eax, esi
00ac9532  5e                       pop        esi
00ac9533  5b                       pop        ebx
00ac9534  8be5                     mov        esp, ebp
00ac9536  5d                       pop        ebp
00ac9537  c21000                   ret        0x10
00ac953a  85db                     test       ebx, ebx
00ac953c  0f846dffffff             je         0xac94af
00ac9542  8b4b1c                   mov        ecx, dword ptr [ebx + 0x1c]
00ac9545  83f908                   cmp        ecx, 8
00ac9548  8d4304                   lea        eax, [ebx + 4]
00ac954b  894514                   mov        dword ptr [ebp + 0x14], eax
00ac954e  7205                     jb         0xac9555
00ac9550  8b4004                   mov        eax, dword ptr [eax + 4]
00ac9553  eb03                     jmp        0xac9558
00ac9555  83c004                   add        eax, 4
00ac9558  68a036e100               push       0xe136a0
00ac955d  50                       push       eax
00ac955e  e8c6871300               call       0xc01d29
00ac9563  8bf0                     mov        esi, eax
00ac9565  83c408                   add        esp, 8
00ac9568  85f6                     test       esi, esi
00ac956a  0f843fffffff             je         0xac94af
00ac9570  8b17                     mov        edx, dword ptr [edi]
00ac9572  6a00                     push       0
00ac9574  52                       push       edx
00ac9575  56                       push       esi
00ac9576  e839911300               call       0xc026b4
00ac957b  8933                     mov        dword ptr [ebx], esi
00ac957d  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9580  83c40c                   add        esp, 0xc
00ac9583  33c0                     xor        eax, eax
00ac9585  6aff                     push       -1
00ac9587  894614                   mov        dword ptr [esi + 0x14], eax
00ac958a  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac9591  50                       push       eax
00ac9592  66894604                 mov        word ptr [esi + 4], ax
00ac9596  8b4514                   mov        eax, dword ptr [ebp + 0x14]
00ac9599  50                       push       eax
00ac959a  8bce                     mov        ecx, esi
00ac959c  e8bf9793ff               call       0x402d60
00ac95a1  5f                       pop        edi
00ac95a2  8bc6                     mov        eax, esi
00ac95a4  5e                       pop        esi
00ac95a5  5b                       pop        ebx
00ac95a6  8be5                     mov        esp, ebp
00ac95a8  5d                       pop        ebp
00ac95a9  c21000                   ret        0x10
00ac95ac  cc                       int3       
00ac95ad  cc                       int3       
00ac95ae  cc                       int3       
00ac95af  cc                       int3       
00ac95b0  55                       push       ebp
00ac95b1  8bec                     mov        ebp, esp
00ac95b3  51                       push       ecx
00ac95b4  53                       push       ebx
00ac95b5  8b5d10                   mov        ebx, dword ptr [ebp + 0x10]
00ac95b8  56                       push       esi
00ac95b9  57                       push       edi
00ac95ba  8bf1                     mov        esi, ecx
00ac95bc  53                       push       ebx
00ac95bd  8975fc                   mov        dword ptr [ebp - 4], esi
00ac95c0  e808681300               call       0xbffdcd
00ac95c5  83c404                   add        esp, 4
00ac95c8  48                       dec        eax
00ac95c9  7815                     js         0xac95e0
00ac95cb  eb03                     jmp        0xac95d0
00ac95cd  8d4900                   lea        ecx, [ecx]
00ac95d0  66833c435c               cmp        word ptr [ebx + eax*2], 0x5c
00ac95d5  7506                     jne        0xac95dd
00ac95d7  66c704432f00             mov        word ptr [ebx + eax*2], 0x2f
00ac95dd  48                       dec        eax
00ac95de  79f0                     jns        0xac95d0
00ac95e0  53                       push       ebx
00ac95e1  e8ea0c0400               call       0xb0a2d0
00ac95e6  8b4604                   mov        eax, dword ptr [esi + 4]
00ac95e9  8b30                     mov        esi, dword ptr [eax]
00ac95eb  83c404                   add        esp, 4
00ac95ee  3bf0                     cmp        esi, eax
00ac95f0  7419                     je         0xac960b
00ac95f2  53                       push       ebx
00ac95f3  8d4e28                   lea        ecx, [esi + 0x28]
00ac95f6  e825fcffff               call       0xac9220
00ac95fb  8bf8                     mov        edi, eax
00ac95fd  85ff                     test       edi, edi
00ac95ff  7515                     jne        0xac9616
00ac9601  8b45fc                   mov        eax, dword ptr [ebp - 4]
00ac9604  8b36                     mov        esi, dword ptr [esi]
00ac9606  3b7004                   cmp        esi, dword ptr [eax + 4]
00ac9609  75e7                     jne        0xac95f2
00ac960b  5f                       pop        edi
00ac960c  5e                       pop        esi
00ac960d  33c0                     xor        eax, eax
00ac960f  5b                       pop        ebx
00ac9610  8be5                     mov        esp, ebp
00ac9612  5d                       pop        ebp
00ac9613  c20c00                   ret        0xc
00ac9616  8b0f                     mov        ecx, dword ptr [edi]
00ac9618  8b5e08                   mov        ebx, dword ptr [esi + 8]
00ac961b  8b5508                   mov        edx, dword ptr [ebp + 8]
00ac961e  83c608                   add        esi, 8
00ac9621  85db                     test       ebx, ebx
00ac9623  890a                     mov        dword ptr [edx], ecx
00ac9625  8b4704                   mov        eax, dword ptr [edi + 4]
00ac9628  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00ac962b  8901                     mov        dword ptr [ecx], eax
00ac962d  7419                     je         0xac9648
00ac962f  8b17                     mov        edx, dword ptr [edi]
00ac9631  6a00                     push       0
00ac9633  52                       push       edx
00ac9634  53                       push       ebx
00ac9635  e87a901300               call       0xc026b4
00ac963a  83c40c                   add        esp, 0xc
00ac963d  5f                       pop        edi
00ac963e  5e                       pop        esi
00ac963f  8bc3                     mov        eax, ebx
00ac9641  5b                       pop        ebx
00ac9642  8be5                     mov        esp, ebp
00ac9644  5d                       pop        ebp
00ac9645  c20c00                   ret        0xc
00ac9648  85f6                     test       esi, esi
00ac964a  74bf                     je         0xac960b
00ac964c  837e1c08                 cmp        dword ptr [esi + 0x1c], 8
00ac9650  7205                     jb         0xac9657
00ac9652  8b4608                   mov        eax, dword ptr [esi + 8]
00ac9655  eb03                     jmp        0xac965a
00ac9657  8d4608                   lea        eax, [esi + 8]
00ac965a  68a036e100               push       0xe136a0
00ac965f  50                       push       eax
00ac9660  e8c4861300               call       0xc01d29
00ac9665  8bd8                     mov        ebx, eax
00ac9667  83c408                   add        esp, 8
00ac966a  85db                     test       ebx, ebx
00ac966c  749d                     je         0xac960b
00ac966e  8b07                     mov        eax, dword ptr [edi]
00ac9670  6a00                     push       0
00ac9672  50                       push       eax
00ac9673  53                       push       ebx
00ac9674  e83b901300               call       0xc026b4
00ac9679  83c40c                   add        esp, 0xc
00ac967c  5f                       pop        edi
00ac967d  891e                     mov        dword ptr [esi], ebx
00ac967f  5e                       pop        esi
00ac9680  8bc3                     mov        eax, ebx
00ac9682  5b                       pop        ebx
00ac9683  8be5                     mov        esp, ebp
00ac9685  5d                       pop        ebp
00ac9686  c20c00                   ret        0xc
00ac9689  cc                       int3       
00ac968a  cc                       int3       
00ac968b  cc                       int3       
00ac968c  cc                       int3       
00ac968d  cc                       int3       
00ac968e  cc                       int3       
00ac968f  cc                       int3       
00ac9690  55                       push       ebp
00ac9691  8bec                     mov        ebp, esp
00ac9693  51                       push       ecx
00ac9694  53                       push       ebx
00ac9695  56                       push       esi
00ac9696  57                       push       edi
00ac9697  8b7d08                   mov        edi, dword ptr [ebp + 8]
00ac969a  8bf1                     mov        esi, ecx
00ac969c  57                       push       edi
00ac969d  8975fc                   mov        dword ptr [ebp - 4], esi
00ac96a0  e828671300               call       0xbffdcd
00ac96a5  83c404                   add        esp, 4
00ac96a8  48                       dec        eax
00ac96a9  7815                     js         0xac96c0
00ac96ab  eb03                     jmp        0xac96b0
00ac96ad  8d4900                   lea        ecx, [ecx]
00ac96b0  66833c475c               cmp        word ptr [edi + eax*2], 0x5c
00ac96b5  7506                     jne        0xac96bd
00ac96b7  66c704472f00             mov        word ptr [edi + eax*2], 0x2f
00ac96bd  48                       dec        eax
00ac96be  79f0                     jns        0xac96b0
00ac96c0  8b4604                   mov        eax, dword ptr [esi + 4]
00ac96c3  8b30                     mov        esi, dword ptr [eax]
00ac96c5  3bf0                     cmp        esi, eax
00ac96c7  7421                     je         0xac96ea
00ac96c9  8da42400000000           lea        esp, [esp]
00ac96d0  57                       push       edi
00ac96d1  8d4e28                   lea        ecx, [esi + 0x28]
00ac96d4  e867faffff               call       0xac9140
00ac96d9  8bd8                     mov        ebx, eax
00ac96db  83fbff                   cmp        ebx, -1
00ac96de  7515                     jne        0xac96f5
00ac96e0  8b45fc                   mov        eax, dword ptr [ebp - 4]
00ac96e3  8b36                     mov        esi, dword ptr [esi]
00ac96e5  3b7004                   cmp        esi, dword ptr [eax + 4]
00ac96e8  75e6                     jne        0xac96d0
00ac96ea  5f                       pop        edi
00ac96eb  5e                       pop        esi
00ac96ec  33c0                     xor        eax, eax
00ac96ee  5b                       pop        ebx
00ac96ef  8be5                     mov        esp, ebp
00ac96f1  5d                       pop        ebp
00ac96f2  c20400                   ret        4
00ac96f5  8d7e08                   lea        edi, [esi + 8]
00ac96f8  8b37                     mov        esi, dword ptr [edi]
00ac96fa  85f6                     test       esi, esi
00ac96fc  7417                     je         0xac9715
00ac96fe  6a00                     push       0
00ac9700  53                       push       ebx
00ac9701  56                       push       esi
00ac9702  e8ad8f1300               call       0xc026b4
00ac9707  83c40c                   add        esp, 0xc
00ac970a  5f                       pop        edi
00ac970b  8bc6                     mov        eax, esi
00ac970d  5e                       pop        esi
00ac970e  5b                       pop        ebx
00ac970f  8be5                     mov        esp, ebp
00ac9711  5d                       pop        ebp
00ac9712  c20400                   ret        4
00ac9715  85ff                     test       edi, edi
00ac9717  74d1                     je         0xac96ea
00ac9719  837f1c08                 cmp        dword ptr [edi + 0x1c], 8
00ac971d  7205                     jb         0xac9724
00ac971f  8b4708                   mov        eax, dword ptr [edi + 8]
00ac9722  eb03                     jmp        0xac9727
00ac9724  8d4708                   lea        eax, [edi + 8]
00ac9727  68a036e100               push       0xe136a0
00ac972c  50                       push       eax
00ac972d  e8f7851300               call       0xc01d29
00ac9732  8bf0                     mov        esi, eax
00ac9734  83c408                   add        esp, 8
00ac9737  85f6                     test       esi, esi
00ac9739  74af                     je         0xac96ea
00ac973b  6a00                     push       0
00ac973d  53                       push       ebx
00ac973e  56                       push       esi
00ac973f  e8708f1300               call       0xc026b4
00ac9744  83c40c                   add        esp, 0xc
00ac9747  8937                     mov        dword ptr [edi], esi
00ac9749  5f                       pop        edi
00ac974a  8bc6                     mov        eax, esi
00ac974c  5e                       pop        esi
00ac974d  5b                       pop        ebx
00ac974e  8be5                     mov        esp, ebp
00ac9750  5d                       pop        ebp
00ac9751  c20400                   ret        4
00ac9754  cc                       int3       
00ac9755  cc                       int3       
00ac9756  cc                       int3       
00ac9757  cc                       int3       
00ac9758  cc                       int3       
00ac9759  cc                       int3       
00ac975a  cc                       int3       
00ac975b  cc                       int3       
00ac975c  cc                       int3       
00ac975d  cc                       int3       
00ac975e  cc                       int3       
00ac975f  cc                       int3       
00ac9760  55                       push       ebp
00ac9761  8bec                     mov        ebp, esp
00ac9763  53                       push       ebx
00ac9764  56                       push       esi
00ac9765  8b750c                   mov        esi, dword ptr [ebp + 0xc]
00ac9768  8bc6                     mov        eax, esi
00ac976a  83e800                   sub        eax, 0
00ac976d  57                       push       edi
00ac976e  8b7d08                   mov        edi, dword ptr [ebp + 8]
00ac9771  7408                     je         0xac977b
00ac9773  48                       dec        eax
00ac9774  7514                     jne        0xac978a
00ac9776  57                       push       edi
00ac9777  6a01                     push       1
00ac9779  eb03                     jmp        0xac977e
00ac977b  57                       push       edi
00ac977c  6a00                     push       0
00ac977e  e83d0d0000               call       0xaca4c0
00ac9783  8bc8                     mov        ecx, eax
00ac9785  e866b4fcff               call       0xa94bf0
00ac978a  8b5d10                   mov        ebx, dword ptr [ebp + 0x10]
00ac978d  c1e604                   shl        esi, 4
00ac9790  8b866cab0d01             mov        eax, dword ptr [esi + 0x10dab6c]
00ac9796  85c0                     test       eax, eax
00ac9798  744f                     je         0xac97e9
00ac979a  85db                     test       ebx, ebx
00ac979c  742c                     je         0xac97ca
00ac979e  8b03                     mov        eax, dword ptr [ebx]
00ac97a0  85c0                     test       eax, eax
00ac97a2  7426                     je         0xac97ca
00ac97a4  83f802                   cmp        eax, 2
00ac97a7  7510                     jne        0xac97b9
00ac97a9  57                       push       edi
00ac97aa  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac97b0  e8dbfeffff               call       0xac9690
00ac97b5  85c0                     test       eax, eax
00ac97b7  750c                     jne        0xac97c5
00ac97b9  85db                     test       ebx, ebx
00ac97bb  7406                     je         0xac97c3
00ac97bd  c70300000000             mov        dword ptr [ebx], 0
00ac97c3  33c0                     xor        eax, eax
00ac97c5  5f                       pop        edi
00ac97c6  5e                       pop        esi
00ac97c7  5b                       pop        ebx
00ac97c8  5d                       pop        ebp
00ac97c9  c3                       ret        
00ac97ca  57                       push       edi
00ac97cb  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac97d1  e8bafeffff               call       0xac9690
00ac97d6  85c0                     test       eax, eax
00ac97d8  74df                     je         0xac97b9
00ac97da  85db                     test       ebx, ebx
00ac97dc  74e7                     je         0xac97c5
00ac97de  5f                       pop        edi
00ac97df  5e                       pop        esi
00ac97e0  c70302000000             mov        dword ptr [ebx], 2
00ac97e6  5b                       pop        ebx
00ac97e7  5d                       pop        ebp
00ac97e8  c3                       ret        
00ac97e9  68a036e100               push       0xe136a0
00ac97ee  57                       push       edi
00ac97ef  e835851300               call       0xc01d29
00ac97f4  83c408                   add        esp, 8
00ac97f7  85c0                     test       eax, eax
00ac97f9  74be                     je         0xac97b9
00ac97fb  8b4d10                   mov        ecx, dword ptr [ebp + 0x10]
00ac97fe  85c9                     test       ecx, ecx
00ac9800  74c3                     je         0xac97c5
00ac9802  5f                       pop        edi
00ac9803  5e                       pop        esi
00ac9804  c70101000000             mov        dword ptr [ecx], 1
00ac980a  5b                       pop        ebx
00ac980b  5d                       pop        ebp
00ac980c  c3                       ret        
00ac980d  cc                       int3       
00ac980e  cc                       int3       
00ac980f  cc                       int3       
00ac9810  55                       push       ebp
00ac9811  8bec                     mov        ebp, esp
00ac9813  6aff                     push       -1
00ac9815  68c433c900               push       0xc933c4
00ac981a  64a100000000             mov        eax, dword ptr fs:[0]
00ac9820  50                       push       eax
00ac9821  64892500000000           mov        dword ptr fs:[0], esp
00ac9828  83ec3c                   sub        esp, 0x3c
00ac982b  53                       push       ebx
00ac982c  56                       push       esi
00ac982d  8b7514                   mov        esi, dword ptr [ebp + 0x14]
00ac9830  33db                     xor        ebx, ebx
00ac9832  8bc6                     mov        eax, esi
00ac9834  2bc3                     sub        eax, ebx
00ac9836  57                       push       edi
00ac9837  8b7d10                   mov        edi, dword ptr [ebp + 0x10]
00ac983a  895df0                   mov        dword ptr [ebp - 0x10], ebx
00ac983d  7408                     je         0xac9847
00ac983f  48                       dec        eax
00ac9840  7513                     jne        0xac9855
00ac9842  57                       push       edi
00ac9843  6a01                     push       1
00ac9845  eb02                     jmp        0xac9849
00ac9847  57                       push       edi
00ac9848  53                       push       ebx
00ac9849  e8720c0000               call       0xaca4c0
00ac984e  8bc8                     mov        ecx, eax
00ac9850  e89bb3fcff               call       0xa94bf0
00ac9855  c1e604                   shl        esi, 4
00ac9858  399e6cab0d01             cmp        dword ptr [esi + 0x10dab6c], ebx
00ac985e  0f8448010000             je         0xac99ac
00ac9864  8b4518                   mov        eax, dword ptr [ebp + 0x18]
00ac9867  3bc3                     cmp        eax, ebx
00ac9869  0f84ae000000             je         0xac991d
00ac986f  8b00                     mov        eax, dword ptr [eax]
00ac9871  3bc3                     cmp        eax, ebx
00ac9873  0f84a4000000             je         0xac991d
00ac9879  83f802                   cmp        eax, 2
00ac987c  7558                     jne        0xac98d6
00ac987e  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00ac9881  57                       push       edi
00ac9882  50                       push       eax
00ac9883  8d4db8                   lea        ecx, [ebp - 0x48]
00ac9886  51                       push       ecx
00ac9887  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac988d  e85efaffff               call       0xac92f0
00ac9892  395dcc                   cmp        dword ptr [ebp - 0x34], ebx
00ac9895  c745fc01000000           mov        dword ptr [ebp - 4], 1
00ac989c  7429                     je         0xac98c7
00ac989e  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac98a1  8d55b8                   lea        edx, [ebp - 0x48]
00ac98a4  52                       push       edx
00ac98a5  8bce                     mov        ecx, esi
00ac98a7  e8645294ff               call       0x40eb10
00ac98ac  8d4db8                   lea        ecx, [ebp - 0x48]
00ac98af  e8bc470c00               call       0xb8e070
00ac98b4  5f                       pop        edi
00ac98b5  8bc6                     mov        eax, esi
00ac98b7  5e                       pop        esi
00ac98b8  5b                       pop        ebx
00ac98b9  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac98bc  64890d00000000           mov        dword ptr fs:[0], ecx
00ac98c3  8be5                     mov        esp, ebp
00ac98c5  5d                       pop        ebp
00ac98c6  c3                       ret        
00ac98c7  8d4db8                   lea        ecx, [ebp - 0x48]
00ac98ca  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00ac98d1  e89a470c00               call       0xb8e070
00ac98d6  8b4518                   mov        eax, dword ptr [ebp + 0x18]
00ac98d9  3bc3                     cmp        eax, ebx
00ac98db  7402                     je         0xac98df
00ac98dd  8918                     mov        dword ptr [eax], ebx
00ac98df  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac98e2  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac98e9  895e14                   mov        dword ptr [esi + 0x14], ebx
00ac98ec  68e0baca00               push       0xcabae0
00ac98f1  66895e04                 mov        word ptr [esi + 4], bx
00ac98f5  e8d3641300               call       0xbffdcd
00ac98fa  83c404                   add        esp, 4
00ac98fd  50                       push       eax
00ac98fe  68e0baca00               push       0xcabae0
00ac9903  8bce                     mov        ecx, esi
00ac9905  e8769593ff               call       0x402e80
00ac990a  5f                       pop        edi
00ac990b  8bc6                     mov        eax, esi
00ac990d  5e                       pop        esi
00ac990e  5b                       pop        ebx
00ac990f  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9912  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9919  8be5                     mov        esp, ebp
00ac991b  5d                       pop        ebp
00ac991c  c3                       ret        
00ac991d  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00ac9920  57                       push       edi
00ac9921  50                       push       eax
00ac9922  8d4dd4                   lea        ecx, [ebp - 0x2c]
00ac9925  51                       push       ecx
00ac9926  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac992c  e8bff9ffff               call       0xac92f0
00ac9931  395de8                   cmp        dword ptr [ebp - 0x18], ebx
00ac9934  895dfc                   mov        dword ptr [ebp - 4], ebx
00ac9937  7451                     je         0xac998a
00ac9939  8b4518                   mov        eax, dword ptr [ebp + 0x18]
00ac993c  3bc3                     cmp        eax, ebx
00ac993e  7406                     je         0xac9946
00ac9940  c70003000000             mov        dword ptr [eax], 3
00ac9946  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9949  6aff                     push       -1
00ac994b  53                       push       ebx
00ac994c  8d55d4                   lea        edx, [ebp - 0x2c]
00ac994f  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac9956  895e14                   mov        dword ptr [esi + 0x14], ebx
00ac9959  52                       push       edx
00ac995a  8bce                     mov        ecx, esi
00ac995c  66895e04                 mov        word ptr [esi + 4], bx
00ac9960  e8fb9393ff               call       0x402d60
00ac9965  837dec08                 cmp        dword ptr [ebp - 0x14], 8
00ac9969  729f                     jb         0xac990a
00ac996b  8b45d8                   mov        eax, dword ptr [ebp - 0x28]
00ac996e  50                       push       eax
00ac996f  e869661300               call       0xbfffdd
00ac9974  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9977  83c404                   add        esp, 4
00ac997a  5f                       pop        edi
00ac997b  8bc6                     mov        eax, esi
00ac997d  5e                       pop        esi
00ac997e  5b                       pop        ebx
00ac997f  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9986  8be5                     mov        esp, ebp
00ac9988  5d                       pop        ebp
00ac9989  c3                       ret        
00ac998a  837dec08                 cmp        dword ptr [ebp - 0x14], 8
00ac998e  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00ac9995  0f823bffffff             jb         0xac98d6
00ac999b  8b4dd8                   mov        ecx, dword ptr [ebp - 0x28]
00ac999e  51                       push       ecx
00ac999f  e839661300               call       0xbfffdd
00ac99a4  83c404                   add        esp, 4
00ac99a7  e92affffff               jmp        0xac98d6
00ac99ac  6a06                     push       6
00ac99ae  57                       push       edi
00ac99af  e8b36c1300               call       0xc00667
00ac99b4  83c408                   add        esp, 8
00ac99b7  83f8ff                   cmp        eax, -1
00ac99ba  0f8416ffffff             je         0xac98d6
00ac99c0  8b4518                   mov        eax, dword ptr [ebp + 0x18]
00ac99c3  3bc3                     cmp        eax, ebx
00ac99c5  8b550c                   mov        edx, dword ptr [ebp + 0xc]
00ac99c8  891a                     mov        dword ptr [edx], ebx
00ac99ca  7406                     je         0xac99d2
00ac99cc  c70001000000             mov        dword ptr [eax], 1
00ac99d2  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac99d5  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac99dc  895e14                   mov        dword ptr [esi + 0x14], ebx
00ac99df  57                       push       edi
00ac99e0  66895e04                 mov        word ptr [esi + 4], bx
00ac99e4  e8e4631300               call       0xbffdcd
00ac99e9  83c404                   add        esp, 4
00ac99ec  50                       push       eax
00ac99ed  57                       push       edi
00ac99ee  e910ffffff               jmp        0xac9903
00ac99f3  cc                       int3       
00ac99f4  cc                       int3       
00ac99f5  cc                       int3       
00ac99f6  cc                       int3       
00ac99f7  cc                       int3       
00ac99f8  cc                       int3       
00ac99f9  cc                       int3       
00ac99fa  cc                       int3       
00ac99fb  cc                       int3       
00ac99fc  cc                       int3       
00ac99fd  cc                       int3       
00ac99fe  cc                       int3       
00ac99ff  cc                       int3       
00ac9a00  55                       push       ebp
00ac9a01  8bec                     mov        ebp, esp
00ac9a03  6aff                     push       -1
00ac9a05  68de33c900               push       0xc933de
00ac9a0a  64a100000000             mov        eax, dword ptr fs:[0]
00ac9a10  50                       push       eax
00ac9a11  64892500000000           mov        dword ptr fs:[0], esp
00ac9a18  83ec3c                   sub        esp, 0x3c
00ac9a1b  53                       push       ebx
00ac9a1c  56                       push       esi
00ac9a1d  8b7518                   mov        esi, dword ptr [ebp + 0x18]
00ac9a20  33db                     xor        ebx, ebx
00ac9a22  8bc6                     mov        eax, esi
00ac9a24  2bc3                     sub        eax, ebx
00ac9a26  57                       push       edi
00ac9a27  8b7d10                   mov        edi, dword ptr [ebp + 0x10]
00ac9a2a  895df0                   mov        dword ptr [ebp - 0x10], ebx
00ac9a2d  7408                     je         0xac9a37
00ac9a2f  48                       dec        eax
00ac9a30  7513                     jne        0xac9a45
00ac9a32  57                       push       edi
00ac9a33  6a01                     push       1
00ac9a35  eb02                     jmp        0xac9a39
00ac9a37  57                       push       edi
00ac9a38  53                       push       ebx
00ac9a39  e8820a0000               call       0xaca4c0
00ac9a3e  8bc8                     mov        ecx, eax
00ac9a40  e8abb1fcff               call       0xa94bf0
00ac9a45  c1e604                   shl        esi, 4
00ac9a48  399e6cab0d01             cmp        dword ptr [esi + 0x10dab6c], ebx
00ac9a4e  0f8450010000             je         0xac9ba4
00ac9a54  8b451c                   mov        eax, dword ptr [ebp + 0x1c]
00ac9a57  3bc3                     cmp        eax, ebx
00ac9a59  0f84b2000000             je         0xac9b11
00ac9a5f  8b00                     mov        eax, dword ptr [eax]
00ac9a61  3bc3                     cmp        eax, ebx
00ac9a63  0f84a8000000             je         0xac9b11
00ac9a69  83f802                   cmp        eax, 2
00ac9a6c  755c                     jne        0xac9aca
00ac9a6e  8b4514                   mov        eax, dword ptr [ebp + 0x14]
00ac9a71  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00ac9a74  57                       push       edi
00ac9a75  50                       push       eax
00ac9a76  51                       push       ecx
00ac9a77  8d55b8                   lea        edx, [ebp - 0x48]
00ac9a7a  52                       push       edx
00ac9a7b  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac9a81  e8caf9ffff               call       0xac9450
00ac9a86  395dcc                   cmp        dword ptr [ebp - 0x34], ebx
00ac9a89  c745fc01000000           mov        dword ptr [ebp - 4], 1
00ac9a90  7429                     je         0xac9abb
00ac9a92  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9a95  8d45b8                   lea        eax, [ebp - 0x48]
00ac9a98  50                       push       eax
00ac9a99  8bce                     mov        ecx, esi
00ac9a9b  e8705094ff               call       0x40eb10
00ac9aa0  8d4db8                   lea        ecx, [ebp - 0x48]
00ac9aa3  e8c8450c00               call       0xb8e070
00ac9aa8  5f                       pop        edi
00ac9aa9  8bc6                     mov        eax, esi
00ac9aab  5e                       pop        esi
00ac9aac  5b                       pop        ebx
00ac9aad  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9ab0  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9ab7  8be5                     mov        esp, ebp
00ac9ab9  5d                       pop        ebp
00ac9aba  c3                       ret        
00ac9abb  8d4db8                   lea        ecx, [ebp - 0x48]
00ac9abe  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00ac9ac5  e8a6450c00               call       0xb8e070
00ac9aca  8b451c                   mov        eax, dword ptr [ebp + 0x1c]
00ac9acd  3bc3                     cmp        eax, ebx
00ac9acf  7402                     je         0xac9ad3
00ac9ad1  8918                     mov        dword ptr [eax], ebx
00ac9ad3  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9ad6  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac9add  895e14                   mov        dword ptr [esi + 0x14], ebx
00ac9ae0  68e0baca00               push       0xcabae0
00ac9ae5  66895e04                 mov        word ptr [esi + 4], bx
00ac9ae9  e8df621300               call       0xbffdcd
00ac9aee  83c404                   add        esp, 4
00ac9af1  50                       push       eax
00ac9af2  68e0baca00               push       0xcabae0
00ac9af7  8bce                     mov        ecx, esi
00ac9af9  e8829393ff               call       0x402e80
00ac9afe  5f                       pop        edi
00ac9aff  8bc6                     mov        eax, esi
00ac9b01  5e                       pop        esi
00ac9b02  5b                       pop        ebx
00ac9b03  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9b06  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9b0d  8be5                     mov        esp, ebp
00ac9b0f  5d                       pop        ebp
00ac9b10  c3                       ret        
00ac9b11  8b4d14                   mov        ecx, dword ptr [ebp + 0x14]
00ac9b14  8b550c                   mov        edx, dword ptr [ebp + 0xc]
00ac9b17  57                       push       edi
00ac9b18  51                       push       ecx
00ac9b19  52                       push       edx
00ac9b1a  8d45d4                   lea        eax, [ebp - 0x2c]
00ac9b1d  50                       push       eax
00ac9b1e  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac9b24  e827f9ffff               call       0xac9450
00ac9b29  395de8                   cmp        dword ptr [ebp - 0x18], ebx
00ac9b2c  895dfc                   mov        dword ptr [ebp - 4], ebx
00ac9b2f  7451                     je         0xac9b82
00ac9b31  8b451c                   mov        eax, dword ptr [ebp + 0x1c]
00ac9b34  3bc3                     cmp        eax, ebx
00ac9b36  7406                     je         0xac9b3e
00ac9b38  c70002000000             mov        dword ptr [eax], 2
00ac9b3e  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9b41  6aff                     push       -1
00ac9b43  53                       push       ebx
00ac9b44  8d4dd4                   lea        ecx, [ebp - 0x2c]
00ac9b47  51                       push       ecx
00ac9b48  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac9b4f  895e14                   mov        dword ptr [esi + 0x14], ebx
00ac9b52  8bce                     mov        ecx, esi
00ac9b54  66895e04                 mov        word ptr [esi + 4], bx
00ac9b58  e8039293ff               call       0x402d60
00ac9b5d  837dec08                 cmp        dword ptr [ebp - 0x14], 8
00ac9b61  729b                     jb         0xac9afe
00ac9b63  8b55d8                   mov        edx, dword ptr [ebp - 0x28]
00ac9b66  52                       push       edx
00ac9b67  e871641300               call       0xbfffdd
00ac9b6c  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9b6f  83c404                   add        esp, 4
00ac9b72  5f                       pop        edi
00ac9b73  8bc6                     mov        eax, esi
00ac9b75  5e                       pop        esi
00ac9b76  5b                       pop        ebx
00ac9b77  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9b7e  8be5                     mov        esp, ebp
00ac9b80  5d                       pop        ebp
00ac9b81  c3                       ret        
00ac9b82  837dec08                 cmp        dword ptr [ebp - 0x14], 8
00ac9b86  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00ac9b8d  0f8237ffffff             jb         0xac9aca
00ac9b93  8b45d8                   mov        eax, dword ptr [ebp - 0x28]
00ac9b96  50                       push       eax
00ac9b97  e841641300               call       0xbfffdd
00ac9b9c  83c404                   add        esp, 4
00ac9b9f  e926ffffff               jmp        0xac9aca
00ac9ba4  68a036e100               push       0xe136a0
00ac9ba9  57                       push       edi
00ac9baa  e87a811300               call       0xc01d29
00ac9baf  8bf0                     mov        esi, eax
00ac9bb1  83c408                   add        esp, 8
00ac9bb4  3bf3                     cmp        esi, ebx
00ac9bb6  0f840effffff             je         0xac9aca
00ac9bbc  8b451c                   mov        eax, dword ptr [ebp + 0x1c]
00ac9bbf  3bc3                     cmp        eax, ebx
00ac9bc1  7406                     je         0xac9bc9
00ac9bc3  c70001000000             mov        dword ptr [eax], 1
00ac9bc9  395d14                   cmp        dword ptr [ebp + 0x14], ebx
00ac9bcc  7411                     je         0xac9bdf
00ac9bce  8b4e10                   mov        ecx, dword ptr [esi + 0x10]
00ac9bd1  51                       push       ecx
00ac9bd2  e8f3a51300               call       0xc041ca
00ac9bd7  8b5514                   mov        edx, dword ptr [ebp + 0x14]
00ac9bda  83c404                   add        esp, 4
00ac9bdd  8902                     mov        dword ptr [edx], eax
00ac9bdf  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00ac9be2  3bc3                     cmp        eax, ebx
00ac9be4  7402                     je         0xac9be8
00ac9be6  8918                     mov        dword ptr [eax], ebx
00ac9be8  56                       push       esi
00ac9be9  e88e801300               call       0xc01c7c
00ac9bee  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9bf1  c7461807000000           mov        dword ptr [esi + 0x18], 7
00ac9bf8  895e14                   mov        dword ptr [esi + 0x14], ebx
00ac9bfb  57                       push       edi
00ac9bfc  66895e04                 mov        word ptr [esi + 4], bx
00ac9c00  e8c8611300               call       0xbffdcd
00ac9c05  83c408                   add        esp, 8
00ac9c08  50                       push       eax
00ac9c09  57                       push       edi
00ac9c0a  e9e8feffff               jmp        0xac9af7
00ac9c0f  cc                       int3       
00ac9c10  55                       push       ebp
00ac9c11  8bec                     mov        ebp, esp
00ac9c13  53                       push       ebx
00ac9c14  56                       push       esi
00ac9c15  8b7514                   mov        esi, dword ptr [ebp + 0x14]
00ac9c18  8bc6                     mov        eax, esi
00ac9c1a  83e800                   sub        eax, 0
00ac9c1d  57                       push       edi
00ac9c1e  8b7d10                   mov        edi, dword ptr [ebp + 0x10]
00ac9c21  7408                     je         0xac9c2b
00ac9c23  48                       dec        eax
00ac9c24  7514                     jne        0xac9c3a
00ac9c26  57                       push       edi
00ac9c27  6a01                     push       1
00ac9c29  eb03                     jmp        0xac9c2e
00ac9c2b  57                       push       edi
00ac9c2c  6a00                     push       0
00ac9c2e  e88d080000               call       0xaca4c0
00ac9c33  8bc8                     mov        ecx, eax
00ac9c35  e8b6affcff               call       0xa94bf0
00ac9c3a  8b5d18                   mov        ebx, dword ptr [ebp + 0x18]
00ac9c3d  c1e604                   shl        esi, 4
00ac9c40  8b866cab0d01             mov        eax, dword ptr [esi + 0x10dab6c]
00ac9c46  85c0                     test       eax, eax
00ac9c48  745f                     je         0xac9ca9
00ac9c4a  85db                     test       ebx, ebx
00ac9c4c  7434                     je         0xac9c82
00ac9c4e  8b03                     mov        eax, dword ptr [ebx]
00ac9c50  85c0                     test       eax, eax
00ac9c52  742e                     je         0xac9c82
00ac9c54  83f802                   cmp        eax, 2
00ac9c57  7518                     jne        0xac9c71
00ac9c59  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00ac9c5c  8b4d08                   mov        ecx, dword ptr [ebp + 8]
00ac9c5f  57                       push       edi
00ac9c60  50                       push       eax
00ac9c61  51                       push       ecx
00ac9c62  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac9c68  e843f9ffff               call       0xac95b0
00ac9c6d  85c0                     test       eax, eax
00ac9c6f  750c                     jne        0xac9c7d
00ac9c71  85db                     test       ebx, ebx
00ac9c73  7406                     je         0xac9c7b
00ac9c75  c70300000000             mov        dword ptr [ebx], 0
00ac9c7b  33c0                     xor        eax, eax
00ac9c7d  5f                       pop        edi
00ac9c7e  5e                       pop        esi
00ac9c7f  5b                       pop        ebx
00ac9c80  5d                       pop        ebp
00ac9c81  c3                       ret        
00ac9c82  8b550c                   mov        edx, dword ptr [ebp + 0xc]
00ac9c85  8b4508                   mov        eax, dword ptr [ebp + 8]
00ac9c88  57                       push       edi
00ac9c89  52                       push       edx
00ac9c8a  50                       push       eax
00ac9c8b  8d8e60ab0d01             lea        ecx, [esi + 0x10dab60]
00ac9c91  e81af9ffff               call       0xac95b0
00ac9c96  85c0                     test       eax, eax
00ac9c98  74d7                     je         0xac9c71
00ac9c9a  85db                     test       ebx, ebx
00ac9c9c  74df                     je         0xac9c7d
00ac9c9e  5f                       pop        edi
00ac9c9f  5e                       pop        esi
00ac9ca0  c70302000000             mov        dword ptr [ebx], 2
00ac9ca6  5b                       pop        ebx
00ac9ca7  5d                       pop        ebp
00ac9ca8  c3                       ret        
00ac9ca9  68a036e100               push       0xe136a0
00ac9cae  57                       push       edi
00ac9caf  e875801300               call       0xc01d29
00ac9cb4  8bf8                     mov        edi, eax
00ac9cb6  83c408                   add        esp, 8
00ac9cb9  85ff                     test       edi, edi
00ac9cbb  74b4                     je         0xac9c71
00ac9cbd  8b4518                   mov        eax, dword ptr [ebp + 0x18]
00ac9cc0  85c0                     test       eax, eax
00ac9cc2  7406                     je         0xac9cca
00ac9cc4  c70001000000             mov        dword ptr [eax], 1
00ac9cca  8b750c                   mov        esi, dword ptr [ebp + 0xc]
00ac9ccd  85f6                     test       esi, esi
00ac9ccf  740e                     je         0xac9cdf
00ac9cd1  8b4f10                   mov        ecx, dword ptr [edi + 0x10]
00ac9cd4  51                       push       ecx
00ac9cd5  e8f0a41300               call       0xc041ca
00ac9cda  83c404                   add        esp, 4
00ac9cdd  8906                     mov        dword ptr [esi], eax
00ac9cdf  8b4508                   mov        eax, dword ptr [ebp + 8]
00ac9ce2  85c0                     test       eax, eax
00ac9ce4  7406                     je         0xac9cec
00ac9ce6  c70000000000             mov        dword ptr [eax], 0
00ac9cec  8bc7                     mov        eax, edi
00ac9cee  5f                       pop        edi
00ac9cef  5e                       pop        esi
00ac9cf0  5b                       pop        ebx
00ac9cf1  5d                       pop        ebp
00ac9cf2  c3                       ret        
00ac9cf3  cc                       int3       
00ac9cf4  cc                       int3       
00ac9cf5  cc                       int3       
00ac9cf6  cc                       int3       
00ac9cf7  cc                       int3       
00ac9cf8  cc                       int3       
00ac9cf9  cc                       int3       
00ac9cfa  cc                       int3       
00ac9cfb  cc                       int3       
00ac9cfc  cc                       int3       
00ac9cfd  cc                       int3       
00ac9cfe  cc                       int3       
00ac9cff  cc                       int3       
00ac9d00  55                       push       ebp
00ac9d01  8bec                     mov        ebp, esp
00ac9d03  6aff                     push       -1
00ac9d05  68f033c900               push       0xc933f0
00ac9d0a  64a100000000             mov        eax, dword ptr fs:[0]
00ac9d10  50                       push       eax
00ac9d11  64892500000000           mov        dword ptr fs:[0], esp
00ac9d18  83ec28                   sub        esp, 0x28
00ac9d1b  53                       push       ebx
00ac9d1c  33c0                     xor        eax, eax
00ac9d1e  56                       push       esi
00ac9d1f  57                       push       edi
00ac9d20  8bd9                     mov        ebx, ecx
00ac9d22  c745ec07000000           mov        dword ptr [ebp - 0x14], 7
00ac9d29  8945e8                   mov        dword ptr [ebp - 0x18], eax
00ac9d2c  668945d8                 mov        word ptr [ebp - 0x28], ax
00ac9d30  8b7d08                   mov        edi, dword ptr [ebp + 8]
00ac9d33  57                       push       edi
00ac9d34  6a01                     push       1
00ac9d36  6a10                     push       0x10
00ac9d38  68987be600               push       0xe67b98
00ac9d3d  8945fc                   mov        dword ptr [ebp - 4], eax
00ac9d40  e861841300               call       0xc021a6
00ac9d45  8b4308                   mov        eax, dword ptr [ebx + 8]
00ac9d48  57                       push       edi
00ac9d49  6a01                     push       1
00ac9d4b  8d4df0                   lea        ecx, [ebp - 0x10]
00ac9d4e  6a04                     push       4
00ac9d50  51                       push       ecx
00ac9d51  8945f0                   mov        dword ptr [ebp - 0x10], eax
00ac9d54  e84d841300               call       0xc021a6
00ac9d59  8b4304                   mov        eax, dword ptr [ebx + 4]
00ac9d5c  8b30                     mov        esi, dword ptr [eax]
00ac9d5e  83c420                   add        esp, 0x20
00ac9d61  3bf0                     cmp        esi, eax
00ac9d63  897508                   mov        dword ptr [ebp + 8], esi
00ac9d66  7468                     je         0xac9dd0
00ac9d68  8b5628                   mov        edx, dword ptr [esi + 0x28]
00ac9d6b  6aff                     push       -1
00ac9d6d  6a00                     push       0
00ac9d6f  8d4e30                   lea        ecx, [esi + 0x30]
00ac9d72  8955cc                   mov        dword ptr [ebp - 0x34], edx
00ac9d75  8b462c                   mov        eax, dword ptr [esi + 0x2c]
00ac9d78  51                       push       ecx
00ac9d79  8d4dd4                   lea        ecx, [ebp - 0x2c]
00ac9d7c  8945d0                   mov        dword ptr [ebp - 0x30], eax
00ac9d7f  e8dc8f93ff               call       0x402d60
00ac9d84  57                       push       edi
00ac9d85  6a01                     push       1
00ac9d87  8d55cc                   lea        edx, [ebp - 0x34]
00ac9d8a  6a04                     push       4
00ac9d8c  52                       push       edx
00ac9d8d  e814841300               call       0xc021a6
00ac9d92  57                       push       edi
00ac9d93  6a01                     push       1
00ac9d95  8d45d0                   lea        eax, [ebp - 0x30]
00ac9d98  6a04                     push       4
00ac9d9a  50                       push       eax
00ac9d9b  e806841300               call       0xc021a6
00ac9da0  83c420                   add        esp, 0x20
00ac9da3  57                       push       edi
00ac9da4  6a01                     push       1
00ac9da6  6800010000               push       0x100
00ac9dab  83c60c                   add        esi, 0xc
00ac9dae  56                       push       esi
00ac9daf  e81c91fcff               call       0xa92ed0
00ac9db4  83c404                   add        esp, 4
00ac9db7  50                       push       eax
00ac9db8  e8e9831300               call       0xc021a6
00ac9dbd  83c410                   add        esp, 0x10
00ac9dc0  8d4d08                   lea        ecx, [ebp + 8]
00ac9dc3  e878080000               call       0xaca640
00ac9dc8  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9dcb  3b7304                   cmp        esi, dword ptr [ebx + 4]
00ac9dce  7598                     jne        0xac9d68
00ac9dd0  837dec08                 cmp        dword ptr [ebp - 0x14], 8
00ac9dd4  5f                       pop        edi
00ac9dd5  5e                       pop        esi
00ac9dd6  5b                       pop        ebx
00ac9dd7  720c                     jb         0xac9de5
00ac9dd9  8b4dd8                   mov        ecx, dword ptr [ebp - 0x28]
00ac9ddc  51                       push       ecx
00ac9ddd  e8fb611300               call       0xbfffdd
00ac9de2  83c404                   add        esp, 4
00ac9de5  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9de8  b801000000               mov        eax, 1
00ac9ded  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9df4  8be5                     mov        esp, ebp
00ac9df6  5d                       pop        ebp
00ac9df7  c20400                   ret        4
00ac9dfa  cc                       int3       
00ac9dfb  cc                       int3       
00ac9dfc  cc                       int3       
00ac9dfd  cc                       int3       
00ac9dfe  cc                       int3       
00ac9dff  cc                       int3       
00ac9e00  56                       push       esi
00ac9e01  8bf1                     mov        esi, ecx
00ac9e03  8b4604                   mov        eax, dword ptr [esi + 4]
00ac9e06  8b4804                   mov        ecx, dword ptr [eax + 4]
00ac9e09  51                       push       ecx
00ac9e0a  8bce                     mov        ecx, esi
00ac9e0c  e8df0f0000               call       0xacadf0
00ac9e11  8b4604                   mov        eax, dword ptr [esi + 4]
00ac9e14  894004                   mov        dword ptr [eax + 4], eax
00ac9e17  8b4604                   mov        eax, dword ptr [esi + 4]
00ac9e1a  c7460800000000           mov        dword ptr [esi + 8], 0
00ac9e21  8900                     mov        dword ptr [eax], eax
00ac9e23  8b7604                   mov        esi, dword ptr [esi + 4]
00ac9e26  897608                   mov        dword ptr [esi + 8], esi
00ac9e29  5e                       pop        esi
00ac9e2a  c3                       ret        
00ac9e2b  cc                       int3       
00ac9e2c  cc                       int3       
00ac9e2d  cc                       int3       
00ac9e2e  cc                       int3       
00ac9e2f  cc                       int3       
00ac9e30  55                       push       ebp
00ac9e31  8bec                     mov        ebp, esp
00ac9e33  6aff                     push       -1
00ac9e35  681534c900               push       0xc93415
00ac9e3a  64a100000000             mov        eax, dword ptr fs:[0]
00ac9e40  50                       push       eax
00ac9e41  64892500000000           mov        dword ptr fs:[0], esp
00ac9e48  81eca4020000             sub        esp, 0x2a4
00ac9e4e  53                       push       ebx
00ac9e4f  33db                     xor        ebx, ebx
00ac9e51  56                       push       esi
00ac9e52  894de8                   mov        dword ptr [ebp - 0x18], ecx
00ac9e55  c745c807000000           mov        dword ptr [ebp - 0x38], 7
00ac9e5c  895dc4                   mov        dword ptr [ebp - 0x3c], ebx
00ac9e5f  66895db4                 mov        word ptr [ebp - 0x4c], bx
00ac9e63  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9e66  56                       push       esi
00ac9e67  6a01                     push       1
00ac9e69  8d8558ffffff             lea        eax, [ebp - 0xa8]
00ac9e6f  6a10                     push       0x10
00ac9e71  50                       push       eax
00ac9e72  895dfc                   mov        dword ptr [ebp - 4], ebx
00ac9e75  e8bc851300               call       0xc02436
00ac9e7a  6a10                     push       0x10
00ac9e7c  8d8d58ffffff             lea        ecx, [ebp - 0xa8]
00ac9e82  51                       push       ecx
00ac9e83  68987be600               push       0xe67b98
00ac9e88  e8a3981300               call       0xc03730
00ac9e8d  83c41c                   add        esp, 0x1c
00ac9e90  85c0                     test       eax, eax
00ac9e92  7426                     je         0xac9eba
00ac9e94  837dc808                 cmp        dword ptr [ebp - 0x38], 8
00ac9e98  720c                     jb         0xac9ea6
00ac9e9a  8b55b4                   mov        edx, dword ptr [ebp - 0x4c]
00ac9e9d  52                       push       edx
00ac9e9e  e83a611300               call       0xbfffdd
00ac9ea3  83c404                   add        esp, 4
00ac9ea6  5e                       pop        esi
00ac9ea7  33c0                     xor        eax, eax
00ac9ea9  5b                       pop        ebx
00ac9eaa  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00ac9ead  64890d00000000           mov        dword ptr fs:[0], ecx
00ac9eb4  8be5                     mov        esp, ebp
00ac9eb6  5d                       pop        ebp
00ac9eb7  c20400                   ret        4
00ac9eba  56                       push       esi
00ac9ebb  6a01                     push       1
00ac9ebd  8d45ec                   lea        eax, [ebp - 0x14]
00ac9ec0  6a04                     push       4
00ac9ec2  50                       push       eax
00ac9ec3  e86e851300               call       0xc02436
00ac9ec8  8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00ac9ecb  83c410                   add        esp, 0x10
00ac9ece  3bc3                     cmp        eax, ebx
00ac9ed0  895df0                   mov        dword ptr [ebp - 0x10], ebx
00ac9ed3  0f8e4a010000             jle        0xaca023
00ac9ed9  57                       push       edi
00ac9eda  eb04                     jmp        0xac9ee0
00ac9edc  8b7508                   mov        esi, dword ptr [ebp + 8]
00ac9edf  90                       nop        
00ac9ee0  56                       push       esi
00ac9ee1  6a01                     push       1
00ac9ee3  8d4da8                   lea        ecx, [ebp - 0x58]
00ac9ee6  6a04                     push       4
00ac9ee8  51                       push       ecx
00ac9ee9  e848851300               call       0xc02436
00ac9eee  56                       push       esi
00ac9eef  6a01                     push       1
00ac9ef1  8d55ac                   lea        edx, [ebp - 0x54]
00ac9ef4  6a04                     push       4
00ac9ef6  52                       push       edx
00ac9ef7  e83a851300               call       0xc02436
00ac9efc  56                       push       esi
00ac9efd  6a01                     push       1
00ac9eff  8d8550fdffff             lea        eax, [ebp - 0x2b0]
00ac9f05  6800010000               push       0x100
00ac9f0a  50                       push       eax
00ac9f0b  e826851300               call       0xc02436
00ac9f10  8b158019ff00             mov        edx, dword ptr [0xff1980]
00ac9f16  83c430                   add        esp, 0x30
00ac9f19  b940000000               mov        ecx, 0x40
00ac9f1e  33c0                     xor        eax, eax
00ac9f20  8dbd50feffff             lea        edi, [ebp - 0x1b0]
00ac9f26  f3ab                     rep stosd  dword ptr es:[edi], eax
00ac9f28  eb06                     jmp        0xac9f30
00ac9f2a  8d9b00000000             lea        ebx, [ebx]
00ac9f30  8a0c42                   mov        cl, byte ptr [edx + eax*2]
00ac9f33  328c0550fdffff           xor        cl, byte ptr [ebp + eax - 0x2b0]
00ac9f3a  888c0550feffff           mov        byte ptr [ebp + eax - 0x1b0], cl
00ac9f41  7408                     je         0xac9f4b
00ac9f43  40                       inc        eax
00ac9f44  3d00010000               cmp        eax, 0x100
00ac9f49  7ce5                     jl         0xac9f30
00ac9f4b  8d8d50feffff             lea        ecx, [ebp - 0x1b0]
00ac9f51  51                       push       ecx
00ac9f52  889d4fffffff             mov        byte ptr [ebp - 0xb1], bl
00ac9f58  e8f38cfcff               call       0xa92c50
00ac9f5d  8bf0                     mov        esi, eax
00ac9f5f  bf07000000               mov        edi, 7
00ac9f64  56                       push       esi
00ac9f65  897de4                   mov        dword ptr [ebp - 0x1c], edi
00ac9f68  895de0                   mov        dword ptr [ebp - 0x20], ebx
00ac9f6b  66895dd0                 mov        word ptr [ebp - 0x30], bx
00ac9f6f  e8595e1300               call       0xbffdcd
00ac9f74  83c408                   add        esp, 8
00ac9f77  50                       push       eax
00ac9f78  56                       push       esi
00ac9f79  8d4dcc                   lea        ecx, [ebp - 0x34]
00ac9f7c  e8ff8e93ff               call       0x402e80
00ac9f81  8d55a8                   lea        edx, [ebp - 0x58]
00ac9f84  52                       push       edx
00ac9f85  8d45cc                   lea        eax, [ebp - 0x34]
00ac9f88  50                       push       eax
00ac9f89  8d8d68ffffff             lea        ecx, [ebp - 0x98]
00ac9f8f  c645fc01                 mov        byte ptr [ebp - 4], 1
00ac9f93  e898090000               call       0xaca930
00ac9f98  50                       push       eax
00ac9f99  8d8d50ffffff             lea        ecx, [ebp - 0xb0]
00ac9f9f  51                       push       ecx
00ac9fa0  8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00ac9fa3  c645fc02                 mov        byte ptr [ebp - 4], 2
00ac9fa7  e8f4100000               call       0xacb0a0
00ac9fac  8b45a4                   mov        eax, dword ptr [ebp - 0x5c]
00ac9faf  be08000000               mov        esi, 8
00ac9fb4  3bc6                     cmp        eax, esi
00ac9fb6  720c                     jb         0xac9fc4
00ac9fb8  8b5590                   mov        edx, dword ptr [ebp - 0x70]
00ac9fbb  52                       push       edx
00ac9fbc  e81c601300               call       0xbfffdd
00ac9fc1  83c404                   add        esp, 4
00ac9fc4  397580                   cmp        dword ptr [ebp - 0x80], esi
00ac9fc7  897da4                   mov        dword ptr [ebp - 0x5c], edi
00ac9fca  895da0                   mov        dword ptr [ebp - 0x60], ebx
00ac9fcd  66895d90                 mov        word ptr [ebp - 0x70], bx
00ac9fd1  720f                     jb         0xac9fe2
00ac9fd3  8b856cffffff             mov        eax, dword ptr [ebp - 0x94]
00ac9fd9  50                       push       eax
00ac9fda  e8fe5f1300               call       0xbfffdd
00ac9fdf  83c404                   add        esp, 4
00ac9fe2  3975e4                   cmp        dword ptr [ebp - 0x1c], esi
00ac9fe5  897d80                   mov        dword ptr [ebp - 0x80], edi
00ac9fe8  899d7cffffff             mov        dword ptr [ebp - 0x84], ebx
00ac9fee  66899d6cffffff           mov        word ptr [ebp - 0x94], bx
00ac9ff5  885dfc                   mov        byte ptr [ebp - 4], bl
00ac9ff8  720c                     jb         0xaca006
00ac9ffa  8b4dd0                   mov        ecx, dword ptr [ebp - 0x30]
00ac9ffd  51                       push       ecx
00ac9ffe  e8da5f1300               call       0xbfffdd
00aca003  83c404                   add        esp, 4
00aca006  8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00aca009  8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00aca00c  40                       inc        eax
00aca00d  3bc1                     cmp        eax, ecx
00aca00f  897de4                   mov        dword ptr [ebp - 0x1c], edi
00aca012  895de0                   mov        dword ptr [ebp - 0x20], ebx
00aca015  66895dd0                 mov        word ptr [ebp - 0x30], bx
00aca019  8945f0                   mov        dword ptr [ebp - 0x10], eax
00aca01c  0f8cbafeffff             jl         0xac9edc
00aca022  5f                       pop        edi
00aca023  837dc808                 cmp        dword ptr [ebp - 0x38], 8
00aca027  720c                     jb         0xaca035
00aca029  8b55b4                   mov        edx, dword ptr [ebp - 0x4c]
00aca02c  52                       push       edx
00aca02d  e8ab5f1300               call       0xbfffdd
00aca032  83c404                   add        esp, 4
00aca035  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca038  5e                       pop        esi
00aca039  b801000000               mov        eax, 1
00aca03e  5b                       pop        ebx
00aca03f  64890d00000000           mov        dword ptr fs:[0], ecx
00aca046  8be5                     mov        esp, ebp
00aca048  5d                       pop        ebp
00aca049  c20400                   ret        4
00aca04c  cc                       int3       
00aca04d  cc                       int3       
00aca04e  cc                       int3       
00aca04f  cc                       int3       
00aca050  55                       push       ebp
00aca051  8bec                     mov        ebp, esp
00aca053  6aff                     push       -1
00aca055  682a34c900               push       0xc9342a
00aca05a  64a100000000             mov        eax, dword ptr fs:[0]
00aca060  50                       push       eax
00aca061  64892500000000           mov        dword ptr fs:[0], esp
00aca068  51                       push       ecx
00aca069  53                       push       ebx
00aca06a  56                       push       esi
00aca06b  8bf1                     mov        esi, ecx
00aca06d  33db                     xor        ebx, ebx
00aca06f  c7461c07000000           mov        dword ptr [esi + 0x1c], 7
00aca076  895e18                   mov        dword ptr [esi + 0x18], ebx
00aca079  57                       push       edi
00aca07a  8975f0                   mov        dword ptr [ebp - 0x10], esi
00aca07d  66895e08                 mov        word ptr [esi + 8], bx
00aca081  8d7e20                   lea        edi, [esi + 0x20]
00aca084  8bcf                     mov        ecx, edi
00aca086  895dfc                   mov        dword ptr [ebp - 4], ebx
00aca089  e812060000               call       0xaca6a0
00aca08e  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca091  894704                   mov        dword ptr [edi + 4], eax
00aca094  c6404d01                 mov        byte ptr [eax + 0x4d], 1
00aca098  8b4704                   mov        eax, dword ptr [edi + 4]
00aca09b  894004                   mov        dword ptr [eax + 4], eax
00aca09e  8b4704                   mov        eax, dword ptr [edi + 4]
00aca0a1  8900                     mov        dword ptr [eax], eax
00aca0a3  8b4704                   mov        eax, dword ptr [edi + 4]
00aca0a6  894008                   mov        dword ptr [eax + 8], eax
00aca0a9  895f08                   mov        dword ptr [edi + 8], ebx
00aca0ac  891e                     mov        dword ptr [esi], ebx
00aca0ae  5f                       pop        edi
00aca0af  8bc6                     mov        eax, esi
00aca0b1  5e                       pop        esi
00aca0b2  5b                       pop        ebx
00aca0b3  64890d00000000           mov        dword ptr fs:[0], ecx
00aca0ba  8be5                     mov        esp, ebp
00aca0bc  5d                       pop        ebp
00aca0bd  c3                       ret        
00aca0be  cc                       int3       
00aca0bf  cc                       int3       
00aca0c0  55                       push       ebp
00aca0c1  8bec                     mov        ebp, esp
00aca0c3  6aff                     push       -1
00aca0c5  64a100000000             mov        eax, dword ptr fs:[0]
00aca0cb  683c34c900               push       0xc9343c
00aca0d0  50                       push       eax
00aca0d1  b8541a0000               mov        eax, 0x1a54
00aca0d6  64892500000000           mov        dword ptr fs:[0], esp
00aca0dd  e8ee6d1300               call       0xc00ed0
00aca0e2  53                       push       ebx
00aca0e3  56                       push       esi
00aca0e4  8bd9                     mov        ebx, ecx
00aca0e6  57                       push       edi
00aca0e7  8d4dbc                   lea        ecx, [ebp - 0x44]
00aca0ea  e861ffffff               call       0xaca050
00aca0ef  8b7508                   mov        esi, dword ptr [ebp + 8]
00aca0f2  56                       push       esi
00aca0f3  6800040000               push       0x400
00aca0f8  8d85a0f5ffff             lea        eax, [ebp - 0xa60]
00aca0fe  33ff                     xor        edi, edi
00aca100  50                       push       eax
00aca101  897dfc                   mov        dword ptr [ebp - 4], edi
00aca104  e8877093ff               call       0x401190
00aca109  8d8da0f5ffff             lea        ecx, [ebp - 0xa60]
00aca10f  51                       push       ecx
00aca110  e8b85c1300               call       0xbffdcd
00aca115  83c404                   add        esp, 4
00aca118  3bc7                     cmp        eax, edi
00aca11a  7e26                     jle        0xaca142
00aca11c  668b8c459ef5ffff         mov        cx, word ptr [ebp + eax*2 - 0xa62]
00aca124  6683f95c                 cmp        cx, 0x5c
00aca128  7418                     je         0xaca142
00aca12a  6683f92f                 cmp        cx, 0x2f
00aca12e  7412                     je         0xaca142
00aca130  66c78445a0f5ffff5c00     mov        word ptr [ebp + eax*2 - 0xa60], 0x5c
00aca13a  6689bc45a2f5ffff         mov        word ptr [ebp + eax*2 - 0xa5e], di
00aca142  8d95a0e5ffff             lea        edx, [ebp - 0x1a60]
00aca148  52                       push       edx
00aca149  6800040000               push       0x400
00aca14e  ff1588f34001             call       dword ptr [0x140f388]
00aca154  56                       push       esi
00aca155  ff15e8f34001             call       dword ptr [0x140f3e8]
00aca15b  8d85a0fdffff             lea        eax, [ebp - 0x260]
00aca161  50                       push       eax
00aca162  68b07ce600               push       0xe67cb0
00aca167  897d08                   mov        dword ptr [ebp + 8], edi
00aca16a  e8b3a11300               call       0xc04322
00aca16f  8bf8                     mov        edi, eax
00aca171  83c408                   add        esp, 8
00aca174  83ffff                   cmp        edi, -1
00aca177  897de8                   mov        dword ptr [ebp - 0x18], edi
00aca17a  0f84b9010000             je         0xaca339
00aca180  8d8db4fdffff             lea        ecx, [ebp - 0x24c]
00aca186  68a036e100               push       0xe136a0
00aca18b  51                       push       ecx
00aca18c  e8987b1300               call       0xc01d29
00aca191  8bf0                     mov        esi, eax
00aca193  83c408                   add        esp, 8
00aca196  85f6                     test       esi, esi
00aca198  8975f0                   mov        dword ptr [ebp - 0x10], esi
00aca19b  0f8462010000             je         0xaca303
00aca1a1  56                       push       esi
00aca1a2  e859ecffff               call       0xac8e00
00aca1a7  83c404                   add        esp, 4
00aca1aa  85c0                     test       eax, eax
00aca1ac  7538                     jne        0xaca1e6
00aca1ae  56                       push       esi
00aca1af  e8c87a1300               call       0xc01c7c
00aca1b4  68707ce600               push       0xe67c70
00aca1b9  ff15bc2eff00             call       dword ptr [0xff2ebc]
00aca1bf  8d95b4fdffff             lea        edx, [ebp - 0x24c]
00aca1c5  52                       push       edx
00aca1c6  68347ce600               push       0xe67c34
00aca1cb  ff15bc2eff00             call       dword ptr [0xff2ebc]
00aca1d1  8d85a0fdffff             lea        eax, [ebp - 0x260]
00aca1d7  50                       push       eax
00aca1d8  57                       push       edi
00aca1d9  e821a21300               call       0xc043ff
00aca1de  83c418                   add        esp, 0x18
00aca1e1  e942010000               jmp        0xaca328
00aca1e6  6a00                     push       0
00aca1e8  6a00                     push       0
00aca1ea  56                       push       esi
00aca1eb  e8c4841300               call       0xc026b4
00aca1f0  83c40c                   add        esp, 0xc
00aca1f3  56                       push       esi
00aca1f4  8d4ddc                   lea        ecx, [ebp - 0x24]
00aca1f7  e834fcffff               call       0xac9e30
00aca1fc  85c0                     test       eax, eax
00aca1fe  0f84d4000000             je         0xaca2d8
00aca204  8d8da0f5ffff             lea        ecx, [ebp - 0xa60]
00aca20a  51                       push       ecx
00aca20b  6800040000               push       0x400
00aca210  8d95a0edffff             lea        edx, [ebp - 0x1260]
00aca216  52                       push       edx
00aca217  e8746f93ff               call       0x401190
00aca21c  8d45ec                   lea        eax, [ebp - 0x14]
00aca21f  50                       push       eax
00aca220  6800040000               push       0x400
00aca225  8d8da0edffff             lea        ecx, [ebp - 0x1260]
00aca22b  51                       push       ecx
00aca22c  e81f7093ff               call       0x401250
00aca231  85c0                     test       eax, eax
00aca233  7c1f                     jl         0xaca254
00aca235  8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00aca238  8d95b4fdffff             lea        edx, [ebp - 0x24c]
00aca23e  52                       push       edx
00aca23f  b900040000               mov        ecx, 0x400
00aca244  2bc8                     sub        ecx, eax
00aca246  51                       push       ecx
00aca247  8d9445a0edffff           lea        edx, [ebp + eax*2 - 0x1260]
00aca24e  52                       push       edx
00aca24f  e83c6f93ff               call       0x401190
00aca254  8d85a0edffff             lea        eax, [ebp - 0x1260]
00aca25a  50                       push       eax
00aca25b  e86d5b1300               call       0xbffdcd
00aca260  83c404                   add        esp, 4
00aca263  50                       push       eax
00aca264  8d8da0edffff             lea        ecx, [ebp - 0x1260]
00aca26a  51                       push       ecx
00aca26b  8d4dc0                   lea        ecx, [ebp - 0x40]
00aca26e  e80d8c93ff               call       0x402e80
00aca273  8b7304                   mov        esi, dword ptr [ebx + 4]
00aca276  8b4604                   mov        eax, dword ptr [esi + 4]
00aca279  8d55bc                   lea        edx, [ebp - 0x44]
00aca27c  52                       push       edx
00aca27d  50                       push       eax
00aca27e  56                       push       esi
00aca27f  8bcb                     mov        ecx, ebx
00aca281  e8ba120000               call       0xacb540
00aca286  6a01                     push       1
00aca288  8bcb                     mov        ecx, ebx
00aca28a  8bf8                     mov        edi, eax
00aca28c  e81f070000               call       0xaca9b0
00aca291  897e04                   mov        dword ptr [esi + 4], edi
00aca294  8b4704                   mov        eax, dword ptr [edi + 4]
00aca297  8938                     mov        dword ptr [eax], edi
00aca299  8b4de0                   mov        ecx, dword ptr [ebp - 0x20]
00aca29c  8b5104                   mov        edx, dword ptr [ecx + 4]
00aca29f  52                       push       edx
00aca2a0  8d4ddc                   lea        ecx, [ebp - 0x24]
00aca2a3  e8480b0000               call       0xacadf0
00aca2a8  8b45e0                   mov        eax, dword ptr [ebp - 0x20]
00aca2ab  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
00aca2ae  8b7de8                   mov        edi, dword ptr [ebp - 0x18]
00aca2b1  894004                   mov        dword ptr [eax + 4], eax
00aca2b4  8b45e0                   mov        eax, dword ptr [ebp - 0x20]
00aca2b7  c745e400000000           mov        dword ptr [ebp - 0x1c], 0
00aca2be  8900                     mov        dword ptr [eax], eax
00aca2c0  8b45e0                   mov        eax, dword ptr [ebp - 0x20]
00aca2c3  894008                   mov        dword ptr [eax + 8], eax
00aca2c6  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca2c9  40                       inc        eax
00aca2ca  56                       push       esi
00aca2cb  894508                   mov        dword ptr [ebp + 8], eax
00aca2ce  e8a9791300               call       0xc01c7c
00aca2d3  83c404                   add        esp, 4
00aca2d6  eb40                     jmp        0xaca318
00aca2d8  68f47be600               push       0xe67bf4
00aca2dd  ff15bc2eff00             call       dword ptr [0xff2ebc]
00aca2e3  8d85b4fdffff             lea        eax, [ebp - 0x24c]
00aca2e9  50                       push       eax
00aca2ea  68d87be600               push       0xe67bd8
00aca2ef  ff15bc2eff00             call       dword ptr [0xff2ebc]
00aca2f5  83c40c                   add        esp, 0xc
00aca2f8  56                       push       esi
00aca2f9  e87e791300               call       0xc01c7c
00aca2fe  83c404                   add        esp, 4
00aca301  eb15                     jmp        0xaca318
00aca303  8d8db4fdffff             lea        ecx, [ebp - 0x24c]
00aca309  51                       push       ecx
00aca30a  68a87be600               push       0xe67ba8
00aca30f  ff15bc2eff00             call       dword ptr [0xff2ebc]
00aca315  83c408                   add        esp, 8
00aca318  8d95a0fdffff             lea        edx, [ebp - 0x260]
00aca31e  52                       push       edx
00aca31f  57                       push       edi
00aca320  e8daa01300               call       0xc043ff
00aca325  83c408                   add        esp, 8
00aca328  85c0                     test       eax, eax
00aca32a  0f8450feffff             je         0xaca180
00aca330  57                       push       edi
00aca331  e8689f1300               call       0xc0429e
00aca336  83c404                   add        esp, 4
00aca339  8d85a0e5ffff             lea        eax, [ebp - 0x1a60]
00aca33f  50                       push       eax
00aca340  ff15e8f34001             call       dword ptr [0x140f3e8]
00aca346  8d4dbc                   lea        ecx, [ebp - 0x44]
00aca349  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00aca350  e8cb100000               call       0xacb420
00aca355  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca358  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca35b  5f                       pop        edi
00aca35c  5e                       pop        esi
00aca35d  5b                       pop        ebx
00aca35e  64890d00000000           mov        dword ptr fs:[0], ecx
00aca365  8be5                     mov        esp, ebp
00aca367  5d                       pop        ebp
00aca368  c20400                   ret        4
00aca36b  cc                       int3       
00aca36c  cc                       int3       
00aca36d  cc                       int3       
00aca36e  cc                       int3       
00aca36f  cc                       int3       
00aca370  56                       push       esi
00aca371  8bf1                     mov        esi, ecx
00aca373  e8f8ecffff               call       0xac9070
00aca378  8bce                     mov        ecx, esi
00aca37a  5e                       pop        esi
00aca37b  e950120000               jmp        0xacb5d0
00aca380  55                       push       ebp
00aca381  8bec                     mov        ebp, esp
00aca383  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00aca386  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca389  c1e104                   shl        ecx, 4
00aca38c  50                       push       eax
00aca38d  81c160ab0d01             add        ecx, 0x10dab60
00aca393  e828fdffff               call       0xaca0c0
00aca398  5d                       pop        ebp
00aca399  c3                       ret        
00aca39a  cc                       int3       
00aca39b  cc                       int3       
00aca39c  cc                       int3       
00aca39d  cc                       int3       
00aca39e  cc                       int3       
00aca39f  cc                       int3       
00aca3a0  55                       push       ebp
00aca3a1  8bec                     mov        ebp, esp
00aca3a3  56                       push       esi
00aca3a4  8b7508                   mov        esi, dword ptr [ebp + 8]
00aca3a7  c1e604                   shl        esi, 4
00aca3aa  81c660ab0d01             add        esi, 0x10dab60
00aca3b0  8bce                     mov        ecx, esi
00aca3b2  e8b9ecffff               call       0xac9070
00aca3b7  8bce                     mov        ecx, esi
00aca3b9  5e                       pop        esi
00aca3ba  5d                       pop        ebp
00aca3bb  e910120000               jmp        0xacb5d0
00aca3c0  56                       push       esi
00aca3c1  8bf1                     mov        esi, ecx
00aca3c3  e808cdf9ff               call       0xa670d0
00aca3c8  894604                   mov        dword ptr [esi + 4], eax
00aca3cb  a05cab0d01               mov        al, byte ptr [0x10dab5c]
00aca3d0  84c0                     test       al, al
00aca3d2  c7460800000000           mov        dword ptr [esi + 8], 0
00aca3d9  751e                     jne        0xaca3f9
00aca3db  6800080000               push       0x800
00aca3e0  e8f2a01300               call       0xc044d7
00aca3e5  b801000000               mov        eax, 1
00aca3ea  89460c                   mov        dword ptr [esi + 0xc], eax
00aca3ed  83c404                   add        esp, 4
00aca3f0  a25cab0d01               mov        byte ptr [0x10dab5c], al
00aca3f5  8bc6                     mov        eax, esi
00aca3f7  5e                       pop        esi
00aca3f8  c3                       ret        
00aca3f9  c7460c01000000           mov        dword ptr [esi + 0xc], 1
00aca400  8bc6                     mov        eax, esi
00aca402  5e                       pop        esi
00aca403  c3                       ret        
00aca404  cc                       int3       
00aca405  cc                       int3       
00aca406  cc                       int3       
00aca407  cc                       int3       
00aca408  cc                       int3       
00aca409  cc                       int3       
00aca40a  cc                       int3       
00aca40b  cc                       int3       
00aca40c  cc                       int3       
00aca40d  cc                       int3       
00aca40e  cc                       int3       
00aca40f  cc                       int3       
00aca410  55                       push       ebp
00aca411  8bec                     mov        ebp, esp
00aca413  6aff                     push       -1
00aca415  684e34c900               push       0xc9344e
00aca41a  64a100000000             mov        eax, dword ptr fs:[0]
00aca420  50                       push       eax
00aca421  64892500000000           mov        dword ptr fs:[0], esp
00aca428  51                       push       ecx
00aca429  56                       push       esi
00aca42a  8bf1                     mov        esi, ecx
00aca42c  8975f0                   mov        dword ptr [ebp - 0x10], esi
00aca42f  c745fc00000000           mov        dword ptr [ebp - 4], 0
00aca436  e835ecffff               call       0xac9070
00aca43b  8bce                     mov        ecx, esi
00aca43d  e88e110000               call       0xacb5d0
00aca442  8bce                     mov        ecx, esi
00aca444  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
00aca44b  e880110000               call       0xacb5d0
00aca450  8b4604                   mov        eax, dword ptr [esi + 4]
00aca453  50                       push       eax
00aca454  e8845b1300               call       0xbfffdd
00aca459  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca45c  83c404                   add        esp, 4
00aca45f  c7460400000000           mov        dword ptr [esi + 4], 0
00aca466  5e                       pop        esi
00aca467  64890d00000000           mov        dword ptr fs:[0], ecx
00aca46e  8be5                     mov        esp, ebp
00aca470  5d                       pop        ebp
00aca471  c3                       ret        
00aca472  cc                       int3       
00aca473  cc                       int3       
00aca474  cc                       int3       
00aca475  cc                       int3       
00aca476  cc                       int3       
00aca477  cc                       int3       
00aca478  cc                       int3       
00aca479  cc                       int3       
00aca47a  cc                       int3       
00aca47b  cc                       int3       
00aca47c  cc                       int3       
00aca47d  cc                       int3       
00aca47e  cc                       int3       
00aca47f  cc                       int3       
00aca480  55                       push       ebp
00aca481  8bec                     mov        ebp, esp
00aca483  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca486  8b4808                   mov        ecx, dword ptr [eax + 8]
00aca489  8a514d                   mov        dl, byte ptr [ecx + 0x4d]
00aca48c  84d2                     test       dl, dl
00aca48e  750c                     jne        0xaca49c
00aca490  8bc1                     mov        eax, ecx
00aca492  8b4808                   mov        ecx, dword ptr [eax + 8]
00aca495  8a514d                   mov        dl, byte ptr [ecx + 0x4d]
00aca498  84d2                     test       dl, dl
00aca49a  74f4                     je         0xaca490
00aca49c  5d                       pop        ebp
00aca49d  c3                       ret        
00aca49e  cc                       int3       
00aca49f  cc                       int3       
00aca4a0  55                       push       ebp
00aca4a1  8bec                     mov        ebp, esp
00aca4a3  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca4a6  8b08                     mov        ecx, dword ptr [eax]
00aca4a8  8a514d                   mov        dl, byte ptr [ecx + 0x4d]
00aca4ab  84d2                     test       dl, dl
00aca4ad  750c                     jne        0xaca4bb
00aca4af  90                       nop        
00aca4b0  8bc1                     mov        eax, ecx
00aca4b2  8b08                     mov        ecx, dword ptr [eax]
00aca4b4  8a514d                   mov        dl, byte ptr [ecx + 0x4d]
00aca4b7  84d2                     test       dl, dl
00aca4b9  74f5                     je         0xaca4b0
00aca4bb  5d                       pop        ebp
00aca4bc  c3                       ret        
00aca4bd  cc                       int3       
00aca4be  cc                       int3       
00aca4bf  cc                       int3       
00aca4c0  55                       push       ebp
00aca4c1  8bec                     mov        ebp, esp
00aca4c3  64a100000000             mov        eax, dword ptr fs:[0]
00aca4c9  8a0d58ab0d01             mov        cl, byte ptr [0x10dab58]
00aca4cf  6aff                     push       -1
00aca4d1  685e33c900               push       0xc9335e
00aca4d6  50                       push       eax
00aca4d7  b801000000               mov        eax, 1
00aca4dc  84c8                     test       al, cl
00aca4de  64892500000000           mov        dword ptr fs:[0], esp
00aca4e5  7524                     jne        0xaca50b
00aca4e7  090558ab0d01             or         dword ptr [0x10dab58], eax
00aca4ed  b9b0aa0d01               mov        ecx, 0x10daab0
00aca4f2  c745fc00000000           mov        dword ptr [ebp - 4], 0
00aca4f9  e842a8fcff               call       0xa94d40
00aca4fe  68f0aaca00               push       0xcaaaf0
00aca503  e839651300               call       0xc00a41
00aca508  83c404                   add        esp, 4
00aca50b  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca50e  b8b0aa0d01               mov        eax, 0x10daab0
00aca513  64890d00000000           mov        dword ptr fs:[0], ecx
00aca51a  8be5                     mov        esp, ebp
00aca51c  5d                       pop        ebp
00aca51d  c3                       ret        
00aca51e  cc                       int3       
00aca51f  cc                       int3       
00aca520  55                       push       ebp
00aca521  8bec                     mov        ebp, esp
00aca523  8b5508                   mov        edx, dword ptr [ebp + 8]
00aca526  8b4208                   mov        eax, dword ptr [edx + 8]
00aca529  53                       push       ebx
00aca52a  56                       push       esi
00aca52b  8b30                     mov        esi, dword ptr [eax]
00aca52d  897208                   mov        dword ptr [edx + 8], esi
00aca530  8b30                     mov        esi, dword ptr [eax]
00aca532  8a5e4d                   mov        bl, byte ptr [esi + 0x4d]
00aca535  84db                     test       bl, bl
00aca537  7503                     jne        0xaca53c
00aca539  895604                   mov        dword ptr [esi + 4], edx
00aca53c  8b7204                   mov        esi, dword ptr [edx + 4]
00aca53f  897004                   mov        dword ptr [eax + 4], esi
00aca542  8b4904                   mov        ecx, dword ptr [ecx + 4]
00aca545  3b5104                   cmp        edx, dword ptr [ecx + 4]
00aca548  750e                     jne        0xaca558
00aca54a  894104                   mov        dword ptr [ecx + 4], eax
00aca54d  5e                       pop        esi
00aca54e  8910                     mov        dword ptr [eax], edx
00aca550  894204                   mov        dword ptr [edx + 4], eax
00aca553  5b                       pop        ebx
00aca554  5d                       pop        ebp
00aca555  c20400                   ret        4
00aca558  8b4a04                   mov        ecx, dword ptr [edx + 4]
00aca55b  3b11                     cmp        edx, dword ptr [ecx]
00aca55d  750d                     jne        0xaca56c
00aca55f  8901                     mov        dword ptr [ecx], eax
00aca561  5e                       pop        esi
00aca562  8910                     mov        dword ptr [eax], edx
00aca564  894204                   mov        dword ptr [edx + 4], eax
00aca567  5b                       pop        ebx
00aca568  5d                       pop        ebp
00aca569  c20400                   ret        4
00aca56c  894108                   mov        dword ptr [ecx + 8], eax
00aca56f  5e                       pop        esi
00aca570  8910                     mov        dword ptr [eax], edx
00aca572  894204                   mov        dword ptr [edx + 4], eax
00aca575  5b                       pop        ebx
00aca576  5d                       pop        ebp
00aca577  c20400                   ret        4
00aca57a  cc                       int3       
00aca57b  cc                       int3       
00aca57c  cc                       int3       
00aca57d  cc                       int3       
00aca57e  cc                       int3       
00aca57f  cc                       int3       
00aca580  55                       push       ebp
00aca581  8bec                     mov        ebp, esp
00aca583  8b5508                   mov        edx, dword ptr [ebp + 8]
00aca586  8b02                     mov        eax, dword ptr [edx]
00aca588  53                       push       ebx
00aca589  56                       push       esi
00aca58a  8b7008                   mov        esi, dword ptr [eax + 8]
00aca58d  8932                     mov        dword ptr [edx], esi
00aca58f  8b7008                   mov        esi, dword ptr [eax + 8]
00aca592  8a5e4d                   mov        bl, byte ptr [esi + 0x4d]
00aca595  84db                     test       bl, bl
00aca597  7503                     jne        0xaca59c
00aca599  895604                   mov        dword ptr [esi + 4], edx
00aca59c  8b7204                   mov        esi, dword ptr [edx + 4]
00aca59f  897004                   mov        dword ptr [eax + 4], esi
00aca5a2  8b4904                   mov        ecx, dword ptr [ecx + 4]
00aca5a5  3b5104                   cmp        edx, dword ptr [ecx + 4]
00aca5a8  750f                     jne        0xaca5b9
00aca5aa  894104                   mov        dword ptr [ecx + 4], eax
00aca5ad  5e                       pop        esi
00aca5ae  895008                   mov        dword ptr [eax + 8], edx
00aca5b1  894204                   mov        dword ptr [edx + 4], eax
00aca5b4  5b                       pop        ebx
00aca5b5  5d                       pop        ebp
00aca5b6  c20400                   ret        4
00aca5b9  8b4a04                   mov        ecx, dword ptr [edx + 4]
00aca5bc  3b5108                   cmp        edx, dword ptr [ecx + 8]
00aca5bf  750f                     jne        0xaca5d0
00aca5c1  894108                   mov        dword ptr [ecx + 8], eax
00aca5c4  5e                       pop        esi
00aca5c5  895008                   mov        dword ptr [eax + 8], edx
00aca5c8  894204                   mov        dword ptr [edx + 4], eax
00aca5cb  5b                       pop        ebx
00aca5cc  5d                       pop        ebp
00aca5cd  c20400                   ret        4
00aca5d0  8901                     mov        dword ptr [ecx], eax
00aca5d2  5e                       pop        esi
00aca5d3  895008                   mov        dword ptr [eax + 8], edx
00aca5d6  894204                   mov        dword ptr [edx + 4], eax
00aca5d9  5b                       pop        ebx
00aca5da  5d                       pop        ebp
00aca5db  c20400                   ret        4
00aca5de  cc                       int3       
00aca5df  cc                       int3       
00aca5e0  8b01                     mov        eax, dword ptr [ecx]
00aca5e2  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca5e5  84d2                     test       dl, dl
00aca5e7  7406                     je         0xaca5ef
00aca5e9  8b4008                   mov        eax, dword ptr [eax + 8]
00aca5ec  8901                     mov        dword ptr [ecx], eax
00aca5ee  c3                       ret        
00aca5ef  8b10                     mov        edx, dword ptr [eax]
00aca5f1  53                       push       ebx
00aca5f2  8a5a4d                   mov        bl, byte ptr [edx + 0x4d]
00aca5f5  84db                     test       bl, bl
00aca5f7  751a                     jne        0xaca613
00aca5f9  8b4208                   mov        eax, dword ptr [edx + 8]
00aca5fc  8a584d                   mov        bl, byte ptr [eax + 0x4d]
00aca5ff  84db                     test       bl, bl
00aca601  750c                     jne        0xaca60f
00aca603  8bd0                     mov        edx, eax
00aca605  8b4208                   mov        eax, dword ptr [edx + 8]
00aca608  8a584d                   mov        bl, byte ptr [eax + 0x4d]
00aca60b  84db                     test       bl, bl
00aca60d  74f4                     je         0xaca603
00aca60f  8911                     mov        dword ptr [ecx], edx
00aca611  5b                       pop        ebx
00aca612  c3                       ret        
00aca613  8b4004                   mov        eax, dword ptr [eax + 4]
00aca616  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca619  84d2                     test       dl, dl
00aca61b  751e                     jne        0xaca63b
00aca61d  8d4900                   lea        ecx, [ecx]
00aca620  8b11                     mov        edx, dword ptr [ecx]
00aca622  3b10                     cmp        edx, dword ptr [eax]
00aca624  750c                     jne        0xaca632
00aca626  8901                     mov        dword ptr [ecx], eax
00aca628  8b4004                   mov        eax, dword ptr [eax + 4]
00aca62b  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca62e  84d2                     test       dl, dl
00aca630  74ee                     je         0xaca620
00aca632  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca635  84d2                     test       dl, dl
00aca637  7502                     jne        0xaca63b
00aca639  8901                     mov        dword ptr [ecx], eax
00aca63b  5b                       pop        ebx
00aca63c  c3                       ret        
00aca63d  cc                       int3       
00aca63e  cc                       int3       
00aca63f  cc                       int3       
00aca640  8b01                     mov        eax, dword ptr [ecx]
00aca642  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca645  84d2                     test       dl, dl
00aca647  754d                     jne        0xaca696
00aca649  8b5008                   mov        edx, dword ptr [eax + 8]
00aca64c  53                       push       ebx
00aca64d  8a5a4d                   mov        bl, byte ptr [edx + 0x4d]
00aca650  84db                     test       bl, bl
00aca652  751b                     jne        0xaca66f
00aca654  8b02                     mov        eax, dword ptr [edx]
00aca656  8a584d                   mov        bl, byte ptr [eax + 0x4d]
00aca659  84db                     test       bl, bl
00aca65b  750e                     jne        0xaca66b
00aca65d  8d4900                   lea        ecx, [ecx]
00aca660  8bd0                     mov        edx, eax
00aca662  8b02                     mov        eax, dword ptr [edx]
00aca664  8a584d                   mov        bl, byte ptr [eax + 0x4d]
00aca667  84db                     test       bl, bl
00aca669  74f5                     je         0xaca660
00aca66b  8911                     mov        dword ptr [ecx], edx
00aca66d  5b                       pop        ebx
00aca66e  c3                       ret        
00aca66f  8b4004                   mov        eax, dword ptr [eax + 4]
00aca672  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca675  84d2                     test       dl, dl
00aca677  751a                     jne        0xaca693
00aca679  8da42400000000           lea        esp, [esp]
00aca680  8b11                     mov        edx, dword ptr [ecx]
00aca682  3b5008                   cmp        edx, dword ptr [eax + 8]
00aca685  750c                     jne        0xaca693
00aca687  8901                     mov        dword ptr [ecx], eax
00aca689  8b4004                   mov        eax, dword ptr [eax + 4]
00aca68c  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00aca68f  84d2                     test       dl, dl
00aca691  74ed                     je         0xaca680
00aca693  8901                     mov        dword ptr [ecx], eax
00aca695  5b                       pop        ebx
00aca696  c3                       ret        
00aca697  cc                       int3       
00aca698  cc                       int3       
00aca699  cc                       int3       
00aca69a  cc                       int3       
00aca69b  cc                       int3       
00aca69c  cc                       int3       
00aca69d  cc                       int3       
00aca69e  cc                       int3       
00aca69f  cc                       int3       
00aca6a0  6a50                     push       0x50
00aca6a2  e876321200               call       0xbed91d
00aca6a7  83c404                   add        esp, 4
00aca6aa  85c0                     test       eax, eax
00aca6ac  7406                     je         0xaca6b4
00aca6ae  c70000000000             mov        dword ptr [eax], 0
00aca6b4  8d4804                   lea        ecx, [eax + 4]
00aca6b7  85c9                     test       ecx, ecx
00aca6b9  7406                     je         0xaca6c1
00aca6bb  c70100000000             mov        dword ptr [ecx], 0
00aca6c1  8d4808                   lea        ecx, [eax + 8]
00aca6c4  85c9                     test       ecx, ecx
00aca6c6  7406                     je         0xaca6ce
00aca6c8  c70100000000             mov        dword ptr [ecx], 0
00aca6ce  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00aca6d2  c6404d00                 mov        byte ptr [eax + 0x4d], 0
00aca6d6  c3                       ret        
00aca6d7  cc                       int3       
00aca6d8  cc                       int3       
00aca6d9  cc                       int3       
00aca6da  cc                       int3       
00aca6db  cc                       int3       
00aca6dc  cc                       int3       
00aca6dd  cc                       int3       
00aca6de  cc                       int3       
00aca6df  cc                       int3       
00aca6e0  55                       push       ebp
00aca6e1  8bec                     mov        ebp, esp
00aca6e3  83ec0c                   sub        esp, 0xc
00aca6e6  8b4104                   mov        eax, dword ptr [ecx + 4]
00aca6e9  53                       push       ebx
00aca6ea  8b5804                   mov        ebx, dword ptr [eax + 4]
00aca6ed  8a4b4d                   mov        cl, byte ptr [ebx + 0x4d]
00aca6f0  84c9                     test       cl, cl
00aca6f2  8945fc                   mov        dword ptr [ebp - 4], eax
00aca6f5  0f8597000000             jne        0xaca792
00aca6fb  8b4d08                   mov        ecx, dword ptr [ebp + 8]
00aca6fe  8b4114                   mov        eax, dword ptr [ecx + 0x14]
00aca701  8b5118                   mov        edx, dword ptr [ecx + 0x18]
00aca704  56                       push       esi
00aca705  83c104                   add        ecx, 4
00aca708  57                       push       edi
00aca709  894508                   mov        dword ptr [ebp + 8], eax
00aca70c  8955f4                   mov        dword ptr [ebp - 0xc], edx
00aca70f  894df8                   mov        dword ptr [ebp - 8], ecx
00aca712  eb03                     jmp        0xaca717
00aca714  8b4df8                   mov        ecx, dword ptr [ebp - 8]
00aca717  837df408                 cmp        dword ptr [ebp - 0xc], 8
00aca71b  7202                     jb         0xaca71f
00aca71d  8b09                     mov        ecx, dword ptr [ecx]
00aca71f  8b7b20                   mov        edi, dword ptr [ebx + 0x20]
00aca722  8bd7                     mov        edx, edi
00aca724  3bd7                     cmp        edx, edi
00aca726  7300                     jae        0xaca728
00aca728  85ff                     test       edi, edi
00aca72a  742e                     je         0xaca75a
00aca72c  3bf8                     cmp        edi, eax
00aca72e  8bf7                     mov        esi, edi
00aca730  7202                     jb         0xaca734
00aca732  8bf0                     mov        esi, eax
00aca734  837b2408                 cmp        dword ptr [ebx + 0x24], 8
00aca738  7205                     jb         0xaca73f
00aca73a  8b5310                   mov        edx, dword ptr [ebx + 0x10]
00aca73d  eb03                     jmp        0xaca742
00aca73f  8d5310                   lea        edx, [ebx + 0x10]
00aca742  85f6                     test       esi, esi
00aca744  7614                     jbe        0xaca75a
00aca746  668b02                   mov        ax, word ptr [edx]
00aca749  663b01                   cmp        ax, word ptr [ecx]
00aca74c  7520                     jne        0xaca76e
00aca74e  83c202                   add        edx, 2
00aca751  83c102                   add        ecx, 2
00aca754  4e                       dec        esi
00aca755  75ef                     jne        0xaca746
00aca757  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca75a  3bf8                     cmp        edi, eax
00aca75c  720b                     jb         0xaca769
00aca75e  33c9                     xor        ecx, ecx
00aca760  3bf8                     cmp        edi, eax
00aca762  0f95c1                   setne      cl
00aca765  85c9                     test       ecx, ecx
00aca767  7d18                     jge        0xaca781
00aca769  8b5b08                   mov        ebx, dword ptr [ebx + 8]
00aca76c  eb18                     jmp        0xaca786
00aca76e  668b12                   mov        dx, word ptr [edx]
00aca771  663b11                   cmp        dx, word ptr [ecx]
00aca774  1bc9                     sbb        ecx, ecx
00aca776  83e1fe                   and        ecx, 0xfffffffe
00aca779  41                       inc        ecx
00aca77a  74db                     je         0xaca757
00aca77c  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca77f  ebe4                     jmp        0xaca765
00aca781  895dfc                   mov        dword ptr [ebp - 4], ebx
00aca784  8b1b                     mov        ebx, dword ptr [ebx]
00aca786  8a4b4d                   mov        cl, byte ptr [ebx + 0x4d]
00aca789  84c9                     test       cl, cl
00aca78b  7487                     je         0xaca714
00aca78d  8b45fc                   mov        eax, dword ptr [ebp - 4]
00aca790  5f                       pop        edi
00aca791  5e                       pop        esi
00aca792  5b                       pop        ebx
00aca793  8be5                     mov        esp, ebp
00aca795  5d                       pop        ebp
00aca796  c20400                   ret        4
00aca799  cc                       int3       
00aca79a  cc                       int3       
00aca79b  cc                       int3       
00aca79c  cc                       int3       
00aca79d  cc                       int3       
00aca79e  cc                       int3       
00aca79f  cc                       int3       
00aca7a0  56                       push       esi
00aca7a1  8bf1                     mov        esi, ecx
00aca7a3  837e3c08                 cmp        dword ptr [esi + 0x3c], 8
00aca7a7  57                       push       edi
00aca7a8  720c                     jb         0xaca7b6
00aca7aa  8b4628                   mov        eax, dword ptr [esi + 0x28]
00aca7ad  50                       push       eax
00aca7ae  e82a581300               call       0xbfffdd
00aca7b3  83c404                   add        esp, 4
00aca7b6  33ff                     xor        edi, edi
00aca7b8  c7463c07000000           mov        dword ptr [esi + 0x3c], 7
00aca7bf  897e38                   mov        dword ptr [esi + 0x38], edi
00aca7c2  66897e28                 mov        word ptr [esi + 0x28], di
00aca7c6  837e1808                 cmp        dword ptr [esi + 0x18], 8
00aca7ca  720c                     jb         0xaca7d8
00aca7cc  8b4e04                   mov        ecx, dword ptr [esi + 4]
00aca7cf  51                       push       ecx
00aca7d0  e808581300               call       0xbfffdd
00aca7d5  83c404                   add        esp, 4
00aca7d8  897e14                   mov        dword ptr [esi + 0x14], edi
00aca7db  c7461807000000           mov        dword ptr [esi + 0x18], 7
00aca7e2  66897e04                 mov        word ptr [esi + 4], di
00aca7e6  5f                       pop        edi
00aca7e7  5e                       pop        esi
00aca7e8  c3                       ret        
00aca7e9  cc                       int3       
00aca7ea  cc                       int3       
00aca7eb  cc                       int3       
00aca7ec  cc                       int3       
00aca7ed  cc                       int3       
00aca7ee  cc                       int3       
00aca7ef  cc                       int3       
00aca7f0  56                       push       esi
00aca7f1  8bf1                     mov        esi, ecx
00aca7f3  837e4808                 cmp        dword ptr [esi + 0x48], 8
00aca7f7  57                       push       edi
00aca7f8  720c                     jb         0xaca806
00aca7fa  8b4634                   mov        eax, dword ptr [esi + 0x34]
00aca7fd  50                       push       eax
00aca7fe  e8da571300               call       0xbfffdd
00aca803  83c404                   add        esp, 4
00aca806  33ff                     xor        edi, edi
00aca808  c7464807000000           mov        dword ptr [esi + 0x48], 7
00aca80f  897e44                   mov        dword ptr [esi + 0x44], edi
00aca812  66897e34                 mov        word ptr [esi + 0x34], di
00aca816  837e2408                 cmp        dword ptr [esi + 0x24], 8
00aca81a  720c                     jb         0xaca828
00aca81c  8b4e10                   mov        ecx, dword ptr [esi + 0x10]
00aca81f  51                       push       ecx
00aca820  e8b8571300               call       0xbfffdd
00aca825  83c404                   add        esp, 4
00aca828  897e20                   mov        dword ptr [esi + 0x20], edi
00aca82b  c7462407000000           mov        dword ptr [esi + 0x24], 7
00aca832  66897e10                 mov        word ptr [esi + 0x10], di
00aca836  5f                       pop        edi
00aca837  5e                       pop        esi
00aca838  c3                       ret        
00aca839  cc                       int3       
00aca83a  cc                       int3       
00aca83b  cc                       int3       
00aca83c  cc                       int3       
00aca83d  cc                       int3       
00aca83e  cc                       int3       
00aca83f  cc                       int3       
00aca840  55                       push       ebp
00aca841  8bec                     mov        ebp, esp
00aca843  51                       push       ecx
00aca844  56                       push       esi
00aca845  57                       push       edi
00aca846  8b7d0c                   mov        edi, dword ptr [ebp + 0xc]
00aca849  57                       push       edi
00aca84a  8bf1                     mov        esi, ecx
00aca84c  e88ffeffff               call       0xaca6e0
00aca851  3b4604                   cmp        eax, dword ptr [esi + 4]
00aca854  89450c                   mov        dword ptr [ebp + 0xc], eax
00aca857  7436                     je         0xaca88f
00aca859  83782408                 cmp        dword ptr [eax + 0x24], 8
00aca85d  8b4820                   mov        ecx, dword ptr [eax + 0x20]
00aca860  7205                     jb         0xaca867
00aca862  8b4010                   mov        eax, dword ptr [eax + 0x10]
00aca865  eb03                     jmp        0xaca86a
00aca867  83c010                   add        eax, 0x10
00aca86a  51                       push       ecx
00aca86b  50                       push       eax
00aca86c  8b4714                   mov        eax, dword ptr [edi + 0x14]
00aca86f  50                       push       eax
00aca870  6a00                     push       0
00aca872  8bcf                     mov        ecx, edi
00aca874  e8779793ff               call       0x403ff0
00aca879  85c0                     test       eax, eax
00aca87b  7c12                     jl         0xaca88f
00aca87d  8d450c                   lea        eax, [ebp + 0xc]
00aca880  8b10                     mov        edx, dword ptr [eax]
00aca882  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca885  5f                       pop        edi
00aca886  8910                     mov        dword ptr [eax], edx
00aca888  5e                       pop        esi
00aca889  8be5                     mov        esp, ebp
00aca88b  5d                       pop        ebp
00aca88c  c20800                   ret        8
00aca88f  8b4e04                   mov        ecx, dword ptr [esi + 4]
00aca892  8d45fc                   lea        eax, [ebp - 4]
00aca895  894dfc                   mov        dword ptr [ebp - 4], ecx
00aca898  8b10                     mov        edx, dword ptr [eax]
00aca89a  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca89d  5f                       pop        edi
00aca89e  8910                     mov        dword ptr [eax], edx
00aca8a0  5e                       pop        esi
00aca8a1  8be5                     mov        esp, ebp
00aca8a3  5d                       pop        ebp
00aca8a4  c20800                   ret        8
00aca8a7  cc                       int3       
00aca8a8  cc                       int3       
00aca8a9  cc                       int3       
00aca8aa  cc                       int3       
00aca8ab  cc                       int3       
00aca8ac  cc                       int3       
00aca8ad  cc                       int3       
00aca8ae  cc                       int3       
00aca8af  cc                       int3       
00aca8b0  55                       push       ebp
00aca8b1  8bec                     mov        ebp, esp
00aca8b3  6aff                     push       -1
00aca8b5  687833c900               push       0xc93378
00aca8ba  64a100000000             mov        eax, dword ptr fs:[0]
00aca8c0  50                       push       eax
00aca8c1  64892500000000           mov        dword ptr fs:[0], esp
00aca8c8  51                       push       ecx
00aca8c9  53                       push       ebx
00aca8ca  56                       push       esi
00aca8cb  57                       push       edi
00aca8cc  8b7d08                   mov        edi, dword ptr [ebp + 8]
00aca8cf  8bf1                     mov        esi, ecx
00aca8d1  33db                     xor        ebx, ebx
00aca8d3  6aff                     push       -1
00aca8d5  53                       push       ebx
00aca8d6  c7461807000000           mov        dword ptr [esi + 0x18], 7
00aca8dd  895e14                   mov        dword ptr [esi + 0x14], ebx
00aca8e0  57                       push       edi
00aca8e1  8975f0                   mov        dword ptr [ebp - 0x10], esi
00aca8e4  66895e04                 mov        word ptr [esi + 4], bx
00aca8e8  e8738493ff               call       0x402d60
00aca8ed  8b471c                   mov        eax, dword ptr [edi + 0x1c]
00aca8f0  89461c                   mov        dword ptr [esi + 0x1c], eax
00aca8f3  8b4f20                   mov        ecx, dword ptr [edi + 0x20]
00aca8f6  894e20                   mov        dword ptr [esi + 0x20], ecx
00aca8f9  6aff                     push       -1
00aca8fb  8d4e24                   lea        ecx, [esi + 0x24]
00aca8fe  53                       push       ebx
00aca8ff  83c724                   add        edi, 0x24
00aca902  c7411807000000           mov        dword ptr [ecx + 0x18], 7
00aca909  895914                   mov        dword ptr [ecx + 0x14], ebx
00aca90c  57                       push       edi
00aca90d  895dfc                   mov        dword ptr [ebp - 4], ebx
00aca910  66895904                 mov        word ptr [ecx + 4], bx
00aca914  e8478493ff               call       0x402d60
00aca919  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca91c  5f                       pop        edi
00aca91d  8bc6                     mov        eax, esi
00aca91f  5e                       pop        esi
00aca920  5b                       pop        ebx
00aca921  64890d00000000           mov        dword ptr fs:[0], ecx
00aca928  8be5                     mov        esp, ebp
00aca92a  5d                       pop        ebp
00aca92b  c20400                   ret        4
00aca92e  cc                       int3       
00aca92f  cc                       int3       
00aca930  55                       push       ebp
00aca931  8bec                     mov        ebp, esp
00aca933  6aff                     push       -1
00aca935  687833c900               push       0xc93378
00aca93a  64a100000000             mov        eax, dword ptr fs:[0]
00aca940  50                       push       eax
00aca941  64892500000000           mov        dword ptr fs:[0], esp
00aca948  51                       push       ecx
00aca949  8b4508                   mov        eax, dword ptr [ebp + 8]
00aca94c  56                       push       esi
00aca94d  57                       push       edi
00aca94e  8bf1                     mov        esi, ecx
00aca950  33ff                     xor        edi, edi
00aca952  6aff                     push       -1
00aca954  57                       push       edi
00aca955  c7461807000000           mov        dword ptr [esi + 0x18], 7
00aca95c  897e14                   mov        dword ptr [esi + 0x14], edi
00aca95f  50                       push       eax
00aca960  8975f0                   mov        dword ptr [ebp - 0x10], esi
00aca963  66897e04                 mov        word ptr [esi + 4], di
00aca967  e8f48393ff               call       0x402d60
00aca96c  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00aca96f  8b08                     mov        ecx, dword ptr [eax]
00aca971  894e1c                   mov        dword ptr [esi + 0x1c], ecx
00aca974  8b5004                   mov        edx, dword ptr [eax + 4]
00aca977  6aff                     push       -1
00aca979  8d4e24                   lea        ecx, [esi + 0x24]
00aca97c  895620                   mov        dword ptr [esi + 0x20], edx
00aca97f  57                       push       edi
00aca980  83c008                   add        eax, 8
00aca983  c7411807000000           mov        dword ptr [ecx + 0x18], 7
00aca98a  897914                   mov        dword ptr [ecx + 0x14], edi
00aca98d  50                       push       eax
00aca98e  897dfc                   mov        dword ptr [ebp - 4], edi
00aca991  66897904                 mov        word ptr [ecx + 4], di
00aca995  e8c68393ff               call       0x402d60
00aca99a  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00aca99d  5f                       pop        edi
00aca99e  8bc6                     mov        eax, esi
00aca9a0  5e                       pop        esi
00aca9a1  64890d00000000           mov        dword ptr fs:[0], ecx
00aca9a8  8be5                     mov        esp, ebp
00aca9aa  5d                       pop        ebp
00aca9ab  c20800                   ret        8
00aca9ae  cc                       int3       
00aca9af  cc                       int3       
00aca9b0  55                       push       ebp
00aca9b1  8bec                     mov        ebp, esp
00aca9b3  6aff                     push       -1
00aca9b5  68a834c900               push       0xc934a8
00aca9ba  64a100000000             mov        eax, dword ptr fs:[0]
00aca9c0  50                       push       eax
00aca9c1  64892500000000           mov        dword ptr fs:[0], esp
00aca9c8  83ec44                   sub        esp, 0x44
00aca9cb  8b4108                   mov        eax, dword ptr [ecx + 8]
00aca9ce  8b5508                   mov        edx, dword ptr [ebp + 8]
00aca9d1  56                       push       esi
00aca9d2  be5d74d105               mov        esi, 0x5d1745d
00aca9d7  2bf0                     sub        esi, eax
00aca9d9  3bf2                     cmp        esi, edx
00aca9db  5e                       pop        esi
00aca9dc  7349                     jae        0xacaa27
00aca9de  6a10                     push       0x10
00aca9e0  68f8baca00               push       0xcabaf8
00aca9e5  8d4dd8                   lea        ecx, [ebp - 0x28]
00aca9e8  c745f00f000000           mov        dword ptr [ebp - 0x10], 0xf
00aca9ef  c745ec00000000           mov        dword ptr [ebp - 0x14], 0
00aca9f6  c645dc00                 mov        byte ptr [ebp - 0x24], 0
00aca9fa  e8b18893ff               call       0x4032b0
00aca9ff  8d45d8                   lea        eax, [ebp - 0x28]
00acaa02  50                       push       eax
00acaa03  8d4db0                   lea        ecx, [ebp - 0x50]
00acaa06  c745fc00000000           mov        dword ptr [ebp - 4], 0
00acaa0d  e87e8b93ff               call       0x403590
00acaa12  681463ed00               push       0xed6314
00acaa17  8d4db0                   lea        ecx, [ebp - 0x50]
00acaa1a  51                       push       ecx
00acaa1b  c745b0a4b9ca00           mov        dword ptr [ebp - 0x50], 0xcab9a4
00acaa22  e8485b1300               call       0xc0056f
00acaa27  03c2                     add        eax, edx
00acaa29  894108                   mov        dword ptr [ecx + 8], eax
00acaa2c  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acaa2f  64890d00000000           mov        dword ptr fs:[0], ecx
00acaa36  8be5                     mov        esp, ebp
00acaa38  5d                       pop        ebp
00acaa39  c20400                   ret        4
00acaa3c  cc                       int3       
00acaa3d  cc                       int3       
00acaa3e  cc                       int3       
00acaa3f  cc                       int3       
00acaa40  55                       push       ebp
00acaa41  8bec                     mov        ebp, esp
00acaa43  6aff                     push       -1
00acaa45  687134c900               push       0xc93471
00acaa4a  64a100000000             mov        eax, dword ptr fs:[0]
00acaa50  50                       push       eax
00acaa51  64892500000000           mov        dword ptr fs:[0], esp
00acaa58  83ec0c                   sub        esp, 0xc
00acaa5b  53                       push       ebx
00acaa5c  56                       push       esi
00acaa5d  57                       push       edi
00acaa5e  8965f0                   mov        dword ptr [ebp - 0x10], esp
00acaa61  6a50                     push       0x50
00acaa63  e8b52e1200               call       0xbed91d
00acaa68  8bf0                     mov        esi, eax
00acaa6a  83c404                   add        esp, 4
00acaa6d  8975ec                   mov        dword ptr [ebp - 0x14], esi
00acaa70  c745fc00000000           mov        dword ptr [ebp - 4], 0
00acaa77  8975e8                   mov        dword ptr [ebp - 0x18], esi
00acaa7a  85f6                     test       esi, esi
00acaa7c  c645fc01                 mov        byte ptr [ebp - 4], 1
00acaa80  7427                     je         0xacaaa9
00acaa82  8b4508                   mov        eax, dword ptr [ebp + 8]
00acaa85  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00acaa88  8b5510                   mov        edx, dword ptr [ebp + 0x10]
00acaa8b  8906                     mov        dword ptr [esi], eax
00acaa8d  8b4514                   mov        eax, dword ptr [ebp + 0x14]
00acaa90  894e04                   mov        dword ptr [esi + 4], ecx
00acaa93  50                       push       eax
00acaa94  8d4e0c                   lea        ecx, [esi + 0xc]
00acaa97  895608                   mov        dword ptr [esi + 8], edx
00acaa9a  e811feffff               call       0xaca8b0
00acaa9f  8a4d18                   mov        cl, byte ptr [ebp + 0x18]
00acaaa2  884e4c                   mov        byte ptr [esi + 0x4c], cl
00acaaa5  c6464d00                 mov        byte ptr [esi + 0x4d], 0
00acaaa9  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acaaac  5f                       pop        edi
00acaaad  8bc6                     mov        eax, esi
00acaaaf  5e                       pop        esi
00acaab0  64890d00000000           mov        dword ptr fs:[0], ecx
00acaab7  5b                       pop        ebx
00acaab8  8be5                     mov        esp, ebp
00acaaba  5d                       pop        ebp
00acaabb  c21400                   ret        0x14
00acaabe  8b55ec                   mov        edx, dword ptr [ebp - 0x14]
00acaac1  52                       push       edx
00acaac2  e816551300               call       0xbfffdd
00acaac7  83c404                   add        esp, 4
00acaaca  6a00                     push       0
00acaacc  6a00                     push       0
00acaace  e89c5a1300               call       0xc0056f
00acaad3  cc                       int3       
00acaad4  cc                       int3       
00acaad5  cc                       int3       
00acaad6  cc                       int3       
00acaad7  cc                       int3       
00acaad8  cc                       int3       
00acaad9  cc                       int3       
00acaada  cc                       int3       
00acaadb  cc                       int3       
00acaadc  cc                       int3       
00acaadd  cc                       int3       
00acaade  cc                       int3       
00acaadf  cc                       int3       
00acaae0  55                       push       ebp
00acaae1  8bec                     mov        ebp, esp
00acaae3  6aff                     push       -1
00acaae5  688834c900               push       0xc93488
00acaaea  64a100000000             mov        eax, dword ptr fs:[0]
00acaaf0  50                       push       eax
00acaaf1  64892500000000           mov        dword ptr fs:[0], esp
00acaaf8  83ec48                   sub        esp, 0x48
00acaafb  53                       push       ebx
00acaafc  56                       push       esi
00acaafd  57                       push       edi
00acaafe  8b7d0c                   mov        edi, dword ptr [ebp + 0xc]
00acab01  8a474d                   mov        al, byte ptr [edi + 0x4d]
00acab04  84c0                     test       al, al
00acab06  894df0                   mov        dword ptr [ebp - 0x10], ecx
00acab09  7443                     je         0xacab4e
00acab0b  6a1b                     push       0x1b
00acab0d  33f6                     xor        esi, esi
00acab0f  680cbbca00               push       0xcabb0c
00acab14  8d4dd4                   lea        ecx, [ebp - 0x2c]
00acab17  c745ec0f000000           mov        dword ptr [ebp - 0x14], 0xf
00acab1e  8975e8                   mov        dword ptr [ebp - 0x18], esi
00acab21  c645d800                 mov        byte ptr [ebp - 0x28], 0
00acab25  e8868793ff               call       0x4032b0
00acab2a  8d45d4                   lea        eax, [ebp - 0x2c]
00acab2d  50                       push       eax
00acab2e  8d4dac                   lea        ecx, [ebp - 0x54]
00acab31  8975fc                   mov        dword ptr [ebp - 4], esi
00acab34  e8578a93ff               call       0x403590
00acab39  68c867ed00               push       0xed67c8
00acab3e  8d4dac                   lea        ecx, [ebp - 0x54]
00acab41  51                       push       ecx
00acab42  c745acf0baca00           mov        dword ptr [ebp - 0x54], 0xcabaf0
00acab49  e8215a1300               call       0xc0056f
00acab4e  8d4d0c                   lea        ecx, [ebp + 0xc]
00acab51  e8eafaffff               call       0xaca640
00acab56  8b0f                     mov        ecx, dword ptr [edi]
00acab58  8a414d                   mov        al, byte ptr [ecx + 0x4d]
00acab5b  84c0                     test       al, al
00acab5d  7405                     je         0xacab64
00acab5f  8b5f08                   mov        ebx, dword ptr [edi + 8]
00acab62  eb18                     jmp        0xacab7c
00acab64  8b5708                   mov        edx, dword ptr [edi + 8]
00acab67  8a424d                   mov        al, byte ptr [edx + 0x4d]
00acab6a  84c0                     test       al, al
00acab6c  7404                     je         0xacab72
00acab6e  8bd9                     mov        ebx, ecx
00acab70  eb0a                     jmp        0xacab7c
00acab72  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00acab75  3bc7                     cmp        eax, edi
00acab77  8b5808                   mov        ebx, dword ptr [eax + 8]
00acab7a  757c                     jne        0xacabf8
00acab7c  8a434d                   mov        al, byte ptr [ebx + 0x4d]
00acab7f  84c0                     test       al, al
00acab81  8b7704                   mov        esi, dword ptr [edi + 4]
00acab84  7503                     jne        0xacab89
00acab86  897304                   mov        dword ptr [ebx + 4], esi
00acab89  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acab8c  8b4104                   mov        eax, dword ptr [ecx + 4]
00acab8f  397804                   cmp        dword ptr [eax + 4], edi
00acab92  7505                     jne        0xacab99
00acab94  895804                   mov        dword ptr [eax + 4], ebx
00acab97  eb0b                     jmp        0xacaba4
00acab99  393e                     cmp        dword ptr [esi], edi
00acab9b  7504                     jne        0xacaba1
00acab9d  891e                     mov        dword ptr [esi], ebx
00acab9f  eb03                     jmp        0xacaba4
00acaba1  895e08                   mov        dword ptr [esi + 8], ebx
00acaba4  8b4104                   mov        eax, dword ptr [ecx + 4]
00acaba7  3938                     cmp        dword ptr [eax], edi
00acaba9  751c                     jne        0xacabc7
00acabab  8a434d                   mov        al, byte ptr [ebx + 0x4d]
00acabae  84c0                     test       al, al
00acabb0  7404                     je         0xacabb6
00acabb2  8bc6                     mov        eax, esi
00acabb4  eb0c                     jmp        0xacabc2
00acabb6  53                       push       ebx
00acabb7  e8e4f8ffff               call       0xaca4a0
00acabbc  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acabbf  83c404                   add        esp, 4
00acabc2  8b5104                   mov        edx, dword ptr [ecx + 4]
00acabc5  8902                     mov        dword ptr [edx], eax
00acabc7  8b4104                   mov        eax, dword ptr [ecx + 4]
00acabca  397808                   cmp        dword ptr [eax + 8], edi
00acabcd  0f8583000000             jne        0xacac56
00acabd3  8a434d                   mov        al, byte ptr [ebx + 0x4d]
00acabd6  84c0                     test       al, al
00acabd8  740a                     je         0xacabe4
00acabda  8b5104                   mov        edx, dword ptr [ecx + 4]
00acabdd  8bc6                     mov        eax, esi
00acabdf  894208                   mov        dword ptr [edx + 8], eax
00acabe2  eb72                     jmp        0xacac56
00acabe4  53                       push       ebx
00acabe5  e896f8ffff               call       0xaca480
00acabea  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acabed  8b5104                   mov        edx, dword ptr [ecx + 4]
00acabf0  83c404                   add        esp, 4
00acabf3  894208                   mov        dword ptr [edx + 8], eax
00acabf6  eb5e                     jmp        0xacac56
00acabf8  894104                   mov        dword ptr [ecx + 4], eax
00acabfb  8b0f                     mov        ecx, dword ptr [edi]
00acabfd  8908                     mov        dword ptr [eax], ecx
00acabff  3b4708                   cmp        eax, dword ptr [edi + 8]
00acac02  7504                     jne        0xacac08
00acac04  8bf0                     mov        esi, eax
00acac06  eb1b                     jmp        0xacac23
00acac08  8a4b4d                   mov        cl, byte ptr [ebx + 0x4d]
00acac0b  84c9                     test       cl, cl
00acac0d  8b7004                   mov        esi, dword ptr [eax + 4]
00acac10  7503                     jne        0xacac15
00acac12  897304                   mov        dword ptr [ebx + 4], esi
00acac15  891e                     mov        dword ptr [esi], ebx
00acac17  8b5708                   mov        edx, dword ptr [edi + 8]
00acac1a  895008                   mov        dword ptr [eax + 8], edx
00acac1d  8b4f08                   mov        ecx, dword ptr [edi + 8]
00acac20  894104                   mov        dword ptr [ecx + 4], eax
00acac23  8b55f0                   mov        edx, dword ptr [ebp - 0x10]
00acac26  8b4a04                   mov        ecx, dword ptr [edx + 4]
00acac29  397904                   cmp        dword ptr [ecx + 4], edi
00acac2c  7505                     jne        0xacac33
00acac2e  894104                   mov        dword ptr [ecx + 4], eax
00acac31  eb0e                     jmp        0xacac41
00acac33  8b4f04                   mov        ecx, dword ptr [edi + 4]
00acac36  3939                     cmp        dword ptr [ecx], edi
00acac38  7504                     jne        0xacac3e
00acac3a  8901                     mov        dword ptr [ecx], eax
00acac3c  eb03                     jmp        0xacac41
00acac3e  894108                   mov        dword ptr [ecx + 8], eax
00acac41  8b4f04                   mov        ecx, dword ptr [edi + 4]
00acac44  894804                   mov        dword ptr [eax + 4], ecx
00acac47  8a484c                   mov        cl, byte ptr [eax + 0x4c]
00acac4a  8a574c                   mov        dl, byte ptr [edi + 0x4c]
00acac4d  88504c                   mov        byte ptr [eax + 0x4c], dl
00acac50  884f4c                   mov        byte ptr [edi + 0x4c], cl
00acac53  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acac56  807f4c01                 cmp        byte ptr [edi + 0x4c], 1
00acac5a  0f8511010000             jne        0xacad71
00acac60  8b4104                   mov        eax, dword ptr [ecx + 4]
00acac63  3b5804                   cmp        ebx, dword ptr [eax + 4]
00acac66  0f8401010000             je         0xacad6d
00acac6c  8d642400                 lea        esp, [esp]
00acac70  807b4c01                 cmp        byte ptr [ebx + 0x4c], 1
00acac74  0f85f3000000             jne        0xacad6d
00acac7a  8b06                     mov        eax, dword ptr [esi]
00acac7c  3bd8                     cmp        ebx, eax
00acac7e  756e                     jne        0xacacee
00acac80  8b4608                   mov        eax, dword ptr [esi + 8]
00acac83  8a504c                   mov        dl, byte ptr [eax + 0x4c]
00acac86  84d2                     test       dl, dl
00acac88  7514                     jne        0xacac9e
00acac8a  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00acac8e  56                       push       esi
00acac8f  c6464c00                 mov        byte ptr [esi + 0x4c], 0
00acac93  e888f8ffff               call       0xaca520
00acac98  8b4608                   mov        eax, dword ptr [esi + 8]
00acac9b  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acac9e  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acaca1  84d2                     test       dl, dl
00acaca3  757f                     jne        0xacad24
00acaca5  8b10                     mov        edx, dword ptr [eax]
00acaca7  807a4c01                 cmp        byte ptr [edx + 0x4c], 1
00acacab  7509                     jne        0xacacb6
00acacad  8b5008                   mov        edx, dword ptr [eax + 8]
00acacb0  807a4c01                 cmp        byte ptr [edx + 0x4c], 1
00acacb4  746a                     je         0xacad20
00acacb6  8b5008                   mov        edx, dword ptr [eax + 8]
00acacb9  807a4c01                 cmp        byte ptr [edx + 0x4c], 1
00acacbd  7516                     jne        0xacacd5
00acacbf  8b10                     mov        edx, dword ptr [eax]
00acacc1  c6424c01                 mov        byte ptr [edx + 0x4c], 1
00acacc5  50                       push       eax
00acacc6  c6404c00                 mov        byte ptr [eax + 0x4c], 0
00acacca  e8b1f8ffff               call       0xaca580
00acaccf  8b4608                   mov        eax, dword ptr [esi + 8]
00acacd2  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acacd5  8a564c                   mov        dl, byte ptr [esi + 0x4c]
00acacd8  88504c                   mov        byte ptr [eax + 0x4c], dl
00acacdb  c6464c01                 mov        byte ptr [esi + 0x4c], 1
00acacdf  8b4008                   mov        eax, dword ptr [eax + 8]
00acace2  56                       push       esi
00acace3  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00acace7  e834f8ffff               call       0xaca520
00acacec  eb7f                     jmp        0xacad6d
00acacee  8a504c                   mov        dl, byte ptr [eax + 0x4c]
00acacf1  84d2                     test       dl, dl
00acacf3  7513                     jne        0xacad08
00acacf5  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00acacf9  56                       push       esi
00acacfa  c6464c00                 mov        byte ptr [esi + 0x4c], 0
00acacfe  e87df8ffff               call       0xaca580
00acad03  8b06                     mov        eax, dword ptr [esi]
00acad05  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acad08  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acad0b  84d2                     test       dl, dl
00acad0d  7515                     jne        0xacad24
00acad0f  8b5008                   mov        edx, dword ptr [eax + 8]
00acad12  807a4c01                 cmp        byte ptr [edx + 0x4c], 1
00acad16  7521                     jne        0xacad39
00acad18  8b10                     mov        edx, dword ptr [eax]
00acad1a  807a4c01                 cmp        byte ptr [edx + 0x4c], 1
00acad1e  7519                     jne        0xacad39
00acad20  c6404c00                 mov        byte ptr [eax + 0x4c], 0
00acad24  8b4104                   mov        eax, dword ptr [ecx + 4]
00acad27  8b5004                   mov        edx, dword ptr [eax + 4]
00acad2a  8bde                     mov        ebx, esi
00acad2c  3bda                     cmp        ebx, edx
00acad2e  8b7604                   mov        esi, dword ptr [esi + 4]
00acad31  0f8539ffffff             jne        0xacac70
00acad37  eb34                     jmp        0xacad6d
00acad39  8b10                     mov        edx, dword ptr [eax]
00acad3b  807a4c01                 cmp        byte ptr [edx + 0x4c], 1
00acad3f  7516                     jne        0xacad57
00acad41  8b5008                   mov        edx, dword ptr [eax + 8]
00acad44  c6424c01                 mov        byte ptr [edx + 0x4c], 1
00acad48  50                       push       eax
00acad49  c6404c00                 mov        byte ptr [eax + 0x4c], 0
00acad4d  e8cef7ffff               call       0xaca520
00acad52  8b06                     mov        eax, dword ptr [esi]
00acad54  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acad57  8a564c                   mov        dl, byte ptr [esi + 0x4c]
00acad5a  88504c                   mov        byte ptr [eax + 0x4c], dl
00acad5d  c6464c01                 mov        byte ptr [esi + 0x4c], 1
00acad61  8b00                     mov        eax, dword ptr [eax]
00acad63  56                       push       esi
00acad64  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00acad68  e813f8ffff               call       0xaca580
00acad6d  c6434c01                 mov        byte ptr [ebx + 0x4c], 1
00acad71  837f4808                 cmp        dword ptr [edi + 0x48], 8
00acad75  720c                     jb         0xacad83
00acad77  8b4f34                   mov        ecx, dword ptr [edi + 0x34]
00acad7a  51                       push       ecx
00acad7b  e85d521300               call       0xbfffdd
00acad80  83c404                   add        esp, 4
00acad83  33f6                     xor        esi, esi
00acad85  bb07000000               mov        ebx, 7
00acad8a  895f48                   mov        dword ptr [edi + 0x48], ebx
00acad8d  897744                   mov        dword ptr [edi + 0x44], esi
00acad90  66897734                 mov        word ptr [edi + 0x34], si
00acad94  837f2408                 cmp        dword ptr [edi + 0x24], 8
00acad98  720c                     jb         0xacada6
00acad9a  8b5710                   mov        edx, dword ptr [edi + 0x10]
00acad9d  52                       push       edx
00acad9e  e83a521300               call       0xbfffdd
00acada3  83c404                   add        esp, 4
00acada6  895f24                   mov        dword ptr [edi + 0x24], ebx
00acada9  897720                   mov        dword ptr [edi + 0x20], esi
00acadac  57                       push       edi
00acadad  66897710                 mov        word ptr [edi + 0x10], si
00acadb1  e827521300               call       0xbfffdd
00acadb6  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acadb9  8b4108                   mov        eax, dword ptr [ecx + 8]
00acadbc  83c404                   add        esp, 4
00acadbf  5f                       pop        edi
00acadc0  3bc6                     cmp        eax, esi
00acadc2  5e                       pop        esi
00acadc3  5b                       pop        ebx
00acadc4  7604                     jbe        0xacadca
00acadc6  48                       dec        eax
00acadc7  894108                   mov        dword ptr [ecx + 8], eax
00acadca  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00acadcd  8b4508                   mov        eax, dword ptr [ebp + 8]
00acadd0  8908                     mov        dword ptr [eax], ecx
00acadd2  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acadd5  64890d00000000           mov        dword ptr fs:[0], ecx
00acaddc  8be5                     mov        esp, ebp
00acadde  5d                       pop        ebp
00acaddf  c20800                   ret        8
00acade2  cc                       int3       
00acade3  cc                       int3       
00acade4  cc                       int3       
00acade5  cc                       int3       
00acade6  cc                       int3       
00acade7  cc                       int3       
00acade8  cc                       int3       
00acade9  cc                       int3       
00acadea  cc                       int3       
00acadeb  cc                       int3       
00acadec  cc                       int3       
00acaded  cc                       int3       
00acadee  cc                       int3       
00acadef  cc                       int3       
00acadf0  55                       push       ebp
00acadf1  8bec                     mov        ebp, esp
00acadf3  53                       push       ebx
00acadf4  56                       push       esi
00acadf5  57                       push       edi
00acadf6  8b7d08                   mov        edi, dword ptr [ebp + 8]
00acadf9  8a474d                   mov        al, byte ptr [edi + 0x4d]
00acadfc  84c0                     test       al, al
00acadfe  8bd9                     mov        ebx, ecx
00acae00  8bf7                     mov        esi, edi
00acae02  7526                     jne        0xacae2a
00acae04  8b4608                   mov        eax, dword ptr [esi + 8]
00acae07  50                       push       eax
00acae08  8bcb                     mov        ecx, ebx
00acae0a  e8e1ffffff               call       0xacadf0
00acae0f  8b36                     mov        esi, dword ptr [esi]
00acae11  8bcf                     mov        ecx, edi
00acae13  e8d8f9ffff               call       0xaca7f0
00acae18  57                       push       edi
00acae19  e8bf511300               call       0xbfffdd
00acae1e  8a464d                   mov        al, byte ptr [esi + 0x4d]
00acae21  83c404                   add        esp, 4
00acae24  84c0                     test       al, al
00acae26  8bfe                     mov        edi, esi
00acae28  74da                     je         0xacae04
00acae2a  5f                       pop        edi
00acae2b  5e                       pop        esi
00acae2c  5b                       pop        ebx
00acae2d  5d                       pop        ebp
00acae2e  c20400                   ret        4
00acae31  cc                       int3       
00acae32  cc                       int3       
00acae33  cc                       int3       
00acae34  cc                       int3       
00acae35  cc                       int3       
00acae36  cc                       int3       
00acae37  cc                       int3       
00acae38  cc                       int3       
00acae39  cc                       int3       
00acae3a  cc                       int3       
00acae3b  cc                       int3       
00acae3c  cc                       int3       
00acae3d  cc                       int3       
00acae3e  cc                       int3       
00acae3f  cc                       int3       
00acae40  55                       push       ebp
00acae41  8bec                     mov        ebp, esp
00acae43  6aff                     push       -1
00acae45  68a834c900               push       0xc934a8
00acae4a  64a100000000             mov        eax, dword ptr fs:[0]
00acae50  50                       push       eax
00acae51  64892500000000           mov        dword ptr fs:[0], esp
00acae58  83ec44                   sub        esp, 0x44
00acae5b  53                       push       ebx
00acae5c  56                       push       esi
00acae5d  57                       push       edi
00acae5e  8bf9                     mov        edi, ecx
00acae60  817f08feffff03           cmp        dword ptr [edi + 8], 0x3fffffe
00acae67  7243                     jb         0xacaeac
00acae69  6a13                     push       0x13
00acae6b  33f6                     xor        esi, esi
00acae6d  6878b4cb00               push       0xcbb478
00acae72  8d4dd8                   lea        ecx, [ebp - 0x28]
00acae75  c745f00f000000           mov        dword ptr [ebp - 0x10], 0xf
00acae7c  8975ec                   mov        dword ptr [ebp - 0x14], esi
00acae7f  c645dc00                 mov        byte ptr [ebp - 0x24], 0
00acae83  e8288493ff               call       0x4032b0
00acae88  8d45d8                   lea        eax, [ebp - 0x28]
00acae8b  50                       push       eax
00acae8c  8d4db0                   lea        ecx, [ebp - 0x50]
00acae8f  8975fc                   mov        dword ptr [ebp - 4], esi
00acae92  e8f98693ff               call       0x403590
00acae97  681463ed00               push       0xed6314
00acae9c  8d4db0                   lea        ecx, [ebp - 0x50]
00acae9f  51                       push       ecx
00acaea0  c745b0a4b9ca00           mov        dword ptr [ebp - 0x50], 0xcab9a4
00acaea7  e8c3561300               call       0xc0056f
00acaeac  8b5514                   mov        edx, dword ptr [ebp + 0x14]
00acaeaf  8b4704                   mov        eax, dword ptr [edi + 4]
00acaeb2  8b7510                   mov        esi, dword ptr [ebp + 0x10]
00acaeb5  6a00                     push       0
00acaeb7  52                       push       edx
00acaeb8  50                       push       eax
00acaeb9  56                       push       esi
00acaeba  50                       push       eax
00acaebb  8bcf                     mov        ecx, edi
00acaebd  e87efbffff               call       0xacaa40
00acaec2  8b5f08                   mov        ebx, dword ptr [edi + 8]
00acaec5  8bc8                     mov        ecx, eax
00acaec7  8b4704                   mov        eax, dword ptr [edi + 4]
00acaeca  43                       inc        ebx
00acaecb  3bf0                     cmp        esi, eax
00acaecd  894d14                   mov        dword ptr [ebp + 0x14], ecx
00acaed0  895f08                   mov        dword ptr [edi + 8], ebx
00acaed3  7510                     jne        0xacaee5
00acaed5  894804                   mov        dword ptr [eax + 4], ecx
00acaed8  8b4704                   mov        eax, dword ptr [edi + 4]
00acaedb  8908                     mov        dword ptr [eax], ecx
00acaedd  8b5704                   mov        edx, dword ptr [edi + 4]
00acaee0  894a08                   mov        dword ptr [edx + 8], ecx
00acaee3  eb22                     jmp        0xacaf07
00acaee5  8a450c                   mov        al, byte ptr [ebp + 0xc]
00acaee8  84c0                     test       al, al
00acaeea  740d                     je         0xacaef9
00acaeec  890e                     mov        dword ptr [esi], ecx
00acaeee  8b4704                   mov        eax, dword ptr [edi + 4]
00acaef1  3b30                     cmp        esi, dword ptr [eax]
00acaef3  7512                     jne        0xacaf07
00acaef5  8908                     mov        dword ptr [eax], ecx
00acaef7  eb0e                     jmp        0xacaf07
00acaef9  894e08                   mov        dword ptr [esi + 8], ecx
00acaefc  8b4704                   mov        eax, dword ptr [edi + 4]
00acaeff  3b7008                   cmp        esi, dword ptr [eax + 8]
00acaf02  7503                     jne        0xacaf07
00acaf04  894808                   mov        dword ptr [eax + 8], ecx
00acaf07  8b5104                   mov        edx, dword ptr [ecx + 4]
00acaf0a  8a5a4c                   mov        bl, byte ptr [edx + 0x4c]
00acaf0d  84db                     test       bl, bl
00acaf0f  8d4104                   lea        eax, [ecx + 4]
00acaf12  8bf1                     mov        esi, ecx
00acaf14  0f85ad000000             jne        0xacafc7
00acaf1a  8d9b00000000             lea        ebx, [ebx]
00acaf20  8b08                     mov        ecx, dword ptr [eax]
00acaf22  8b5904                   mov        ebx, dword ptr [ecx + 4]
00acaf25  8b13                     mov        edx, dword ptr [ebx]
00acaf27  3bca                     cmp        ecx, edx
00acaf29  7554                     jne        0xacaf7f
00acaf2b  8b5308                   mov        edx, dword ptr [ebx + 8]
00acaf2e  8a5a4c                   mov        bl, byte ptr [edx + 0x4c]
00acaf31  84db                     test       bl, bl
00acaf33  751a                     jne        0xacaf4f
00acaf35  8b08                     mov        ecx, dword ptr [eax]
00acaf37  c6414c01                 mov        byte ptr [ecx + 0x4c], 1
00acaf3b  c6424c01                 mov        byte ptr [edx + 0x4c], 1
00acaf3f  8b10                     mov        edx, dword ptr [eax]
00acaf41  8b4a04                   mov        ecx, dword ptr [edx + 4]
00acaf44  c6414c00                 mov        byte ptr [ecx + 0x4c], 0
00acaf48  8b10                     mov        edx, dword ptr [eax]
00acaf4a  8b7204                   mov        esi, dword ptr [edx + 4]
00acaf4d  eb64                     jmp        0xacafb3
00acaf4f  3b7108                   cmp        esi, dword ptr [ecx + 8]
00acaf52  750a                     jne        0xacaf5e
00acaf54  8bf1                     mov        esi, ecx
00acaf56  56                       push       esi
00acaf57  8bcf                     mov        ecx, edi
00acaf59  e8c2f5ffff               call       0xaca520
00acaf5e  8b4604                   mov        eax, dword ptr [esi + 4]
00acaf61  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00acaf65  8b4e04                   mov        ecx, dword ptr [esi + 4]
00acaf68  8b5104                   mov        edx, dword ptr [ecx + 4]
00acaf6b  c6424c00                 mov        byte ptr [edx + 0x4c], 0
00acaf6f  8b4604                   mov        eax, dword ptr [esi + 4]
00acaf72  8b4804                   mov        ecx, dword ptr [eax + 4]
00acaf75  51                       push       ecx
00acaf76  8bcf                     mov        ecx, edi
00acaf78  e803f6ffff               call       0xaca580
00acaf7d  eb34                     jmp        0xacafb3
00acaf7f  8a5a4c                   mov        bl, byte ptr [edx + 0x4c]
00acaf82  84db                     test       bl, bl
00acaf84  74af                     je         0xacaf35
00acaf86  3b31                     cmp        esi, dword ptr [ecx]
00acaf88  750a                     jne        0xacaf94
00acaf8a  8bf1                     mov        esi, ecx
00acaf8c  56                       push       esi
00acaf8d  8bcf                     mov        ecx, edi
00acaf8f  e8ecf5ffff               call       0xaca580
00acaf94  8b4604                   mov        eax, dword ptr [esi + 4]
00acaf97  c6404c01                 mov        byte ptr [eax + 0x4c], 1
00acaf9b  8b4e04                   mov        ecx, dword ptr [esi + 4]
00acaf9e  8b5104                   mov        edx, dword ptr [ecx + 4]
00acafa1  c6424c00                 mov        byte ptr [edx + 0x4c], 0
00acafa5  8b4604                   mov        eax, dword ptr [esi + 4]
00acafa8  8b4804                   mov        ecx, dword ptr [eax + 4]
00acafab  51                       push       ecx
00acafac  8bcf                     mov        ecx, edi
00acafae  e86df5ffff               call       0xaca520
00acafb3  8b5604                   mov        edx, dword ptr [esi + 4]
00acafb6  8a4a4c                   mov        cl, byte ptr [edx + 0x4c]
00acafb9  84c9                     test       cl, cl
00acafbb  8d4604                   lea        eax, [esi + 4]
00acafbe  0f845cffffff             je         0xacaf20
00acafc4  8b4d14                   mov        ecx, dword ptr [ebp + 0x14]
00acafc7  8b4704                   mov        eax, dword ptr [edi + 4]
00acafca  8b5004                   mov        edx, dword ptr [eax + 4]
00acafcd  8b4508                   mov        eax, dword ptr [ebp + 8]
00acafd0  c6424c01                 mov        byte ptr [edx + 0x4c], 1
00acafd4  5f                       pop        edi
00acafd5  8908                     mov        dword ptr [eax], ecx
00acafd7  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acafda  5e                       pop        esi
00acafdb  5b                       pop        ebx
00acafdc  64890d00000000           mov        dword ptr fs:[0], ecx
00acafe3  8be5                     mov        esp, ebp
00acafe5  5d                       pop        ebp
00acafe6  c21000                   ret        0x10
00acafe9  cc                       int3       
00acafea  cc                       int3       
00acafeb  cc                       int3       
00acafec  cc                       int3       
00acafed  cc                       int3       
00acafee  cc                       int3       
00acafef  cc                       int3       
00acaff0  55                       push       ebp
00acaff1  8bec                     mov        ebp, esp
00acaff3  6aff                     push       -1
00acaff5  68c034c900               push       0xc934c0
00acaffa  64a100000000             mov        eax, dword ptr fs:[0]
00acb000  50                       push       eax
00acb001  64892500000000           mov        dword ptr fs:[0], esp
00acb008  83ec0c                   sub        esp, 0xc
00acb00b  53                       push       ebx
00acb00c  8b5d08                   mov        ebx, dword ptr [ebp + 8]
00acb00f  56                       push       esi
00acb010  8bf1                     mov        esi, ecx
00acb012  8b4604                   mov        eax, dword ptr [esi + 4]
00acb015  8945ec                   mov        dword ptr [ebp - 0x14], eax
00acb018  8a434d                   mov        al, byte ptr [ebx + 0x4d]
00acb01b  84c0                     test       al, al
00acb01d  57                       push       edi
00acb01e  8965f0                   mov        dword ptr [ebp - 0x10], esp
00acb021  8975e8                   mov        dword ptr [ebp - 0x18], esi
00acb024  754c                     jne        0xacb072
00acb026  8b4604                   mov        eax, dword ptr [esi + 4]
00acb029  33c9                     xor        ecx, ecx
00acb02b  8a4b4c                   mov        cl, byte ptr [ebx + 0x4c]
00acb02e  8d530c                   lea        edx, [ebx + 0xc]
00acb031  51                       push       ecx
00acb032  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00acb035  52                       push       edx
00acb036  50                       push       eax
00acb037  51                       push       ecx
00acb038  50                       push       eax
00acb039  8bce                     mov        ecx, esi
00acb03b  e800faffff               call       0xacaa40
00acb040  8b55ec                   mov        edx, dword ptr [ebp - 0x14]
00acb043  8bf8                     mov        edi, eax
00acb045  8a424d                   mov        al, byte ptr [edx + 0x4d]
00acb048  84c0                     test       al, al
00acb04a  7403                     je         0xacb04f
00acb04c  897dec                   mov        dword ptr [ebp - 0x14], edi
00acb04f  8b03                     mov        eax, dword ptr [ebx]
00acb051  57                       push       edi
00acb052  50                       push       eax
00acb053  8bce                     mov        ecx, esi
00acb055  c745fc00000000           mov        dword ptr [ebp - 4], 0
00acb05c  e88fffffff               call       0xacaff0
00acb061  8907                     mov        dword ptr [edi], eax
00acb063  8b4b08                   mov        ecx, dword ptr [ebx + 8]
00acb066  57                       push       edi
00acb067  51                       push       ecx
00acb068  8bce                     mov        ecx, esi
00acb06a  e881ffffff               call       0xacaff0
00acb06f  894708                   mov        dword ptr [edi + 8], eax
00acb072  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb075  8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00acb078  5f                       pop        edi
00acb079  5e                       pop        esi
00acb07a  64890d00000000           mov        dword ptr fs:[0], ecx
00acb081  5b                       pop        ebx
00acb082  8be5                     mov        esp, ebp
00acb084  5d                       pop        ebp
00acb085  c20800                   ret        8
00acb088  8b55ec                   mov        edx, dword ptr [ebp - 0x14]
00acb08b  8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00acb08e  52                       push       edx
00acb08f  e85cfdffff               call       0xacadf0
00acb094  6a00                     push       0
00acb096  6a00                     push       0
00acb098  e8d2541300               call       0xc0056f
00acb09d  cc                       int3       
00acb09e  cc                       int3       
00acb09f  cc                       int3       
00acb0a0  55                       push       ebp
00acb0a1  8bec                     mov        ebp, esp
00acb0a3  83ec14                   sub        esp, 0x14
00acb0a6  8b4104                   mov        eax, dword ptr [ecx + 4]
00acb0a9  53                       push       ebx
00acb0aa  8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00acb0ad  56                       push       esi
00acb0ae  57                       push       edi
00acb0af  8b7804                   mov        edi, dword ptr [eax + 4]
00acb0b2  8a574d                   mov        dl, byte ptr [edi + 0x4d]
00acb0b5  84d2                     test       dl, dl
00acb0b7  8bf0                     mov        esi, eax
00acb0b9  b001                     mov        al, 1
00acb0bb  894df4                   mov        dword ptr [ebp - 0xc], ecx
00acb0be  8975fc                   mov        dword ptr [ebp - 4], esi
00acb0c1  8845f8                   mov        byte ptr [ebp - 8], al
00acb0c4  0f85b6000000             jne        0xacb180
00acb0ca  8b4314                   mov        eax, dword ptr [ebx + 0x14]
00acb0cd  8bc8                     mov        ecx, eax
00acb0cf  8945ec                   mov        dword ptr [ebp - 0x14], eax
00acb0d2  894df0                   mov        dword ptr [ebp - 0x10], ecx
00acb0d5  eb09                     jmp        0xacb0e0
00acb0d7  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00acb0da  8d9b00000000             lea        ebx, [ebx]
00acb0e0  837f2408                 cmp        dword ptr [edi + 0x24], 8
00acb0e4  8b5720                   mov        edx, dword ptr [edi + 0x20]
00acb0e7  897dfc                   mov        dword ptr [ebp - 4], edi
00acb0ea  7205                     jb         0xacb0f1
00acb0ec  8b4710                   mov        eax, dword ptr [edi + 0x10]
00acb0ef  eb03                     jmp        0xacb0f4
00acb0f1  8d4710                   lea        eax, [edi + 0x10]
00acb0f4  8b75ec                   mov        esi, dword ptr [ebp - 0x14]
00acb0f7  3bce                     cmp        ecx, esi
00acb0f9  7302                     jae        0xacb0fd
00acb0fb  8bf1                     mov        esi, ecx
00acb0fd  85f6                     test       esi, esi
00acb0ff  7433                     je         0xacb134
00acb101  3bf2                     cmp        esi, edx
00acb103  7302                     jae        0xacb107
00acb105  8bd6                     mov        edx, esi
00acb107  837b1808                 cmp        dword ptr [ebx + 0x18], 8
00acb10b  7205                     jb         0xacb112
00acb10d  8b4b04                   mov        ecx, dword ptr [ebx + 4]
00acb110  eb03                     jmp        0xacb115
00acb112  8d4b04                   lea        ecx, [ebx + 4]
00acb115  85d2                     test       edx, edx
00acb117  761b                     jbe        0xacb134
00acb119  8da42400000000           lea        esp, [esp]
00acb120  668b19                   mov        bx, word ptr [ecx]
00acb123  663b18                   cmp        bx, word ptr [eax]
00acb126  7518                     jne        0xacb140
00acb128  83c102                   add        ecx, 2
00acb12b  83c002                   add        eax, 2
00acb12e  4a                       dec        edx
00acb12f  75ef                     jne        0xacb120
00acb131  8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00acb134  8b4720                   mov        eax, dword ptr [edi + 0x20]
00acb137  3bf0                     cmp        esi, eax
00acb139  7318                     jae        0xacb153
00acb13b  83c8ff                   or         eax, 0xffffffff
00acb13e  eb1c                     jmp        0xacb15c
00acb140  668b09                   mov        cx, word ptr [ecx]
00acb143  663b08                   cmp        cx, word ptr [eax]
00acb146  1bc0                     sbb        eax, eax
00acb148  83e0fe                   and        eax, 0xfffffffe
00acb14b  40                       inc        eax
00acb14c  74e3                     je         0xacb131
00acb14e  8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
00acb151  eb09                     jmp        0xacb15c
00acb153  33d2                     xor        edx, edx
00acb155  3bf0                     cmp        esi, eax
00acb157  0f95c2                   setne      dl
00acb15a  8bc2                     mov        eax, edx
00acb15c  85c0                     test       eax, eax
00acb15e  0f9cc0                   setl       al
00acb161  84c0                     test       al, al
00acb163  8845f8                   mov        byte ptr [ebp - 8], al
00acb166  7404                     je         0xacb16c
00acb168  8b3f                     mov        edi, dword ptr [edi]
00acb16a  eb03                     jmp        0xacb16f
00acb16c  8b7f08                   mov        edi, dword ptr [edi + 8]
00acb16f  8a4f4d                   mov        cl, byte ptr [edi + 0x4d]
00acb172  84c9                     test       cl, cl
00acb174  0f845dffffff             je         0xacb0d7
00acb17a  8b75fc                   mov        esi, dword ptr [ebp - 4]
00acb17d  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb180  84c0                     test       al, al
00acb182  89750c                   mov        dword ptr [ebp + 0xc], esi
00acb185  7433                     je         0xacb1ba
00acb187  8b4104                   mov        eax, dword ptr [ecx + 4]
00acb18a  3b30                     cmp        esi, dword ptr [eax]
00acb18c  7521                     jne        0xacb1af
00acb18e  53                       push       ebx
00acb18f  56                       push       esi
00acb190  6a01                     push       1
00acb192  8d550c                   lea        edx, [ebp + 0xc]
00acb195  52                       push       edx
00acb196  e8a5fcffff               call       0xacae40
00acb19b  8b08                     mov        ecx, dword ptr [eax]
00acb19d  8b4508                   mov        eax, dword ptr [ebp + 8]
00acb1a0  5f                       pop        edi
00acb1a1  5e                       pop        esi
00acb1a2  8908                     mov        dword ptr [eax], ecx
00acb1a4  c6400401                 mov        byte ptr [eax + 4], 1
00acb1a8  5b                       pop        ebx
00acb1a9  8be5                     mov        esp, ebp
00acb1ab  5d                       pop        ebp
00acb1ac  c20800                   ret        8
00acb1af  8d4d0c                   lea        ecx, [ebp + 0xc]
00acb1b2  e829f4ffff               call       0xaca5e0
00acb1b7  8b750c                   mov        esi, dword ptr [ebp + 0xc]
00acb1ba  837b1808                 cmp        dword ptr [ebx + 0x18], 8
00acb1be  8b5314                   mov        edx, dword ptr [ebx + 0x14]
00acb1c1  8d4e0c                   lea        ecx, [esi + 0xc]
00acb1c4  7205                     jb         0xacb1cb
00acb1c6  8b4304                   mov        eax, dword ptr [ebx + 4]
00acb1c9  eb03                     jmp        0xacb1ce
00acb1cb  8d4304                   lea        eax, [ebx + 4]
00acb1ce  52                       push       edx
00acb1cf  8b5114                   mov        edx, dword ptr [ecx + 0x14]
00acb1d2  50                       push       eax
00acb1d3  52                       push       edx
00acb1d4  6a00                     push       0
00acb1d6  e8158e93ff               call       0x403ff0
00acb1db  85c0                     test       eax, eax
00acb1dd  7d0e                     jge        0xacb1ed
00acb1df  8b45fc                   mov        eax, dword ptr [ebp - 4]
00acb1e2  8b4df8                   mov        ecx, dword ptr [ebp - 8]
00acb1e5  53                       push       ebx
00acb1e6  50                       push       eax
00acb1e7  51                       push       ecx
00acb1e8  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb1eb  eba5                     jmp        0xacb192
00acb1ed  8b4508                   mov        eax, dword ptr [ebp + 8]
00acb1f0  5f                       pop        edi
00acb1f1  8930                     mov        dword ptr [eax], esi
00acb1f3  5e                       pop        esi
00acb1f4  c6400400                 mov        byte ptr [eax + 4], 0
00acb1f8  5b                       pop        ebx
00acb1f9  8be5                     mov        esp, ebp
00acb1fb  5d                       pop        ebp
00acb1fc  c20800                   ret        8
00acb1ff  cc                       int3       
00acb200  55                       push       ebp
00acb201  8bec                     mov        ebp, esp
00acb203  53                       push       ebx
00acb204  8b5d10                   mov        ebx, dword ptr [ebp + 0x10]
00acb207  56                       push       esi
00acb208  8b750c                   mov        esi, dword ptr [ebp + 0xc]
00acb20b  57                       push       edi
00acb20c  8bf9                     mov        edi, ecx
00acb20e  8b4704                   mov        eax, dword ptr [edi + 4]
00acb211  3b30                     cmp        esi, dword ptr [eax]
00acb213  7538                     jne        0xacb24d
00acb215  3bd8                     cmp        ebx, eax
00acb217  7534                     jne        0xacb24d
00acb219  8b4004                   mov        eax, dword ptr [eax + 4]
00acb21c  50                       push       eax
00acb21d  8bcf                     mov        ecx, edi
00acb21f  e8ccfbffff               call       0xacadf0
00acb224  8b4704                   mov        eax, dword ptr [edi + 4]
00acb227  894004                   mov        dword ptr [eax + 4], eax
00acb22a  8b4704                   mov        eax, dword ptr [edi + 4]
00acb22d  c7470800000000           mov        dword ptr [edi + 8], 0
00acb234  8900                     mov        dword ptr [eax], eax
00acb236  8b4704                   mov        eax, dword ptr [edi + 4]
00acb239  894008                   mov        dword ptr [eax + 8], eax
00acb23c  8b4f04                   mov        ecx, dword ptr [edi + 4]
00acb23f  8b11                     mov        edx, dword ptr [ecx]
00acb241  8b4508                   mov        eax, dword ptr [ebp + 8]
00acb244  5f                       pop        edi
00acb245  5e                       pop        esi
00acb246  8910                     mov        dword ptr [eax], edx
00acb248  5b                       pop        ebx
00acb249  5d                       pop        ebp
00acb24a  c20c00                   ret        0xc
00acb24d  3bf3                     cmp        esi, ebx
00acb24f  7459                     je         0xacb2aa
00acb251  8a464d                   mov        al, byte ptr [esi + 0x4d]
00acb254  84c0                     test       al, al
00acb256  8bce                     mov        ecx, esi
00acb258  7540                     jne        0xacb29a
00acb25a  8b4608                   mov        eax, dword ptr [esi + 8]
00acb25d  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb260  84d2                     test       dl, dl
00acb262  7519                     jne        0xacb27d
00acb264  8bf0                     mov        esi, eax
00acb266  8b06                     mov        eax, dword ptr [esi]
00acb268  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb26b  84d2                     test       dl, dl
00acb26d  752b                     jne        0xacb29a
00acb26f  90                       nop        
00acb270  8bf0                     mov        esi, eax
00acb272  8b06                     mov        eax, dword ptr [esi]
00acb274  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb277  84d2                     test       dl, dl
00acb279  74f5                     je         0xacb270
00acb27b  eb1d                     jmp        0xacb29a
00acb27d  8b4604                   mov        eax, dword ptr [esi + 4]
00acb280  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb283  84d2                     test       dl, dl
00acb285  7511                     jne        0xacb298
00acb287  3b7008                   cmp        esi, dword ptr [eax + 8]
00acb28a  750c                     jne        0xacb298
00acb28c  8bf0                     mov        esi, eax
00acb28e  8b4004                   mov        eax, dword ptr [eax + 4]
00acb291  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb294  84d2                     test       dl, dl
00acb296  74ef                     je         0xacb287
00acb298  8bf0                     mov        esi, eax
00acb29a  51                       push       ecx
00acb29b  8d450c                   lea        eax, [ebp + 0xc]
00acb29e  50                       push       eax
00acb29f  8bcf                     mov        ecx, edi
00acb2a1  e83af8ffff               call       0xacaae0
00acb2a6  3bf3                     cmp        esi, ebx
00acb2a8  75a7                     jne        0xacb251
00acb2aa  8b4508                   mov        eax, dword ptr [ebp + 8]
00acb2ad  5f                       pop        edi
00acb2ae  8930                     mov        dword ptr [eax], esi
00acb2b0  5e                       pop        esi
00acb2b1  5b                       pop        ebx
00acb2b2  5d                       pop        ebp
00acb2b3  c20c00                   ret        0xc
00acb2b6  cc                       int3       
00acb2b7  cc                       int3       
00acb2b8  cc                       int3       
00acb2b9  cc                       int3       
00acb2ba  cc                       int3       
00acb2bb  cc                       int3       
00acb2bc  cc                       int3       
00acb2bd  cc                       int3       
00acb2be  cc                       int3       
00acb2bf  cc                       int3       
00acb2c0  55                       push       ebp
00acb2c1  8bec                     mov        ebp, esp
00acb2c3  53                       push       ebx
00acb2c4  8b5d08                   mov        ebx, dword ptr [ebp + 8]
00acb2c7  8b4304                   mov        eax, dword ptr [ebx + 4]
00acb2ca  56                       push       esi
00acb2cb  8bf1                     mov        esi, ecx
00acb2cd  8b4804                   mov        ecx, dword ptr [eax + 4]
00acb2d0  57                       push       edi
00acb2d1  8b7e04                   mov        edi, dword ptr [esi + 4]
00acb2d4  57                       push       edi
00acb2d5  51                       push       ecx
00acb2d6  8bce                     mov        ecx, esi
00acb2d8  e813fdffff               call       0xacaff0
00acb2dd  894704                   mov        dword ptr [edi + 4], eax
00acb2e0  8b5308                   mov        edx, dword ptr [ebx + 8]
00acb2e3  895608                   mov        dword ptr [esi + 8], edx
00acb2e6  8b5604                   mov        edx, dword ptr [esi + 4]
00acb2e9  8b4204                   mov        eax, dword ptr [edx + 4]
00acb2ec  8a484d                   mov        cl, byte ptr [eax + 0x4d]
00acb2ef  84c9                     test       cl, cl
00acb2f1  7543                     jne        0xacb336
00acb2f3  8b08                     mov        ecx, dword ptr [eax]
00acb2f5  8a594d                   mov        bl, byte ptr [ecx + 0x4d]
00acb2f8  84db                     test       bl, bl
00acb2fa  750f                     jne        0xacb30b
00acb2fc  8d642400                 lea        esp, [esp]
00acb300  8bc1                     mov        eax, ecx
00acb302  8b08                     mov        ecx, dword ptr [eax]
00acb304  8a594d                   mov        bl, byte ptr [ecx + 0x4d]
00acb307  84db                     test       bl, bl
00acb309  74f5                     je         0xacb300
00acb30b  8902                     mov        dword ptr [edx], eax
00acb30d  8b7604                   mov        esi, dword ptr [esi + 4]
00acb310  8b4e04                   mov        ecx, dword ptr [esi + 4]
00acb313  8b4108                   mov        eax, dword ptr [ecx + 8]
00acb316  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb319  84d2                     test       dl, dl
00acb31b  750f                     jne        0xacb32c
00acb31d  8d4900                   lea        ecx, [ecx]
00acb320  8bc8                     mov        ecx, eax
00acb322  8b4108                   mov        eax, dword ptr [ecx + 8]
00acb325  8a504d                   mov        dl, byte ptr [eax + 0x4d]
00acb328  84d2                     test       dl, dl
00acb32a  74f4                     je         0xacb320
00acb32c  5f                       pop        edi
00acb32d  894e08                   mov        dword ptr [esi + 8], ecx
00acb330  5e                       pop        esi
00acb331  5b                       pop        ebx
00acb332  5d                       pop        ebp
00acb333  c20400                   ret        4
00acb336  8912                     mov        dword ptr [edx], edx
00acb338  8b7604                   mov        esi, dword ptr [esi + 4]
00acb33b  5f                       pop        edi
00acb33c  897608                   mov        dword ptr [esi + 8], esi
00acb33f  5e                       pop        esi
00acb340  5b                       pop        ebx
00acb341  5d                       pop        ebp
00acb342  c20400                   ret        4
00acb345  cc                       int3       
00acb346  cc                       int3       
00acb347  cc                       int3       
00acb348  cc                       int3       
00acb349  cc                       int3       
00acb34a  cc                       int3       
00acb34b  cc                       int3       
00acb34c  cc                       int3       
00acb34d  cc                       int3       
00acb34e  cc                       int3       
00acb34f  cc                       int3       
00acb350  55                       push       ebp
00acb351  8bec                     mov        ebp, esp
00acb353  51                       push       ecx
00acb354  56                       push       esi
00acb355  8bf1                     mov        esi, ecx
00acb357  8b4604                   mov        eax, dword ptr [esi + 4]
00acb35a  8b08                     mov        ecx, dword ptr [eax]
00acb35c  50                       push       eax
00acb35d  51                       push       ecx
00acb35e  8d45fc                   lea        eax, [ebp - 4]
00acb361  50                       push       eax
00acb362  8bce                     mov        ecx, esi
00acb364  e897feffff               call       0xacb200
00acb369  8b4e04                   mov        ecx, dword ptr [esi + 4]
00acb36c  51                       push       ecx
00acb36d  e86b4c1300               call       0xbfffdd
00acb372  83c404                   add        esp, 4
00acb375  33c0                     xor        eax, eax
00acb377  894604                   mov        dword ptr [esi + 4], eax
00acb37a  894608                   mov        dword ptr [esi + 8], eax
00acb37d  5e                       pop        esi
00acb37e  8be5                     mov        esp, ebp
00acb380  5d                       pop        ebp
00acb381  c3                       ret        
00acb382  cc                       int3       
00acb383  cc                       int3       
00acb384  cc                       int3       
00acb385  cc                       int3       
00acb386  cc                       int3       
00acb387  cc                       int3       
00acb388  cc                       int3       
00acb389  cc                       int3       
00acb38a  cc                       int3       
00acb38b  cc                       int3       
00acb38c  cc                       int3       
00acb38d  cc                       int3       
00acb38e  cc                       int3       
00acb38f  cc                       int3       
00acb390  55                       push       ebp
00acb391  8bec                     mov        ebp, esp
00acb393  6aff                     push       -1
00acb395  68d034c900               push       0xc934d0
00acb39a  64a100000000             mov        eax, dword ptr fs:[0]
00acb3a0  50                       push       eax
00acb3a1  64892500000000           mov        dword ptr fs:[0], esp
00acb3a8  83ec08                   sub        esp, 8
00acb3ab  53                       push       ebx
00acb3ac  56                       push       esi
00acb3ad  57                       push       edi
00acb3ae  8bf1                     mov        esi, ecx
00acb3b0  8965f0                   mov        dword ptr [ebp - 0x10], esp
00acb3b3  8975ec                   mov        dword ptr [ebp - 0x14], esi
00acb3b6  e8e5f2ffff               call       0xaca6a0
00acb3bb  894604                   mov        dword ptr [esi + 4], eax
00acb3be  c6404d01                 mov        byte ptr [eax + 0x4d], 1
00acb3c2  8b4604                   mov        eax, dword ptr [esi + 4]
00acb3c5  894004                   mov        dword ptr [eax + 4], eax
00acb3c8  8b4604                   mov        eax, dword ptr [esi + 4]
00acb3cb  8900                     mov        dword ptr [eax], eax
00acb3cd  8b4604                   mov        eax, dword ptr [esi + 4]
00acb3d0  894008                   mov        dword ptr [eax + 8], eax
00acb3d3  8b4508                   mov        eax, dword ptr [ebp + 8]
00acb3d6  50                       push       eax
00acb3d7  8bce                     mov        ecx, esi
00acb3d9  c7460800000000           mov        dword ptr [esi + 8], 0
00acb3e0  c745fc00000000           mov        dword ptr [ebp - 4], 0
00acb3e7  e8d4feffff               call       0xacb2c0
00acb3ec  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb3ef  5f                       pop        edi
00acb3f0  8bc6                     mov        eax, esi
00acb3f2  5e                       pop        esi
00acb3f3  64890d00000000           mov        dword ptr fs:[0], ecx
00acb3fa  5b                       pop        ebx
00acb3fb  8be5                     mov        esp, ebp
00acb3fd  5d                       pop        ebp
00acb3fe  c20400                   ret        4
00acb401  8b4dec                   mov        ecx, dword ptr [ebp - 0x14]
00acb404  e847ffffff               call       0xacb350
00acb409  6a00                     push       0
00acb40b  6a00                     push       0
00acb40d  e85d511300               call       0xc0056f
00acb412  cc                       int3       
00acb413  cc                       int3       
00acb414  cc                       int3       
00acb415  cc                       int3       
00acb416  cc                       int3       
00acb417  cc                       int3       
00acb418  cc                       int3       
00acb419  cc                       int3       
00acb41a  cc                       int3       
00acb41b  cc                       int3       
00acb41c  cc                       int3       
00acb41d  cc                       int3       
00acb41e  cc                       int3       
00acb41f  cc                       int3       
00acb420  55                       push       ebp
00acb421  8bec                     mov        ebp, esp
00acb423  6aff                     push       -1
00acb425  68eb34c900               push       0xc934eb
00acb42a  64a100000000             mov        eax, dword ptr fs:[0]
00acb430  50                       push       eax
00acb431  64892500000000           mov        dword ptr fs:[0], esp
00acb438  83ec08                   sub        esp, 8
00acb43b  53                       push       ebx
00acb43c  56                       push       esi
00acb43d  57                       push       edi
00acb43e  8bf9                     mov        edi, ecx
00acb440  897df0                   mov        dword ptr [ebp - 0x10], edi
00acb443  8b4724                   mov        eax, dword ptr [edi + 0x24]
00acb446  8b08                     mov        ecx, dword ptr [eax]
00acb448  8d7720                   lea        esi, [edi + 0x20]
00acb44b  50                       push       eax
00acb44c  51                       push       ecx
00acb44d  8d45ec                   lea        eax, [ebp - 0x14]
00acb450  33db                     xor        ebx, ebx
00acb452  50                       push       eax
00acb453  8bce                     mov        ecx, esi
00acb455  895dfc                   mov        dword ptr [ebp - 4], ebx
00acb458  e8a3fdffff               call       0xacb200
00acb45d  8b4e04                   mov        ecx, dword ptr [esi + 4]
00acb460  51                       push       ecx
00acb461  e8774b1300               call       0xbfffdd
00acb466  895e04                   mov        dword ptr [esi + 4], ebx
00acb469  895e08                   mov        dword ptr [esi + 8], ebx
00acb46c  8b471c                   mov        eax, dword ptr [edi + 0x1c]
00acb46f  83c404                   add        esp, 4
00acb472  83f808                   cmp        eax, 8
00acb475  720c                     jb         0xacb483
00acb477  8b5708                   mov        edx, dword ptr [edi + 8]
00acb47a  52                       push       edx
00acb47b  e85d4b1300               call       0xbfffdd
00acb480  83c404                   add        esp, 4
00acb483  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb486  895f18                   mov        dword ptr [edi + 0x18], ebx
00acb489  c7471c07000000           mov        dword ptr [edi + 0x1c], 7
00acb490  66895f08                 mov        word ptr [edi + 8], bx
00acb494  5f                       pop        edi
00acb495  5e                       pop        esi
00acb496  5b                       pop        ebx
00acb497  64890d00000000           mov        dword ptr fs:[0], ecx
00acb49e  8be5                     mov        esp, ebp
00acb4a0  5d                       pop        ebp
00acb4a1  c3                       ret        
00acb4a2  cc                       int3       
00acb4a3  cc                       int3       
00acb4a4  cc                       int3       
00acb4a5  cc                       int3       
00acb4a6  cc                       int3       
00acb4a7  cc                       int3       
00acb4a8  cc                       int3       
00acb4a9  cc                       int3       
00acb4aa  cc                       int3       
00acb4ab  cc                       int3       
00acb4ac  cc                       int3       
00acb4ad  cc                       int3       
00acb4ae  cc                       int3       
00acb4af  cc                       int3       
00acb4b0  55                       push       ebp
00acb4b1  8bec                     mov        ebp, esp
00acb4b3  6aff                     push       -1
00acb4b5  68eb34c900               push       0xc934eb
00acb4ba  64a100000000             mov        eax, dword ptr fs:[0]
00acb4c0  50                       push       eax
00acb4c1  64892500000000           mov        dword ptr fs:[0], esp
00acb4c8  51                       push       ecx
00acb4c9  56                       push       esi
00acb4ca  57                       push       edi
00acb4cb  8b7d08                   mov        edi, dword ptr [ebp + 8]
00acb4ce  8b07                     mov        eax, dword ptr [edi]
00acb4d0  8bf1                     mov        esi, ecx
00acb4d2  6aff                     push       -1
00acb4d4  8d4e04                   lea        ecx, [esi + 4]
00acb4d7  8906                     mov        dword ptr [esi], eax
00acb4d9  6a00                     push       0
00acb4db  8d5704                   lea        edx, [edi + 4]
00acb4de  c7411807000000           mov        dword ptr [ecx + 0x18], 7
00acb4e5  c7411400000000           mov        dword ptr [ecx + 0x14], 0
00acb4ec  52                       push       edx
00acb4ed  8975f0                   mov        dword ptr [ebp - 0x10], esi
00acb4f0  66c741040000             mov        word ptr [ecx + 4], 0
00acb4f6  e8657893ff               call       0x402d60
00acb4fb  83c720                   add        edi, 0x20
00acb4fe  57                       push       edi
00acb4ff  8d4e20                   lea        ecx, [esi + 0x20]
00acb502  c745fc00000000           mov        dword ptr [ebp - 4], 0
00acb509  e882feffff               call       0xacb390
00acb50e  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb511  5f                       pop        edi
00acb512  8bc6                     mov        eax, esi
00acb514  5e                       pop        esi
00acb515  64890d00000000           mov        dword ptr fs:[0], ecx
00acb51c  8be5                     mov        esp, ebp
00acb51e  5d                       pop        ebp
00acb51f  c20400                   ret        4
00acb522  cc                       int3       
00acb523  cc                       int3       
00acb524  cc                       int3       
00acb525  cc                       int3       
00acb526  cc                       int3       
00acb527  cc                       int3       
00acb528  cc                       int3       
00acb529  cc                       int3       
00acb52a  cc                       int3       
00acb52b  cc                       int3       
00acb52c  cc                       int3       
00acb52d  cc                       int3       
00acb52e  cc                       int3       
00acb52f  cc                       int3       
00acb530  83c108                   add        ecx, 8
00acb533  e9e8feffff               jmp        0xacb420
00acb538  cc                       int3       
00acb539  cc                       int3       
00acb53a  cc                       int3       
00acb53b  cc                       int3       
00acb53c  cc                       int3       
00acb53d  cc                       int3       
00acb53e  cc                       int3       
00acb53f  cc                       int3       
00acb540  55                       push       ebp
00acb541  8bec                     mov        ebp, esp
00acb543  6aff                     push       -1
00acb545  681135c900               push       0xc93511
00acb54a  64a100000000             mov        eax, dword ptr fs:[0]
00acb550  50                       push       eax
00acb551  64892500000000           mov        dword ptr fs:[0], esp
00acb558  83ec0c                   sub        esp, 0xc
00acb55b  53                       push       ebx
00acb55c  56                       push       esi
00acb55d  57                       push       edi
00acb55e  8965f0                   mov        dword ptr [ebp - 0x10], esp
00acb561  6a34                     push       0x34
00acb563  e8b5231200               call       0xbed91d
00acb568  8bf0                     mov        esi, eax
00acb56a  83c404                   add        esp, 4
00acb56d  8975ec                   mov        dword ptr [ebp - 0x14], esi
00acb570  c745fc00000000           mov        dword ptr [ebp - 4], 0
00acb577  8975e8                   mov        dword ptr [ebp - 0x18], esi
00acb57a  85f6                     test       esi, esi
00acb57c  c645fc01                 mov        byte ptr [ebp - 4], 1
00acb580  7417                     je         0xacb599
00acb582  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00acb585  8b5510                   mov        edx, dword ptr [ebp + 0x10]
00acb588  8b4508                   mov        eax, dword ptr [ebp + 8]
00acb58b  894e04                   mov        dword ptr [esi + 4], ecx
00acb58e  52                       push       edx
00acb58f  8d4e08                   lea        ecx, [esi + 8]
00acb592  8906                     mov        dword ptr [esi], eax
00acb594  e817ffffff               call       0xacb4b0
00acb599  8b4df4                   mov        ecx, dword ptr [ebp - 0xc]
00acb59c  5f                       pop        edi
00acb59d  8bc6                     mov        eax, esi
00acb59f  5e                       pop        esi
00acb5a0  64890d00000000           mov        dword ptr fs:[0], ecx
00acb5a7  5b                       pop        ebx
00acb5a8  8be5                     mov        esp, ebp
00acb5aa  5d                       pop        ebp
00acb5ab  c20c00                   ret        0xc
00acb5ae  8b45ec                   mov        eax, dword ptr [ebp - 0x14]
00acb5b1  50                       push       eax
00acb5b2  e8264a1300               call       0xbfffdd
00acb5b7  83c404                   add        esp, 4
00acb5ba  6a00                     push       0
00acb5bc  6a00                     push       0
00acb5be  e8ac4f1300               call       0xc0056f
00acb5c3  cc                       int3       
00acb5c4  cc                       int3       
00acb5c5  cc                       int3       
00acb5c6  cc                       int3       
00acb5c7  cc                       int3       
00acb5c8  cc                       int3       
00acb5c9  cc                       int3       
00acb5ca  cc                       int3       
00acb5cb  cc                       int3       
00acb5cc  cc                       int3       
00acb5cd  cc                       int3       
00acb5ce  cc                       int3       
00acb5cf  cc                       int3       
00acb5d0  56                       push       esi
00acb5d1  57                       push       edi
00acb5d2  8bf9                     mov        edi, ecx
00acb5d4  8b4704                   mov        eax, dword ptr [edi + 4]
00acb5d7  8b30                     mov        esi, dword ptr [eax]
00acb5d9  8900                     mov        dword ptr [eax], eax
00acb5db  8b4704                   mov        eax, dword ptr [edi + 4]
00acb5de  894004                   mov        dword ptr [eax + 4], eax
00acb5e1  3b7704                   cmp        esi, dword ptr [edi + 4]
00acb5e4  c7470800000000           mov        dword ptr [edi + 8], 0
00acb5eb  741f                     je         0xacb60c
00acb5ed  53                       push       ebx
00acb5ee  8bff                     mov        edi, edi
00acb5f0  8b1e                     mov        ebx, dword ptr [esi]
00acb5f2  8bce                     mov        ecx, esi
00acb5f4  e837ffffff               call       0xacb530
00acb5f9  56                       push       esi
00acb5fa  e8de491300               call       0xbfffdd
00acb5ff  8b4704                   mov        eax, dword ptr [edi + 4]
00acb602  83c404                   add        esp, 4
00acb605  3bd8                     cmp        ebx, eax
00acb607  8bf3                     mov        esi, ebx
00acb609  75e5                     jne        0xacb5f0
00acb60b  5b                       pop        ebx
00acb60c  5f                       pop        edi
00acb60d  5e                       pop        esi
00acb60e  c3                       ret        
00acb60f  cc                       int3       
00acb610  56                       push       esi
00acb611  8bf1                     mov        esi, ecx
00acb613  e8b8ffffff               call       0xacb5d0
00acb618  8b4604                   mov        eax, dword ptr [esi + 4]
00acb61b  50                       push       eax
00acb61c  e8bc491300               call       0xbfffdd
00acb621  83c404                   add        esp, 4
00acb624  c7460400000000           mov        dword ptr [esi + 4], 0
00acb62b  5e                       pop        esi
00acb62c  c3                       ret        
00acb62d  cc                       int3       
00acb62e  cc                       int3       
00acb62f  cc                       int3       
00acb630  8bc1                     mov        eax, ecx
00acb632  c60000                   mov        byte ptr [eax], 0
00acb635  c74004ffffffff           mov        dword ptr [eax + 4], 0xffffffff
00acb63c  c6400800                 mov        byte ptr [eax + 8], 0
00acb640  c3                       ret        
00acb641  cc                       int3       
00acb642  cc                       int3       
00acb643  cc                       int3       
00acb644  cc                       int3       
00acb645  cc                       int3       
00acb646  cc                       int3       
00acb647  cc                       int3       
00acb648  cc                       int3       
00acb649  cc                       int3       
00acb64a  cc                       int3       
00acb64b  cc                       int3       
00acb64c  cc                       int3       
00acb64d  cc                       int3       
00acb64e  cc                       int3       
00acb64f  cc                       int3       
00acb650  8b01                     mov        eax, dword ptr [ecx]
00acb652  85c0                     test       eax, eax
00acb654  7c24                     jl         0xacb67a
00acb656  83f820                   cmp        eax, 0x20
00acb659  7d1f                     jge        0xacb67a
00acb65b  8d0440                   lea        eax, [eax + eax*2]
00acb65e  c1e002                   shl        eax, 2
00acb661  8a88e8af0d01             mov        cl, byte ptr [eax + 0x10dafe8]
00acb667  84c9                     test       cl, cl
00acb669  7509                     jne        0xacb674
00acb66b  83b8ecaf0d01ff           cmp        dword ptr [eax + 0x10dafec], -1
00acb672  7406                     je         0xacb67a
00acb674  b801000000               mov        eax, 1
00acb679  c3                       ret        
00acb67a  33c0                     xor        eax, eax
00acb67c  c3                       ret        
00acb67d  cc                       int3       
00acb67e  cc                       int3       
00acb67f  cc                       int3       
00acb680  8b01                     mov        eax, dword ptr [ecx]
00acb682  8d0440                   lea        eax, [eax + eax*2]
00acb685  c1e002                   shl        eax, 2
00acb688  8b88ecaf0d01             mov        ecx, dword ptr [eax + 0x10dafec]
00acb68e  85c9                     test       ecx, ecx
00acb690  7c1b                     jl         0xacb6ad
00acb692  8a90e8af0d01             mov        dl, byte ptr [eax + 0x10dafe8]
00acb698  84d2                     test       dl, dl
00acb69a  7511                     jne        0xacb6ad
00acb69c  8b0c8d90ab0d01           mov        ecx, dword ptr [ecx*4 + 0x10dab90]
00acb6a3  68d0ab0d01               push       0x10dabd0
00acb6a8  e8a30b0000               call       0xacc250
00acb6ad  c3                       ret        
00acb6ae  cc                       int3       
00acb6af  cc                       int3       
00acb6b0  33c0                     xor        eax, eax
00acb6b2  a390ab0d01               mov        dword ptr [0x10dab90], eax
00acb6b7  a394ab0d01               mov        dword ptr [0x10dab94], eax
00acb6bc  a398ab0d01               mov        dword ptr [0x10dab98], eax
00acb6c1  a39cab0d01               mov        dword ptr [0x10dab9c], eax
00acb6c6  a3a0ab0d01               mov        dword ptr [0x10daba0], eax
00acb6cb  a3a4ab0d01               mov        dword ptr [0x10daba4], eax
00acb6d0  a3a8ab0d01               mov        dword ptr [0x10daba8], eax
00acb6d5  a3acab0d01               mov        dword ptr [0x10dabac], eax
00acb6da  a3b0ab0d01               mov        dword ptr [0x10dabb0], eax
00acb6df  a3b4ab0d01               mov        dword ptr [0x10dabb4], eax
00acb6e4  a3b8ab0d01               mov        dword ptr [0x10dabb8], eax
00acb6e9  a3bcab0d01               mov        dword ptr [0x10dabbc], eax
00acb6ee  a3c0ab0d01               mov        dword ptr [0x10dabc0], eax
00acb6f3  a3c4ab0d01               mov        dword ptr [0x10dabc4], eax
00acb6f8  a3c8ab0d01               mov        dword ptr [0x10dabc8], eax
00acb6fd  c6058419ff0001           mov        byte ptr [0xff1984], 1
00acb704  a3ccab0d01               mov        dword ptr [0x10dabcc], eax
00acb709  e8b2100000               call       0xacc7c0
00acb70e  8b10                     mov        edx, dword ptr [eax]
00acb710  8bc8                     mov        ecx, eax
00acb712  ff22                     jmp        dword ptr [edx]
00acb714  cc                       int3       
00acb715  cc                       int3       
00acb716  cc                       int3       
00acb717  cc                       int3       
00acb718  cc                       int3       
00acb719  cc                       int3       
00acb71a  cc                       int3       
00acb71b  cc                       int3       
00acb71c  cc                       int3       
00acb71d  cc                       int3       
00acb71e  cc                       int3       
00acb71f  cc                       int3       
00acb720  a08419ff00               mov        al, byte ptr [0xff1984]
00acb725  84c0                     test       al, al
00acb727  7412                     je         0xacb73b
00acb729  6870b10d01               push       0x10db170
00acb72e  ff1500f04001             call       dword ptr [0x140f000]
00acb734  c6058419ff0000           mov        byte ptr [0xff1984], 0
00acb73b  b870b10d01               mov        eax, 0x10db170
00acb740  c3                       ret        
00acb741  cc                       int3       
00acb742  cc                       int3       
00acb743  cc                       int3       
00acb744  cc                       int3       
00acb745  cc                       int3       
00acb746  cc                       int3       
00acb747  cc                       int3       
00acb748  cc                       int3       
00acb749  cc                       int3       
00acb74a  cc                       int3       
00acb74b  cc                       int3       
00acb74c  cc                       int3       
00acb74d  cc                       int3       
00acb74e  cc                       int3       
00acb74f  cc                       int3       
00acb750  55                       push       ebp
00acb751  8bec                     mov        ebp, esp
00acb753  81ec00020000             sub        esp, 0x200
00acb759  56                       push       esi
00acb75a  8b7508                   mov        esi, dword ptr [ebp + 8]
00acb75d  8a0e                     mov        cl, byte ptr [esi]
00acb75f  32d2                     xor        dl, dl
00acb761  33c0                     xor        eax, eax
00acb763  84c9                     test       cl, cl
00acb765  57                       push       edi
00acb766  8bfe                     mov        edi, esi
00acb768  7441                     je         0xacb7ab
00acb76a  8d9b00000000             lea        ebx, [ebx]
00acb770  80f90a                   cmp        cl, 0xa
00acb773  751e                     jne        0xacb793
00acb775  80fa0d                   cmp        dl, 0xd
00acb778  7419                     je         0xacb793
00acb77a  3dfd010000               cmp        eax, 0x1fd
00acb77f  7d12                     jge        0xacb793
00acb781  c6840500feffff0d         mov        byte ptr [ebp + eax - 0x200], 0xd
00acb789  40                       inc        eax
00acb78a  888c0500feffff           mov        byte ptr [ebp + eax - 0x200], cl
00acb791  eb0e                     jmp        0xacb7a1
00acb793  3dfe010000               cmp        eax, 0x1fe
00acb798  7d08                     jge        0xacb7a2
00acb79a  888c0500feffff           mov        byte ptr [ebp + eax - 0x200], cl
00acb7a1  40                       inc        eax
00acb7a2  47                       inc        edi
00acb7a3  8ad1                     mov        dl, cl
00acb7a5  8a0f                     mov        cl, byte ptr [edi]
00acb7a7  84c9                     test       cl, cl
00acb7a9  75c5                     jne        0xacb770
00acb7ab  8d8d00feffff             lea        ecx, [ebp - 0x200]
00acb7b1  8bd1                     mov        edx, ecx
00acb7b3  c6840500feffff00         mov        byte ptr [ebp + eax - 0x200], 0
00acb7bb  2bf2                     sub        esi, edx
00acb7bd  8d4900                   lea        ecx, [ecx]
00acb7c0  8a11                     mov        dl, byte ptr [ecx]
00acb7c2  88140e                   mov        byte ptr [esi + ecx], dl
00acb7c5  41                       inc        ecx
00acb7c6  84d2                     test       dl, dl
00acb7c8  75f6                     jne        0xacb7c0
00acb7ca  5f                       pop        edi
00acb7cb  5e                       pop        esi
00acb7cc  8be5                     mov        esp, ebp
00acb7ce  5d                       pop        ebp
00acb7cf  c3                       ret        
00acb7d0  55                       push       ebp
00acb7d1  8bec                     mov        ebp, esp
00acb7d3  83ec08                   sub        esp, 8
00acb7d6  a08c19ff00               mov        al, byte ptr [0xff198c]
00acb7db  84c0                     test       al, al
00acb7dd  56                       push       esi
00acb7de  8b3584f34001             mov        esi, dword ptr [0x140f384]
00acb7e4  7419                     je         0xacb7ff
00acb7e6  6890b10d01               push       0x10db190
00acb7eb  ff1580f34001             call       dword ptr [0x140f380]
00acb7f1  6888b10d01               push       0x10db188
00acb7f6  ffd6                     call       esi
00acb7f8  c6058c19ff0000           mov        byte ptr [0xff198c], 0
00acb7ff  8d45f8                   lea        eax, [ebp - 8]
00acb802  50                       push       eax
00acb803  ffd6                     call       esi
00acb805  8b4df8                   mov        ecx, dword ptr [ebp - 8]
00acb808  8b1588b10d01             mov        edx, dword ptr [0x10db188]
00acb80e  a18cb10d01               mov        eax, dword ptr [0x10db18c]
00acb813  2bca                     sub        ecx, edx
00acb815  8b55fc                   mov        edx, dword ptr [ebp - 4]
00acb818  1bd0                     sbb        edx, eax
00acb81a  894df8                   mov        dword ptr [ebp - 8], ecx
00acb81d  8955fc                   mov        dword ptr [ebp - 4], edx
00acb820  df6df8                   fild       qword ptr [ebp - 8]
00acb823  df2d90b10d01             fild       qword ptr [0x10db190]
00acb829  5e                       pop        esi
00acb82a  def9                     fdivp      st(1)
00acb82c  8be5                     mov        esp, ebp
00acb82e  5d                       pop        ebp
00acb82f  c3                       ret        
00acb830  55                       push       ebp
00acb831  8bec                     mov        ebp, esp
00acb833  8b01                     mov        eax, dword ptr [ecx]
00acb835  8d0440                   lea        eax, [eax + eax*2]
00acb838  8a0c85f0af0d01           mov        cl, byte ptr [eax*4 + 0x10daff0]
00acb83f  84c9                     test       cl, cl
00acb841  56                       push       esi
00acb842  57                       push       edi
00acb843  bed0ab0d01               mov        esi, 0x10dabd0
00acb848  ba00020000               mov        edx, 0x200
00acb84d  742d                     je         0xacb87c
00acb84f  e87cffffff               call       0xacb7d0
00acb854  83ec08                   sub        esp, 8
00acb857  dd1c24                   fstp       qword ptr [esp]
00acb85a  68bc7ce600               push       0xe67cbc
00acb85f  56                       push       esi
00acb860  e8a8561300               call       0xc00f0d
00acb865  56                       push       esi
00acb866  e862451300               call       0xbffdcd
00acb86b  ba00020000               mov        edx, 0x200
00acb870  83c414                   add        esp, 0x14
00acb873  2bd0                     sub        edx, eax
00acb875  8d3445d0ab0d01           lea        esi, [eax*2 + 0x10dabd0]
00acb87c  8d3c12                   lea        edi, [edx + edx]
00acb87f  8bc7                     mov        eax, edi
00acb881  d1e8                     shr        eax, 1
00acb883  3dffffff7f               cmp        eax, 0x7fffffff
00acb888  770f                     ja         0xacb899
00acb88a  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00acb88d  8b5508                   mov        edx, dword ptr [ebp + 8]
00acb890  51                       push       ecx
00acb891  52                       push       edx
00acb892  50                       push       eax
00acb893  56                       push       esi
00acb894  e8575993ff               call       0x4011f0
00acb899  66c74437fe0000           mov        word ptr [edi + esi - 2], 0
00acb8a0  5f                       pop        edi
00acb8a1  5e                       pop        esi
00acb8a2  5d                       pop        ebp
00acb8a3  c20800                   ret        8
00acb8a6  cc                       int3       
00acb8a7  cc                       int3       
00acb8a8  cc                       int3       
00acb8a9  cc                       int3       
00acb8aa  cc                       int3       
00acb8ab  cc                       int3       
00acb8ac  cc                       int3       
00acb8ad  cc                       int3       
00acb8ae  cc                       int3       
00acb8af  cc                       int3       
00acb8b0  55                       push       ebp
00acb8b1  8bec                     mov        ebp, esp
00acb8b3  57                       push       edi
00acb8b4  8b7d08                   mov        edi, dword ptr [ebp + 8]
00acb8b7  85ff                     test       edi, edi
00acb8b9  7c38                     jl         0xacb8f3
00acb8bb  83ff10                   cmp        edi, 0x10
00acb8be  7d33                     jge        0xacb8f3
00acb8c0  56                       push       esi
00acb8c1  8b34bd90ab0d01           mov        esi, dword ptr [edi*4 + 0x10dab90]
00acb8c8  85f6                     test       esi, esi
00acb8ca  7426                     je         0xacb8f2
00acb8cc  8bce                     mov        ecx, esi
00acb8ce  e8bd0e0000               call       0xacc790
00acb8d3  56                       push       esi
00acb8d4  e804471300               call       0xbfffdd
00acb8d9  a1d0af0d01               mov        eax, dword ptr [0x10dafd0]
00acb8de  83c404                   add        esp, 4
00acb8e1  48                       dec        eax
00acb8e2  c704bd90ab0d0100000000   mov        dword ptr [edi*4 + 0x10dab90], 0
00acb8ed  a3d0af0d01               mov        dword ptr [0x10dafd0], eax
00acb8f2  5e                       pop        esi
00acb8f3  5f                       pop        edi
00acb8f4  5d                       pop        ebp
00acb8f5  c3                       ret        
00acb8f6  cc                       int3       
00acb8f7  cc                       int3       
00acb8f8  cc                       int3       
00acb8f9  cc                       int3       
00acb8fa  cc                       int3       
00acb8fb  cc                       int3       
00acb8fc  cc                       int3       
00acb8fd  cc                       int3       
00acb8fe  cc                       int3       
00acb8ff  cc                       int3       
00acb900  68c87de600               push       0xe67dc8
00acb905  e8d6030000               call       0xacbce0
00acb90a  681456cb00               push       0xcb5614
00acb90f  68947de600               push       0xe67d94
00acb914  6800020000               push       0x200
00acb919  68a8b10d01               push       0x10db1a8
00acb91e  e8cd6493ff               call       0x401df0
00acb923  68a8b10d01               push       0x10db1a8
00acb928  e8b3030000               call       0xacbce0
00acb92d  83c418                   add        esp, 0x18
00acb930  6898b10d01               push       0x10db198
00acb935  ff1578f24001             call       dword ptr [0x140f278]
00acb93b  0fb705a4b10d01           movzx      eax, word ptr [0x10db1a4]
00acb942  0fb70da2b10d01           movzx      ecx, word ptr [0x10db1a2]
00acb949  0fb715a0b10d01           movzx      edx, word ptr [0x10db1a0]
00acb950  50                       push       eax
00acb951  0fb70598b10d01           movzx      eax, word ptr [0x10db198]
00acb958  51                       push       ecx
00acb959  0fb70d9eb10d01           movzx      ecx, word ptr [0x10db19e]
00acb960  52                       push       edx
00acb961  0fb7159ab10d01           movzx      edx, word ptr [0x10db19a]
00acb968  50                       push       eax
00acb969  51                       push       ecx
00acb96a  52                       push       edx
00acb96b  68487de600               push       0xe67d48
00acb970  6800020000               push       0x200
00acb975  68a8b10d01               push       0x10db1a8
00acb97a  e8716493ff               call       0x401df0
00acb97f  68a8b10d01               push       0x10db1a8
00acb984  e857030000               call       0xacbce0
00acb989  68c87ce600               push       0xe67cc8
00acb98e  e84d030000               call       0xacbce0
00acb993  83c42c                   add        esp, 0x2c
00acb996  c3                       ret        
00acb997  cc                       int3       
00acb998  cc                       int3       
00acb999  cc                       int3       
00acb99a  cc                       int3       
00acb99b  cc                       int3       
00acb99c  cc                       int3       
00acb99d  cc                       int3       
00acb99e  cc                       int3       
00acb99f  cc                       int3       
00acb9a0  55                       push       ebp
00acb9a1  8bec                     mov        ebp, esp
00acb9a3  81ec84080000             sub        esp, 0x884
00acb9a9  a1d8af0d01               mov        eax, dword ptr [0x10dafd8]
00acb9ae  85c0                     test       eax, eax
00acb9b0  0f840b030000             je         0xacbcc1
00acb9b6  8b15dcaf0d01             mov        edx, dword ptr [0x10dafdc]
00acb9bc  85d2                     test       edx, edx
00acb9be  0f84fd020000             je         0xacbcc1
00acb9c4  33c0                     xor        eax, eax
00acb9c6  89857cffffff             mov        dword ptr [ebp - 0x84], eax
00acb9cc  894580                   mov        dword ptr [ebp - 0x80], eax
00acb9cf  894584                   mov        dword ptr [ebp - 0x7c], eax
00acb9d2  894588                   mov        dword ptr [ebp - 0x78], eax
00acb9d5  89458c                   mov        dword ptr [ebp - 0x74], eax
00acb9d8  894590                   mov        dword ptr [ebp - 0x70], eax
00acb9db  894594                   mov        dword ptr [ebp - 0x6c], eax
00acb9de  894598                   mov        dword ptr [ebp - 0x68], eax
00acb9e1  89459c                   mov        dword ptr [ebp - 0x64], eax
00acb9e4  8945a0                   mov        dword ptr [ebp - 0x60], eax
00acb9e7  8945a4                   mov        dword ptr [ebp - 0x5c], eax
00acb9ea  8945a8                   mov        dword ptr [ebp - 0x58], eax
00acb9ed  8945ac                   mov        dword ptr [ebp - 0x54], eax
00acb9f0  8945b0                   mov        dword ptr [ebp - 0x50], eax
00acb9f3  8945b4                   mov        dword ptr [ebp - 0x4c], eax
00acb9f6  8945b8                   mov        dword ptr [ebp - 0x48], eax
00acb9f9  8945bc                   mov        dword ptr [ebp - 0x44], eax
00acb9fc  8945c0                   mov        dword ptr [ebp - 0x40], eax
00acb9ff  89                       .byte      0x89