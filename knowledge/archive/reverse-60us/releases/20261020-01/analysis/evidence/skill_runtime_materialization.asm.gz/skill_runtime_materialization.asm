; Source SHA256: a3177551b8f7373e042865b0e99022e24e6ffd47298299a50dc97fec5254745b
; VA 00551ad0..005535e0 (end exclusive); file offset 00151ad0
; This is an instruction excerpt, not a recovered original source file.
00551ad0  55                       push       ebp
00551ad1  8bec                     mov        ebp, esp
00551ad3  6aff                     push       -1
00551ad5  687cd2c500               push       0xc5d27c
00551ada  64a100000000             mov        eax, dword ptr fs:[0]
00551ae0  50                       push       eax
00551ae1  64892500000000           mov        dword ptr fs:[0], esp
00551ae8  81ec64030000             sub        esp, 0x364
00551aee  53                       push       ebx
00551aef  56                       push       esi
00551af0  8bd9                     mov        ebx, ecx
00551af2  57                       push       edi
00551af3  8d8d90fcffff             lea        ecx, [ebp - 0x370]
00551af9  895df0                   mov        dword ptr [ebp - 0x10], ebx
00551afc  e86f460000               call       0x556170
00551b01  83bbd403000006           cmp        dword ptr [ebx + 0x3d4], 6
00551b08  8d7308                   lea        esi, [ebx + 8]
00551b0b  8bce                     mov        ecx, esi
00551b0d  c745fc00000000           mov        dword ptr [ebp - 4], 0
00551b14  0f9445ef                 sete       byte ptr [ebp - 0x11]
00551b18  e82341f9ff               call       0x4e5c40
00551b1d  8b7d08                   mov        edi, dword ptr [ebp + 8]
00551b20  57                       push       edi
00551b21  e8a7e26a00               call       0xbffdcd
00551b26  83c404                   add        esp, 4
00551b29  50                       push       eax
00551b2a  57                       push       edi
00551b2b  8d8bb8030000             lea        ecx, [ebx + 0x3b8]
00551b31  e84a13ebff               call       0x402e80
00551b36  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00551b39  8983d4030000             mov        dword ptr [ebx + 0x3d4], eax
00551b3f  8b4510                   mov        eax, dword ptr [ebp + 0x10]
00551b42  83f80c                   cmp        eax, 0xc
00551b45  751b                     jne        0x551b62
00551b47  a148280001               mov        eax, dword ptr [0x1002848]
00551b4c  85c0                     test       eax, eax
00551b4e  740d                     je         0x551b5d
00551b50  8d8840100000             lea        ecx, [eax + 0x1040]
00551b56  e80505ebff               call       0x402060
00551b5b  eb05                     jmp        0x551b62
00551b5d  b803000000               mov        eax, 3
00551b62  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00551b65  50                       push       eax
00551b66  51                       push       ecx
00551b67  8d9590fcffff             lea        edx, [ebp - 0x370]
00551b6d  57                       push       edi
00551b6e  52                       push       edx
00551b6f  e82cf23400               call       0x8a0da0
00551b74  83c410                   add        esp, 0x10
00551b77  84c0                     test       al, al
00551b79  7514                     jne        0x551b8f
00551b7b  57                       push       edi
00551b7c  68d8cdcd00               push       0xcdcdd8
00551b81  ff15bc2eff00             call       dword ptr [0xff2ebc]
00551b87  83c408                   add        esp, 8
00551b8a  e93e1a0000               jmp        0x5535cd
00551b8f  8d8590fcffff             lea        eax, [ebp - 0x370]
00551b95  50                       push       eax
00551b96  8bce                     mov        ecx, esi
00551b98  e8132aebff               call       0x4045b0
00551b9d  8d9598fcffff             lea        edx, [ebp - 0x368]
00551ba3  8d4b10                   lea        ecx, [ebx + 0x10]
00551ba6  52                       push       edx
00551ba7  e8e4185000               call       0xa53490
00551bac  8d859cfcffff             lea        eax, [ebp - 0x364]
00551bb2  8d4b14                   lea        ecx, [ebx + 0x14]
00551bb5  50                       push       eax
00551bb6  e8d5185000               call       0xa53490
00551bbb  8d95a0fcffff             lea        edx, [ebp - 0x360]
00551bc1  8d4b18                   lea        ecx, [ebx + 0x18]
00551bc4  52                       push       edx
00551bc5  e8c6185000               call       0xa53490
00551bca  8d85a4fcffff             lea        eax, [ebp - 0x35c]
00551bd0  8d4b1c                   lea        ecx, [ebx + 0x1c]
00551bd3  50                       push       eax
00551bd4  e8b7185000               call       0xa53490
00551bd9  8d95a8fcffff             lea        edx, [ebp - 0x358]
00551bdf  8d4b20                   lea        ecx, [ebx + 0x20]
00551be2  52                       push       edx
00551be3  e8c829ebff               call       0x4045b0
00551be8  8b85b4fcffff             mov        eax, dword ptr [ebp - 0x34c]
00551bee  85c0                     test       eax, eax
00551bf0  0f84b3000000             je         0x551ca9
00551bf6  8bb5b8fcffff             mov        esi, dword ptr [ebp - 0x348]
00551bfc  2bf0                     sub        esi, eax
00551bfe  c1fe03                   sar        esi, 3
00551c01  85f6                     test       esi, esi
00551c03  0f84a0000000             je         0x551ca9
00551c09  83ec08                   sub        esp, 8
00551c0c  8bcc                     mov        ecx, esp
00551c0e  89650c                   mov        dword ptr [ebp + 0xc], esp
00551c11  e8ca28ebff               call       0x4044e0
00551c16  8d4b28                   lea        ecx, [ebx + 0x28]
00551c19  56                       push       esi
00551c1a  e8f1230000               call       0x554010
00551c1f  33ff                     xor        edi, edi
00551c21  8bb5b4fcffff             mov        esi, dword ptr [ebp - 0x34c]
00551c27  85f6                     test       esi, esi
00551c29  897d0c                   mov        dword ptr [ebp + 0xc], edi
00551c2c  747b                     je         0x551ca9
00551c2e  8b85b8fcffff             mov        eax, dword ptr [ebp - 0x348]
00551c34  2bc6                     sub        eax, esi
00551c36  c1f803                   sar        eax, 3
00551c39  3bc7                     cmp        eax, edi
00551c3b  766c                     jbe        0x551ca9
00551c3d  8b4b2c                   mov        ecx, dword ptr [ebx + 0x2c]
00551c40  85c9                     test       ecx, ecx
00551c42  8d5328                   lea        edx, [ebx + 0x28]
00551c45  8d34fe                   lea        esi, [esi + edi*8]
00551c48  0f8427050000             je         0x552175
00551c4e  8b4208                   mov        eax, dword ptr [edx + 8]
00551c51  2bc1                     sub        eax, ecx
00551c53  c1f803                   sar        eax, 3
00551c56  3bc7                     cmp        eax, edi
00551c58  0f8617050000             jbe        0x552175
00551c5e  8d14f9                   lea        edx, [ecx + edi*8]
00551c61  3bd6                     cmp        edx, esi
00551c63  743e                     je         0x551ca3
00551c65  8b7a04                   mov        edi, dword ptr [edx + 4]
00551c68  a1d8012101               mov        eax, dword ptr [0x12101d8]
00551c6d  8b4044                   mov        eax, dword ptr [eax + 0x44]
00551c70  8b4e04                   mov        ecx, dword ptr [esi + 4]
00551c73  8d0c88                   lea        ecx, [eax + ecx*4]
00551c76  8d04b8                   lea        eax, [eax + edi*4]
00551c79  8bf8                     mov        edi, eax
00551c7b  33f9                     xor        edi, ecx
00551c7d  3339                     xor        edi, dword ptr [ecx]
00551c7f  8938                     mov        dword ptr [eax], edi
00551c81  a1d8012101               mov        eax, dword ptr [0x12101d8]
00551c86  8b5204                   mov        edx, dword ptr [edx + 4]
00551c89  8b4048                   mov        eax, dword ptr [eax + 0x48]
00551c8c  8b4e04                   mov        ecx, dword ptr [esi + 4]
00551c8f  8b3488                   mov        esi, dword ptr [eax + ecx*4]
00551c92  8b7d0c                   mov        edi, dword ptr [ebp + 0xc]
00551c95  8d0c88                   lea        ecx, [eax + ecx*4]
00551c98  8d0490                   lea        eax, [eax + edx*4]
00551c9b  8bd0                     mov        edx, eax
00551c9d  33d1                     xor        edx, ecx
00551c9f  33d6                     xor        edx, esi
00551ca1  8910                     mov        dword ptr [eax], edx
00551ca3  47                       inc        edi
00551ca4  e978ffffff               jmp        0x551c21
00551ca9  8d7338                   lea        esi, [ebx + 0x38]
00551cac  8d85c0fcffff             lea        eax, [ebp - 0x340]
00551cb2  3bf0                     cmp        esi, eax
00551cb4  7462                     je         0x551d18
00551cb6  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00551cbc  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00551cbf  8b95c4fcffff             mov        edx, dword ptr [ebp - 0x33c]
00551cc5  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551cc8  8d0491                   lea        eax, [ecx + edx*4]
00551ccb  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00551cd1  33c7                     xor        eax, edi
00551cd3  33c2                     xor        eax, edx
00551cd5  8b5604                   mov        edx, dword ptr [esi + 4]
00551cd8  c1e202                   shl        edx, 2
00551cdb  8d3c0a                   lea        edi, [edx + ecx]
00551cde  33f8                     xor        edi, eax
00551ce0  333ddc012101             xor        edi, dword ptr [0x12101dc]
00551ce6  893c0a                   mov        dword ptr [edx + ecx], edi
00551ce9  8b15d8012101             mov        edx, dword ptr [0x12101d8]
00551cef  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
00551cf2  8b95c4fcffff             mov        edx, dword ptr [ebp - 0x33c]
00551cf8  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551cfb  8d0491                   lea        eax, [ecx + edx*4]
00551cfe  8b5604                   mov        edx, dword ptr [esi + 4]
00551d01  33c7                     xor        eax, edi
00551d03  8b3ddc012101             mov        edi, dword ptr [0x12101dc]
00551d09  c1e202                   shl        edx, 2
00551d0c  33c7                     xor        eax, edi
00551d0e  8d340a                   lea        esi, [edx + ecx]
00551d11  33f0                     xor        esi, eax
00551d13  33f7                     xor        esi, edi
00551d15  89340a                   mov        dword ptr [edx + ecx], esi
00551d18  8d7340                   lea        esi, [ebx + 0x40]
00551d1b  8d85c8fcffff             lea        eax, [ebp - 0x338]
00551d21  3bf0                     cmp        esi, eax
00551d23  7462                     je         0x551d87
00551d25  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00551d2b  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00551d2e  8b95ccfcffff             mov        edx, dword ptr [ebp - 0x334]
00551d34  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551d37  8d0491                   lea        eax, [ecx + edx*4]
00551d3a  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00551d40  33c7                     xor        eax, edi
00551d42  33c2                     xor        eax, edx
00551d44  8b5604                   mov        edx, dword ptr [esi + 4]
00551d47  c1e202                   shl        edx, 2
00551d4a  8d3c0a                   lea        edi, [edx + ecx]
00551d4d  33f8                     xor        edi, eax
00551d4f  333ddc012101             xor        edi, dword ptr [0x12101dc]
00551d55  893c0a                   mov        dword ptr [edx + ecx], edi
00551d58  8b15d8012101             mov        edx, dword ptr [0x12101d8]
00551d5e  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
00551d61  8b95ccfcffff             mov        edx, dword ptr [ebp - 0x334]
00551d67  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551d6a  8d0491                   lea        eax, [ecx + edx*4]
00551d6d  8b5604                   mov        edx, dword ptr [esi + 4]
00551d70  33c7                     xor        eax, edi
00551d72  8b3ddc012101             mov        edi, dword ptr [0x12101dc]
00551d78  c1e202                   shl        edx, 2
00551d7b  33c7                     xor        eax, edi
00551d7d  8d3411                   lea        esi, [ecx + edx]
00551d80  33f0                     xor        esi, eax
00551d82  33f7                     xor        esi, edi
00551d84  893411                   mov        dword ptr [ecx + edx], esi
00551d87  8db3c8020000             lea        esi, [ebx + 0x2c8]
00551d8d  8d85d0fcffff             lea        eax, [ebp - 0x330]
00551d93  3bf0                     cmp        esi, eax
00551d95  7462                     je         0x551df9
00551d97  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00551d9d  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00551da0  8b95d4fcffff             mov        edx, dword ptr [ebp - 0x32c]
00551da6  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551da9  8d0491                   lea        eax, [ecx + edx*4]
00551dac  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00551db2  33c7                     xor        eax, edi
00551db4  33c2                     xor        eax, edx
00551db6  8b5604                   mov        edx, dword ptr [esi + 4]
00551db9  c1e202                   shl        edx, 2
00551dbc  8d3c11                   lea        edi, [ecx + edx]
00551dbf  33f8                     xor        edi, eax
00551dc1  333ddc012101             xor        edi, dword ptr [0x12101dc]
00551dc7  893c11                   mov        dword ptr [ecx + edx], edi
00551dca  8b15d8012101             mov        edx, dword ptr [0x12101d8]
00551dd0  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
00551dd3  8b95d4fcffff             mov        edx, dword ptr [ebp - 0x32c]
00551dd9  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551ddc  8d0491                   lea        eax, [ecx + edx*4]
00551ddf  8b5604                   mov        edx, dword ptr [esi + 4]
00551de2  33c7                     xor        eax, edi
00551de4  8b3ddc012101             mov        edi, dword ptr [0x12101dc]
00551dea  c1e202                   shl        edx, 2
00551ded  33c7                     xor        eax, edi
00551def  8d3411                   lea        esi, [ecx + edx]
00551df2  33f0                     xor        esi, eax
00551df4  33f7                     xor        esi, edi
00551df6  893411                   mov        dword ptr [ecx + edx], esi
00551df9  8db3d0020000             lea        esi, [ebx + 0x2d0]
00551dff  8d85d8fcffff             lea        eax, [ebp - 0x328]
00551e05  3bf0                     cmp        esi, eax
00551e07  7462                     je         0x551e6b
00551e09  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00551e0f  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00551e12  8b95dcfcffff             mov        edx, dword ptr [ebp - 0x324]
00551e18  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551e1b  8d0491                   lea        eax, [ecx + edx*4]
00551e1e  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00551e24  33c7                     xor        eax, edi
00551e26  33c2                     xor        eax, edx
00551e28  8b5604                   mov        edx, dword ptr [esi + 4]
00551e2b  c1e202                   shl        edx, 2
00551e2e  8d3c11                   lea        edi, [ecx + edx]
00551e31  33f8                     xor        edi, eax
00551e33  333ddc012101             xor        edi, dword ptr [0x12101dc]
00551e39  893c11                   mov        dword ptr [ecx + edx], edi
00551e3c  8b15d8012101             mov        edx, dword ptr [0x12101d8]
00551e42  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
00551e45  8b95dcfcffff             mov        edx, dword ptr [ebp - 0x324]
00551e4b  8b3c91                   mov        edi, dword ptr [ecx + edx*4]
00551e4e  8d0491                   lea        eax, [ecx + edx*4]
00551e51  8b5604                   mov        edx, dword ptr [esi + 4]
00551e54  33c7                     xor        eax, edi
00551e56  8b3ddc012101             mov        edi, dword ptr [0x12101dc]
00551e5c  c1e202                   shl        edx, 2
00551e5f  33c7                     xor        eax, edi
00551e61  8d3411                   lea        esi, [ecx + edx]
00551e64  33f0                     xor        esi, eax
00551e66  33f7                     xor        esi, edi
00551e68  893411                   mov        dword ptr [ecx + edx], esi
00551e6b  8b8568ffffff             mov        eax, dword ptr [ebp - 0x98]
00551e71  85c0                     test       eax, eax
00551e73  0f84bd000000             je         0x551f36
00551e79  8bb56cffffff             mov        esi, dword ptr [ebp - 0x94]
00551e7f  2bf0                     sub        esi, eax
00551e81  c1fe03                   sar        esi, 3
00551e84  85f6                     test       esi, esi
00551e86  0f84aa000000             je         0x551f36
00551e8c  83ec08                   sub        esp, 8
00551e8f  8bcc                     mov        ecx, esp
00551e91  89650c                   mov        dword ptr [ebp + 0xc], esp
00551e94  e84726ebff               call       0x4044e0
00551e99  8d8ba8020000             lea        ecx, [ebx + 0x2a8]
00551e9f  56                       push       esi
00551ea0  e86b210000               call       0x554010
00551ea5  33ff                     xor        edi, edi
00551ea7  8b8d68ffffff             mov        ecx, dword ptr [ebp - 0x98]
00551ead  85c9                     test       ecx, ecx
00551eaf  0f8481000000             je         0x551f36
00551eb5  8b856cffffff             mov        eax, dword ptr [ebp - 0x94]
00551ebb  2bc1                     sub        eax, ecx
00551ebd  c1f803                   sar        eax, 3
00551ec0  3bc7                     cmp        eax, edi
00551ec2  7672                     jbe        0x551f36
00551ec4  8bc1                     mov        eax, ecx
00551ec6  8b8bac020000             mov        ecx, dword ptr [ebx + 0x2ac]
00551ecc  85c9                     test       ecx, ecx
00551ece  8d93a8020000             lea        edx, [ebx + 0x2a8]
00551ed4  8d34f8                   lea        esi, [eax + edi*8]
00551ed7  0f8498020000             je         0x552175
00551edd  8b4208                   mov        eax, dword ptr [edx + 8]
00551ee0  2bc1                     sub        eax, ecx
00551ee2  c1f803                   sar        eax, 3
00551ee5  3bc7                     cmp        eax, edi
00551ee7  0f8688020000             jbe        0x552175
00551eed  8d14f9                   lea        edx, [ecx + edi*8]
00551ef0  3bd6                     cmp        edx, esi
00551ef2  743c                     je         0x551f30
00551ef4  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00551efa  8b4144                   mov        eax, dword ptr [ecx + 0x44]
00551efd  8b5a04                   mov        ebx, dword ptr [edx + 4]
00551f00  8b4e04                   mov        ecx, dword ptr [esi + 4]
00551f03  8d0c88                   lea        ecx, [eax + ecx*4]
00551f06  8d0498                   lea        eax, [eax + ebx*4]
00551f09  8b19                     mov        ebx, dword ptr [ecx]
00551f0b  33d8                     xor        ebx, eax
00551f0d  33d9                     xor        ebx, ecx
00551f0f  8918                     mov        dword ptr [eax], ebx
00551f11  a1d8012101               mov        eax, dword ptr [0x12101d8]
00551f16  8b5204                   mov        edx, dword ptr [edx + 4]
00551f19  8b4048                   mov        eax, dword ptr [eax + 0x48]
00551f1c  8b4e04                   mov        ecx, dword ptr [esi + 4]
00551f1f  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
00551f22  8d0c88                   lea        ecx, [eax + ecx*4]
00551f25  8d0490                   lea        eax, [eax + edx*4]
00551f28  8b11                     mov        edx, dword ptr [ecx]
00551f2a  33d0                     xor        edx, eax
00551f2c  33d1                     xor        edx, ecx
00551f2e  8910                     mov        dword ptr [eax], edx
00551f30  47                       inc        edi
00551f31  e971ffffff               jmp        0x551ea7
00551f36  8b8578ffffff             mov        eax, dword ptr [ebp - 0x88]
00551f3c  85c0                     test       eax, eax
00551f3e  0f84bd000000             je         0x552001
00551f44  8bb57cffffff             mov        esi, dword ptr [ebp - 0x84]
00551f4a  2bf0                     sub        esi, eax
00551f4c  c1fe03                   sar        esi, 3
00551f4f  85f6                     test       esi, esi
00551f51  0f84aa000000             je         0x552001
00551f57  83ec08                   sub        esp, 8
00551f5a  8bcc                     mov        ecx, esp
00551f5c  89650c                   mov        dword ptr [ebp + 0xc], esp
00551f5f  e87c25ebff               call       0x4044e0
00551f64  8d8bb8020000             lea        ecx, [ebx + 0x2b8]
00551f6a  56                       push       esi
00551f6b  e8a0200000               call       0x554010
00551f70  33ff                     xor        edi, edi
00551f72  8b8d78ffffff             mov        ecx, dword ptr [ebp - 0x88]
00551f78  85c9                     test       ecx, ecx
00551f7a  0f8481000000             je         0x552001
00551f80  8b857cffffff             mov        eax, dword ptr [ebp - 0x84]
00551f86  2bc1                     sub        eax, ecx
00551f88  c1f803                   sar        eax, 3
00551f8b  3bc7                     cmp        eax, edi
00551f8d  7672                     jbe        0x552001
00551f8f  8bc1                     mov        eax, ecx
00551f91  8b8bbc020000             mov        ecx, dword ptr [ebx + 0x2bc]
00551f97  85c9                     test       ecx, ecx
00551f99  8d93b8020000             lea        edx, [ebx + 0x2b8]
00551f9f  8d34f8                   lea        esi, [eax + edi*8]
00551fa2  0f84cd010000             je         0x552175
00551fa8  8b4208                   mov        eax, dword ptr [edx + 8]
00551fab  2bc1                     sub        eax, ecx
00551fad  c1f803                   sar        eax, 3
00551fb0  3bc7                     cmp        eax, edi
00551fb2  0f86bd010000             jbe        0x552175
00551fb8  8d14f9                   lea        edx, [ecx + edi*8]
00551fbb  3bd6                     cmp        edx, esi
00551fbd  743c                     je         0x551ffb
00551fbf  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00551fc5  8b4144                   mov        eax, dword ptr [ecx + 0x44]
00551fc8  8b5a04                   mov        ebx, dword ptr [edx + 4]
00551fcb  8b4e04                   mov        ecx, dword ptr [esi + 4]
00551fce  8d0c88                   lea        ecx, [eax + ecx*4]
00551fd1  8d0498                   lea        eax, [eax + ebx*4]
00551fd4  8b19                     mov        ebx, dword ptr [ecx]
00551fd6  33d8                     xor        ebx, eax
00551fd8  33d9                     xor        ebx, ecx
00551fda  8918                     mov        dword ptr [eax], ebx
00551fdc  a1d8012101               mov        eax, dword ptr [0x12101d8]
00551fe1  8b5204                   mov        edx, dword ptr [edx + 4]
00551fe4  8b4048                   mov        eax, dword ptr [eax + 0x48]
00551fe7  8b4e04                   mov        ecx, dword ptr [esi + 4]
00551fea  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
00551fed  8d0c88                   lea        ecx, [eax + ecx*4]
00551ff0  8d0490                   lea        eax, [eax + edx*4]
00551ff3  8b11                     mov        edx, dword ptr [ecx]
00551ff5  33d0                     xor        edx, eax
00551ff7  33d1                     xor        edx, ecx
00551ff9  8910                     mov        dword ptr [eax], edx
00551ffb  47                       inc        edi
00551ffc  e971ffffff               jmp        0x551f72
00552001  8b85e4fcffff             mov        eax, dword ptr [ebp - 0x31c]
00552007  85c0                     test       eax, eax
00552009  0f84b0000000             je         0x5520bf
0055200f  8bb5e8fcffff             mov        esi, dword ptr [ebp - 0x318]
00552015  2bf0                     sub        esi, eax
00552017  c1fe03                   sar        esi, 3
0055201a  85f6                     test       esi, esi
0055201c  0f849d000000             je         0x5520bf
00552022  83ec08                   sub        esp, 8
00552025  8bcc                     mov        ecx, esp
00552027  89650c                   mov        dword ptr [ebp + 0xc], esp
0055202a  e8b124ebff               call       0x4044e0
0055202f  8d4b48                   lea        ecx, [ebx + 0x48]
00552032  56                       push       esi
00552033  e8d81f0000               call       0x554010
00552038  33ff                     xor        edi, edi
0055203a  8b8de4fcffff             mov        ecx, dword ptr [ebp - 0x31c]
00552040  85c9                     test       ecx, ecx
00552042  747b                     je         0x5520bf
00552044  8b85e8fcffff             mov        eax, dword ptr [ebp - 0x318]
0055204a  2bc1                     sub        eax, ecx
0055204c  c1f803                   sar        eax, 3
0055204f  3bc7                     cmp        eax, edi
00552051  766c                     jbe        0x5520bf
00552053  8bc1                     mov        eax, ecx
00552055  8b4b4c                   mov        ecx, dword ptr [ebx + 0x4c]
00552058  85c9                     test       ecx, ecx
0055205a  8d5348                   lea        edx, [ebx + 0x48]
0055205d  8d34f8                   lea        esi, [eax + edi*8]
00552060  0f840f010000             je         0x552175
00552066  8b4208                   mov        eax, dword ptr [edx + 8]
00552069  2bc1                     sub        eax, ecx
0055206b  c1f803                   sar        eax, 3
0055206e  3bc7                     cmp        eax, edi
00552070  0f86ff000000             jbe        0x552175
00552076  8d14f9                   lea        edx, [ecx + edi*8]
00552079  3bd6                     cmp        edx, esi
0055207b  743c                     je         0x5520b9
0055207d  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552083  8b4144                   mov        eax, dword ptr [ecx + 0x44]
00552086  8b5a04                   mov        ebx, dword ptr [edx + 4]
00552089  8b4e04                   mov        ecx, dword ptr [esi + 4]
0055208c  8d0c88                   lea        ecx, [eax + ecx*4]
0055208f  8d0498                   lea        eax, [eax + ebx*4]
00552092  8b19                     mov        ebx, dword ptr [ecx]
00552094  33d8                     xor        ebx, eax
00552096  33d9                     xor        ebx, ecx
00552098  8918                     mov        dword ptr [eax], ebx
0055209a  a1d8012101               mov        eax, dword ptr [0x12101d8]
0055209f  8b5204                   mov        edx, dword ptr [edx + 4]
005520a2  8b4048                   mov        eax, dword ptr [eax + 0x48]
005520a5  8b4e04                   mov        ecx, dword ptr [esi + 4]
005520a8  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
005520ab  8d0c88                   lea        ecx, [eax + ecx*4]
005520ae  8d0490                   lea        eax, [eax + edx*4]
005520b1  8b11                     mov        edx, dword ptr [ecx]
005520b3  33d0                     xor        edx, eax
005520b5  33d1                     xor        edx, ecx
005520b7  8910                     mov        dword ptr [eax], edx
005520b9  47                       inc        edi
005520ba  e97bffffff               jmp        0x55203a
005520bf  8b85f4fcffff             mov        eax, dword ptr [ebp - 0x30c]
005520c5  85c0                     test       eax, eax
005520c7  0f84af000000             je         0x55217c
005520cd  8bb5f8fcffff             mov        esi, dword ptr [ebp - 0x308]
005520d3  2bf0                     sub        esi, eax
005520d5  c1fe03                   sar        esi, 3
005520d8  85f6                     test       esi, esi
005520da  0f849c000000             je         0x55217c
005520e0  83ec08                   sub        esp, 8
005520e3  8bcc                     mov        ecx, esp
005520e5  89650c                   mov        dword ptr [ebp + 0xc], esp
005520e8  e8f323ebff               call       0x4044e0
005520ed  8d4b58                   lea        ecx, [ebx + 0x58]
005520f0  56                       push       esi
005520f1  e81a1f0000               call       0x554010
005520f6  33ff                     xor        edi, edi
005520f8  8b8df4fcffff             mov        ecx, dword ptr [ebp - 0x30c]
005520fe  85c9                     test       ecx, ecx
00552100  747a                     je         0x55217c
00552102  8b85f8fcffff             mov        eax, dword ptr [ebp - 0x308]
00552108  2bc1                     sub        eax, ecx
0055210a  c1f803                   sar        eax, 3
0055210d  3bc7                     cmp        eax, edi
0055210f  766b                     jbe        0x55217c
00552111  8bc1                     mov        eax, ecx
00552113  8b4b5c                   mov        ecx, dword ptr [ebx + 0x5c]
00552116  85c9                     test       ecx, ecx
00552118  8d5358                   lea        edx, [ebx + 0x58]
0055211b  8d34f8                   lea        esi, [eax + edi*8]
0055211e  7455                     je         0x552175
00552120  8b4208                   mov        eax, dword ptr [edx + 8]
00552123  2bc1                     sub        eax, ecx
00552125  c1f803                   sar        eax, 3
00552128  3bc7                     cmp        eax, edi
0055212a  7649                     jbe        0x552175
0055212c  8d14f9                   lea        edx, [ecx + edi*8]
0055212f  3bd6                     cmp        edx, esi
00552131  743f                     je         0x552172
00552133  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552139  8b4144                   mov        eax, dword ptr [ecx + 0x44]
0055213c  8b5a04                   mov        ebx, dword ptr [edx + 4]
0055213f  8b4e04                   mov        ecx, dword ptr [esi + 4]
00552142  8d0c88                   lea        ecx, [eax + ecx*4]
00552145  8d0498                   lea        eax, [eax + ebx*4]
00552148  8bd8                     mov        ebx, eax
0055214a  33d9                     xor        ebx, ecx
0055214c  3319                     xor        ebx, dword ptr [ecx]
0055214e  8918                     mov        dword ptr [eax], ebx
00552150  a1d8012101               mov        eax, dword ptr [0x12101d8]
00552155  8b5204                   mov        edx, dword ptr [edx + 4]
00552158  8b4048                   mov        eax, dword ptr [eax + 0x48]
0055215b  8b4e04                   mov        ecx, dword ptr [esi + 4]
0055215e  8b3488                   mov        esi, dword ptr [eax + ecx*4]
00552161  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
00552164  8d0c88                   lea        ecx, [eax + ecx*4]
00552167  8d0490                   lea        eax, [eax + edx*4]
0055216a  8bd0                     mov        edx, eax
0055216c  33d1                     xor        edx, ecx
0055216e  33d6                     xor        edx, esi
00552170  8910                     mov        dword ptr [eax], edx
00552172  47                       inc        edi
00552173  eb83                     jmp        0x5520f8
00552175  8bca                     mov        ecx, edx
00552177  e88481f1ff               call       0x46a300
0055217c  8d7b68                   lea        edi, [ebx + 0x68]
0055217f  8d8500fdffff             lea        eax, [ebp - 0x300]
00552185  3bf8                     cmp        edi, eax
00552187  745e                     je         0x5521e7
00552189  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
0055218f  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00552192  8b9504fdffff             mov        edx, dword ptr [ebp - 0x2fc]
00552198  8b3491                   mov        esi, dword ptr [ecx + edx*4]
0055219b  8d0491                   lea        eax, [ecx + edx*4]
0055219e  8b5704                   mov        edx, dword ptr [edi + 4]
005521a1  33c6                     xor        eax, esi
005521a3  8b35dc012101             mov        esi, dword ptr [0x12101dc]
005521a9  c1e202                   shl        edx, 2
005521ac  8d3c0a                   lea        edi, [edx + ecx]
005521af  33c6                     xor        eax, esi
005521b1  33fe                     xor        edi, esi
005521b3  33f8                     xor        edi, eax
005521b5  893c0a                   mov        dword ptr [edx + ecx], edi
005521b8  8b15d8012101             mov        edx, dword ptr [0x12101d8]
005521be  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
005521c1  8b9504fdffff             mov        edx, dword ptr [ebp - 0x2fc]
005521c7  8b3491                   mov        esi, dword ptr [ecx + edx*4]
005521ca  8d0491                   lea        eax, [ecx + edx*4]
005521cd  8b536c                   mov        edx, dword ptr [ebx + 0x6c]
005521d0  c1e202                   shl        edx, 2
005521d3  33c6                     xor        eax, esi
005521d5  8b35dc012101             mov        esi, dword ptr [0x12101dc]
005521db  8d3c0a                   lea        edi, [edx + ecx]
005521de  33c6                     xor        eax, esi
005521e0  33fe                     xor        edi, esi
005521e2  33f8                     xor        edi, eax
005521e4  893c0a                   mov        dword ptr [edx + ecx], edi
005521e7  8d7b70                   lea        edi, [ebx + 0x70]
005521ea  8d8508fdffff             lea        eax, [ebp - 0x2f8]
005521f0  3bf8                     cmp        edi, eax
005521f2  745e                     je         0x552252
005521f4  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005521fa  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
005521fd  8b950cfdffff             mov        edx, dword ptr [ebp - 0x2f4]
00552203  8b3491                   mov        esi, dword ptr [ecx + edx*4]
00552206  8d0491                   lea        eax, [ecx + edx*4]
00552209  8b5704                   mov        edx, dword ptr [edi + 4]
0055220c  33c6                     xor        eax, esi
0055220e  8b35dc012101             mov        esi, dword ptr [0x12101dc]
00552214  c1e202                   shl        edx, 2
00552217  8d3c0a                   lea        edi, [edx + ecx]
0055221a  33c6                     xor        eax, esi
0055221c  33fe                     xor        edi, esi
0055221e  33f8                     xor        edi, eax
00552220  893c0a                   mov        dword ptr [edx + ecx], edi
00552223  8b15d8012101             mov        edx, dword ptr [0x12101d8]
00552229  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
0055222c  8b950cfdffff             mov        edx, dword ptr [ebp - 0x2f4]
00552232  8b3491                   mov        esi, dword ptr [ecx + edx*4]
00552235  8d0491                   lea        eax, [ecx + edx*4]
00552238  8b5374                   mov        edx, dword ptr [ebx + 0x74]
0055223b  33c6                     xor        eax, esi
0055223d  8b35dc012101             mov        esi, dword ptr [0x12101dc]
00552243  c1e202                   shl        edx, 2
00552246  33c6                     xor        eax, esi
00552248  8d3c0a                   lea        edi, [edx + ecx]
0055224b  33f8                     xor        edi, eax
0055224d  33fe                     xor        edi, esi
0055224f  893c0a                   mov        dword ptr [edx + ecx], edi
00552252  8d8574fdffff             lea        eax, [ebp - 0x28c]
00552258  894510                   mov        dword ptr [ebp + 0x10], eax
0055225b  8d8598fcffff             lea        eax, [ebp - 0x368]
00552261  2bc3                     sub        eax, ebx
00552263  8945c8                   mov        dword ptr [ebp - 0x38], eax
00552266  8d8594fcffff             lea        eax, [ebp - 0x36c]
0055226c  8d8b1c010000             lea        ecx, [ebx + 0x11c]
00552272  2bc3                     sub        eax, ebx
00552274  8d9514fdffff             lea        edx, [ebp - 0x2ec]
0055227a  8dbba4000000             lea        edi, [ebx + 0xa4]
00552280  894de0                   mov        dword ptr [ebp - 0x20], ecx
00552283  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552289  8945d8                   mov        dword ptr [ebp - 0x28], eax
0055228c  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552291  895508                   mov        dword ptr [ebp + 8], edx
00552294  897dc4                   mov        dword ptr [ebp - 0x3c], edi
00552297  c745d005000000           mov        dword ptr [ebp - 0x30], 5
0055229e  8bff                     mov        edi, edi
005522a0  8d72fc                   lea        esi, [edx - 4]
005522a3  8d5fd4                   lea        ebx, [edi - 0x2c]
005522a6  3bde                     cmp        ebx, esi
005522a8  745e                     je         0x552308
005522aa  8b32                     mov        esi, dword ptr [edx]
005522ac  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
005522af  c1e602                   shl        esi, 2
005522b2  8b1c0e                   mov        ebx, dword ptr [esi + ecx]
005522b5  8d140e                   lea        edx, [esi + ecx]
005522b8  8b77d8                   mov        esi, dword ptr [edi - 0x28]
005522bb  33d3                     xor        edx, ebx
005522bd  33d0                     xor        edx, eax
005522bf  c1e602                   shl        esi, 2
005522c2  8d1c0e                   lea        ebx, [esi + ecx]
005522c5  33da                     xor        ebx, edx
005522c7  33d8                     xor        ebx, eax
005522c9  8b4508                   mov        eax, dword ptr [ebp + 8]
005522cc  891c0e                   mov        dword ptr [esi + ecx], ebx
005522cf  8b15d8012101             mov        edx, dword ptr [0x12101d8]
005522d5  8b4a48                   mov        ecx, dword ptr [edx + 0x48]
005522d8  8b10                     mov        edx, dword ptr [eax]
005522da  c1e202                   shl        edx, 2
005522dd  8b340a                   mov        esi, dword ptr [edx + ecx]
005522e0  8d040a                   lea        eax, [edx + ecx]
005522e3  8b57d8                   mov        edx, dword ptr [edi - 0x28]
005522e6  33c6                     xor        eax, esi
005522e8  8b35dc012101             mov        esi, dword ptr [0x12101dc]
005522ee  c1e202                   shl        edx, 2
005522f1  33c6                     xor        eax, esi
005522f3  8d1c0a                   lea        ebx, [edx + ecx]
005522f6  33d8                     xor        ebx, eax
005522f8  33de                     xor        ebx, esi
005522fa  891c0a                   mov        dword ptr [edx + ecx], ebx
005522fd  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552302  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552308  8b75d8                   mov        esi, dword ptr [ebp - 0x28]
0055230b  8d57fc                   lea        edx, [edi - 4]
0055230e  03f7                     add        esi, edi
00552310  3bd6                     cmp        edx, esi
00552312  7460                     je         0x552374
00552314  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00552317  8b55c8                   mov        edx, dword ptr [ebp - 0x38]
0055231a  8b343a                   mov        esi, dword ptr [edx + edi]
0055231d  c1e602                   shl        esi, 2
00552320  8b1c0e                   mov        ebx, dword ptr [esi + ecx]
00552323  8d140e                   lea        edx, [esi + ecx]
00552326  8b37                     mov        esi, dword ptr [edi]
00552328  33d3                     xor        edx, ebx
0055232a  33d0                     xor        edx, eax
0055232c  c1e602                   shl        esi, 2
0055232f  8d1c31                   lea        ebx, [ecx + esi]
00552332  33da                     xor        ebx, edx
00552334  8b55c8                   mov        edx, dword ptr [ebp - 0x38]
00552337  33d8                     xor        ebx, eax
00552339  891c31                   mov        dword ptr [ecx + esi], ebx
0055233c  8b143a                   mov        edx, dword ptr [edx + edi]
0055233f  a1d8012101               mov        eax, dword ptr [0x12101d8]
00552344  8b4848                   mov        ecx, dword ptr [eax + 0x48]
00552347  c1e202                   shl        edx, 2
0055234a  8b340a                   mov        esi, dword ptr [edx + ecx]
0055234d  8d040a                   lea        eax, [edx + ecx]
00552350  8b17                     mov        edx, dword ptr [edi]
00552352  33c6                     xor        eax, esi
00552354  8b35dc012101             mov        esi, dword ptr [0x12101dc]
0055235a  c1e202                   shl        edx, 2
0055235d  33c6                     xor        eax, esi
0055235f  8d1c11                   lea        ebx, [ecx + edx]
00552362  33d8                     xor        ebx, eax
00552364  33de                     xor        ebx, esi
00552366  891c11                   mov        dword ptr [ecx + edx], ebx
00552369  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055236e  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552374  8b5ffc                   mov        ebx, dword ptr [edi - 4]
00552377  8d57fc                   lea        edx, [edi - 4]
0055237a  33d8                     xor        ebx, eax
0055237c  8d77fc                   lea        esi, [edi - 4]
0055237f  2bde                     sub        ebx, esi
00552381  3b1f                     cmp        ebx, dword ptr [edi]
00552383  7413                     je         0x552398
00552385  6a3f                     push       0x3f
00552387  52                       push       edx
00552388  e8234d5c00               call       0xb170b0
0055238d  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552392  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552398  8b5944                   mov        ebx, dword ptr [ecx + 0x44]
0055239b  8b17                     mov        edx, dword ptr [edi]
0055239d  c1e202                   shl        edx, 2
005523a0  8d3413                   lea        esi, [ebx + edx]
005523a3  333413                   xor        esi, dword ptr [ebx + edx]
005523a6  33f0                     xor        esi, eax
005523a8  8975dc                   mov        dword ptr [ebp - 0x24], esi
005523ab  8b7148                   mov        esi, dword ptr [ecx + 0x48]
005523ae  8d1c16                   lea        ebx, [esi + edx]
005523b1  331c16                   xor        ebx, dword ptr [esi + edx]
005523b4  8b55dc                   mov        edx, dword ptr [ebp - 0x24]
005523b7  33d8                     xor        ebx, eax
005523b9  3bd3                     cmp        edx, ebx
005523bb  7416                     je         0x5523d3
005523bd  6a40                     push       0x40
005523bf  8d47fc                   lea        eax, [edi - 4]
005523c2  50                       push       eax
005523c3  e8e84c5c00               call       0xb170b0
005523c8  a1dc012101               mov        eax, dword ptr [0x12101dc]
005523cd  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005523d3  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
005523d6  8b9678010000             mov        edx, dword ptr [esi + 0x178]
005523dc  8b9e7c010000             mov        ebx, dword ptr [esi + 0x17c]
005523e2  81c678010000             add        esi, 0x178
005523e8  33d0                     xor        edx, eax
005523ea  2bd6                     sub        edx, esi
005523ec  3bd3                     cmp        edx, ebx
005523ee  89750c                   mov        dword ptr [ebp + 0xc], esi
005523f1  7413                     je         0x552406
005523f3  6a3f                     push       0x3f
005523f5  56                       push       esi
005523f6  e8b54c5c00               call       0xb170b0
005523fb  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552400  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552406  8b5604                   mov        edx, dword ptr [esi + 4]
00552409  8b5944                   mov        ebx, dword ptr [ecx + 0x44]
0055240c  c1e202                   shl        edx, 2
0055240f  8d341a                   lea        esi, [edx + ebx]
00552412  33341a                   xor        esi, dword ptr [edx + ebx]
00552415  33f0                     xor        esi, eax
00552417  8975e8                   mov        dword ptr [ebp - 0x18], esi
0055241a  8b7148                   mov        esi, dword ptr [ecx + 0x48]
0055241d  8d1c32                   lea        ebx, [edx + esi]
00552420  331c32                   xor        ebx, dword ptr [edx + esi]
00552423  8b75e8                   mov        esi, dword ptr [ebp - 0x18]
00552426  33d8                     xor        ebx, eax
00552428  3bf3                     cmp        esi, ebx
0055242a  8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
0055242d  7413                     je         0x552442
0055242f  6a40                     push       0x40
00552431  53                       push       ebx
00552432  e8794c5c00               call       0xb170b0
00552437  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055243c  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552442  3975dc                   cmp        dword ptr [ebp - 0x24], esi
00552445  7e62                     jle        0x5524a9
00552447  8d57fc                   lea        edx, [edi - 4]
0055244a  3bda                     cmp        ebx, edx
0055244c  745b                     je         0x5524a9
0055244e  8b37                     mov        esi, dword ptr [edi]
00552450  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
00552453  c1e602                   shl        esi, 2
00552456  8d1431                   lea        edx, [ecx + esi]
00552459  331431                   xor        edx, dword ptr [ecx + esi]
0055245c  8b7304                   mov        esi, dword ptr [ebx + 4]
0055245f  33d0                     xor        edx, eax
00552461  c1e602                   shl        esi, 2
00552464  8d1c0e                   lea        ebx, [esi + ecx]
00552467  33da                     xor        ebx, edx
00552469  33d8                     xor        ebx, eax
0055246b  891c0e                   mov        dword ptr [esi + ecx], ebx
0055246e  8b3f                     mov        edi, dword ptr [edi]
00552470  a1d8012101               mov        eax, dword ptr [0x12101d8]
00552475  8b4848                   mov        ecx, dword ptr [eax + 0x48]
00552478  8b35dc012101             mov        esi, dword ptr [0x12101dc]
0055247e  c1e702                   shl        edi, 2
00552481  8b1439                   mov        edx, dword ptr [ecx + edi]
00552484  8d0439                   lea        eax, [ecx + edi]
00552487  33c2                     xor        eax, edx
00552489  8b550c                   mov        edx, dword ptr [ebp + 0xc]
0055248c  8b5204                   mov        edx, dword ptr [edx + 4]
0055248f  c1e202                   shl        edx, 2
00552492  33c6                     xor        eax, esi
00552494  8d3c0a                   lea        edi, [edx + ecx]
00552497  33f8                     xor        edi, eax
00552499  33fe                     xor        edi, esi
0055249b  893c0a                   mov        dword ptr [edx + ecx], edi
0055249e  a1dc012101               mov        eax, dword ptr [0x12101dc]
005524a3  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005524a9  8b7d10                   mov        edi, dword ptr [ebp + 0x10]
005524ac  8b75e0                   mov        esi, dword ptr [ebp - 0x20]
005524af  897d0c                   mov        dword ptr [ebp + 0xc], edi
005524b2  c745e002000000           mov        dword ptr [ebp - 0x20], 2
005524b9  8da42400000000           lea        esp, [esp]
005524c0  8d56ac                   lea        edx, [esi - 0x54]
005524c3  8d5fec                   lea        ebx, [edi - 0x14]
005524c6  3bd3                     cmp        edx, ebx
005524c8  7463                     je         0x55252d
005524ca  8b7ff0                   mov        edi, dword ptr [edi - 0x10]
005524cd  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
005524d0  c1e702                   shl        edi, 2
005524d3  8b1c0f                   mov        ebx, dword ptr [edi + ecx]
005524d6  8d140f                   lea        edx, [edi + ecx]
005524d9  8b7eb0                   mov        edi, dword ptr [esi - 0x50]
005524dc  33d3                     xor        edx, ebx
005524de  33d0                     xor        edx, eax
005524e0  c1e702                   shl        edi, 2
005524e3  8d1c0f                   lea        ebx, [edi + ecx]
005524e6  33da                     xor        ebx, edx
005524e8  33d8                     xor        ebx, eax
005524ea  891c0f                   mov        dword ptr [edi + ecx], ebx
005524ed  a1d8012101               mov        eax, dword ptr [0x12101d8]
005524f2  8b4848                   mov        ecx, dword ptr [eax + 0x48]
005524f5  8b7d0c                   mov        edi, dword ptr [ebp + 0xc]
005524f8  8b57f0                   mov        edx, dword ptr [edi - 0x10]
005524fb  c1e202                   shl        edx, 2
005524fe  8b1c0a                   mov        ebx, dword ptr [edx + ecx]
00552501  8d040a                   lea        eax, [edx + ecx]
00552504  8b15dc012101             mov        edx, dword ptr [0x12101dc]
0055250a  33c3                     xor        eax, ebx
0055250c  33c2                     xor        eax, edx
0055250e  8b56b0                   mov        edx, dword ptr [esi - 0x50]
00552511  c1e202                   shl        edx, 2
00552514  8d1c0a                   lea        ebx, [edx + ecx]
00552517  33d8                     xor        ebx, eax
00552519  331ddc012101             xor        ebx, dword ptr [0x12101dc]
0055251f  891c0a                   mov        dword ptr [edx + ecx], ebx
00552522  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552527  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
0055252d  8d56fc                   lea        edx, [esi - 4]
00552530  8d5ffc                   lea        ebx, [edi - 4]
00552533  3bd3                     cmp        edx, ebx
00552535  745c                     je         0x552593
00552537  8b3f                     mov        edi, dword ptr [edi]
00552539  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
0055253c  c1e702                   shl        edi, 2
0055253f  8b1c0f                   mov        ebx, dword ptr [edi + ecx]
00552542  8d140f                   lea        edx, [edi + ecx]
00552545  8b3e                     mov        edi, dword ptr [esi]
00552547  33d3                     xor        edx, ebx
00552549  33d0                     xor        edx, eax
0055254b  c1e702                   shl        edi, 2
0055254e  8d1c0f                   lea        ebx, [edi + ecx]
00552551  33da                     xor        ebx, edx
00552553  8b550c                   mov        edx, dword ptr [ebp + 0xc]
00552556  33d8                     xor        ebx, eax
00552558  891c0f                   mov        dword ptr [edi + ecx], ebx
0055255b  8b12                     mov        edx, dword ptr [edx]
0055255d  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552563  8b4948                   mov        ecx, dword ptr [ecx + 0x48]
00552566  c1e202                   shl        edx, 2
00552569  8b3c0a                   mov        edi, dword ptr [edx + ecx]
0055256c  8d040a                   lea        eax, [edx + ecx]
0055256f  8b16                     mov        edx, dword ptr [esi]
00552571  33c7                     xor        eax, edi
00552573  8b3ddc012101             mov        edi, dword ptr [0x12101dc]
00552579  c1e202                   shl        edx, 2
0055257c  33c7                     xor        eax, edi
0055257e  8d1c0a                   lea        ebx, [edx + ecx]
00552581  33d8                     xor        ebx, eax
00552583  33df                     xor        ebx, edi
00552585  891c0a                   mov        dword ptr [edx + ecx], ebx
00552588  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055258d  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552593  8b5efc                   mov        ebx, dword ptr [esi - 4]
00552596  8d56fc                   lea        edx, [esi - 4]
00552599  33d8                     xor        ebx, eax
0055259b  8d7efc                   lea        edi, [esi - 4]
0055259e  2bdf                     sub        ebx, edi
005525a0  3b1e                     cmp        ebx, dword ptr [esi]
005525a2  7413                     je         0x5525b7
005525a4  6a3f                     push       0x3f
005525a6  52                       push       edx
005525a7  e8044b5c00               call       0xb170b0
005525ac  a1dc012101               mov        eax, dword ptr [0x12101dc]
005525b1  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005525b7  8b5944                   mov        ebx, dword ptr [ecx + 0x44]
005525ba  8b16                     mov        edx, dword ptr [esi]
005525bc  c1e202                   shl        edx, 2
005525bf  8d3c1a                   lea        edi, [edx + ebx]
005525c2  333c1a                   xor        edi, dword ptr [edx + ebx]
005525c5  33f8                     xor        edi, eax
005525c7  897ddc                   mov        dword ptr [ebp - 0x24], edi
005525ca  8b7948                   mov        edi, dword ptr [ecx + 0x48]
005525cd  8d1c3a                   lea        ebx, [edx + edi]
005525d0  331c3a                   xor        ebx, dword ptr [edx + edi]
005525d3  8b55dc                   mov        edx, dword ptr [ebp - 0x24]
005525d6  33d8                     xor        ebx, eax
005525d8  3bd3                     cmp        edx, ebx
005525da  7416                     je         0x5525f2
005525dc  6a40                     push       0x40
005525de  8d46fc                   lea        eax, [esi - 4]
005525e1  50                       push       eax
005525e2  e8c94a5c00               call       0xb170b0
005525e7  a1dc012101               mov        eax, dword ptr [0x12101dc]
005525ec  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005525f2  8b7df0                   mov        edi, dword ptr [ebp - 0x10]
005525f5  8b9778010000             mov        edx, dword ptr [edi + 0x178]
005525fb  8b9f7c010000             mov        ebx, dword ptr [edi + 0x17c]
00552601  81c778010000             add        edi, 0x178
00552607  33d0                     xor        edx, eax
00552609  2bd7                     sub        edx, edi
0055260b  3bd3                     cmp        edx, ebx
0055260d  7413                     je         0x552622
0055260f  6a3f                     push       0x3f
00552611  57                       push       edi
00552612  e8994a5c00               call       0xb170b0
00552617  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055261c  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552622  8b5704                   mov        edx, dword ptr [edi + 4]
00552625  8b5944                   mov        ebx, dword ptr [ecx + 0x44]
00552628  c1e202                   shl        edx, 2
0055262b  8d3c1a                   lea        edi, [edx + ebx]
0055262e  333c1a                   xor        edi, dword ptr [edx + ebx]
00552631  33f8                     xor        edi, eax
00552633  897de8                   mov        dword ptr [ebp - 0x18], edi
00552636  8b7948                   mov        edi, dword ptr [ecx + 0x48]
00552639  8d1c3a                   lea        ebx, [edx + edi]
0055263c  331c3a                   xor        ebx, dword ptr [edx + edi]
0055263f  8b7de8                   mov        edi, dword ptr [ebp - 0x18]
00552642  33d8                     xor        ebx, eax
00552644  3bfb                     cmp        edi, ebx
00552646  741b                     je         0x552663
00552648  8b45f0                   mov        eax, dword ptr [ebp - 0x10]
0055264b  6a40                     push       0x40
0055264d  0578010000               add        eax, 0x178
00552652  50                       push       eax
00552653  e8584a5c00               call       0xb170b0
00552658  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055265d  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552663  397ddc                   cmp        dword ptr [ebp - 0x24], edi
00552666  7e71                     jle        0x5526d9
00552668  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
0055266b  81c378010000             add        ebx, 0x178
00552671  8d56fc                   lea        edx, [esi - 4]
00552674  3bda                     cmp        ebx, edx
00552676  7461                     je         0x5526d9
00552678  8b4944                   mov        ecx, dword ptr [ecx + 0x44]
0055267b  8b3e                     mov        edi, dword ptr [esi]
0055267d  c1e702                   shl        edi, 2
00552680  8d140f                   lea        edx, [edi + ecx]
00552683  33140f                   xor        edx, dword ptr [edi + ecx]
00552686  8b7b04                   mov        edi, dword ptr [ebx + 4]
00552689  33d0                     xor        edx, eax
0055268b  c1e702                   shl        edi, 2
0055268e  8d1c0f                   lea        ebx, [edi + ecx]
00552691  33da                     xor        ebx, edx
00552693  33d8                     xor        ebx, eax
00552695  891c0f                   mov        dword ptr [edi + ecx], ebx
00552698  a1d8012101               mov        eax, dword ptr [0x12101d8]
0055269d  8b4848                   mov        ecx, dword ptr [eax + 0x48]
005526a0  8b16                     mov        edx, dword ptr [esi]
005526a2  c1e202                   shl        edx, 2
005526a5  8b3c0a                   mov        edi, dword ptr [edx + ecx]
005526a8  8d040a                   lea        eax, [edx + ecx]
005526ab  8b55f0                   mov        edx, dword ptr [ebp - 0x10]
005526ae  81c278010000             add        edx, 0x178
005526b4  8b5204                   mov        edx, dword ptr [edx + 4]
005526b7  33c7                     xor        eax, edi
005526b9  8b3ddc012101             mov        edi, dword ptr [0x12101dc]
005526bf  c1e202                   shl        edx, 2
005526c2  33c7                     xor        eax, edi
005526c4  8d1c0a                   lea        ebx, [edx + ecx]
005526c7  33d8                     xor        ebx, eax
005526c9  33df                     xor        ebx, edi
005526cb  891c0a                   mov        dword ptr [edx + ecx], ebx
005526ce  a1dc012101               mov        eax, dword ptr [0x12101dc]
005526d3  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005526d9  8b7d0c                   mov        edi, dword ptr [ebp + 0xc]
005526dc  8b55e0                   mov        edx, dword ptr [ebp - 0x20]
005526df  83c708                   add        edi, 8
005526e2  83c608                   add        esi, 8
005526e5  4a                       dec        edx
005526e6  897d0c                   mov        dword ptr [ebp + 0xc], edi
005526e9  8955e0                   mov        dword ptr [ebp - 0x20], edx
005526ec  0f85cefdffff             jne        0x5524c0
005526f2  8b5508                   mov        edx, dword ptr [ebp + 8]
005526f5  8b7dc4                   mov        edi, dword ptr [ebp - 0x3c]
005526f8  8b5d10                   mov        ebx, dword ptr [ebp + 0x10]
005526fb  8975e0                   mov        dword ptr [ebp - 0x20], esi
005526fe  8b75d0                   mov        esi, dword ptr [ebp - 0x30]
00552701  83c208                   add        edx, 8
00552704  83c708                   add        edi, 8
00552707  83c320                   add        ebx, 0x20
0055270a  4e                       dec        esi
0055270b  895508                   mov        dword ptr [ebp + 8], edx
0055270e  897dc4                   mov        dword ptr [ebp - 0x3c], edi
00552711  895d10                   mov        dword ptr [ebp + 0x10], ebx
00552714  8975d0                   mov        dword ptr [ebp - 0x30], esi
00552717  0f8583fbffff             jne        0x5522a0
0055271d  c7450c00000000           mov        dword ptr [ebp + 0xc], 0
00552724  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
00552727  8b5620                   mov        edx, dword ptr [esi + 0x20]
0055272a  8b7e24                   mov        edi, dword ptr [esi + 0x24]
0055272d  83c620                   add        esi, 0x20
00552730  33d0                     xor        edx, eax
00552732  2bd6                     sub        edx, esi
00552734  3bd7                     cmp        edx, edi
00552736  7413                     je         0x55274b
00552738  6a3f                     push       0x3f
0055273a  56                       push       esi
0055273b  e870495c00               call       0xb170b0
00552740  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552745  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
0055274b  8b5944                   mov        ebx, dword ptr [ecx + 0x44]
0055274e  8b5604                   mov        edx, dword ptr [esi + 4]
00552751  c1e202                   shl        edx, 2
00552754  8d3c1a                   lea        edi, [edx + ebx]
00552757  333c1a                   xor        edi, dword ptr [edx + ebx]
0055275a  33f8                     xor        edi, eax
0055275c  897d08                   mov        dword ptr [ebp + 8], edi
0055275f  8b7948                   mov        edi, dword ptr [ecx + 0x48]
00552762  8d1c3a                   lea        ebx, [edx + edi]
00552765  331c3a                   xor        ebx, dword ptr [edx + edi]
00552768  8b7d08                   mov        edi, dword ptr [ebp + 8]
0055276b  33d8                     xor        ebx, eax
0055276d  3bfb                     cmp        edi, ebx
0055276f  7413                     je         0x552784
00552771  6a40                     push       0x40
00552773  56                       push       esi
00552774  e837495c00               call       0xb170b0
00552779  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055277e  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552784  8b550c                   mov        edx, dword ptr [ebp + 0xc]
00552787  42                       inc        edx
00552788  3bd7                     cmp        edx, edi
0055278a  8955e8                   mov        dword ptr [ebp - 0x18], edx
0055278d  0f8feb030000             jg         0x552b7e
00552793  8b16                     mov        edx, dword ptr [esi]
00552795  8b7e04                   mov        edi, dword ptr [esi + 4]
00552798  33d0                     xor        edx, eax
0055279a  2bd6                     sub        edx, esi
0055279c  3bd7                     cmp        edx, edi
0055279e  7413                     je         0x5527b3
005527a0  6a3f                     push       0x3f
005527a2  56                       push       esi
005527a3  e808495c00               call       0xb170b0
005527a8  a1dc012101               mov        eax, dword ptr [0x12101dc]
005527ad  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005527b3  8b5944                   mov        ebx, dword ptr [ecx + 0x44]
005527b6  8b5604                   mov        edx, dword ptr [esi + 4]
005527b9  c1e202                   shl        edx, 2
005527bc  8d3c1a                   lea        edi, [edx + ebx]
005527bf  333c1a                   xor        edi, dword ptr [edx + ebx]
005527c2  33f8                     xor        edi, eax
005527c4  897d08                   mov        dword ptr [ebp + 8], edi
005527c7  8b7948                   mov        edi, dword ptr [ecx + 0x48]
005527ca  8d1c3a                   lea        ebx, [edx + edi]
005527cd  331c3a                   xor        ebx, dword ptr [edx + edi]
005527d0  8b5508                   mov        edx, dword ptr [ebp + 8]
005527d3  33d8                     xor        ebx, eax
005527d5  3bd3                     cmp        edx, ebx
005527d7  7413                     je         0x5527ec
005527d9  6a40                     push       0x40
005527db  56                       push       esi
005527dc  e8cf485c00               call       0xb170b0
005527e1  a1dc012101               mov        eax, dword ptr [0x12101dc]
005527e6  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005527ec  8b9518feffff             mov        edx, dword ptr [ebp - 0x1e8]
005527f2  33d0                     xor        edx, eax
005527f4  8db518feffff             lea        esi, [ebp - 0x1e8]
005527fa  2bd6                     sub        edx, esi
005527fc  8bb51cfeffff             mov        esi, dword ptr [ebp - 0x1e4]
00552802  3bd6                     cmp        edx, esi
00552804  741f                     je         0x552825
00552806  6a3f                     push       0x3f
00552808  8d8518feffff             lea        eax, [ebp - 0x1e8]
0055280e  50                       push       eax
0055280f  e89c485c00               call       0xb170b0
00552814  8bb51cfeffff             mov        esi, dword ptr [ebp - 0x1e4]
0055281a  a1dc012101               mov        eax, dword ptr [0x12101dc]
0055281f  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552825  8b7944                   mov        edi, dword ptr [ecx + 0x44]
00552828  8b1cb7                   mov        ebx, dword ptr [edi + esi*4]
0055282b  8d14b7                   lea        edx, [edi + esi*4]
0055282e  8b7948                   mov        edi, dword ptr [ecx + 0x48]
00552831  33d3                     xor        edx, ebx
00552833  8d1cb7                   lea        ebx, [edi + esi*4]
00552836  331cb7                   xor        ebx, dword ptr [edi + esi*4]
00552839  33d0                     xor        edx, eax
0055283b  33d8                     xor        ebx, eax
0055283d  3bd3                     cmp        edx, ebx
0055283f  895510                   mov        dword ptr [ebp + 0x10], edx
00552842  7419                     je         0x55285d
00552844  6a40                     push       0x40
00552846  8d9518feffff             lea        edx, [ebp - 0x1e8]
0055284c  52                       push       edx
0055284d  e85e485c00               call       0xb170b0
00552852  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552857  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
0055285d  8bb510feffff             mov        esi, dword ptr [ebp - 0x1f0]
00552863  33f0                     xor        esi, eax
00552865  8d9510feffff             lea        edx, [ebp - 0x1f0]
0055286b  2bf2                     sub        esi, edx
0055286d  8b9514feffff             mov        edx, dword ptr [ebp - 0x1ec]
00552873  3bf2                     cmp        esi, edx
00552875  741f                     je         0x552896
00552877  6a3f                     push       0x3f
00552879  8d8510feffff             lea        eax, [ebp - 0x1f0]
0055287f  50                       push       eax
00552880  e82b485c00               call       0xb170b0
00552885  8b9514feffff             mov        edx, dword ptr [ebp - 0x1ec]
0055288b  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552890  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552896  8b7944                   mov        edi, dword ptr [ecx + 0x44]
00552899  8b1c97                   mov        ebx, dword ptr [edi + edx*4]
0055289c  8d3497                   lea        esi, [edi + edx*4]
0055289f  8b7948                   mov        edi, dword ptr [ecx + 0x48]
005528a2  33f3                     xor        esi, ebx
005528a4  8d1c97                   lea        ebx, [edi + edx*4]
005528a7  331c97                   xor        ebx, dword ptr [edi + edx*4]
005528aa  33f0                     xor        esi, eax
005528ac  33d8                     xor        ebx, eax
005528ae  3bf3                     cmp        esi, ebx
005528b0  740e                     je         0x5528c0
005528b2  6a40                     push       0x40
005528b4  8d9510feffff             lea        edx, [ebp - 0x1f0]
005528ba  52                       push       edx
005528bb  e8f0475c00               call       0xb170b0
005528c0  8b4508                   mov        eax, dword ptr [ebp + 8]
005528c3  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
005528c6  8b5510                   mov        edx, dword ptr [ebp + 0x10]
005528c9  48                       dec        eax
005528ca  50                       push       eax
005528cb  51                       push       ecx
005528cc  52                       push       edx
005528cd  56                       push       esi
005528ce  e8dd705b00               call       0xb099b0
005528d3  83c410                   add        esp, 0x10
005528d6  e869ec6a00               call       0xc01544
005528db  894508                   mov        dword ptr [ebp + 8], eax
005528de  8d4508                   lea        eax, [ebp + 8]
005528e1  50                       push       eax
005528e2  8d4dd4                   lea        ecx, [ebp - 0x2c]
005528e5  e866f8eaff               call       0x402150
005528ea  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
005528ed  8b8684010000             mov        eax, dword ptr [esi + 0x184]
005528f3  81c680010000             add        esi, 0x180
005528f9  85c0                     test       eax, eax
005528fb  c645fc01                 mov        byte ptr [ebp - 4], 1
005528ff  7504                     jne        0x552905
00552901  33d2                     xor        edx, edx
00552903  eb08                     jmp        0x55290d
00552905  8b5608                   mov        edx, dword ptr [esi + 8]
00552908  2bd0                     sub        edx, eax
0055290a  c1fa03                   sar        edx, 3
0055290d  85c0                     test       eax, eax
0055290f  742b                     je         0x55293c
00552911  8b4e0c                   mov        ecx, dword ptr [esi + 0xc]
00552914  2bc8                     sub        ecx, eax
00552916  c1f903                   sar        ecx, 3
00552919  3bd1                     cmp        edx, ecx
0055291b  731f                     jae        0x55293c
0055291d  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00552920  8b7e08                   mov        edi, dword ptr [esi + 8]
00552923  51                       push       ecx
00552924  56                       push       esi
00552925  8d55d4                   lea        edx, [ebp - 0x2c]
00552928  52                       push       edx
00552929  6a01                     push       1
0055292b  57                       push       edi
0055292c  e8bf69f1ff               call       0x4692f0
00552931  83c414                   add        esp, 0x14
00552934  83c708                   add        edi, 8
00552937  897e08                   mov        dword ptr [esi + 8], edi
0055293a  eb11                     jmp        0x55294d
0055293c  8b4608                   mov        eax, dword ptr [esi + 8]
0055293f  8d4dd4                   lea        ecx, [ebp - 0x2c]
00552942  51                       push       ecx
00552943  6a01                     push       1
00552945  50                       push       eax
00552946  8bce                     mov        ecx, esi
00552948  e8837df1ff               call       0x46a6d0
0055294d  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552953  8d55d4                   lea        edx, [ebp - 0x2c]
00552956  52                       push       edx
00552957  c645fc02                 mov        byte ptr [ebp - 4], 2
0055295b  e8404a5c00               call       0xb173a0
00552960  8d4dd4                   lea        ecx, [ebp - 0x2c]
00552963  c645fc00                 mov        byte ptr [ebp - 4], 0
00552967  e814515c00               call       0xb17a80
0055296c  8b8d20feffff             mov        ecx, dword ptr [ebp - 0x1e0]
00552972  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00552978  33ca                     xor        ecx, edx
0055297a  8d8520feffff             lea        eax, [ebp - 0x1e0]
00552980  2bc8                     sub        ecx, eax
00552982  8b8524feffff             mov        eax, dword ptr [ebp - 0x1dc]
00552988  3bc8                     cmp        ecx, eax
0055298a  7420                     je         0x5529ac
0055298c  6a3f                     push       0x3f
0055298e  8d8d20feffff             lea        ecx, [ebp - 0x1e0]
00552994  51                       push       ecx
00552995  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
0055299b  e810475c00               call       0xb170b0
005529a0  8b8524feffff             mov        eax, dword ptr [ebp - 0x1dc]
005529a6  8b15dc012101             mov        edx, dword ptr [0x12101dc]
005529ac  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005529b2  8b7944                   mov        edi, dword ptr [ecx + 0x44]
005529b5  8b1c87                   mov        ebx, dword ptr [edi + eax*4]
005529b8  8d3487                   lea        esi, [edi + eax*4]
005529bb  8b7948                   mov        edi, dword ptr [ecx + 0x48]
005529be  33f3                     xor        esi, ebx
005529c0  8d1c87                   lea        ebx, [edi + eax*4]
005529c3  331c87                   xor        ebx, dword ptr [edi + eax*4]
005529c6  33f2                     xor        esi, edx
005529c8  33da                     xor        ebx, edx
005529ca  3bf3                     cmp        esi, ebx
005529cc  7420                     je         0x5529ee
005529ce  6a40                     push       0x40
005529d0  8d9520feffff             lea        edx, [ebp - 0x1e0]
005529d6  52                       push       edx
005529d7  e8d4465c00               call       0xb170b0
005529dc  8b8524feffff             mov        eax, dword ptr [ebp - 0x1dc]
005529e2  8b15dc012101             mov        edx, dword ptr [0x12101dc]
005529e8  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
005529ee  8bbd20feffff             mov        edi, dword ptr [ebp - 0x1e0]
005529f4  897508                   mov        dword ptr [ebp + 8], esi
005529f7  33fa                     xor        edi, edx
005529f9  8db520feffff             lea        esi, [ebp - 0x1e0]
005529ff  2bfe                     sub        edi, esi
00552a01  3bf8                     cmp        edi, eax
00552a03  741c                     je         0x552a21
00552a05  6a3f                     push       0x3f
00552a07  8bc6                     mov        eax, esi
00552a09  50                       push       eax
00552a0a  e8a1465c00               call       0xb170b0
00552a0f  8b8524feffff             mov        eax, dword ptr [ebp - 0x1dc]
00552a15  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00552a1b  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552a21  8b7944                   mov        edi, dword ptr [ecx + 0x44]
00552a24  8b1c87                   mov        ebx, dword ptr [edi + eax*4]
00552a27  8d3487                   lea        esi, [edi + eax*4]
00552a2a  8b7948                   mov        edi, dword ptr [ecx + 0x48]
00552a2d  33f3                     xor        esi, ebx
00552a2f  8d1c87                   lea        ebx, [edi + eax*4]
00552a32  331c87                   xor        ebx, dword ptr [edi + eax*4]
00552a35  33f2                     xor        esi, edx
00552a37  33da                     xor        ebx, edx
00552a39  3bf3                     cmp        esi, ebx
00552a3b  741a                     je         0x552a57
00552a3d  6a40                     push       0x40
00552a3f  8d9520feffff             lea        edx, [ebp - 0x1e0]
00552a45  52                       push       edx
00552a46  e865465c00               call       0xb170b0
00552a4b  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00552a51  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552a57  d94508                   fld        dword ptr [ebp + 8]
00552a5a  897510                   mov        dword ptr [ebp + 0x10], esi
00552a5d  d9e1                     fabs       
00552a5f  d94510                   fld        dword ptr [ebp + 0x10]
00552a62  d9e1                     fabs       
00552a64  dc0de8b8ca00             fmul       qword ptr [0xcab8e8]
00552a6a  ded9                     fcompp     
00552a6c  dfe0                     fnstsw     ax
00552a6e  f6c401                   test       ah, 1
00552a71  0f858c000000             jne        0x552b03
00552a77  8bb528feffff             mov        esi, dword ptr [ebp - 0x1d8]
00552a7d  33f2                     xor        esi, edx
00552a7f  8d8528feffff             lea        eax, [ebp - 0x1d8]
00552a85  2bf0                     sub        esi, eax
00552a87  8b852cfeffff             mov        eax, dword ptr [ebp - 0x1d4]
00552a8d  3bf0                     cmp        esi, eax
00552a8f  7420                     je         0x552ab1
00552a91  6a3f                     push       0x3f
00552a93  8d9528feffff             lea        edx, [ebp - 0x1d8]
00552a99  52                       push       edx
00552a9a  e811465c00               call       0xb170b0
00552a9f  8b852cfeffff             mov        eax, dword ptr [ebp - 0x1d4]
00552aa5  8b15dc012101             mov        edx, dword ptr [0x12101dc]
00552aab  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552ab1  8b7944                   mov        edi, dword ptr [ecx + 0x44]
00552ab4  8b1c87                   mov        ebx, dword ptr [edi + eax*4]
00552ab7  8d3487                   lea        esi, [edi + eax*4]
00552aba  8b7948                   mov        edi, dword ptr [ecx + 0x48]
00552abd  33f3                     xor        esi, ebx
00552abf  8d1c87                   lea        ebx, [edi + eax*4]
00552ac2  331c87                   xor        ebx, dword ptr [edi + eax*4]
00552ac5  33f2                     xor        esi, edx
00552ac7  33da                     xor        ebx, edx
00552ac9  3bf3                     cmp        esi, ebx
00552acb  740e                     je         0x552adb
00552acd  6a40                     push       0x40
00552acf  8d8528feffff             lea        eax, [ebp - 0x1d8]
00552ad5  50                       push       eax
00552ad6  e8d5455c00               call       0xb170b0
00552adb  897508                   mov        dword ptr [ebp + 8], esi
00552ade  d94508                   fld        dword ptr [ebp + 8]
00552ae1  d9e1                     fabs       
00552ae3  8d8d28feffff             lea        ecx, [ebp - 0x1d8]
00552ae9  dd5dc0                   fstp       qword ptr [ebp - 0x40]
00552aec  e8bf08eeff               call       0x4333b0
00552af1  d9e1                     fabs       
00552af3  dc0de8b8ca00             fmul       qword ptr [0xcab8e8]
00552af9  dc5dc0                   fcomp      qword ptr [ebp - 0x40]
00552afc  dfe0                     fnstsw     ax
00552afe  f6c401                   test       ah, 1
00552b01  7465                     je         0x552b68
00552b03  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
00552b06  8d4e20                   lea        ecx, [esi + 0x20]
00552b09  e852f5eaff               call       0x402060
00552b0e  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00552b11  48                       dec        eax
00552b12  50                       push       eax
00552b13  51                       push       ecx
00552b14  8d8d28feffff             lea        ecx, [ebp - 0x1d8]
00552b1a  e89108eeff               call       0x4333b0
00552b1f  51                       push       ecx
00552b20  8d8d20feffff             lea        ecx, [ebp - 0x1e0]
00552b26  d91c24                   fstp       dword ptr [esp]
00552b29  e88208eeff               call       0x4333b0
00552b2e  51                       push       ecx
00552b2f  d91c24                   fstp       dword ptr [esp]
00552b32  e8796e5b00               call       0xb099b0
00552b37  83c410                   add        esp, 0x10
00552b3a  d95d0c                   fstp       dword ptr [ebp + 0xc]
00552b3d  8d550c                   lea        edx, [ebp + 0xc]
00552b40  52                       push       edx
00552b41  8d4dcc                   lea        ecx, [ebp - 0x34]
00552b44  e8c7a4efff               call       0x44d010
00552b49  8d45cc                   lea        eax, [ebp - 0x34]
00552b4c  50                       push       eax
00552b4d  8d8e90010000             lea        ecx, [esi + 0x190]
00552b53  c645fc03                 mov        byte ptr [ebp - 4], 3
00552b57  e884eaefff               call       0x4515e0
00552b5c  8d4dcc                   lea        ecx, [ebp - 0x34]
00552b5f  c645fc00                 mov        byte ptr [ebp - 4], 0
00552b63  e8a8f4eaff               call       0x402010
00552b68  8b4de8                   mov        ecx, dword ptr [ebp - 0x18]
00552b6b  a1dc012101               mov        eax, dword ptr [0x12101dc]
00552b70  894d0c                   mov        dword ptr [ebp + 0xc], ecx
00552b73  8b0dd8012101             mov        ecx, dword ptr [0x12101d8]
00552b79  e9a6fbffff               jmp        0x552724
00552b7e  8bce                     mov        ecx, esi
00552b80  bb01000000               mov        ebx, 1
00552b85  e8d6f4eaff               call       0x402060
00552b8a  3bc3                     cmp        eax, ebx
00552b8c  0f8c89000000             jl         0x552c1b
00552b92  8bce                     mov        ecx, esi
00552b94  e8c7f4eaff               call       0x402060
00552b99  8bf8                     mov        edi, eax
00552b9b  8d8d38feffff             lea        ecx, [ebp - 0x1c8]
00552ba1  4f                       dec        edi
00552ba2  e8b9f4eaff               call       0x402060
00552ba7  8d8d30feffff             lea        ecx, [ebp - 0x1d0]
00552bad  89450c                   mov        dword ptr [ebp + 0xc], eax
00552bb0  e8abf4eaff               call       0x402060
00552bb5  db450c                   fild       dword ptr [ebp + 0xc]
00552bb8  57                       push       edi
00552bb9  8d53ff                   lea        edx, [ebx - 1]
00552bbc  52                       push       edx
00552bbd  83ec08                   sub        esp, 8
00552bc0  d95c2404                 fstp       dword ptr [esp + 4]
00552bc4  894508                   mov        dword ptr [ebp + 8], eax
00552bc7  db4508                   fild       dword ptr [ebp + 8]
00552bca  d91c24                   fstp       dword ptr [esp]
00552bcd  e8de6d5b00               call       0xb099b0
00552bd2  83c410                   add        esp, 0x10
00552bd5  e86ae96a00               call       0xc01544
00552bda  89450c                   mov        dword ptr [ebp + 0xc], eax
00552bdd  8d450c                   lea        eax, [ebp + 0xc]
00552be0  50                       push       eax
00552be1  8d4de4                   lea        ecx, [ebp - 0x1c]
00552be4  e867f5eaff               call       0x402150
00552be9  8d4de4                   lea        ecx, [ebp - 0x1c]
00552bec  51                       push       ecx
00552bed  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00552bf0  81c1a0010000             add        ecx, 0x1a0
00552bf6  c645fc04                 mov        byte ptr [ebp - 4], 4
00552bfa  e8b1a4f1ff               call       0x46d0b0
00552bff  8d4de4                   lea        ecx, [ebp - 0x1c]
00552c02  c645fc00                 mov        byte ptr [ebp - 4], 0
00552c06  e805f4eaff               call       0x402010
00552c0b  8bce                     mov        ecx, esi
00552c0d  43                       inc        ebx
00552c0e  e84df4eaff               call       0x402060
00552c13  3bd8                     cmp        ebx, eax
00552c15  0f8e77ffffff             jle        0x552b92
00552c1b  8b7df0                   mov        edi, dword ptr [ebp - 0x10]
00552c1e  8d9540feffff             lea        edx, [ebp - 0x1c0]
00552c24  52                       push       edx
00552c25  8d8fb0010000             lea        ecx, [edi + 0x1b0]
00552c2b  e88019ebff               call       0x4045b0
00552c30  8d8548feffff             lea        eax, [ebp - 0x1b8]
00552c36  50                       push       eax
00552c37  8d8fb8010000             lea        ecx, [edi + 0x1b8]
00552c3d  e84e150000               call       0x554190
00552c42  8d8d58feffff             lea        ecx, [ebp - 0x1a8]
00552c48  51                       push       ecx
00552c49  8d8fc8010000             lea        ecx, [edi + 0x1c8]
00552c4f  e8bc8df1ff               call       0x46ba10
00552c54  8d9568feffff             lea        edx, [ebp - 0x198]
00552c5a  52                       push       edx
00552c5b  8d8fd8010000             lea        ecx, [edi + 0x1d8]
00552c61  e84a19ebff               call       0x4045b0
00552c66  8d45a8                   lea        eax, [ebp - 0x58]
00552c69  50                       push       eax
00552c6a  8d8ffc020000             lea        ecx, [edi + 0x2fc]
00552c70  e83b19ebff               call       0x4045b0
00552c75  8bce                     mov        ecx, esi
00552c77  bb01000000               mov        ebx, 1
00552c7c  e8dff3eaff               call       0x402060
00552c81  3bc3                     cmp        eax, ebx
00552c83  0f8cc3000000             jl         0x552d4c
00552c89  8da42400000000           lea        esp, [esp]
00552c90  8bce                     mov        ecx, esi
00552c92  e8c9f3eaff               call       0x402060
00552c97  8bf8                     mov        edi, eax
00552c99  8d8d78feffff             lea        ecx, [ebp - 0x188]
00552c9f  4f                       dec        edi
00552ca0  e8bbf3eaff               call       0x402060
00552ca5  8d8d70feffff             lea        ecx, [ebp - 0x190]
00552cab  89450c                   mov        dword ptr [ebp + 0xc], eax
00552cae  e8adf3eaff               call       0x402060
00552cb3  db450c                   fild       dword ptr [ebp + 0xc]
00552cb6  57                       push       edi
00552cb7  8d4bff                   lea        ecx, [ebx - 1]
00552cba  51                       push       ecx
00552cbb  83ec08                   sub        esp, 8
00552cbe  d95c2404                 fstp       dword ptr [esp + 4]
00552cc2  894508                   mov        dword ptr [ebp + 8], eax
00552cc5  db4508                   fild       dword ptr [ebp + 8]
00552cc8  d91c24                   fstp       dword ptr [esp]
00552ccb  e8e06c5b00               call       0xb099b0
00552cd0  83c410                   add        esp, 0x10
00552cd3  e86ce86a00               call       0xc01544
00552cd8  8d550c                   lea        edx, [ebp + 0xc]
00552cdb  8bf8                     mov        edi, eax
00552cdd  52                       push       edx
00552cde  8d4de4                   lea        ecx, [ebp - 0x1c]
00552ce1  897d0c                   mov        dword ptr [ebp + 0xc], edi
00552ce4  e867f4eaff               call       0x402150
00552ce9  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00552cec  8d45e4                   lea        eax, [ebp - 0x1c]
00552cef  50                       push       eax
00552cf0  81c1f0010000             add        ecx, 0x1f0
00552cf6  c645fc05                 mov        byte ptr [ebp - 4], 5
00552cfa  e8b1a3f1ff               call       0x46d0b0
00552cff  8d4de4                   lea        ecx, [ebp - 0x1c]
00552d02  c645fc00                 mov        byte ptr [ebp - 4], 0
00552d06  e805f3eaff               call       0x402010
00552d0b  8d4d0c                   lea        ecx, [ebp + 0xc]
00552d0e  51                       push       ecx
00552d0f  8d4dd4                   lea        ecx, [ebp - 0x2c]
00552d12  897d0c                   mov        dword ptr [ebp + 0xc], edi
00552d15  e836f4eaff               call       0x402150
00552d1a  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00552d1d  8d55d4                   lea        edx, [ebp - 0x2c]
00552d20  52                       push       edx
00552d21  81c1e0010000             add        ecx, 0x1e0
00552d27  c645fc06                 mov        byte ptr [ebp - 4], 6
00552d2b  e880a3f1ff               call       0x46d0b0
00552d30  8d4dd4                   lea        ecx, [ebp - 0x2c]
00552d33  c645fc00                 mov        byte ptr [ebp - 4], 0
00552d37  e8d4f2eaff               call       0x402010
00552d3c  8bce                     mov        ecx, esi
00552d3e  43                       inc        ebx
00552d3f  e81cf3eaff               call       0x402060
00552d44  3bd8                     cmp        ebx, eax
00552d46  0f8e44ffffff             jle        0x552c90
00552d4c  8b8584feffff             mov        eax, dword ptr [ebp - 0x17c]
00552d52  85c0                     test       eax, eax
00552d54  7472                     je         0x552dc8
00552d56  8bb588feffff             mov        esi, dword ptr [ebp - 0x178]
00552d5c  2bf0                     sub        esi, eax
00552d5e  c1fe03                   sar        esi, 3
00552d61  85f6                     test       esi, esi
00552d63  7463                     je         0x552dc8
00552d65  83ec08                   sub        esp, 8
00552d68  8bcc                     mov        ecx, esp
00552d6a  89650c                   mov        dword ptr [ebp + 0xc], esp
00552d6d  e86e17ebff               call       0x4044e0
00552d72  8b7df0                   mov        edi, dword ptr [ebp - 0x10]
00552d75  81c700020000             add        edi, 0x200
00552d7b  56                       push       esi
00552d7c  8bcf                     mov        ecx, edi
00552d7e  e88d120000               call       0x554010
00552d83  33f6                     xor        esi, esi
00552d85  8b8d84feffff             mov        ecx, dword ptr [ebp - 0x17c]
00552d8b  85c9                     test       ecx, ecx
00552d8d  7439                     je         0x552dc8
00552d8f  8b8588feffff             mov        eax, dword ptr [ebp - 0x178]
00552d95  2bc1                     sub        eax, ecx
00552d97  c1f803                   sar        eax, 3
00552d9a  3bc6                     cmp        eax, esi
00552d9c  762a                     jbe        0x552dc8
00552d9e  8d14f1                   lea        edx, [ecx + esi*8]
00552da1  8b4f04                   mov        ecx, dword ptr [edi + 4]
00552da4  85c9                     test       ecx, ecx
00552da6  0f84b9040000             je         0x553265
00552dac  8b4708                   mov        eax, dword ptr [edi + 8]
00552daf  2bc1                     sub        eax, ecx
00552db1  c1f803                   sar        eax, 3
00552db4  3bc6                     cmp        eax, esi
00552db6  0f86a9040000             jbe        0x553265
00552dbc  52                       push       edx
00552dbd  8d0cf1                   lea        ecx, [ecx + esi*8]
00552dc0  e8eb17ebff               call       0x4045b0
00552dc5  46                       inc        esi
00552dc6  ebbd                     jmp        0x552d85
00552dc8  8b7df0                   mov        edi, dword ptr [ebp - 0x10]
00552dcb  8d8590feffff             lea        eax, [ebp - 0x170]
00552dd1  50                       push       eax
00552dd2  8d8f10020000             lea        ecx, [edi + 0x210]
00552dd8  e8d317ebff               call       0x4045b0
00552ddd  8d8d98feffff             lea        ecx, [ebp - 0x168]
00552de3  51                       push       ecx
00552de4  8d8f18020000             lea        ecx, [edi + 0x218]
00552dea  e8c117ebff               call       0x4045b0
00552def  8d9da8feffff             lea        ebx, [ebp - 0x158]
00552df5  8db5a0feffff             lea        esi, [ebp - 0x160]
00552dfb  81c720020000             add        edi, 0x220
00552e01  c7450c02000000           mov        dword ptr [ebp + 0xc], 2
00552e08  8bce                     mov        ecx, esi
00552e0a  e8e1025000               call       0xa530f0
00552e0f  8bcb                     mov        ecx, ebx
00552e11  894508                   mov        dword ptr [ebp + 8], eax
00552e14  e847f2eaff               call       0x402060
00552e19  8b0dd8300001             mov        ecx, dword ptr [0x10030d8]
00552e1f  8b11                     mov        edx, dword ptr [ecx]
00552e21  50                       push       eax
00552e22  8b4508                   mov        eax, dword ptr [ebp + 8]
00552e25  50                       push       eax
00552e26  ff5210                   call       dword ptr [edx + 0x10]
00552e29  8bc8                     mov        ecx, eax
00552e2b  e8a0f55900               call       0xaf23d0
00552e30  8907                     mov        dword ptr [edi], eax
00552e32  8b450c                   mov        eax, dword ptr [ebp + 0xc]
00552e35  83c604                   add        esi, 4
00552e38  83c704                   add        edi, 4
00552e3b  83c308                   add        ebx, 8
00552e3e  48                       dec        eax
00552e3f  89450c                   mov        dword ptr [ebp + 0xc], eax
00552e42  75c4                     jne        0x552e08
00552e44  8a45ef                   mov        al, byte ptr [ebp - 0x11]
00552e47  84c0                     test       al, al
00552e49  0f8431020000             je         0x553080
00552e4f  8b8dc0feffff             mov        ecx, dword ptr [ebp - 0x140]
00552e55  2b8dbcfeffff             sub        ecx, dword ptr [ebp - 0x144]
00552e5b  b8abaaaa2a               mov        eax, 0x2aaaaaab
00552e60  f7e9                     imul       ecx
00552e62  c1fa02                   sar        edx, 2
00552e65  8bca                     mov        ecx, edx
00552e67  c1e91f                   shr        ecx, 0x1f
00552e6a  03ca                     add        ecx, edx
00552e6c  0f840e020000             je         0x553080
00552e72  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
00552e75  8d95b8feffff             lea        edx, [ebp - 0x148]
00552e7b  8d8ea8030000             lea        ecx, [esi + 0x3a8]
00552e81  52                       push       edx
00552e82  e849520000               call       0x5580d0
00552e87  8b86ac030000             mov        eax, dword ptr [esi + 0x3ac]
00552e8d  8b7804                   mov        edi, dword ptr [eax + 4]
00552e90  8b4008                   mov        eax, dword ptr [eax + 8]
00552e93  3bf8                     cmp        edi, eax
00552e95  8b1d28f04001             mov        ebx, dword ptr [0x140f028]
00552e9b  c6450f00                 mov        byte ptr [ebp + 0xf], 0
00552e9f  0f8478010000             je         0x55301d
00552ea5  8a450f                   mov        al, byte ptr [ebp + 0xf]
00552ea8  84c0                     test       al, al
00552eaa  754f                     jne        0x552efb
00552eac  8b4704                   mov        eax, dword ptr [edi + 4]
00552eaf  8b4f08                   mov        ecx, dword ptr [edi + 8]
00552eb2  8bd0                     mov        edx, eax
00552eb4  3bd1                     cmp        edx, ecx
00552eb6  740e                     je         0x552ec6
00552eb8  833a02                   cmp        dword ptr [edx], 2
00552ebb  7407                     je         0x552ec4
00552ebd  83c204                   add        edx, 4
00552ec0  3bd1                     cmp        edx, ecx
00552ec2  75f4                     jne        0x552eb8
00552ec4  3bd1                     cmp        edx, ecx
00552ec6  0f95c2                   setne      dl
00552ec9  3bc1                     cmp        eax, ecx
00552ecb  7411                     je         0x552ede
00552ecd  8d4900                   lea        ecx, [ecx]
00552ed0  833803                   cmp        dword ptr [eax], 3
00552ed3  7407                     je         0x552edc
00552ed5  83c004                   add        eax, 4
00552ed8  3bc1                     cmp        eax, ecx
00552eda  75f4                     jne        0x552ed0
00552edc  3bc1                     cmp        eax, ecx
00552ede  0f95c0                   setne      al
00552ee1  84d2                     test       dl, dl
00552ee3  750a                     jne        0x552eef
00552ee5  84c0                     test       al, al
00552ee7  0f8416010000             je         0x553003
00552eed  eb08                     jmp        0x552ef7
00552eef  84c0                     test       al, al
00552ef1  0f850c010000             jne        0x553003
00552ef7  c6450f01                 mov        byte ptr [ebp + 0xf], 1
00552efb  8b4708                   mov        eax, dword ptr [edi + 8]
00552efe  8b5704                   mov        edx, dword ptr [edi + 4]
00552f01  8bc8                     mov        ecx, eax
00552f03  2bca                     sub        ecx, edx
00552f05  c1f902                   sar        ecx, 2
00552f08  33f6                     xor        esi, esi
00552f0a  85c9                     test       ecx, ecx
00552f0c  0f86f1000000             jbe        0x553003
00552f12  2b4704                   sub        eax, dword ptr [edi + 4]
00552f15  c1f802                   sar        eax, 2
00552f18  3bf0                     cmp        esi, eax
00552f1a  7222                     jb         0x552f3e
00552f1c  50                       push       eax
00552f1d  56                       push       esi
00552f1e  6830cbcd00               push       0xcdcb30
00552f23  68a0b3cb00               push       0xcbb3a0
00552f28  ff15bc2eff00             call       dword ptr [0xff2ebc]
00552f2e  83c410                   add        esp, 0x10
00552f31  6a00                     push       0
00552f33  6a00                     push       0
00552f35  6a00                     push       0
00552f37  688c0000c0               push       0xc000008c
00552f3c  ffd3                     call       ebx
00552f3e  8b4f04                   mov        ecx, dword ptr [edi + 4]
00552f41  833cb102                 cmp        dword ptr [ecx + esi*4], 2
00552f45  8b4708                   mov        eax, dword ptr [edi + 8]
00552f48  7537                     jne        0x552f81
00552f4a  2bc1                     sub        eax, ecx
00552f4c  c1f802                   sar        eax, 2
00552f4f  3bf0                     cmp        esi, eax
00552f51  7222                     jb         0x552f75
00552f53  50                       push       eax
00552f54  56                       push       esi
00552f55  6830cbcd00               push       0xcdcb30
00552f5a  68a0b3cb00               push       0xcbb3a0
00552f5f  ff15bc2eff00             call       dword ptr [0xff2ebc]
00552f65  83c410                   add        esp, 0x10
00552f68  6a00                     push       0
00552f6a  6a00                     push       0
00552f6c  6a00                     push       0
00552f6e  688c0000c0               push       0xc000008c
00552f73  ffd3                     call       ebx
00552f75  8b4704                   mov        eax, dword ptr [edi + 4]
00552f78  c704b003000000           mov        dword ptr [eax + esi*4], 3
00552f7f  eb6c                     jmp        0x552fed
00552f81  2bc1                     sub        eax, ecx
00552f83  c1f802                   sar        eax, 2
00552f86  3bf0                     cmp        esi, eax
00552f88  7222                     jb         0x552fac
00552f8a  50                       push       eax
00552f8b  56                       push       esi
00552f8c  6830cbcd00               push       0xcdcb30
00552f91  68a0b3cb00               push       0xcbb3a0
00552f96  ff15bc2eff00             call       dword ptr [0xff2ebc]
00552f9c  83c410                   add        esp, 0x10
00552f9f  6a00                     push       0
00552fa1  6a00                     push       0
00552fa3  6a00                     push       0
00552fa5  688c0000c0               push       0xc000008c
00552faa  ffd3                     call       ebx
00552fac  8b4f04                   mov        ecx, dword ptr [edi + 4]
00552faf  833cb103                 cmp        dword ptr [ecx + esi*4], 3
00552fb3  7538                     jne        0x552fed
00552fb5  8b4708                   mov        eax, dword ptr [edi + 8]
00552fb8  2bc1                     sub        eax, ecx
00552fba  c1f802                   sar        eax, 2
00552fbd  3bf0                     cmp        esi, eax
00552fbf  7222                     jb         0x552fe3
00552fc1  50                       push       eax
00552fc2  56                       push       esi
00552fc3  6830cbcd00               push       0xcdcb30
00552fc8  68a0b3cb00               push       0xcbb3a0
00552fcd  ff15bc2eff00             call       dword ptr [0xff2ebc]
00552fd3  83c410                   add        esp, 0x10
00552fd6  6a00                     push       0
00552fd8  6a00                     push       0
00552fda  6a00                     push       0
00552fdc  688c0000c0               push       0xc000008c
00552fe1  ffd3                     call       ebx
00552fe3  8b4704                   mov        eax, dword ptr [edi + 4]
00552fe6  c704b002000000           mov        dword ptr [eax + esi*4], 2
00552fed  8b4708                   mov        eax, dword ptr [edi + 8]
00552ff0  8b4f04                   mov        ecx, dword ptr [edi + 4]
00552ff3  8bd0                     mov        edx, eax
00552ff5  2bd1                     sub        edx, ecx
00552ff7  46                       inc        esi
00552ff8  c1fa02                   sar        edx, 2
00552ffb  3bf2                     cmp        esi, edx
00552ffd  0f820fffffff             jb         0x552f12
00553003  8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00553006  8b80ac030000             mov        eax, dword ptr [eax + 0x3ac]
0055300c  8b4808                   mov        ecx, dword ptr [eax + 8]
0055300f  83c718                   add        edi, 0x18
00553012  3bf9                     cmp        edi, ecx
00553014  0f858bfeffff             jne        0x552ea5
0055301a  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
0055301d  8a450f                   mov        al, byte ptr [ebp + 0xf]
00553020  84c0                     test       al, al
00553022  8bbeac030000             mov        edi, dword ptr [esi + 0x3ac]
00553028  0f8509010000             jne        0x553137
0055302e  8b4714                   mov        eax, dword ptr [edi + 0x14]
00553031  8b4f18                   mov        ecx, dword ptr [edi + 0x18]
00553034  8bd0                     mov        edx, eax
00553036  3bd1                     cmp        edx, ecx
00553038  7414                     je         0x55304e
0055303a  8d9b00000000             lea        ebx, [ebx]
00553040  833a02                   cmp        dword ptr [edx], 2
00553043  7407                     je         0x55304c
00553045  83c204                   add        edx, 4
00553048  3bd1                     cmp        edx, ecx
0055304a  75f4                     jne        0x553040
0055304c  3bd1                     cmp        edx, ecx
0055304e  0f95c2                   setne      dl
00553051  3bc1                     cmp        eax, ecx
00553053  740e                     je         0x553063
00553055  833803                   cmp        dword ptr [eax], 3
00553058  7407                     je         0x553061
0055305a  83c004                   add        eax, 4
0055305d  3bc1                     cmp        eax, ecx
0055305f  75f4                     jne        0x553055
00553061  3bc1                     cmp        eax, ecx
00553063  0f95c0                   setne      al
00553066  84d2                     test       dl, dl
00553068  0f85bd000000             jne        0x55312b
0055306e  84c0                     test       al, al
00553070  0f85bd000000             jne        0x553133
00553076  8b45f0                   mov        eax, dword ptr [ebp - 0x10]
00553079  c680e003000000           mov        byte ptr [eax + 0x3e0], 0
00553080  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
00553083  8d95e4feffff             lea        edx, [ebp - 0x11c]
00553089  8d8b28020000             lea        ecx, [ebx + 0x228]
0055308f  52                       push       edx
00553090  e8fb035000               call       0xa53490
00553095  8b85ecfeffff             mov        eax, dword ptr [ebp - 0x114]
0055309b  85c0                     test       eax, eax
0055309d  0f84c9010000             je         0x55326c
005530a3  8bb5f0feffff             mov        esi, dword ptr [ebp - 0x110]
005530a9  2bf0                     sub        esi, eax
005530ab  c1fe03                   sar        esi, 3
005530ae  85f6                     test       esi, esi
005530b0  0f84b6010000             je         0x55326c
005530b6  83ec08                   sub        esp, 8
005530b9  8bcc                     mov        ecx, esp
005530bb  89650c                   mov        dword ptr [ebp + 0xc], esp
005530be  e81d14ebff               call       0x4044e0
005530c3  8dbb2c020000             lea        edi, [ebx + 0x22c]
005530c9  56                       push       esi
005530ca  8bcf                     mov        ecx, edi
005530cc  e83f0f0000               call       0x554010
005530d1  33f6                     xor        esi, esi
005530d3  eb0b                     jmp        0x5530e0
005530d5  8da42400000000           lea        esp, [esp]
005530dc  8d642400                 lea        esp, [esp]
005530e0  8b8decfeffff             mov        ecx, dword ptr [ebp - 0x114]
005530e6  85c9                     test       ecx, ecx
005530e8  0f847e010000             je         0x55326c
005530ee  8b85f0feffff             mov        eax, dword ptr [ebp - 0x110]
005530f4  2bc1                     sub        eax, ecx
005530f6  c1f803                   sar        eax, 3
005530f9  3bc6                     cmp        eax, esi
005530fb  0f866b010000             jbe        0x55326c
00553101  8d14f1                   lea        edx, [ecx + esi*8]
00553104  8b4f04                   mov        ecx, dword ptr [edi + 4]
00553107  85c9                     test       ecx, ecx
00553109  0f8456010000             je         0x553265
0055310f  8b4708                   mov        eax, dword ptr [edi + 8]
00553112  2bc1                     sub        eax, ecx
00553114  c1f803                   sar        eax, 3
00553117  3bc6                     cmp        eax, esi
00553119  0f8646010000             jbe        0x553265
0055311f  52                       push       edx
00553120  8d0cf1                   lea        ecx, [ecx + esi*8]
00553123  e88814ebff               call       0x4045b0
00553128  46                       inc        esi
00553129  ebb5                     jmp        0x5530e0
0055312b  84c0                     test       al, al
0055312d  0f8543ffffff             jne        0x553076
00553133  c6450f01                 mov        byte ptr [ebp + 0xf], 1
00553137  8b4718                   mov        eax, dword ptr [edi + 0x18]
0055313a  2b4714                   sub        eax, dword ptr [edi + 0x14]
0055313d  c1f802                   sar        eax, 2
00553140  33f6                     xor        esi, esi
00553142  85c0                     test       eax, eax
00553144  0f86e4000000             jbe        0x55322e
0055314a  3bf0                     cmp        esi, eax
0055314c  721f                     jb         0x55316d
0055314e  50                       push       eax
0055314f  56                       push       esi
00553150  6830cbcd00               push       0xcdcb30
00553155  68a0b3cb00               push       0xcbb3a0
0055315a  ff15bc2eff00             call       dword ptr [0xff2ebc]
00553160  83c410                   add        esp, 0x10
00553163  56                       push       esi
00553164  56                       push       esi
00553165  56                       push       esi
00553166  688c0000c0               push       0xc000008c
0055316b  ffd3                     call       ebx
0055316d  8b4f14                   mov        ecx, dword ptr [edi + 0x14]
00553170  833cb102                 cmp        dword ptr [ecx + esi*4], 2
00553174  8b4718                   mov        eax, dword ptr [edi + 0x18]
00553177  7537                     jne        0x5531b0
00553179  2bc1                     sub        eax, ecx
0055317b  c1f802                   sar        eax, 2
0055317e  3bf0                     cmp        esi, eax
00553180  7222                     jb         0x5531a4
00553182  50                       push       eax
00553183  56                       push       esi
00553184  6830cbcd00               push       0xcdcb30
00553189  68a0b3cb00               push       0xcbb3a0
0055318e  ff15bc2eff00             call       dword ptr [0xff2ebc]
00553194  83c410                   add        esp, 0x10
00553197  6a00                     push       0
00553199  6a00                     push       0
0055319b  6a00                     push       0
0055319d  688c0000c0               push       0xc000008c
005531a2  ffd3                     call       ebx
005531a4  8b4714                   mov        eax, dword ptr [edi + 0x14]
005531a7  c704b003000000           mov        dword ptr [eax + esi*4], 3
005531ae  eb6c                     jmp        0x55321c
005531b0  2bc1                     sub        eax, ecx
005531b2  c1f802                   sar        eax, 2
005531b5  3bf0                     cmp        esi, eax
005531b7  7222                     jb         0x5531db
005531b9  50                       push       eax
005531ba  56                       push       esi
005531bb  6830cbcd00               push       0xcdcb30
005531c0  68a0b3cb00               push       0xcbb3a0
005531c5  ff15bc2eff00             call       dword ptr [0xff2ebc]
005531cb  83c410                   add        esp, 0x10
005531ce  6a00                     push       0
005531d0  6a00                     push       0
005531d2  6a00                     push       0
005531d4  688c0000c0               push       0xc000008c
005531d9  ffd3                     call       ebx
005531db  8b4f14                   mov        ecx, dword ptr [edi + 0x14]
005531de  833cb103                 cmp        dword ptr [ecx + esi*4], 3
005531e2  7538                     jne        0x55321c
005531e4  8b4718                   mov        eax, dword ptr [edi + 0x18]
005531e7  2bc1                     sub        eax, ecx
005531e9  c1f802                   sar        eax, 2
005531ec  3bf0                     cmp        esi, eax
005531ee  7222                     jb         0x553212
005531f0  50                       push       eax
005531f1  56                       push       esi
005531f2  6830cbcd00               push       0xcdcb30
005531f7  68a0b3cb00               push       0xcbb3a0
005531fc  ff15bc2eff00             call       dword ptr [0xff2ebc]
00553202  83c410                   add        esp, 0x10
00553205  6a00                     push       0
00553207  6a00                     push       0
00553209  6a00                     push       0
0055320b  688c0000c0               push       0xc000008c
00553210  ffd3                     call       ebx
00553212  8b4714                   mov        eax, dword ptr [edi + 0x14]
00553215  c704b002000000           mov        dword ptr [eax + esi*4], 2
0055321c  8b4718                   mov        eax, dword ptr [edi + 0x18]
0055321f  2b4714                   sub        eax, dword ptr [edi + 0x14]
00553222  46                       inc        esi
00553223  c1f802                   sar        eax, 2
00553226  3bf0                     cmp        esi, eax
00553228  0f823fffffff             jb         0x55316d
0055322e  8a450f                   mov        al, byte ptr [ebp + 0xf]
00553231  84c0                     test       al, al
00553233  0f843dfeffff             je         0x553076
00553239  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
0055323c  8b86ac030000             mov        eax, dword ptr [esi + 0x3ac]
00553242  8d8db8feffff             lea        ecx, [ebp - 0x148]
00553248  51                       push       ecx
00553249  50                       push       eax
0055324a  8d550c                   lea        edx, [ebp + 0xc]
0055324d  52                       push       edx
0055324e  8d8ea8030000             lea        ecx, [esi + 0x3a8]
00553254  e8074e0000               call       0x558060
00553259  c686e003000001           mov        byte ptr [esi + 0x3e0], 1
00553260  e91bfeffff               jmp        0x553080
00553265  8bcf                     mov        ecx, edi
00553267  e89470f1ff               call       0x46a300
0055326c  8b85fcfeffff             mov        eax, dword ptr [ebp - 0x104]
00553272  33f6                     xor        esi, esi
00553274  3bc6                     cmp        eax, esi
00553276  0f84c3010000             je         0x55343f
0055327c  8b9500ffffff             mov        edx, dword ptr [ebp - 0x100]
00553282  2bd0                     sub        edx, eax
00553284  c1fa04                   sar        edx, 4
00553287  3bd6                     cmp        edx, esi
00553289  0f84b0010000             je         0x55343f
0055328f  83ec10                   sub        esp, 0x10
00553292  8bc4                     mov        eax, esp
00553294  89650c                   mov        dword ptr [ebp + 0xc], esp
00553297  8d8b3c020000             lea        ecx, [ebx + 0x23c]
0055329d  52                       push       edx
0055329e  897004                   mov        dword ptr [eax + 4], esi
005532a1  897008                   mov        dword ptr [eax + 8], esi
005532a4  89700c                   mov        dword ptr [eax + 0xc], esi
005532a7  e8c4380000               call       0x556b70
005532ac  8b95fcfeffff             mov        edx, dword ptr [ebp - 0x104]
005532b2  33c0                     xor        eax, eax
005532b4  89450c                   mov        dword ptr [ebp + 0xc], eax
005532b7  897508                   mov        dword ptr [ebp + 8], esi
005532ba  8d9b00000000             lea        ebx, [ebx]
005532c0  85d2                     test       edx, edx
005532c2  0f8477010000             je         0x55343f
005532c8  8b8d00ffffff             mov        ecx, dword ptr [ebp - 0x100]
005532ce  2bca                     sub        ecx, edx
005532d0  c1f904                   sar        ecx, 4
005532d3  3bc8                     cmp        ecx, eax
005532d5  0f8664010000             jbe        0x55343f
005532db  8b4508                   mov        eax, dword ptr [ebp + 8]
005532de  8b740204                 mov        esi, dword ptr [edx + eax + 4]
005532e2  85f6                     test       esi, esi
005532e4  0f842c010000             je         0x553416
005532ea  8b440208                 mov        eax, dword ptr [edx + eax + 8]
005532ee  2bc6                     sub        eax, esi
005532f0  c1f803                   sar        eax, 3
005532f3  85c0                     test       eax, eax
005532f5  0f841b010000             je         0x553416
005532fb  8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
005532fe  3bcb                     cmp        ecx, ebx
00553300  0f8627010000             jbe        0x55342d
00553306  8b7d08                   mov        edi, dword ptr [ebp + 8]
00553309  8b443a04                 mov        eax, dword ptr [edx + edi + 4]
0055330d  85c0                     test       eax, eax
0055330f  7504                     jne        0x553315
00553311  33f6                     xor        esi, esi
00553313  eb09                     jmp        0x55331e
00553315  8b743a08                 mov        esi, dword ptr [edx + edi + 8]
00553319  2bf0                     sub        esi, eax
0055331b  c1fe03                   sar        esi, 3
0055331e  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
00553321  8b9140020000             mov        edx, dword ptr [ecx + 0x240]
00553327  81c13c020000             add        ecx, 0x23c
0055332d  85d2                     test       edx, edx
0055332f  0f8405010000             je         0x55343a
00553335  8b4108                   mov        eax, dword ptr [ecx + 8]
00553338  2bc2                     sub        eax, edx
0055333a  c1f804                   sar        eax, 4
0055333d  3bc3                     cmp        eax, ebx
0055333f  0f86f5000000             jbe        0x55343a
00553345  83ec08                   sub        esp, 8
00553348  8bcc                     mov        ecx, esp
0055334a  03fa                     add        edi, edx
0055334c  896510                   mov        dword ptr [ebp + 0x10], esp
0055334f  e88c11ebff               call       0x4044e0
00553354  56                       push       esi
00553355  8bcf                     mov        ecx, edi
00553357  e8b40c0000               call       0x554010
0055335c  33ff                     xor        edi, edi
0055335e  8bff                     mov        edi, edi
00553360  8b95fcfeffff             mov        edx, dword ptr [ebp - 0x104]
00553366  85d2                     test       edx, edx
00553368  0f84bf000000             je         0x55342d
0055336e  8bb500ffffff             mov        esi, dword ptr [ebp - 0x100]
00553374  2bf2                     sub        esi, edx
00553376  c1fe04                   sar        esi, 4
00553379  3bf3                     cmp        esi, ebx
0055337b  0f86ac000000             jbe        0x55342d
00553381  8b4d08                   mov        ecx, dword ptr [ebp + 8]
00553384  8b5c1104                 mov        ebx, dword ptr [ecx + edx + 4]
00553388  03ca                     add        ecx, edx
0055338a  85db                     test       ebx, ebx
0055338c  0f8484000000             je         0x553416
00553392  8b4108                   mov        eax, dword ptr [ecx + 8]
00553395  2bc3                     sub        eax, ebx
00553397  c1f803                   sar        eax, 3
0055339a  3bf8                     cmp        edi, eax
0055339c  7378                     jae        0x553416
0055339e  8b5d0c                   mov        ebx, dword ptr [ebp + 0xc]
005533a1  3bf3                     cmp        esi, ebx
005533a3  0f8684000000             jbe        0x55342d
005533a9  8b5104                   mov        edx, dword ptr [ecx + 4]
005533ac  85d2                     test       edx, edx
005533ae  0f84b3feffff             je         0x553267
005533b4  8b4108                   mov        eax, dword ptr [ecx + 8]
005533b7  2bc2                     sub        eax, edx
005533b9  c1f803                   sar        eax, 3
005533bc  3bc7                     cmp        eax, edi
005533be  0f86a3feffff             jbe        0x553267
005533c4  8d34fa                   lea        esi, [edx + edi*8]
005533c7  8b55f0                   mov        edx, dword ptr [ebp - 0x10]
005533ca  8b8240020000             mov        eax, dword ptr [edx + 0x240]
005533d0  81c23c020000             add        edx, 0x23c
005533d6  85c0                     test       eax, eax
005533d8  745e                     je         0x553438
005533da  8b4a08                   mov        ecx, dword ptr [edx + 8]
005533dd  2bc8                     sub        ecx, eax
005533df  c1f904                   sar        ecx, 4
005533e2  3bcb                     cmp        ecx, ebx
005533e4  7652                     jbe        0x553438
005533e6  8b5508                   mov        edx, dword ptr [ebp + 8]
005533e9  8d0c02                   lea        ecx, [edx + eax]
005533ec  8b5104                   mov        edx, dword ptr [ecx + 4]
005533ef  85d2                     test       edx, edx
005533f1  0f8470feffff             je         0x553267
005533f7  8b4108                   mov        eax, dword ptr [ecx + 8]
005533fa  2bc2                     sub        eax, edx
005533fc  c1f803                   sar        eax, 3
005533ff  3bc7                     cmp        eax, edi
00553401  0f8660feffff             jbe        0x553267
00553407  56                       push       esi
00553408  8d0cfa                   lea        ecx, [edx + edi*8]
0055340b  e8a011ebff               call       0x4045b0
00553410  47                       inc        edi
00553411  e94affffff               jmp        0x553360
00553416  8b4d0c                   mov        ecx, dword ptr [ebp + 0xc]
00553419  8b4508                   mov        eax, dword ptr [ebp + 8]
0055341c  41                       inc        ecx
0055341d  83c010                   add        eax, 0x10
00553420  894508                   mov        dword ptr [ebp + 8], eax
00553423  894d0c                   mov        dword ptr [ebp + 0xc], ecx
00553426  8bc1                     mov        eax, ecx
00553428  e993feffff               jmp        0x5532c0
0055342d  8d8df8feffff             lea        ecx, [ebp - 0x108]
00553433  e8680b0000               call       0x553fa0
00553438  8bca                     mov        ecx, edx
0055343a  e8610b0000               call       0x553fa0
0055343f  8b5df0                   mov        ebx, dword ptr [ebp - 0x10]
00553442  8d8554ffffff             lea        eax, [ebp - 0xac]
00553448  50                       push       eax
00553449  8d8b98020000             lea        ecx, [ebx + 0x298]
0055344f  e88c5eeeff               call       0x4392e0
00553454  8d8d08ffffff             lea        ecx, [ebp - 0xf8]
0055345a  51                       push       ecx
0055345b  8d8b4c020000             lea        ecx, [ebx + 0x24c]
00553461  e88a350000               call       0x5569f0
00553466  8d9518ffffff             lea        edx, [ebp - 0xe8]
0055346c  52                       push       edx
0055346d  8d8b5c020000             lea        ecx, [ebx + 0x25c]
00553473  e878350000               call       0x5569f0
00553478  8b8d2cffffff             mov        ecx, dword ptr [ebp - 0xd4]
0055347e  8b8528ffffff             mov        eax, dword ptr [ebp - 0xd8]
00553484  8a9530ffffff             mov        dl, byte ptr [ebp - 0xd0]
0055348a  898b70020000             mov        dword ptr [ebx + 0x270], ecx
00553490  8b8d48ffffff             mov        ecx, dword ptr [ebp - 0xb8]
00553496  89836c020000             mov        dword ptr [ebx + 0x26c], eax
0055349c  8a8544ffffff             mov        al, byte ptr [ebp - 0xbc]
005534a2  898b8c020000             mov        dword ptr [ebx + 0x28c], ecx
005534a8  8d8d34ffffff             lea        ecx, [ebp - 0xcc]
005534ae  889374020000             mov        byte ptr [ebx + 0x274], dl
005534b4  8b954cffffff             mov        edx, dword ptr [ebp - 0xb4]
005534ba  888388020000             mov        byte ptr [ebx + 0x288], al
005534c0  8b8550ffffff             mov        eax, dword ptr [ebp - 0xb0]
005534c6  51                       push       ecx
005534c7  8d8b78020000             lea        ecx, [ebx + 0x278]
005534cd  899390020000             mov        dword ptr [ebx + 0x290], edx
005534d3  898394020000             mov        dword ptr [ebx + 0x294], eax
005534d9  e83285f1ff               call       0x46ba10
005534de  8d9500feffff             lea        edx, [ebp - 0x200]
005534e4  52                       push       edx
005534e5  8d8b68010000             lea        ecx, [ebx + 0x168]
005534eb  e82085f1ff               call       0x46ba10
005534f0  83c320                   add        ebx, 0x20
005534f3  8bcb                     mov        ecx, ebx
005534f5  bf01000000               mov        edi, 1
005534fa  e861ebeaff               call       0x402060
005534ff  3bc7                     cmp        eax, edi
00553501  0f8c7f000000             jl         0x553586
00553507  8bcb                     mov        ecx, ebx
00553509  e852ebeaff               call       0x402060
0055350e  8bf0                     mov        esi, eax
00553510  8d4d8c                   lea        ecx, [ebp - 0x74]
00553513  4e                       dec        esi
00553514  e847ebeaff               call       0x402060
00553519  8d4d84                   lea        ecx, [ebp - 0x7c]
0055351c  89450c                   mov        dword ptr [ebp + 0xc], eax
0055351f  e83cebeaff               call       0x402060
00553524  db450c                   fild       dword ptr [ebp + 0xc]
00553527  894508                   mov        dword ptr [ebp + 8], eax
0055352a  56                       push       esi
0055352b  8d47ff                   lea        eax, [edi - 1]
0055352e  50                       push       eax
0055352f  83ec08                   sub        esp, 8
00553532  d95c2404                 fstp       dword ptr [esp + 4]
00553536  db4508                   fild       dword ptr [ebp + 8]
00553539  d91c24                   fstp       dword ptr [esp]
0055353c  e86f645b00               call       0xb099b0
00553541  83c410                   add        esp, 0x10
00553544  e8fbdf6a00               call       0xc01544
00553549  8d4d0c                   lea        ecx, [ebp + 0xc]
0055354c  51                       push       ecx
0055354d  8d4de4                   lea        ecx, [ebp - 0x1c]
00553550  89450c                   mov        dword ptr [ebp + 0xc], eax
00553553  e8f8ebeaff               call       0x402150
00553558  8b4df0                   mov        ecx, dword ptr [ebp - 0x10]
0055355b  8d55e4                   lea        edx, [ebp - 0x1c]
0055355e  52                       push       edx
0055355f  81c1d8020000             add        ecx, 0x2d8
00553565  c645fc07                 mov        byte ptr [ebp - 4], 7
00553569  e8429bf1ff               call       0x46d0b0
0055356e  8d4de4                   lea        ecx, [ebp - 0x1c]
00553571  c645fc00                 mov        byte ptr [ebp - 4], 0
00553575  e896eaeaff               call       0x402010
0055357a  8bcb                     mov        ecx, ebx
0055357c  47                       inc        edi
0055357d  e8deeaeaff               call       0x402060
00553582  3bf8                     cmp        edi, eax
00553584  7e81                     jle        0x553507
00553586  8b75f0                   mov        esi, dword ptr [ebp - 0x10]
00553589  8d4594                   lea        eax, [ebp - 0x6c]
0055358c  50                       push       eax
0055358d  8d8ee8020000             lea        ecx, [esi + 0x2e8]
00553593  e81810ebff               call       0x4045b0
00553598  8b559c                   mov        edx, dword ptr [ebp - 0x64]
0055359b  8b45a0                   mov        eax, dword ptr [ebp - 0x60]
0055359e  8d8ef0020000             lea        ecx, [esi + 0x2f0]
005535a4  8911                     mov        dword ptr [ecx], edx
005535a6  8b55a4                   mov        edx, dword ptr [ebp - 0x5c]
005535a9  894104                   mov        dword ptr [ecx + 4], eax
005535ac  8d45b0                   lea        eax, [ebp - 0x50]
005535af  895108                   mov        dword ptr [ecx + 8], edx
005535b2  50                       push       eax
005535b3  8d8e04030000             lea        ecx, [esi + 0x304]
005535b9  e8f20febff               call       0x4045b0
005535be  8d4db8                   lea        ecx, [ebp - 0x48]
005535c1  51                       push       ecx
005535c2  8d8e0c030000             lea        ecx, [esi + 0x30c]
005535c8  e8e30febff               call       0x4045b0
005535cd  8d8d90fcffff             lea        ecx, [ebp - 0x370]
005535d3  c745fcffffffff           mov        dword ptr [ebp - 4], 0xffffffff
005535da  e8412f0000               call       0x556520
