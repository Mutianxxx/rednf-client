008c1a30 55                       push      ebp
008c1a31 8bec                     mov       ebp, esp
008c1a33 6aff                     push      -1
008c1a35 68ad30c800               push      0xc830ad
008c1a3a 64a100000000             mov       eax, dword ptr fs:[0]
008c1a40 50                       push      eax
008c1a41 64892500000000           mov       dword ptr fs:[0], esp
008c1a48 81ec4c0b0000             sub       esp, 0xb4c
008c1a4e 53                       push      ebx
008c1a4f 56                       push      esi
008c1a50 57                       push      edi
008c1a51 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
008c1a54 8bf1                     mov       esi, ecx
008c1a56 8b06                     mov       eax, dword ptr [esi]
008c1a58 83c707                   add       edi, 7
008c1a5b 57                       push      edi
008c1a5c ff5048                   call      dword ptr [eax + 0x48]
008c1a5f 8b5d10                   mov       ebx, dword ptr [ebp + 0x10]
008c1a62 b994070c01               mov       ecx, 0x10c0794
008c1a67 83c3f9                   add       ebx, -7
008c1a6a e8f105b4ff               call      0x402060
008c1a6f 8d8d48ffffff             lea       ecx, [ebp - 0xb8]
008c1a75 51                       push      ecx
008c1a76 53                       push      ebx
008c1a77 57                       push      edi
008c1a78 898548ffffff             mov       dword ptr [ebp - 0xb8], eax
008c1a7e e82dc3feff               call      0x8addb0
008c1a83 53                       push      ebx
008c1a84 57                       push      edi
008c1a85 e836c61900               call      0xa5e0c0
008c1a8a 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
008c1a8d 8b4f03                   mov       ecx, dword ptr [edi + 3]
008c1a90 83c414                   add       esp, 0x14
008c1a93 3bc1                     cmp       eax, ecx
008c1a95 7424                     je        0x8c1abb
008c1a97 51                       push      ecx
008c1a98 50                       push      eax
008c1a99 53                       push      ebx
008c1a9a 68c013e300               push      0xe313c0
008c1a9f ff15bc2eff00             call      dword ptr [0xff2ebc]
008c1aa5 83c410                   add       esp, 0x10
008c1aa8 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1aab 64890d00000000           mov       dword ptr fs:[0], ecx
008c1ab2 5f                       pop       edi
008c1ab3 5e                       pop       esi
008c1ab4 5b                       pop       ebx
008c1ab5 8be5                     mov       esp, ebp
008c1ab7 5d                       pop       ebp
008c1ab8 c20c00                   ret       0xc
008c1abb 33d2                     xor       edx, edx
008c1abd 668b5701                 mov       dx, word ptr [edi + 1]
008c1ac1 52                       push      edx
008c1ac2 53                       push      ebx
008c1ac3 e8e84e0000               call      0x8c69b0
008c1ac8 0fb74701                 movzx     eax, word ptr [edi + 1]
008c1acc 83c408                   add       esp, 8
008c1acf 83f837                   cmp       eax, 0x37
008c1ad2 0f8778430000             ja        0x8c5e50
008c1ad8 ff2485645e8c00           jmp       dword ptr [eax*4 + 0x8c5e64]
008c1adf 8b06                     mov       eax, dword ptr [esi]
008c1ae1 8d4d0c                   lea       ecx, [ebp + 0xc]
008c1ae4 51                       push      ecx
008c1ae5 8bce                     mov       ecx, esi
008c1ae7 c7450c00000000           mov       dword ptr [ebp + 0xc], 0
008c1aee ff505c                   call      dword ptr [eax + 0x5c]
008c1af1 8b450c                   mov       eax, dword ptr [ebp + 0xc]
008c1af4 8b4e54                   mov       ecx, dword ptr [esi + 0x54]
008c1af7 8b11                     mov       edx, dword ptr [ecx]
008c1af9 50                       push      eax
008c1afa 8b4508                   mov       eax, dword ptr [ebp + 8]
008c1afd 50                       push      eax
008c1afe ff12                     call      dword ptr [edx]
008c1b00 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1b03 64890d00000000           mov       dword ptr fs:[0], ecx
008c1b0a 5f                       pop       edi
008c1b0b 5e                       pop       esi
008c1b0c 5b                       pop       ebx
008c1b0d 8be5                     mov       esp, ebp
008c1b0f 5d                       pop       ebp
008c1b10 c20c00                   ret       0xc
008c1b13 8b4e54                   mov       ecx, dword ptr [esi + 0x54]
008c1b16 8b4508                   mov       eax, dword ptr [ebp + 8]
008c1b19 8b11                     mov       edx, dword ptr [ecx]
008c1b1b 50                       push      eax
008c1b1c ff5204                   call      dword ptr [edx + 4]
008c1b1f 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1b22 64890d00000000           mov       dword ptr fs:[0], ecx
008c1b29 5f                       pop       edi
008c1b2a 5e                       pop       esi
008c1b2b 5b                       pop       ebx
008c1b2c 8be5                     mov       esp, ebp
008c1b2e 5d                       pop       ebp
008c1b2f c20c00                   ret       0xc
008c1b32 8b16                     mov       edx, dword ptr [esi]
008c1b34 8d450c                   lea       eax, [ebp + 0xc]
008c1b37 50                       push      eax
008c1b38 8bce                     mov       ecx, esi
008c1b3a c7450c00000000           mov       dword ptr [ebp + 0xc], 0
008c1b41 ff525c                   call      dword ptr [edx + 0x5c]
008c1b44 8b450c                   mov       eax, dword ptr [ebp + 0xc]
008c1b47 8b4e54                   mov       ecx, dword ptr [esi + 0x54]
008c1b4a 8b11                     mov       edx, dword ptr [ecx]
008c1b4c 50                       push      eax
008c1b4d 8b4508                   mov       eax, dword ptr [ebp + 8]
008c1b50 50                       push      eax
008c1b51 ff5208                   call      dword ptr [edx + 8]
008c1b54 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1b57 64890d00000000           mov       dword ptr fs:[0], ecx
008c1b5e 5f                       pop       edi
008c1b5f 5e                       pop       esi
008c1b60 5b                       pop       ebx
008c1b61 8be5                     mov       esp, ebp
008c1b63 5d                       pop       ebp
008c1b64 c20c00                   ret       0xc
008c1b67 8b4d08                   mov       ecx, dword ptr [ebp + 8]
008c1b6a 51                       push      ecx
008c1b6b 8b4e54                   mov       ecx, dword ptr [esi + 0x54]
008c1b6e e85d6a2c00               call      0xb885d0
008c1b73 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1b76 64890d00000000           mov       dword ptr fs:[0], ecx
008c1b7d 5f                       pop       edi
008c1b7e 5e                       pop       esi
008c1b7f 5b                       pop       ebx
008c1b80 8be5                     mov       esp, ebp
008c1b82 5d                       pop       ebp
008c1b83 c20c00                   ret       0xc
008c1b86 8b16                     mov       edx, dword ptr [esi]
008c1b88 8d450b                   lea       eax, [ebp + 0xb]
008c1b8b 50                       push      eax
008c1b8c 8bce                     mov       ecx, esi
008c1b8e c6450b00                 mov       byte ptr [ebp + 0xb], 0
008c1b92 ff5250                   call      dword ptr [edx + 0x50]
008c1b95 8b16                     mov       edx, dword ptr [esi]
008c1b97 8d450c                   lea       eax, [ebp + 0xc]
008c1b9a 50                       push      eax
008c1b9b 8bce                     mov       ecx, esi
008c1b9d ff5268                   call      dword ptr [edx + 0x68]
008c1ba0 8b450c                   mov       eax, dword ptr [ebp + 0xc]
008c1ba3 8b4e54                   mov       ecx, dword ptr [esi + 0x54]
008c1ba6 8b11                     mov       edx, dword ptr [ecx]
008c1ba8 50                       push      eax
008c1ba9 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1bad 50                       push      eax
008c1bae ff520c                   call      dword ptr [edx + 0xc]
008c1bb1 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1bb4 64890d00000000           mov       dword ptr fs:[0], ecx
008c1bbb 5f                       pop       edi
008c1bbc 5e                       pop       esi
008c1bbd 5b                       pop       ebx
008c1bbe 8be5                     mov       esp, ebp
008c1bc0 5d                       pop       ebp
008c1bc1 c20c00                   ret       0xc
008c1bc4 8b16                     mov       edx, dword ptr [esi]
008c1bc6 8d450c                   lea       eax, [ebp + 0xc]
008c1bc9 33db                     xor       ebx, ebx
008c1bcb 50                       push      eax
008c1bcc 8bce                     mov       ecx, esi
008c1bce 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c1bd1 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c1bd4 ff525c                   call      dword ptr [edx + 0x5c]
008c1bd7 8b16                     mov       edx, dword ptr [esi]
008c1bd9 8d450b                   lea       eax, [ebp + 0xb]
008c1bdc 50                       push      eax
008c1bdd 8bce                     mov       ecx, esi
008c1bdf ff5250                   call      dword ptr [edx + 0x50]
008c1be2 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1be6 8b4e54                   mov       ecx, dword ptr [esi + 0x54]
008c1be9 8b11                     mov       edx, dword ptr [ecx]
008c1beb 50                       push      eax
008c1bec 8b450c                   mov       eax, dword ptr [ebp + 0xc]
008c1bef 50                       push      eax
008c1bf0 ff5210                   call      dword ptr [edx + 0x10]
008c1bf3 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1bf6 64890d00000000           mov       dword ptr fs:[0], ecx
008c1bfd 5f                       pop       edi
008c1bfe 5e                       pop       esi
008c1bff 5b                       pop       ebx
008c1c00 8be5                     mov       esp, ebp
008c1c02 5d                       pop       ebp
008c1c03 c20c00                   ret       0xc
008c1c06 8b16                     mov       edx, dword ptr [esi]
008c1c08 8d450b                   lea       eax, [ebp + 0xb]
008c1c0b 33db                     xor       ebx, ebx
008c1c0d 50                       push      eax
008c1c0e 8bce                     mov       ecx, esi
008c1c10 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c1c13 885d13                   mov       byte ptr [ebp + 0x13], bl
008c1c16 ff5250                   call      dword ptr [edx + 0x50]
008c1c19 8b16                     mov       edx, dword ptr [esi]
008c1c1b 8d4513                   lea       eax, [ebp + 0x13]
008c1c1e 50                       push      eax
008c1c1f 8bce                     mov       ecx, esi
008c1c21 ff5250                   call      dword ptr [edx + 0x50]
008c1c24 8b16                     mov       edx, dword ptr [esi]
008c1c26 8d450f                   lea       eax, [ebp + 0xf]
008c1c29 50                       push      eax
008c1c2a 8bce                     mov       ecx, esi
008c1c2c 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c1c2f ff5250                   call      dword ptr [edx + 0x50]
008c1c32 0fb64d0f                 movzx     ecx, byte ptr [ebp + 0xf]
008c1c36 0fb65513                 movzx     edx, byte ptr [ebp + 0x13]
008c1c3a 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1c3e 51                       push      ecx
008c1c3f 52                       push      edx
008c1c40 50                       push      eax
008c1c41 689413e300               push      0xe31394
008c1c46 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c1c4c 8a4513                   mov       al, byte ptr [ebp + 0x13]
008c1c4f 83c410                   add       esp, 0x10
008c1c52 3ac3                     cmp       al, bl
008c1c54 7534                     jne       0x8c1c8a
008c1c56 0fb64d0f                 movzx     ecx, byte ptr [ebp + 0xf]
008c1c5a 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1c5e 51                       push      ecx
008c1c5f 6a01                     push      1
008c1c61 52                       push      edx
008c1c62 8bce                     mov       ecx, esi
008c1c64 e837cfffff               call      0x8beba0
008c1c69 0fb6450f                 movzx     eax, byte ptr [ebp + 0xf]
008c1c6d 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1c71 50                       push      eax
008c1c72 51                       push      ecx
008c1c73 8bce                     mov       ecx, esi
008c1c75 e8565dbfff               call      0x4b79d0
008c1c7a 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1c7e 50                       push      eax
008c1c7f 52                       push      edx
008c1c80 684813e300               push      0xe31348
008c1c85 e9e8000000               jmp       0x8c1d72
008c1c8a 3c01                     cmp       al, 1
008c1c8c 0f8508010000             jne       0x8c1d9a
008c1c92 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1c96 51                       push      ecx
008c1c97 8bce                     mov       ecx, esi
008c1c99 e8325dbfff               call      0x4b79d0
008c1c9e 85c0                     test      eax, eax
008c1ca0 7520                     jne       0x8c1cc2
008c1ca2 0fb67d0b                 movzx     edi, byte ptr [ebp + 0xb]
008c1ca6 e8d51d2c00               call      0xb83a80
008c1cab 8b4020                   mov       eax, dword ptr [eax + 0x20]
008c1cae 57                       push      edi
008c1caf 8bc8                     mov       ecx, eax
008c1cb1 e87a462c00               call      0xb86330
008c1cb6 0fb6550f                 movzx     edx, byte ptr [ebp + 0xf]
008c1cba 3bc2                     cmp       eax, edx
008c1cbc 0f8e8e410000             jle       0x8c5e50
008c1cc2 807d0f02                 cmp       byte ptr [ebp + 0xf], 2
008c1cc6 740b                     je        0x8c1cd3
008c1cc8 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1ccc 889c3008a61000           mov       byte ptr [eax + esi + 0x10a608], bl
008c1cd3 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1cd7 0fb67d0f                 movzx     edi, byte ptr [ebp + 0xf]
008c1cdb 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c1cde e89d1d2c00               call      0xb83a80
008c1ce3 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
008c1ce6 8b4820                   mov       ecx, dword ptr [eax + 0x20]
008c1ce9 57                       push      edi
008c1cea 52                       push      edx
008c1ceb e800462c00               call      0xb862f0
008c1cf0 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1cf4 6a01                     push      1
008c1cf6 53                       push      ebx
008c1cf7 50                       push      eax
008c1cf8 8bce                     mov       ecx, esi
008c1cfa e841e6ffff               call      0x8c0340
008c1cff 807d0f02                 cmp       byte ptr [ebp + 0xf], 2
008c1d03 750e                     jne       0x8c1d13
008c1d05 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1d09 c6843178a7100001         mov       byte ptr [ecx + esi + 0x10a778], 1
008c1d11 eb0b                     jmp       0x8c1d1e
008c1d13 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1d17 889c3278a71000           mov       byte ptr [edx + esi + 0x10a778], bl
008c1d1e 8b0d48280001             mov       ecx, dword ptr [0x1002848]
008c1d24 81c140100000             add       ecx, 0x1040
008c1d2a e83103b4ff               call      0x402060
008c1d2f 83f809                   cmp       eax, 9
008c1d32 7513                     jne       0x8c1d47
008c1d34 0fb6450f                 movzx     eax, byte ptr [ebp + 0xf]
008c1d38 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1d3c 50                       push      eax
008c1d3d 6a02                     push      2
008c1d3f 51                       push      ecx
008c1d40 8bce                     mov       ecx, esi
008c1d42 e859ceffff               call      0x8beba0
008c1d47 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1d4b 6a01                     push      1
008c1d4d 52                       push      edx
008c1d4e e82d5ebfff               call      0x4b7b80
008c1d53 0fb6450f                 movzx     eax, byte ptr [ebp + 0xf]
008c1d57 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1d5b 83c408                   add       esp, 8
008c1d5e 50                       push      eax
008c1d5f 51                       push      ecx
008c1d60 8bce                     mov       ecx, esi
008c1d62 e8695cbfff               call      0x4b79d0
008c1d67 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1d6b 50                       push      eax
008c1d6c 52                       push      edx
008c1d6d 68f812e300               push      0xe312f8
008c1d72 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c1d78 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1d7c 83c410                   add       esp, 0x10
008c1d7f c68430cfa0100001         mov       byte ptr [eax + esi + 0x10a0cf], 1
008c1d87 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1d8a 64890d00000000           mov       dword ptr fs:[0], ecx
008c1d91 5f                       pop       edi
008c1d92 5e                       pop       esi
008c1d93 5b                       pop       ebx
008c1d94 8be5                     mov       esp, ebp
008c1d96 5d                       pop       ebp
008c1d97 c20c00                   ret       0xc
008c1d9a 3c02                     cmp       al, 2
008c1d9c 0f85ae400000             jne       0x8c5e50
008c1da2 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1da6 389c30cfa01000           cmp       byte ptr [eax + esi + 0x10a0cf], bl
008c1dad 0f849d400000             je        0x8c5e50
008c1db3 50                       push      eax
008c1db4 8bce                     mov       ecx, esi
008c1db6 e8155cbfff               call      0x4b79d0
008c1dbb 85c0                     test      eax, eax
008c1dbd 7520                     jne       0x8c1ddf
008c1dbf 0fb67d0b                 movzx     edi, byte ptr [ebp + 0xb]
008c1dc3 e8b81c2c00               call      0xb83a80
008c1dc8 8b4020                   mov       eax, dword ptr [eax + 0x20]
008c1dcb 57                       push      edi
008c1dcc 8bc8                     mov       ecx, eax
008c1dce e85d452c00               call      0xb86330
008c1dd3 0fb64d0f                 movzx     ecx, byte ptr [ebp + 0xf]
008c1dd7 3bc1                     cmp       eax, ecx
008c1dd9 0f8e71400000             jle       0x8c5e50
008c1ddf 807d0f02                 cmp       byte ptr [ebp + 0xf], 2
008c1de3 750e                     jne       0x8c1df3
008c1de5 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1de9 c6843278a7100001         mov       byte ptr [edx + esi + 0x10a778], 1
008c1df1 eb0b                     jmp       0x8c1dfe
008c1df3 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1df7 889c3078a71000           mov       byte ptr [eax + esi + 0x10a778], bl
008c1dfe 8a450f                   mov       al, byte ptr [ebp + 0xf]
008c1e01 3c02                     cmp       al, 2
008c1e03 754b                     jne       0x8c1e50
008c1e05 0fb67d0b                 movzx     edi, byte ptr [ebp + 0xb]
008c1e09 e8721c2c00               call      0xb83a80
008c1e0e 8b4020                   mov       eax, dword ptr [eax + 0x20]
008c1e11 57                       push      edi
008c1e12 8bc8                     mov       ecx, eax
008c1e14 e817452c00               call      0xb86330
008c1e19 83f8ff                   cmp       eax, -1
008c1e1c 0f85a5000000             jne       0x8c1ec7
008c1e22 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1e26 0fb67d0f                 movzx     edi, byte ptr [ebp + 0xf]
008c1e2a 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c1e2d e84e1c2c00               call      0xb83a80
008c1e32 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
008c1e35 8b4820                   mov       ecx, dword ptr [eax + 0x20]
008c1e38 57                       push      edi
008c1e39 52                       push      edx
008c1e3a e8b1442c00               call      0xb862f0
008c1e3f 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1e43 6a01                     push      1
008c1e45 53                       push      ebx
008c1e46 50                       push      eax
008c1e47 8bce                     mov       ecx, esi
008c1e49 e8f2e4ffff               call      0x8c0340
008c1e4e eb77                     jmp       0x8c1ec7
008c1e50 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1e54 0fb6f8                   movzx     edi, al
008c1e57 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c1e5a e8211c2c00               call      0xb83a80
008c1e5f 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
008c1e62 8b4820                   mov       ecx, dword ptr [eax + 0x20]
008c1e65 57                       push      edi
008c1e66 52                       push      edx
008c1e67 e884442c00               call      0xb862f0
008c1e6c 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1e70 50                       push      eax
008c1e71 8bce                     mov       ecx, esi
008c1e73 e8585bbfff               call      0x4b79d0
008c1e78 85c0                     test      eax, eax
008c1e7a 7531                     jne       0x8c1ead
008c1e7c 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1e80 8d0431                   lea       eax, [ecx + esi]
008c1e83 389808a61000             cmp       byte ptr [eax + 0x10a608], bl
008c1e89 7422                     je        0x8c1ead
008c1e8b 8898cca51000             mov       byte ptr [eax + 0x10a5cc], bl
008c1e91 33c0                     xor       eax, eax
008c1e93 389c06cca51000           cmp       byte ptr [esi + eax + 0x10a5cc], bl
008c1e9a 7511                     jne       0x8c1ead
008c1e9c 40                       inc       eax
008c1e9d 83f808                   cmp       eax, 8
008c1ea0 7cf1                     jl        0x8c1e93
008c1ea2 8b8ed4a51000             mov       ecx, dword ptr [esi + 0x10a5d4]
008c1ea8 e883282c00               call      0xb84730
008c1ead 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c1eb1 6a01                     push      1
008c1eb3 53                       push      ebx
008c1eb4 52                       push      edx
008c1eb5 8bce                     mov       ecx, esi
008c1eb7 e884e4ffff               call      0x8c0340
008c1ebc 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1ec0 889c3008a61000           mov       byte ptr [eax + esi + 0x10a608], bl
008c1ec7 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1ecb 6a01                     push      1
008c1ecd 51                       push      ecx
008c1ece e8ad5cbfff               call      0x4b7b80
008c1ed3 0fb6550f                 movzx     edx, byte ptr [ebp + 0xf]
008c1ed7 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c1edb 83c408                   add       esp, 8
008c1ede 52                       push      edx
008c1edf 50                       push      eax
008c1ee0 8bce                     mov       ecx, esi
008c1ee2 e8e95abfff               call      0x4b79d0
008c1ee7 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1eeb 50                       push      eax
008c1eec 51                       push      ecx
008c1eed 68a812e300               push      0xe312a8
008c1ef2 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c1ef8 83c410                   add       esp, 0x10
008c1efb 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1efe 64890d00000000           mov       dword ptr fs:[0], ecx
008c1f05 5f                       pop       edi
008c1f06 5e                       pop       esi
008c1f07 5b                       pop       ebx
008c1f08 8be5                     mov       esp, ebp
008c1f0a 5d                       pop       ebp
008c1f0b c20c00                   ret       0xc
008c1f0e 8b16                     mov       edx, dword ptr [esi]
008c1f10 33db                     xor       ebx, ebx
008c1f12 8d450b                   lea       eax, [ebp + 0xb]
008c1f15 50                       push      eax
008c1f16 8bce                     mov       ecx, esi
008c1f18 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c1f1b 885dd7                   mov       byte ptr [ebp - 0x29], bl
008c1f1e 885d13                   mov       byte ptr [ebp + 0x13], bl
008c1f21 ff5250                   call      dword ptr [edx + 0x50]
008c1f24 8b0d48280001             mov       ecx, dword ptr [0x1002848]
008c1f2a 8bb950100000             mov       edi, dword ptr [ecx + 0x1050]
008c1f30 8b16                     mov       edx, dword ptr [esi]
008c1f32 8d450f                   lea       eax, [ebp + 0xf]
008c1f35 50                       push      eax
008c1f36 8bce                     mov       ecx, esi
008c1f38 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c1f3b ff5250                   call      dword ptr [edx + 0x50]
008c1f3e 0fb6450f                 movzx     eax, byte ptr [ebp + 0xf]
008c1f42 89871c020000             mov       dword ptr [edi + 0x21c], eax
008c1f48 895d80                   mov       dword ptr [ebp - 0x80], ebx
008c1f4b 895d84                   mov       dword ptr [ebp - 0x7c], ebx
008c1f4e 895d88                   mov       dword ptr [ebp - 0x78], ebx
008c1f51 8bcf                     mov       ecx, edi
008c1f53 895dfc                   mov       dword ptr [ebp - 4], ebx
008c1f56 e8c5480000               call      0x8c6820
008c1f5b 385d0b                   cmp       byte ptr [ebp + 0xb], bl
008c1f5e 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c1f61 763f                     jbe       0x8c1fa2
008c1f63 8b16                     mov       edx, dword ptr [esi]
008c1f65 8d45e4                   lea       eax, [ebp - 0x1c]
008c1f68 50                       push      eax
008c1f69 8bce                     mov       ecx, esi
008c1f6b 895de4                   mov       dword ptr [ebp - 0x1c], ebx
008c1f6e ff5254                   call      dword ptr [edx + 0x54]
008c1f71 0fb74de4                 movzx     ecx, word ptr [ebp - 0x1c]
008c1f75 51                       push      ecx
008c1f76 8bcf                     mov       ecx, edi
008c1f78 e8439c1f00               call      0xabbbc0
008c1f7d 0fb755e4                 movzx     edx, word ptr [ebp - 0x1c]
008c1f81 8d45ec                   lea       eax, [ebp - 0x14]
008c1f84 50                       push      eax
008c1f85 8d8d7cffffff             lea       ecx, [ebp - 0x84]
008c1f8b 8955ec                   mov       dword ptr [ebp - 0x14], edx
008c1f8e e88d51b4ff               call      0x407120
008c1f93 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
008c1f96 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c1f9a 40                       inc       eax
008c1f9b 3bc1                     cmp       eax, ecx
008c1f9d 8945e8                   mov       dword ptr [ebp - 0x18], eax
008c1fa0 7cc1                     jl        0x8c1f63
008c1fa2 8b16                     mov       edx, dword ptr [esi]
008c1fa4 8d45d7                   lea       eax, [ebp - 0x29]
008c1fa7 50                       push      eax
008c1fa8 8bce                     mov       ecx, esi
008c1faa ff5250                   call      dword ptr [edx + 0x50]
008c1fad 8b16                     mov       edx, dword ptr [esi]
008c1faf 8d4513                   lea       eax, [ebp + 0x13]
008c1fb2 50                       push      eax
008c1fb3 8bce                     mov       ecx, esi
008c1fb5 ff5250                   call      dword ptr [edx + 0x50]
008c1fb8 0fb64d13                 movzx     ecx, byte ptr [ebp + 0x13]
008c1fbc 0fb655d7                 movzx     edx, byte ptr [ebp - 0x29]
008c1fc0 51                       push      ecx
008c1fc1 52                       push      edx
008c1fc2 8bcf                     mov       ecx, edi
008c1fc4 e8675d1f00               call      0xab7d30
008c1fc9 8bcf                     mov       ecx, edi
008c1fcb e8508c1f00               call      0xabac20
008c1fd0 8d8d7cffffff             lea       ecx, [ebp - 0x84]
008c1fd6 e8752dd8ff               call      0x644d50
008c1fdb 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c1fde 64890d00000000           mov       dword ptr fs:[0], ecx
008c1fe5 5f                       pop       edi
008c1fe6 5e                       pop       esi
008c1fe7 5b                       pop       ebx
008c1fe8 8be5                     mov       esp, ebp
008c1fea 5d                       pop       ebp
008c1feb c20c00                   ret       0xc
008c1fee 8b06                     mov       eax, dword ptr [esi]
008c1ff0 8d4d0f                   lea       ecx, [ebp + 0xf]
008c1ff3 33db                     xor       ebx, ebx
008c1ff5 51                       push      ecx
008c1ff6 8bce                     mov       ecx, esi
008c1ff8 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c1ffb 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c1ffe ff5050                   call      dword ptr [eax + 0x50]
008c2001 8b16                     mov       edx, dword ptr [esi]
008c2003 8d450b                   lea       eax, [ebp + 0xb]
008c2006 50                       push      eax
008c2007 8bce                     mov       ecx, esi
008c2009 ff5250                   call      dword ptr [edx + 0x50]
008c200c 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c2010 0fb6550f                 movzx     edx, byte ptr [ebp + 0xf]
008c2014 a148280001               mov       eax, dword ptr [0x1002848]
008c2019 51                       push      ecx
008c201a 8b8850100000             mov       ecx, dword ptr [eax + 0x1050]
008c2020 52                       push      edx
008c2021 e80a5d1f00               call      0xab7d30
008c2026 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2029 64890d00000000           mov       dword ptr fs:[0], ecx
008c2030 5f                       pop       edi
008c2031 5e                       pop       esi
008c2032 5b                       pop       ebx
008c2033 8be5                     mov       esp, ebp
008c2035 5d                       pop       ebp
008c2036 c20c00                   ret       0xc
008c2039 8b16                     mov       edx, dword ptr [esi]
008c203b 33db                     xor       ebx, ebx
008c203d 8d450b                   lea       eax, [ebp + 0xb]
008c2040 50                       push      eax
008c2041 8bce                     mov       ecx, esi
008c2043 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c2046 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c2049 885d13                   mov       byte ptr [ebp + 0x13], bl
008c204c 895de0                   mov       dword ptr [ebp - 0x20], ebx
008c204f 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c2052 895dd0                   mov       dword ptr [ebp - 0x30], ebx
008c2055 895de4                   mov       dword ptr [ebp - 0x1c], ebx
008c2058 ff5250                   call      dword ptr [edx + 0x50]
008c205b 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c205f 3bc3                     cmp       eax, ebx
008c2061 0f86e93d0000             jbe       0x8c5e50
008c2067 8945dc                   mov       dword ptr [ebp - 0x24], eax
008c206a 8d9b00000000             lea       ebx, [ebx]
008c2070 8b16                     mov       edx, dword ptr [esi]
008c2072 8d45e0                   lea       eax, [ebp - 0x20]
008c2075 50                       push      eax
008c2076 8bce                     mov       ecx, esi
008c2078 ff5254                   call      dword ptr [edx + 0x54]
008c207b 8b16                     mov       edx, dword ptr [esi]
008c207d 8d45e8                   lea       eax, [ebp - 0x18]
008c2080 50                       push      eax
008c2081 8bce                     mov       ecx, esi
008c2083 ff5254                   call      dword ptr [edx + 0x54]
008c2086 8b16                     mov       edx, dword ptr [esi]
008c2088 8d45d0                   lea       eax, [ebp - 0x30]
008c208b 50                       push      eax
008c208c 8bce                     mov       ecx, esi
008c208e ff5254                   call      dword ptr [edx + 0x54]
008c2091 8b16                     mov       edx, dword ptr [esi]
008c2093 8d45e4                   lea       eax, [ebp - 0x1c]
008c2096 50                       push      eax
008c2097 8bce                     mov       ecx, esi
008c2099 ff5254                   call      dword ptr [edx + 0x54]
008c209c 8b16                     mov       edx, dword ptr [esi]
008c209e 8d450f                   lea       eax, [ebp + 0xf]
008c20a1 50                       push      eax
008c20a2 8bce                     mov       ecx, esi
008c20a4 ff5250                   call      dword ptr [edx + 0x50]
008c20a7 8b16                     mov       edx, dword ptr [esi]
008c20a9 8d4513                   lea       eax, [ebp + 0x13]
008c20ac 50                       push      eax
008c20ad 8bce                     mov       ecx, esi
008c20af ff5250                   call      dword ptr [edx + 0x50]
008c20b2 8b16                     mov       edx, dword ptr [esi]
008c20b4 8d45f0                   lea       eax, [ebp - 0x10]
008c20b7 50                       push      eax
008c20b8 8bce                     mov       ecx, esi
008c20ba ff525c                   call      dword ptr [edx + 0x5c]
008c20bd 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c20c3 3bc3                     cmp       eax, ebx
008c20c5 747f                     je        0x8c2146
008c20c7 8b88b0000000             mov       ecx, dword ptr [eax + 0xb0]
008c20cd 3bcb                     cmp       ecx, ebx
008c20cf 7475                     je        0x8c2146
008c20d1 0fb755e8                 movzx     edx, word ptr [ebp - 0x18]
008c20d5 0fb745e0                 movzx     eax, word ptr [ebp - 0x20]
008c20d9 52                       push      edx
008c20da 50                       push      eax
008c20db e84097c4ff               call      0x50b820
008c20e0 8bf8                     mov       edi, eax
008c20e2 3bfb                     cmp       edi, ebx
008c20e4 7460                     je        0x8c2146
008c20e6 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c20ec 0fb64d0f                 movzx     ecx, byte ptr [ebp + 0xf]
008c20f0 3b88b8000000             cmp       ecx, dword ptr [eax + 0xb8]
008c20f6 754e                     jne       0x8c2146
008c20f8 0fb65513                 movzx     edx, byte ptr [ebp + 0x13]
008c20fc 3b90bc000000             cmp       edx, dword ptr [eax + 0xbc]
008c2102 7542                     jne       0x8c2146
008c2104 8b07                     mov       eax, dword ptr [edi]
008c2106 8bcf                     mov       ecx, edi
008c2108 ff9060010000             call      dword ptr [eax + 0x160]
008c210e 3bc3                     cmp       eax, ebx
008c2110 8945ec                   mov       dword ptr [ebp - 0x14], eax
008c2113 741f                     je        0x8c2134
008c2115 8b10                     mov       edx, dword ptr [eax]
008c2117 8bc8                     mov       ecx, eax
008c2119 ff523c                   call      dword ptr [edx + 0x3c]
008c211c 0fb74dd0                 movzx     ecx, word ptr [ebp - 0x30]
008c2120 3bc1                     cmp       eax, ecx
008c2122 7522                     jne       0x8c2146
008c2124 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
008c2127 8b11                     mov       edx, dword ptr [ecx]
008c2129 ff5240                   call      dword ptr [edx + 0x40]
008c212c 0fb74de4                 movzx     ecx, word ptr [ebp - 0x1c]
008c2130 3bc1                     cmp       eax, ecx
008c2132 7512                     jne       0x8c2146
008c2134 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
008c2137 8b07                     mov       eax, dword ptr [edi]
008c2139 52                       push      edx
008c213a 8bcf                     mov       ecx, edi
008c213c ff5048                   call      dword ptr [eax + 0x48]
008c213f 8bc8                     mov       ecx, eax
008c2141 e80ae2c4ff               call      0x510350
008c2146 ff4ddc                   dec       dword ptr [ebp - 0x24]
008c2149 0f8521ffffff             jne       0x8c2070
008c214f 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2152 64890d00000000           mov       dword ptr fs:[0], ecx
008c2159 5f                       pop       edi
008c215a 5e                       pop       esi
008c215b 5b                       pop       ebx
008c215c 8be5                     mov       esp, ebp
008c215e 5d                       pop       ebp
008c215f c20c00                   ret       0xc
008c2162 33db                     xor       ebx, ebx
008c2164 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c2167 895de0                   mov       dword ptr [ebp - 0x20], ebx
008c216a 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c216d 895d98                   mov       dword ptr [ebp - 0x68], ebx
008c2170 895d9c                   mov       dword ptr [ebp - 0x64], ebx
008c2173 895da0                   mov       dword ptr [ebp - 0x60], ebx
008c2176 8b16                     mov       edx, dword ptr [esi]
008c2178 8d45e0                   lea       eax, [ebp - 0x20]
008c217b 50                       push      eax
008c217c 8bce                     mov       ecx, esi
008c217e c745fc01000000           mov       dword ptr [ebp - 4], 1
008c2185 ff5254                   call      dword ptr [edx + 0x54]
008c2188 8b16                     mov       edx, dword ptr [esi]
008c218a 8d45e8                   lea       eax, [ebp - 0x18]
008c218d 50                       push      eax
008c218e 8bce                     mov       ecx, esi
008c2190 ff5254                   call      dword ptr [edx + 0x54]
008c2193 8b16                     mov       edx, dword ptr [esi]
008c2195 8d450b                   lea       eax, [ebp + 0xb]
008c2198 50                       push      eax
008c2199 8bce                     mov       ecx, esi
008c219b ff5250                   call      dword ptr [edx + 0x50]
008c219e 8b16                     mov       edx, dword ptr [esi]
008c21a0 8d4510                   lea       eax, [ebp + 0x10]
008c21a3 50                       push      eax
008c21a4 8bce                     mov       ecx, esi
008c21a6 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c21a9 ff5254                   call      dword ptr [edx + 0x54]
008c21ac 899d50ffffff             mov       dword ptr [ebp - 0xb0], ebx
008c21b2 899d54ffffff             mov       dword ptr [ebp - 0xac], ebx
008c21b8 899d58ffffff             mov       dword ptr [ebp - 0xa8], ebx
008c21be 0fb74d10                 movzx     ecx, word ptr [ebp + 0x10]
008c21c2 51                       push      ecx
008c21c3 8d8d4cffffff             lea       ecx, [ebp - 0xb4]
008c21c9 c645fc02                 mov       byte ptr [ebp - 4], 2
008c21cd e8be400000               call      0x8c6290
008c21d2 33ff                     xor       edi, edi
008c21d4 66395d10                 cmp       word ptr [ebp + 0x10], bx
008c21d8 7629                     jbe       0x8c2203
008c21da 8d9b00000000             lea       ebx, [ebx]
008c21e0 8b16                     mov       edx, dword ptr [esi]
008c21e2 8d450f                   lea       eax, [ebp + 0xf]
008c21e5 50                       push      eax
008c21e6 8bce                     mov       ecx, esi
008c21e8 ff5250                   call      dword ptr [edx + 0x50]
008c21eb 8d4d0f                   lea       ecx, [ebp + 0xf]
008c21ee 51                       push      ecx
008c21ef 8d8d4cffffff             lea       ecx, [ebp - 0xb4]
008c21f5 e896d6b5ff               call      0x41f890
008c21fa 0fb75510                 movzx     edx, word ptr [ebp + 0x10]
008c21fe 47                       inc       edi
008c21ff 3bfa                     cmp       edi, edx
008c2201 7cdd                     jl        0x8c21e0
008c2203 895d80                   mov       dword ptr [ebp - 0x80], ebx
008c2206 895d84                   mov       dword ptr [ebp - 0x7c], ebx
008c2209 895d88                   mov       dword ptr [ebp - 0x78], ebx
008c220c 8d854cffffff             lea       eax, [ebp - 0xb4]
008c2212 50                       push      eax
008c2213 8d8d7cffffff             lea       ecx, [ebp - 0x84]
008c2219 c645fc03                 mov       byte ptr [ebp - 4], 3
008c221d e8de430000               call      0x8c6600
008c2222 8d4d94                   lea       ecx, [ebp - 0x6c]
008c2225 51                       push      ecx
008c2226 8d8d7cffffff             lea       ecx, [ebp - 0x84]
008c222c e85fb2c2ff               call      0x4ed490
008c2231 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c2237 3bf3                     cmp       esi, ebx
008c2239 0f8436360000             je        0x8c5875
008c223f 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c2245 3bcb                     cmp       ecx, ebx
008c2247 0f8428360000             je        0x8c5875
008c224d 0fb755e8                 movzx     edx, word ptr [ebp - 0x18]
008c2251 0fb745e0                 movzx     eax, word ptr [ebp - 0x20]
008c2255 53                       push      ebx
008c2256 687c28f400               push      0xf4287c
008c225b 681009f400               push      0xf40910
008c2260 53                       push      ebx
008c2261 52                       push      edx
008c2262 50                       push      eax
008c2263 e8b895c4ff               call      0x50b820
008c2268 50                       push      eax
008c2269 e89dea3300               call      0xc00d0b
008c226e 8bf0                     mov       esi, eax
008c2270 83c414                   add       esp, 0x14
008c2273 3bf3                     cmp       esi, ebx
008c2275 0f84fa350000             je        0x8c5875
008c227b 8b16                     mov       edx, dword ptr [esi]
008c227d 8bce                     mov       ecx, esi
008c227f ff9224010000             call      dword ptr [edx + 0x124]
008c2285 8bf8                     mov       edi, eax
008c2287 8b06                     mov       eax, dword ptr [esi]
008c2289 8bce                     mov       ecx, esi
008c228b 897df0                   mov       dword ptr [ebp - 0x10], edi
008c228e ff902c010000             call      dword ptr [eax + 0x12c]
008c2294 8b16                     mov       edx, dword ptr [esi]
008c2296 8bce                     mov       ecx, esi
008c2298 8945d0                   mov       dword ptr [ebp - 0x30], eax
008c229b ff9228010000             call      dword ptr [edx + 0x128]
008c22a1 3bfb                     cmp       edi, ebx
008c22a3 8945c8                   mov       dword ptr [ebp - 0x38], eax
008c22a6 740e                     je        0x8c22b6
008c22a8 8b06                     mov       eax, dword ptr [esi]
008c22aa 53                       push      ebx
008c22ab 6aff                     push      -1
008c22ad 53                       push      ebx
008c22ae 8bce                     mov       ecx, esi
008c22b0 ff901c010000             call      dword ptr [eax + 0x11c]
008c22b6 b928070001               mov       ecx, 0x1000728
008c22bb e8600ab4ff               call      0x402d20
008c22c0 8b16                     mov       edx, dword ptr [esi]
008c22c2 6a21                     push      0x21
008c22c4 8bce                     mov       ecx, esi
008c22c6 c7450cffffffff           mov       dword ptr [ebp + 0xc], 0xffffffff
008c22cd ff522c                   call      dword ptr [edx + 0x2c]
008c22d0 84c0                     test      al, al
008c22d2 8bce                     mov       ecx, esi
008c22d4 751d                     jne       0x8c22f3
008c22d6 8b16                     mov       edx, dword ptr [esi]
008c22d8 6a11                     push      0x11
008c22da ff522c                   call      dword ptr [edx + 0x2c]
008c22dd 84c0                     test      al, al
008c22df 8bce                     mov       ecx, esi
008c22e1 7510                     jne       0x8c22f3
008c22e3 8b16                     mov       edx, dword ptr [esi]
008c22e5 6881000000               push      0x81
008c22ea ff522c                   call      dword ptr [edx + 0x2c]
008c22ed 84c0                     test      al, al
008c22ef 740d                     je        0x8c22fe
008c22f1 8bce                     mov       ecx, esi
008c22f3 8b06                     mov       eax, dword ptr [esi]
008c22f5 ff9030020000             call      dword ptr [eax + 0x230]
008c22fb 89450c                   mov       dword ptr [ebp + 0xc], eax
008c22fe 8b4598                   mov       eax, dword ptr [ebp - 0x68]
008c2301 3bc3                     cmp       eax, ebx
008c2303 7504                     jne       0x8c2309
008c2305 33ff                     xor       edi, edi
008c2307 eb08                     jmp       0x8c2311
008c2309 8b7d9c                   mov       edi, dword ptr [ebp - 0x64]
008c230c 2bf8                     sub       edi, eax
008c230e c1ff02                   sar       edi, 2
008c2311 8d8e08020000             lea       ecx, [esi + 0x208]
008c2317 e8d40d1900               call      0xa530f0
008c231c 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c2320 8b550c                   mov       edx, dword ptr [ebp + 0xc]
008c2323 57                       push      edi
008c2324 51                       push      ecx
008c2325 8945ec                   mov       dword ptr [ebp - 0x14], eax
008c2328 8b06                     mov       eax, dword ptr [esi]
008c232a 52                       push      edx
008c232b 8bce                     mov       ecx, esi
008c232d ff5040                   call      dword ptr [eax + 0x40]
008c2330 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
008c2333 50                       push      eax
008c2334 51                       push      ecx
008c2335 680812e300               push      0xe31208
008c233a 53                       push      ebx
008c233b e860071900               call      0xa52aa0
008c2340 83c41c                   add       esp, 0x1c
008c2343 50                       push      eax
008c2344 b928070001               mov       ecx, 0x1000728
008c2349 e8f2c7b4ff               call      0x40eb40
008c234e 33ff                     xor       edi, edi
008c2350 8b4d98                   mov       ecx, dword ptr [ebp - 0x68]
008c2353 3bcb                     cmp       ecx, ebx
008c2355 742d                     je        0x8c2384
008c2357 8b459c                   mov       eax, dword ptr [ebp - 0x64]
008c235a 2bc1                     sub       eax, ecx
008c235c c1f802                   sar       eax, 2
008c235f 3bf8                     cmp       edi, eax
008c2361 7321                     jae       0x8c2384
008c2363 8b14b9                   mov       edx, dword ptr [ecx + edi*4]
008c2366 52                       push      edx
008c2367 57                       push      edi
008c2368 68e411e300               push      0xe311e4
008c236d 53                       push      ebx
008c236e e82d071900               call      0xa52aa0
008c2373 83c410                   add       esp, 0x10
008c2376 50                       push      eax
008c2377 b928070001               mov       ecx, 0x1000728
008c237c e8efc7b4ff               call      0x40eb70
008c2381 47                       inc       edi
008c2382 ebcc                     jmp       0x8c2350
008c2384 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c2388 8b06                     mov       eax, dword ptr [esi]
008c238a 6a01                     push      1
008c238c 6a01                     push      1
008c238e 8d4d94                   lea       ecx, [ebp - 0x6c]
008c2391 51                       push      ecx
008c2392 52                       push      edx
008c2393 8bce                     mov       ecx, esi
008c2395 ff902c020000             call      dword ptr [eax + 0x22c]
008c239b 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
008c239e 3bfb                     cmp       edi, ebx
008c23a0 743e                     je        0x8c23e0
008c23a2 8b06                     mov       eax, dword ptr [esi]
008c23a4 6a11                     push      0x11
008c23a6 8bce                     mov       ecx, esi
008c23a8 ff502c                   call      dword ptr [eax + 0x2c]
008c23ab 84c0                     test      al, al
008c23ad 741e                     je        0x8c23cd
008c23af 8a450b                   mov       al, byte ptr [ebp + 0xb]
008c23b2 3c03                     cmp       al, 3
008c23b4 7417                     je        0x8c23cd
008c23b6 3c04                     cmp       al, 4
008c23b8 7413                     je        0x8c23cd
008c23ba 3c05                     cmp       al, 5
008c23bc 740f                     je        0x8c23cd
008c23be 3c09                     cmp       al, 9
008c23c0 740b                     je        0x8c23cd
008c23c2 83ff01                   cmp       edi, 1
008c23c5 7506                     jne       0x8c23cd
008c23c7 837dd0ff                 cmp       dword ptr [ebp - 0x30], -1
008c23cb 7513                     jne       0x8c23e0
008c23cd 8b45c8                   mov       eax, dword ptr [ebp - 0x38]
008c23d0 8b4dd0                   mov       ecx, dword ptr [ebp - 0x30]
008c23d3 8b16                     mov       edx, dword ptr [esi]
008c23d5 50                       push      eax
008c23d6 51                       push      ecx
008c23d7 57                       push      edi
008c23d8 8bce                     mov       ecx, esi
008c23da ff921c010000             call      dword ptr [edx + 0x11c]
008c23e0 8b16                     mov       edx, dword ptr [esi]
008c23e2 8bce                     mov       ecx, esi
008c23e4 ff9294020000             call      dword ptr [edx + 0x294]
008c23ea 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c23ee 3bc1                     cmp       eax, ecx
008c23f0 750a                     jne       0x8c23fc
008c23f2 8b16                     mov       edx, dword ptr [esi]
008c23f4 8bce                     mov       ecx, esi
008c23f6 ff9298020000             call      dword ptr [edx + 0x298]
008c23fc 8bce                     mov       ecx, esi
008c23fe e88d9cbdff               call      0x49c090
008c2403 84c0                     test      al, al
008c2405 0f846a340000             je        0x8c5875
008c240b 8b06                     mov       eax, dword ptr [esi]
008c240d 6a01                     push      1
008c240f 6a01                     push      1
008c2411 8bce                     mov       ecx, esi
008c2413 ff5048                   call      dword ptr [eax + 0x48]
008c2416 8bc8                     mov       ecx, eax
008c2418 e853f7c4ff               call      0x511b70
008c241d e953340000               jmp       0x8c5875
008c2422 8b16                     mov       edx, dword ptr [esi]
008c2424 33db                     xor       ebx, ebx
008c2426 8d450c                   lea       eax, [ebp + 0xc]
008c2429 50                       push      eax
008c242a 8bce                     mov       ecx, esi
008c242c 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c242f 895d08                   mov       dword ptr [ebp + 8], ebx
008c2432 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c2435 ff5254                   call      dword ptr [edx + 0x54]
008c2438 8b16                     mov       edx, dword ptr [esi]
008c243a 8d4508                   lea       eax, [ebp + 8]
008c243d 50                       push      eax
008c243e 8bce                     mov       ecx, esi
008c2440 ff5254                   call      dword ptr [edx + 0x54]
008c2443 8b16                     mov       edx, dword ptr [esi]
008c2445 8d4510                   lea       eax, [ebp + 0x10]
008c2448 50                       push      eax
008c2449 8bce                     mov       ecx, esi
008c244b ff5254                   call      dword ptr [edx + 0x54]
008c244e 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c2454 3bc3                     cmp       eax, ebx
008c2456 0f84f4390000             je        0x8c5e50
008c245c 3998b0000000             cmp       dword ptr [eax + 0xb0], ebx
008c2462 0f84e8390000             je        0x8c5e50
008c2468 8b4d10                   mov       ecx, dword ptr [ebp + 0x10]
008c246b 51                       push      ecx
008c246c 8b0d3c310001             mov       ecx, dword ptr [0x100313c]
008c2472 e85998c9ff               call      0x55bcd0
008c2477 8bf8                     mov       edi, eax
008c2479 3bfb                     cmp       edi, ebx
008c247b 0f8456010000             je        0x8c25d7
008c2481 8b8704020000             mov       eax, dword ptr [edi + 0x204]
008c2487 3bc3                     cmp       eax, ebx
008c2489 0f8442010000             je        0x8c25d1
008c248f 8b9660a01000             mov       edx, dword ptr [esi + 0x10a060]
008c2495 8b8ab0000000             mov       ecx, dword ptr [edx + 0xb0]
008c249b 50                       push      eax
008c249c e82f8cc4ff               call      0x50b0d0
008c24a1 84c0                     test      al, al
008c24a3 0f8428010000             je        0x8c25d1
008c24a9 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c24af 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c24b3 8b88b0000000             mov       ecx, dword ptr [eax + 0xb0]
008c24b9 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c24bd 52                       push      edx
008c24be 50                       push      eax
008c24bf e85c93c4ff               call      0x50b820
008c24c4 8bf0                     mov       esi, eax
008c24c6 3bf3                     cmp       esi, ebx
008c24c8 0f84e2000000             je        0x8c25b0
008c24ce 8b16                     mov       edx, dword ptr [esi]
008c24d0 6811020000               push      0x211
008c24d5 8bce                     mov       ecx, esi
008c24d7 ff522c                   call      dword ptr [edx + 0x2c]
008c24da 84c0                     test      al, al
008c24dc 744d                     je        0x8c252b
008c24de 53                       push      ebx
008c24df 682829f400               push      0xf42928
008c24e4 687c28f400               push      0xf4287c
008c24e9 53                       push      ebx
008c24ea 56                       push      esi
008c24eb e81be83300               call      0xc00d0b
008c24f0 83c414                   add       esp, 0x14
008c24f3 3bc3                     cmp       eax, ebx
008c24f5 7561                     jne       0x8c2558
008c24f7 8d4f10                   lea       ecx, [edi + 0x10]
008c24fa e8f10b1900               call      0xa530f0
008c24ff 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c2503 50                       push      eax
008c2504 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c2508 52                       push      edx
008c2509 50                       push      eax
008c250a 68a011e300               push      0xe311a0
008c250f ff15bc2eff00             call      dword ptr [0xff2ebc]
008c2515 83c410                   add       esp, 0x10
008c2518 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c251b 64890d00000000           mov       dword ptr fs:[0], ecx
008c2522 5f                       pop       edi
008c2523 5e                       pop       esi
008c2524 5b                       pop       ebx
008c2525 8be5                     mov       esp, ebp
008c2527 5d                       pop       ebp
008c2528 c20c00                   ret       0xc
008c252b 8b16                     mov       edx, dword ptr [esi]
008c252d 6811010000               push      0x111
008c2532 8bce                     mov       ecx, esi
008c2534 ff522c                   call      dword ptr [edx + 0x2c]
008c2537 84c0                     test      al, al
008c2539 0f8411390000             je        0x8c5e50
008c253f 53                       push      ebx
008c2540 680829f400               push      0xf42908
008c2545 687c28f400               push      0xf4287c
008c254a 53                       push      ebx
008c254b 56                       push      esi
008c254c e8bae73300               call      0xc00d0b
008c2551 83c414                   add       esp, 0x14
008c2554 3bc3                     cmp       eax, ebx
008c2556 7424                     je        0x8c257c
008c2558 8b8f04020000             mov       ecx, dword ptr [edi + 0x204]
008c255e 8b10                     mov       edx, dword ptr [eax]
008c2560 51                       push      ecx
008c2561 8bc8                     mov       ecx, eax
008c2563 ff9228030000             call      dword ptr [edx + 0x328]
008c2569 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c256c 64890d00000000           mov       dword ptr fs:[0], ecx
008c2573 5f                       pop       edi
008c2574 5e                       pop       esi
008c2575 5b                       pop       ebx
008c2576 8be5                     mov       esp, ebp
008c2578 5d                       pop       ebp
008c2579 c20c00                   ret       0xc
008c257c 8d4f10                   lea       ecx, [edi + 0x10]
008c257f e86c0b1900               call      0xa530f0
008c2584 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c2588 50                       push      eax
008c2589 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c258d 52                       push      edx
008c258e 50                       push      eax
008c258f 685811e300               push      0xe31158
008c2594 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c259a 83c410                   add       esp, 0x10
008c259d 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c25a0 64890d00000000           mov       dword ptr fs:[0], ecx
008c25a7 5f                       pop       edi
008c25a8 5e                       pop       esi
008c25a9 5b                       pop       ebx
008c25aa 8be5                     mov       esp, ebp
008c25ac 5d                       pop       ebp
008c25ad c20c00                   ret       0xc
008c25b0 682811e300               push      0xe31128
008c25b5 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c25bb 83c404                   add       esp, 4
008c25be 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c25c1 64890d00000000           mov       dword ptr fs:[0], ecx
008c25c8 5f                       pop       edi
008c25c9 5e                       pop       esi
008c25ca 5b                       pop       ebx
008c25cb 8be5                     mov       esp, ebp
008c25cd 5d                       pop       ebp
008c25ce c20c00                   ret       0xc
008c25d1 8b9f04020000             mov       ebx, dword ptr [edi + 0x204]
008c25d7 0fb74d10                 movzx     ecx, word ptr [ebp + 0x10]
008c25db 53                       push      ebx
008c25dc 57                       push      edi
008c25dd 51                       push      ecx
008c25de 68b810e300               push      0xe310b8
008c25e3 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c25e9 83c410                   add       esp, 0x10
008c25ec 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c25ef 64890d00000000           mov       dword ptr fs:[0], ecx
008c25f6 5f                       pop       edi
008c25f7 5e                       pop       esi
008c25f8 5b                       pop       ebx
008c25f9 8be5                     mov       esp, ebp
008c25fb 5d                       pop       ebp
008c25fc c20c00                   ret       0xc
008c25ff 8b16                     mov       edx, dword ptr [esi]
008c2601 33db                     xor       ebx, ebx
008c2603 8d450c                   lea       eax, [ebp + 0xc]
008c2606 50                       push      eax
008c2607 8bce                     mov       ecx, esi
008c2609 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c260c 895d08                   mov       dword ptr [ebp + 8], ebx
008c260f 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c2612 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c2615 ff5254                   call      dword ptr [edx + 0x54]
008c2618 8b16                     mov       edx, dword ptr [esi]
008c261a 8d4508                   lea       eax, [ebp + 8]
008c261d 50                       push      eax
008c261e 8bce                     mov       ecx, esi
008c2620 ff5254                   call      dword ptr [edx + 0x54]
008c2623 8b16                     mov       edx, dword ptr [esi]
008c2625 8d45e8                   lea       eax, [ebp - 0x18]
008c2628 50                       push      eax
008c2629 8bce                     mov       ecx, esi
008c262b ff5254                   call      dword ptr [edx + 0x54]
008c262e 8b16                     mov       edx, dword ptr [esi]
008c2630 8d4510                   lea       eax, [ebp + 0x10]
008c2633 50                       push      eax
008c2634 8bce                     mov       ecx, esi
008c2636 ff5254                   call      dword ptr [edx + 0x54]
008c2639 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c263f 3bc3                     cmp       eax, ebx
008c2641 0f8409380000             je        0x8c5e50
008c2647 8b88b0000000             mov       ecx, dword ptr [eax + 0xb0]
008c264d 3bcb                     cmp       ecx, ebx
008c264f 0f84fb370000             je        0x8c5e50
008c2655 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c2659 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c265d 53                       push      ebx
008c265e 682829f400               push      0xf42928
008c2663 681009f400               push      0xf40910
008c2668 53                       push      ebx
008c2669 52                       push      edx
008c266a 50                       push      eax
008c266b e8b091c4ff               call      0x50b820
008c2670 50                       push      eax
008c2671 e895e63300               call      0xc00d0b
008c2676 8bf8                     mov       edi, eax
008c2678 83c414                   add       esp, 0x14
008c267b 3bfb                     cmp       edi, ebx
008c267d 0f84cd370000             je        0x8c5e50
008c2683 0fb75510                 movzx     edx, word ptr [ebp + 0x10]
008c2687 0fb745e8                 movzx     eax, word ptr [ebp - 0x18]
008c268b 8b8e60a01000             mov       ecx, dword ptr [esi + 0x10a060]
008c2691 8b89b0000000             mov       ecx, dword ptr [ecx + 0xb0]
008c2697 8b37                     mov       esi, dword ptr [edi]
008c2699 52                       push      edx
008c269a 50                       push      eax
008c269b e88091c4ff               call      0x50b820
008c26a0 50                       push      eax
008c26a1 8bcf                     mov       ecx, edi
008c26a3 ff962c060000             call      dword ptr [esi + 0x62c]
008c26a9 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c26ac 64890d00000000           mov       dword ptr fs:[0], ecx
008c26b3 5f                       pop       edi
008c26b4 5e                       pop       esi
008c26b5 5b                       pop       ebx
008c26b6 8be5                     mov       esp, ebp
008c26b8 5d                       pop       ebp
008c26b9 c20c00                   ret       0xc
008c26bc 8b16                     mov       edx, dword ptr [esi]
008c26be 8d450c                   lea       eax, [ebp + 0xc]
008c26c1 33db                     xor       ebx, ebx
008c26c3 50                       push      eax
008c26c4 8bce                     mov       ecx, esi
008c26c6 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c26c9 895d08                   mov       dword ptr [ebp + 8], ebx
008c26cc ff5254                   call      dword ptr [edx + 0x54]
008c26cf 8b16                     mov       edx, dword ptr [esi]
008c26d1 8d4508                   lea       eax, [ebp + 8]
008c26d4 50                       push      eax
008c26d5 8bce                     mov       ecx, esi
008c26d7 ff5254                   call      dword ptr [edx + 0x54]
008c26da 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c26e0 3bf3                     cmp       esi, ebx
008c26e2 0f8468370000             je        0x8c5e50
008c26e8 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c26ee 3bcb                     cmp       ecx, ebx
008c26f0 0f845a370000             je        0x8c5e50
008c26f6 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c26fa 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c26fe 53                       push      ebx
008c26ff 682829f400               push      0xf42928
008c2704 681009f400               push      0xf40910
008c2709 53                       push      ebx
008c270a 52                       push      edx
008c270b 50                       push      eax
008c270c e80f91c4ff               call      0x50b820
008c2711 50                       push      eax
008c2712 e8f4e53300               call      0xc00d0b
008c2717 83c414                   add       esp, 0x14
008c271a 3bc3                     cmp       eax, ebx
008c271c 0f842e370000             je        0x8c5e50
008c2722 8b10                     mov       edx, dword ptr [eax]
008c2724 8bc8                     mov       ecx, eax
008c2726 ff92e0050000             call      dword ptr [edx + 0x5e0]
008c272c 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c272f 64890d00000000           mov       dword ptr fs:[0], ecx
008c2736 5f                       pop       edi
008c2737 5e                       pop       esi
008c2738 5b                       pop       ebx
008c2739 8be5                     mov       esp, ebp
008c273b 5d                       pop       ebp
008c273c c20c00                   ret       0xc
008c273f 8b06                     mov       eax, dword ptr [esi]
008c2741 8d4d0c                   lea       ecx, [ebp + 0xc]
008c2744 33db                     xor       ebx, ebx
008c2746 51                       push      ecx
008c2747 8bce                     mov       ecx, esi
008c2749 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c274c 895d08                   mov       dword ptr [ebp + 8], ebx
008c274f ff5054                   call      dword ptr [eax + 0x54]
008c2752 8b16                     mov       edx, dword ptr [esi]
008c2754 8d4508                   lea       eax, [ebp + 8]
008c2757 50                       push      eax
008c2758 8bce                     mov       ecx, esi
008c275a ff5254                   call      dword ptr [edx + 0x54]
008c275d 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c2763 3bf3                     cmp       esi, ebx
008c2765 0f84e5360000             je        0x8c5e50
008c276b 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c2771 3bcb                     cmp       ecx, ebx
008c2773 0f84d7360000             je        0x8c5e50
008c2779 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c277d 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c2781 52                       push      edx
008c2782 50                       push      eax
008c2783 e89890c4ff               call      0x50b820
008c2788 8bf0                     mov       esi, eax
008c278a 3bf3                     cmp       esi, ebx
008c278c 0f84be360000             je        0x8c5e50
008c2792 8b16                     mov       edx, dword ptr [esi]
008c2794 6a11                     push      0x11
008c2796 8bce                     mov       ecx, esi
008c2798 ff522c                   call      dword ptr [edx + 0x2c]
008c279b 84c0                     test      al, al
008c279d 0f84ad360000             je        0x8c5e50
008c27a3 53                       push      ebx
008c27a4 687c28f400               push      0xf4287c
008c27a9 681009f400               push      0xf40910
008c27ae 53                       push      ebx
008c27af 56                       push      esi
008c27b0 e856e53300               call      0xc00d0b
008c27b5 83c414                   add       esp, 0x14
008c27b8 3bc3                     cmp       eax, ebx
008c27ba 0f8490360000             je        0x8c5e50
008c27c0 8b10                     mov       edx, dword ptr [eax]
008c27c2 8bc8                     mov       ecx, eax
008c27c4 ff92b0010000             call      dword ptr [edx + 0x1b0]
008c27ca 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c27cd 64890d00000000           mov       dword ptr fs:[0], ecx
008c27d4 5f                       pop       edi
008c27d5 5e                       pop       esi
008c27d6 5b                       pop       ebx
008c27d7 8be5                     mov       esp, ebp
008c27d9 5d                       pop       ebp
008c27da c20c00                   ret       0xc
008c27dd 8b06                     mov       eax, dword ptr [esi]
008c27df 8d4d0c                   lea       ecx, [ebp + 0xc]
008c27e2 33db                     xor       ebx, ebx
008c27e4 51                       push      ecx
008c27e5 8bce                     mov       ecx, esi
008c27e7 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c27ea 895d08                   mov       dword ptr [ebp + 8], ebx
008c27ed ff5054                   call      dword ptr [eax + 0x54]
008c27f0 8b16                     mov       edx, dword ptr [esi]
008c27f2 8d4508                   lea       eax, [ebp + 8]
008c27f5 50                       push      eax
008c27f6 8bce                     mov       ecx, esi
008c27f8 ff5254                   call      dword ptr [edx + 0x54]
008c27fb 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c2801 3bf3                     cmp       esi, ebx
008c2803 0f8447360000             je        0x8c5e50
008c2809 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c280f 3bcb                     cmp       ecx, ebx
008c2811 0f8439360000             je        0x8c5e50
008c2817 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c281b 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c281f 53                       push      ebx
008c2820 682829f400               push      0xf42928
008c2825 681009f400               push      0xf40910
008c282a 53                       push      ebx
008c282b 52                       push      edx
008c282c 50                       push      eax
008c282d e8ee8fc4ff               call      0x50b820
008c2832 50                       push      eax
008c2833 e8d3e43300               call      0xc00d0b
008c2838 83c414                   add       esp, 0x14
008c283b 3bc3                     cmp       eax, ebx
008c283d 0f840d360000             je        0x8c5e50
008c2843 8b10                     mov       edx, dword ptr [eax]
008c2845 8bc8                     mov       ecx, eax
008c2847 ff92c4050000             call      dword ptr [edx + 0x5c4]
008c284d 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2850 64890d00000000           mov       dword ptr fs:[0], ecx
008c2857 5f                       pop       edi
008c2858 5e                       pop       esi
008c2859 5b                       pop       ebx
008c285a 8be5                     mov       esp, ebp
008c285c 5d                       pop       ebp
008c285d c20c00                   ret       0xc
008c2860 8b06                     mov       eax, dword ptr [esi]
008c2862 8d4d0b                   lea       ecx, [ebp + 0xb]
008c2865 51                       push      ecx
008c2866 8bce                     mov       ecx, esi
008c2868 ff5050                   call      dword ptr [eax + 0x50]
008c286b 8a450b                   mov       al, byte ptr [ebp + 0xb]
008c286e 33db                     xor       ebx, ebx
008c2870 3ac3                     cmp       al, bl
008c2872 0f86d8350000             jbe       0x8c5e50
008c2878 8b16                     mov       edx, dword ptr [esi]
008c287a 8d45ec                   lea       eax, [ebp - 0x14]
008c287d 50                       push      eax
008c287e 8bce                     mov       ecx, esi
008c2880 ff525c                   call      dword ptr [edx + 0x5c]
008c2883 8b16                     mov       edx, dword ptr [esi]
008c2885 8d4513                   lea       eax, [ebp + 0x13]
008c2888 50                       push      eax
008c2889 8bce                     mov       ecx, esi
008c288b ff5250                   call      dword ptr [edx + 0x50]
008c288e 8b16                     mov       edx, dword ptr [esi]
008c2890 8d450f                   lea       eax, [ebp + 0xf]
008c2893 50                       push      eax
008c2894 8bce                     mov       ecx, esi
008c2896 ff5250                   call      dword ptr [edx + 0x50]
008c2899 0fb64d0f                 movzx     ecx, byte ptr [ebp + 0xf]
008c289d 0fb65513                 movzx     edx, byte ptr [ebp + 0x13]
008c28a1 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
008c28a4 51                       push      ecx
008c28a5 52                       push      edx
008c28a6 50                       push      eax
008c28a7 e8b411bdff               call      0x493a60
008c28ac 8a450b                   mov       al, byte ptr [ebp + 0xb]
008c28af 83c40c                   add       esp, 0xc
008c28b2 fec3                     inc       bl
008c28b4 3ad8                     cmp       bl, al
008c28b6 72c0                     jb        0x8c2878
008c28b8 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c28bb 64890d00000000           mov       dword ptr fs:[0], ecx
008c28c2 5f                       pop       edi
008c28c3 5e                       pop       esi
008c28c4 5b                       pop       ebx
008c28c5 8be5                     mov       esp, ebp
008c28c7 5d                       pop       ebp
008c28c8 c20c00                   ret       0xc
008c28cb 8b16                     mov       edx, dword ptr [esi]
008c28cd 33db                     xor       ebx, ebx
008c28cf 8d450c                   lea       eax, [ebp + 0xc]
008c28d2 50                       push      eax
008c28d3 8bce                     mov       ecx, esi
008c28d5 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c28d8 895d08                   mov       dword ptr [ebp + 8], ebx
008c28db 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c28de ff5254                   call      dword ptr [edx + 0x54]
008c28e1 8b16                     mov       edx, dword ptr [esi]
008c28e3 8d4508                   lea       eax, [ebp + 8]
008c28e6 50                       push      eax
008c28e7 8bce                     mov       ecx, esi
008c28e9 ff5254                   call      dword ptr [edx + 0x54]
008c28ec 8b16                     mov       edx, dword ptr [esi]
008c28ee 8d4510                   lea       eax, [ebp + 0x10]
008c28f1 50                       push      eax
008c28f2 8bce                     mov       ecx, esi
008c28f4 ff5254                   call      dword ptr [edx + 0x54]
008c28f7 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c28fd 3bf3                     cmp       esi, ebx
008c28ff 0f844b350000             je        0x8c5e50
008c2905 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c290b 3bcb                     cmp       ecx, ebx
008c290d 0f843d350000             je        0x8c5e50
008c2913 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c2917 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c291b 53                       push      ebx
008c291c 687c28f400               push      0xf4287c
008c2921 681009f400               push      0xf40910
008c2926 53                       push      ebx
008c2927 52                       push      edx
008c2928 50                       push      eax
008c2929 e8f28ec4ff               call      0x50b820
008c292e 50                       push      eax
008c292f e8d7e33300               call      0xc00d0b
008c2934 83c414                   add       esp, 0x14
008c2937 3bc3                     cmp       eax, ebx
008c2939 0f8411350000             je        0x8c5e50
008c293f 0fb74d10                 movzx     ecx, word ptr [ebp + 0x10]
008c2943 8b10                     mov       edx, dword ptr [eax]
008c2945 51                       push      ecx
008c2946 8bc8                     mov       ecx, eax
008c2948 ff92c0010000             call      dword ptr [edx + 0x1c0]
008c294e 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2951 64890d00000000           mov       dword ptr fs:[0], ecx
008c2958 5f                       pop       edi
008c2959 5e                       pop       esi
008c295a 5b                       pop       ebx
008c295b 8be5                     mov       esp, ebp
008c295d 5d                       pop       ebp
008c295e c20c00                   ret       0xc
008c2961 8b16                     mov       edx, dword ptr [esi]
008c2963 8d450c                   lea       eax, [ebp + 0xc]
008c2966 33db                     xor       ebx, ebx
008c2968 50                       push      eax
008c2969 8bce                     mov       ecx, esi
008c296b 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c296e 895d08                   mov       dword ptr [ebp + 8], ebx
008c2971 ff5254                   call      dword ptr [edx + 0x54]
008c2974 8b16                     mov       edx, dword ptr [esi]
008c2976 8d4508                   lea       eax, [ebp + 8]
008c2979 50                       push      eax
008c297a 8bce                     mov       ecx, esi
008c297c ff5254                   call      dword ptr [edx + 0x54]
008c297f 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c2985 3bf3                     cmp       esi, ebx
008c2987 0f84c3340000             je        0x8c5e50
008c298d 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c2993 3bcb                     cmp       ecx, ebx
008c2995 0f84b5340000             je        0x8c5e50
008c299b 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c299f 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c29a3 53                       push      ebx
008c29a4 682829f400               push      0xf42928
008c29a9 681009f400               push      0xf40910
008c29ae 53                       push      ebx
008c29af 52                       push      edx
008c29b0 50                       push      eax
008c29b1 e86a8ec4ff               call      0x50b820
008c29b6 50                       push      eax
008c29b7 e84fe33300               call      0xc00d0b
008c29bc 83c414                   add       esp, 0x14
008c29bf 3bc3                     cmp       eax, ebx
008c29c1 0f8489340000             je        0x8c5e50
008c29c7 8bc8                     mov       ecx, eax
008c29c9 e8620fc3ff               call      0x4f3930
008c29ce 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c29d1 64890d00000000           mov       dword ptr fs:[0], ecx
008c29d8 5f                       pop       edi
008c29d9 5e                       pop       esi
008c29da 5b                       pop       ebx
008c29db 8be5                     mov       esp, ebp
008c29dd 5d                       pop       ebp
008c29de c20c00                   ret       0xc
008c29e1 8b16                     mov       edx, dword ptr [esi]
008c29e3 33db                     xor       ebx, ebx
008c29e5 8d450c                   lea       eax, [ebp + 0xc]
008c29e8 50                       push      eax
008c29e9 8bce                     mov       ecx, esi
008c29eb 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c29ee 895d08                   mov       dword ptr [ebp + 8], ebx
008c29f1 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c29f4 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c29f7 ff5254                   call      dword ptr [edx + 0x54]
008c29fa 8b16                     mov       edx, dword ptr [esi]
008c29fc 8d4508                   lea       eax, [ebp + 8]
008c29ff 50                       push      eax
008c2a00 8bce                     mov       ecx, esi
008c2a02 ff5254                   call      dword ptr [edx + 0x54]
008c2a05 8b16                     mov       edx, dword ptr [esi]
008c2a07 8d4510                   lea       eax, [ebp + 0x10]
008c2a0a 50                       push      eax
008c2a0b 8bce                     mov       ecx, esi
008c2a0d ff5254                   call      dword ptr [edx + 0x54]
008c2a10 8b16                     mov       edx, dword ptr [esi]
008c2a12 8d45e8                   lea       eax, [ebp - 0x18]
008c2a15 50                       push      eax
008c2a16 8bce                     mov       ecx, esi
008c2a18 ff5254                   call      dword ptr [edx + 0x54]
008c2a1b 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c2a21 3bc3                     cmp       eax, ebx
008c2a23 0f8427340000             je        0x8c5e50
008c2a29 8b88b0000000             mov       ecx, dword ptr [eax + 0xb0]
008c2a2f 3bcb                     cmp       ecx, ebx
008c2a31 0f8419340000             je        0x8c5e50
008c2a37 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c2a3b 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c2a3f 53                       push      ebx
008c2a40 68a028f400               push      0xf428a0
008c2a45 681009f400               push      0xf40910
008c2a4a 53                       push      ebx
008c2a4b 52                       push      edx
008c2a4c 50                       push      eax
008c2a4d e8ce8dc4ff               call      0x50b820
008c2a52 50                       push      eax
008c2a53 e8b3e23300               call      0xc00d0b
008c2a58 83c414                   add       esp, 0x14
008c2a5b 3bc3                     cmp       eax, ebx
008c2a5d 8945e0                   mov       dword ptr [ebp - 0x20], eax
008c2a60 0f84ea330000             je        0x8c5e50
008c2a66 8b5510                   mov       edx, dword ptr [ebp + 0x10]
008c2a69 33ff                     xor       edi, edi
008c2a6b 6681faffff               cmp       dx, 0xffff
008c2a70 7434                     je        0x8c2aa6
008c2a72 0fb745e8                 movzx     eax, word ptr [ebp - 0x18]
008c2a76 8b8e60a01000             mov       ecx, dword ptr [esi + 0x10a060]
008c2a7c 8b89b0000000             mov       ecx, dword ptr [ecx + 0xb0]
008c2a82 53                       push      ebx
008c2a83 687c28f400               push      0xf4287c
008c2a88 681009f400               push      0xf40910
008c2a8d 53                       push      ebx
008c2a8e 0fb7d2                   movzx     edx, dx
008c2a91 50                       push      eax
008c2a92 52                       push      edx
008c2a93 e8888dc4ff               call      0x50b820
008c2a98 50                       push      eax
008c2a99 e86de23300               call      0xc00d0b
008c2a9e 8bf8                     mov       edi, eax
008c2aa0 8b45e0                   mov       eax, dword ptr [ebp - 0x20]
008c2aa3 83c414                   add       esp, 0x14
008c2aa6 8b10                     mov       edx, dword ptr [eax]
008c2aa8 57                       push      edi
008c2aa9 8bc8                     mov       ecx, eax
008c2aab ff9244030000             call      dword ptr [edx + 0x344]
008c2ab1 3bfb                     cmp       edi, ebx
008c2ab3 0f8497330000             je        0x8c5e50
008c2ab9 8b45e0                   mov       eax, dword ptr [ebp - 0x20]
008c2abc 57                       push      edi
008c2abd 50                       push      eax
008c2abe e82d63b8ff               call      0x448df0
008c2ac3 83c408                   add       esp, 8
008c2ac6 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2ac9 64890d00000000           mov       dword ptr fs:[0], ecx
008c2ad0 5f                       pop       edi
008c2ad1 5e                       pop       esi
008c2ad2 5b                       pop       ebx
008c2ad3 8be5                     mov       esp, ebp
008c2ad5 5d                       pop       ebp
008c2ad6 c20c00                   ret       0xc
008c2ad9 8b16                     mov       edx, dword ptr [esi]
008c2adb 33db                     xor       ebx, ebx
008c2add 8d45e8                   lea       eax, [ebp - 0x18]
008c2ae0 50                       push      eax
008c2ae1 8bce                     mov       ecx, esi
008c2ae3 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c2ae6 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c2ae9 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c2aec ff5254                   call      dword ptr [edx + 0x54]
008c2aef 8b16                     mov       edx, dword ptr [esi]
008c2af1 8d4510                   lea       eax, [ebp + 0x10]
008c2af4 50                       push      eax
008c2af5 8bce                     mov       ecx, esi
008c2af7 ff5254                   call      dword ptr [edx + 0x54]
008c2afa 8b16                     mov       edx, dword ptr [esi]
008c2afc 8d450b                   lea       eax, [ebp + 0xb]
008c2aff 50                       push      eax
008c2b00 8bce                     mov       ecx, esi
008c2b02 ff5250                   call      dword ptr [edx + 0x50]
008c2b05 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c2b0b 3bc3                     cmp       eax, ebx
008c2b0d 0f843d330000             je        0x8c5e50
008c2b13 8b88b0000000             mov       ecx, dword ptr [eax + 0xb0]
008c2b19 3bcb                     cmp       ecx, ebx
008c2b1b 0f842f330000             je        0x8c5e50
008c2b21 0fb75510                 movzx     edx, word ptr [ebp + 0x10]
008c2b25 0fb745e8                 movzx     eax, word ptr [ebp - 0x18]
008c2b29 52                       push      edx
008c2b2a 50                       push      eax
008c2b2b e8f08cc4ff               call      0x50b820
008c2b30 3bc3                     cmp       eax, ebx
008c2b32 8945d0                   mov       dword ptr [ebp - 0x30], eax
008c2b35 0f8415330000             je        0x8c5e50
008c2b3b 8b10                     mov       edx, dword ptr [eax]
008c2b3d 8bc8                     mov       ecx, eax
008c2b3f ff5248                   call      dword ptr [edx + 0x48]
008c2b42 385d0b                   cmp       byte ptr [ebp + 0xb], bl
008c2b45 8945e0                   mov       dword ptr [ebp - 0x20], eax
008c2b48 0f84cb000000             je        0x8c2c19
008c2b4e 8b7878                   mov       edi, dword ptr [eax + 0x78]
008c2b51 3bfb                     cmp       edi, ebx
008c2b53 897d0c                   mov       dword ptr [ebp + 0xc], edi
008c2b56 753b                     jne       0x8c2b93
008c2b58 68c4000000               push      0xc4
008c2b5d e8ee10b4ff               call      0x403c50
008c2b62 83c404                   add       esp, 4
008c2b65 89450c                   mov       dword ptr [ebp + 0xc], eax
008c2b68 3bc3                     cmp       eax, ebx
008c2b6a c745fc04000000           mov       dword ptr [ebp - 4], 4
008c2b71 7409                     je        0x8c2b7c
008c2b73 8bc8                     mov       ecx, eax
008c2b75 e8462fbdff               call      0x495ac0
008c2b7a eb02                     jmp       0x8c2b7e
008c2b7c 33c0                     xor       eax, eax
008c2b7e 8b4de0                   mov       ecx, dword ptr [ebp - 0x20]
008c2b81 8bf8                     mov       edi, eax
008c2b83 50                       push      eax
008c2b84 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
008c2b8b 897d0c                   mov       dword ptr [ebp + 0xc], edi
008c2b8e e87df3c4ff               call      0x511f10
008c2b93 8b06                     mov       eax, dword ptr [esi]
008c2b95 8b17                     mov       edx, dword ptr [edi]
008c2b97 6a67                     push      0x67
008c2b99 8bcf                     mov       ecx, edi
008c2b9b 8945ec                   mov       dword ptr [ebp - 0x14], eax
008c2b9e ff5210                   call      dword ptr [edx + 0x10]
008c2ba1 50                       push      eax
008c2ba2 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
008c2ba5 8bce                     mov       ecx, esi
008c2ba7 ff5064                   call      dword ptr [eax + 0x64]
008c2baa 33ff                     xor       edi, edi
008c2bac 8d642400                 lea       esp, [esp]
008c2bb0 8b4d0c                   mov       ecx, dword ptr [ebp + 0xc]
008c2bb3 8b01                     mov       eax, dword ptr [ecx]
008c2bb5 ff5010                   call      dword ptr [eax + 0x10]
008c2bb8 8b0cb8                   mov       ecx, dword ptr [eax + edi*4]
008c2bbb 51                       push      ecx
008c2bbc 8b4de0                   mov       ecx, dword ptr [ebp - 0x20]
008c2bbf 57                       push      edi
008c2bc0 e88be3c4ff               call      0x510f50
008c2bc5 47                       inc       edi
008c2bc6 83ff03                   cmp       edi, 3
008c2bc9 7ce5                     jl        0x8c2bb0
008c2bcb 8b4d0c                   mov       ecx, dword ptr [ebp + 0xc]
008c2bce 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
008c2bd1 8b01                     mov       eax, dword ptr [ecx]
008c2bd3 8b3a                     mov       edi, dword ptr [edx]
008c2bd5 ff5010                   call      dword ptr [eax + 0x10]
008c2bd8 8a5058                   mov       dl, byte ptr [eax + 0x58]
008c2bdb 33c9                     xor       ecx, ecx
008c2bdd 3ad3                     cmp       dl, bl
008c2bdf 0f94c1                   sete      cl
008c2be2 51                       push      ecx
008c2be3 8b4dd0                   mov       ecx, dword ptr [ebp - 0x30]
008c2be6 ff97bc000000             call      dword ptr [edi + 0xbc]
008c2bec 8b16                     mov       edx, dword ptr [esi]
008c2bee 8d45e4                   lea       eax, [ebp - 0x1c]
008c2bf1 50                       push      eax
008c2bf2 8bce                     mov       ecx, esi
008c2bf4 895de4                   mov       dword ptr [ebp - 0x1c], ebx
008c2bf7 ff525c                   call      dword ptr [edx + 0x5c]
008c2bfa 8b4d0c                   mov       ecx, dword ptr [ebp + 0xc]
008c2bfd 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
008c2c00 8b11                     mov       edx, dword ptr [ecx]
008c2c02 50                       push      eax
008c2c03 ff5204                   call      dword ptr [edx + 4]
008c2c06 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2c09 64890d00000000           mov       dword ptr fs:[0], ecx
008c2c10 5f                       pop       edi
008c2c11 5e                       pop       esi
008c2c12 5b                       pop       ebx
008c2c13 8be5                     mov       esp, ebp
008c2c15 5d                       pop       ebp
008c2c16 c20c00                   ret       0xc
008c2c19 53                       push      ebx
008c2c1a 8bc8                     mov       ecx, eax
008c2c1c e8eff2c4ff               call      0x511f10
008c2c21 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c2c24 64890d00000000           mov       dword ptr fs:[0], ecx
008c2c2b 5f                       pop       edi
008c2c2c 5e                       pop       esi
008c2c2d 5b                       pop       ebx
008c2c2e 8be5                     mov       esp, ebp
008c2c30 5d                       pop       ebp
008c2c31 c20c00                   ret       0xc
008c2c34 33db                     xor       ebx, ebx
008c2c36 8d8da8feffff             lea       ecx, [ebp - 0x158]
008c2c3c 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c2c3f 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c2c42 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c2c45 895dd8                   mov       dword ptr [ebp - 0x28], ebx
008c2c48 895dd4                   mov       dword ptr [ebp - 0x2c], ebx
008c2c4b e86044b9ff               call      0x4570b0
008c2c50 8b16                     mov       edx, dword ptr [esi]
008c2c52 33c9                     xor       ecx, ecx
008c2c54 898d72ffffff             mov       dword ptr [ebp - 0x8e], ecx
008c2c5a 898d76ffffff             mov       dword ptr [ebp - 0x8a], ecx
008c2c60 898d7affffff             mov       dword ptr [ebp - 0x86], ecx
008c2c66 898d7effffff             mov       dword ptr [ebp - 0x82], ecx
008c2c6c 894d82                   mov       dword ptr [ebp - 0x7e], ecx
008c2c6f 8d45e8                   lea       eax, [ebp - 0x18]
008c2c72 894d86                   mov       dword ptr [ebp - 0x7a], ecx
008c2c75 50                       push      eax
008c2c76 8bce                     mov       ecx, esi
008c2c78 c745fc05000000           mov       dword ptr [ebp - 4], 5
008c2c7f 895de4                   mov       dword ptr [ebp - 0x1c], ebx
008c2c82 895dcc                   mov       dword ptr [ebp - 0x34], ebx
008c2c85 895ddc                   mov       dword ptr [ebp - 0x24], ebx
008c2c88 66899d70ffffff           mov       word ptr [ebp - 0x90], bx
008c2c8f ff5254                   call      dword ptr [edx + 0x54]
008c2c92 8b16                     mov       edx, dword ptr [esi]
008c2c94 8d45d8                   lea       eax, [ebp - 0x28]
008c2c97 50                       push      eax
008c2c98 8bce                     mov       ecx, esi
008c2c9a ff5254                   call      dword ptr [edx + 0x54]
008c2c9d 8b16                     mov       edx, dword ptr [esi]
008c2c9f 8d450b                   lea       eax, [ebp + 0xb]
008c2ca2 50                       push      eax
008c2ca3 8bce                     mov       ecx, esi
008c2ca5 ff5250                   call      dword ptr [edx + 0x50]
008c2ca8 8b16                     mov       edx, dword ptr [esi]
008c2caa 8d45d4                   lea       eax, [ebp - 0x2c]
008c2cad 50                       push      eax
008c2cae 8bce                     mov       ecx, esi
008c2cb0 ff525c                   call      dword ptr [edx + 0x5c]
008c2cb3 8b16                     mov       edx, dword ptr [esi]
008c2cb5 8d45ec                   lea       eax, [ebp - 0x14]
008c2cb8 50                       push      eax
008c2cb9 8bce                     mov       ecx, esi
008c2cbb ff525c                   call      dword ptr [edx + 0x5c]
008c2cbe 8b16                     mov       edx, dword ptr [esi]
008c2cc0 8d45f0                   lea       eax, [ebp - 0x10]
008c2cc3 50                       push      eax
008c2cc4 8bce                     mov       ecx, esi
008c2cc6 ff525c                   call      dword ptr [edx + 0x5c]
008c2cc9 8b16                     mov       edx, dword ptr [esi]
008c2ccb 8d45c8                   lea       eax, [ebp - 0x38]
008c2cce 50                       push      eax
008c2ccf 8bce                     mov       ecx, esi
008c2cd1 ff525c                   call      dword ptr [edx + 0x5c]
008c2cd4 8b16                     mov       edx, dword ptr [esi]
008c2cd6 8d45c0                   lea       eax, [ebp - 0x40]
008c2cd9 50                       push      eax
008c2cda 8bce                     mov       ecx, esi
008c2cdc ff525c                   call      dword ptr [edx + 0x5c]
008c2cdf 8b16                     mov       edx, dword ptr [esi]
008c2ce1 8d45cc                   lea       eax, [ebp - 0x34]
008c2ce4 50                       push      eax
008c2ce5 8bce                     mov       ecx, esi
008c2ce7 ff525c                   call      dword ptr [edx + 0x5c]
008c2cea 8b16                     mov       edx, dword ptr [esi]
008c2cec 8d45dc                   lea       eax, [ebp - 0x24]
008c2cef 50                       push      eax
008c2cf0 8bce                     mov       ecx, esi
008c2cf2 ff525c                   call      dword ptr [edx + 0x5c]
008c2cf5 807d0b13                 cmp       byte ptr [ebp + 0xb], 0x13
008c2cf9 752a                     jne       0x8c2d25
008c2cfb 837dd4ff                 cmp       dword ptr [ebp - 0x2c], -1
008c2cff 7424                     je        0x8c2d25
008c2d01 8b16                     mov       edx, dword ptr [esi]
008c2d03 8d8570ffffff             lea       eax, [ebp - 0x90]
008c2d09 50                       push      eax
008c2d0a 8bce                     mov       ecx, esi
008c2d0c ff526c                   call      dword ptr [edx + 0x6c]
008c2d0f 8b16                     mov       edx, dword ptr [esi]
008c2d11 8d450f                   lea       eax, [ebp + 0xf]
008c2d14 50                       push      eax
008c2d15 8bce                     mov       ecx, esi
008c2d17 ff5250                   call      dword ptr [edx + 0x50]
008c2d1a 8b16                     mov       edx, dword ptr [esi]
008c2d1c 8d45e4                   lea       eax, [ebp - 0x1c]
008c2d1f 50                       push      eax
008c2d20 8bce                     mov       ecx, esi
008c2d22 ff525c                   call      dword ptr [edx + 0x5c]
008c2d25 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
008c2d28 51                       push      ecx
008c2d29 8d8da8feffff             lea       ecx, [ebp - 0x158]
008c2d2f e8dcd4b4ff               call      0x410210
008c2d34 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
008c2d37 8d4510                   lea       eax, [ebp + 0x10]
008c2d3a 50                       push      eax
008c2d3b 8d8db0feffff             lea       ecx, [ebp - 0x150]
008c2d41 895510                   mov       dword ptr [ebp + 0x10], edx
008c2d44 e81718b4ff               call      0x404560
008c2d49 8b4dc8                   mov       ecx, dword ptr [ebp - 0x38]
008c2d4c 8d5510                   lea       edx, [ebp + 0x10]
008c2d4f 894d10                   mov       dword ptr [ebp + 0x10], ecx
008c2d52 52                       push      edx
008c2d53 8d8db8feffff             lea       ecx, [ebp - 0x148]
008c2d59 e80218b4ff               call      0x404560
008c2d5e 8b45c0                   mov       eax, dword ptr [ebp - 0x40]
008c2d61 8d4d10                   lea       ecx, [ebp + 0x10]
008c2d64 51                       push      ecx
008c2d65 8d8dc0feffff             lea       ecx, [ebp - 0x140]
008c2d6b 894510                   mov       dword ptr [ebp + 0x10], eax
008c2d6e e8ed17b4ff               call      0x404560
008c2d73 8b55cc                   mov       edx, dword ptr [ebp - 0x34]
008c2d76 8d4510                   lea       eax, [ebp + 0x10]
008c2d79 50                       push      eax
008c2d7a 8d8dd0feffff             lea       ecx, [ebp - 0x130]
008c2d80 895510                   mov       dword ptr [ebp + 0x10], edx
008c2d83 e8d817b4ff               call      0x404560
008c2d88 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
008c2d8b 8d5510                   lea       edx, [ebp + 0x10]
008c2d8e 894d10                   mov       dword ptr [ebp + 0x10], ecx
008c2d91 52                       push      edx
008c2d92 8d8dd8feffff             lea       ecx, [ebp - 0x128]
008c2d98 e8c317b4ff               call      0x404560
008c2d9d 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c2da3 3bf3                     cmp       esi, ebx
008c2da5 0f84d4020000             je        0x8c307f
008c2dab 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c2db1 3bcb                     cmp       ecx, ebx
008c2db3 0f84c6020000             je        0x8c307f
008c2db9 0fb745d8                 movzx     eax, word ptr [ebp - 0x28]
008c2dbd 0fb755e8                 movzx     edx, word ptr [ebp - 0x18]
008c2dc1 53                       push      ebx
008c2dc2 686c52f500               push      0xf5526c
008c2dc7 681009f400               push      0xf40910
008c2dcc 53                       push      ebx
008c2dcd 50                       push      eax
008c2dce 52                       push      edx
008c2dcf e84c8ac4ff               call      0x50b820
008c2dd4 50                       push      eax
008c2dd5 e831df3300               call      0xc00d0b
008c2dda 53                       push      ebx
008c2ddb 688c52f500               push      0xf5528c
008c2de0 686c52f500               push      0xf5526c
008c2de5 8bf0                     mov       esi, eax
008c2de7 53                       push      ebx
008c2de8 56                       push      esi
008c2de9 e81ddf3300               call      0xc00d0b
008c2dee 83c428                   add       esp, 0x28
008c2df1 3bf3                     cmp       esi, ebx
008c2df3 8945e0                   mov       dword ptr [ebp - 0x20], eax
008c2df6 0f8483020000             je        0x8c307f
008c2dfc 8b45d4                   mov       eax, dword ptr [ebp - 0x2c]
008c2dff 83f8ff                   cmp       eax, -1
008c2e02 7557                     jne       0x8c2e5b
008c2e04 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c2e08 8b06                     mov       eax, dword ptr [esi]
008c2e0a 51                       push      ecx
008c2e0b 8bce                     mov       ecx, esi
008c2e0d ff9028040000             call      dword ptr [eax + 0x428]
008c2e13 85c0                     test      eax, eax
008c2e15 741c                     je        0x8c2e33
008c2e17 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c2e1b 8b16                     mov       edx, dword ptr [esi]
008c2e1d 50                       push      eax
008c2e1e 8bce                     mov       ecx, esi
008c2e20 ff9220040000             call      dword ptr [edx + 0x420]
008c2e26 3bc3                     cmp       eax, ebx
008c2e28 7409                     je        0x8c2e33
008c2e2a 8b10                     mov       edx, dword ptr [eax]
008c2e2c 6a01                     push      1
008c2e2e 8bc8                     mov       ecx, eax
008c2e30 ff5208                   call      dword ptr [edx + 8]
008c2e33 8b06                     mov       eax, dword ptr [esi]
008c2e35 6811010000               push      0x111
008c2e3a 8bce                     mov       ecx, esi
008c2e3c ff502c                   call      dword ptr [eax + 0x2c]
008c2e3f 84c0                     test      al, al
008c2e41 0f8467010000             je        0x8c2fae
008c2e47 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c2e4b 8b16                     mov       edx, dword ptr [esi]
008c2e4d 50                       push      eax
008c2e4e 8bce                     mov       ecx, esi
008c2e50 ff9210060000             call      dword ptr [edx + 0x610]
008c2e56 e953010000               jmp       0x8c2fae
008c2e5b 807d0b13                 cmp       byte ptr [ebp + 0xb], 0x13
008c2e5f 0f858b000000             jne       0x8c2ef0
008c2e65 50                       push      eax
008c2e66 e885d8caff               call      0x5706f0
008c2e6b 8b16                     mov       edx, dword ptr [esi]
008c2e6d 83c404                   add       esp, 4
008c2e70 6811010000               push      0x111
008c2e75 8bce                     mov       ecx, esi
008c2e77 894510                   mov       dword ptr [ebp + 0x10], eax
008c2e7a ff522c                   call      dword ptr [edx + 0x2c]
008c2e7d 84c0                     test      al, al
008c2e7f 746f                     je        0x8c2ef0
008c2e81 53                       push      ebx
008c2e82 688c52f500               push      0xf5528c
008c2e87 686c52f500               push      0xf5526c
008c2e8c 53                       push      ebx
008c2e8d 56                       push      esi
008c2e8e e878de3300               call      0xc00d0b
008c2e93 8bf8                     mov       edi, eax
008c2e95 83c414                   add       esp, 0x14
008c2e98 3bfb                     cmp       edi, ebx
008c2e9a 7454                     je        0x8c2ef0
008c2e9c 8a450f                   mov       al, byte ptr [ebp + 0xf]
008c2e9f 3c02                     cmp       al, 2
008c2ea1 750d                     jne       0x8c2eb0
008c2ea3 8b4510                   mov       eax, dword ptr [ebp + 0x10]
008c2ea6 50                       push      eax
008c2ea7 8bcf                     mov       ecx, edi
008c2ea9 e862e5c1ff               call      0x4e1410
008c2eae eb18                     jmp       0x8c2ec8
008c2eb0 3c01                     cmp       al, 1
008c2eb2 8b4510                   mov       eax, dword ptr [ebp + 0x10]
008c2eb5 0f94c1                   sete      cl
008c2eb8 8d9570ffffff             lea       edx, [ebp - 0x90]
008c2ebe 51                       push      ecx
008c2ebf 52                       push      edx
008c2ec0 50                       push      eax
008c2ec1 8bcf                     mov       ecx, edi
008c2ec3 e8187fc0ff               call      0x4cade0
008c2ec8 395de4                   cmp       dword ptr [ebp - 0x1c], ebx
008c2ecb 7623                     jbe       0x8c2ef0
008c2ecd 8b17                     mov       edx, dword ptr [edi]
008c2ecf 8bcf                     mov       ecx, edi
008c2ed1 ff923c060000             call      dword ptr [edx + 0x63c]
008c2ed7 85c0                     test      eax, eax
008c2ed9 7415                     je        0x8c2ef0
008c2edb 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
008c2ede 8b17                     mov       edx, dword ptr [edi]
008c2ee0 50                       push      eax
008c2ee1 8bcf                     mov       ecx, edi
008c2ee3 ff923c060000             call      dword ptr [edx + 0x63c]
008c2ee9 8bc8                     mov       ecx, eax
008c2eeb e84007c6ff               call      0x523630
008c2ef0 8d8db0feffff             lea       ecx, [ebp - 0x150]
008c2ef6 e865f1b3ff               call      0x402060
008c2efb 241f                     and       al, 0x1f
008c2efd 8d8dc8feffff             lea       ecx, [ebp - 0x138]
008c2f03 884513                   mov       byte ptr [ebp + 0x13], al
008c2f06 e855f1b3ff               call      0x402060
008c2f0b 8a4d13                   mov       cl, byte ptr [ebp + 0x13]
008c2f0e c0e005                   shl       al, 5
008c2f11 0ac8                     or        cl, al
008c2f13 884d10                   mov       byte ptr [ebp + 0x10], cl
008c2f16 8d8da8feffff             lea       ecx, [ebp - 0x158]
008c2f1c e83ff1b3ff               call      0x402060
008c2f21 8b4dcc                   mov       ecx, dword ptr [ebp - 0x34]
008c2f24 53                       push      ebx
008c2f25 686809f400               push      0xf40968
008c2f2a 685009f400               push      0xf40950
008c2f2f 53                       push      ebx
008c2f30 8bf8                     mov       edi, eax
008c2f32 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
008c2f35 6a01                     push      1
008c2f37 50                       push      eax
008c2f38 51                       push      ecx
008c2f39 8d8dc0feffff             lea       ecx, [ebp - 0x140]
008c2f3f e81cf1b3ff               call      0x402060
008c2f44 8b5510                   mov       edx, dword ptr [ebp + 0x10]
008c2f47 50                       push      eax
008c2f48 8b45d4                   mov       eax, dword ptr [ebp - 0x2c]
008c2f4b 53                       push      ebx
008c2f4c 52                       push      edx
008c2f4d 57                       push      edi
008c2f4e 50                       push      eax
008c2f4f e8ccc4cbff               call      0x57f420
008c2f54 83c420                   add       esp, 0x20
008c2f57 50                       push      eax
008c2f58 e8aedd3300               call      0xc00d0b
008c2f5d 8bf8                     mov       edi, eax
008c2f5f 83c414                   add       esp, 0x14
008c2f62 3bfb                     cmp       edi, ebx
008c2f64 7436                     je        0x8c2f9c
008c2f66 8b16                     mov       edx, dword ptr [esi]
008c2f68 6aff                     push      -1
008c2f6a 57                       push      edi
008c2f6b 8bce                     mov       ecx, esi
008c2f6d ff9218040000             call      dword ptr [edx + 0x418]
008c2f73 3bc3                     cmp       eax, ebx
008c2f75 7409                     je        0x8c2f80
008c2f77 8b10                     mov       edx, dword ptr [eax]
008c2f79 6a01                     push      1
008c2f7b 8bc8                     mov       ecx, eax
008c2f7d ff5208                   call      dword ptr [edx + 8]
008c2f80 8b45e0                   mov       eax, dword ptr [ebp - 0x20]
008c2f83 3bc3                     cmp       eax, ebx
008c2f85 0f84f4000000             je        0x8c307f
008c2f8b 3905d4f10401             cmp       dword ptr [0x104f1d4], eax
008c2f91 751b                     jne       0x8c2fae
008c2f93 8b07                     mov       eax, dword ptr [edi]
008c2f95 8bcf                     mov       ecx, edi
008c2f97 ff5068                   call      dword ptr [eax + 0x68]
008c2f9a eb12                     jmp       0x8c2fae
008c2f9c 8b4dd4                   mov       ecx, dword ptr [ebp - 0x2c]
008c2f9f 51                       push      ecx
008c2fa0 687c10e300               push      0xe3107c
008c2fa5 ff15bc2eff00             call      dword ptr [0xff2ebc]
008c2fab 83c408                   add       esp, 8
008c2fae 395de0                   cmp       dword ptr [ebp - 0x20], ebx
008c2fb1 0f84c8000000             je        0x8c307f
008c2fb7 8b0d48280001             mov       ecx, dword ptr [0x1002848]
008c2fbd 81c140100000             add       ecx, 0x1040
008c2fc3 e898f0b3ff               call      0x402060
008c2fc8 83f801                   cmp       eax, 1
008c2fcb 0f84ae000000             je        0x8c307f
008c2fd1 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c2fd5 52                       push      edx
008c2fd6 e8e575b9ff               call      0x45a5c0
008c2fdb 83c404                   add       esp, 4
008c2fde 84c0                     test      al, al
008c2fe0 0f8499000000             je        0x8c307f
008c2fe6 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
008c2fe9 8b0d3c310001             mov       ecx, dword ptr [0x100313c]
008c2fef 50                       push      eax
008c2ff0 e8db8cc9ff               call      0x55bcd0
008c2ff5 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c2ff9 8b55d4                   mov       edx, dword ptr [ebp - 0x2c]
008c2ffc 8d7810                   lea       edi, [eax + 0x10]
008c2fff 8954cf20                 mov       dword ptr [edi + ecx*8 + 0x20], edx
008c3003 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
008c3006 8b0d3c310001             mov       ecx, dword ptr [0x100313c]
008c300c 50                       push      eax
008c300d e8be8cc9ff               call      0x55bcd0
008c3012 8b8800020000             mov       ecx, dword ptr [eax + 0x200]
008c3018 3bcb                     cmp       ecx, ebx
008c301a 740a                     je        0x8c3026
008c301c 8b11                     mov       edx, dword ptr [ecx]
008c301e 53                       push      ebx
008c301f 57                       push      edi
008c3020 ff9298010000             call      dword ptr [edx + 0x198]
008c3026 8b45d8                   mov       eax, dword ptr [ebp - 0x28]
008c3029 8b0d3c310001             mov       ecx, dword ptr [0x100313c]
008c302f 53                       push      ebx
008c3030 50                       push      eax
008c3031 e89a8cc9ff               call      0x55bcd0
008c3036 8b0d78310001             mov       ecx, dword ptr [0x1003178]
008c303c 50                       push      eax
008c303d e88ea1bbff               call      0x47d1d0
008c3042 8b4dd8                   mov       ecx, dword ptr [ebp - 0x28]
008c3045 6a01                     push      1
008c3047 51                       push      ecx
008c3048 8b0d3c310001             mov       ecx, dword ptr [0x100313c]
008c304e 8bf8                     mov       edi, eax
008c3050 e87b8cc9ff               call      0x55bcd0
008c3055 8b0d78310001             mov       ecx, dword ptr [0x1003178]
008c305b 50                       push      eax
008c305c e86fa1bbff               call      0x47d1d0
008c3061 3bfb                     cmp       edi, ebx
008c3063 894510                   mov       dword ptr [ebp + 0x10], eax
008c3066 740b                     je        0x8c3073
008c3068 57                       push      edi
008c3069 8bce                     mov       ecx, esi
008c306b e8102fb7ff               call      0x435f80
008c3070 8b4510                   mov       eax, dword ptr [ebp + 0x10]
008c3073 3bc3                     cmp       eax, ebx
008c3075 7408                     je        0x8c307f
008c3077 50                       push      eax
008c3078 8bce                     mov       ecx, esi
008c307a e8312fb7ff               call      0x435fb0
008c307f 8d8da8feffff             lea       ecx, [ebp - 0x158]
008c3085 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
008c308c e80f13b4ff               call      0x4043a0
008c3091 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c3094 64890d00000000           mov       dword ptr fs:[0], ecx
008c309b 5f                       pop       edi
008c309c 5e                       pop       esi
008c309d 5b                       pop       ebx
008c309e 8be5                     mov       esp, ebp
008c30a0 5d                       pop       ebp
008c30a1 c20c00                   ret       0xc
008c30a4 a1d4f10401               mov       eax, dword ptr [0x104f1d4]
008c30a9 33db                     xor       ebx, ebx
008c30ab 3bc3                     cmp       eax, ebx
008c30ad 0f849d2d0000             je        0x8c5e50
008c30b3 8b16                     mov       edx, dword ptr [esi]
008c30b5 8d450b                   lea       eax, [ebp + 0xb]
008c30b8 50                       push      eax
008c30b9 8bce                     mov       ecx, esi
008c30bb 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c30be 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c30c1 ff5250                   call      dword ptr [edx + 0x50]
008c30c4 33ff                     xor       edi, edi
008c30c6 897d0c                   mov       dword ptr [ebp + 0xc], edi
008c30c9 8da42400000000           lea       esp, [esp]
008c30d0 8b16                     mov       edx, dword ptr [esi]
008c30d2 8d4510                   lea       eax, [ebp + 0x10]
008c30d5 50                       push      eax
008c30d6 8bce                     mov       ecx, esi
008c30d8 ff525c                   call      dword ptr [edx + 0x5c]
008c30db 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c30df 80bc31f8a5100001         cmp       byte ptr [ecx + esi + 0x10a5f8], 1
008c30e7 7540                     jne       0x8c3129
008c30e9 a148280001               mov       eax, dword ptr [0x1002848]
008c30ee 3bc3                     cmp       eax, ebx
008c30f0 7437                     je        0x8c3129
008c30f2 8d8840100000             lea       ecx, [eax + 0x1040]
008c30f8 e863efb3ff               call      0x402060
008c30fd 83f809                   cmp       eax, 9
008c3100 7474                     je        0x8c3176
008c3102 8b0d48280001             mov       ecx, dword ptr [0x1002848]
008c3108 81c140100000             add       ecx, 0x1040
008c310e e84defb3ff               call      0x402060
008c3113 83f804                   cmp       eax, 4
008c3116 7511                     jne       0x8c3129
008c3118 8b1548280001             mov       edx, dword ptr [0x1002848]
008c311e 8b8258100000             mov       eax, dword ptr [edx + 0x1058]
008c3124 395828                   cmp       dword ptr [eax + 0x28], ebx
008c3127 754d                     jne       0x8c3176
008c3129 8b0dd4f10401             mov       ecx, dword ptr [0x104f1d4]
008c312f 8b11                     mov       edx, dword ptr [ecx]
008c3131 57                       push      edi
008c3132 ff9228040000             call      dword ptr [edx + 0x428]
008c3138 8bf8                     mov       edi, eax
008c313a 3bfb                     cmp       edi, ebx
008c313c 740c                     je        0x8c314a
008c313e 8b07                     mov       eax, dword ptr [edi]
008c3140 8bcf                     mov       ecx, edi
008c3142 ff5014                   call      dword ptr [eax + 0x14]
008c3145 8b4008                   mov       eax, dword ptr [eax + 8]
008c3148 eb03                     jmp       0x8c314d
008c314a 83c8ff                   or        eax, 0xffffffff
008c314d 394510                   cmp       dword ptr [ebp + 0x10], eax
008c3150 7424                     je        0x8c3176
008c3152 3bfb                     cmp       edi, ebx
008c3154 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c3158 8b0dd4f10401             mov       ecx, dword ptr [0x104f1d4]
008c315e 8b11                     mov       edx, dword ptr [ecx]
008c3160 50                       push      eax
008c3161 7409                     je        0x8c316c
008c3163 57                       push      edi
008c3164 ff923c040000             call      dword ptr [edx + 0x43c]
008c316a eb0a                     jmp       0x8c3176
008c316c 8b450c                   mov       eax, dword ptr [ebp + 0xc]
008c316f 50                       push      eax
008c3170 ff9240040000             call      dword ptr [edx + 0x440]
008c3176 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
008c3179 47                       inc       edi
008c317a 83ff17                   cmp       edi, 0x17
008c317d 897d0c                   mov       dword ptr [ebp + 0xc], edi
008c3180 0f8c4affffff             jl        0x8c30d0
008c3186 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c318a c68431f8a5100001         mov       byte ptr [ecx + esi + 0x10a5f8], 1
008c3192 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c3195 64890d00000000           mov       dword ptr fs:[0], ecx
008c319c 5f                       pop       edi
008c319d 5e                       pop       esi
008c319e 5b                       pop       ebx
008c319f 8be5                     mov       esp, ebp
008c31a1 5d                       pop       ebp
008c31a2 c20c00                   ret       0xc
008c31a5 8b16                     mov       edx, dword ptr [esi]
008c31a7 33db                     xor       ebx, ebx
008c31a9 8d450c                   lea       eax, [ebp + 0xc]
008c31ac 50                       push      eax
008c31ad 8bce                     mov       ecx, esi
008c31af 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c31b2 895d08                   mov       dword ptr [ebp + 8], ebx
008c31b5 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c31b8 895dec                   mov       dword ptr [ebp - 0x14], ebx
008c31bb ff5254                   call      dword ptr [edx + 0x54]
008c31be 8b16                     mov       edx, dword ptr [esi]
008c31c0 8d4508                   lea       eax, [ebp + 8]
008c31c3 50                       push      eax
008c31c4 8bce                     mov       ecx, esi
008c31c6 ff5254                   call      dword ptr [edx + 0x54]
008c31c9 8b16                     mov       edx, dword ptr [esi]
008c31cb 8d4510                   lea       eax, [ebp + 0x10]
008c31ce 50                       push      eax
008c31cf 8bce                     mov       ecx, esi
008c31d1 ff525c                   call      dword ptr [edx + 0x5c]
008c31d4 8b16                     mov       edx, dword ptr [esi]
008c31d6 8d45ec                   lea       eax, [ebp - 0x14]
008c31d9 50                       push      eax
008c31da 8bce                     mov       ecx, esi
008c31dc ff525c                   call      dword ptr [edx + 0x5c]
008c31df 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c31e5 3bf3                     cmp       esi, ebx
008c31e7 0f84632c0000             je        0x8c5e50
008c31ed 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c31f3 3bcb                     cmp       ecx, ebx
008c31f5 0f84552c0000             je        0x8c5e50
008c31fb 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c31ff 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c3203 53                       push      ebx
008c3204 686c52f500               push      0xf5526c
008c3209 681009f400               push      0xf40910
008c320e 53                       push      ebx
008c320f 52                       push      edx
008c3210 50                       push      eax
008c3211 e80a86c4ff               call      0x50b820
008c3216 50                       push      eax
008c3217 e8efda3300               call      0xc00d0b
008c321c 83c414                   add       esp, 0x14
008c321f 3bc3                     cmp       eax, ebx
008c3221 0f84292c0000             je        0x8c5e50
008c3227 8b4d10                   mov       ecx, dword ptr [ebp + 0x10]
008c322a 8b10                     mov       edx, dword ptr [eax]
008c322c 6a01                     push      1
008c322e 53                       push      ebx
008c322f 51                       push      ecx
008c3230 8bc8                     mov       ecx, eax
008c3232 ff92ec030000             call      dword ptr [edx + 0x3ec]
008c3238 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c323b 64890d00000000           mov       dword ptr fs:[0], ecx
008c3242 5f                       pop       edi
008c3243 5e                       pop       esi
008c3244 5b                       pop       ebx
008c3245 8be5                     mov       esp, ebp
008c3247 5d                       pop       ebp
008c3248 c20c00                   ret       0xc
008c324b 8b16                     mov       edx, dword ptr [esi]
008c324d 33db                     xor       ebx, ebx
008c324f 8d450c                   lea       eax, [ebp + 0xc]
008c3252 50                       push      eax
008c3253 8bce                     mov       ecx, esi
008c3255 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c3258 895d08                   mov       dword ptr [ebp + 8], ebx
008c325b 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c325e ff5254                   call      dword ptr [edx + 0x54]
008c3261 8b16                     mov       edx, dword ptr [esi]
008c3263 8d4508                   lea       eax, [ebp + 8]
008c3266 50                       push      eax
008c3267 8bce                     mov       ecx, esi
008c3269 ff5254                   call      dword ptr [edx + 0x54]
008c326c 8b16                     mov       edx, dword ptr [esi]
008c326e 8d4510                   lea       eax, [ebp + 0x10]
008c3271 50                       push      eax
008c3272 8bce                     mov       ecx, esi
008c3274 ff525c                   call      dword ptr [edx + 0x5c]
008c3277 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c327d 3bf3                     cmp       esi, ebx
008c327f 0f84cb2b0000             je        0x8c5e50
008c3285 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c328b 3bcb                     cmp       ecx, ebx
008c328d 0f84bd2b0000             je        0x8c5e50
008c3293 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c3297 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c329b 53                       push      ebx
008c329c 686c52f500               push      0xf5526c
008c32a1 681009f400               push      0xf40910
008c32a6 53                       push      ebx
008c32a7 52                       push      edx
008c32a8 50                       push      eax
008c32a9 e87285c4ff               call      0x50b820
008c32ae 50                       push      eax
008c32af e857da3300               call      0xc00d0b
008c32b4 83c414                   add       esp, 0x14
008c32b7 3bc3                     cmp       eax, ebx
008c32b9 0f84912b0000             je        0x8c5e50
008c32bf 8b4d10                   mov       ecx, dword ptr [ebp + 0x10]
008c32c2 8b10                     mov       edx, dword ptr [eax]
008c32c4 6a01                     push      1
008c32c6 51                       push      ecx
008c32c7 8bc8                     mov       ecx, eax
008c32c9 ff92f4030000             call      dword ptr [edx + 0x3f4]
008c32cf 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c32d2 64890d00000000           mov       dword ptr fs:[0], ecx
008c32d9 5f                       pop       edi
008c32da 5e                       pop       esi
008c32db 5b                       pop       ebx
008c32dc 8be5                     mov       esp, ebp
008c32de 5d                       pop       ebp
008c32df c20c00                   ret       0xc
008c32e2 33db                     xor       ebx, ebx
008c32e4 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c32e7 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c32ea 895de0                   mov       dword ptr [ebp - 0x20], ebx
008c32ed 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c32f0 895dd4                   mov       dword ptr [ebp - 0x2c], ebx
008c32f3 895dd0                   mov       dword ptr [ebp - 0x30], ebx
008c32f6 895de4                   mov       dword ptr [ebp - 0x1c], ebx
008c32f9 895dd8                   mov       dword ptr [ebp - 0x28], ebx
008c32fc 895ddc                   mov       dword ptr [ebp - 0x24], ebx
008c32ff 895dcc                   mov       dword ptr [ebp - 0x34], ebx
008c3302 895d98                   mov       dword ptr [ebp - 0x68], ebx
008c3305 895d9c                   mov       dword ptr [ebp - 0x64], ebx
008c3308 895da0                   mov       dword ptr [ebp - 0x60], ebx
008c330b 8b16                     mov       edx, dword ptr [esi]
008c330d 8d45e0                   lea       eax, [ebp - 0x20]
008c3310 50                       push      eax
008c3311 8bce                     mov       ecx, esi
008c3313 c745fc06000000           mov       dword ptr [ebp - 4], 6
008c331a ff5254                   call      dword ptr [edx + 0x54]
008c331d 8b16                     mov       edx, dword ptr [esi]
008c331f 8d45e8                   lea       eax, [ebp - 0x18]
008c3322 50                       push      eax
008c3323 8bce                     mov       ecx, esi
008c3325 ff5254                   call      dword ptr [edx + 0x54]
008c3328 8b16                     mov       edx, dword ptr [esi]
008c332a 8d450f                   lea       eax, [ebp + 0xf]
008c332d 50                       push      eax
008c332e 8bce                     mov       ecx, esi
008c3330 ff5250                   call      dword ptr [edx + 0x50]
008c3333 8b16                     mov       edx, dword ptr [esi]
008c3335 8d45d4                   lea       eax, [ebp - 0x2c]
008c3338 50                       push      eax
008c3339 8bce                     mov       ecx, esi
008c333b ff5254                   call      dword ptr [edx + 0x54]
008c333e 8b16                     mov       edx, dword ptr [esi]
008c3340 8d45d0                   lea       eax, [ebp - 0x30]
008c3343 50                       push      eax
008c3344 8bce                     mov       ecx, esi
008c3346 ff5254                   call      dword ptr [edx + 0x54]
008c3349 8b16                     mov       edx, dword ptr [esi]
008c334b 8d45e4                   lea       eax, [ebp - 0x1c]
008c334e 50                       push      eax
008c334f 8bce                     mov       ecx, esi
008c3351 ff5254                   call      dword ptr [edx + 0x54]
008c3354 8b16                     mov       edx, dword ptr [esi]
008c3356 8d45dc                   lea       eax, [ebp - 0x24]
008c3359 50                       push      eax
008c335a 8bce                     mov       ecx, esi
008c335c ff5254                   call      dword ptr [edx + 0x54]
008c335f 8b16                     mov       edx, dword ptr [esi]
008c3361 8d45cc                   lea       eax, [ebp - 0x34]
008c3364 50                       push      eax
008c3365 8bce                     mov       ecx, esi
008c3367 ff5254                   call      dword ptr [edx + 0x54]
008c336a 8b16                     mov       edx, dword ptr [esi]
008c336c 8d45d8                   lea       eax, [ebp - 0x28]
008c336f 50                       push      eax
008c3370 8bce                     mov       ecx, esi
008c3372 ff5254                   call      dword ptr [edx + 0x54]
008c3375 8b16                     mov       edx, dword ptr [esi]
008c3377 8d450b                   lea       eax, [ebp + 0xb]
008c337a 50                       push      eax
008c337b 8bce                     mov       ecx, esi
008c337d ff5250                   call      dword ptr [edx + 0x50]
008c3380 8a450b                   mov       al, byte ptr [ebp + 0xb]
008c3383 33ff                     xor       edi, edi
008c3385 3ac3                     cmp       al, bl
008c3387 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c338a 7650                     jbe       0x8c33dc
008c338c 8d642400                 lea       esp, [esp]
008c3390 8b16                     mov       edx, dword ptr [esi]
008c3392 8d4510                   lea       eax, [ebp + 0x10]
008c3395 50                       push      eax
008c3396 8bce                     mov       ecx, esi
008c3398 ff5254                   call      dword ptr [edx + 0x54]
008c339b 0fbf4d10                 movsx     ecx, word ptr [ebp + 0x10]
008c339f 8d55ec                   lea       edx, [ebp - 0x14]
008c33a2 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c33a5 52                       push      edx
008c33a6 8d8d40ffffff             lea       ecx, [ebp - 0xc0]
008c33ac e89fedb3ff               call      0x402150
008c33b1 8d8540ffffff             lea       eax, [ebp - 0xc0]
008c33b7 50                       push      eax
008c33b8 8d4d94                   lea       ecx, [ebp - 0x6c]
008c33bb c645fc07                 mov       byte ptr [ebp - 4], 7
008c33bf e8ec9cbaff               call      0x46d0b0
008c33c4 8d8d40ffffff             lea       ecx, [ebp - 0xc0]
008c33ca c645fc06                 mov       byte ptr [ebp - 4], 6
008c33ce e83decb3ff               call      0x402010
008c33d3 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c33d7 47                       inc       edi
008c33d8 3bf9                     cmp       edi, ecx
008c33da 7cb4                     jl        0x8c3390
008c33dc 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c33e2 3bc3                     cmp       eax, ebx
008c33e4 0f84d5000000             je        0x8c34bf
008c33ea 8b88b0000000             mov       ecx, dword ptr [eax + 0xb0]
008c33f0 3bcb                     cmp       ecx, ebx
008c33f2 0f84c7000000             je        0x8c34bf
008c33f8 0fb755e8                 movzx     edx, word ptr [ebp - 0x18]
008c33fc 0fb745e0                 movzx     eax, word ptr [ebp - 0x20]
008c3400 53                       push      ebx
008c3401 686c52f500               push      0xf5526c
008c3406 681009f400               push      0xf40910
008c340b 53                       push      ebx
008c340c 52                       push      edx
008c340d 50                       push      eax
008c340e e80d84c4ff               call      0x50b820
008c3413 50                       push      eax
008c3414 e8f2d83300               call      0xc00d0b
008c3419 83c414                   add       esp, 0x14
008c341c 3bc3                     cmp       eax, ebx
008c341e 8945ec                   mov       dword ptr [ebp - 0x14], eax
008c3421 0f8498000000             je        0x8c34bf
008c3427 8b45d0                   mov       eax, dword ptr [ebp - 0x30]
008c342a 33ff                     xor       edi, edi
008c342c 663dffff                 cmp       ax, 0xffff
008c3430 7431                     je        0x8c3463
008c3432 0fb755e4                 movzx     edx, word ptr [ebp - 0x1c]
008c3436 8b8e60a01000             mov       ecx, dword ptr [esi + 0x10a060]
008c343c 8b89b0000000             mov       ecx, dword ptr [ecx + 0xb0]
008c3442 53                       push      ebx
008c3443 687c28f400               push      0xf4287c
008c3448 681009f400               push      0xf40910
008c344d 53                       push      ebx
008c344e 0fb7c0                   movzx     eax, ax
008c3451 52                       push      edx
008c3452 50                       push      eax
008c3453 e8c883c4ff               call      0x50b820
008c3458 50                       push      eax
008c3459 e8add83300               call      0xc00d0b
008c345e 83c414                   add       esp, 0x14
008c3461 8bf8                     mov       edi, eax
008c3463 8b55dc                   mov       edx, dword ptr [ebp - 0x24]
008c3466 6681faffff               cmp       dx, 0xffff
008c346b 8bc7                     mov       eax, edi
008c346d 742f                     je        0x8c349e
008c346f 0fb745cc                 movzx     eax, word ptr [ebp - 0x34]
008c3473 8b8e60a01000             mov       ecx, dword ptr [esi + 0x10a060]
008c3479 8b89b0000000             mov       ecx, dword ptr [ecx + 0xb0]
008c347f 53                       push      ebx
008c3480 687c28f400               push      0xf4287c
008c3485 681009f400               push      0xf40910
008c348a 53                       push      ebx
008c348b 0fb7d2                   movzx     edx, dx
008c348e 50                       push      eax
008c348f 52                       push      edx
008c3490 e88b83c4ff               call      0x50b820
008c3495 50                       push      eax
008c3496 e870d83300               call      0xc00d0b
008c349b 83c414                   add       esp, 0x14
008c349e 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
008c34a1 8b11                     mov       edx, dword ptr [ecx]
008c34a3 50                       push      eax
008c34a4 8d4594                   lea       eax, [ebp - 0x6c]
008c34a7 50                       push      eax
008c34a8 0fb745d8                 movzx     eax, word ptr [ebp - 0x28]
008c34ac 50                       push      eax
008c34ad 0fb745d4                 movzx     eax, word ptr [ebp - 0x2c]
008c34b1 53                       push      ebx
008c34b2 57                       push      edi
008c34b3 50                       push      eax
008c34b4 0fb6450f                 movzx     eax, byte ptr [ebp + 0xf]
008c34b8 50                       push      eax
008c34b9 ff9208040000             call      dword ptr [edx + 0x408]
008c34bf 8b7598                   mov       esi, dword ptr [ebp - 0x68]
008c34c2 83cfff                   or        edi, 0xffffffff
008c34c5 3bf3                     cmp       esi, ebx
008c34c7 897dfc                   mov       dword ptr [ebp - 4], edi
008c34ca 0f8480290000             je        0x8c5e50
008c34d0 8b5d9c                   mov       ebx, dword ptr [ebp - 0x64]
008c34d3 3bf3                     cmp       esi, ebx
008c34d5 8975ec                   mov       dword ptr [ebp - 0x14], esi
008c34d8 7430                     je        0x8c350a
008c34da 8d9b00000000             lea       ebx, [ebx]
008c34e0 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
008c34e6 56                       push      esi
008c34e7 c745fc08000000           mov       dword ptr [ebp - 4], 8
008c34ee e8ad3e2500               call      0xb173a0
008c34f3 8bce                     mov       ecx, esi
008c34f5 897dfc                   mov       dword ptr [ebp - 4], edi
008c34f8 e883452500               call      0xb17a80
008c34fd 83c608                   add       esi, 8
008c3500 3bf3                     cmp       esi, ebx
008c3502 8975ec                   mov       dword ptr [ebp - 0x14], esi
008c3505 75d9                     jne       0x8c34e0
008c3507 8b7598                   mov       esi, dword ptr [ebp - 0x68]
008c350a 56                       push      esi
008c350b e8cdca3300               call      0xbfffdd
008c3510 83c404                   add       esp, 4
008c3513 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c3516 64890d00000000           mov       dword ptr fs:[0], ecx
008c351d 5f                       pop       edi
008c351e 5e                       pop       esi
008c351f 5b                       pop       ebx
008c3520 8be5                     mov       esp, ebp
008c3522 5d                       pop       ebp
008c3523 c20c00                   ret       0xc
008c3526 8b16                     mov       edx, dword ptr [esi]
008c3528 33db                     xor       ebx, ebx
008c352a 8d45e8                   lea       eax, [ebp - 0x18]
008c352d 50                       push      eax
008c352e 8bce                     mov       ecx, esi
008c3530 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c3533 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c3536 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c3539 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c353c ff5254                   call      dword ptr [edx + 0x54]
008c353f 8b16                     mov       edx, dword ptr [esi]
008c3541 8d4510                   lea       eax, [ebp + 0x10]
008c3544 50                       push      eax
008c3545 8bce                     mov       ecx, esi
008c3547 ff5254                   call      dword ptr [edx + 0x54]
008c354a 8b16                     mov       edx, dword ptr [esi]
008c354c 8d450f                   lea       eax, [ebp + 0xf]
008c354f 50                       push      eax
008c3550 8bce                     mov       ecx, esi
008c3552 ff5250                   call      dword ptr [edx + 0x50]
008c3555 8b16                     mov       edx, dword ptr [esi]
008c3557 8d450b                   lea       eax, [ebp + 0xb]
008c355a 50                       push      eax
008c355b 8bce                     mov       ecx, esi
008c355d ff5250                   call      dword ptr [edx + 0x50]
008c3560 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c3566 3bf3                     cmp       esi, ebx
008c3568 0f84e2280000             je        0x8c5e50
008c356e 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c3574 3bcb                     cmp       ecx, ebx
008c3576 0f84d4280000             je        0x8c5e50
008c357c 0fb75510                 movzx     edx, word ptr [ebp + 0x10]
008c3580 0fb745e8                 movzx     eax, word ptr [ebp - 0x18]
008c3584 53                       push      ebx
008c3585 686c52f500               push      0xf5526c
008c358a 681009f400               push      0xf40910
008c358f 53                       push      ebx
008c3590 52                       push      edx
008c3591 50                       push      eax
008c3592 e88982c4ff               call      0x50b820
008c3597 50                       push      eax
008c3598 e86ed73300               call      0xc00d0b
008c359d 8bf0                     mov       esi, eax
008c359f 83c414                   add       esp, 0x14
008c35a2 3bf3                     cmp       esi, ebx
008c35a4 0f84a6280000             je        0x8c5e50
008c35aa 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c35ae 8b06                     mov       eax, dword ptr [esi]
008c35b0 8d55ec                   lea       edx, [ebp - 0x14]
008c35b3 52                       push      edx
008c35b4 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c35b7 53                       push      ebx
008c35b8 8bce                     mov       ecx, esi
008c35ba ff9044030000             call      dword ptr [eax + 0x344]
008c35c0 8bc8                     mov       ecx, eax
008c35c2 e8990fb4ff               call      0x404560
008c35c7 8b16                     mov       edx, dword ptr [esi]
008c35c9 53                       push      ebx
008c35ca 8bce                     mov       ecx, esi
008c35cc ff9248030000             call      dword ptr [edx + 0x348]
008c35d2 53                       push      ebx
008c35d3 688c52f500               push      0xf5528c
008c35d8 686c52f500               push      0xf5526c
008c35dd 53                       push      ebx
008c35de 56                       push      esi
008c35df e827d73300               call      0xc00d0b
008c35e4 8bf0                     mov       esi, eax
008c35e6 83c414                   add       esp, 0x14
008c35e9 3bf3                     cmp       esi, ebx
008c35eb 0f845f280000             je        0x8c5e50
008c35f1 8b4510                   mov       eax, dword ptr [ebp + 0x10]
008c35f4 8b0d3c310001             mov       ecx, dword ptr [0x100313c]
008c35fa 50                       push      eax
008c35fb e8d086c9ff               call      0x55bcd0
008c3600 8bf8                     mov       edi, eax
008c3602 3bfb                     cmp       edi, ebx
008c3604 0f8446280000             je        0x8c5e50
008c360a 8a4d0b                   mov       cl, byte ptr [ebp + 0xb]
008c360d 3a4d0f                   cmp       cl, byte ptr [ebp + 0xf]
008c3610 0f861c010000             jbe       0x8c3732
008c3616 3935d4f10401             cmp       dword ptr [0x104f1d4], esi
008c361c 0f85c2000000             jne       0x8c36e4
008c3622 8b0d48280001             mov       ecx, dword ptr [0x1002848]
008c3628 e8f36fb7ff               call      0x43a620
008c362d 84c0                     test      al, al
008c362f 0f8484000000             je        0x8c36b9
008c3635 8a450b                   mov       al, byte ptr [ebp + 0xb]
008c3638 3c0a                     cmp       al, 0xa
008c363a 7408                     je        0x8c3644
008c363c 3c14                     cmp       al, 0x14
008c363e 7404                     je        0x8c3644
008c3640 3c1e                     cmp       al, 0x1e
008c3642 7575                     jne       0x8c36b9
008c3644 53                       push      ebx
008c3645 53                       push      ebx
008c3646 8b16                     mov       edx, dword ptr [esi]
008c3648 53                       push      ebx
008c3649 53                       push      ebx
008c364a 53                       push      ebx
008c364b 6a04                     push      4
008c364d 53                       push      ebx
008c364e 53                       push      ebx
008c364f 53                       push      ebx
008c3650 53                       push      ebx
008c3651 53                       push      ebx
008c3652 6a04                     push      4
008c3654 6881bb0000               push      0xbb81
008c3659 8bce                     mov       ecx, esi
008c365b ff92b8020000             call      dword ptr [edx + 0x2b8]
008c3661 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c3665 50                       push      eax
008c3666 683ba40000               push      0xa43b
008c366b e8d0db1800               call      0xa51240
008c3670 83c404                   add       esp, 4
008c3673 50                       push      eax
008c3674 8d8da8f4ffff             lea       ecx, [ebp - 0xb58]
008c367a 6800080000               push      0x800
008c367f 51                       push      ecx
008c3680 e86be7b3ff               call      0x401df0
008c3685 a16c310001               mov       eax, dword ptr [0x100316c]
008c368a 8b4864                   mov       ecx, dword ptr [eax + 0x64]
008c368d 83c410                   add       esp, 0x10
008c3690 53                       push      ebx
008c3691 53                       push      ebx
008c3692 6a1f                     push      0x1f
008c3694 68e6c89bff               push      0xff9bc8e6
008c3699 8d95a8f4ffff             lea       edx, [ebp - 0xb58]
008c369f 52                       push      edx
008c36a0 e86b900f00               call      0x9bc710
008c36a5 8b0d6c310001             mov       ecx, dword ptr [0x100316c]
008c36ab 53                       push      ebx
008c36ac 53                       push      ebx
008c36ad 6894000000               push      0x94
008c36b2 e8f9c20000               call      0x8cf9b0
008c36b7 eb1c                     jmp       0x8c36d5
008c36b9 53                       push      ebx
008c36ba 53                       push      ebx
008c36bb 8b16                     mov       edx, dword ptr [esi]
008c36bd 53                       push      ebx
008c36be 53                       push      ebx
008c36bf 53                       push      ebx
008c36c0 6a04                     push      4
008c36c2 53                       push      ebx
008c36c3 53                       push      ebx
008c36c4 53                       push      ebx
008c36c5 53                       push      ebx
008c36c6 53                       push      ebx
008c36c7 53                       push      ebx
008c36c8 6881bb0000               push      0xbb81
008c36cd 8bce                     mov       ecx, esi
008c36cf ff92b8020000             call      dword ptr [edx + 0x2b8]
008c36d5 a16c310001               mov       eax, dword ptr [0x100316c]
008c36da 8b4858                   mov       ecx, dword ptr [eax + 0x58]
008c36dd 6a01                     push      1
008c36df e8dc280000               call      0x8c5fc0
008c36e4 8d4f10                   lea       ecx, [edi + 0x10]
008c36e7 e804fa1800               call      0xa530f0
008c36ec 0fb64d0b                 movzx     ecx, byte ptr [ebp + 0xb]
008c36f0 51                       push      ecx
008c36f1 50                       push      eax
008c36f2 68f6010000               push      0x1f6
008c36f7 e844db1800               call      0xa51240
008c36fc 83c404                   add       esp, 4
008c36ff 50                       push      eax
008c3700 8d95a8fcffff             lea       edx, [ebp - 0x358]
008c3706 6800020000               push      0x200
008c370b 52                       push      edx
008c370c e8dfe6b3ff               call      0x401df0
008c3711 8b0d6c310001             mov       ecx, dword ptr [0x100316c]
008c3717 8b4964                   mov       ecx, dword ptr [ecx + 0x64]
008c371a 83c414                   add       esp, 0x14
008c371d 53                       push      ebx
008c371e 53                       push      ebx
008c371f 6a1f                     push      0x1f
008c3721 68e6c89bff               push      0xff9bc8e6
008c3726 8d85a8fcffff             lea       eax, [ebp - 0x358]
008c372c 50                       push      eax
008c372d e8de8f0f00               call      0x9bc710
008c3732 0fb6550b                 movzx     edx, byte ptr [ebp + 0xb]
008c3736 8d45ec                   lea       eax, [ebp - 0x14]
008c3739 50                       push      eax
008c373a 8d4f24                   lea       ecx, [edi + 0x24]
008c373d 8955ec                   mov       dword ptr [ebp - 0x14], edx
008c3740 e81b0eb4ff               call      0x404560
008c3745 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c3748 64890d00000000           mov       dword ptr fs:[0], ecx
008c374f 5f                       pop       edi
008c3750 5e                       pop       esi
008c3751 5b                       pop       ebx
008c3752 8be5                     mov       esp, ebp
008c3754 5d                       pop       ebp
008c3755 c20c00                   ret       0xc
008c3758 8b16                     mov       edx, dword ptr [esi]
008c375a 33db                     xor       ebx, ebx
008c375c 8d450c                   lea       eax, [ebp + 0xc]
008c375f 50                       push      eax
008c3760 8bce                     mov       ecx, esi
008c3762 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c3765 895d08                   mov       dword ptr [ebp + 8], ebx
008c3768 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c376b ff5254                   call      dword ptr [edx + 0x54]
008c376e 8b16                     mov       edx, dword ptr [esi]
008c3770 8d4508                   lea       eax, [ebp + 8]
008c3773 50                       push      eax
008c3774 8bce                     mov       ecx, esi
008c3776 ff5254                   call      dword ptr [edx + 0x54]
008c3779 8b16                     mov       edx, dword ptr [esi]
008c377b 8d4510                   lea       eax, [ebp + 0x10]
008c377e 50                       push      eax
008c377f 8bce                     mov       ecx, esi
008c3781 ff525c                   call      dword ptr [edx + 0x5c]
008c3784 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c378a 3bf3                     cmp       esi, ebx
008c378c 0f84be260000             je        0x8c5e50
008c3792 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c3798 3bcb                     cmp       ecx, ebx
008c379a 0f84b0260000             je        0x8c5e50
008c37a0 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c37a4 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c37a8 53                       push      ebx
008c37a9 687c28f400               push      0xf4287c
008c37ae 681009f400               push      0xf40910
008c37b3 53                       push      ebx
008c37b4 52                       push      edx
008c37b5 50                       push      eax
008c37b6 e86580c4ff               call      0x50b820
008c37bb 50                       push      eax
008c37bc e84ad53300               call      0xc00d0b
008c37c1 83c414                   add       esp, 0x14
008c37c4 3bc3                     cmp       eax, ebx
008c37c6 0f8484260000             je        0x8c5e50
008c37cc db4510                   fild      dword ptr [ebp + 0x10]
008c37cf 8b10                     mov       edx, dword ptr [eax]
008c37d1 8d4dec                   lea       ecx, [ebp - 0x14]
008c37d4 51                       push      ecx
008c37d5 8bc8                     mov       ecx, eax
008c37d7 d95dec                   fstp      dword ptr [ebp - 0x14]
008c37da ff929c010000             call      dword ptr [edx + 0x19c]
008c37e0 8bc8                     mov       ecx, eax
008c37e2 e82931baff               call      0x466910
008c37e7 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c37ea 64890d00000000           mov       dword ptr fs:[0], ecx
008c37f1 5f                       pop       edi
008c37f2 5e                       pop       esi
008c37f3 5b                       pop       ebx
008c37f4 8be5                     mov       esp, ebp
008c37f6 5d                       pop       ebp
008c37f7 c20c00                   ret       0xc
008c37fa 8b06                     mov       eax, dword ptr [esi]
008c37fc 8d4d0c                   lea       ecx, [ebp + 0xc]
008c37ff 33db                     xor       ebx, ebx
008c3801 51                       push      ecx
008c3802 8bce                     mov       ecx, esi
008c3804 895d0c                   mov       dword ptr [ebp + 0xc], ebx
008c3807 895d08                   mov       dword ptr [ebp + 8], ebx
008c380a 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c380d ff5054                   call      dword ptr [eax + 0x54]
008c3810 8b16                     mov       edx, dword ptr [esi]
008c3812 8d4508                   lea       eax, [ebp + 8]
008c3815 50                       push      eax
008c3816 8bce                     mov       ecx, esi
008c3818 ff5254                   call      dword ptr [edx + 0x54]
008c381b 8b16                     mov       edx, dword ptr [esi]
008c381d 8d4510                   lea       eax, [ebp + 0x10]
008c3820 50                       push      eax
008c3821 8bce                     mov       ecx, esi
008c3823 ff5254                   call      dword ptr [edx + 0x54]
008c3826 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c382c 3bf3                     cmp       esi, ebx
008c382e 0f841c260000             je        0x8c5e50
008c3834 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c383a 3bcb                     cmp       ecx, ebx
008c383c 0f840e260000             je        0x8c5e50
008c3842 0fb75508                 movzx     edx, word ptr [ebp + 8]
008c3846 0fb7450c                 movzx     eax, word ptr [ebp + 0xc]
008c384a 53                       push      ebx
008c384b 687c28f400               push      0xf4287c
008c3850 681009f400               push      0xf40910
008c3855 53                       push      ebx
008c3856 52                       push      edx
008c3857 50                       push      eax
008c3858 e8c37fc4ff               call      0x50b820
008c385d 50                       push      eax
008c385e e8a8d43300               call      0xc00d0b
008c3863 83c414                   add       esp, 0x14
008c3866 3bc3                     cmp       eax, ebx
008c3868 0f84e2250000             je        0x8c5e50
008c386e 0fbf4d10                 movsx     ecx, word ptr [ebp + 0x10]
008c3872 8d55ec                   lea       edx, [ebp - 0x14]
008c3875 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c3878 52                       push      edx
008c3879 8b10                     mov       edx, dword ptr [eax]
008c387b 8bc8                     mov       ecx, eax
008c387d ff929c010000             call      dword ptr [edx + 0x19c]
008c3883 8bc8                     mov       ecx, eax
008c3885 83c110                   add       ecx, 0x10
008c3888 e883c3b4ff               call      0x40fc10
008c388d 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c3890 64890d00000000           mov       dword ptr fs:[0], ecx
008c3897 5f                       pop       edi
008c3898 5e                       pop       esi
008c3899 5b                       pop       ebx
008c389a 8be5                     mov       esp, ebp
008c389c 5d                       pop       ebp
008c389d c20c00                   ret       0xc
008c38a0 8b06                     mov       eax, dword ptr [esi]
008c38a2 33db                     xor       ebx, ebx
008c38a4 8d4de8                   lea       ecx, [ebp - 0x18]
008c38a7 51                       push      ecx
008c38a8 8bce                     mov       ecx, esi
008c38aa 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c38ad 885d0f                   mov       byte ptr [ebp + 0xf], bl
008c38b0 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c38b3 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c38b6 895de0                   mov       dword ptr [ebp - 0x20], ebx
008c38b9 ff5054                   call      dword ptr [eax + 0x54]
008c38bc 8b16                     mov       edx, dword ptr [esi]
008c38be 8d4510                   lea       eax, [ebp + 0x10]
008c38c1 50                       push      eax
008c38c2 8bce                     mov       ecx, esi
008c38c4 ff5254                   call      dword ptr [edx + 0x54]
008c38c7 8b16                     mov       edx, dword ptr [esi]
008c38c9 8d450b                   lea       eax, [ebp + 0xb]
008c38cc 50                       push      eax
008c38cd 8bce                     mov       ecx, esi
008c38cf ff5250                   call      dword ptr [edx + 0x50]
008c38d2 8b16                     mov       edx, dword ptr [esi]
008c38d4 8d45e0                   lea       eax, [ebp - 0x20]
008c38d7 50                       push      eax
008c38d8 8bce                     mov       ecx, esi
008c38da ff5254                   call      dword ptr [edx + 0x54]
008c38dd 8b16                     mov       edx, dword ptr [esi]
008c38df 8d450f                   lea       eax, [ebp + 0xf]
008c38e2 50                       push      eax
008c38e3 8bce                     mov       ecx, esi
008c38e5 ff5250                   call      dword ptr [edx + 0x50]
008c38e8 8bb660a01000             mov       esi, dword ptr [esi + 0x10a060]
008c38ee 3bf3                     cmp       esi, ebx
008c38f0 0f845a250000             je        0x8c5e50
008c38f6 8b8eb0000000             mov       ecx, dword ptr [esi + 0xb0]
008c38fc 3bcb                     cmp       ecx, ebx
008c38fe 0f844c250000             je        0x8c5e50
008c3904 0fb75510                 movzx     edx, word ptr [ebp + 0x10]
008c3908 0fb745e8                 movzx     eax, word ptr [ebp - 0x18]
008c390c 53                       push      ebx
008c390d 687c28f400               push      0xf4287c
008c3912 681009f400               push      0xf40910
008c3917 53                       push      ebx
008c3918 52                       push      edx
008c3919 50                       push      eax
008c391a e8017fc4ff               call      0x50b820
008c391f 50                       push      eax
008c3920 e8e6d33300               call      0xc00d0b
008c3925 83c414                   add       esp, 0x14
008c3928 3bc3                     cmp       eax, ebx
008c392a 0f8420250000             je        0x8c5e50
008c3930 8b10                     mov       edx, dword ptr [eax]
008c3932 8bc8                     mov       ecx, eax
008c3934 ff929c010000             call      dword ptr [edx + 0x19c]
008c393a 8bf0                     mov       esi, eax
008c393c 8d4648                   lea       eax, [esi + 0x48]
008c393f 90                       nop       
008c3940 833812                   cmp       dword ptr [eax], 0x12
008c3943 741c                     je        0x8c3961
008c3945 43                       inc       ebx
008c3946 83c004                   add       eax, 4
008c3949 83fb03                   cmp       ebx, 3
008c394c 7cf2                     jl        0x8c3940
008c394e 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c3951 64890d00000000           mov       dword ptr fs:[0], ecx
008c3958 5f                       pop       edi
008c3959 5e                       pop       esi
008c395a 5b                       pop       ebx
008c395b 8be5                     mov       esp, ebp
008c395d 5d                       pop       ebp
008c395e c20c00                   ret       0xc
008c3961 0fb6450b                 movzx     eax, byte ptr [ebp + 0xb]
008c3965 89449e48                 mov       dword ptr [esi + ebx*4 + 0x48], eax
008c3969 0fb74de0                 movzx     ecx, word ptr [ebp - 0x20]
008c396d 894dec                   mov       dword ptr [ebp - 0x14], ecx
008c3970 8d55ec                   lea       edx, [ebp - 0x14]
008c3973 db45ec                   fild      dword ptr [ebp - 0x14]
008c3976 52                       push      edx
008c3977 8d4cde54                 lea       ecx, [esi + ebx*8 + 0x54]
008c397b d80dac10cc00             fmul      dword ptr [0xcc10ac]
008c3981 d95dec                   fstp      dword ptr [ebp - 0x14]
008c3984 e8d70bb4ff               call      0x404560
008c3989 0fb6450f                 movzx     eax, byte ptr [ebp + 0xf]
008c398d 8d4dec                   lea       ecx, [ebp - 0x14]
008c3990 51                       push      ecx
008c3991 8d4cde6c                 lea       ecx, [esi + ebx*8 + 0x6c]
008c3995 8945ec                   mov       dword ptr [ebp - 0x14], eax
008c3998 e8c30bb4ff               call      0x404560
008c399d 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
008c39a0 64890d00000000           mov       dword ptr fs:[0], ecx
008c39a7 5f                       pop       edi
008c39a8 5e                       pop       esi
008c39a9 5b                       pop       ebx
008c39aa 8be5                     mov       esp, ebp
008c39ac 5d                       pop       ebp
008c39ad c20c00                   ret       0xc
008c39b0 33db                     xor       ebx, ebx
008c39b2 8d8d5cffffff             lea       ecx, [ebp - 0xa4]
008c39b8 885d0b                   mov       byte ptr [ebp + 0xb], bl
008c39bb 895de8                   mov       dword ptr [ebp - 0x18], ebx
008c39be 895dd0                   mov       dword ptr [ebp - 0x30], ebx
008c39c1 895de4                   mov       dword ptr [ebp - 0x1c], ebx
008c39c4 895d10                   mov       dword ptr [ebp + 0x10], ebx
008c39c7 895de0                   mov       dword ptr [ebp - 0x20], ebx
008c39ca e8e138baff               call      0x4672b0
008c39cf 8b16                     mov       edx, dword ptr [esi]
008c39d1 8d45e8                   lea       eax, [ebp - 0x18]
008c39d4 50                       push      eax
008c39d5 8bce                     mov       ecx, esi
008c39d7 c745fc09000000           mov       dword ptr [ebp - 4], 9
008c39de ff5254                   call      dword ptr [edx + 0x54]
008c39e1 8b16                     mov       edx, dword ptr [esi]
008c39e3 8d45d0                   lea       eax, [ebp - 0x30]
008c39e6 50                       push      eax
008c39e7 8bce                     mov       ecx, esi
008c39e9 ff5254                   call      dword ptr [edx + 0x54]
008c39ec 8b16                     mov       edx, dword ptr [esi]
008c39ee 8d45e4                   lea       eax, [ebp - 0x1c]
008c39f1 50                       push      eax
008c39f2 8bce                     mov       ecx, esi
008c39f4 ff5254                   call      dword ptr [edx + 0x54]
008c39f7 8b16                     mov       edx, dword ptr [esi]
008c39f9 8d4510                   lea       eax, [ebp + 0x10]
008c39fc 50                       push      eax
008c39fd 8bce                     mov       ecx, esi
008c39ff ff5254                   call      dword ptr [edx + 0x54]
008c3a02 8b16                     mov       edx, dword ptr [esi]
008c3a04 6a04                     push      4
008c3a06 8d45ec                   lea       eax, [ebp - 0x14]
008c3a09 50                       push      eax
008c3a0a 8bce                     mov       ecx, esi
008c3a0c ff5264                   call      dword ptr [edx + 0x64]
008c3a0f 8d4dec                   lea       ecx, [ebp - 0x14]
008c3a12 51                       push      ecx
008c3a13 8d8d08ffffff             lea       ecx, [ebp - 0xf8]
008c3a19 e8f295b8ff               call      0x44d010
008c3a1e 50                       push      eax
008c3a1f 8d8d5cffffff             lea       ecx, [ebp - 0xa4]
008c3a25 e8860bb4ff               call      0x4045b0
008c3a2a 8d8d08ffffff             lea       ecx, [ebp - 0xf8]
008c3a30 e8dbe5b3ff               call      0x402010
008c3a35 8b16                     mov       edx, dword ptr [esi]
008c3a37 6a02                     push      2
008c3a39 8d450e                   lea       eax, [ebp + 0xe]
008c3a3c 50                       push      eax
008c3a3d 8bce                     mov       ecx, esi
008c3a3f ff5264                   call      dword ptr [edx + 0x64]
008c3a42 0fbf4d0e                 movsx     ecx, word ptr [ebp + 0xe]
008c3a46 894df0                   mov       dword ptr [ebp - 0x10], ecx
008c3a49 8d55f0                   lea       edx, [ebp - 0x10]
008c3a4c db45f0                   fild      dword ptr [ebp - 0x10]
008c3a4f 52                       push      edx
008c3a50 8d8df8feffff             lea       ecx, [ebp - 0x108]
008c3a56 d95df0                   fstp      dword ptr [ebp - 0x10]
008c3a59 e8b295b8ff               call      0x44d010
008c3a5e 50                       push      eax
008c3a5f 8d8d64ffffff             lea       ecx, [ebp - 0x9c]
008c3a65 e8460bb4ff               call      0x4045b0
008c3a6a 8d8df8feffff             lea       ecx, [ebp - 0x108]
008c3a70 e89be5b3ff               call      0x402010
008c3a75 8b06                     mov       eax, dword ptr [esi]
008c3a77 6a02                     push      2
008c3a79 8d4d0e                   lea       ecx, [ebp + 0xe]
008c3a7c 51                       push      ecx
008c3a7d 8bce                     mov       ecx, esi
008c3a7f ff5064                   call      dword ptr [eax + 0x64]
008c3a82 0fbf550e                 movsx     edx, word ptr [ebp + 0xe]
008c3a86 8955f0                   mov       dword ptr [ebp - 0x10], edx
008c3a89 8d45f0                   lea       eax, [ebp - 0x10]
008c3a8c db45f0                   fild      dword ptr [ebp - 0x10]
008c3a8f 50                       push      eax
008c3a90 8d8d00ffffff             lea       ecx, [ebp - 0x100]
008c3a96 d95df0                   fstp      dword ptr [ebp - 0x10]
008c3a99 e87295b8ff               call      0x44d010
008c3a9e 50                       push      eax
008c3a9f 8d8d6cffffff             lea       ecx, [ebp - 0x94]
008c3aa5 e8060bb4ff               call      0x4045b0
008c3aaa 8d8d00ffffff             lea       ecx, [ebp - 0x100]
008c3ab0 e85be5b3ff               call      0x402010
008c3ab5 8b16                     mov       edx, dword ptr [esi]
008c3ab7 6a02                     push      2
008c3ab9 8d450e                   lea       eax, [ebp + 0xe]
008c3abc 50                       push      eax
008c3abd 8bce                     mov       ecx, esi
008c3abf ff5264                   call      dword ptr [edx + 0x64]
008c3ac2 0fbf4d0e                 movsx     ecx, word ptr [ebp + 0xe]
008c3ac6 894df0                   mov       dword ptr [ebp - 0x10], ecx
008c3ac9 8d55f0                   lea       edx, [ebp - 0x10]
008c3acc db45f0                   fild      dword ptr [ebp - 0x10]
008c3acf 52                       push      edx
008c3ad0 8d8d18ffffff             lea       ecx, [ebp - 0xe8]
008c3ad6 d95df0                   fstp      dword ptr [ebp - 0x10]
008c3ad9 e83295b8ff               call      0x44d010
008c3ade 50                       push      eax
008c3adf 8d8d74ffffff             lea       ecx, [ebp - 0x8c]
008c3ae5 e8c60ab4ff               call      0x4045b0
008c3aea 8d8d18ffffff             lea       ecx, [ebp - 0xe8]
008c3af0 e81be5b3ff               call      0x402010
008c3af5 8b06                     mov       eax, dword ptr [esi]
008c3af7 6a02                     push      2
008c3af9 8d4d0e                   lea       ecx, [ebp + 0xe]
008c3afc 51                       push      ecx
008c3afd 8bce                     mov       ecx, esi
008c3aff ff5064                   call      dword ptr [eax + 0x64]
008c3b02 0fbf550e                 movsx     edx, word ptr [ebp + 0xe]
008c3b06 8955f0                   mov       dword ptr [ebp - 0x10], edx
008c3b09 8d45f0                   lea       eax, [ebp - 0x10]
008c3b0c db45f0                   fild      dword ptr [ebp - 0x10]
008c3b0f 50                       push      eax
008c3b10 8d8de8feffff             lea       ecx, [ebp - 0x118]
008c3b16 d95df0                   fstp      dword ptr [ebp - 0x10]
008c3b19 e8f294b8ff               call      0x44d010
008c3b1e 50                       push      eax
008c3b1f 8d8d7cffffff             lea       ecx, [ebp - 0x84]
008c3b25 e8860ab4ff               call      0x4045b0
008c3b2a 8d8de8feffff             lea       ecx, [ebp - 0x118]
008c3b30 e8dbe4b3ff               call      0x402010
008c3b35 8b16                     mov       edx, dword ptr [esi]
008c3b37 6a02                     push      2
008c3b39 8d450e                   lea       eax, [ebp + 0xe]
008c3b3c 50                       push      eax
008c3b3d 8bce                     mov       ecx, esi
008c3b3f ff5264                   call      dword ptr [edx + 0x64]
008c3b42 0fbf4d0e                 movsx     ecx, word ptr [ebp + 0xe]
008c3b46 894df0                   mov       dword ptr [ebp - 0x10], ecx
008c3b49 8d55f0                   lea       edx, [ebp - 0x10]
008c3b4c db45f0                   fild      dword ptr [ebp - 0x10]
008c3b4f 52                       push      edx
008c3b50 8d8d20ffffff             lea       ecx, [ebp - 0xe0]
008c3b56 d95df0                   fstp      dword ptr [ebp - 0x10]
008c3b59 e8b294b8ff               call      0x44d010
008c3b5e 50                       push      eax
008c3b5f 8d4d84                   lea       ecx, [ebp - 0x7c]
008c3b62 e8490ab4ff               call      0x4045b0
008c3b67 8d8d20ffffff             lea       ecx, [ebp - 0xe0]
008c3b6d e89ee4b3ff               call      0x402010
008c3b72 8b06                     mov       eax, dword ptr [esi]
008c3b74 8d4d0b                   lea       ecx, [ebp + 0xb]
008c3b77 51                       push      ecx
008c3b78 8bce                     mov       ecx, esi
008c3b7a ff5050                   call      dword ptr [eax + 0x50]
008c3b7d 8b16                     mov       edx, dword ptr [esi]
008c3b7f 8d45e0                   lea       eax, [ebp - 0x20]
008c3b82 50                       push      eax
008c3b83 8bce                     mov       ecx, esi
008c3b85 ff5254                   call      dword ptr [edx + 0x54]
008c3b88 0fb77de8                 movzx     edi, word ptr [ebp - 0x18]
008c3b8c 8d8d64ffffff             lea       ecx, [ebp - 0x9c]
008c3b92 e819f8b6ff               call      0x4333b0
008c3b97 8d8d5cffffff             lea       ecx, [ebp - 0xa4]
008c3b9d d95df0                   fstp      dword ptr [ebp - 0x10]
008c3ba0 e80bf8b6ff               call      0x4333b0
008c3ba5 d845f0                   fadd      dword ptr [ebp - 0x10]
008c3ba8 0fb755e0                 movzx     edx, word ptr [ebp - 0x20]
008c3bac 8d4f01                   lea       ecx, [edi + 1]
008c3baf d805581fcc00             fadd      dword ptr [0xcc1f58]
008c3bb5 0fb74510                 movzx     eax, word ptr [ebp + 0x10]
008c3bb9 0fafca                   imul      ecx, edx
008c3bbc 894df0                   mov       dword ptr [ebp - 0x10], ecx
008c3bbf da4df0                   fimul     dword ptr [ebp - 0x10]
008c3bc2 8945f0                   mov       dword ptr [ebp - 0x10], eax
008c3bc5 da45f0                   fiadd     dword ptr [ebp - 0x10]
008c3bc8 e877d93300               call      0xc01544
008c3bcd 8986c8a51000             mov       dword ptr [esi + 0x10a5c8], eax
008c3bd3 8b8660a01000             mov       eax, dword ptr [esi + 0x10a060]
008c3bd9 3bc3                     cmp       eax, ebx
008c3bdb 0f84b2010000             je        0x8c3d93
008c3be1 8b80b0000000             mov       eax, dword ptr [eax + 0xb0]
008c3be7 3bc3                     cmp       eax, ebx
008c3be9 0f84a4010000             je        0x8c3d93
008c3bef 0fb74dd0                 movzx     ecx, word ptr [ebp - 0x30]
008c3bf3 53                       push      ebx
008c3bf4 687c28f400               push      0xf4287c
008c3bf9 681009f400               push      0xf40910
008c3bfe 53                       push      ebx
008c3bff 51                       push      ecx
008c3c00 57                       push      edi
008c3c01 8bc8                     mov       ecx, eax
008c3c03 e8187cc4ff               call      0x50b820
008c3c08 50                       push      eax
008c3c09 e8fdd03300               call      0xc00d0b
008c3c0e 8b9660a01000             mov       edx, dword ptr [esi + 0x10a060]
008c3c14 8b8ab0000000             mov       ecx, dword ptr [edx + 0xb0]
008c3c1a 0fb755e4                 movzx     edx, word ptr [ebp - 0x1c]
008c3c1e 83c414                   add       esp, 0x14
008c3c21 53                       push      ebx
008c3c22 687c28f400               push      0xf4287c
008c3c27 681009f400               push      0xf40910
008c3c2c 8bf8                     mov       edi, eax
008c3c2e 0fb74510                 movzx     eax, word ptr [ebp + 0x10]
008c3c32 53                       push      ebx
008c3c33 50                       push      eax
008c3c34 52                       push      edx
008c3c35 e8e67bc4ff               call      0x50b820
008c3c3a 50                       push      eax
008c3c3b e8cbd03300               call      0xc00d0b
008c3c40 83c414                   add       esp, 0x14
008c3c43 3bfb                     cmp       edi, ebx
008c3c45 8bf0                     mov       esi, eax
008c3c47 0f8446010000             je        0x8c3d93
008c3c4d 3bf3                     cmp       esi, ebx
008c3c4f 0f843e010000             je        0x8c3d93
008c3c55 8b07                     mov       eax, dword ptr [edi]
008c3c57 8bcf                     mov       ecx, edi
008c3c59 ff90c8010000             call      dword ptr [eax + 0x1c8]
008c3c5f 8b16                     mov       edx, dword ptr [esi]
008c3c61 8bce                     mov       ecx, esi
008c3c63 8bf8                     mov       edi, eax
008c3c65 ff92c8010000             call      dword ptr [edx + 0x1c8]
008c3c6b 385d0b                   cmp       byte ptr [ebp + 0xb], bl
008c3c6e 0f95c1                   setne     cl
008c3c71 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3c77 8bf0                     mov       esi, eax
008c3c79 8b07                     mov       eax, dword ptr [edi]
008c3c7b 51                       push      ecx
008c3c7c 52                       push      edx
008c3c7d 56                       push      esi
008c3c7e 8bcf                     mov       ecx, edi
008c3c80 ff9050020000             call      dword ptr [eax + 0x250]
008c3c86 8a4d0b                   mov       cl, byte ptr [ebp + 0xb]
008c3c89 8b06                     mov       eax, dword ptr [esi]
008c3c8b 3acb                     cmp       cl, bl
008c3c8d 0f95c1                   setne     cl
008c3c90 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3c96 51                       push      ecx
008c3c97 52                       push      edx
008c3c98 57                       push      edi
008c3c99 8bce                     mov       ecx, esi
008c3c9b ff905c020000             call      dword ptr [eax + 0x25c]
008c3ca1 8a4d0b                   mov       cl, byte ptr [ebp + 0xb]
008c3ca4 8b07                     mov       eax, dword ptr [edi]
008c3ca6 3acb                     cmp       cl, bl
008c3ca8 0f95c1                   setne     cl
008c3cab 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3cb1 51                       push      ecx
008c3cb2 52                       push      edx
008c3cb3 56                       push      esi
008c3cb4 8bcf                     mov       ecx, edi
008c3cb6 ff9054020000             call      dword ptr [eax + 0x254]
008c3cbc 8a4d0b                   mov       cl, byte ptr [ebp + 0xb]
008c3cbf 8b06                     mov       eax, dword ptr [esi]
008c3cc1 3acb                     cmp       cl, bl
008c3cc3 0f95c1                   setne     cl
008c3cc6 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3ccc 51                       push      ecx
008c3ccd 52                       push      edx
008c3cce 57                       push      edi
008c3ccf 8bce                     mov       ecx, esi
008c3cd1 ff9060020000             call      dword ptr [eax + 0x260]
008c3cd7 8a4d0b                   mov       cl, byte ptr [ebp + 0xb]
008c3cda 8b07                     mov       eax, dword ptr [edi]
008c3cdc 3acb                     cmp       cl, bl
008c3cde 0f95c1                   setne     cl
008c3ce1 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3ce7 51                       push      ecx
008c3ce8 52                       push      edx
008c3ce9 56                       push      esi
008c3cea 8bcf                     mov       ecx, edi
008c3cec ff9058020000             call      dword ptr [eax + 0x258]
008c3cf2 8a4d0b                   mov       cl, byte ptr [ebp + 0xb]
008c3cf5 8b06                     mov       eax, dword ptr [esi]
008c3cf7 3acb                     cmp       cl, bl
008c3cf9 0f95c1                   setne     cl
008c3cfc 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3d02 51                       push      ecx
008c3d03 52                       push      edx
008c3d04 57                       push      edi
008c3d05 8bce                     mov       ecx, esi
008c3d07 ff9064020000             call      dword ptr [eax + 0x264]
008c3d0d 8b06                     mov       eax, dword ptr [esi]
008c3d0f 6a11                     push      0x11
008c3d11 8bce                     mov       ecx, esi
008c3d13 ff502c                   call      dword ptr [eax + 0x2c]
008c3d16 84c0                     test      al, al
008c3d18 7420                     je        0x8c3d3a
008c3d1a 385d0b                   cmp       byte ptr [ebp + 0xb], bl
008c3d1d 8b06                     mov       eax, dword ptr [esi]
008c3d1f 0f95c1                   setne     cl
008c3d22 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3d28 51                       push      ecx
008c3d29 52                       push      edx
008c3d2a 57                       push      edi
008c3d2b 8bce                     mov       ecx, esi
008c3d2d ff90c4030000             call      dword ptr [eax + 0x3c4]
008c3d33 8bc8                     mov       ecx, eax
008c3d35 e876230000               call      0x8c60b0
008c3d3a 8b17                     mov       edx, dword ptr [edi]
008c3d3c 8bcf                     mov       ecx, edi
008c3d3e ff92a4020000             call      dword ptr [edx + 0x2a4]
008c3d44 85c0                     test      eax, eax
008c3d46 744b                     je        0x8c3d93
008c3d48 8b07                     mov       eax, dword ptr [edi]
008c3d4a 8bcf                     mov       ecx, edi
008c3d4c ff90a4020000             call      dword ptr [eax + 0x2a4]
008c3d52 385d0b                   cmp       byte ptr [ebp + 0xb], bl
008c3d55 0f95c1                   setne     cl
008c3d58 8d955cffffff             lea       edx, [ebp - 0xa4]
008c3d5e 8945f0                   mov       dword ptr [ebp - 0x10], eax
008c3d61 51                       push      ecx
008c3d62 52                       push      edx
008c3d63 8b10                     mov       edx, dword ptr [eax]
008c3d65 56                       push      esi
008c3d66 57                       push      edi
008c3d67 8bc8                     mov       ecx, eax
008c3d69 ff92c4030000             call      dword ptr [edx + 0x3c4]
008c3d6f 8bc8                     mov       ecx, eax
