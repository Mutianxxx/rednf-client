00500530 55                       push      ebp
00500531 8bec                     mov       ebp, esp
00500533 6aff                     push      -1
00500535 680ea0c500               push      0xc5a00e
0050053a 64a100000000             mov       eax, dword ptr fs:[0]
00500540 50                       push      eax
00500541 64892500000000           mov       dword ptr fs:[0], esp
00500548 81ec74090000             sub       esp, 0x974
0050054e 53                       push      ebx
0050054f 8bd9                     mov       ebx, ecx
00500551 56                       push      esi
00500552 8db3741d0000             lea       esi, [ebx + 0x1d74]
00500558 57                       push      edi
00500559 8bce                     mov       ecx, esi
0050055b e89049f0ff               call      0x404ef0
00500560 33ff                     xor       edi, edi
00500562 57                       push      edi
00500563 57                       push      edi
00500564 8bce                     mov       ecx, esi
00500566 e8f5696000               call      0xb06f60
0050056b 8db31c210000             lea       esi, [ebx + 0x211c]
00500571 8bce                     mov       ecx, esi
00500573 e87849f0ff               call      0x404ef0
00500578 57                       push      edi
00500579 57                       push      edi
0050057a 8bce                     mov       ecx, esi
0050057c e8df696000               call      0xb06f60
00500581 8b7508                   mov       esi, dword ptr [ebp + 8]
00500584 89bb14210000             mov       dword ptr [ebx + 0x2114], edi
0050058a 56                       push      esi
0050058b c78318210000b80b0000     mov       dword ptr [ebx + 0x2118], 0xbb8
00500595 e833f86f00               call      0xbffdcd
0050059a 83c404                   add       esp, 4
0050059d 50                       push      eax
0050059e 56                       push      esi
0050059f 8d8b441b0000             lea       ecx, [ebx + 0x1b44]
005005a5 e8d628f0ff               call      0x402e80
005005aa c683601b000000           mov       byte ptr [ebx + 0x1b60], 0
005005b1 c683611b000000           mov       byte ptr [ebx + 0x1b61], 0
005005b8 c683661b000000           mov       byte ptr [ebx + 0x1b66], 0
005005bf 66c783621b0000ffff       mov       word ptr [ebx + 0x1b62], 0xffff
005005c8 6689bb641b0000           mov       word ptr [ebx + 0x1b64], di
005005cf c683671b000000           mov       byte ptr [ebx + 0x1b67], 0
005005d6 89bb681b0000             mov       dword ptr [ebx + 0x1b68], edi
005005dc a1cce4ff00               mov       eax, dword ptr [0xffe4cc]
005005e1 8983681b0000             mov       dword ptr [ebx + 0x1b68], eax
005005e7 66c783621b0000b400       mov       word ptr [ebx + 0x1b62], 0xb4
005005f0 c683661b000001           mov       byte ptr [ebx + 0x1b66], 1
005005f7 56                       push      esi
005005f8 c683611b000001           mov       byte ptr [ebx + 0x1b61], 1
005005ff 8b0de0300001             mov       ecx, dword ptr [0x10030e0]
00500605 57                       push      edi
00500606 e825c86700               call      0xb7ce30
0050060b 8bf8                     mov       edi, eax
0050060d 85ff                     test      edi, edi
0050060f 897d08                   mov       dword ptr [ebp + 8], edi
00500612 7522                     jne       0x500636
00500614 56                       push      esi
00500615 688061cd00               push      0xcd6180
0050061a ff15bc2eff00             call      dword ptr [0xff2ebc]
00500620 83c408                   add       esp, 8
00500623 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
00500626 64890d00000000           mov       dword ptr fs:[0], ecx
0050062d 5f                       pop       edi
0050062e 5e                       pop       esi
0050062f 5b                       pop       ebx
00500630 8be5                     mov       esp, ebp
00500632 5d                       pop       ebp
00500633 c20800                   ret       8
00500636 8d8fc0070000             lea       ecx, [edi + 0x7c0]
0050063c e8af2a5500               call      0xa530f0
00500641 8bf0                     mov       esi, eax
00500643 56                       push      esi
00500644 e884f76f00               call      0xbffdcd
00500649 83c404                   add       esp, 4
0050064c 50                       push      eax
0050064d 56                       push      esi
0050064e 8d8b44020000             lea       ecx, [ebx + 0x244]
00500654 e82728f0ff               call      0x402e80
00500659 8b13                     mov       edx, dword ptr [ebx]
0050065b 8bcb                     mov       ecx, ebx
0050065d ff9294010000             call      dword ptr [edx + 0x194]
00500663 8b0f                     mov       ecx, dword ptr [edi]
00500665 8908                     mov       dword ptr [eax], ecx
00500667 8b13                     mov       edx, dword ptr [ebx]
00500669 8bcb                     mov       ecx, ebx
0050066b ff9294010000             call      dword ptr [edx + 0x194]
00500671 8d4f04                   lea       ecx, [edi + 4]
00500674 83c004                   add       eax, 4
00500677 51                       push      ecx
00500678 8bc8                     mov       ecx, eax
0050067a e8112e5500               call      0xa53490
0050067f 8b13                     mov       edx, dword ptr [ebx]
00500681 8b7708                   mov       esi, dword ptr [edi + 8]
00500684 8bcb                     mov       ecx, ebx
00500686 ff9294010000             call      dword ptr [edx + 0x194]
0050068c 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
00500692 8b5144                   mov       edx, dword ptr [ecx + 0x44]
00500695 8b480c                   mov       ecx, dword ptr [eax + 0xc]
00500698 83c008                   add       eax, 8
0050069b c1e102                   shl       ecx, 2
0050069e 8d3c0a                   lea       edi, [edx + ecx]
005006a1 333ddc012101             xor       edi, dword ptr [0x12101dc]
005006a7 33fe                     xor       edi, esi
005006a9 893c0a                   mov       dword ptr [edx + ecx], edi
005006ac 8b15d8012101             mov       edx, dword ptr [0x12101d8]
005006b2 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
005006b5 8b4004                   mov       eax, dword ptr [eax + 4]
005006b8 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
005006be c1e002                   shl       eax, 2
005006c1 8d1401                   lea       edx, [ecx + eax]
005006c4 33d7                     xor       edx, edi
005006c6 33d6                     xor       edx, esi
005006c8 891401                   mov       dword ptr [ecx + eax], edx
005006cb 8b4508                   mov       eax, dword ptr [ebp + 8]
005006ce 8b13                     mov       edx, dword ptr [ebx]
005006d0 8b700c                   mov       esi, dword ptr [eax + 0xc]
005006d3 8bcb                     mov       ecx, ebx
005006d5 ff9294010000             call      dword ptr [edx + 0x194]
005006db 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
005006e1 8b5144                   mov       edx, dword ptr [ecx + 0x44]
005006e4 8b4814                   mov       ecx, dword ptr [eax + 0x14]
005006e7 83c010                   add       eax, 0x10
005006ea c1e102                   shl       ecx, 2
005006ed 8d3c0a                   lea       edi, [edx + ecx]
005006f0 333ddc012101             xor       edi, dword ptr [0x12101dc]
005006f6 33fe                     xor       edi, esi
005006f8 893c0a                   mov       dword ptr [edx + ecx], edi
005006fb 8b15d8012101             mov       edx, dword ptr [0x12101d8]
00500701 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
00500704 8b4004                   mov       eax, dword ptr [eax + 4]
00500707 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
0050070d c1e002                   shl       eax, 2
00500710 8d1401                   lea       edx, [ecx + eax]
00500713 33d7                     xor       edx, edi
00500715 33d6                     xor       edx, esi
00500717 891401                   mov       dword ptr [ecx + eax], edx
0050071a 8b03                     mov       eax, dword ptr [ebx]
0050071c 8bcb                     mov       ecx, ebx
0050071e ff9094010000             call      dword ptr [eax + 0x194]
00500724 8b7508                   mov       esi, dword ptr [ebp + 8]
00500727 8b4e10                   mov       ecx, dword ptr [esi + 0x10]
0050072a 894818                   mov       dword ptr [eax + 0x18], ecx
0050072d 8b5610                   mov       edx, dword ptr [esi + 0x10]
00500730 899384270000             mov       dword ptr [ebx + 0x2784], edx
00500736 8b4614                   mov       eax, dword ptr [esi + 0x14]
00500739 8d8b08020000             lea       ecx, [ebx + 0x208]
0050073f 8983f4000000             mov       dword ptr [ebx + 0xf4], eax
00500745 e8a6295500               call      0xa530f0
0050074a 50                       push      eax
0050074b 686861cd00               push      0xcd6168
00500750 684061cd00               push      0xcd6140
00500755 ff15bc2eff00             call      dword ptr [0xff2ebc]
0050075b 83c40c                   add       esp, 0xc
0050075e 83c618                   add       esi, 0x18
00500761 56                       push      esi
00500762 8d8b20020000             lea       ecx, [ebx + 0x220]
00500768 e8d3710000               call      0x507940
0050076d 8b8b28020000             mov       ecx, dword ptr [ebx + 0x228]
00500773 8b8324020000             mov       eax, dword ptr [ebx + 0x224]
00500779 3bc1                     cmp       eax, ecx
0050077b 741a                     je        0x500797
0050077d 8d4900                   lea       ecx, [ecx]
00500780 833818                   cmp       dword ptr [eax], 0x18
00500783 7407                     je        0x50078c
00500785 83c004                   add       eax, 4
00500788 3bc1                     cmp       eax, ecx
0050078a 75f4                     jne       0x500780
0050078c 3bc1                     cmp       eax, ecx
0050078e 7407                     je        0x500797
00500790 c6838827000001           mov       byte ptr [ebx + 0x2788], 1
00500797 8b7508                   mov       esi, dword ptr [ebp + 8]
0050079a 8d4e78                   lea       ecx, [esi + 0x78]
0050079d 51                       push      ecx
0050079e 8d8b6c1b0000             lea       ecx, [ebx + 0x1b6c]
005007a4 e8d7750000               call      0x507d80
005007a9 8b8b28020000             mov       ecx, dword ptr [ebx + 0x228]
005007af 8b8324020000             mov       eax, dword ptr [ebx + 0x224]
005007b5 3bc1                     cmp       eax, ecx
005007b7 7417                     je        0x5007d0
005007b9 8da42400000000           lea       esp, [esp]
005007c0 83380b                   cmp       dword ptr [eax], 0xb
005007c3 7407                     je        0x5007cc
005007c5 83c004                   add       eax, 4
005007c8 3bc1                     cmp       eax, ecx
005007ca 75f4                     jne       0x5007c0
005007cc 3bc1                     cmp       eax, ecx
005007ce 751b                     jne       0x5007eb
005007d0 6a0c                     push      0xc
005007d2 8bcb                     mov       ecx, ebx
005007d4 e82778f6ff               call      0x468000
005007d9 84c0                     test      al, al
005007db 750e                     jne       0x5007eb
005007dd 8b13                     mov       edx, dword ptr [ebx]
005007df 6a00                     push      0
005007e1 6a0b                     push      0xb
005007e3 8bcb                     mov       ecx, ebx
005007e5 ff921c020000             call      dword ptr [edx + 0x21c]
005007eb 8b8b28020000             mov       ecx, dword ptr [ebx + 0x228]
005007f1 8b8324020000             mov       eax, dword ptr [ebx + 0x224]
005007f7 3bc1                     cmp       eax, ecx
005007f9 7415                     je        0x500810
005007fb eb03                     jmp       0x500800
005007fd 8d4900                   lea       ecx, [ecx]
00500800 83380d                   cmp       dword ptr [eax], 0xd
00500803 7407                     je        0x50080c
00500805 83c004                   add       eax, 4
00500808 3bc1                     cmp       eax, ecx
0050080a 75f4                     jne       0x500800
0050080c 3bc1                     cmp       eax, ecx
0050080e 7535                     jne       0x500845
00500810 6a0e                     push      0xe
00500812 8bcb                     mov       ecx, ebx
00500814 e8e777f6ff               call      0x468000
00500819 84c0                     test      al, al
0050081b 7528                     jne       0x500845
0050081d 6a10                     push      0x10
0050081f 8bcb                     mov       ecx, ebx
00500821 e8da77f6ff               call      0x468000
00500826 84c0                     test      al, al
00500828 751b                     jne       0x500845
0050082a 6a11                     push      0x11
0050082c 8bcb                     mov       ecx, ebx
0050082e e8cd77f6ff               call      0x468000
00500833 84c0                     test      al, al
00500835 750e                     jne       0x500845
00500837 8b03                     mov       eax, dword ptr [ebx]
00500839 6a00                     push      0
0050083b 6a0e                     push      0xe
0050083d 8bcb                     mov       ecx, ebx
0050083f ff901c020000             call      dword ptr [eax + 0x21c]
00500845 8d8e54060000             lea       ecx, [esi + 0x654]
0050084b 51                       push      ecx
0050084c 8d8ba81c0000             lea       ecx, [ebx + 0x1ca8]
00500852 e8593df0ff               call      0x4045b0
00500857 8d9674060000             lea       edx, [esi + 0x674]
0050085d 52                       push      edx
0050085e 8d8bb01c0000             lea       ecx, [ebx + 0x1cb0]
00500864 e8473df0ff               call      0x4045b0
00500869 8a868c060000             mov       al, byte ptr [esi + 0x68c]
0050086f 8883c01c0000             mov       byte ptr [ebx + 0x1cc0], al
00500875 8a8e8d060000             mov       cl, byte ptr [esi + 0x68d]
0050087b 888bc11c0000             mov       byte ptr [ebx + 0x1cc1], cl
00500881 8a969c060000             mov       dl, byte ptr [esi + 0x69c]
00500887 8893c21c0000             mov       byte ptr [ebx + 0x1cc2], dl
0050088d 8a869d060000             mov       al, byte ptr [esi + 0x69d]
00500893 8883c31c0000             mov       byte ptr [ebx + 0x1cc3], al
00500899 8a8e9e060000             mov       cl, byte ptr [esi + 0x69e]
0050089f 888bc41c0000             mov       byte ptr [ebx + 0x1cc4], cl
005008a5 8d8e7c060000             lea       ecx, [esi + 0x67c]
005008ab e8b017f0ff               call      0x402060
005008b0 8d8e84060000             lea       ecx, [esi + 0x684]
005008b6 8983001d0000             mov       dword ptr [ebx + 0x1d00], eax
005008bc e89f17f0ff               call      0x402060
005008c1 8983081d0000             mov       dword ptr [ebx + 0x1d08], eax
005008c7 8a96b1060000             mov       dl, byte ptr [esi + 0x6b1]
005008cd 8893df1c0000             mov       byte ptr [ebx + 0x1cdf], dl
005008d3 8b86b4060000             mov       eax, dword ptr [esi + 0x6b4]
005008d9 8983e01c0000             mov       dword ptr [ebx + 0x1ce0], eax
005008df 8b8ea0060000             mov       ecx, dword ptr [esi + 0x6a0]
005008e5 898bf01c0000             mov       dword ptr [ebx + 0x1cf0], ecx
005008eb 8b96a4060000             mov       edx, dword ptr [esi + 0x6a4]
005008f1 8993f41c0000             mov       dword ptr [ebx + 0x1cf4], edx
005008f7 8b86a8060000             mov       eax, dword ptr [esi + 0x6a8]
005008fd 8983f81c0000             mov       dword ptr [ebx + 0x1cf8], eax
00500903 8b8eac060000             mov       ecx, dword ptr [esi + 0x6ac]
00500909 898bfc1c0000             mov       dword ptr [ebx + 0x1cfc], ecx
0050090f 8b9690060000             mov       edx, dword ptr [esi + 0x690]
00500915 8993e41c0000             mov       dword ptr [ebx + 0x1ce4], edx
0050091b 8b8694060000             mov       eax, dword ptr [esi + 0x694]
00500921 8dbe5c060000             lea       edi, [esi + 0x65c]
00500927 68e0baca00               push      0xcabae0
0050092c 8bcf                     mov       ecx, edi
0050092e 8983e81c0000             mov       dword ptr [ebx + 0x1ce8], eax
00500934 e8b7275500               call      0xa530f0
00500939 50                       push      eax
0050093a e8ac047000               call      0xc00deb
0050093f 83c408                   add       esp, 8
00500942 85c0                     test      eax, eax
00500944 7475                     je        0x5009bb
00500946 68e0020000               push      0x2e0
0050094b e80033f0ff               call      0x403c50
00500950 83c404                   add       esp, 4
00500953 8945ec                   mov       dword ptr [ebp - 0x14], eax
00500956 85c0                     test      eax, eax
00500958 c745fc00000000           mov       dword ptr [ebp - 4], 0
0050095f 7435                     je        0x500996
00500961 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500968 720b                     jb        0x500975
0050096a 8b8b48020000             mov       ecx, dword ptr [ebx + 0x248]
00500970 894de4                   mov       dword ptr [ebp - 0x1c], ecx
00500973 eb09                     jmp       0x50097e
00500975 8d9348020000             lea       edx, [ebx + 0x248]
0050097b 8955e4                   mov       dword ptr [ebp - 0x1c], edx
0050097e 6a00                     push      0
00500980 8bcf                     mov       ecx, edi
00500982 e869275500               call      0xa530f0
00500987 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
0050098a 50                       push      eax
0050098b 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
0050098e 50                       push      eax
0050098f e86c2ffaff               call      0x4a3900
00500994 eb02                     jmp       0x500998
00500996 33c0                     xor       eax, eax
00500998 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0050099f 53                       push      ebx
005009a0 8bc8                     mov       ecx, eax
005009a2 898300250000             mov       dword ptr [ebx + 0x2500], eax
005009a8 e873c65200               call      0xa2d020
005009ad 8b13                     mov       edx, dword ptr [ebx]
005009af 6a01                     push      1
005009b1 6a18                     push      0x18
005009b3 8bcb                     mov       ecx, ebx
005009b5 ff921c020000             call      dword ptr [edx + 0x21c]
005009bb 8d8e64060000             lea       ecx, [esi + 0x664]
005009c1 e89a16f0ff               call      0x402060
005009c6 8d8e6c060000             lea       ecx, [esi + 0x66c]
005009cc 898304250000             mov       dword ptr [ebx + 0x2504], eax
005009d2 e88916f0ff               call      0x402060
005009d7 8dbe60060000             lea       edi, [esi + 0x660]
005009dd 68e0baca00               push      0xcabae0
005009e2 8bcf                     mov       ecx, edi
005009e4 898308250000             mov       dword ptr [ebx + 0x2508], eax
005009ea e801275500               call      0xa530f0
005009ef 50                       push      eax
005009f0 e8f6037000               call      0xc00deb
005009f5 83c408                   add       esp, 8
005009f8 85c0                     test      eax, eax
005009fa 741f                     je        0x500a1b
005009fc 8bcf                     mov       ecx, edi
005009fe e8ed265500               call      0xa530f0
00500a03 8bf8                     mov       edi, eax
00500a05 57                       push      edi
00500a06 e8c2f36f00               call      0xbffdcd
00500a0b 83c404                   add       esp, 4
00500a0e 50                       push      eax
00500a0f 57                       push      edi
00500a10 8d8b281b0000             lea       ecx, [ebx + 0x1b28]
00500a16 e86524f0ff               call      0x402e80
00500a1b 8b869c070000             mov       eax, dword ptr [esi + 0x79c]
00500a21 89834c1d0000             mov       dword ptr [ebx + 0x1d4c], eax
00500a27 8a8ea0070000             mov       cl, byte ptr [esi + 0x7a0]
00500a2d 888b501d0000             mov       byte ptr [ebx + 0x1d50], cl
00500a33 8a968c030000             mov       dl, byte ptr [esi + 0x38c]
00500a39 889370270000             mov       byte ptr [ebx + 0x2770], dl
00500a3f 8b8690030000             mov       eax, dword ptr [esi + 0x390]
00500a45 898374270000             mov       dword ptr [ebx + 0x2774], eax
00500a4b 8b8e90030000             mov       ecx, dword ptr [esi + 0x390]
00500a51 898b78270000             mov       dword ptr [ebx + 0x2778], ecx
00500a57 8a968d030000             mov       dl, byte ptr [esi + 0x38d]
00500a5d 889371270000             mov       byte ptr [ebx + 0x2771], dl
00500a63 8a8698030000             mov       al, byte ptr [esi + 0x398]
00500a69 88837c270000             mov       byte ptr [ebx + 0x277c], al
00500a6f 8b8e9c030000             mov       ecx, dword ptr [esi + 0x39c]
00500a75 8dbea4070000             lea       edi, [esi + 0x7a4]
00500a7b 898b80270000             mov       dword ptr [ebx + 0x2780], ecx
00500a81 8b4704                   mov       eax, dword ptr [edi + 4]
00500a84 85c0                     test      eax, eax
00500a86 742c                     je        0x500ab4
00500a88 8b4f08                   mov       ecx, dword ptr [edi + 8]
00500a8b 2bc8                     sub       ecx, eax
00500a8d b8abaaaa2a               mov       eax, 0x2aaaaaab
00500a92 f7e9                     imul      ecx
00500a94 c1fa04                   sar       edx, 4
00500a97 8bc2                     mov       eax, edx
00500a99 c1e81f                   shr       eax, 0x1f
00500a9c 03c2                     add       eax, edx
00500a9e 8945e8                   mov       dword ptr [ebp - 0x18], eax
00500aa1 7411                     je        0x500ab4
00500aa3 8d8b5c1d0000             lea       ecx, [ebx + 0x1d5c]
00500aa9 57                       push      edi
00500aaa e851740000               call      0x507f00
00500aaf e9a9000000               jmp       0x500b5d
00500ab4 8b8e2c070000             mov       ecx, dword ptr [esi + 0x72c]
00500aba 85c9                     test      ecx, ecx
00500abc 7504                     jne       0x500ac2
00500abe 33c0                     xor       eax, eax
00500ac0 eb0b                     jmp       0x500acd
00500ac2 8b8630070000             mov       eax, dword ptr [esi + 0x730]
00500ac8 2bc1                     sub       eax, ecx
00500aca c1f802                   sar       eax, 2
00500acd 8b8ee8060000             mov       ecx, dword ptr [esi + 0x6e8]
00500ad3 85c9                     test      ecx, ecx
00500ad5 7504                     jne       0x500adb
00500ad7 33f6                     xor       esi, esi
00500ad9 eb0b                     jmp       0x500ae6
00500adb 8bb6ec060000             mov       esi, dword ptr [esi + 0x6ec]
00500ae1 2bf1                     sub       esi, ecx
00500ae3 c1fe02                   sar       esi, 2
00500ae6 83ec60                   sub       esp, 0x60
00500ae9 8bcc                     mov       ecx, esp
00500aeb 8d3c06                   lea       edi, [esi + eax]
00500aee 8965e8                   mov       dword ptr [ebp - 0x18], esp
00500af1 e8ea3b0000               call      0x5046e0
00500af6 8d8b5c1d0000             lea       ecx, [ebx + 0x1d5c]
00500afc 57                       push      edi
00500afd e8ce780000               call      0x5083d0
00500b02 85ff                     test      edi, edi
00500b04 7e57                     jle       0x500b5d
00500b06 33f6                     xor       esi, esi
00500b08 897de4                   mov       dword ptr [ebp - 0x1c], edi
00500b0b eb03                     jmp       0x500b10
00500b0d 8d4900                   lea       ecx, [ecx]
00500b10 8b83601d0000             mov       eax, dword ptr [ebx + 0x1d60]
00500b16 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
00500b1c 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
00500b1f 8d540604                 lea       edx, [esi + eax + 4]
00500b23 8b02                     mov       eax, dword ptr [edx]
00500b25 c1e002                   shl       eax, 2
00500b28 8d3c08                   lea       edi, [eax + ecx]
00500b2b 333ddc012101             xor       edi, dword ptr [0x12101dc]
00500b31 83c660                   add       esi, 0x60
00500b34 83f701                   xor       edi, 1
00500b37 893c08                   mov       dword ptr [eax + ecx], edi
00500b3a a1d8012101               mov       eax, dword ptr [0x12101d8]
00500b3f 8b4848                   mov       ecx, dword ptr [eax + 0x48]
00500b42 8b02                     mov       eax, dword ptr [edx]
00500b44 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
00500b4a c1e002                   shl       eax, 2
00500b4d 8d1408                   lea       edx, [eax + ecx]
00500b50 33d7                     xor       edx, edi
00500b52 83f201                   xor       edx, 1
00500b55 891408                   mov       dword ptr [eax + ecx], edx
00500b58 ff4de4                   dec       dword ptr [ebp - 0x1c]
00500b5b 75b3                     jne       0x500b10
00500b5d 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500b60 8b87a0030000             mov       eax, dword ptr [edi + 0x3a0]
00500b66 8983a8270000             mov       dword ptr [ebx + 0x27a8], eax
00500b6c 8b8fa4030000             mov       ecx, dword ptr [edi + 0x3a4]
00500b72 898bac270000             mov       dword ptr [ebx + 0x27ac], ecx
00500b78 8b97b4070000             mov       edx, dword ptr [edi + 0x7b4]
00500b7e 8993a01b0000             mov       dword ptr [ebx + 0x1ba0], edx
00500b84 8b87b8070000             mov       eax, dword ptr [edi + 0x7b8]
00500b8a 8983a41b0000             mov       dword ptr [ebx + 0x1ba4], eax
00500b90 8b8fbc070000             mov       ecx, dword ptr [edi + 0x7bc]
00500b96 898ba81b0000             mov       dword ptr [ebx + 0x1ba8], ecx
00500b9c 8a97b8090000             mov       dl, byte ptr [edi + 0x9b8]
00500ba2 88930c250000             mov       byte ptr [ebx + 0x250c], dl
00500ba8 8b87e4090000             mov       eax, dword ptr [edi + 0x9e4]
00500bae 8db7b8060000             lea       esi, [edi + 0x6b8]
00500bb4 68e0baca00               push      0xcabae0
00500bb9 8bce                     mov       ecx, esi
00500bbb 8983b4270000             mov       dword ptr [ebx + 0x27b4], eax
00500bc1 e82a255500               call      0xa530f0
00500bc6 50                       push      eax
00500bc7 e81f027000               call      0xc00deb
00500bcc 83c408                   add       esp, 8
00500bcf 85c0                     test      eax, eax
00500bd1 7427                     je        0x500bfa
00500bd3 8bce                     mov       ecx, esi
00500bd5 e816255500               call      0xa530f0
00500bda 8b8fbc060000             mov       ecx, dword ptr [edi + 0x6bc]
00500be0 51                       push      ecx
00500be1 8b0dd8300001             mov       ecx, dword ptr [0x10030d8]
00500be7 8b11                     mov       edx, dword ptr [ecx]
00500be9 50                       push      eax
00500bea ff5210                   call      dword ptr [edx + 0x10]
00500bed 8bc8                     mov       ecx, eax
00500bef e8dc175f00               call      0xaf23d0
00500bf4 8983ac1b0000             mov       dword ptr [ebx + 0x1bac], eax
00500bfa 8d8fc0060000             lea       ecx, [edi + 0x6c0]
00500c00 68e0baca00               push      0xcabae0
00500c05 e8e6245500               call      0xa530f0
00500c0a 50                       push      eax
00500c0b e8db017000               call      0xc00deb
00500c10 83c408                   add       esp, 8
00500c13 85c0                     test      eax, eax
00500c15 7461                     je        0x500c78
00500c17 68e8010000               push      0x1e8
00500c1c e82f30f0ff               call      0x403c50
00500c21 8bf0                     mov       esi, eax
00500c23 83c404                   add       esp, 4
00500c26 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500c29 85f6                     test      esi, esi
00500c2b c745fc01000000           mov       dword ptr [ebp - 4], 1
00500c32 7435                     je        0x500c69
00500c34 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500c3b 7208                     jb        0x500c45
00500c3d 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500c43 eb06                     jmp       0x500c4b
00500c45 8dbb48020000             lea       edi, [ebx + 0x248]
00500c4b 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500c4e 6a01                     push      1
00500c50 81c1c0060000             add       ecx, 0x6c0
00500c56 e895245500               call      0xa530f0
00500c5b 50                       push      eax
00500c5c 57                       push      edi
00500c5d 8bce                     mov       ecx, esi
00500c5f e8fc1df7ff               call      0x472a60
00500c64 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500c67 eb02                     jmp       0x500c6b
00500c69 33c0                     xor       eax, eax
00500c6b c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500c72 898340120000             mov       dword ptr [ebx + 0x1240], eax
00500c78 8d8fc4060000             lea       ecx, [edi + 0x6c4]
00500c7e 68e0baca00               push      0xcabae0
00500c83 e868245500               call      0xa530f0
00500c88 50                       push      eax
00500c89 e85d017000               call      0xc00deb
00500c8e 83c408                   add       esp, 8
00500c91 85c0                     test      eax, eax
00500c93 7461                     je        0x500cf6
00500c95 68e8010000               push      0x1e8
00500c9a e8b12ff0ff               call      0x403c50
00500c9f 8bf0                     mov       esi, eax
00500ca1 83c404                   add       esp, 4
00500ca4 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500ca7 85f6                     test      esi, esi
00500ca9 c745fc02000000           mov       dword ptr [ebp - 4], 2
00500cb0 7435                     je        0x500ce7
00500cb2 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500cb9 7208                     jb        0x500cc3
00500cbb 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500cc1 eb06                     jmp       0x500cc9
00500cc3 8dbb48020000             lea       edi, [ebx + 0x248]
00500cc9 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500ccc 6a01                     push      1
00500cce 81c1c4060000             add       ecx, 0x6c4
00500cd4 e817245500               call      0xa530f0
00500cd9 50                       push      eax
00500cda 57                       push      edi
00500cdb 8bce                     mov       ecx, esi
00500cdd e87e1df7ff               call      0x472a60
00500ce2 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500ce5 eb02                     jmp       0x500ce9
00500ce7 33c0                     xor       eax, eax
00500ce9 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500cf0 898344120000             mov       dword ptr [ebx + 0x1244], eax
00500cf6 8d8fc8060000             lea       ecx, [edi + 0x6c8]
00500cfc 68e0baca00               push      0xcabae0
00500d01 e8ea235500               call      0xa530f0
00500d06 50                       push      eax
00500d07 e8df007000               call      0xc00deb
00500d0c 83c408                   add       esp, 8
00500d0f 85c0                     test      eax, eax
00500d11 7461                     je        0x500d74
00500d13 68e8010000               push      0x1e8
00500d18 e8332ff0ff               call      0x403c50
00500d1d 8bf0                     mov       esi, eax
00500d1f 83c404                   add       esp, 4
00500d22 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500d25 85f6                     test      esi, esi
00500d27 c745fc03000000           mov       dword ptr [ebp - 4], 3
00500d2e 7435                     je        0x500d65
00500d30 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500d37 7208                     jb        0x500d41
00500d39 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500d3f eb06                     jmp       0x500d47
00500d41 8dbb48020000             lea       edi, [ebx + 0x248]
00500d47 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500d4a 6a01                     push      1
00500d4c 81c1c8060000             add       ecx, 0x6c8
00500d52 e899235500               call      0xa530f0
00500d57 50                       push      eax
00500d58 57                       push      edi
00500d59 8bce                     mov       ecx, esi
00500d5b e8001df7ff               call      0x472a60
00500d60 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500d63 eb02                     jmp       0x500d67
00500d65 33c0                     xor       eax, eax
00500d67 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500d6e 898348120000             mov       dword ptr [ebx + 0x1248], eax
00500d74 8d834c120000             lea       eax, [ebx + 0x124c]
00500d7a 8d8fcc060000             lea       ecx, [edi + 0x6cc]
00500d80 8945f0                   mov       dword ptr [ebp - 0x10], eax
00500d83 894de4                   mov       dword ptr [ebp - 0x1c], ecx
00500d86 c745ec02000000           mov       dword ptr [ebp - 0x14], 2
00500d8d 8d4900                   lea       ecx, [ecx]
00500d90 68e0baca00               push      0xcabae0
00500d95 e856235500               call      0xa530f0
00500d9a 50                       push      eax
00500d9b e84b007000               call      0xc00deb
00500da0 83c408                   add       esp, 8
00500da3 85c0                     test      eax, eax
00500da5 745a                     je        0x500e01
00500da7 68e8010000               push      0x1e8
00500dac e89f2ef0ff               call      0x403c50
00500db1 8bf0                     mov       esi, eax
00500db3 83c404                   add       esp, 4
00500db6 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500db9 85f6                     test      esi, esi
00500dbb c745fc04000000           mov       dword ptr [ebp - 4], 4
00500dc2 742f                     je        0x500df3
00500dc4 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500dcb 7208                     jb        0x500dd5
00500dcd 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500dd3 eb06                     jmp       0x500ddb
00500dd5 8dbb48020000             lea       edi, [ebx + 0x248]
00500ddb 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
00500dde 6a01                     push      1
00500de0 e80b235500               call      0xa530f0
00500de5 50                       push      eax
00500de6 57                       push      edi
00500de7 8bce                     mov       ecx, esi
00500de9 e8721cf7ff               call      0x472a60
00500dee 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500df1 eb02                     jmp       0x500df5
00500df3 33c0                     xor       eax, eax
00500df5 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
00500df8 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500dff 8901                     mov       dword ptr [ecx], eax
00500e01 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
00500e04 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
00500e07 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
00500e0a 83c104                   add       ecx, 4
00500e0d 83c204                   add       edx, 4
00500e10 48                       dec       eax
00500e11 894de4                   mov       dword ptr [ebp - 0x1c], ecx
00500e14 8955f0                   mov       dword ptr [ebp - 0x10], edx
00500e17 8945ec                   mov       dword ptr [ebp - 0x14], eax
00500e1a 0f8570ffffff             jne       0x500d90
00500e20 8d8fd4060000             lea       ecx, [edi + 0x6d4]
00500e26 68e0baca00               push      0xcabae0
00500e2b e8c0225500               call      0xa530f0
00500e30 50                       push      eax
00500e31 e8b5ff6f00               call      0xc00deb
00500e36 83c408                   add       esp, 8
00500e39 85c0                     test      eax, eax
00500e3b 7461                     je        0x500e9e
00500e3d 68e8010000               push      0x1e8
00500e42 e8092ef0ff               call      0x403c50
00500e47 8bf0                     mov       esi, eax
00500e49 83c404                   add       esp, 4
00500e4c 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500e4f 85f6                     test      esi, esi
00500e51 c745fc05000000           mov       dword ptr [ebp - 4], 5
00500e58 7435                     je        0x500e8f
00500e5a 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500e61 7208                     jb        0x500e6b
00500e63 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500e69 eb06                     jmp       0x500e71
00500e6b 8dbb48020000             lea       edi, [ebx + 0x248]
00500e71 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500e74 6a01                     push      1
00500e76 81c1d4060000             add       ecx, 0x6d4
00500e7c e86f225500               call      0xa530f0
00500e81 50                       push      eax
00500e82 57                       push      edi
00500e83 8bce                     mov       ecx, esi
00500e85 e8d61bf7ff               call      0x472a60
00500e8a 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500e8d eb02                     jmp       0x500e91
00500e8f 33c0                     xor       eax, eax
00500e91 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500e98 898354120000             mov       dword ptr [ebx + 0x1254], eax
00500e9e 8d8fd8060000             lea       ecx, [edi + 0x6d8]
00500ea4 68e0baca00               push      0xcabae0
00500ea9 e842225500               call      0xa530f0
00500eae 50                       push      eax
00500eaf e837ff6f00               call      0xc00deb
00500eb4 83c408                   add       esp, 8
00500eb7 85c0                     test      eax, eax
00500eb9 7461                     je        0x500f1c
00500ebb 68e8010000               push      0x1e8
00500ec0 e88b2df0ff               call      0x403c50
00500ec5 8bf0                     mov       esi, eax
00500ec7 83c404                   add       esp, 4
00500eca 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500ecd 85f6                     test      esi, esi
00500ecf c745fc06000000           mov       dword ptr [ebp - 4], 6
00500ed6 7435                     je        0x500f0d
00500ed8 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500edf 7208                     jb        0x500ee9
00500ee1 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500ee7 eb06                     jmp       0x500eef
00500ee9 8dbb48020000             lea       edi, [ebx + 0x248]
00500eef 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500ef2 6a01                     push      1
00500ef4 81c1d8060000             add       ecx, 0x6d8
00500efa e8f1215500               call      0xa530f0
00500eff 50                       push      eax
00500f00 57                       push      edi
00500f01 8bce                     mov       ecx, esi
00500f03 e8581bf7ff               call      0x472a60
00500f08 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500f0b eb02                     jmp       0x500f0f
00500f0d 33c0                     xor       eax, eax
00500f0f c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500f16 898358120000             mov       dword ptr [ebx + 0x1258], eax
00500f1c 8d8fdc060000             lea       ecx, [edi + 0x6dc]
00500f22 68e0baca00               push      0xcabae0
00500f27 e8c4215500               call      0xa530f0
00500f2c 50                       push      eax
00500f2d e8b9fe6f00               call      0xc00deb
00500f32 83c408                   add       esp, 8
00500f35 85c0                     test      eax, eax
00500f37 7461                     je        0x500f9a
00500f39 68e8010000               push      0x1e8
00500f3e e80d2df0ff               call      0x403c50
00500f43 8bf0                     mov       esi, eax
00500f45 83c404                   add       esp, 4
00500f48 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500f4b 85f6                     test      esi, esi
00500f4d c745fc07000000           mov       dword ptr [ebp - 4], 7
00500f54 7435                     je        0x500f8b
00500f56 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500f5d 7208                     jb        0x500f67
00500f5f 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500f65 eb06                     jmp       0x500f6d
00500f67 8dbb48020000             lea       edi, [ebx + 0x248]
00500f6d 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500f70 6a01                     push      1
00500f72 81c1dc060000             add       ecx, 0x6dc
00500f78 e873215500               call      0xa530f0
00500f7d 50                       push      eax
00500f7e 57                       push      edi
00500f7f 8bce                     mov       ecx, esi
00500f81 e8da1af7ff               call      0x472a60
00500f86 8b7d08                   mov       edi, dword ptr [ebp + 8]
00500f89 eb02                     jmp       0x500f8d
00500f8b 33c0                     xor       eax, eax
00500f8d c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00500f94 89835c120000             mov       dword ptr [ebx + 0x125c], eax
00500f9a 8d8fe0060000             lea       ecx, [edi + 0x6e0]
00500fa0 68e0baca00               push      0xcabae0
00500fa5 e846215500               call      0xa530f0
00500faa 50                       push      eax
00500fab e83bfe6f00               call      0xc00deb
00500fb0 83c408                   add       esp, 8
00500fb3 85c0                     test      eax, eax
00500fb5 7461                     je        0x501018
00500fb7 68e8010000               push      0x1e8
00500fbc e88f2cf0ff               call      0x403c50
00500fc1 8bf0                     mov       esi, eax
00500fc3 83c404                   add       esp, 4
00500fc6 8975e8                   mov       dword ptr [ebp - 0x18], esi
00500fc9 85f6                     test      esi, esi
00500fcb c745fc08000000           mov       dword ptr [ebp - 4], 8
00500fd2 7435                     je        0x501009
00500fd4 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00500fdb 7208                     jb        0x500fe5
00500fdd 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00500fe3 eb06                     jmp       0x500feb
00500fe5 8dbb48020000             lea       edi, [ebx + 0x248]
00500feb 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00500fee 6a01                     push      1
00500ff0 81c1e0060000             add       ecx, 0x6e0
00500ff6 e8f5205500               call      0xa530f0
00500ffb 50                       push      eax
00500ffc 57                       push      edi
00500ffd 8bce                     mov       ecx, esi
00500fff e85c1af7ff               call      0x472a60
00501004 8b7d08                   mov       edi, dword ptr [ebp + 8]
00501007 eb02                     jmp       0x50100b
00501009 33c0                     xor       eax, eax
0050100b c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00501012 898360120000             mov       dword ptr [ebx + 0x1260], eax
00501018 8b8fe8060000             mov       ecx, dword ptr [edi + 0x6e8]
0050101e 894df0                   mov       dword ptr [ebp - 0x10], ecx
00501021 8b87ec060000             mov       eax, dword ptr [edi + 0x6ec]
00501027 3bc8                     cmp       ecx, eax
00501029 0f8445010000             je        0x501174
0050102f 8db364120000             lea       esi, [ebx + 0x1264]
00501035 eb09                     jmp       0x501040
00501037 8da42400000000           lea       esp, [esp]
0050103e 8bff                     mov       edi, edi
00501040 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
00501043 68e0baca00               push      0xcabae0
00501048 e8a3205500               call      0xa530f0
0050104d 50                       push      eax
0050104e e898fd6f00               call      0xc00deb
00501053 83c408                   add       esp, 8
00501056 85c0                     test      eax, eax
00501058 0f84af000000             je        0x50110d
0050105e 68e8010000               push      0x1e8
00501063 e8e82bf0ff               call      0x403c50
00501068 8bf8                     mov       edi, eax
0050106a 83c404                   add       esp, 4
0050106d 897de8                   mov       dword ptr [ebp - 0x18], edi
00501070 85ff                     test      edi, edi
00501072 c745fc09000000           mov       dword ptr [ebp - 4], 9
00501079 7437                     je        0x5010b2
0050107b 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00501082 720b                     jb        0x50108f
00501084 8b9348020000             mov       edx, dword ptr [ebx + 0x248]
0050108a 8955ec                   mov       dword ptr [ebp - 0x14], edx
0050108d eb09                     jmp       0x501098
0050108f 8d8348020000             lea       eax, [ebx + 0x248]
00501095 8945ec                   mov       dword ptr [ebp - 0x14], eax
00501098 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
0050109b 6a01                     push      1
0050109d e84e205500               call      0xa530f0
005010a2 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
005010a5 50                       push      eax
005010a6 51                       push      ecx
005010a7 8bcf                     mov       ecx, edi
005010a9 e8b219f7ff               call      0x472a60
005010ae 8bf8                     mov       edi, eax
005010b0 eb02                     jmp       0x5010b4
005010b2 33ff                     xor       edi, edi
005010b4 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
005010bb 89bd7cffffff             mov       dword ptr [ebp - 0x84], edi
005010c1 8b5604                   mov       edx, dword ptr [esi + 4]
005010c4 85d2                     test      edx, edx
005010c6 7504                     jne       0x5010cc
005010c8 33c0                     xor       eax, eax
005010ca eb08                     jmp       0x5010d4
005010cc 8b4608                   mov       eax, dword ptr [esi + 8]
005010cf 2bc2                     sub       eax, edx
005010d1 c1f802                   sar       eax, 2
005010d4 85d2                     test      edx, edx
005010d6 741c                     je        0x5010f4
005010d8 8b4e0c                   mov       ecx, dword ptr [esi + 0xc]
005010db 2bca                     sub       ecx, edx
005010dd c1f902                   sar       ecx, 2
005010e0 3bc1                     cmp       eax, ecx
005010e2 7310                     jae       0x5010f4
005010e4 8b4608                   mov       eax, dword ptr [esi + 8]
005010e7 8938                     mov       dword ptr [eax], edi
005010e9 8b7d08                   mov       edi, dword ptr [ebp + 8]
005010ec 83c004                   add       eax, 4
005010ef 894608                   mov       dword ptr [esi + 8], eax
005010f2 eb6b                     jmp       0x50115f
005010f4 8b4608                   mov       eax, dword ptr [esi + 8]
005010f7 8d957cffffff             lea       edx, [ebp - 0x84]
005010fd 52                       push      edx
005010fe 6a01                     push      1
00501100 50                       push      eax
00501101 8bce                     mov       ecx, esi
00501103 e85870f0ff               call      0x408160
00501108 8b7d08                   mov       edi, dword ptr [ebp + 8]
0050110b eb52                     jmp       0x50115f
0050110d c78574ffffff00000000     mov       dword ptr [ebp - 0x8c], 0
00501117 8b5604                   mov       edx, dword ptr [esi + 4]
0050111a 85d2                     test      edx, edx
0050111c 7504                     jne       0x501122
0050111e 33c9                     xor       ecx, ecx
00501120 eb08                     jmp       0x50112a
00501122 8b4e08                   mov       ecx, dword ptr [esi + 8]
00501125 2bca                     sub       ecx, edx
00501127 c1f902                   sar       ecx, 2
0050112a 85d2                     test      edx, edx
0050112c 741d                     je        0x50114b
0050112e 8b460c                   mov       eax, dword ptr [esi + 0xc]
00501131 2bc2                     sub       eax, edx
00501133 c1f802                   sar       eax, 2
00501136 3bc8                     cmp       ecx, eax
00501138 7311                     jae       0x50114b
0050113a 8b4608                   mov       eax, dword ptr [esi + 8]
0050113d c70000000000             mov       dword ptr [eax], 0
00501143 83c004                   add       eax, 4
00501146 894608                   mov       dword ptr [esi + 8], eax
00501149 eb14                     jmp       0x50115f
0050114b 8b4608                   mov       eax, dword ptr [esi + 8]
0050114e 8d8d74ffffff             lea       ecx, [ebp - 0x8c]
00501154 51                       push      ecx
00501155 6a01                     push      1
00501157 50                       push      eax
00501158 8bce                     mov       ecx, esi
0050115a e80170f0ff               call      0x408160
0050115f 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
00501162 83c004                   add       eax, 4
00501165 8945f0                   mov       dword ptr [ebp - 0x10], eax
00501168 3b87ec060000             cmp       eax, dword ptr [edi + 0x6ec]
0050116e 0f85ccfeffff             jne       0x501040
00501174 8b4508                   mov       eax, dword ptr [ebp + 8]
00501177 8bb8f8060000             mov       edi, dword ptr [eax + 0x6f8]
0050117d 897df0                   mov       dword ptr [ebp - 0x10], edi
00501180 8b80fc060000             mov       eax, dword ptr [eax + 0x6fc]
00501186 3bf8                     cmp       edi, eax
00501188 0f842d010000             je        0x5012bb
0050118e 8db374120000             lea       esi, [ebx + 0x1274]
00501194 68e0baca00               push      0xcabae0
00501199 8bcf                     mov       ecx, edi
0050119b e8501f5500               call      0xa530f0
005011a0 50                       push      eax
005011a1 e845fc6f00               call      0xc00deb
005011a6 83c408                   add       esp, 8
005011a9 85c0                     test      eax, eax
005011ab 0f84a9000000             je        0x50125a
005011b1 68e8010000               push      0x1e8
005011b6 e8952af0ff               call      0x403c50
005011bb 8bf8                     mov       edi, eax
005011bd 83c404                   add       esp, 4
005011c0 897de8                   mov       dword ptr [ebp - 0x18], edi
005011c3 85ff                     test      edi, edi
005011c5 c745fc0a000000           mov       dword ptr [ebp - 4], 0xa
005011cc 7437                     je        0x501205
005011ce 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
005011d5 720b                     jb        0x5011e2
005011d7 8b9348020000             mov       edx, dword ptr [ebx + 0x248]
005011dd 8955ec                   mov       dword ptr [ebp - 0x14], edx
005011e0 eb09                     jmp       0x5011eb
005011e2 8d8348020000             lea       eax, [ebx + 0x248]
005011e8 8945ec                   mov       dword ptr [ebp - 0x14], eax
005011eb 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
005011ee 6a01                     push      1
005011f0 e8fb1e5500               call      0xa530f0
005011f5 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
005011f8 50                       push      eax
005011f9 51                       push      ecx
005011fa 8bcf                     mov       ecx, edi
005011fc e85f18f7ff               call      0x472a60
00501201 8bf8                     mov       edi, eax
00501203 eb02                     jmp       0x501207
00501205 33ff                     xor       edi, edi
00501207 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0050120e 897da0                   mov       dword ptr [ebp - 0x60], edi
00501211 8b5604                   mov       edx, dword ptr [esi + 4]
00501214 85d2                     test      edx, edx
00501216 7504                     jne       0x50121c
00501218 33c0                     xor       eax, eax
0050121a eb08                     jmp       0x501224
0050121c 8b4608                   mov       eax, dword ptr [esi + 8]
0050121f 2bc2                     sub       eax, edx
00501221 c1f802                   sar       eax, 2
00501224 85d2                     test      edx, edx
00501226 741c                     je        0x501244
00501228 8b4e0c                   mov       ecx, dword ptr [esi + 0xc]
0050122b 2bca                     sub       ecx, edx
0050122d c1f902                   sar       ecx, 2
00501230 3bc1                     cmp       eax, ecx
00501232 7310                     jae       0x501244
00501234 8b4608                   mov       eax, dword ptr [esi + 8]
00501237 8938                     mov       dword ptr [eax], edi
00501239 83c004                   add       eax, 4
0050123c 894608                   mov       dword ptr [esi + 8], eax
0050123f 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
00501242 eb62                     jmp       0x5012a6
00501244 8b4608                   mov       eax, dword ptr [esi + 8]
00501247 8d55a0                   lea       edx, [ebp - 0x60]
0050124a 52                       push      edx
0050124b 6a01                     push      1
0050124d 50                       push      eax
0050124e 8bce                     mov       ecx, esi
00501250 e80b6ff0ff               call      0x408160
00501255 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
00501258 eb4c                     jmp       0x5012a6
0050125a c745a400000000           mov       dword ptr [ebp - 0x5c], 0
00501261 8b5604                   mov       edx, dword ptr [esi + 4]
00501264 85d2                     test      edx, edx
00501266 7504                     jne       0x50126c
00501268 33c9                     xor       ecx, ecx
0050126a eb08                     jmp       0x501274
0050126c 8b4e08                   mov       ecx, dword ptr [esi + 8]
0050126f 2bca                     sub       ecx, edx
00501271 c1f902                   sar       ecx, 2
00501274 85d2                     test      edx, edx
00501276 741d                     je        0x501295
00501278 8b460c                   mov       eax, dword ptr [esi + 0xc]
0050127b 2bc2                     sub       eax, edx
0050127d c1f802                   sar       eax, 2
00501280 3bc8                     cmp       ecx, eax
00501282 7311                     jae       0x501295
00501284 8b4608                   mov       eax, dword ptr [esi + 8]
00501287 c70000000000             mov       dword ptr [eax], 0
0050128d 83c004                   add       eax, 4
00501290 894608                   mov       dword ptr [esi + 8], eax
00501293 eb11                     jmp       0x5012a6
00501295 8b4608                   mov       eax, dword ptr [esi + 8]
00501298 8d4da4                   lea       ecx, [ebp - 0x5c]
0050129b 51                       push      ecx
0050129c 6a01                     push      1
0050129e 50                       push      eax
0050129f 8bce                     mov       ecx, esi
005012a1 e8ba6ef0ff               call      0x408160
005012a6 8b5508                   mov       edx, dword ptr [ebp + 8]
005012a9 83c704                   add       edi, 4
005012ac 897df0                   mov       dword ptr [ebp - 0x10], edi
005012af 3bbafc060000             cmp       edi, dword ptr [edx + 0x6fc]
005012b5 0f85d9feffff             jne       0x501194
005012bb 8b7d08                   mov       edi, dword ptr [ebp + 8]
005012be 8d8f50070000             lea       ecx, [edi + 0x750]
005012c4 68e0baca00               push      0xcabae0
005012c9 e8221e5500               call      0xa530f0
005012ce 50                       push      eax
005012cf e817fb6f00               call      0xc00deb
005012d4 83c408                   add       esp, 8
005012d7 85c0                     test      eax, eax
005012d9 0f8490000000             je        0x50136f
005012df 68e0020000               push      0x2e0
005012e4 e86729f0ff               call      0x403c50
005012e9 8bf0                     mov       esi, eax
005012eb 83c404                   add       esp, 4
005012ee 8975e8                   mov       dword ptr [ebp - 0x18], esi
005012f1 85f6                     test      esi, esi
005012f3 c745fc0b000000           mov       dword ptr [ebp - 4], 0xb
005012fa 7435                     je        0x501331
005012fc 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00501303 7208                     jb        0x50130d
00501305 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
0050130b eb06                     jmp       0x501313
0050130d 8dbb48020000             lea       edi, [ebx + 0x248]
00501313 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00501316 6a00                     push      0
00501318 81c150070000             add       ecx, 0x750
0050131e e8cd1d5500               call      0xa530f0
00501323 50                       push      eax
00501324 57                       push      edi
00501325 8bce                     mov       ecx, esi
00501327 e8d425faff               call      0x4a3900
0050132c 8b7d08                   mov       edi, dword ptr [ebp + 8]
0050132f eb02                     jmp       0x501333
00501331 33c0                     xor       eax, eax
00501333 33c9                     xor       ecx, ecx
00501335 3bc1                     cmp       eax, ecx
00501337 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0050133e 8983e0120000             mov       dword ptr [ebx + 0x12e0], eax
00501344 7418                     je        0x50135e
00501346 8988cc020000             mov       dword ptr [eax + 0x2cc], ecx
0050134c 8988d0020000             mov       dword ptr [eax + 0x2d0], ecx
00501352 8b8be0120000             mov       ecx, dword ptr [ebx + 0x12e0]
00501358 53                       push      ebx
00501359 e8c2bc5200               call      0xa2d020
0050135e 8b83e0120000             mov       eax, dword ptr [ebx + 0x12e0]
00501364 8983e4120000             mov       dword ptr [ebx + 0x12e4], eax
0050136a e946010000               jmp       0x5014b5
0050136f 8d8f04070000             lea       ecx, [edi + 0x704]
00501375 68e0baca00               push      0xcabae0
0050137a e8711d5500               call      0xa530f0
0050137f 50                       push      eax
00501380 e866fa6f00               call      0xc00deb
00501385 83c408                   add       esp, 8
00501388 85c0                     test      eax, eax
0050138a 0f847f000000             je        0x50140f
00501390 68e0020000               push      0x2e0
00501395 e8b628f0ff               call      0x403c50
0050139a 8bf0                     mov       esi, eax
0050139c 83c404                   add       esp, 4
0050139f 8975e8                   mov       dword ptr [ebp - 0x18], esi
005013a2 85f6                     test      esi, esi
005013a4 c745fc0c000000           mov       dword ptr [ebp - 4], 0xc
005013ab 7435                     je        0x5013e2
005013ad 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
005013b4 7208                     jb        0x5013be
005013b6 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
005013bc eb06                     jmp       0x5013c4
005013be 8dbb48020000             lea       edi, [ebx + 0x248]
005013c4 8b4d08                   mov       ecx, dword ptr [ebp + 8]
005013c7 6a00                     push      0
005013c9 81c104070000             add       ecx, 0x704
005013cf e81c1d5500               call      0xa530f0
005013d4 50                       push      eax
005013d5 57                       push      edi
005013d6 8bce                     mov       ecx, esi
005013d8 e82325faff               call      0x4a3900
005013dd 8b7d08                   mov       edi, dword ptr [ebp + 8]
005013e0 eb02                     jmp       0x5013e4
005013e2 33c0                     xor       eax, eax
005013e4 85c0                     test      eax, eax
005013e6 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
005013ed 8983e0120000             mov       dword ptr [ebx + 0x12e0], eax
005013f3 741a                     je        0x50140f
005013f5 33c9                     xor       ecx, ecx
005013f7 8988cc020000             mov       dword ptr [eax + 0x2cc], ecx
005013fd 8988d0020000             mov       dword ptr [eax + 0x2d0], ecx
00501403 8b8be0120000             mov       ecx, dword ptr [ebx + 0x12e0]
00501409 53                       push      ebx
0050140a e811bc5200               call      0xa2d020
0050140f 8d8f08070000             lea       ecx, [edi + 0x708]
00501415 68e0baca00               push      0xcabae0
0050141a e8d11c5500               call      0xa530f0
0050141f 50                       push      eax
00501420 e8c6f96f00               call      0xc00deb
00501425 83c408                   add       esp, 8
00501428 85c0                     test      eax, eax
0050142a 0f8485000000             je        0x5014b5
00501430 68e0020000               push      0x2e0
00501435 e81628f0ff               call      0x403c50
0050143a 8bf0                     mov       esi, eax
0050143c 83c404                   add       esp, 4
0050143f 8975e8                   mov       dword ptr [ebp - 0x18], esi
00501442 85f6                     test      esi, esi
00501444 c745fc0d000000           mov       dword ptr [ebp - 4], 0xd
0050144b 7435                     je        0x501482
0050144d 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00501454 7208                     jb        0x50145e
00501456 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
0050145c eb06                     jmp       0x501464
0050145e 8dbb48020000             lea       edi, [ebx + 0x248]
00501464 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00501467 6a00                     push      0
00501469 81c108070000             add       ecx, 0x708
0050146f e87c1c5500               call      0xa530f0
00501474 50                       push      eax
00501475 57                       push      edi
00501476 8bce                     mov       ecx, esi
00501478 e88324faff               call      0x4a3900
0050147d 8b7d08                   mov       edi, dword ptr [ebp + 8]
00501480 eb02                     jmp       0x501484
00501482 33c0                     xor       eax, eax
00501484 85c0                     test      eax, eax
00501486 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0050148d 8983e4120000             mov       dword ptr [ebx + 0x12e4], eax
00501493 7420                     je        0x5014b5
00501495 c780cc02000001000000     mov       dword ptr [eax + 0x2cc], 1
0050149f c780d002000000000000     mov       dword ptr [eax + 0x2d0], 0
005014a9 8b8be4120000             mov       ecx, dword ptr [ebx + 0x12e4]
005014af 53                       push      ebx
005014b0 e86bbb5200               call      0xa2d020
005014b5 8d8f0c070000             lea       ecx, [edi + 0x70c]
005014bb 68e0baca00               push      0xcabae0
005014c0 e82b1c5500               call      0xa530f0
005014c5 50                       push      eax
005014c6 e820f96f00               call      0xc00deb
005014cb 83c408                   add       esp, 8
005014ce 85c0                     test      eax, eax
005014d0 0f8485000000             je        0x50155b
005014d6 68e0020000               push      0x2e0
005014db e87027f0ff               call      0x403c50
005014e0 8bf0                     mov       esi, eax
005014e2 83c404                   add       esp, 4
005014e5 8975e8                   mov       dword ptr [ebp - 0x18], esi
005014e8 85f6                     test      esi, esi
005014ea c745fc0e000000           mov       dword ptr [ebp - 4], 0xe
005014f1 7435                     je        0x501528
005014f3 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
005014fa 7208                     jb        0x501504
005014fc 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00501502 eb06                     jmp       0x50150a
00501504 8dbb48020000             lea       edi, [ebx + 0x248]
0050150a 8b4d08                   mov       ecx, dword ptr [ebp + 8]
0050150d 6a00                     push      0
0050150f 81c10c070000             add       ecx, 0x70c
00501515 e8d61b5500               call      0xa530f0
0050151a 50                       push      eax
0050151b 57                       push      edi
0050151c 8bce                     mov       ecx, esi
0050151e e8dd23faff               call      0x4a3900
00501523 8b7d08                   mov       edi, dword ptr [ebp + 8]
00501526 eb02                     jmp       0x50152a
00501528 33c0                     xor       eax, eax
0050152a 85c0                     test      eax, eax
0050152c c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00501533 8983e8120000             mov       dword ptr [ebx + 0x12e8], eax
00501539 7420                     je        0x50155b
0050153b c780cc02000002000000     mov       dword ptr [eax + 0x2cc], 2
00501545 c780d002000000000000     mov       dword ptr [eax + 0x2d0], 0
0050154f 8b8be8120000             mov       ecx, dword ptr [ebx + 0x12e8]
00501555 53                       push      ebx
00501556 e8c5ba5200               call      0xa2d020
0050155b 8db748070000             lea       esi, [edi + 0x748]
00501561 68e0baca00               push      0xcabae0
00501566 8bce                     mov       ecx, esi
00501568 e8831b5500               call      0xa530f0
0050156d 50                       push      eax
0050156e e878f86f00               call      0xc00deb
00501573 83c408                   add       esp, 8
00501576 85c0                     test      eax, eax
00501578 741f                     je        0x501599
0050157a 8bce                     mov       ecx, esi
0050157c e86f1b5500               call      0xa530f0
00501581 8bf0                     mov       esi, eax
00501583 56                       push      esi
00501584 e844e86f00               call      0xbffdcd
00501589 83c404                   add       esp, 4
0050158c 50                       push      eax
0050158d 56                       push      esi
0050158e 8d8bf01a0000             lea       ecx, [ebx + 0x1af0]
00501594 e8e718f0ff               call      0x402e80
00501599 8db74c070000             lea       esi, [edi + 0x74c]
0050159f 68e0baca00               push      0xcabae0
005015a4 8bce                     mov       ecx, esi
005015a6 e8451b5500               call      0xa530f0
005015ab 50                       push      eax
005015ac e83af86f00               call      0xc00deb
005015b1 83c408                   add       esp, 8
005015b4 85c0                     test      eax, eax
005015b6 741f                     je        0x5015d7
005015b8 8bce                     mov       ecx, esi
005015ba e8311b5500               call      0xa530f0
005015bf 8bf0                     mov       esi, eax
005015c1 56                       push      esi
005015c2 e806e86f00               call      0xbffdcd
005015c7 83c404                   add       esp, 4
005015ca 50                       push      eax
005015cb 56                       push      esi
005015cc 8d8b0c1b0000             lea       ecx, [ebx + 0x1b0c]
005015d2 e8a918f0ff               call      0x402e80
005015d7 8b4d08                   mov       ecx, dword ptr [ebp + 8]
005015da 8dbbec120000             lea       edi, [ebx + 0x12ec]
005015e0 81c110070000             add       ecx, 0x710
005015e6 c745f000000000           mov       dword ptr [ebp - 0x10], 0
005015ed 897dec                   mov       dword ptr [ebp - 0x14], edi
005015f0 894de4                   mov       dword ptr [ebp - 0x1c], ecx
005015f3 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
005015f6 68e0baca00               push      0xcabae0
005015fb e8f01a5500               call      0xa530f0
00501600 50                       push      eax
00501601 e8e5f76f00               call      0xc00deb
00501606 83c408                   add       esp, 8
00501609 85c0                     test      eax, eax
0050160b 0f8480000000             je        0x501691
00501611 68e0020000               push      0x2e0
00501616 e83526f0ff               call      0x403c50
0050161b 8bf0                     mov       esi, eax
0050161d 83c404                   add       esp, 4
00501620 8975e8                   mov       dword ptr [ebp - 0x18], esi
00501623 85f6                     test      esi, esi
00501625 c745fc0f000000           mov       dword ptr [ebp - 4], 0xf
0050162c 742f                     je        0x50165d
0050162e 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00501635 7208                     jb        0x50163f
00501637 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
0050163d eb06                     jmp       0x501645
0050163f 8dbb48020000             lea       edi, [ebx + 0x248]
00501645 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
00501648 6a00                     push      0
0050164a e8a11a5500               call      0xa530f0
0050164f 50                       push      eax
00501650 57                       push      edi
00501651 8bce                     mov       ecx, esi
00501653 e8a822faff               call      0x4a3900
00501658 8b7dec                   mov       edi, dword ptr [ebp - 0x14]
0050165b eb02                     jmp       0x50165f
0050165d 33c0                     xor       eax, eax
0050165f 85c0                     test      eax, eax
00501661 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
00501668 8907                     mov       dword ptr [edi], eax
0050166a 7425                     je        0x501691
0050166c 8b75f0                   mov       esi, dword ptr [ebp - 0x10]
0050166f 33d2                     xor       edx, edx
00501671 85f6                     test      esi, esi
00501673 0f95c2                   setne     dl
00501676 53                       push      ebx
00501677 83c203                   add       edx, 3
0050167a 8990cc020000             mov       dword ptr [eax + 0x2cc], edx
00501680 c780d002000000000000     mov       dword ptr [eax + 0x2d0], 0
0050168a 8b0f                     mov       ecx, dword ptr [edi]
0050168c e88fb95200               call      0xa2d020
00501691 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
00501694 8b75e4                   mov       esi, dword ptr [ebp - 0x1c]
00501697 40                       inc       eax
00501698 83c604                   add       esi, 4
0050169b 83c704                   add       edi, 4
0050169e 83f802                   cmp       eax, 2
005016a1 8945f0                   mov       dword ptr [ebp - 0x10], eax
005016a4 8975e4                   mov       dword ptr [ebp - 0x1c], esi
005016a7 897dec                   mov       dword ptr [ebp - 0x14], edi
005016aa 0f8c43ffffff             jl        0x5015f3
005016b0 8b4d08                   mov       ecx, dword ptr [ebp + 8]
005016b3 81c118070000             add       ecx, 0x718
005016b9 68e0baca00               push      0xcabae0
005016be e82d1a5500               call      0xa530f0
005016c3 50                       push      eax
005016c4 e822f76f00               call      0xc00deb
005016c9 83c408                   add       esp, 8
005016cc 85c0                     test      eax, eax
005016ce 0f8482000000             je        0x501756
005016d4 68e0020000               push      0x2e0
005016d9 e87225f0ff               call      0x403c50
005016de 8bf0                     mov       esi, eax
005016e0 83c404                   add       esp, 4
005016e3 8975e8                   mov       dword ptr [ebp - 0x18], esi
005016e6 85f6                     test      esi, esi
005016e8 c745fc10000000           mov       dword ptr [ebp - 4], 0x10
005016ef 7432                     je        0x501723
005016f1 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
005016f8 7208                     jb        0x501702
005016fa 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
00501700 eb06                     jmp       0x501708
00501702 8dbb48020000             lea       edi, [ebx + 0x248]
00501708 8b4d08                   mov       ecx, dword ptr [ebp + 8]
0050170b 6a00                     push      0
0050170d 81c118070000             add       ecx, 0x718
00501713 e8d8195500               call      0xa530f0
00501718 50                       push      eax
00501719 57                       push      edi
0050171a 8bce                     mov       ecx, esi
0050171c e8df21faff               call      0x4a3900
00501721 eb02                     jmp       0x501725
00501723 33c0                     xor       eax, eax
00501725 85c0                     test      eax, eax
00501727 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0050172e 8983f4120000             mov       dword ptr [ebx + 0x12f4], eax
00501734 7420                     je        0x501756
00501736 c780cc02000005000000     mov       dword ptr [eax + 0x2cc], 5
00501740 c780d002000000000000     mov       dword ptr [eax + 0x2d0], 0
0050174a 8b8bf4120000             mov       ecx, dword ptr [ebx + 0x12f4]
00501750 53                       push      ebx
00501751 e8cab85200               call      0xa2d020
00501756 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00501759 81c11c070000             add       ecx, 0x71c
0050175f 68e0baca00               push      0xcabae0
00501764 e887195500               call      0xa530f0
00501769 50                       push      eax
0050176a e87cf66f00               call      0xc00deb
0050176f 83c408                   add       esp, 8
00501772 85c0                     test      eax, eax
00501774 0f8482000000             je        0x5017fc
0050177a 68e0020000               push      0x2e0
0050177f e8cc24f0ff               call      0x403c50
00501784 8bf0                     mov       esi, eax
00501786 83c404                   add       esp, 4
00501789 8975e8                   mov       dword ptr [ebp - 0x18], esi
0050178c 85f6                     test      esi, esi
0050178e c745fc11000000           mov       dword ptr [ebp - 4], 0x11
00501795 7432                     je        0x5017c9
00501797 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
0050179e 7208                     jb        0x5017a8
005017a0 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
005017a6 eb06                     jmp       0x5017ae
005017a8 8dbb48020000             lea       edi, [ebx + 0x248]
005017ae 8b4d08                   mov       ecx, dword ptr [ebp + 8]
005017b1 6a00                     push      0
005017b3 81c11c070000             add       ecx, 0x71c
005017b9 e832195500               call      0xa530f0
005017be 50                       push      eax
005017bf 57                       push      edi
005017c0 8bce                     mov       ecx, esi
005017c2 e83921faff               call      0x4a3900
005017c7 eb02                     jmp       0x5017cb
005017c9 33c0                     xor       eax, eax
005017cb 85c0                     test      eax, eax
005017cd c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
005017d4 8983f8120000             mov       dword ptr [ebx + 0x12f8], eax
005017da 7420                     je        0x5017fc
005017dc c780cc02000006000000     mov       dword ptr [eax + 0x2cc], 6
005017e6 c780d002000000000000     mov       dword ptr [eax + 0x2d0], 0
005017f0 8b8bf8120000             mov       ecx, dword ptr [ebx + 0x12f8]
005017f6 53                       push      ebx
005017f7 e824b85200               call      0xa2d020
005017fc 8b4d08                   mov       ecx, dword ptr [ebp + 8]
005017ff 81c120070000             add       ecx, 0x720
00501805 68e0baca00               push      0xcabae0
0050180a e8e1185500               call      0xa530f0
0050180f 50                       push      eax
00501810 e8d6f56f00               call      0xc00deb
00501815 83c408                   add       esp, 8
00501818 85c0                     test      eax, eax
0050181a 0f8482000000             je        0x5018a2
00501820 68e0020000               push      0x2e0
00501825 e82624f0ff               call      0x403c50
0050182a 8bf0                     mov       esi, eax
0050182c 83c404                   add       esp, 4
0050182f 8975e8                   mov       dword ptr [ebp - 0x18], esi
00501832 85f6                     test      esi, esi
00501834 c745fc12000000           mov       dword ptr [ebp - 4], 0x12
0050183b 7432                     je        0x50186f
0050183d 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
00501844 7208                     jb        0x50184e
00501846 8bbb48020000             mov       edi, dword ptr [ebx + 0x248]
0050184c eb06                     jmp       0x501854
0050184e 8dbb48020000             lea       edi, [ebx + 0x248]
00501854 8b4d08                   mov       ecx, dword ptr [ebp + 8]
00501857 6a00                     push      0
00501859 81c120070000             add       ecx, 0x720
0050185f e88c185500               call      0xa530f0
00501864 50                       push      eax
00501865 57                       push      edi
00501866 8bce                     mov       ecx, esi
00501868 e89320faff               call      0x4a3900
0050186d eb02                     jmp       0x501871
0050186f 33c0                     xor       eax, eax
00501871 85c0                     test      eax, eax
00501873 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
0050187a 8983fc120000             mov       dword ptr [ebx + 0x12fc], eax
00501880 7420                     je        0x5018a2
00501882 c780cc02000007000000     mov       dword ptr [eax + 0x2cc], 7
0050188c c780d002000000000000     mov       dword ptr [eax + 0x2d0], 0
00501896 8b8bfc120000             mov       ecx, dword ptr [ebx + 0x12fc]
0050189c 53                       push      ebx
0050189d e87eb75200               call      0xa2d020
005018a2 8b4d08                   mov       ecx, dword ptr [ebp + 8]
005018a5 81c124070000             add       ecx, 0x724
005018ab 68e0baca00               push      0xcabae0
005018b0 894dec                   mov       dword ptr [ebp - 0x14], ecx
005018b3 e838185500               call      0xa530f0
005018b8 50                       push      eax
005018b9 e82df56f00               call      0xc00deb
005018be 83c408                   add       esp, 8
005018c1 85c0                     test      eax, eax
005018c3 0f847c000000             je        0x501945
005018c9 68e0020000               push      0x2e0
005018ce e87d23f0ff               call      0x403c50
005018d3 8bf8                     mov       edi, eax
005018d5 83c404                   add       esp, 4
005018d8 897de8                   mov       dword ptr [ebp - 0x18], edi
005018db 85ff                     test      edi, edi
005018dd c745fc13000000           mov       dword ptr [ebp - 4], 0x13
005018e4 742c                     je        0x501912
005018e6 83bb5c02000008           cmp       dword ptr [ebx + 0x25c], 8
005018ed 7208                     jb        0x5018f7
005018ef 8bb348020000             mov       esi, dword ptr [ebx + 0x248]
005018f5 eb06                     jmp       0x5018fd
005018f7 8db348020000             lea       esi, [ebx + 0x248]
005018fd 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
