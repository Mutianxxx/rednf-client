004bad60 55                       push      ebp
004bad61 8bec                     mov       ebp, esp
004bad63 6aff                     push      -1
004bad65 687078c500               push      0xc57870
004bad6a 64a100000000             mov       eax, dword ptr fs:[0]
004bad70 50                       push      eax
004bad71 64892500000000           mov       dword ptr fs:[0], esp
004bad78 83ec38                   sub       esp, 0x38
004bad7b 53                       push      ebx
004bad7c 56                       push      esi
004bad7d 8bf1                     mov       esi, ecx
004bad7f 57                       push      edi
004bad80 8d8e5c150000             lea       ecx, [esi + 0x155c]
004bad86 e8d572f4ff               call      0x402060
004bad8b 8bf8                     mov       edi, eax
004bad8d 8b06                     mov       eax, dword ptr [esi]
004bad8f 6a10                     push      0x10
004bad91 8bce                     mov       ecx, esi
004bad93 897de8                   mov       dword ptr [ebp - 0x18], edi
004bad96 ff9010040000             call      dword ptr [eax + 0x410]
004bad9c 84c0                     test      al, al
004bad9e 8b5d0c                   mov       ebx, dword ptr [ebp + 0xc]
004bada1 7412                     je        0x4badb5
004bada3 837d0806                 cmp       dword ptr [ebp + 8], 6
004bada7 750c                     jne       0x4badb5
004bada9 8b4304                   mov       eax, dword ptr [ebx + 4]
004badac 833800                   cmp       dword ptr [eax], 0
004badaf 0f84ce190000             je        0x4bc783
004badb5 85ff                     test      edi, edi
004badb7 7413                     je        0x4badcc
004badb9 83ff04                   cmp       edi, 4
004badbc 751a                     jne       0x4badd8
004badbe 8b16                     mov       edx, dword ptr [esi]
004badc0 6a03                     push      3
004badc2 8bce                     mov       ecx, esi
004badc4 ff9210040000             call      dword ptr [edx + 0x410]
004badca eb0c                     jmp       0x4badd8
004badcc 8b06                     mov       eax, dword ptr [esi]
004badce 6a01                     push      1
004badd0 8bce                     mov       ecx, esi
004badd2 ff9010010000             call      dword ptr [eax + 0x110]
004badd8 8b4508                   mov       eax, dword ptr [ebp + 8]
004baddb 83f809                   cmp       eax, 9
004badde 0f8761180000             ja        0x4bc645
004bade4 ff248598c74b00           jmp       dword ptr [eax*4 + 0x4bc798]
004badeb 8d4d0c                   lea       ecx, [ebp + 0xc]
004badee 51                       push      ecx
004badef 8d8eb4160000             lea       ecx, [esi + 0x16b4]
004badf5 c7450c01000000           mov       dword ptr [ebp + 0xc], 1
004badfc e85f97f4ff               call      0x404560
004bae01 8b1e                     mov       ebx, dword ptr [esi]
004bae03 8bce                     mov       ecx, esi
004bae05 ff9390030000             call      dword ptr [ebx + 0x390]
004bae0b 50                       push      eax
004bae0c 8bce                     mov       ecx, esi
004bae0e ff9300010000             call      dword ptr [ebx + 0x100]
004bae14 8b8648010000             mov       eax, dword ptr [esi + 0x148]
004bae1a 85c0                     test      eax, eax
004bae1c 8bce                     mov       ecx, esi
004bae1e 740c                     je        0x4bae2c
004bae20 8b16                     mov       edx, dword ptr [esi]
004bae22 6a00                     push      0
004bae24 ff92f0000000             call      dword ptr [edx + 0xf0]
004bae2a eb11                     jmp       0x4bae3d
004bae2c 8b1e                     mov       ebx, dword ptr [esi]
004bae2e ff9370030000             call      dword ptr [ebx + 0x370]
004bae34 50                       push      eax
004bae35 8bce                     mov       ecx, esi
004bae37 ff93f0000000             call      dword ptr [ebx + 0xf0]
004bae3d 8b06                     mov       eax, dword ptr [esi]
004bae3f 6a00                     push      0
004bae41 6a00                     push      0
004bae43 6a01                     push      1
004bae45 6a77                     push      0x77
004bae47 688f000000               push      0x8f
004bae4c 6a00                     push      0
004bae4e 8bce                     mov       ecx, esi
004bae50 ff9088040000             call      dword ptr [eax + 0x488]
004bae56 8b16                     mov       edx, dword ptr [esi]
004bae58 6a00                     push      0
004bae5a 6a00                     push      0
004bae5c 6a01                     push      1
004bae5e 6a5f                     push      0x5f
004bae60 6a72                     push      0x72
004bae62 6a01                     push      1
004bae64 8bce                     mov       ecx, esi
004bae66 ff9288040000             call      dword ptr [edx + 0x488]
004bae6c 8b06                     mov       eax, dword ptr [esi]
004bae6e 680000803f               push      0x3f800000
004bae73 680000803f               push      0x3f800000
004bae78 68e8030000               push      0x3e8
004bae7d 68e8030000               push      0x3e8
004bae82 6a00                     push      0
004bae84 6a01                     push      1
004bae86 8bce                     mov       ecx, esi
004bae88 ff9094040000             call      dword ptr [eax + 0x494]
004bae8e 8b16                     mov       edx, dword ptr [esi]
004bae90 6a00                     push      0
004bae92 6a04                     push      4
004bae94 6a04                     push      4
004bae96 8bce                     mov       ecx, esi
004bae98 ff929c040000             call      dword ptr [edx + 0x49c]
004bae9e 8b06                     mov       eax, dword ptr [esi]
004baea0 8bce                     mov       ecx, esi
004baea2 ff9008020000             call      dword ptr [eax + 0x208]
004baea8 85c0                     test      eax, eax
004baeaa 7f14                     jg        0x4baec0
004baeac 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004baeb2 6a00                     push      0
004baeb4 6a02                     push      2
004baeb6 e885610500               call      0x511040
004baebb e9e9000000               jmp       0x4bafa9
004baec0 8b16                     mov       edx, dword ptr [esi]
004baec2 8bce                     mov       ecx, esi
004baec4 ff9204020000             call      dword ptr [edx + 0x204]
004baeca 8bd8                     mov       ebx, eax
004baecc 8b06                     mov       eax, dword ptr [esi]
004baece 8bce                     mov       ecx, esi
004baed0 ff909c000000             call      dword ptr [eax + 0x9c]
004baed6 2bd8                     sub       ebx, eax
004baed8 74d2                     je        0x4baeac
004baeda 33c9                     xor       ecx, ecx
004baedc 85db                     test      ebx, ebx
004baede 0f9ec1                   setle     cl
004baee1 49                       dec       ecx
004baee2 81e130f8ffff             and       ecx, 0xfffff830
004baee8 81c1e8030000             add       ecx, 0x3e8
004baeee 51                       push      ecx
004baeef 6a00                     push      0
004baef1 8bce                     mov       ecx, esi
004baef3 e8c8f1ffff               call      0x4ba0c0
004baef8 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004baefe 53                       push      ebx
004baeff e82c6e0500               call      0x511d30
004baf04 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004baf0a 6a02                     push      2
004baf0c e85f5e0500               call      0x510d70
004baf11 e99e000000               jmp       0x4bafb4
004baf16 8b1e                     mov       ebx, dword ptr [esi]
004baf18 8bce                     mov       ecx, esi
004baf1a ff936c030000             call      dword ptr [ebx + 0x36c]
004baf20 50                       push      eax
004baf21 8bce                     mov       ecx, esi
004baf23 ff93f0000000             call      dword ptr [ebx + 0xf0]
004baf29 8b1e                     mov       ebx, dword ptr [esi]
004baf2b 8bce                     mov       ecx, esi
004baf2d ff9398030000             call      dword ptr [ebx + 0x398]
004baf33 50                       push      eax
004baf34 8bce                     mov       ecx, esi
004baf36 ff9300010000             call      dword ptr [ebx + 0x100]
004baf3c 8b16                     mov       edx, dword ptr [esi]
004baf3e 6a00                     push      0
004baf40 6a00                     push      0
004baf42 6a00                     push      0
004baf44 6a00                     push      0
004baf46 6a00                     push      0
004baf48 6a00                     push      0
004baf4a 8bce                     mov       ecx, esi
004baf4c ff9288040000             call      dword ptr [edx + 0x488]
004baf52 8b06                     mov       eax, dword ptr [esi]
004baf54 6a00                     push      0
004baf56 6a00                     push      0
004baf58 6a00                     push      0
004baf5a 6a00                     push      0
004baf5c 6a00                     push      0
004baf5e 6a01                     push      1
004baf60 8bce                     mov       ecx, esi
004baf62 ff9088040000             call      dword ptr [eax + 0x488]
004baf68 8b16                     mov       edx, dword ptr [esi]
004baf6a 680000803f               push      0x3f800000
004baf6f 680000803f               push      0x3f800000
004baf74 68e8030000               push      0x3e8
004baf79 68e8030000               push      0x3e8
004baf7e 6a00                     push      0
004baf80 6a00                     push      0
004baf82 8bce                     mov       ecx, esi
004baf84 ff9294040000             call      dword ptr [edx + 0x494]
004baf8a 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004baf90 6a00                     push      0
004baf92 6a02                     push      2
004baf94 e8a7600500               call      0x511040
004baf99 8b06                     mov       eax, dword ptr [esi]
004baf9b 6a00                     push      0
004baf9d 6a04                     push      4
004baf9f 6a04                     push      4
004bafa1 8bce                     mov       ecx, esi
004bafa3 ff909c040000             call      dword ptr [eax + 0x49c]
004bafa9 6a00                     push      0
004bafab 8bce                     mov       ecx, esi
004bafad 6a02                     push      2
004bafaf e80cf1ffff               call      0x4ba0c0
004bafb4 83ff04                   cmp       edi, 4
004bafb7 0f8588160000             jne       0x4bc645
004bafbd f686cc04000002           test      byte ptr [esi + 0x4cc], 2
004bafc4 0f847b160000             je        0x4bc645
004bafca 6a00                     push      0
004bafcc 6a01                     push      1
004bafce 6a00                     push      0
004bafd0 8bce                     mov       ecx, esi
004bafd2 e879fd5a00               call      0xa6ad50
004bafd7 68f4010000               push      0x1f4
004bafdc 6a00                     push      0
004bafde 6a00                     push      0
004bafe0 6a00                     push      0
004bafe2 8bce                     mov       ecx, esi
004bafe4 e837fd5a00               call      0xa6ad20
004bafe9 e957160000               jmp       0x4bc645
004bafee 8b1e                     mov       ebx, dword ptr [esi]
004baff0 8bce                     mov       ecx, esi
004baff2 ff936c030000             call      dword ptr [ebx + 0x36c]
004baff8 50                       push      eax
004baff9 8bce                     mov       ecx, esi
004baffb ff93f0000000             call      dword ptr [ebx + 0xf0]
004bb001 8b1e                     mov       ebx, dword ptr [esi]
004bb003 8bce                     mov       ecx, esi
004bb005 ff9398030000             call      dword ptr [ebx + 0x398]
004bb00b 50                       push      eax
004bb00c 8bce                     mov       ecx, esi
004bb00e ff9300010000             call      dword ptr [ebx + 0x100]
004bb014 8b16                     mov       edx, dword ptr [esi]
004bb016 6a00                     push      0
004bb018 6a00                     push      0
004bb01a 6a00                     push      0
004bb01c 6a00                     push      0
004bb01e 6a00                     push      0
004bb020 6a00                     push      0
004bb022 8bce                     mov       ecx, esi
004bb024 ff9288040000             call      dword ptr [edx + 0x488]
004bb02a 8b06                     mov       eax, dword ptr [esi]
004bb02c 6a00                     push      0
004bb02e 6a00                     push      0
004bb030 6a00                     push      0
004bb032 6a00                     push      0
004bb034 6a00                     push      0
004bb036 6a01                     push      1
004bb038 8bce                     mov       ecx, esi
004bb03a ff9088040000             call      dword ptr [eax + 0x488]
004bb040 8b16                     mov       edx, dword ptr [esi]
004bb042 680000803f               push      0x3f800000
004bb047 680000803f               push      0x3f800000
004bb04c 68e8030000               push      0x3e8
004bb051 68e8030000               push      0x3e8
004bb056 6a00                     push      0
004bb058 6a00                     push      0
004bb05a 8bce                     mov       ecx, esi
004bb05c ff9294040000             call      dword ptr [edx + 0x494]
004bb062 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bb068 6a00                     push      0
004bb06a 6a02                     push      2
004bb06c e8cf5f0500               call      0x511040
004bb071 8b06                     mov       eax, dword ptr [esi]
004bb073 6a00                     push      0
004bb075 6a04                     push      4
004bb077 6a04                     push      4
004bb079 8bce                     mov       ecx, esi
004bb07b ff909c040000             call      dword ptr [eax + 0x49c]
004bb081 6a00                     push      0
004bb083 6a02                     push      2
004bb085 8bce                     mov       ecx, esi
004bb087 e834f0ffff               call      0x4ba0c0
004bb08c e9b4150000               jmp       0x4bc645
004bb091 8b4304                   mov       eax, dword ptr [ebx + 4]
004bb094 db4004                   fild      dword ptr [eax + 4]
004bb097 8b4808                   mov       ecx, dword ptr [eax + 8]
004bb09a 8b38                     mov       edi, dword ptr [eax]
004bb09c 898ebc160000             mov       dword ptr [esi + 0x16bc], ecx
004bb0a2 d80dac10cc00             fmul      dword ptr [0xcc10ac]
004bb0a8 8b4304                   mov       eax, dword ptr [ebx + 4]
004bb0ab 33d2                     xor       edx, edx
004bb0ad 3bc2                     cmp       eax, edx
004bb0af d95ddc                   fstp      dword ptr [ebp - 0x24]
004bb0b2 89550c                   mov       dword ptr [ebp + 0xc], edx
004bb0b5 7413                     je        0x4bb0ca
004bb0b7 8b4b08                   mov       ecx, dword ptr [ebx + 8]
004bb0ba 2bc8                     sub       ecx, eax
004bb0bc c1f902                   sar       ecx, 2
004bb0bf 83f903                   cmp       ecx, 3
004bb0c2 7606                     jbe       0x4bb0ca
004bb0c4 8b480c                   mov       ecx, dword ptr [eax + 0xc]
004bb0c7 894d0c                   mov       dword ptr [ebp + 0xc], ecx
004bb0ca 3bc2                     cmp       eax, edx
004bb0cc 8955e0                   mov       dword ptr [ebp - 0x20], edx
004bb0cf 7413                     je        0x4bb0e4
004bb0d1 8b5b08                   mov       ebx, dword ptr [ebx + 8]
004bb0d4 2bd8                     sub       ebx, eax
004bb0d6 c1fb02                   sar       ebx, 2
004bb0d9 83fb04                   cmp       ebx, 4
004bb0dc 7606                     jbe       0x4bb0e4
004bb0de 8b5010                   mov       edx, dword ptr [eax + 0x10]
004bb0e1 8955e0                   mov       dword ptr [ebp - 0x20], edx
004bb0e4 33db                     xor       ebx, ebx
004bb0e6 53                       push      ebx
004bb0e7 68f49df500               push      0xf59df4
004bb0ec 686c52f500               push      0xf5526c
004bb0f1 53                       push      ebx
004bb0f2 56                       push      esi
004bb0f3 e8135c7400               call      0xc00d0b
004bb0f8 83c414                   add       esp, 0x14
004bb0fb 3bc3                     cmp       eax, ebx
004bb0fd 740a                     je        0x4bb109
004bb0ff 8a8870270000             mov       cl, byte ptr [eax + 0x2770]
004bb105 84c9                     test      cl, cl
004bb107 741c                     je        0x4bb125
004bb109 83ff04                   cmp       edi, 4
004bb10c 8bce                     mov       ecx, esi
004bb10e 750c                     jne       0x4bb11c
004bb110 8b06                     mov       eax, dword ptr [esi]
004bb112 ff90c0000000             call      dword ptr [eax + 0xc0]
004bb118 8bf8                     mov       edi, eax
004bb11a eb09                     jmp       0x4bb125
004bb11c 8b16                     mov       edx, dword ptr [esi]
004bb11e 57                       push      edi
004bb11f ff92b8000000             call      dword ptr [edx + 0xb8]
004bb125 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004bb128 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
004bb12b 8b06                     mov       eax, dword ptr [esi]
004bb12d 83fa02                   cmp       edx, 2
004bb130 0f94c2                   sete      dl
004bb133 51                       push      ecx
004bb134 8b4de0                   mov       ecx, dword ptr [ebp - 0x20]
004bb137 895de8                   mov       dword ptr [ebp - 0x18], ebx
004bb13a 895de4                   mov       dword ptr [ebp - 0x1c], ebx
004bb13d 52                       push      edx
004bb13e 51                       push      ecx
004bb13f 8d55e4                   lea       edx, [ebp - 0x1c]
004bb142 52                       push      edx
004bb143 8d4de8                   lea       ecx, [ebp - 0x18]
004bb146 51                       push      ecx
004bb147 8bce                     mov       ecx, esi
004bb149 ff9018050000             call      dword ptr [eax + 0x518]
004bb14f 8d550c                   lea       edx, [ebp + 0xc]
004bb152 52                       push      edx
004bb153 8d8ec0160000             lea       ecx, [esi + 0x16c0]
004bb159 89450c                   mov       dword ptr [ebp + 0xc], eax
004bb15c e8ff93f4ff               call      0x404560
004bb161 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
004bb164 8b16                     mov       edx, dword ptr [esi]
004bb166 6a01                     push      1
004bb168 50                       push      eax
004bb169 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
004bb16c 53                       push      ebx
004bb16d 50                       push      eax
004bb16e 50                       push      eax
004bb16f 53                       push      ebx
004bb170 8bce                     mov       ecx, esi
004bb172 ff9288040000             call      dword ptr [edx + 0x488]
004bb178 8b16                     mov       edx, dword ptr [esi]
004bb17a 53                       push      ebx
004bb17b 53                       push      ebx
004bb17c 53                       push      ebx
004bb17d 53                       push      ebx
004bb17e 53                       push      ebx
004bb17f 6a01                     push      1
004bb181 8bce                     mov       ecx, esi
004bb183 ff9288040000             call      dword ptr [edx + 0x488]
004bb189 8b06                     mov       eax, dword ptr [esi]
004bb18b 680000803f               push      0x3f800000
004bb190 680000803f               push      0x3f800000
004bb195 68e8030000               push      0x3e8
004bb19a 68e8030000               push      0x3e8
004bb19f 53                       push      ebx
004bb1a0 53                       push      ebx
004bb1a1 8bce                     mov       ecx, esi
004bb1a3 ff9094040000             call      dword ptr [eax + 0x494]
004bb1a9 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bb1af 53                       push      ebx
004bb1b0 6a02                     push      2
004bb1b2 e8895e0500               call      0x511040
004bb1b7 8b06                     mov       eax, dword ptr [esi]
004bb1b9 53                       push      ebx
004bb1ba 6a04                     push      4
004bb1bc 57                       push      edi
004bb1bd 89450c                   mov       dword ptr [ebp + 0xc], eax
004bb1c0 e89bc7f8ff               call      0x447960
004bb1c5 83c404                   add       esp, 4
004bb1c8 50                       push      eax
004bb1c9 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004bb1cc 8bce                     mov       ecx, esi
004bb1ce ff909c040000             call      dword ptr [eax + 0x49c]
004bb1d4 53                       push      ebx
004bb1d5 6a02                     push      2
004bb1d7 8bce                     mov       ecx, esi
004bb1d9 e8e2eeffff               call      0x4ba0c0
004bb1de 8b86bc160000             mov       eax, dword ptr [esi + 0x16bc]
004bb1e4 8b16                     mov       edx, dword ptr [esi]
004bb1e6 50                       push      eax
004bb1e7 8bce                     mov       ecx, esi
004bb1e9 ff9274030000             call      dword ptr [edx + 0x374]
004bb1ef 85c0                     test      eax, eax
004bb1f1 0f844e140000             je        0x4bc645
004bb1f7 8b8ebc160000             mov       ecx, dword ptr [esi + 0x16bc]
004bb1fd 8b3e                     mov       edi, dword ptr [esi]
004bb1ff 51                       push      ecx
004bb200 8bce                     mov       ecx, esi
004bb202 ff979c030000             call      dword ptr [edi + 0x39c]
004bb208 50                       push      eax
004bb209 8bce                     mov       ecx, esi
004bb20b ff9700010000             call      dword ptr [edi + 0x100]
004bb211 8b86bc160000             mov       eax, dword ptr [esi + 0x16bc]
004bb217 8b16                     mov       edx, dword ptr [esi]
004bb219 50                       push      eax
004bb21a 8bce                     mov       ecx, esi
004bb21c ff929c030000             call      dword ptr [edx + 0x39c]
004bb222 85c0                     test      eax, eax
004bb224 0f851b140000             jne       0x4bc645
004bb22a 8b8ebc160000             mov       ecx, dword ptr [esi + 0x16bc]
004bb230 8b3e                     mov       edi, dword ptr [esi]
004bb232 51                       push      ecx
004bb233 8bce                     mov       ecx, esi
004bb235 ff9774030000             call      dword ptr [edi + 0x374]
004bb23b 50                       push      eax
004bb23c 8bce                     mov       ecx, esi
004bb23e ff97f0000000             call      dword ptr [edi + 0xf0]
004bb244 e9fc130000               jmp       0x4bc645
004bb249 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb24f e80c6ef4ff               call      0x402060
004bb254 8b9628170000             mov       edx, dword ptr [esi + 0x1728]
004bb25a 8945e4                   mov       dword ptr [ebp - 0x1c], eax
004bb25d 8b06                     mov       eax, dword ptr [esi]
004bb25f 8bce                     mov       ecx, esi
004bb261 8955dc                   mov       dword ptr [ebp - 0x24], edx
004bb264 ff90c0000000             call      dword ptr [eax + 0xc0]
004bb26a 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bb26d 8b4304                   mov       eax, dword ptr [ebx + 4]
004bb270 8b08                     mov       ecx, dword ptr [eax]
004bb272 83f904                   cmp       ecx, 4
004bb275 7403                     je        0x4bb27a
004bb277 894dec                   mov       dword ptr [ebp - 0x14], ecx
004bb27a 8d550c                   lea       edx, [ebp + 0xc]
004bb27d 33ff                     xor       edi, edi
004bb27f 52                       push      edx
004bb280 8d8e14170000             lea       ecx, [esi + 0x1714]
004bb286 897d0c                   mov       dword ptr [ebp + 0xc], edi
004bb289 e8d292f4ff               call      0x404560
004bb28e 8b06                     mov       eax, dword ptr [esi]
004bb290 8bce                     mov       ecx, esi
004bb292 ff9094000000             call      dword ptr [eax + 0x94]
004bb298 897d0c                   mov       dword ptr [ebp + 0xc], edi
004bb29b 8d4d0c                   lea       ecx, [ebp + 0xc]
004bb29e 8dbe0c170000             lea       edi, [esi + 0x170c]
004bb2a4 51                       push      ecx
004bb2a5 8bcf                     mov       ecx, edi
004bb2a7 89861c170000             mov       dword ptr [esi + 0x171c], eax
004bb2ad e8ae92f4ff               call      0x404560
004bb2b2 8b16                     mov       edx, dword ptr [esi]
004bb2b4 6a03                     push      3
004bb2b6 8bce                     mov       ecx, esi
004bb2b8 c745f000000000           mov       dword ptr [ebp - 0x10], 0
004bb2bf ff9244030000             call      dword ptr [edx + 0x344]
004bb2c5 8bc8                     mov       ecx, eax
004bb2c7 e8f42a0000               call      0x4bddc0
004bb2cc 8945e0                   mov       dword ptr [ebp - 0x20], eax
004bb2cf 8b4304                   mov       eax, dword ptr [ebx + 4]
004bb2d2 8b4004                   mov       eax, dword ptr [eax + 4]
004bb2d5 8d4d0c                   lea       ecx, [ebp + 0xc]
004bb2d8 51                       push      ecx
004bb2d9 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb2df 89450c                   mov       dword ptr [ebp + 0xc], eax
004bb2e2 e87992f4ff               call      0x404560
004bb2e7 8b4304                   mov       eax, dword ptr [ebx + 4]
004bb2ea 8b5008                   mov       edx, dword ptr [eax + 8]
004bb2ed 837de804                 cmp       dword ptr [ebp - 0x18], 4
004bb2f1 899628170000             mov       dword ptr [esi + 0x1728], edx
004bb2f7 c6450f00                 mov       byte ptr [ebp + 0xf], 0
004bb2fb 7528                     jne       0x4bb325
004bb2fd 8b06                     mov       eax, dword ptr [esi]
004bb2ff 8bce                     mov       ecx, esi
004bb301 ff909c000000             call      dword ptr [eax + 0x9c]
004bb307 85c0                     test      eax, eax
004bb309 751a                     jne       0x4bb325
004bb30b 837ddc02                 cmp       dword ptr [ebp - 0x24], 2
004bb30f 7410                     je        0x4bb321
004bb311 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb317 e8446df4ff               call      0x402060
004bb31c 3b45e4                   cmp       eax, dword ptr [ebp - 0x1c]
004bb31f 7e04                     jle       0x4bb325
004bb321 c6450f01                 mov       byte ptr [ebp + 0xf], 1
004bb325 8b8628170000             mov       eax, dword ptr [esi + 0x1728]
004bb32b 83f802                   cmp       eax, 2
004bb32e 7509                     jne       0x4bb339
004bb330 c6862c17000001           mov       byte ptr [esi + 0x172c], 1
004bb337 eb0e                     jmp       0x4bb347
004bb339 8a4d0f                   mov       cl, byte ptr [ebp + 0xf]
004bb33c 84c9                     test      cl, cl
004bb33e 7507                     jne       0x4bb347
004bb340 c6862c17000000           mov       byte ptr [esi + 0x172c], 0
004bb347 83f801                   cmp       eax, 1
004bb34a 747d                     je        0x4bb3c9
004bb34c 83f802                   cmp       eax, 2
004bb34f 7478                     je        0x4bb3c9
004bb351 85c0                     test      eax, eax
004bb353 0f8543010000             jne       0x4bb49c
004bb359 8b4304                   mov       eax, dword ptr [ebx + 4]
004bb35c 8b480c                   mov       ecx, dword ptr [eax + 0xc]
004bb35f 8d55f0                   lea       edx, [ebp - 0x10]
004bb362 894df0                   mov       dword ptr [ebp - 0x10], ecx
004bb365 52                       push      edx
004bb366 8bcf                     mov       ecx, edi
004bb368 e8f391f4ff               call      0x404560
004bb36d 8b5b04                   mov       ebx, dword ptr [ebx + 4]
004bb370 8b4310                   mov       eax, dword ptr [ebx + 0x10]
004bb373 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb379 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bb37c e8df6cf4ff               call      0x402060
004bb381 83f801                   cmp       eax, 1
004bb384 0f8512010000             jne       0x4bb49c
004bb38a 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004bb38d 85c0                     test      eax, eax
004bb38f 0f8f07010000             jg        0x4bb49c
004bb395 8b16                     mov       edx, dword ptr [esi]
004bb397 8bce                     mov       ecx, esi
004bb399 ff929c000000             call      dword ptr [edx + 0x9c]
004bb39f 85c0                     test      eax, eax
004bb3a1 0f8ff5000000             jg        0x4bb49c
004bb3a7 8d45d8                   lea       eax, [ebp - 0x28]
004bb3aa 50                       push      eax
004bb3ab 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb3b1 c745d802000000           mov       dword ptr [ebp - 0x28], 2
004bb3b8 e8a391f4ff               call      0x404560
004bb3bd c6051452000101           mov       byte ptr [0x1005214], 1
004bb3c4 e9d3000000               jmp       0x4bb49c
004bb3c9 83f802                   cmp       eax, 2
004bb3cc 8b5b04                   mov       ebx, dword ptr [ebx + 4]
004bb3cf 8b4b0c                   mov       ecx, dword ptr [ebx + 0xc]
004bb3d2 8b5b10                   mov       ebx, dword ptr [ebx + 0x10]
004bb3d5 894df0                   mov       dword ptr [ebp - 0x10], ecx
004bb3d8 7541                     jne       0x4bb41b
004bb3da 837de804                 cmp       dword ptr [ebp - 0x18], 4
004bb3de 750f                     jne       0x4bb3ef
004bb3e0 837de402                 cmp       dword ptr [ebp - 0x1c], 2
004bb3e4 7c09                     jl        0x4bb3ef
004bb3e6 8bc3                     mov       eax, ebx
004bb3e8 99                       cdq       
004bb3e9 2bc2                     sub       eax, edx
004bb3eb d1f8                     sar       eax, 1
004bb3ed 8bd8                     mov       ebx, eax
004bb3ef 8d55d8                   lea       edx, [ebp - 0x28]
004bb3f2 52                       push      edx
004bb3f3 8d8e30170000             lea       ecx, [esi + 0x1730]
004bb3f9 895dd8                   mov       dword ptr [ebp - 0x28], ebx
004bb3fc e85f91f4ff               call      0x404560
004bb401 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004bb404 8d4dd8                   lea       ecx, [ebp - 0x28]
004bb407 51                       push      ecx
004bb408 8d8e38170000             lea       ecx, [esi + 0x1738]
004bb40e 8945d8                   mov       dword ptr [ebp - 0x28], eax
004bb411 e84a91f4ff               call      0x404560
004bb416 bb70feffff               mov       ebx, 0xfffffe70
004bb41b 8b55e0                   mov       edx, dword ptr [ebp - 0x20]
004bb41e 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004bb421 6a64                     push      0x64
004bb423 52                       push      edx
004bb424 50                       push      eax
004bb425 e8c6e4ffff               call      0x4b98f0
004bb42a 83c40c                   add       esp, 0xc
004bb42d e812617400               call      0xc01544
004bb432 8d4dd8                   lea       ecx, [ebp - 0x28]
004bb435 51                       push      ecx
004bb436 8bcf                     mov       ecx, edi
004bb438 8945d8                   mov       dword ptr [ebp - 0x28], eax
004bb43b e82091f4ff               call      0x404560
004bb440 8b55e0                   mov       edx, dword ptr [ebp - 0x20]
004bb443 6a64                     push      0x64
004bb445 52                       push      edx
004bb446 53                       push      ebx
004bb447 e8a4e4ffff               call      0x4b98f0
004bb44c 83c40c                   add       esp, 0xc
004bb44f e8f0607400               call      0xc01544
004bb454 6a01                     push      1
004bb456 8bce                     mov       ecx, esi
004bb458 8bd8                     mov       ebx, eax
004bb45a e841ebffff               call      0x4b9fa0
004bb45f 8bc8                     mov       ecx, eax
004bb461 8bc3                     mov       eax, ebx
004bb463 0fafc3                   imul      eax, ebx
004bb466 f7d9                     neg       ecx
004bb468 d1e1                     shl       ecx, 1
004bb46a 99                       cdq       
004bb46b f7f9                     idiv      ecx
004bb46d 85db                     test      ebx, ebx
004bb46f 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bb472 7d07                     jge       0x4bb47b
004bb474 8bd0                     mov       edx, eax
004bb476 f7da                     neg       edx
004bb478 8955f0                   mov       dword ptr [ebp - 0x10], edx
004bb47b 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb481 e8da6bf4ff               call      0x402060
004bb486 83f801                   cmp       eax, 1
004bb489 7511                     jne       0x4bb49c
004bb48b 85db                     test      ebx, ebx
004bb48d 7e0d                     jle       0x4bb49c
004bb48f 837df001                 cmp       dword ptr [ebp - 0x10], 1
004bb493 7d07                     jge       0x4bb49c
004bb495 c745f001000000           mov       dword ptr [ebp - 0x10], 1
004bb49c 8a450f                   mov       al, byte ptr [ebp + 0xf]
004bb49f 84c0                     test      al, al
004bb4a1 7564                     jne       0x4bb507
004bb4a3 8bcf                     mov       ecx, edi
004bb4a5 e8b66bf4ff               call      0x402060
004bb4aa 85c0                     test      eax, eax
004bb4ac 7d26                     jge       0x4bb4d4
004bb4ae 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004bb4b1 50                       push      eax
004bb4b2 e8a9c4f8ff               call      0x447960
004bb4b7 83c404                   add       esp, 4
004bb4ba 8bcf                     mov       ecx, edi
004bb4bc 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bb4bf e89c6bf4ff               call      0x402060
004bb4c4 8d4dd8                   lea       ecx, [ebp - 0x28]
004bb4c7 f7d8                     neg       eax
004bb4c9 51                       push      ecx
004bb4ca 8bcf                     mov       ecx, edi
004bb4cc 8945d8                   mov       dword ptr [ebp - 0x28], eax
004bb4cf e88c90f4ff               call      0x404560
004bb4d4 6a00                     push      0
004bb4d6 68f49df500               push      0xf59df4
004bb4db 686c52f500               push      0xf5526c
004bb4e0 6a00                     push      0
004bb4e2 56                       push      esi
004bb4e3 e823587400               call      0xc00d0b
004bb4e8 83c414                   add       esp, 0x14
004bb4eb 85c0                     test      eax, eax
004bb4ed 740a                     je        0x4bb4f9
004bb4ef 8a8870270000             mov       cl, byte ptr [eax + 0x2770]
004bb4f5 84c9                     test      cl, cl
004bb4f7 740e                     je        0x4bb507
004bb4f9 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004bb4fc 8b16                     mov       edx, dword ptr [esi]
004bb4fe 50                       push      eax
004bb4ff 8bce                     mov       ecx, esi
004bb501 ff92b8000000             call      dword ptr [edx + 0xb8]
004bb507 8bcf                     mov       ecx, edi
004bb509 e8526bf4ff               call      0x402060
004bb50e 99                       cdq       
004bb50f 2bc2                     sub       eax, edx
004bb511 8d4dd8                   lea       ecx, [ebp - 0x28]
004bb514 d1f8                     sar       eax, 1
004bb516 51                       push      ecx
004bb517 8bcf                     mov       ecx, edi
004bb519 8945d8                   mov       dword ptr [ebp - 0x28], eax
004bb51c e83f90f4ff               call      0x404560
004bb521 8b16                     mov       edx, dword ptr [esi]
004bb523 8bce                     mov       ecx, esi
004bb525 ff92a0030000             call      dword ptr [edx + 0x3a0]
004bb52b 85c0                     test      eax, eax
004bb52d 8bce                     mov       ecx, esi
004bb52f 741f                     je        0x4bb550
004bb531 8b1e                     mov       ebx, dword ptr [esi]
004bb533 ff93a0030000             call      dword ptr [ebx + 0x3a0]
004bb539 50                       push      eax
004bb53a 8bce                     mov       ecx, esi
004bb53c ff9300010000             call      dword ptr [ebx + 0x100]
004bb542 8b06                     mov       eax, dword ptr [esi]
004bb544 6a00                     push      0
004bb546 8bce                     mov       ecx, esi
004bb548 ff90f0000000             call      dword ptr [eax + 0xf0]
004bb54e eb37                     jmp       0x4bb587
004bb550 8b16                     mov       edx, dword ptr [esi]
004bb552 ff9278030000             call      dword ptr [edx + 0x378]
004bb558 85c0                     test      eax, eax
004bb55a 8bce                     mov       ecx, esi
004bb55c 740a                     je        0x4bb568
004bb55e 8b1e                     mov       ebx, dword ptr [esi]
004bb560 ff9378030000             call      dword ptr [ebx + 0x378]
004bb566 eb16                     jmp       0x4bb57e
004bb568 8b06                     mov       eax, dword ptr [esi]
004bb56a ff906c030000             call      dword ptr [eax + 0x36c]
004bb570 85c0                     test      eax, eax
004bb572 7413                     je        0x4bb587
004bb574 8b1e                     mov       ebx, dword ptr [esi]
004bb576 8bce                     mov       ecx, esi
004bb578 ff936c030000             call      dword ptr [ebx + 0x36c]
004bb57e 8bce                     mov       ecx, esi
004bb580 50                       push      eax
004bb581 ff93f0000000             call      dword ptr [ebx + 0xf0]
004bb587 8d9e20170000             lea       ebx, [esi + 0x1720]
004bb58d 8bcb                     mov       ecx, ebx
004bb58f e8cc6af4ff               call      0x402060
004bb594 85c0                     test      eax, eax
004bb596 744e                     je        0x4bb5e6
004bb598 8bcb                     mov       ecx, ebx
004bb59a e8c16af4ff               call      0x402060
004bb59f 83f801                   cmp       eax, 1
004bb5a2 751d                     jne       0x4bb5c1
004bb5a4 837de804                 cmp       dword ptr [ebp - 0x18], 4
004bb5a8 753c                     jne       0x4bb5e6
004bb5aa 837de401                 cmp       dword ptr [ebp - 0x1c], 1
004bb5ae 7c36                     jl        0x4bb5e6
004bb5b0 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004bb5b3 99                       cdq       
004bb5b4 83e203                   and       edx, 3
004bb5b7 03c2                     add       eax, edx
004bb5b9 c1f802                   sar       eax, 2
004bb5bc 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bb5bf eb25                     jmp       0x4bb5e6
004bb5c1 8bcb                     mov       ecx, ebx
004bb5c3 e8986af4ff               call      0x402060
004bb5c8 83f802                   cmp       eax, 2
004bb5cb 7519                     jne       0x4bb5e6
004bb5cd 8d4dd8                   lea       ecx, [ebp - 0x28]
004bb5d0 51                       push      ecx
004bb5d1 8bcf                     mov       ecx, edi
004bb5d3 c745d800000000           mov       dword ptr [ebp - 0x28], 0
004bb5da e8818ff4ff               call      0x404560
004bb5df c745f000000000           mov       dword ptr [ebp - 0x10], 0
004bb5e6 8a450f                   mov       al, byte ptr [ebp + 0xf]
004bb5e9 84c0                     test      al, al
004bb5eb 0f8407010000             je        0x4bb6f8
004bb5f1 8bcb                     mov       ecx, ebx
004bb5f3 e8686af4ff               call      0x402060
004bb5f8 83f802                   cmp       eax, 2
004bb5fb 743e                     je        0x4bb63b
004bb5fd 8b45e0                   mov       eax, dword ptr [ebp - 0x20]
004bb600 3d60ea0000               cmp       eax, 0xea60
004bb605 6a00                     push      0
004bb607 6a00                     push      0
004bb609 6aff                     push      -1
004bb60b 7f07                     jg        0x4bb614
004bb60d 680015cd00               push      0xcd1500
004bb612 eb1d                     jmp       0x4bb631
004bb614 3da0860100               cmp       eax, 0x186a0
004bb619 7f11                     jg        0x4bb62c
004bb61b 8b06                     mov       eax, dword ptr [esi]
004bb61d 68e814cd00               push      0xcd14e8
004bb622 8bce                     mov       ecx, esi
004bb624 ff900c010000             call      dword ptr [eax + 0x10c]
004bb62a eb0f                     jmp       0x4bb63b
004bb62c 68d014cd00               push      0xcd14d0
004bb631 8b16                     mov       edx, dword ptr [esi]
004bb633 8bce                     mov       ecx, esi
004bb635 ff920c010000             call      dword ptr [edx + 0x10c]
004bb63b 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004bb641 85c0                     test      eax, eax
004bb643 0f84af000000             je        0x4bb6f8
004bb649 8bcb                     mov       ecx, ebx
004bb64b e8106af4ff               call      0x402060
004bb650 83f801                   cmp       eax, 1
004bb653 8bce                     mov       ecx, esi
004bb655 750c                     jne       0x4bb663
004bb657 8b06                     mov       eax, dword ptr [esi]
004bb659 6a00                     push      0
004bb65b ff90d0040000             call      dword ptr [eax + 0x4d0]
004bb661 eb0a                     jmp       0x4bb66d
004bb663 8b16                     mov       edx, dword ptr [esi]
004bb665 6a01                     push      1
004bb667 ff92d0040000             call      dword ptr [edx + 0x4d0]
004bb66d 8b3c85782e0001           mov       edi, dword ptr [eax*4 + 0x1002e78]
004bb674 8b06                     mov       eax, dword ptr [esi]
004bb676 8bce                     mov       ecx, esi
004bb678 ff90c0000000             call      dword ptr [eax + 0xc0]
004bb67e 8b17                     mov       edx, dword ptr [edi]
004bb680 8bd8                     mov       ebx, eax
004bb682 f7db                     neg       ebx
004bb684 1adb                     sbb       bl, bl
004bb686 8bcf                     mov       ecx, edi
004bb688 fec3                     inc       bl
004bb68a ff521c                   call      dword ptr [edx + 0x1c]
004bb68d 885858                   mov       byte ptr [eax + 0x58], bl
004bb690 8b06                     mov       eax, dword ptr [esi]
004bb692 8b1f                     mov       ebx, dword ptr [edi]
004bb694 8bce                     mov       ecx, esi
004bb696 ff909c000000             call      dword ptr [eax + 0x9c]
004bb69c 8b16                     mov       edx, dword ptr [esi]
004bb69e 50                       push      eax
004bb69f 8bce                     mov       ecx, esi
004bb6a1 ff9298000000             call      dword ptr [edx + 0x98]
004bb6a7 50                       push      eax
004bb6a8 8b06                     mov       eax, dword ptr [esi]
004bb6aa 8bce                     mov       ecx, esi
004bb6ac ff9094000000             call      dword ptr [eax + 0x94]
004bb6b2 50                       push      eax
004bb6b3 8bcf                     mov       ecx, edi
004bb6b5 ff5328                   call      dword ptr [ebx + 0x28]
004bb6b8 8b17                     mov       edx, dword ptr [edi]
004bb6ba 6a00                     push      0
004bb6bc 8bcf                     mov       ecx, edi
004bb6be ff520c                   call      dword ptr [edx + 0xc]
004bb6c1 8b07                     mov       eax, dword ptr [edi]
004bb6c3 8d4dcc                   lea       ecx, [ebp - 0x34]
004bb6c6 51                       push      ecx
004bb6c7 8bcf                     mov       ecx, edi
004bb6c9 ff505c                   call      dword ptr [eax + 0x5c]
004bb6cc 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004bb6d2 6a00                     push      0
004bb6d4 8d55cc                   lea       edx, [ebp - 0x34]
004bb6d7 52                       push      edx
004bb6d8 6a00                     push      0
004bb6da 6a02                     push      2
004bb6dc 56                       push      esi
004bb6dd c745fc00000000           mov       dword ptr [ebp - 4], 0
004bb6e4 e877290500               call      0x50e060
004bb6e9 8d4dcc                   lea       ecx, [ebp - 0x34]
004bb6ec c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004bb6f3 e858961800               call      0x644d50
004bb6f8 68e7030000               push      0x3e7
004bb6fd 6a00                     push      0
004bb6ff e8ec293f00               call      0x8ae0f0
004bb704 99                       cdq       
004bb705 b9e8030000               mov       ecx, 0x3e8
004bb70a f7f9                     idiv      ecx
004bb70c 83c404                   add       esp, 4
004bb70f 8d9e0c170000             lea       ebx, [esi + 0x170c]
004bb715 8bcb                     mov       ecx, ebx
004bb717 52                       push      edx
004bb718 e84369f4ff               call      0x402060
004bb71d 89450c                   mov       dword ptr [ebp + 0xc], eax
004bb720 db450c                   fild      dword ptr [ebp + 0xc]
004bb723 dc0dc814cd00             fmul      qword ptr [0xcd14c8]
004bb729 e8165e7400               call      0xc01544
004bb72e 50                       push      eax
004bb72f 8bcb                     mov       ecx, ebx
004bb731 e82a69f4ff               call      0x402060
004bb736 89450c                   mov       dword ptr [ebp + 0xc], eax
004bb739 db450c                   fild      dword ptr [ebp + 0xc]
004bb73c dc0dc014cd00             fmul      qword ptr [0xcd14c0]
004bb742 e8fd5d7400               call      0xc01544
004bb747 50                       push      eax
004bb748 e8d387fbff               call      0x473f20
004bb74d 83c410                   add       esp, 0x10
004bb750 8d550c                   lea       edx, [ebp + 0xc]
004bb753 52                       push      edx
004bb754 8bcb                     mov       ecx, ebx
004bb756 89450c                   mov       dword ptr [ebp + 0xc], eax
004bb759 e8028ef4ff               call      0x404560
004bb75e db45f0                   fild      dword ptr [ebp - 0x10]
004bb761 68e7030000               push      0x3e7
004bb766 6a00                     push      0
004bb768 dd5dd4                   fstp      qword ptr [ebp - 0x2c]
004bb76b e880293f00               call      0x8ae0f0
004bb770 99                       cdq       
004bb771 dd45d4                   fld       qword ptr [ebp - 0x2c]
004bb774 b9e8030000               mov       ecx, 0x3e8
004bb779 dc0db814cd00             fmul      qword ptr [0xcd14b8]
004bb77f f7f9                     idiv      ecx
004bb781 83c404                   add       esp, 4
004bb784 52                       push      edx
004bb785 e8ba5d7400               call      0xc01544
004bb78a dd45d4                   fld       qword ptr [ebp - 0x2c]
004bb78d dc0db014cd00             fmul      qword ptr [0xcd14b0]
004bb793 50                       push      eax
004bb794 e8ab5d7400               call      0xc01544
004bb799 50                       push      eax
004bb79a e88187fbff               call      0x473f20
004bb79f 8b3e                     mov       edi, dword ptr [esi]
004bb7a1 83c410                   add       esp, 0x10
004bb7a4 6a00                     push      0
004bb7a6 6a00                     push      0
004bb7a8 6a00                     push      0
004bb7aa 8bcb                     mov       ecx, ebx
004bb7ac 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bb7af e8ac68f4ff               call      0x402060
004bb7b4 50                       push      eax
004bb7b5 8bcb                     mov       ecx, ebx
004bb7b7 e8a468f4ff               call      0x402060
004bb7bc 50                       push      eax
004bb7bd 6a00                     push      0
004bb7bf 8bce                     mov       ecx, esi
004bb7c1 ff9788040000             call      dword ptr [edi + 0x488]
004bb7c7 8b16                     mov       edx, dword ptr [esi]
004bb7c9 6a00                     push      0
004bb7cb 6a00                     push      0
004bb7cd 6a00                     push      0
004bb7cf 6a00                     push      0
004bb7d1 6a00                     push      0
004bb7d3 6a01                     push      1
004bb7d5 8bce                     mov       ecx, esi
004bb7d7 ff9288040000             call      dword ptr [edx + 0x488]
004bb7dd 8b06                     mov       eax, dword ptr [esi]
004bb7df 680000803f               push      0x3f800000
004bb7e4 680000803f               push      0x3f800000
004bb7e9 68e8030000               push      0x3e8
004bb7ee 68e8030000               push      0x3e8
004bb7f3 6a00                     push      0
004bb7f5 6a00                     push      0
004bb7f7 8bce                     mov       ecx, esi
004bb7f9 ff9094040000             call      dword ptr [eax + 0x494]
004bb7ff 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004bb802 8b3e                     mov       edi, dword ptr [esi]
004bb804 6a00                     push      0
004bb806 6a04                     push      4
004bb808 51                       push      ecx
004bb809 e852c1f8ff               call      0x447960
004bb80e 83c404                   add       esp, 4
004bb811 50                       push      eax
004bb812 8bce                     mov       ecx, esi
004bb814 ff979c040000             call      dword ptr [edi + 0x49c]
004bb81a 6a00                     push      0
004bb81c 6a01                     push      1
004bb81e 8bce                     mov       ecx, esi
004bb820 e89be8ffff               call      0x4ba0c0
004bb825 8b16                     mov       edx, dword ptr [esi]
004bb827 6811020000               push      0x211
004bb82c 8bce                     mov       ecx, esi
004bb82e ff522c                   call      dword ptr [edx + 0x2c]
004bb831 84c0                     test      al, al
004bb833 7414                     je        0x4bb849
004bb835 6812000100               push      0x10012
004bb83a 8bce                     mov       ecx, esi
004bb83c e8df480300               call      0x4f0120
004bb841 84c0                     test      al, al
004bb843 7404                     je        0x4bb849
004bb845 33c0                     xor       eax, eax
004bb847 eb03                     jmp       0x4bb84c
004bb849 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004bb84c 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bb852 50                       push      eax
004bb853 e8d8640500               call      0x511d30
004bb858 8d8e20170000             lea       ecx, [esi + 0x1720]
004bb85e e8fd67f4ff               call      0x402060
004bb863 8bf8                     mov       edi, eax
004bb865 837de804                 cmp       dword ptr [ebp - 0x18], 4
004bb869 750d                     jne       0x4bb878
004bb86b 837ddc02                 cmp       dword ptr [ebp - 0x24], 2
004bb86f 7507                     jne       0x4bb878
004bb871 bf01000000               mov       edi, 1
004bb876 eb0e                     jmp       0x4bb886
004bb878 83ff01                   cmp       edi, 1
004bb87b 7409                     je        0x4bb886
004bb87d 83ff02                   cmp       edi, 2
004bb880 0f85bf0d0000             jne       0x4bc645
004bb886 8b06                     mov       eax, dword ptr [esi]
004bb888 8bce                     mov       ecx, esi
004bb88a ff9004010000             call      dword ptr [eax + 0x104]
004bb890 85c0                     test      eax, eax
004bb892 8bce                     mov       ecx, esi
004bb894 746b                     je        0x4bb901
004bb896 8b16                     mov       edx, dword ptr [esi]
004bb898 6a00                     push      0
004bb89a ff9204010000             call      dword ptr [edx + 0x104]
004bb8a0 8bc8                     mov       ecx, eax
004bb8a2 e8891d5700               call      0xa2d630
004bb8a7 83ff01                   cmp       edi, 1
004bb8aa 7526                     jne       0x4bb8d2
004bb8ac 8d8ef4160000             lea       ecx, [esi + 0x16f4]
004bb8b2 e8a967f4ff               call      0x402060
004bb8b7 50                       push      eax
004bb8b8 8b06                     mov       eax, dword ptr [esi]
004bb8ba 8bce                     mov       ecx, esi
004bb8bc ff9004010000             call      dword ptr [eax + 0x104]
004bb8c2 8bc8                     mov       ecx, eax
004bb8c4 e8e74c5700               call      0xa305b0
004bb8c9 c6451400                 mov       byte ptr [ebp + 0x14], 0
004bb8cd e9730d0000               jmp       0x4bc645
004bb8d2 83ff02                   cmp       edi, 2
004bb8d5 0f8592000000             jne       0x4bb96d
004bb8db 8d8e04170000             lea       ecx, [esi + 0x1704]
004bb8e1 e87a67f4ff               call      0x402060
004bb8e6 8b16                     mov       edx, dword ptr [esi]
004bb8e8 50                       push      eax
004bb8e9 8bce                     mov       ecx, esi
004bb8eb ff9204010000             call      dword ptr [edx + 0x104]
004bb8f1 8bc8                     mov       ecx, eax
004bb8f3 e8b84c5700               call      0xa305b0
004bb8f8 c6451400                 mov       byte ptr [ebp + 0x14], 0
004bb8fc e9440d0000               jmp       0x4bc645
004bb901 8b06                     mov       eax, dword ptr [esi]
004bb903 ff90f4000000             call      dword ptr [eax + 0xf4]
004bb909 85c0                     test      eax, eax
004bb90b 7460                     je        0x4bb96d
004bb90d 8b16                     mov       edx, dword ptr [esi]
004bb90f 6a00                     push      0
004bb911 8bce                     mov       ecx, esi
004bb913 ff92f4000000             call      dword ptr [edx + 0xf4]
004bb919 8bc8                     mov       ecx, eax
004bb91b e8f0c75600               call      0xa28110
004bb920 83ff01                   cmp       edi, 1
004bb923 7526                     jne       0x4bb94b
004bb925 8d8ef4160000             lea       ecx, [esi + 0x16f4]
004bb92b e83067f4ff               call      0x402060
004bb930 50                       push      eax
004bb931 8b06                     mov       eax, dword ptr [esi]
004bb933 8bce                     mov       ecx, esi
004bb935 ff90f4000000             call      dword ptr [eax + 0xf4]
004bb93b 8bc8                     mov       ecx, eax
004bb93d e81eeaffff               call      0x4ba360
004bb942 c6451400                 mov       byte ptr [ebp + 0x14], 0
004bb946 e9fa0c0000               jmp       0x4bc645
004bb94b 83ff02                   cmp       edi, 2
004bb94e 751d                     jne       0x4bb96d
004bb950 8d8e04170000             lea       ecx, [esi + 0x1704]
004bb956 e80567f4ff               call      0x402060
004bb95b 8b16                     mov       edx, dword ptr [esi]
004bb95d 50                       push      eax
004bb95e 8bce                     mov       ecx, esi
004bb960 ff92f4000000             call      dword ptr [edx + 0xf4]
004bb966 8bc8                     mov       ecx, eax
004bb968 e8f3e9ffff               call      0x4ba360
004bb96d c6451400                 mov       byte ptr [ebp + 0x14], 0
004bb971 e9cf0c0000               jmp       0x4bc645
004bb976 8bce                     mov       ecx, esi
004bb978 e8830bffff               call      0x4ac500
004bb97d 85c0                     test      eax, eax
004bb97f 742c                     je        0x4bb9ad
004bb981 8b10                     mov       edx, dword ptr [eax]
004bb983 8bc8                     mov       ecx, eax
004bb985 ff92a4020000             call      dword ptr [edx + 0x2a4]
004bb98b 8bf8                     mov       edi, eax
004bb98d 85ff                     test      edi, edi
004bb98f 741c                     je        0x4bb9ad
004bb991 8b1f                     mov       ebx, dword ptr [edi]
004bb993 8d8e60180000             lea       ecx, [esi + 0x1860]
004bb999 e8c266f4ff               call      0x402060
004bb99e 85c0                     test      eax, eax
004bb9a0 0f95c0                   setne     al
004bb9a3 8bcf                     mov       ecx, edi
004bb9a5 50                       push      eax
004bb9a6 56                       push      esi
004bb9a7 ff93b0040000             call      dword ptr [ebx + 0x4b0]
004bb9ad 8b8edc120000             mov       ecx, dword ptr [esi + 0x12dc]
004bb9b3 e888250000               call      0x4bdf40
004bb9b8 83be5817000008           cmp       dword ptr [esi + 0x1758], 8
004bb9bf 7208                     jb        0x4bb9c9
004bb9c1 8b8644170000             mov       eax, dword ptr [esi + 0x1744]
004bb9c7 eb06                     jmp       0x4bb9cf
004bb9c9 8d8644170000             lea       eax, [esi + 0x1744]
004bb9cf 8b16                     mov       edx, dword ptr [esi]
004bb9d1 6a00                     push      0
004bb9d3 6a00                     push      0
004bb9d5 6aff                     push      -1
004bb9d7 50                       push      eax
004bb9d8 8bce                     mov       ecx, esi
004bb9da ff920c010000             call      dword ptr [edx + 0x10c]
004bb9e0 8b06                     mov       eax, dword ptr [esi]
004bb9e2 6a00                     push      0
004bb9e4 8bce                     mov       ecx, esi
004bb9e6 ff9010010000             call      dword ptr [eax + 0x110]
004bb9ec 8b16                     mov       edx, dword ptr [esi]
004bb9ee 6a00                     push      0
004bb9f0 8bce                     mov       ecx, esi
004bb9f2 ff92d0020000             call      dword ptr [edx + 0x2d0]
004bb9f8 8b06                     mov       eax, dword ptr [esi]
004bb9fa 6a00                     push      0
004bb9fc 8bce                     mov       ecx, esi
004bb9fe ff90d8020000             call      dword ptr [eax + 0x2d8]
004bba04 8b16                     mov       edx, dword ptr [esi]
004bba06 8bce                     mov       ecx, esi
004bba08 c6451400                 mov       byte ptr [ebp + 0x14], 0
004bba0c ff92f4000000             call      dword ptr [edx + 0xf4]
004bba12 85c0                     test      eax, eax
004bba14 7413                     je        0x4bba29
004bba16 8b06                     mov       eax, dword ptr [esi]
004bba18 6a01                     push      1
004bba1a 8bce                     mov       ecx, esi
004bba1c ff90f4000000             call      dword ptr [eax + 0xf4]
004bba22 8bc8                     mov       ecx, eax
004bba24 e8e7c65600               call      0xa28110
004bba29 8b16                     mov       edx, dword ptr [esi]
004bba2b 6a00                     push      0
004bba2d 6a00                     push      0
004bba2f 6a00                     push      0
004bba31 6a00                     push      0
004bba33 6a00                     push      0
004bba35 6a00                     push      0
004bba37 8bce                     mov       ecx, esi
004bba39 ff9288040000             call      dword ptr [edx + 0x488]
004bba3f 8b06                     mov       eax, dword ptr [esi]
004bba41 6a00                     push      0
004bba43 6a00                     push      0
004bba45 6a00                     push      0
004bba47 6a00                     push      0
004bba49 6a00                     push      0
004bba4b 6a01                     push      1
004bba4d 8bce                     mov       ecx, esi
004bba4f ff9088040000             call      dword ptr [eax + 0x488]
004bba55 8b16                     mov       edx, dword ptr [esi]
004bba57 680000803f               push      0x3f800000
004bba5c 680000803f               push      0x3f800000
004bba61 68e8030000               push      0x3e8
004bba66 68e8030000               push      0x3e8
004bba6b 6a00                     push      0
004bba6d 6a00                     push      0
004bba6f 8bce                     mov       ecx, esi
004bba71 ff9294040000             call      dword ptr [edx + 0x494]
004bba77 8b06                     mov       eax, dword ptr [esi]
004bba79 6a00                     push      0
004bba7b 6a04                     push      4
004bba7d 6a04                     push      4
004bba7f 8bce                     mov       ecx, esi
004bba81 ff909c040000             call      dword ptr [eax + 0x49c]
004bba87 8b16                     mov       edx, dword ptr [esi]
004bba89 6811020000               push      0x211
004bba8e 8bce                     mov       ecx, esi
004bba90 ff522c                   call      dword ptr [edx + 0x2c]
004bba93 84c0                     test      al, al
004bba95 0f84aa0b0000             je        0x4bc645
004bba9b 8b06                     mov       eax, dword ptr [esi]
004bba9d 8bce                     mov       ecx, esi
004bba9f ff90a0050000             call      dword ptr [eax + 0x5a0]
004bbaa5 84c0                     test      al, al
004bbaa7 0f85980b0000             jne       0x4bc645
004bbaad 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bbab3 6a00                     push      0
004bbab5 6a02                     push      2
004bbab7 e884550500               call      0x511040
004bbabc 6a00                     push      0
004bbabe 6a00                     push      0
004bbac0 8bce                     mov       ecx, esi
004bbac2 e8f9e5ffff               call      0x4ba0c0
004bbac7 e9790b0000               jmp       0x4bc645
004bbacc 83ff06                   cmp       edi, 6
004bbacf 7409                     je        0x4bbada
004bbad1 6a00                     push      0
004bbad3 8bce                     mov       ecx, esi
004bbad5 e856deffff               call      0x4b9930
004bbada 8b4304                   mov       eax, dword ptr [ebx + 4]
004bbadd 8b08                     mov       ecx, dword ptr [eax]
004bbadf 8d550c                   lea       edx, [ebp + 0xc]
004bbae2 894d0c                   mov       dword ptr [ebp + 0xc], ecx
004bbae5 8dbe88170000             lea       edi, [esi + 0x1788]
004bbaeb 52                       push      edx
004bbaec 8bcf                     mov       ecx, edi
004bbaee e86d8af4ff               call      0x404560
004bbaf3 8b4304                   mov       eax, dword ptr [ebx + 4]
004bbaf6 8b4804                   mov       ecx, dword ptr [eax + 4]
004bbaf9 85c9                     test      ecx, ecx
004bbafb 0f95c0                   setne     al
004bbafe 0fb6c8                   movzx     ecx, al
004bbb01 8d550c                   lea       edx, [ebp + 0xc]
004bbb04 894d0c                   mov       dword ptr [ebp + 0xc], ecx
004bbb07 8d8ef4170000             lea       ecx, [esi + 0x17f4]
004bbb0d 52                       push      edx
004bbb0e e84d8af4ff               call      0x404560
004bbb13 8b06                     mov       eax, dword ptr [esi]
004bbb15 8bce                     mov       ecx, esi
004bbb17 89450c                   mov       dword ptr [ebp + 0xc], eax
004bbb1a ff9080030000             call      dword ptr [eax + 0x380]
004bbb20 50                       push      eax
004bbb21 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004bbb24 8bce                     mov       ecx, esi
004bbb26 ff90f0000000             call      dword ptr [eax + 0xf0]
004bbb2c 8b06                     mov       eax, dword ptr [esi]
004bbb2e 8bce                     mov       ecx, esi
004bbb30 89450c                   mov       dword ptr [ebp + 0xc], eax
004bbb33 ff90a8030000             call      dword ptr [eax + 0x3a8]
004bbb39 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004bbb3c 50                       push      eax
004bbb3d 8bce                     mov       ecx, esi
004bbb3f ff9200010000             call      dword ptr [edx + 0x100]
004bbb45 8bcf                     mov       ecx, edi
004bbb47 e81465f4ff               call      0x402060
004bbb4c 85c0                     test      eax, eax
004bbb4e 0f85dc000000             jne       0x4bbc30
004bbb54 8d450c                   lea       eax, [ebp + 0xc]
004bbb57 50                       push      eax
004bbb58 8d8e68170000             lea       ecx, [esi + 0x1768]
004bbb5e c7450c8f000000           mov       dword ptr [ebp + 0xc], 0x8f
004bbb65 e8f689f4ff               call      0x404560
004bbb6a 8d4d0c                   lea       ecx, [ebp + 0xc]
004bbb6d 51                       push      ecx
004bbb6e 8d8e70170000             lea       ecx, [esi + 0x1770]
004bbb74 c7450c77000000           mov       dword ptr [ebp + 0xc], 0x77
004bbb7b e8e089f4ff               call      0x404560
004bbb80 8d550c                   lea       edx, [ebp + 0xc]
004bbb83 52                       push      edx
004bbb84 8d8e78170000             lea       ecx, [esi + 0x1778]
004bbb8a c7450c72000000           mov       dword ptr [ebp + 0xc], 0x72
004bbb91 e8ca89f4ff               call      0x404560
004bbb96 8d450c                   lea       eax, [ebp + 0xc]
004bbb99 50                       push      eax
004bbb9a 8d8e80170000             lea       ecx, [esi + 0x1780]
004bbba0 c7450c5f000000           mov       dword ptr [ebp + 0xc], 0x5f
004bbba7 e8b489f4ff               call      0x404560
004bbbac 8b16                     mov       edx, dword ptr [esi]
004bbbae 6a00                     push      0
004bbbb0 6a00                     push      0
004bbbb2 6a00                     push      0
004bbbb4 6a00                     push      0
004bbbb6 6a00                     push      0
004bbbb8 6a00                     push      0
004bbbba 8bce                     mov       ecx, esi
004bbbbc ff9288040000             call      dword ptr [edx + 0x488]
004bbbc2 8b06                     mov       eax, dword ptr [esi]
004bbbc4 6a00                     push      0
004bbbc6 6a00                     push      0
004bbbc8 6a00                     push      0
004bbbca 6a00                     push      0
004bbbcc 6a00                     push      0
004bbbce 6a01                     push      1
004bbbd0 8bce                     mov       ecx, esi
004bbbd2 ff9088040000             call      dword ptr [eax + 0x488]
004bbbd8 8b16                     mov       edx, dword ptr [esi]
004bbbda 680000803f               push      0x3f800000
004bbbdf 680000803f               push      0x3f800000
004bbbe4 68e8030000               push      0x3e8
004bbbe9 68e8030000               push      0x3e8
004bbbee 6a00                     push      0
004bbbf0 6a01                     push      1
004bbbf2 8bce                     mov       ecx, esi
004bbbf4 ff9294040000             call      dword ptr [edx + 0x494]
004bbbfa 8b06                     mov       eax, dword ptr [esi]
004bbbfc 6a00                     push      0
004bbbfe 6a04                     push      4
004bbc00 6a04                     push      4
004bbc02 8bce                     mov       ecx, esi
004bbc04 ff909c040000             call      dword ptr [eax + 0x49c]
004bbc0a 6a00                     push      0
004bbc0c 6a02                     push      2
004bbc0e 8bce                     mov       ecx, esi
004bbc10 e8abe4ffff               call      0x4ba0c0
004bbc15 8d4d0c                   lea       ecx, [ebp + 0xc]
004bbc18 51                       push      ecx
004bbc19 8d8e04180000             lea       ecx, [esi + 0x1804]
004bbc1f c7450c00000000           mov       dword ptr [ebp + 0xc], 0
004bbc26 e83589f4ff               call      0x404560
004bbc2b e9150a0000               jmp       0x4bc645
004bbc30 8bcf                     mov       ecx, edi
004bbc32 e82964f4ff               call      0x402060
004bbc37 83f801                   cmp       eax, 1
004bbc3a 0f854b040000             jne       0x4bc08b
004bbc40 8b5b04                   mov       ebx, dword ptr [ebx + 4]
004bbc43 8b7b08                   mov       edi, dword ptr [ebx + 8]
004bbc46 83c308                   add       ebx, 8
004bbc49 8d8ef4170000             lea       ecx, [esi + 0x17f4]
004bbc4f e80c64f4ff               call      0x402060
004bbc54 85c0                     test      eax, eax
004bbc56 6a00                     push      0
004bbc58 6a00                     push      0
004bbc5a 0f848e010000             je        0x4bbdee
004bbc60 8b16                     mov       edx, dword ptr [esi]
004bbc62 6aff                     push      -1
004bbc64 689414cd00               push      0xcd1494
004bbc69 8bce                     mov       ecx, esi
004bbc6b ff920c010000             call      dword ptr [edx + 0x10c]
004bbc71 8b06                     mov       eax, dword ptr [esi]
004bbc73 8bce                     mov       ecx, esi
004bbc75 ff90ec040000             call      dword ptr [eax + 0x4ec]
004bbc7b 8b16                     mov       edx, dword ptr [esi]
004bbc7d 6a64                     push      0x64
004bbc7f 6a03                     push      3
004bbc81 8bce                     mov       ecx, esi
004bbc83 ff9244030000             call      dword ptr [edx + 0x344]
004bbc89 8bc8                     mov       ecx, eax
004bbc8b e830210000               call      0x4bddc0
004bbc90 50                       push      eax
004bbc91 57                       push      edi
004bbc92 e859dcffff               call      0x4b98f0
004bbc97 d95d14                   fstp      dword ptr [ebp + 0x14]
004bbc9a 8b4514                   mov       eax, dword ptr [ebp + 0x14]
004bbc9d 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bbca3 83c40c                   add       esp, 0xc
004bbca6 50                       push      eax
004bbca7 6a02                     push      2
004bbca9 e892530500               call      0x511040
004bbcae 8b16                     mov       edx, dword ptr [esi]
004bbcb0 6a00                     push      0
004bbcb2 6a00                     push      0
004bbcb4 6a00                     push      0
004bbcb6 681e010000               push      0x11e
004bbcbb 681e010000               push      0x11e
004bbcc0 6a00                     push      0
004bbcc2 8bce                     mov       ecx, esi
004bbcc4 ff9288040000             call      dword ptr [edx + 0x488]
004bbcca 8b06                     mov       eax, dword ptr [esi]
004bbccc 6a00                     push      0
004bbcce 6a00                     push      0
004bbcd0 6a00                     push      0
004bbcd2 6a00                     push      0
004bbcd4 6a00                     push      0
004bbcd6 6a01                     push      1
004bbcd8 8bce                     mov       ecx, esi
004bbcda ff9088040000             call      dword ptr [eax + 0x488]
004bbce0 8b16                     mov       edx, dword ptr [esi]
004bbce2 680000803f               push      0x3f800000
004bbce7 680000803f               push      0x3f800000
004bbcec 68e8030000               push      0x3e8
004bbcf1 68e8030000               push      0x3e8
004bbcf6 6a00                     push      0
004bbcf8 6a01                     push      1
004bbcfa 8bce                     mov       ecx, esi
004bbcfc ff9294040000             call      dword ptr [edx + 0x494]
004bbd02 8b1e                     mov       ebx, dword ptr [esi]
004bbd04 6a00                     push      0
004bbd06 6a04                     push      4
004bbd08 8bce                     mov       ecx, esi
004bbd0a ff93c0000000             call      dword ptr [ebx + 0xc0]
004bbd10 50                       push      eax
004bbd11 e84abcf8ff               call      0x447960
004bbd16 83c404                   add       esp, 4
004bbd19 50                       push      eax
004bbd1a 8bce                     mov       ecx, esi
004bbd1c ff939c040000             call      dword ptr [ebx + 0x49c]
004bbd22 8b1e                     mov       ebx, dword ptr [esi]
004bbd24 8bce                     mov       ecx, esi
004bbd26 ff9380030000             call      dword ptr [ebx + 0x380]
004bbd2c 50                       push      eax
004bbd2d 8bce                     mov       ecx, esi
004bbd2f ff93f0000000             call      dword ptr [ebx + 0xf0]
004bbd35 8b1e                     mov       ebx, dword ptr [esi]
004bbd37 8bce                     mov       ecx, esi
004bbd39 ff93a8030000             call      dword ptr [ebx + 0x3a8]
004bbd3f 50                       push      eax
004bbd40 8bce                     mov       ecx, esi
004bbd42 ff9300010000             call      dword ptr [ebx + 0x100]
004bbd48 8b06                     mov       eax, dword ptr [esi]
004bbd4a 8bce                     mov       ecx, esi
004bbd4c ff9004010000             call      dword ptr [eax + 0x104]
004bbd52 85c0                     test      eax, eax
004bbd54 7415                     je        0x4bbd6b
004bbd56 8b16                     mov       edx, dword ptr [esi]
004bbd58 6a01                     push      1
004bbd5a 8bce                     mov       ecx, esi
004bbd5c ff9204010000             call      dword ptr [edx + 0x104]
004bbd62 8bc8                     mov       ecx, eax
004bbd64 e8c7185700               call      0xa2d630
004bbd69 eb11                     jmp       0x4bbd7c
004bbd6b 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bbd71 85c9                     test      ecx, ecx
004bbd73 7407                     je        0x4bbd7c
004bbd75 6a01                     push      1
004bbd77 e894c35600               call      0xa28110
004bbd7c 8b06                     mov       eax, dword ptr [esi]
004bbd7e 8bce                     mov       ecx, esi
004bbd80 ff90c0040000             call      dword ptr [eax + 0x4c0]
004bbd86 8b16                     mov       edx, dword ptr [esi]
004bbd88 8bd8                     mov       ebx, eax
004bbd8a 8bce                     mov       ecx, esi
004bbd8c 4b                       dec       ebx
004bbd8d ff92bc040000             call      dword ptr [edx + 0x4bc]
004bbd93 3bc3                     cmp       eax, ebx
004bbd95 8bce                     mov       ecx, esi
004bbd97 7e0c                     jle       0x4bbda5
004bbd99 8b06                     mov       eax, dword ptr [esi]
004bbd9b ff90bc040000             call      dword ptr [eax + 0x4bc]
004bbda1 8bd8                     mov       ebx, eax
004bbda3 eb0b                     jmp       0x4bbdb0
004bbda5 8b16                     mov       edx, dword ptr [esi]
004bbda7 ff92c0040000             call      dword ptr [edx + 0x4c0]
004bbdad 8bd8                     mov       ebx, eax
004bbdaf 4b                       dec       ebx
004bbdb0 8b06                     mov       eax, dword ptr [esi]
004bbdb2 8bce                     mov       ecx, esi
004bbdb4 ff9004010000             call      dword ptr [eax + 0x104]
004bbdba 85c0                     test      eax, eax
004bbdbc 7417                     je        0x4bbdd5
004bbdbe 8b16                     mov       edx, dword ptr [esi]
004bbdc0 53                       push      ebx
004bbdc1 8bce                     mov       ecx, esi
004bbdc3 ff9204010000             call      dword ptr [edx + 0x104]
004bbdc9 8bc8                     mov       ecx, eax
004bbdcb e8e0475700               call      0xa305b0
004bbdd0 e93b020000               jmp       0x4bc010
004bbdd5 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bbddb 85c9                     test      ecx, ecx
004bbddd 0f842d020000             je        0x4bc010
004bbde3 53                       push      ebx
004bbde4 e877e5ffff               call      0x4ba360
004bbde9 e922020000               jmp       0x4bc010
004bbdee 8b1e                     mov       ebx, dword ptr [esi]
004bbdf0 6a01                     push      1
004bbdf2 8d8e70170000             lea       ecx, [esi + 0x1770]
004bbdf8 e86362f4ff               call      0x402060
004bbdfd 50                       push      eax
004bbdfe 8d8e68170000             lea       ecx, [esi + 0x1768]
004bbe04 e85762f4ff               call      0x402060
004bbe09 50                       push      eax
004bbe0a 6a00                     push      0
004bbe0c 8bce                     mov       ecx, esi
004bbe0e ff9388040000             call      dword ptr [ebx + 0x488]
004bbe14 8b1e                     mov       ebx, dword ptr [esi]
004bbe16 6a00                     push      0
004bbe18 6a00                     push      0
004bbe1a 6a01                     push      1
004bbe1c 8d8e80170000             lea       ecx, [esi + 0x1780]
004bbe22 e83962f4ff               call      0x402060
004bbe27 99                       cdq       
004bbe28 2bc2                     sub       eax, edx
004bbe2a d1f8                     sar       eax, 1
004bbe2c 50                       push      eax
004bbe2d 8d8e78170000             lea       ecx, [esi + 0x1778]
004bbe33 e82862f4ff               call      0x402060
004bbe38 99                       cdq       
004bbe39 2bc2                     sub       eax, edx
004bbe3b d1f8                     sar       eax, 1
004bbe3d 50                       push      eax
004bbe3e 6a01                     push      1
004bbe40 8bce                     mov       ecx, esi
004bbe42 ff9388040000             call      dword ptr [ebx + 0x488]
004bbe48 8b06                     mov       eax, dword ptr [esi]
004bbe4a 680000803f               push      0x3f800000
004bbe4f 680000803f               push      0x3f800000
004bbe54 68e8030000               push      0x3e8
004bbe59 68e8030000               push      0x3e8
004bbe5e 6a00                     push      0
004bbe60 6a01                     push      1
004bbe62 8bce                     mov       ecx, esi
004bbe64 ff9094040000             call      dword ptr [eax + 0x494]
004bbe6a 85ff                     test      edi, edi
004bbe6c 8bce                     mov       ecx, esi
004bbe6e 0f84cf000000             je        0x4bbf43
004bbe74 8b16                     mov       edx, dword ptr [esi]
004bbe76 6a00                     push      0
004bbe78 6a00                     push      0
004bbe7a 6aff                     push      -1
004bbe7c 689414cd00               push      0xcd1494
004bbe81 ff920c010000             call      dword ptr [edx + 0x10c]
004bbe87 8b06                     mov       eax, dword ptr [esi]
004bbe89 8bce                     mov       ecx, esi
004bbe8b ff90e4040000             call      dword ptr [eax + 0x4e4]
004bbe91 8b16                     mov       edx, dword ptr [esi]
004bbe93 6a03                     push      3
004bbe95 8bce                     mov       ecx, esi
004bbe97 ff9244030000             call      dword ptr [edx + 0x344]
004bbe9d 8bc8                     mov       ecx, eax
004bbe9f e82ce4ffff               call      0x4ba2d0
004bbea4 50                       push      eax
004bbea5 8b06                     mov       eax, dword ptr [esi]
004bbea7 6a03                     push      3
004bbea9 8bce                     mov       ecx, esi
004bbeab ff9044030000             call      dword ptr [eax + 0x344]
004bbeb1 8bc8                     mov       ecx, eax
004bbeb3 e8081f0000               call      0x4bddc0
004bbeb8 50                       push      eax
004bbeb9 57                       push      edi
004bbeba e831daffff               call      0x4b98f0
004bbebf d95d14                   fstp      dword ptr [ebp + 0x14]
004bbec2 8b4d14                   mov       ecx, dword ptr [ebp + 0x14]
004bbec5 83c40c                   add       esp, 0xc
004bbec8 51                       push      ecx
004bbec9 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bbecf 6a02                     push      2
004bbed1 e86a510500               call      0x511040
004bbed6 8b16                     mov       edx, dword ptr [esi]
004bbed8 8bce                     mov       ecx, esi
004bbeda ff9204010000             call      dword ptr [edx + 0x104]
004bbee0 85c0                     test      eax, eax
004bbee2 7434                     je        0x4bbf18
004bbee4 8b06                     mov       eax, dword ptr [esi]
004bbee6 6a00                     push      0
004bbee8 8bce                     mov       ecx, esi
004bbeea ff9004010000             call      dword ptr [eax + 0x104]
004bbef0 8bc8                     mov       ecx, eax
004bbef2 e839175700               call      0xa2d630
004bbef7 8b16                     mov       edx, dword ptr [esi]
004bbef9 8bce                     mov       ecx, esi
004bbefb ff92b8040000             call      dword ptr [edx + 0x4b8]
004bbf01 50                       push      eax
004bbf02 8b06                     mov       eax, dword ptr [esi]
004bbf04 8bce                     mov       ecx, esi
004bbf06 ff9004010000             call      dword ptr [eax + 0x104]
004bbf0c 8bc8                     mov       ecx, eax
004bbf0e e89d465700               call      0xa305b0
004bbf13 e9f4000000               jmp       0x4bc00c
004bbf18 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bbf1e 85c9                     test      ecx, ecx
004bbf20 0f84e6000000             je        0x4bc00c
004bbf26 6a00                     push      0
004bbf28 e8e3c15600               call      0xa28110
004bbf2d 8b16                     mov       edx, dword ptr [esi]
004bbf2f 8bce                     mov       ecx, esi
004bbf31 ff92b8040000             call      dword ptr [edx + 0x4b8]
004bbf37 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bbf3d 50                       push      eax
004bbf3e e9c4000000               jmp       0x4bc007
004bbf43 8b06                     mov       eax, dword ptr [esi]
004bbf45 ff90f4000000             call      dword ptr [eax + 0xf4]
004bbf4b 85c0                     test      eax, eax
004bbf4d 7413                     je        0x4bbf62
004bbf4f 8b16                     mov       edx, dword ptr [esi]
004bbf51 6a00                     push      0
004bbf53 8bce                     mov       ecx, esi
004bbf55 ff92f4000000             call      dword ptr [edx + 0xf4]
004bbf5b 8bc8                     mov       ecx, eax
004bbf5d e8aec15600               call      0xa28110
004bbf62 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bbf68 8b08                     mov       ecx, dword ptr [eax]
004bbf6a 85c9                     test      ecx, ecx
004bbf6c 7503                     jne       0x4bbf71
004bbf6e 8d4808                   lea       ecx, [eax + 8]
004bbf71 8b01                     mov       eax, dword ptr [ecx]
004bbf73 6a02                     push      2
004bbf75 ff5008                   call      dword ptr [eax + 8]
004bbf78 8b16                     mov       edx, dword ptr [esi]
004bbf7a dc1d60b2cc00             fcomp     qword ptr [0xccb260]
004bbf80 8bce                     mov       ecx, esi
004bbf82 dfe0                     fnstsw    ax
004bbf84 f6c441                   test      ah, 0x41
004bbf87 752f                     jne       0x4bbfb8
004bbf89 ff92bc040000             call      dword ptr [edx + 0x4bc]
004bbf8f 8bd8                     mov       ebx, eax
004bbf91 8b06                     mov       eax, dword ptr [esi]
004bbf93 8bce                     mov       ecx, esi
004bbf95 4b                       dec       ebx
004bbf96 ff90b8040000             call      dword ptr [eax + 0x4b8]
004bbf9c 3bc3                     cmp       eax, ebx
004bbf9e 8bce                     mov       ecx, esi
004bbfa0 7e0c                     jle       0x4bbfae
004bbfa2 8b16                     mov       edx, dword ptr [esi]
004bbfa4 ff92b8040000             call      dword ptr [edx + 0x4b8]
004bbfaa 8bd8                     mov       ebx, eax
004bbfac eb3a                     jmp       0x4bbfe8
004bbfae 8b06                     mov       eax, dword ptr [esi]
004bbfb0 ff90bc040000             call      dword ptr [eax + 0x4bc]
004bbfb6 eb2d                     jmp       0x4bbfe5
004bbfb8 ff92c0040000             call      dword ptr [edx + 0x4c0]
004bbfbe 8bd8                     mov       ebx, eax
004bbfc0 8b06                     mov       eax, dword ptr [esi]
004bbfc2 8bce                     mov       ecx, esi
004bbfc4 4b                       dec       ebx
004bbfc5 ff90bc040000             call      dword ptr [eax + 0x4bc]
004bbfcb 3bc3                     cmp       eax, ebx
004bbfcd 8bce                     mov       ecx, esi
004bbfcf 7e0c                     jle       0x4bbfdd
004bbfd1 8b16                     mov       edx, dword ptr [esi]
004bbfd3 ff92bc040000             call      dword ptr [edx + 0x4bc]
004bbfd9 8bd8                     mov       ebx, eax
004bbfdb eb0b                     jmp       0x4bbfe8
004bbfdd 8b06                     mov       eax, dword ptr [esi]
004bbfdf ff90c0040000             call      dword ptr [eax + 0x4c0]
004bbfe5 8bd8                     mov       ebx, eax
004bbfe7 4b                       dec       ebx
004bbfe8 8b16                     mov       edx, dword ptr [esi]
004bbfea 8bce                     mov       ecx, esi
004bbfec ff9204010000             call      dword ptr [edx + 0x104]
004bbff2 85c0                     test      eax, eax
004bbff4 7406                     je        0x4bbffc
004bbff6 53                       push      ebx
004bbff7 e906ffffff               jmp       0x4bbf02
004bbffc 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bc002 85c9                     test      ecx, ecx
004bc004 7406                     je        0x4bc00c
004bc006 53                       push      ebx
004bc007 e854e3ffff               call      0x4ba360
004bc00c c6451000                 mov       byte ptr [ebp + 0x10], 0
004bc010 8d8ef4170000             lea       ecx, [esi + 0x17f4]
004bc016 c6451400                 mov       byte ptr [ebp + 0x14], 0
004bc01a e84160f4ff               call      0x402060
004bc01f 85c0                     test      eax, eax
004bc021 8bce                     mov       ecx, esi
004bc023 6a00                     push      0
004bc025 7404                     je        0x4bc02b
004bc027 6a01                     push      1
004bc029 eb02                     jmp       0x4bc02d
004bc02b 6a02                     push      2
004bc02d e88ee0ffff               call      0x4ba0c0
004bc032 85ff                     test      edi, edi
004bc034 7f24                     jg        0x4bc05a
004bc036 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
004bc039 85ff                     test      edi, edi
004bc03b 741d                     je        0x4bc05a
004bc03d 8b16                     mov       edx, dword ptr [esi]
004bc03f 6811010000               push      0x111
004bc044 8bce                     mov       ecx, esi
004bc046 ff522c                   call      dword ptr [edx + 0x2c]
004bc049 84c0                     test      al, al
004bc04b 0f84f4050000             je        0x4bc645
004bc051 83ff0b                   cmp       edi, 0xb
004bc054 0f85eb050000             jne       0x4bc645
004bc05a 8d450c                   lea       eax, [ebp + 0xc]
004bc05d 50                       push      eax
004bc05e 8d8e90170000             lea       ecx, [esi + 0x1790]
004bc064 c7450c00000000           mov       dword ptr [ebp + 0xc], 0
004bc06b e8f084f4ff               call      0x404560
004bc070 8d4d0c                   lea       ecx, [ebp + 0xc]
004bc073 51                       push      ecx
004bc074 8d8e98170000             lea       ecx, [esi + 0x1798]
004bc07a c7450c01000000           mov       dword ptr [ebp + 0xc], 1
004bc081 e8da84f4ff               call      0x404560
004bc086 e9ba050000               jmp       0x4bc645
004bc08b 8bcf                     mov       ecx, edi
004bc08d e8ce5ff4ff               call      0x402060
004bc092 83f802                   cmp       eax, 2
004bc095 0f85aa050000             jne       0x4bc645
004bc09b 8b16                     mov       edx, dword ptr [esi]
004bc09d 6a00                     push      0
004bc09f 6a00                     push      0
004bc0a1 6aff                     push      -1
004bc0a3 688014cd00               push      0xcd1480
004bc0a8 8bce                     mov       ecx, esi
004bc0aa ff920c010000             call      dword ptr [edx + 0x10c]
004bc0b0 8b06                     mov       eax, dword ptr [esi]
004bc0b2 8bce                     mov       ecx, esi
004bc0b4 ff90e8040000             call      dword ptr [eax + 0x4e8]
004bc0ba 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004bc0c0 85c0                     test      eax, eax
004bc0c2 0f8497000000             je        0x4bc15f
004bc0c8 8b16                     mov       edx, dword ptr [esi]
004bc0ca 6a01                     push      1
004bc0cc 8bce                     mov       ecx, esi
004bc0ce ff92d0040000             call      dword ptr [edx + 0x4d0]
004bc0d4 8b3c85782e0001           mov       edi, dword ptr [eax*4 + 0x1002e78]
004bc0db 8b06                     mov       eax, dword ptr [esi]
004bc0dd 8bce                     mov       ecx, esi
004bc0df ff90c0000000             call      dword ptr [eax + 0xc0]
004bc0e5 8b17                     mov       edx, dword ptr [edi]
004bc0e7 8bd8                     mov       ebx, eax
004bc0e9 f7db                     neg       ebx
004bc0eb 1adb                     sbb       bl, bl
004bc0ed 8bcf                     mov       ecx, edi
004bc0ef fec3                     inc       bl
004bc0f1 ff521c                   call      dword ptr [edx + 0x1c]
004bc0f4 885858                   mov       byte ptr [eax + 0x58], bl
004bc0f7 8b06                     mov       eax, dword ptr [esi]
004bc0f9 8b1f                     mov       ebx, dword ptr [edi]
004bc0fb 8bce                     mov       ecx, esi
004bc0fd ff909c000000             call      dword ptr [eax + 0x9c]
004bc103 8b16                     mov       edx, dword ptr [esi]
004bc105 50                       push      eax
004bc106 8bce                     mov       ecx, esi
004bc108 ff9298000000             call      dword ptr [edx + 0x98]
004bc10e 50                       push      eax
004bc10f 8b06                     mov       eax, dword ptr [esi]
004bc111 8bce                     mov       ecx, esi
004bc113 ff9094000000             call      dword ptr [eax + 0x94]
004bc119 50                       push      eax
004bc11a 8bcf                     mov       ecx, edi
004bc11c ff5328                   call      dword ptr [ebx + 0x28]
004bc11f 8b17                     mov       edx, dword ptr [edi]
004bc121 6a00                     push      0
004bc123 8bcf                     mov       ecx, edi
004bc125 ff520c                   call      dword ptr [edx + 0xc]
004bc128 8b07                     mov       eax, dword ptr [edi]
004bc12a 8d4dbc                   lea       ecx, [ebp - 0x44]
004bc12d 51                       push      ecx
004bc12e 8bcf                     mov       ecx, edi
004bc130 ff505c                   call      dword ptr [eax + 0x5c]
004bc133 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004bc139 6a00                     push      0
004bc13b 8d55bc                   lea       edx, [ebp - 0x44]
004bc13e 52                       push      edx
004bc13f 6a00                     push      0
004bc141 6a02                     push      2
004bc143 56                       push      esi
004bc144 c745fc01000000           mov       dword ptr [ebp - 4], 1
004bc14b e8101f0500               call      0x50e060
004bc150 8d4dbc                   lea       ecx, [ebp - 0x44]
004bc153 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004bc15a e8f18b1800               call      0x644d50
004bc15f 8b06                     mov       eax, dword ptr [esi]
004bc161 6a00                     push      0
004bc163 6a00                     push      0
004bc165 6a00                     push      0
004bc167 6a00                     push      0
004bc169 6a00                     push      0
004bc16b 6a00                     push      0
004bc16d 8bce                     mov       ecx, esi
004bc16f ff9088040000             call      dword ptr [eax + 0x488]
004bc175 8b16                     mov       edx, dword ptr [esi]
004bc177 6a00                     push      0
004bc179 6a00                     push      0
004bc17b 6a00                     push      0
004bc17d 6a00                     push      0
004bc17f 6a00                     push      0
004bc181 6a01                     push      1
004bc183 8bce                     mov       ecx, esi
004bc185 ff9288040000             call      dword ptr [edx + 0x488]
004bc18b 8b06                     mov       eax, dword ptr [esi]
004bc18d 680000803f               push      0x3f800000
004bc192 680000803f               push      0x3f800000
004bc197 68e8030000               push      0x3e8
004bc19c 68e8030000               push      0x3e8
004bc1a1 6a00                     push      0
004bc1a3 6a00                     push      0
004bc1a5 8bce                     mov       ecx, esi
004bc1a7 ff9094040000             call      dword ptr [eax + 0x494]
004bc1ad 8b16                     mov       edx, dword ptr [esi]
004bc1af 6a00                     push      0
004bc1b1 6a04                     push      4
004bc1b3 6a04                     push      4
004bc1b5 8bce                     mov       ecx, esi
004bc1b7 ff929c040000             call      dword ptr [edx + 0x49c]
004bc1bd 6a00                     push      0
004bc1bf 6a02                     push      2
004bc1c1 8bce                     mov       ecx, esi
004bc1c3 e8f8deffff               call      0x4ba0c0
004bc1c8 8b06                     mov       eax, dword ptr [esi]
004bc1ca 8bce                     mov       ecx, esi
004bc1cc ff9004010000             call      dword ptr [eax + 0x104]
004bc1d2 85c0                     test      eax, eax
004bc1d4 7434                     je        0x4bc20a
004bc1d6 8b16                     mov       edx, dword ptr [esi]
004bc1d8 6a00                     push      0
004bc1da 8bce                     mov       ecx, esi
004bc1dc ff9204010000             call      dword ptr [edx + 0x104]
004bc1e2 8bc8                     mov       ecx, eax
004bc1e4 e847145700               call      0xa2d630
004bc1e9 8b06                     mov       eax, dword ptr [esi]
004bc1eb 8bce                     mov       ecx, esi
004bc1ed ff90c0040000             call      dword ptr [eax + 0x4c0]
004bc1f3 8b16                     mov       edx, dword ptr [esi]
004bc1f5 50                       push      eax
004bc1f6 8bce                     mov       ecx, esi
004bc1f8 ff9204010000             call      dword ptr [edx + 0x104]
004bc1fe 8bc8                     mov       ecx, eax
004bc200 e8ab435700               call      0xa305b0
004bc205 e97b040000               jmp       0x4bc685
004bc20a 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bc210 85c9                     test      ecx, ecx
004bc212 0f846d040000             je        0x4bc685
004bc218 6a00                     push      0
004bc21a e8f1be5600               call      0xa28110
004bc21f 8b06                     mov       eax, dword ptr [esi]
004bc221 8bce                     mov       ecx, esi
004bc223 ff90c0040000             call      dword ptr [eax + 0x4c0]
004bc229 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bc22f 50                       push      eax
004bc230 e82be1ffff               call      0x4ba360
004bc235 e94b040000               jmp       0x4bc685
004bc23a 8b16                     mov       edx, dword ptr [esi]
004bc23c 8bce                     mov       ecx, esi
004bc23e ff92e0040000             call      dword ptr [edx + 0x4e0]
004bc244 8b1e                     mov       ebx, dword ptr [esi]
004bc246 8bce                     mov       ecx, esi
004bc248 ff9384030000             call      dword ptr [ebx + 0x384]
004bc24e 50                       push      eax
004bc24f 8bce                     mov       ecx, esi
004bc251 ff93f0000000             call      dword ptr [ebx + 0xf0]
004bc257 8b1e                     mov       ebx, dword ptr [esi]
004bc259 8bce                     mov       ecx, esi
004bc25b ff93ac030000             call      dword ptr [ebx + 0x3ac]
004bc261 50                       push      eax
004bc262 8bce                     mov       ecx, esi
004bc264 ff9300010000             call      dword ptr [ebx + 0x100]
004bc26a 8b1e                     mov       ebx, dword ptr [esi]
004bc26c 8bce                     mov       ecx, esi
004bc26e ff9364040000             call      dword ptr [ebx + 0x464]
004bc274 50                       push      eax
004bc275 8bce                     mov       ecx, esi
004bc277 ff9398010000             call      dword ptr [ebx + 0x198]
004bc27d 8b06                     mov       eax, dword ptr [esi]
004bc27f 680000803f               push      0x3f800000
004bc284 680000803f               push      0x3f800000
004bc289 68e8030000               push      0x3e8
004bc28e 68e8030000               push      0x3e8
004bc293 6a03                     push      3
004bc295 6a01                     push      1
004bc297 8bce                     mov       ecx, esi
004bc299 ff9094040000             call      dword ptr [eax + 0x494]
004bc29f 6a00                     push      0
004bc2a1 8d8e90170000             lea       ecx, [esi + 0x1790]
004bc2a7 e89432f8ff               call      0x43f540
004bc2ac e9b3030000               jmp       0x4bc664
004bc2b1 83be4818000008           cmp       dword ptr [esi + 0x1848], 8
004bc2b8 7208                     jb        0x4bc2c2
004bc2ba 8b8634180000             mov       eax, dword ptr [esi + 0x1834]
004bc2c0 eb06                     jmp       0x4bc2c8
004bc2c2 8d8634180000             lea       eax, [esi + 0x1834]
004bc2c8 8b16                     mov       edx, dword ptr [esi]
004bc2ca 6a00                     push      0
004bc2cc 6a00                     push      0
004bc2ce 6aff                     push      -1
004bc2d0 50                       push      eax
004bc2d1 8bce                     mov       ecx, esi
004bc2d3 ff920c010000             call      dword ptr [edx + 0x10c]
004bc2d9 8b5b04                   mov       ebx, dword ptr [ebx + 4]
004bc2dc 8b03                     mov       eax, dword ptr [ebx]
004bc2de 8d4d0c                   lea       ecx, [ebp + 0xc]
004bc2e1 8d9e28180000             lea       ebx, [esi + 0x1828]
004bc2e7 51                       push      ecx
004bc2e8 8bcb                     mov       ecx, ebx
004bc2ea 89450c                   mov       dword ptr [ebp + 0xc], eax
004bc2ed e86e82f4ff               call      0x404560
004bc2f2 8b3e                     mov       edi, dword ptr [esi]
004bc2f4 8bcb                     mov       ecx, ebx
004bc2f6 e8655df4ff               call      0x402060
004bc2fb 50                       push      eax
004bc2fc 8bce                     mov       ecx, esi
004bc2fe ff9760040000             call      dword ptr [edi + 0x460]
004bc304 85c0                     test      eax, eax
004bc306 740b                     je        0x4bc313
004bc308 8b16                     mov       edx, dword ptr [esi]
004bc30a 50                       push      eax
004bc30b 8bce                     mov       ecx, esi
004bc30d ff9298010000             call      dword ptr [edx + 0x198]
004bc313 8b06                     mov       eax, dword ptr [esi]
004bc315 6a00                     push      0
004bc317 6a00                     push      0
004bc319 6a00                     push      0
004bc31b 6a00                     push      0
004bc31d 6a00                     push      0
004bc31f 6a00                     push      0
004bc321 8bce                     mov       ecx, esi
004bc323 ff9088040000             call      dword ptr [eax + 0x488]
004bc329 8b16                     mov       edx, dword ptr [esi]
004bc32b 6a00                     push      0
004bc32d 6a00                     push      0
004bc32f 6a00                     push      0
004bc331 6a00                     push      0
004bc333 6a00                     push      0
004bc335 6a01                     push      1
004bc337 8bce                     mov       ecx, esi
004bc339 ff9288040000             call      dword ptr [edx + 0x488]
004bc33f 8b06                     mov       eax, dword ptr [esi]
004bc341 680000803f               push      0x3f800000
004bc346 680000803f               push      0x3f800000
004bc34b 68e8030000               push      0x3e8
004bc350 68e8030000               push      0x3e8
004bc355 6a02                     push      2
004bc357 6a02                     push      2
004bc359 8bce                     mov       ecx, esi
004bc35b ff9094040000             call      dword ptr [eax + 0x494]
004bc361 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bc367 6a00                     push      0
004bc369 6a02                     push      2
004bc36b e8d04c0500               call      0x511040
004bc370 8b16                     mov       edx, dword ptr [esi]
004bc372 6a00                     push      0
004bc374 6a04                     push      4
004bc376 6a04                     push      4
004bc378 8bce                     mov       ecx, esi
004bc37a ff929c040000             call      dword ptr [edx + 0x49c]
004bc380 6a00                     push      0
004bc382 6a02                     push      2
004bc384 8bce                     mov       ecx, esi
004bc386 e835ddffff               call      0x4ba0c0
004bc38b 8b3e                     mov       edi, dword ptr [esi]
004bc38d 8bcb                     mov       ecx, ebx
004bc38f e8cc5cf4ff               call      0x402060
004bc394 50                       push      eax
004bc395 8bce                     mov       ecx, esi
004bc397 ff97b0030000             call      dword ptr [edi + 0x3b0]
004bc39d 8bf8                     mov       edi, eax
004bc39f 8b06                     mov       eax, dword ptr [esi]
004bc3a1 8bcb                     mov       ecx, ebx
004bc3a3 89450c                   mov       dword ptr [ebp + 0xc], eax
004bc3a6 e8b55cf4ff               call      0x402060
004bc3ab 50                       push      eax
004bc3ac 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004bc3af 8bce                     mov       ecx, esi
004bc3b1 ff9088030000             call      dword ptr [eax + 0x388]
004bc3b7 85ff                     test      edi, edi
004bc3b9 8bd8                     mov       ebx, eax
004bc3bb 741c                     je        0x4bc3d9
004bc3bd 8b06                     mov       eax, dword ptr [esi]
004bc3bf 6a00                     push      0
004bc3c1 8bce                     mov       ecx, esi
004bc3c3 ff90f0000000             call      dword ptr [eax + 0xf0]
004bc3c9 8b16                     mov       edx, dword ptr [esi]
004bc3cb 57                       push      edi
004bc3cc 8bce                     mov       ecx, esi
004bc3ce ff9200010000             call      dword ptr [edx + 0x100]
004bc3d4 e96c020000               jmp       0x4bc645
004bc3d9 85db                     test      ebx, ebx
004bc3db 0f8464020000             je        0x4bc645
004bc3e1 8b06                     mov       eax, dword ptr [esi]
004bc3e3 6a00                     push      0
004bc3e5 8bce                     mov       ecx, esi
004bc3e7 ff9000010000             call      dword ptr [eax + 0x100]
004bc3ed 8b16                     mov       edx, dword ptr [esi]
004bc3ef 53                       push      ebx
004bc3f0 8bce                     mov       ecx, esi
004bc3f2 ff92f0000000             call      dword ptr [edx + 0xf0]
004bc3f8 e948020000               jmp       0x4bc645
004bc3fd 85db                     test      ebx, ebx
004bc3ff 7445                     je        0x4bc446
004bc401 8bcb                     mov       ecx, ebx
004bc403 e888a3faff               call      0x466790
004bc408 83f802                   cmp       eax, 2
004bc40b 7639                     jbe       0x4bc446
004bc40d 8b4304                   mov       eax, dword ptr [ebx + 4]
004bc410 8b4808                   mov       ecx, dword ptr [eax + 8]
004bc413 83c008                   add       eax, 8
004bc416 83f901                   cmp       ecx, 1
004bc419 752b                     jne       0x4bc446
004bc41b 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bc421 85c9                     test      ecx, ecx
004bc423 7407                     je        0x4bc42c
004bc425 6a01                     push      1
004bc427 e8e4bc5600               call      0xa28110
004bc42c 8b8e48010000             mov       ecx, dword ptr [esi + 0x148]
004bc432 85c9                     test      ecx, ecx
004bc434 0f84d3000000             je        0x4bc50d
004bc43a 6a01                     push      1
004bc43c e8ef115700               call      0xa2d630
004bc441 e9c7000000               jmp       0x4bc50d
004bc446 8b06                     mov       eax, dword ptr [esi]
004bc448 6a00                     push      0
004bc44a 8bce                     mov       ecx, esi
004bc44c ff909c030000             call      dword ptr [eax + 0x39c]
004bc452 85c0                     test      eax, eax
004bc454 8bce                     mov       ecx, esi
004bc456 7418                     je        0x4bc470
004bc458 8b3e                     mov       edi, dword ptr [esi]
004bc45a 6a00                     push      0
004bc45c ff979c030000             call      dword ptr [edi + 0x39c]
004bc462 50                       push      eax
004bc463 8bce                     mov       ecx, esi
004bc465 ff9700010000             call      dword ptr [edi + 0x100]
004bc46b e99d000000               jmp       0x4bc50d
004bc470 8b16                     mov       edx, dword ptr [esi]
004bc472 6a01                     push      1
004bc474 ff929c030000             call      dword ptr [edx + 0x39c]
004bc47a 85c0                     test      eax, eax
004bc47c 8bce                     mov       ecx, esi
004bc47e 7415                     je        0x4bc495
004bc480 8b3e                     mov       edi, dword ptr [esi]
004bc482 6a01                     push      1
004bc484 ff979c030000             call      dword ptr [edi + 0x39c]
004bc48a 50                       push      eax
004bc48b 8bce                     mov       ecx, esi
004bc48d ff9700010000             call      dword ptr [edi + 0x100]
004bc493 eb78                     jmp       0x4bc50d
004bc495 8b06                     mov       eax, dword ptr [esi]
004bc497 6a00                     push      0
004bc499 ff9074030000             call      dword ptr [eax + 0x374]
004bc49f 85c0                     test      eax, eax
004bc4a1 8bce                     mov       ecx, esi
004bc4a3 740c                     je        0x4bc4b1
004bc4a5 8b3e                     mov       edi, dword ptr [esi]
004bc4a7 6a00                     push      0
004bc4a9 ff9774030000             call      dword ptr [edi + 0x374]
004bc4af eb53                     jmp       0x4bc504
004bc4b1 8b16                     mov       edx, dword ptr [esi]
004bc4b3 6a01                     push      1
004bc4b5 ff9274030000             call      dword ptr [edx + 0x374]
004bc4bb 85c0                     test      eax, eax
004bc4bd 8bce                     mov       ecx, esi
004bc4bf 740c                     je        0x4bc4cd
004bc4c1 8b3e                     mov       edi, dword ptr [esi]
004bc4c3 6a01                     push      1
004bc4c5 ff9774030000             call      dword ptr [edi + 0x374]
004bc4cb eb37                     jmp       0x4bc504
004bc4cd 8b06                     mov       eax, dword ptr [esi]
004bc4cf ff9090030000             call      dword ptr [eax + 0x390]
004bc4d5 85c0                     test      eax, eax
004bc4d7 8bce                     mov       ecx, esi
004bc4d9 7413                     je        0x4bc4ee
004bc4db 8b3e                     mov       edi, dword ptr [esi]
004bc4dd ff9790030000             call      dword ptr [edi + 0x390]
004bc4e3 50                       push      eax
004bc4e4 8bce                     mov       ecx, esi
004bc4e6 ff9700010000             call      dword ptr [edi + 0x100]
004bc4ec eb1f                     jmp       0x4bc50d
004bc4ee 8b16                     mov       edx, dword ptr [esi]
004bc4f0 ff9270030000             call      dword ptr [edx + 0x370]
004bc4f6 85c0                     test      eax, eax
004bc4f8 7413                     je        0x4bc50d
004bc4fa 8b3e                     mov       edi, dword ptr [esi]
004bc4fc 8bce                     mov       ecx, esi
004bc4fe ff9770030000             call      dword ptr [edi + 0x370]
004bc504 8bce                     mov       ecx, esi
004bc506 50                       push      eax
004bc507 ff97f0000000             call      dword ptr [edi + 0xf0]
004bc50d 8b06                     mov       eax, dword ptr [esi]
004bc50f 6a00                     push      0
004bc511 6a00                     push      0
004bc513 6a00                     push      0
004bc515 6a00                     push      0
004bc517 6a00                     push      0
004bc519 6a00                     push      0
004bc51b 8bce                     mov       ecx, esi
004bc51d ff9088040000             call      dword ptr [eax + 0x488]
004bc523 8b16                     mov       edx, dword ptr [esi]
004bc525 6a00                     push      0
004bc527 6a00                     push      0
004bc529 6a00                     push      0
004bc52b 6a00                     push      0
004bc52d 6a00                     push      0
004bc52f 6a01                     push      1
004bc531 8bce                     mov       ecx, esi
004bc533 ff9288040000             call      dword ptr [edx + 0x488]
004bc539 8b06                     mov       eax, dword ptr [esi]
004bc53b 680000803f               push      0x3f800000
004bc540 680000803f               push      0x3f800000
004bc545 68e8030000               push      0x3e8
004bc54a 68e8030000               push      0x3e8
004bc54f 6a00                     push      0
004bc551 6a00                     push      0
004bc553 8bce                     mov       ecx, esi
004bc555 ff9094040000             call      dword ptr [eax + 0x494]
004bc55b 8b16                     mov       edx, dword ptr [esi]
004bc55d 6a00                     push      0
004bc55f 6a04                     push      4
004bc561 6a04                     push      4
004bc563 8bce                     mov       ecx, esi
004bc565 ff929c040000             call      dword ptr [edx + 0x49c]
004bc56b 8b06                     mov       eax, dword ptr [esi]
004bc56d 8bce                     mov       ecx, esi
004bc56f ff9004010000             call      dword ptr [eax + 0x104]
004bc575 85c0                     test      eax, eax
004bc577 8b16                     mov       edx, dword ptr [esi]
004bc579 8bce                     mov       ecx, esi
004bc57b 7422                     je        0x4bc59f
004bc57d ff9204010000             call      dword ptr [edx + 0x104]
004bc583 8bc8                     mov       ecx, eax
004bc585 e856545700               call      0xa319e0
004bc58a 8b06                     mov       eax, dword ptr [esi]
004bc58c 6a01                     push      1
004bc58e 8bce                     mov       ecx, esi
004bc590 ff9004010000             call      dword ptr [eax + 0x104]
004bc596 8bc8                     mov       ecx, eax
004bc598 e893105700               call      0xa2d630
004bc59d eb2e                     jmp       0x4bc5cd
004bc59f ff92f4000000             call      dword ptr [edx + 0xf4]
004bc5a5 85c0                     test      eax, eax
004bc5a7 7424                     je        0x4bc5cd
004bc5a9 8b06                     mov       eax, dword ptr [esi]
004bc5ab 8bce                     mov       ecx, esi
004bc5ad ff90f4000000             call      dword ptr [eax + 0xf4]
004bc5b3 8bc8                     mov       ecx, eax
004bc5b5 e8a6ad5600               call      0xa27360
004bc5ba 8b16                     mov       edx, dword ptr [esi]
004bc5bc 6a01                     push      1
004bc5be 8bce                     mov       ecx, esi
004bc5c0 ff92f4000000             call      dword ptr [edx + 0xf4]
004bc5c6 8bc8                     mov       ecx, eax
004bc5c8 e843bb5600               call      0xa28110
004bc5cd 85db                     test      ebx, ebx
004bc5cf c6451400                 mov       byte ptr [ebp + 0x14], 0
004bc5d3 7412                     je        0x4bc5e7
004bc5d5 8bcb                     mov       ecx, ebx
004bc5d7 e8b4a1faff               call      0x466790
004bc5dc 85c0                     test      eax, eax
004bc5de 7607                     jbe       0x4bc5e7
004bc5e0 8b4304                   mov       eax, dword ptr [ebx + 4]
004bc5e3 8b38                     mov       edi, dword ptr [eax]
004bc5e5 eb05                     jmp       0x4bc5ec
004bc5e7 bf02000000               mov       edi, 2
004bc5ec 85db                     test      ebx, ebx
004bc5ee 7416                     je        0x4bc606
004bc5f0 8bcb                     mov       ecx, ebx
004bc5f2 e899a1faff               call      0x466790
004bc5f7 83f801                   cmp       eax, 1
004bc5fa 760a                     jbe       0x4bc606
004bc5fc 8b5b04                   mov       ebx, dword ptr [ebx + 4]
004bc5ff 83c304                   add       ebx, 4
004bc602 8b1b                     mov       ebx, dword ptr [ebx]
004bc604 eb02                     jmp       0x4bc608
004bc606 33db                     xor       ebx, ebx
004bc608 53                       push      ebx
004bc609 57                       push      edi
004bc60a 8bce                     mov       ecx, esi
004bc60c e8afdaffff               call      0x4ba0c0
004bc611 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bc617 6a00                     push      0
004bc619 6a02                     push      2
004bc61b e8204a0500               call      0x511040
004bc620 8b06                     mov       eax, dword ptr [esi]
004bc622 6a10                     push      0x10
004bc624 8bce                     mov       ecx, esi
004bc626 ff9010040000             call      dword ptr [eax + 0x410]
004bc62c 84c0                     test      al, al
004bc62e 7415                     je        0x4bc645
004bc630 8b16                     mov       edx, dword ptr [esi]
004bc632 6a00                     push      0
004bc634 6a00                     push      0
004bc636 6aff                     push      -1
004bc638 686014cd00               push      0xcd1460
004bc63d 8bce                     mov       ecx, esi
004bc63f ff920c010000             call      dword ptr [edx + 0x10c]
004bc645 8a4510                   mov       al, byte ptr [ebp + 0x10]
004bc648 84c0                     test      al, al
004bc64a 7418                     je        0x4bc664
004bc64c 8dbe64150000             lea       edi, [esi + 0x1564]
004bc652 8bcf                     mov       ecx, edi
004bc654 e89788f4ff               call      0x404ef0
004bc659 6a00                     push      0
004bc65b 6a00                     push      0
004bc65d 8bcf                     mov       ecx, edi
004bc65f e8fca86400               call      0xb06f60
004bc664 8a4514                   mov       al, byte ptr [ebp + 0x14]
004bc667 84c0                     test      al, al
004bc669 741a                     je        0x4bc685
004bc66b 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bc671 85c9                     test      ecx, ecx
004bc673 7410                     je        0x4bc685
004bc675 e8e6ac5600               call      0xa27360
004bc67a 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bc680 e80b765600               call      0xa23c90
004bc685 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004bc68b 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004bc68e 8b8660150000             mov       eax, dword ptr [esi + 0x1560]
004bc694 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004bc69a 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004bc69d 8d0482                   lea       eax, [edx + eax*4]
004bc6a0 8bc8                     mov       ecx, eax
004bc6a2 33cf                     xor       ecx, edi
004bc6a4 33cb                     xor       ecx, ebx
004bc6a6 8908                     mov       dword ptr [eax], ecx
004bc6a8 a1d8012101               mov       eax, dword ptr [0x12101d8]
004bc6ad 8b9660150000             mov       edx, dword ptr [esi + 0x1560]
004bc6b3 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004bc6b6 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004bc6bc 8d0491                   lea       eax, [ecx + edx*4]
004bc6bf 8bd0                     mov       edx, eax
004bc6c1 33d7                     xor       edx, edi
004bc6c3 33d3                     xor       edx, ebx
004bc6c5 8910                     mov       dword ptr [eax], edx
004bc6c7 8dbeec140000             lea       edi, [esi + 0x14ec]
004bc6cd c7451417000000           mov       dword ptr [ebp + 0x14], 0x17
004bc6d4 8b07                     mov       eax, dword ptr [edi]
004bc6d6 85c0                     test      eax, eax
004bc6d8 740b                     je        0x4bc6e5
004bc6da 8bc8                     mov       ecx, eax
004bc6dc 8b01                     mov       eax, dword ptr [ecx]
004bc6de 53                       push      ebx
004bc6df ff90cc000000             call      dword ptr [eax + 0xcc]
004bc6e5 8b4514                   mov       eax, dword ptr [ebp + 0x14]
004bc6e8 83c704                   add       edi, 4
004bc6eb 48                       dec       eax
004bc6ec 894514                   mov       dword ptr [ebp + 0x14], eax
004bc6ef 75e3                     jne       0x4bc6d4
004bc6f1 8a8665160000             mov       al, byte ptr [esi + 0x1665]
004bc6f7 84c0                     test      al, al
004bc6f9 0f8484000000             je        0x4bc783
004bc6ff 8dbe5c150000             lea       edi, [esi + 0x155c]
004bc705 8bcf                     mov       ecx, edi
004bc707 e85459f4ff               call      0x402060
004bc70c 83f804                   cmp       eax, 4
004bc70f 7535                     jne       0x4bc746
004bc711 8d8e20170000             lea       ecx, [esi + 0x1720]
004bc717 e84459f4ff               call      0x402060
004bc71c 83f802                   cmp       eax, 2
004bc71f 7525                     jne       0x4bc746
004bc721 8a8666160000             mov       al, byte ptr [esi + 0x1666]
004bc727 84c0                     test      al, al
004bc729 751b                     jne       0x4bc746
004bc72b c7866816000000000000     mov       dword ptr [esi + 0x1668], 0
004bc735 c7866c160000ffffffff     mov       dword ptr [esi + 0x166c], 0xffffffff
004bc73f c6866616000001           mov       byte ptr [esi + 0x1666], 1
004bc746 8bcf                     mov       ecx, edi
004bc748 e81359f4ff               call      0x402060
004bc74d 83f804                   cmp       eax, 4
004bc750 7431                     je        0x4bc783
004bc752 8bcf                     mov       ecx, edi
004bc754 e80759f4ff               call      0x402060
004bc759 83f809                   cmp       eax, 9
004bc75c 7425                     je        0x4bc783
004bc75e 8a8666160000             mov       al, byte ptr [esi + 0x1666]
004bc764 84c0                     test      al, al
004bc766 741b                     je        0x4bc783
004bc768 c7866816000000000000     mov       dword ptr [esi + 0x1668], 0
004bc772 c7866c160000ffffffff     mov       dword ptr [esi + 0x166c], 0xffffffff
004bc77c c6866616000000           mov       byte ptr [esi + 0x1666], 0
004bc783 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004bc786 5f                       pop       edi
004bc787 5e                       pop       esi
004bc788 5b                       pop       ebx
004bc789 64890d00000000           mov       dword ptr fs:[0], ecx
004bc790 8be5                     mov       esp, ebp
004bc792 5d                       pop       ebp
004bc793 c21000                   ret       0x10
004bc796 8bff                     mov       edi, edi
004bc798 ebad                     jmp       0x4bc747
004bc79a 4b                       dec       ebx
004bc79b 0016                     add       byte ptr [esi], dl
004bc79d af                       scasd     eax, dword ptr es:[edi]
004bc79e 4b                       dec       ebx
004bc79f 00ee                     add       dh, ch
004bc7a1 af                       scasd     eax, dword ptr es:[edi]
004bc7a2 4b                       dec       ebx
004bc7a3 0091b04b0049             add       byte ptr [ecx + 0x49004bb0], dl
004bc7a9 b24b                     mov       dl, 0x4b
004bc7ab 0076b9                   add       byte ptr [esi - 0x47], dh
004bc7ae 4b                       dec       ebx
004bc7af 00cc                     add       ah, cl
004bc7b1 ba4b003ac2               mov       edx, 0xc23a004b
004bc7b6 4b                       dec       ebx
004bc7b7 00b1c24b00fd             add       byte ptr [ecx - 0x2ffb43e], dh
004bc7bd c3                       ret       
004bc7be 4b                       dec       ebx
004bc7bf 0081c1e81800             add       byte ptr [ecx + 0x18e8c1], al
004bc7c5 00e9                     add       cl, ch
004bc7c7 d56f                     aad       0x6f
004bc7c9 2800                     sub       byte ptr [eax], al
004bc7cb cc                       int3      
004bc7cc cc                       int3      
004bc7cd cc                       int3      
004bc7ce cc                       int3      
004bc7cf cc                       int3      
