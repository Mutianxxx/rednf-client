004f8a30 55                       push      ebp
004f8a31 8bec                     mov       ebp, esp
004f8a33 6aff                     push      -1
004f8a35 681a9cc500               push      0xc59c1a
004f8a3a 64a100000000             mov       eax, dword ptr fs:[0]
004f8a40 50                       push      eax
004f8a41 64892500000000           mov       dword ptr fs:[0], esp
004f8a48 81ec84000000             sub       esp, 0x84
004f8a4e 53                       push      ebx
004f8a4f 56                       push      esi
004f8a50 8bf1                     mov       esi, ecx
004f8a52 8b86e4190000             mov       eax, dword ptr [esi + 0x19e4]
004f8a58 83f803                   cmp       eax, 3
004f8a5b 57                       push      edi
004f8a5c 7405                     je        0x4f8a63
004f8a5e 83f808                   cmp       eax, 8
004f8a61 750a                     jne       0x4f8a6d
004f8a63 8b06                     mov       eax, dword ptr [esi]
004f8a65 8bce                     mov       ecx, esi
004f8a67 ff90c8050000             call      dword ptr [eax + 0x5c8]
004f8a6d 33ff                     xor       edi, edi
004f8a6f 897dec                   mov       dword ptr [ebp - 0x14], edi
004f8a72 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8a78 85c0                     test      eax, eax
004f8a7a 0f84cc010000             je        0x4f8c4c
004f8a80 8b8e60220000             mov       ecx, dword ptr [esi + 0x2260]
004f8a86 2bc8                     sub       ecx, eax
004f8a88 b867666666               mov       eax, 0x66666667
004f8a8d f7e9                     imul      ecx
004f8a8f 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004f8a92 c1fa03                   sar       edx, 3
004f8a95 8bc2                     mov       eax, edx
004f8a97 c1e81f                   shr       eax, 0x1f
004f8a9a 03c2                     add       eax, edx
004f8a9c 3bc8                     cmp       ecx, eax
004f8a9e 0f83a8010000             jae       0x4f8c4c
004f8aa4 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004f8aa7 8b11                     mov       edx, dword ptr [ecx]
004f8aa9 ff92a4020000             call      dword ptr [edx + 0x2a4]
004f8aaf 85c0                     test      eax, eax
004f8ab1 0f841b010000             je        0x4f8bd2
004f8ab7 8b06                     mov       eax, dword ptr [esi]
004f8ab9 8bce                     mov       ecx, esi
004f8abb ff909c000000             call      dword ptr [eax + 0x9c]
004f8ac1 85c0                     test      eax, eax
004f8ac3 0f8509010000             jne       0x4f8bd2
004f8ac9 8d9e5c150000             lea       ebx, [esi + 0x155c]
004f8acf 8bcb                     mov       ecx, ebx
004f8ad1 e88a95f0ff               call      0x402060
004f8ad6 83f804                   cmp       eax, 4
004f8ad9 0f84f3000000             je        0x4f8bd2
004f8adf 8bcb                     mov       ecx, ebx
004f8ae1 e87a95f0ff               call      0x402060
004f8ae6 83f809                   cmp       eax, 9
004f8ae9 0f84e3000000             je        0x4f8bd2
004f8aef 8a4510                   mov       al, byte ptr [ebp + 0x10]
004f8af2 84c0                     test      al, al
004f8af4 0f85d8000000             jne       0x4f8bd2
004f8afa 8d8ebc040000             lea       ecx, [esi + 0x4bc]
004f8b00 e85b95f0ff               call      0x402060
004f8b05 85c0                     test      eax, eax
004f8b07 740d                     je        0x4f8b16
004f8b09 8d8ec4040000             lea       ecx, [esi + 0x4c4]
004f8b0f e84c95f0ff               call      0x402060
004f8b14 eb07                     jmp       0x4f8b1d
004f8b16 8bce                     mov       ecx, esi
004f8b18 e8c314faff               call      0x499fe0
004f8b1d 85c0                     test      eax, eax
004f8b1f 0f85ad000000             jne       0x4f8bd2
004f8b25 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004f8b28 8b13                     mov       edx, dword ptr [ebx]
004f8b2a 8bcb                     mov       ecx, ebx
004f8b2c ff929c010000             call      dword ptr [edx + 0x19c]
004f8b32 8b03                     mov       eax, dword ptr [ebx]
004f8b34 8bcb                     mov       ecx, ebx
004f8b36 ff909c010000             call      dword ptr [eax + 0x19c]
004f8b3c 8b88ec000000             mov       ecx, dword ptr [eax + 0xec]
004f8b42 85c9                     test      ecx, ecx
004f8b44 0f8488000000             je        0x4f8bd2
004f8b4a 8bce                     mov       ecx, esi
004f8b4c e83f35faff               call      0x49c090
004f8b51 84c0                     test      al, al
004f8b53 747d                     je        0x4f8bd2
004f8b55 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8b5b 8a4c070c                 mov       cl, byte ptr [edi + eax + 0xc]
004f8b5f 84c9                     test      cl, cl
004f8b61 746f                     je        0x4f8bd2
004f8b63 8a4c070d                 mov       cl, byte ptr [edi + eax + 0xd]
004f8b67 84c9                     test      cl, cl
004f8b69 7467                     je        0x4f8bd2
004f8b6b 8b13                     mov       edx, dword ptr [ebx]
004f8b6d 8bcb                     mov       ecx, ebx
004f8b6f ff92b4010000             call      dword ptr [edx + 0x1b4]
004f8b75 84c0                     test      al, al
004f8b77 740d                     je        0x4f8b86
004f8b79 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8b7f 837c070801               cmp       dword ptr [edi + eax + 8], 1
004f8b84 742d                     je        0x4f8bb3
004f8b86 8b03                     mov       eax, dword ptr [ebx]
004f8b88 8bcb                     mov       ecx, ebx
004f8b8a ff90b4010000             call      dword ptr [eax + 0x1b4]
004f8b90 84c0                     test      al, al
004f8b92 750e                     jne       0x4f8ba2
004f8b94 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8b9a 8b4c0708                 mov       ecx, dword ptr [edi + eax + 8]
004f8b9e 85c9                     test      ecx, ecx
004f8ba0 7411                     je        0x4f8bb3
004f8ba2 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8ba8 837c070802               cmp       dword ptr [edi + eax + 8], 2
004f8bad 0f858d000000             jne       0x4f8c40
004f8bb3 6a00                     push      0
004f8bb5 e836553b00               call      0x8ae0f0
004f8bba 99                       cdq       
004f8bbb b964000000               mov       ecx, 0x64
004f8bc0 f7f9                     idiv      ecx
004f8bc2 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8bc8 8b0c07                   mov       ecx, dword ptr [edi + eax]
004f8bcb 83c404                   add       esp, 4
004f8bce 3bd1                     cmp       edx, ecx
004f8bd0 7c0b                     jl        0x4f8bdd
004f8bd2 ff45ec                   inc       dword ptr [ebp - 0x14]
004f8bd5 83c714                   add       edi, 0x14
004f8bd8 e995feffff               jmp       0x4f8a72
004f8bdd 33ff                     xor       edi, edi
004f8bdf 897ddc                   mov       dword ptr [ebp - 0x24], edi
004f8be2 897de0                   mov       dword ptr [ebp - 0x20], edi
004f8be5 897de4                   mov       dword ptr [ebp - 0x1c], edi
004f8be8 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004f8beb 8d1480                   lea       edx, [eax + eax*4]
004f8bee 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004f8bf4 8d0490                   lea       eax, [eax + edx*4]
004f8bf7 83c004                   add       eax, 4
004f8bfa 50                       push      eax
004f8bfb 8d4dd8                   lea       ecx, [ebp - 0x28]
004f8bfe 897dfc                   mov       dword ptr [ebp - 4], edi
004f8c01 e81ae5f0ff               call      0x407120
004f8c06 8b16                     mov       edx, dword ptr [esi]
004f8c08 57                       push      edi
004f8c09 57                       push      edi
004f8c0a 57                       push      edi
004f8c0b 8d45d8                   lea       eax, [ebp - 0x28]
004f8c0e 50                       push      eax
004f8c0f 6a08                     push      8
004f8c11 8bce                     mov       ecx, esi
004f8c13 ff928c020000             call      dword ptr [edx + 0x28c]
004f8c19 8b16                     mov       edx, dword ptr [esi]
004f8c1b 8bce                     mov       ecx, esi
004f8c1d ff9290020000             call      dword ptr [edx + 0x290]
004f8c23 8d4dd8                   lea       ecx, [ebp - 0x28]
004f8c26 e825c11400               call      0x644d50
004f8c2b 5f                       pop       edi
004f8c2c 5e                       pop       esi
004f8c2d 33c0                     xor       eax, eax
004f8c2f 5b                       pop       ebx
004f8c30 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004f8c33 64890d00000000           mov       dword ptr fs:[0], ecx
004f8c3a 8be5                     mov       esp, ebp
004f8c3c 5d                       pop       ebp
004f8c3d c20c00                   ret       0xc
004f8c40 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004f8c43 6a00                     push      0
004f8c45 50                       push      eax
004f8c46 53                       push      ebx
004f8c47 e9740e0000               jmp       0x4f9ac0
004f8c4c 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004f8c52 85c9                     test      ecx, ecx
004f8c54 0f8424010000             je        0x4f8d7e
004f8c5a 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004f8c60 2bc1                     sub       eax, ecx
004f8c62 c1f804                   sar       eax, 4
004f8c65 85c0                     test      eax, eax
004f8c67 0f8411010000             je        0x4f8d7e
004f8c6d 33d2                     xor       edx, edx
004f8c6f 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004f8c75 85c9                     test      ecx, ecx
004f8c77 8955f0                   mov       dword ptr [ebp - 0x10], edx
004f8c7a 0f84fe000000             je        0x4f8d7e
004f8c80 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004f8c86 2bc1                     sub       eax, ecx
004f8c88 c1f804                   sar       eax, 4
004f8c8b 3bd0                     cmp       edx, eax
004f8c8d 0f83eb000000             jae       0x4f8d7e
004f8c93 33ff                     xor       edi, edi
004f8c95 8bca                     mov       ecx, edx
004f8c97 c1e104                   shl       ecx, 4
004f8c9a 897dec                   mov       dword ptr [ebp - 0x14], edi
004f8c9d 894de8                   mov       dword ptr [ebp - 0x18], ecx
004f8ca0 8b96a0220000             mov       edx, dword ptr [esi + 0x22a0]
004f8ca6 03ca                     add       ecx, edx
004f8ca8 8b5104                   mov       edx, dword ptr [ecx + 4]
004f8cab 85d2                     test      edx, edx
004f8cad 0f84c2000000             je        0x4f8d75
004f8cb3 8b4108                   mov       eax, dword ptr [ecx + 8]
004f8cb6 2bc2                     sub       eax, edx
004f8cb8 c1f802                   sar       eax, 2
004f8cbb 3bf8                     cmp       edi, eax
004f8cbd 0f83b2000000             jae       0x4f8d75
004f8cc3 8d1cbd00000000           lea       ebx, [edi*4]
004f8cca 8bc2                     mov       eax, edx
004f8ccc 03c3                     add       eax, ebx
004f8cce 8b00                     mov       eax, dword ptr [eax]
004f8cd0 8a8838010000             mov       cl, byte ptr [eax + 0x138]
004f8cd6 84c9                     test      cl, cl
004f8cd8 0f8486000000             je        0x4f8d64
004f8cde 8b16                     mov       edx, dword ptr [esi]
004f8ce0 8bce                     mov       ecx, esi
004f8ce2 ff92f4000000             call      dword ptr [edx + 0xf4]
004f8ce8 85c0                     test      eax, eax
004f8cea 7478                     je        0x4f8d64
004f8cec 8b06                     mov       eax, dword ptr [esi]
004f8cee 8bce                     mov       ecx, esi
004f8cf0 ff90f4000000             call      dword ptr [eax + 0xf4]
004f8cf6 8bf8                     mov       edi, eax
004f8cf8 83bf24010000ff           cmp       dword ptr [edi + 0x124], -1
004f8cff 7507                     jne       0x4f8d08
004f8d01 8bcf                     mov       ecx, edi
004f8d03 e858f25200               call      0xa27f60
004f8d08 81c7a8000000             add       edi, 0xa8
004f8d0e 7454                     je        0x4f8d64
004f8d10 8b16                     mov       edx, dword ptr [esi]
004f8d12 8bce                     mov       ecx, esi
004f8d14 ff92f4000000             call      dword ptr [edx + 0xf4]
004f8d1a 8bf8                     mov       edi, eax
004f8d1c 83bf24010000ff           cmp       dword ptr [edi + 0x124], -1
004f8d23 7507                     jne       0x4f8d2c
004f8d25 8bcf                     mov       ecx, edi
004f8d27 e834f25200               call      0xa27f60
004f8d2c 8b8fdc000000             mov       ecx, dword ptr [edi + 0xdc]
004f8d32 8b15f83e0d01             mov       edx, dword ptr [0x10d3ef8]
004f8d38 8d87dc000000             lea       eax, [edi + 0xdc]
004f8d3e 2bc8                     sub       ecx, eax
004f8d40 33ca                     xor       ecx, edx
004f8d42 83f901                   cmp       ecx, 1
004f8d45 741d                     je        0x4f8d64
004f8d47 8b86a0220000             mov       eax, dword ptr [esi + 0x22a0]
004f8d4d 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
004f8d50 8b16                     mov       edx, dword ptr [esi]
004f8d52 03c7                     add       eax, edi
004f8d54 8b4004                   mov       eax, dword ptr [eax + 4]
004f8d57 03c3                     add       eax, ebx
004f8d59 8b00                     mov       eax, dword ptr [eax]
004f8d5b 50                       push      eax
004f8d5c 8bce                     mov       ecx, esi
004f8d5e ff92fc000000             call      dword ptr [edx + 0xfc]
004f8d64 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004f8d67 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004f8d6a 40                       inc       eax
004f8d6b 8945ec                   mov       dword ptr [ebp - 0x14], eax
004f8d6e 8bf8                     mov       edi, eax
004f8d70 e92bffffff               jmp       0x4f8ca0
004f8d75 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004f8d78 42                       inc       edx
004f8d79 e9f1feffff               jmp       0x4f8c6f
004f8d7e 8b7d08                   mov       edi, dword ptr [ebp + 8]
004f8d81 8b17                     mov       edx, dword ptr [edi]
004f8d83 8bcf                     mov       ecx, edi
004f8d85 ff92b4010000             call      dword ptr [edx + 0x1b4]
004f8d8b 84c0                     test      al, al
004f8d8d 0f84a9000000             je        0x4f8e3c
004f8d93 8b06                     mov       eax, dword ptr [esi]
004f8d95 57                       push      edi
004f8d96 8bce                     mov       ecx, esi
004f8d98 ff90c0060000             call      dword ptr [eax + 0x6c0]
004f8d9e 84c0                     test      al, al
004f8da0 0f8496000000             je        0x4f8e3c
004f8da6 8bce                     mov       ecx, esi
004f8da8 e8e332faff               call      0x49c090
004f8dad 84c0                     test      al, al
004f8daf 0f8487000000             je        0x4f8e3c
004f8db5 8bdf                     mov       ebx, edi
004f8db7 8b13                     mov       edx, dword ptr [ebx]
004f8db9 6a01                     push      1
004f8dbb 8bcb                     mov       ecx, ebx
004f8dbd ff9264010000             call      dword ptr [edx + 0x164]
004f8dc3 8b03                     mov       eax, dword ptr [ebx]
004f8dc5 8bcb                     mov       ecx, ebx
004f8dc7 ff5048                   call      dword ptr [eax + 0x48]
004f8dca 8b7878                   mov       edi, dword ptr [eax + 0x78]
004f8dcd 8bcb                     mov       ecx, ebx
004f8dcf e82cfafeff               call      0x4e8800
004f8dd4 8b8b04020000             mov       ecx, dword ptr [ebx + 0x204]
004f8dda 8b17                     mov       edx, dword ptr [edi]
004f8ddc f6d8                     neg       al
004f8dde 894d08                   mov       dword ptr [ebp + 8], ecx
004f8de1 8bcf                     mov       ecx, edi
004f8de3 1bc0                     sbb       eax, eax
004f8de5 f7d0                     not       eax
004f8de7 23f0                     and       esi, eax
004f8de9 8d8570ffffff             lea       eax, [ebp - 0x90]
004f8def 50                       push      eax
004f8df0 ff5214                   call      dword ptr [edx + 0x14]
004f8df3 8b17                     mov       edx, dword ptr [edi]
004f8df5 8bcf                     mov       ecx, edi
004f8df7 ff522c                   call      dword ptr [edx + 0x2c]
004f8dfa 8b13                     mov       edx, dword ptr [ebx]
004f8dfc 6a00                     push      0
004f8dfe 6a00                     push      0
004f8e00 6a00                     push      0
004f8e02 6a00                     push      0
004f8e04 6a00                     push      0
004f8e06 50                       push      eax
004f8e07 8d8570ffffff             lea       eax, [ebp - 0x90]
004f8e0d 50                       push      eax
004f8e0e 8bcb                     mov       ecx, ebx
004f8e10 ff923c030000             call      dword ptr [edx + 0x33c]
004f8e16 8b4020                   mov       eax, dword ptr [eax + 0x20]
004f8e19 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004f8e1c 50                       push      eax
004f8e1d 51                       push      ecx
004f8e1e 56                       push      esi
004f8e1f e8dc12ffff               call      0x4ea100
004f8e24 83c428                   add       esp, 0x28
004f8e27 5f                       pop       edi
004f8e28 5e                       pop       esi
004f8e29 33c0                     xor       eax, eax
004f8e2b 5b                       pop       ebx
004f8e2c 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004f8e2f 64890d00000000           mov       dword ptr fs:[0], ecx
004f8e36 8be5                     mov       esp, ebp
004f8e38 5d                       pop       ebp
004f8e39 c20c00                   ret       0xc
004f8e3c 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004f8e3f 8b11                     mov       edx, dword ptr [ecx]
004f8e41 ff929c010000             call      dword ptr [edx + 0x19c]
004f8e47 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004f8e4d 8b4820                   mov       ecx, dword ptr [eax + 0x20]
004f8e50 8d581c                   lea       ebx, [eax + 0x1c]
004f8e53 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f8e56 8b03                     mov       eax, dword ptr [ebx]
004f8e58 33c7                     xor       eax, edi
004f8e5a 2bc3                     sub       eax, ebx
004f8e5c 3bc1                     cmp       eax, ecx
004f8e5e 740e                     je        0x4f8e6e
004f8e60 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8e66 6a3f                     push      0x3f
004f8e68 53                       push      ebx
004f8e69 e842e26100               call      0xb170b0
004f8e6e 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8e74 8b4304                   mov       eax, dword ptr [ebx + 4]
004f8e77 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004f8e7a c1e002                   shl       eax, 2
004f8e7d 8b3c02                   mov       edi, dword ptr [edx + eax]
004f8e80 03d0                     add       edx, eax
004f8e82 33fa                     xor       edi, edx
004f8e84 333ddc012101             xor       edi, dword ptr [0x12101dc]
004f8e8a 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004f8e8d 03c2                     add       eax, edx
004f8e8f 8b10                     mov       edx, dword ptr [eax]
004f8e91 33d0                     xor       edx, eax
004f8e93 3315dc012101             xor       edx, dword ptr [0x12101dc]
004f8e99 3bfa                     cmp       edi, edx
004f8e9b 740e                     je        0x4f8eab
004f8e9d 6a40                     push      0x40
004f8e9f 53                       push      ebx
004f8ea0 e80be26100               call      0xb170b0
004f8ea5 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8eab 85ff                     test      edi, edi
004f8ead 0f8572010000             jne       0x4f9025
004f8eb3 8b5df0                   mov       ebx, dword ptr [ebp - 0x10]
004f8eb6 8bcb                     mov       ecx, ebx
004f8eb8 e8f3a4f3ff               call      0x4333b0
004f8ebd d81da4d7e900             fcomp     dword ptr [0xe9d7a4]
004f8ec3 dfe0                     fnstsw    ax
004f8ec5 f6c441                   test      ah, 0x41
004f8ec8 0f8451010000             je        0x4f901f
004f8ece 8b4308                   mov       eax, dword ptr [ebx + 8]
004f8ed1 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004f8ed7 8b4b0c                   mov       ecx, dword ptr [ebx + 0xc]
004f8eda 83c308                   add       ebx, 8
004f8edd 33c7                     xor       eax, edi
004f8edf 2bc3                     sub       eax, ebx
004f8ee1 3bc1                     cmp       eax, ecx
004f8ee3 740e                     je        0x4f8ef3
004f8ee5 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8eeb 6a3f                     push      0x3f
004f8eed 53                       push      ebx
004f8eee e8bde16100               call      0xb170b0
004f8ef3 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8ef9 8b4304                   mov       eax, dword ptr [ebx + 4]
004f8efc 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004f8eff c1e002                   shl       eax, 2
004f8f02 8b3c02                   mov       edi, dword ptr [edx + eax]
004f8f05 03d0                     add       edx, eax
004f8f07 33fa                     xor       edi, edx
004f8f09 333ddc012101             xor       edi, dword ptr [0x12101dc]
004f8f0f 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004f8f12 03c2                     add       eax, edx
004f8f14 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004f8f1a 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f8f1d 33c2                     xor       eax, edx
004f8f1f 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004f8f22 3302                     xor       eax, dword ptr [edx]
004f8f24 3bf8                     cmp       edi, eax
004f8f26 740e                     je        0x4f8f36
004f8f28 6a40                     push      0x40
004f8f2a 53                       push      ebx
004f8f2b e880e16100               call      0xb170b0
004f8f30 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8f36 85ff                     test      edi, edi
004f8f38 0f8fe7000000             jg        0x4f9025
004f8f3e 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004f8f41 33c0                     xor       eax, eax
004f8f43 8945ec                   mov       dword ptr [ebp - 0x14], eax
004f8f46 8945e8                   mov       dword ptr [ebp - 0x18], eax
004f8f49 8b86e8220000             mov       eax, dword ptr [esi + 0x22e8]
004f8f4f 85c0                     test      eax, eax
004f8f51 0f84b2030000             je        0x4f9309
004f8f57 8b96ec220000             mov       edx, dword ptr [esi + 0x22ec]
004f8f5d 2bd0                     sub       edx, eax
004f8f5f b867666666               mov       eax, 0x66666667
004f8f64 f7ea                     imul      edx
004f8f66 c1fa04                   sar       edx, 4
004f8f69 8bc2                     mov       eax, edx
004f8f6b c1e81f                   shr       eax, 0x1f
004f8f6e 03c2                     add       eax, edx
004f8f70 3945ec                   cmp       dword ptr [ebp - 0x14], eax
004f8f73 0f8390030000             jae       0x4f9309
004f8f79 a1dc012101               mov       eax, dword ptr [0x12101dc]
004f8f7e 8b9628180000             mov       edx, dword ptr [esi + 0x1828]
004f8f84 8d9e28180000             lea       ebx, [esi + 0x1828]
004f8f8a 33d0                     xor       edx, eax
004f8f8c 8b4304                   mov       eax, dword ptr [ebx + 4]
004f8f8f 2bd3                     sub       edx, ebx
004f8f91 3bd0                     cmp       edx, eax
004f8f93 740e                     je        0x4f8fa3
004f8f95 6a3f                     push      0x3f
004f8f97 53                       push      ebx
004f8f98 e813e16100               call      0xb170b0
004f8f9d 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8fa3 8b4304                   mov       eax, dword ptr [ebx + 4]
004f8fa6 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004f8fa9 c1e002                   shl       eax, 2
004f8fac 8b3c02                   mov       edi, dword ptr [edx + eax]
004f8faf 03d0                     add       edx, eax
004f8fb1 33fa                     xor       edi, edx
004f8fb3 333ddc012101             xor       edi, dword ptr [0x12101dc]
004f8fb9 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004f8fbc 03c2                     add       eax, edx
004f8fbe 8b10                     mov       edx, dword ptr [eax]
004f8fc0 33d0                     xor       edx, eax
004f8fc2 3315dc012101             xor       edx, dword ptr [0x12101dc]
004f8fc8 3bfa                     cmp       edi, edx
004f8fca 740e                     je        0x4f8fda
004f8fcc 6a40                     push      0x40
004f8fce 53                       push      ebx
004f8fcf e8dce06100               call      0xb170b0
004f8fd4 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f8fda 8b55e8                   mov       edx, dword ptr [ebp - 0x18]
004f8fdd 8b86e8220000             mov       eax, dword ptr [esi + 0x22e8]
004f8fe3 03c2                     add       eax, edx
004f8fe5 3b7804                   cmp       edi, dword ptr [eax + 4]
004f8fe8 7520                     jne       0x4f900a
004f8fea 833802                   cmp       dword ptr [eax], 2
004f8fed 741b                     je        0x4f900a
004f8fef 8b8618230000             mov       eax, dword ptr [esi + 0x2318]
004f8ff5 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004f8ff8 8d0488                   lea       eax, [eax + ecx*4]
004f8ffb 8b08                     mov       ecx, dword ptr [eax]
004f8ffd 6a0a                     push      0xa
004f8fff e88c422500               call      0x74d290
004f9004 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f900a 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
004f900d 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
004f9010 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004f9013 42                       inc       edx
004f9014 8955ec                   mov       dword ptr [ebp - 0x14], edx
004f9017 83c028                   add       eax, 0x28
004f901a e927ffffff               jmp       0x4f8f46
004f901f 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9025 8b5d0c                   mov       ebx, dword ptr [ebp + 0xc]
004f9028 8dbe1e1e0000             lea       edi, [esi + 0x1e1e]
004f902e 3bfb                     cmp       edi, ebx
004f9030 7439                     je        0x4f906b
004f9032 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004f9035 8b4704                   mov       eax, dword ptr [edi + 4]
004f9038 8b5304                   mov       edx, dword ptr [ebx + 4]
004f903b 8d0481                   lea       eax, [ecx + eax*4]
004f903e 8d0c91                   lea       ecx, [ecx + edx*4]
004f9041 8bd1                     mov       edx, ecx
004f9043 33d0                     xor       edx, eax
004f9045 3311                     xor       edx, dword ptr [ecx]
004f9047 8910                     mov       dword ptr [eax], edx
004f9049 a1d8012101               mov       eax, dword ptr [0x12101d8]
004f904e 8b4048                   mov       eax, dword ptr [eax + 0x48]
004f9051 8b4f04                   mov       ecx, dword ptr [edi + 4]
004f9054 8b5304                   mov       edx, dword ptr [ebx + 4]
004f9057 8d0c88                   lea       ecx, [eax + ecx*4]
004f905a 8d0490                   lea       eax, [eax + edx*4]
004f905d 8bd0                     mov       edx, eax
004f905f 33d1                     xor       edx, ecx
004f9061 3310                     xor       edx, dword ptr [eax]
004f9063 8911                     mov       dword ptr [ecx], edx
004f9065 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f906b 8d5308                   lea       edx, [ebx + 8]
004f906e 8d4708                   lea       eax, [edi + 8]
004f9071 3bc2                     cmp       eax, edx
004f9073 743d                     je        0x4f90b2
004f9075 8b4204                   mov       eax, dword ptr [edx + 4]
004f9078 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004f907b 8b5f0c                   mov       ebx, dword ptr [edi + 0xc]
004f907e 8d0481                   lea       eax, [ecx + eax*4]
004f9081 8d0c99                   lea       ecx, [ecx + ebx*4]
004f9084 8b18                     mov       ebx, dword ptr [eax]
004f9086 33d8                     xor       ebx, eax
004f9088 33d9                     xor       ebx, ecx
004f908a 8919                     mov       dword ptr [ecx], ebx
004f908c 8b5204                   mov       edx, dword ptr [edx + 4]
004f908f 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9095 8b4148                   mov       eax, dword ptr [ecx + 0x48]
004f9098 8b5d0c                   mov       ebx, dword ptr [ebp + 0xc]
004f909b 8d0c90                   lea       ecx, [eax + edx*4]
004f909e 8b570c                   mov       edx, dword ptr [edi + 0xc]
004f90a1 8d0490                   lea       eax, [eax + edx*4]
004f90a4 8b11                     mov       edx, dword ptr [ecx]
004f90a6 33d0                     xor       edx, eax
004f90a8 33d1                     xor       edx, ecx
004f90aa 8910                     mov       dword ptr [eax], edx
004f90ac 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f90b2 8d5310                   lea       edx, [ebx + 0x10]
004f90b5 8d4710                   lea       eax, [edi + 0x10]
004f90b8 3bc2                     cmp       eax, edx
004f90ba 743d                     je        0x4f90f9
004f90bc 8b4204                   mov       eax, dword ptr [edx + 4]
004f90bf 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004f90c2 8b5f14                   mov       ebx, dword ptr [edi + 0x14]
004f90c5 8d0481                   lea       eax, [ecx + eax*4]
004f90c8 8d0c99                   lea       ecx, [ecx + ebx*4]
004f90cb 8b18                     mov       ebx, dword ptr [eax]
004f90cd 33d9                     xor       ebx, ecx
004f90cf 33d8                     xor       ebx, eax
004f90d1 8919                     mov       dword ptr [ecx], ebx
004f90d3 8b5204                   mov       edx, dword ptr [edx + 4]
004f90d6 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f90dc 8b4148                   mov       eax, dword ptr [ecx + 0x48]
004f90df 8b5d0c                   mov       ebx, dword ptr [ebp + 0xc]
004f90e2 8d0c90                   lea       ecx, [eax + edx*4]
004f90e5 8b5714                   mov       edx, dword ptr [edi + 0x14]
004f90e8 8d0490                   lea       eax, [eax + edx*4]
004f90eb 8b11                     mov       edx, dword ptr [ecx]
004f90ed 33d0                     xor       edx, eax
004f90ef 33d1                     xor       edx, ecx
004f90f1 8910                     mov       dword ptr [eax], edx
004f90f3 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f90f9 8d5318                   lea       edx, [ebx + 0x18]
004f90fc 8d5f18                   lea       ebx, [edi + 0x18]
004f90ff 3bda                     cmp       ebx, edx
004f9101 743a                     je        0x4f913d
004f9103 8b4204                   mov       eax, dword ptr [edx + 4]
004f9106 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004f9109 8b5b04                   mov       ebx, dword ptr [ebx + 4]
004f910c 8d0481                   lea       eax, [ecx + eax*4]
004f910f 8d0c99                   lea       ecx, [ecx + ebx*4]
004f9112 8b18                     mov       ebx, dword ptr [eax]
004f9114 33d9                     xor       ebx, ecx
004f9116 33d8                     xor       ebx, eax
004f9118 8919                     mov       dword ptr [ecx], ebx
004f911a 8b5204                   mov       edx, dword ptr [edx + 4]
004f911d 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9123 8b4148                   mov       eax, dword ptr [ecx + 0x48]
004f9126 8d0c90                   lea       ecx, [eax + edx*4]
004f9129 8b571c                   mov       edx, dword ptr [edi + 0x1c]
004f912c 8d0490                   lea       eax, [eax + edx*4]
004f912f 8b11                     mov       edx, dword ptr [ecx]
004f9131 33d0                     xor       edx, eax
004f9133 33d1                     xor       edx, ecx
004f9135 8910                     mov       dword ptr [eax], edx
004f9137 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f913d 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004f9140 83c220                   add       edx, 0x20
004f9143 83c720                   add       edi, 0x20
004f9146 3bfa                     cmp       edi, edx
004f9148 743c                     je        0x4f9186
004f914a 8b4204                   mov       eax, dword ptr [edx + 4]
004f914d 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004f9150 8b5f04                   mov       ebx, dword ptr [edi + 4]
004f9153 8d0481                   lea       eax, [ecx + eax*4]
004f9156 8d0c99                   lea       ecx, [ecx + ebx*4]
004f9159 8bd9                     mov       ebx, ecx
004f915b 33d8                     xor       ebx, eax
004f915d 3318                     xor       ebx, dword ptr [eax]
004f915f 8919                     mov       dword ptr [ecx], ebx
004f9161 8b5204                   mov       edx, dword ptr [edx + 4]
004f9164 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f916a 8b4148                   mov       eax, dword ptr [ecx + 0x48]
004f916d 8d0c90                   lea       ecx, [eax + edx*4]
004f9170 8b5704                   mov       edx, dword ptr [edi + 4]
004f9173 8b39                     mov       edi, dword ptr [ecx]
004f9175 8d0490                   lea       eax, [eax + edx*4]
004f9178 8bd0                     mov       edx, eax
004f917a 33d1                     xor       edx, ecx
004f917c 33d7                     xor       edx, edi
004f917e 8910                     mov       dword ptr [eax], edx
004f9180 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9186 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004f9189 83c228                   add       edx, 0x28
004f918c 8dbe461e0000             lea       edi, [esi + 0x1e46]
004f9192 3bfa                     cmp       edi, edx
004f9194 7434                     je        0x4f91ca
004f9196 8b4204                   mov       eax, dword ptr [edx + 4]
004f9199 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004f919c 8b5f04                   mov       ebx, dword ptr [edi + 4]
004f919f 8d0481                   lea       eax, [ecx + eax*4]
004f91a2 8d0c99                   lea       ecx, [ecx + ebx*4]
004f91a5 8b18                     mov       ebx, dword ptr [eax]
004f91a7 33d9                     xor       ebx, ecx
004f91a9 33d8                     xor       ebx, eax
004f91ab 8919                     mov       dword ptr [ecx], ebx
004f91ad 8b5204                   mov       edx, dword ptr [edx + 4]
004f91b0 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f91b6 8b4148                   mov       eax, dword ptr [ecx + 0x48]
004f91b9 8d0c90                   lea       ecx, [eax + edx*4]
004f91bc 8b5704                   mov       edx, dword ptr [edi + 4]
004f91bf 8d0490                   lea       eax, [eax + edx*4]
004f91c2 8b11                     mov       edx, dword ptr [ecx]
004f91c4 33d0                     xor       edx, eax
004f91c6 33d1                     xor       edx, ecx
004f91c8 8910                     mov       dword ptr [eax], edx
004f91ca 8b06                     mov       eax, dword ptr [esi]
004f91cc 8bce                     mov       ecx, esi
004f91ce ff90dc030000             call      dword ptr [eax + 0x3dc]
004f91d4 84c0                     test      al, al
004f91d6 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004f91d9 752f                     jne       0x4f920a
004f91db 8b13                     mov       edx, dword ptr [ebx]
004f91dd 8bcb                     mov       ecx, ebx
004f91df ff92a4020000             call      dword ptr [edx + 0x2a4]
004f91e5 85c0                     test      eax, eax
004f91e7 750a                     jne       0x4f91f3
004f91e9 8b03                     mov       eax, dword ptr [ebx]
004f91eb 8bcb                     mov       ecx, ebx
004f91ed ff90a0020000             call      dword ptr [eax + 0x2a0]
004f91f3 85c0                     test      eax, eax
004f91f5 8986841b0000             mov       dword ptr [esi + 0x1b84], eax
004f91fb 740d                     je        0x4f920a
004f91fd 8b10                     mov       edx, dword ptr [eax]
004f91ff 8bc8                     mov       ecx, eax
004f9201 ff5240                   call      dword ptr [edx + 0x40]
004f9204 8986ac240000             mov       dword ptr [esi + 0x24ac], eax
004f920a 8a86c11c0000             mov       al, byte ptr [esi + 0x1cc1]
004f9210 84c0                     test      al, al
004f9212 740a                     je        0x4f921e
004f9214 8b06                     mov       eax, dword ptr [esi]
004f9216 8bce                     mov       ecx, esi
004f9218 ff908c060000             call      dword ptr [eax + 0x68c]
004f921e 83be301a00000b           cmp       dword ptr [esi + 0x1a30], 0xb
004f9225 750c                     jne       0x4f9233
004f9227 8b16                     mov       edx, dword ptr [esi]
004f9229 6a04                     push      4
004f922b 8bce                     mov       ecx, esi
004f922d ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9233 8b03                     mov       eax, dword ptr [ebx]
004f9235 8bcb                     mov       ecx, ebx
004f9237 ff90a4020000             call      dword ptr [eax + 0x2a4]
004f923d 85c0                     test      eax, eax
004f923f 0f849c000000             je        0x4f92e1
004f9245 8b13                     mov       edx, dword ptr [ebx]
004f9247 8bcb                     mov       ecx, ebx
004f9249 ff92b8010000             call      dword ptr [edx + 0x1b8]
004f924f 84c0                     test      al, al
004f9251 0f858a000000             jne       0x4f92e1
004f9257 8b06                     mov       eax, dword ptr [esi]
004f9259 53                       push      ebx
004f925a 8bce                     mov       ecx, esi
004f925c ff9018060000             call      dword ptr [eax + 0x618]
004f9262 3c01                     cmp       al, 1
004f9264 7522                     jne       0x4f9288
004f9266 6a00                     push      0
004f9268 e8834e3b00               call      0x8ae0f0
004f926d 99                       cdq       
004f926e b964000000               mov       ecx, 0x64
004f9273 f7f9                     idiv      ecx
004f9275 83c404                   add       esp, 4
004f9278 83fa46                   cmp       edx, 0x46
004f927b 7d0b                     jge       0x4f9288
004f927d 8b16                     mov       edx, dword ptr [esi]
004f927f 53                       push      ebx
004f9280 8bce                     mov       ecx, esi
004f9282 ff92b0060000             call      dword ptr [edx + 0x6b0]
004f9288 8bce                     mov       ecx, esi
004f928a e8012efaff               call      0x49c090
004f928f 84c0                     test      al, al
004f9291 744e                     je        0x4f92e1
004f9293 6a00                     push      0
004f9295 e8564e3b00               call      0x8ae0f0
004f929a 99                       cdq       
004f929b b964000000               mov       ecx, 0x64
004f92a0 f7f9                     idiv      ecx
004f92a2 8b8614210000             mov       eax, dword ptr [esi + 0x2114]
004f92a8 83c404                   add       esp, 4
004f92ab 3bd0                     cmp       edx, eax
004f92ad 7d32                     jge       0x4f92e1
004f92af 8dbe1c210000             lea       edi, [esi + 0x211c]
004f92b5 8bcf                     mov       ecx, edi
004f92b7 e844dc6000               call      0xb06f00
004f92bc 3b8618210000             cmp       eax, dword ptr [esi + 0x2118]
004f92c2 7e1d                     jle       0x4f92e1
004f92c4 8b16                     mov       edx, dword ptr [esi]
004f92c6 53                       push      ebx
004f92c7 8bce                     mov       ecx, esi
004f92c9 ff9244060000             call      dword ptr [edx + 0x644]
004f92cf 8bcf                     mov       ecx, edi
004f92d1 e81abcf0ff               call      0x404ef0
004f92d6 6a00                     push      0
004f92d8 6a00                     push      0
004f92da 8bcf                     mov       ecx, edi
004f92dc e87fdc6000               call      0xb06f60
004f92e1 8b03                     mov       eax, dword ptr [ebx]
004f92e3 8bcb                     mov       ecx, ebx
004f92e5 ff909c010000             call      dword ptr [eax + 0x19c]
004f92eb 83b87801000002           cmp       dword ptr [eax + 0x178], 2
004f92f2 750a                     jne       0x4f92fe
004f92f4 6a00                     push      0
004f92f6 e8f54d3b00               call      0x8ae0f0
004f92fb 83c404                   add       esp, 4
004f92fe 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9304 e938fcffff               jmp       0x4f8f41
004f9309 33ff                     xor       edi, edi
004f930b eb03                     jmp       0x4f9310
004f930d 8d4900                   lea       ecx, [ecx]
004f9310 8b8608230000             mov       eax, dword ptr [esi + 0x2308]
004f9316 85c0                     test      eax, eax
004f9318 7441                     je        0x4f935b
004f931a 8b8e0c230000             mov       ecx, dword ptr [esi + 0x230c]
004f9320 2bc8                     sub       ecx, eax
004f9322 b8398ee338               mov       eax, 0x38e38e39
004f9327 f7e9                     imul      ecx
004f9329 c1fa03                   sar       edx, 3
004f932c 8bc2                     mov       eax, edx
004f932e c1e81f                   shr       eax, 0x1f
004f9331 03c2                     add       eax, edx
004f9333 3bf8                     cmp       edi, eax
004f9335 7324                     jae       0x4f935b
004f9337 8b9648230000             mov       edx, dword ptr [esi + 0x2348]
004f933d 8b4d10                   mov       ecx, dword ptr [ebp + 0x10]
004f9340 8d04ba                   lea       eax, [edx + edi*4]
004f9343 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004f9346 51                       push      ecx
004f9347 8b08                     mov       ecx, dword ptr [eax]
004f9349 52                       push      edx
004f934a 53                       push      ebx
004f934b e860492500               call      0x74dcb0
004f9350 85c0                     test      eax, eax
004f9352 0f84cffaffff             je        0x4f8e27
004f9358 47                       inc       edi
004f9359 ebb5                     jmp       0x4f9310
004f935b 6a00                     push      0
004f935d 6890010000               push      0x190
004f9362 8d8ea81a0000             lea       ecx, [esi + 0x1aa8]
004f9368 e8f3db6000               call      0xb06f60
004f936d 8a8608050000             mov       al, byte ptr [esi + 0x508]
004f9373 84c0                     test      al, al
004f9375 7511                     jne       0x4f9388
004f9377 8b86a41a0000             mov       eax, dword ptr [esi + 0x1aa4]
004f937d 8a483c                   mov       cl, byte ptr [eax + 0x3c]
004f9380 84c9                     test      cl, cl
004f9382 0f842c070000             je        0x4f9ab4
004f9388 6a0f                     push      0xf
004f938a 8bce                     mov       ecx, esi
004f938c e8dff5feff               call      0x4e8970
004f9391 84c0                     test      al, al
004f9393 750d                     jne       0x4f93a2
004f9395 6a02                     push      2
004f9397 8bce                     mov       ecx, esi
004f9399 e8d2f5feff               call      0x4e8970
004f939e 84c0                     test      al, al
004f93a0 7411                     je        0x4f93b3
004f93a2 8b8ea41a0000             mov       ecx, dword ptr [esi + 0x1aa4]
004f93a8 8a413c                   mov       al, byte ptr [ecx + 0x3c]
004f93ab 84c0                     test      al, al
004f93ad 0f8401070000             je        0x4f9ab4
004f93b3 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004f93b6 8b11                     mov       edx, dword ptr [ecx]
004f93b8 ff92b8010000             call      dword ptr [edx + 0x1b8]
004f93be 84c0                     test      al, al
004f93c0 0f84f0020000             je        0x4f96b6
004f93c6 8b8660240000             mov       eax, dword ptr [esi + 0x2460]
004f93cc 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004f93d2 8b9664240000             mov       edx, dword ptr [esi + 0x2464]
004f93d8 8d9e60240000             lea       ebx, [esi + 0x2460]
004f93de 33c1                     xor       eax, ecx
004f93e0 2bc3                     sub       eax, ebx
004f93e2 3bc2                     cmp       eax, edx
004f93e4 7414                     je        0x4f93fa
004f93e6 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f93ec 6a3f                     push      0x3f
004f93ee 53                       push      ebx
004f93ef e8bcdc6100               call      0xb170b0
004f93f4 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004f93fa 8b4304                   mov       eax, dword ptr [ebx + 4]
004f93fd 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004f9403 8b5244                   mov       edx, dword ptr [edx + 0x44]
004f9406 c1e002                   shl       eax, 2
004f9409 8b3c02                   mov       edi, dword ptr [edx + eax]
004f940c 03d0                     add       edx, eax
004f940e 33fa                     xor       edi, edx
004f9410 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004f9416 8b5248                   mov       edx, dword ptr [edx + 0x48]
004f9419 03c2                     add       eax, edx
004f941b 8b10                     mov       edx, dword ptr [eax]
004f941d 33d0                     xor       edx, eax
004f941f 33f9                     xor       edi, ecx
004f9421 33d1                     xor       edx, ecx
004f9423 3bfa                     cmp       edi, edx
004f9425 740e                     je        0x4f9435
004f9427 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f942d 6a40                     push      0x40
004f942f 53                       push      ebx
004f9430 e87bdc6100               call      0xb170b0
004f9435 8d8e28240000             lea       ecx, [esi + 0x2428]
004f943b e8c0da6000               call      0xb06f00
004f9440 3bc7                     cmp       eax, edi
004f9442 7d7d                     jge       0x4f94c1
004f9444 8b8640240000             mov       eax, dword ptr [esi + 0x2440]
004f944a 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004f9450 8b8e44240000             mov       ecx, dword ptr [esi + 0x2444]
004f9456 8dbe40240000             lea       edi, [esi + 0x2440]
004f945c 33c2                     xor       eax, edx
004f945e 2bc7                     sub       eax, edi
004f9460 3bc1                     cmp       eax, ecx
004f9462 7414                     je        0x4f9478
004f9464 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f946a 6a3f                     push      0x3f
004f946c 57                       push      edi
004f946d e83edc6100               call      0xb170b0
004f9472 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004f9478 8b4704                   mov       eax, dword ptr [edi + 4]
004f947b 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9481 8b7944                   mov       edi, dword ptr [ecx + 0x44]
004f9484 c1e002                   shl       eax, 2
004f9487 8d1c07                   lea       ebx, [edi + eax]
004f948a 8b3b                     mov       edi, dword ptr [ebx]
004f948c 33fb                     xor       edi, ebx
004f948e 8b5948                   mov       ebx, dword ptr [ecx + 0x48]
004f9491 03c3                     add       eax, ebx
004f9493 8b18                     mov       ebx, dword ptr [eax]
004f9495 33d8                     xor       ebx, eax
004f9497 33fa                     xor       edi, edx
004f9499 33da                     xor       ebx, edx
004f949b 3bfb                     cmp       edi, ebx
004f949d 741a                     je        0x4f94b9
004f949f 6a40                     push      0x40
004f94a1 8d8640240000             lea       eax, [esi + 0x2440]
004f94a7 50                       push      eax
004f94a8 e803dc6100               call      0xb170b0
004f94ad 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004f94b3 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f94b9 85ff                     test      edi, edi
004f94bb 0f8501020000             jne       0x4f96c2
004f94c1 8b8e18240000             mov       ecx, dword ptr [esi + 0x2418]
004f94c7 85c9                     test      ecx, ecx
004f94c9 0f84e5050000             je        0x4f9ab4
004f94cf 8b861c240000             mov       eax, dword ptr [esi + 0x241c]
004f94d5 2bc1                     sub       eax, ecx
004f94d7 c1f802                   sar       eax, 2
004f94da 85c0                     test      eax, eax
004f94dc 0f84d2050000             je        0x4f9ab4
004f94e2 8bc1                     mov       eax, ecx
004f94e4 833800                   cmp       dword ptr [eax], 0
004f94e7 0f84c7050000             je        0x4f9ab4
004f94ed 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004f94f3 85c0                     test      eax, eax
004f94f5 750e                     jne       0x4f9505
004f94f7 8b8648010000             mov       eax, dword ptr [esi + 0x148]
004f94fd 85c0                     test      eax, eax
004f94ff 0f84af050000             je        0x4f9ab4
004f9505 8b16                     mov       edx, dword ptr [esi]
004f9507 8bce                     mov       ecx, esi
004f9509 ff92dc030000             call      dword ptr [edx + 0x3dc]
004f950f 84c0                     test      al, al
004f9511 0f859d050000             jne       0x4f9ab4
004f9517 8b06                     mov       eax, dword ptr [esi]
004f9519 8bce                     mov       ecx, esi
004f951b ff9078030000             call      dword ptr [eax + 0x378]
004f9521 398604010000             cmp       dword ptr [esi + 0x104], eax
004f9527 7516                     jne       0x4f953f
004f9529 8b16                     mov       edx, dword ptr [esi]
004f952b 8bce                     mov       ecx, esi
004f952d ff92a0030000             call      dword ptr [edx + 0x3a0]
004f9533 398648010000             cmp       dword ptr [esi + 0x148], eax
004f9539 0f8475050000             je        0x4f9ab4
004f953f 8b06                     mov       eax, dword ptr [esi]
004f9541 8bce                     mov       ecx, esi
004f9543 ff907c030000             call      dword ptr [eax + 0x37c]
004f9549 398604010000             cmp       dword ptr [esi + 0x104], eax
004f954f 7516                     jne       0x4f9567
004f9551 8b16                     mov       edx, dword ptr [esi]
004f9553 8bce                     mov       ecx, esi
004f9555 ff92a4030000             call      dword ptr [edx + 0x3a4]
004f955b 398648010000             cmp       dword ptr [esi + 0x148], eax
004f9561 0f844d050000             je        0x4f9ab4
004f9567 6a0e                     push      0xe
004f9569 8bce                     mov       ecx, esi
004f956b e800f4feff               call      0x4e8970
004f9570 84c0                     test      al, al
004f9572 0f853c050000             jne       0x4f9ab4
004f9578 6a01                     push      1
004f957a 8bce                     mov       ecx, esi
004f957c e8eff3feff               call      0x4e8970
004f9581 84c0                     test      al, al
004f9583 0f852b050000             jne       0x4f9ab4
004f9589 8b86a41a0000             mov       eax, dword ptr [esi + 0x1aa4]
004f958f 8a483c                   mov       cl, byte ptr [eax + 0x3c]
004f9592 84c9                     test      cl, cl
004f9594 0f851a050000             jne       0x4f9ab4
004f959a 8d8e40240000             lea       ecx, [esi + 0x2440]
004f95a0 e8bb8af0ff               call      0x402060
004f95a5 85c0                     test      eax, eax
004f95a7 757b                     jne       0x4f9624
004f95a9 50                       push      eax
004f95aa 6890010000               push      0x190
004f95af 8d8e28240000             lea       ecx, [esi + 0x2428]
004f95b5 e8a6d96000               call      0xb06f60
004f95ba 8b1e                     mov       ebx, dword ptr [esi]
004f95bc 8bbe18240000             mov       edi, dword ptr [esi + 0x2418]
004f95c2 6a01                     push      1
004f95c4 6a00                     push      0
004f95c6 6a00                     push      0
004f95c8 6a01                     push      1
004f95ca 6a00                     push      0
004f95cc 6a00                     push      0
004f95ce 8bd3                     mov       edx, ebx
004f95d0 8bce                     mov       ecx, esi
004f95d2 ff92e4000000             call      dword ptr [edx + 0xe4]
004f95d8 99                       cdq       
004f95d9 83e207                   and       edx, 7
004f95dc 03c2                     add       eax, edx
004f95de c1f803                   sar       eax, 3
004f95e1 50                       push      eax
004f95e2 8b07                     mov       eax, dword ptr [edi]
004f95e4 6a00                     push      0
004f95e6 50                       push      eax
004f95e7 6a01                     push      1
004f95e9 8bce                     mov       ecx, esi
004f95eb ff93f8000000             call      dword ptr [ebx + 0xf8]
004f95f1 8b16                     mov       edx, dword ptr [esi]
004f95f3 8bce                     mov       ecx, esi
004f95f5 ff92e4000000             call      dword ptr [edx + 0xe4]
004f95fb 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f95fe db45f0                   fild      dword ptr [ebp - 0x10]
004f9601 b904340001               mov       ecx, 0x1003404
004f9606 d95df0                   fstp      dword ptr [ebp - 0x10]
004f9609 e8a29df3ff               call      0x4333b0
004f960e d87df0                   fdivr     dword ptr [ebp - 0x10]
004f9611 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f9617 d95df0                   fstp      dword ptr [ebp - 0x10]
004f961a 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004f961d 51                       push      ecx
004f961e 51                       push      ecx
004f961f e989040000               jmp       0x4f9aad
004f9624 8dbe28240000             lea       edi, [esi + 0x2428]
004f962a 8bcf                     mov       ecx, edi
004f962c e8bfb8f0ff               call      0x404ef0
004f9631 6a00                     push      0
004f9633 6890010000               push      0x190
004f9638 8bcf                     mov       ecx, edi
004f963a e821d96000               call      0xb06f60
004f963f 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f9645 8b08                     mov       ecx, dword ptr [eax]
004f9647 e814dd5200               call      0xa27360
004f964c 8b1e                     mov       ebx, dword ptr [esi]
004f964e 8bbe18240000             mov       edi, dword ptr [esi + 0x2418]
004f9654 6a01                     push      1
004f9656 6a00                     push      0
004f9658 6a00                     push      0
004f965a 6a01                     push      1
004f965c 6a00                     push      0
004f965e 6a00                     push      0
004f9660 8bc3                     mov       eax, ebx
004f9662 8bce                     mov       ecx, esi
004f9664 ff90e4000000             call      dword ptr [eax + 0xe4]
004f966a 8b0f                     mov       ecx, dword ptr [edi]
004f966c 99                       cdq       
004f966d 83e207                   and       edx, 7
004f9670 03c2                     add       eax, edx
004f9672 c1f803                   sar       eax, 3
004f9675 50                       push      eax
004f9676 6a00                     push      0
004f9678 51                       push      ecx
004f9679 6a01                     push      1
004f967b 8bce                     mov       ecx, esi
004f967d ff93f8000000             call      dword ptr [ebx + 0xf8]
004f9683 8b16                     mov       edx, dword ptr [esi]
004f9685 8bce                     mov       ecx, esi
004f9687 ff92e4000000             call      dword ptr [edx + 0xe4]
004f968d 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f9690 db45f0                   fild      dword ptr [ebp - 0x10]
004f9693 b904340001               mov       ecx, 0x1003404
004f9698 d95df0                   fstp      dword ptr [ebp - 0x10]
004f969b e8109df3ff               call      0x4333b0
004f96a0 d87df0                   fdivr     dword ptr [ebp - 0x10]
004f96a3 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f96a9 d95df0                   fstp      dword ptr [ebp - 0x10]
004f96ac 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004f96af 51                       push      ecx
004f96b0 51                       push      ecx
004f96b1 e9f7030000               jmp       0x4f9aad
004f96b6 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004f96bc 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f96c2 8b86a0240000             mov       eax, dword ptr [esi + 0x24a0]
004f96c8 8b9ea4240000             mov       ebx, dword ptr [esi + 0x24a4]
004f96ce 8dbea0240000             lea       edi, [esi + 0x24a0]
004f96d4 33c2                     xor       eax, edx
004f96d6 2bc7                     sub       eax, edi
004f96d8 3bc3                     cmp       eax, ebx
004f96da 7414                     je        0x4f96f0
004f96dc 6a3f                     push      0x3f
004f96de 57                       push      edi
004f96df e8ccd96100               call      0xb170b0
004f96e4 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004f96ea 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f96f0 8b4704                   mov       eax, dword ptr [edi + 4]
004f96f3 8b7944                   mov       edi, dword ptr [ecx + 0x44]
004f96f6 c1e002                   shl       eax, 2
004f96f9 8d1c07                   lea       ebx, [edi + eax]
004f96fc 8b3b                     mov       edi, dword ptr [ebx]
004f96fe 33fb                     xor       edi, ebx
004f9700 8b5948                   mov       ebx, dword ptr [ecx + 0x48]
004f9703 03c3                     add       eax, ebx
004f9705 8b18                     mov       ebx, dword ptr [eax]
004f9707 33d8                     xor       ebx, eax
004f9709 33fa                     xor       edi, edx
004f970b 33da                     xor       ebx, edx
004f970d 3bfb                     cmp       edi, ebx
004f970f 740e                     je        0x4f971f
004f9711 6a40                     push      0x40
004f9713 8d86a0240000             lea       eax, [esi + 0x24a0]
004f9719 50                       push      eax
004f971a e891d96100               call      0xb170b0
004f971f 8d8e68240000             lea       ecx, [esi + 0x2468]
004f9725 e8d6d76000               call      0xb06f00
004f972a 3bc7                     cmp       eax, edi
004f972c 7d6d                     jge       0x4f979b
004f972e 8b8e80240000             mov       ecx, dword ptr [esi + 0x2480]
004f9734 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004f973a 8b8684240000             mov       eax, dword ptr [esi + 0x2484]
004f9740 8d9e80240000             lea       ebx, [esi + 0x2480]
004f9746 33cf                     xor       ecx, edi
004f9748 2bcb                     sub       ecx, ebx
004f974a 3bc8                     cmp       ecx, eax
004f974c 740e                     je        0x4f975c
004f974e 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9754 6a3f                     push      0x3f
004f9756 53                       push      ebx
004f9757 e854d96100               call      0xb170b0
004f975c 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9762 8b4304                   mov       eax, dword ptr [ebx + 4]
004f9765 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004f9768 c1e002                   shl       eax, 2
004f976b 8b3c02                   mov       edi, dword ptr [edx + eax]
004f976e 03d0                     add       edx, eax
004f9770 33fa                     xor       edi, edx
004f9772 333ddc012101             xor       edi, dword ptr [0x12101dc]
004f9778 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004f977b 03c2                     add       eax, edx
004f977d 8b10                     mov       edx, dword ptr [eax]
004f977f 33d0                     xor       edx, eax
004f9781 3315dc012101             xor       edx, dword ptr [0x12101dc]
004f9787 3bfa                     cmp       edi, edx
004f9789 7408                     je        0x4f9793
004f978b 6a40                     push      0x40
004f978d 53                       push      ebx
004f978e e81dd96100               call      0xb170b0
004f9793 85ff                     test      edi, edi
004f9795 0f8519030000             jne       0x4f9ab4
004f979b 8b8e18240000             mov       ecx, dword ptr [esi + 0x2418]
004f97a1 85c9                     test      ecx, ecx
004f97a3 0f840b030000             je        0x4f9ab4
004f97a9 8b861c240000             mov       eax, dword ptr [esi + 0x241c]
004f97af 2bc1                     sub       eax, ecx
004f97b1 c1f802                   sar       eax, 2
004f97b4 85c0                     test      eax, eax
004f97b6 0f84f8020000             je        0x4f9ab4
004f97bc 8bc1                     mov       eax, ecx
004f97be 833800                   cmp       dword ptr [eax], 0
004f97c1 0f84ed020000             je        0x4f9ab4
004f97c7 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004f97cd 85c0                     test      eax, eax
004f97cf 750e                     jne       0x4f97df
004f97d1 8b8648010000             mov       eax, dword ptr [esi + 0x148]
004f97d7 85c0                     test      eax, eax
004f97d9 0f84d5020000             je        0x4f9ab4
004f97df 8b06                     mov       eax, dword ptr [esi]
004f97e1 8bce                     mov       ecx, esi
004f97e3 ff90dc030000             call      dword ptr [eax + 0x3dc]
004f97e9 84c0                     test      al, al
004f97eb 0f85c3020000             jne       0x4f9ab4
004f97f1 8b16                     mov       edx, dword ptr [esi]
004f97f3 8bce                     mov       ecx, esi
004f97f5 ff9278030000             call      dword ptr [edx + 0x378]
004f97fb 398604010000             cmp       dword ptr [esi + 0x104], eax
004f9801 7516                     jne       0x4f9819
004f9803 8b06                     mov       eax, dword ptr [esi]
004f9805 8bce                     mov       ecx, esi
004f9807 ff90a0030000             call      dword ptr [eax + 0x3a0]
004f980d 398648010000             cmp       dword ptr [esi + 0x148], eax
004f9813 0f849b020000             je        0x4f9ab4
004f9819 8b16                     mov       edx, dword ptr [esi]
004f981b 8bce                     mov       ecx, esi
004f981d ff927c030000             call      dword ptr [edx + 0x37c]
004f9823 398604010000             cmp       dword ptr [esi + 0x104], eax
004f9829 7516                     jne       0x4f9841
004f982b 8b06                     mov       eax, dword ptr [esi]
004f982d 8bce                     mov       ecx, esi
004f982f ff90a4030000             call      dword ptr [eax + 0x3a4]
004f9835 398648010000             cmp       dword ptr [esi + 0x148], eax
004f983b 0f8473020000             je        0x4f9ab4
004f9841 8b8e80240000             mov       ecx, dword ptr [esi + 0x2480]
004f9847 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004f984d 8b8684240000             mov       eax, dword ptr [esi + 0x2484]
004f9853 8d9e80240000             lea       ebx, [esi + 0x2480]
004f9859 33cf                     xor       ecx, edi
004f985b 2bcb                     sub       ecx, ebx
004f985d 3bc8                     cmp       ecx, eax
004f985f 740e                     je        0x4f986f
004f9861 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9867 6a3f                     push      0x3f
004f9869 53                       push      ebx
004f986a e841d86100               call      0xb170b0
004f986f 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004f9875 8b4304                   mov       eax, dword ptr [ebx + 4]
004f9878 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004f987b c1e002                   shl       eax, 2
004f987e 03d0                     add       edx, eax
004f9880 8bfa                     mov       edi, edx
004f9882 333ddc012101             xor       edi, dword ptr [0x12101dc]
004f9888 333a                     xor       edi, dword ptr [edx]
004f988a 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004f988d 03c2                     add       eax, edx
004f988f 8b10                     mov       edx, dword ptr [eax]
004f9891 33d0                     xor       edx, eax
004f9893 3315dc012101             xor       edx, dword ptr [0x12101dc]
004f9899 3bfa                     cmp       edi, edx
004f989b 7408                     je        0x4f98a5
004f989d 6a40                     push      0x40
004f989f 53                       push      ebx
004f98a0 e80bd86100               call      0xb170b0
004f98a5 85ff                     test      edi, edi
004f98a7 7508                     jne       0x4f98b1
004f98a9 8d8e68240000             lea       ecx, [esi + 0x2468]
004f98af eb0f                     jmp       0x4f98c0
004f98b1 8dbe68240000             lea       edi, [esi + 0x2468]
004f98b7 8bcf                     mov       ecx, edi
004f98b9 e832b6f0ff               call      0x404ef0
004f98be 8bcf                     mov       ecx, edi
004f98c0 6a00                     push      0
004f98c2 68c8000000               push      0xc8
004f98c7 e894d66000               call      0xb06f60
004f98cc ff15d8f04001             call      dword ptr [0x140f0d8]
004f98d2 33d2                     xor       edx, edx
004f98d4 b907000000               mov       ecx, 7
004f98d9 f7f1                     div       ecx
004f98db 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004f98de 8b3e                     mov       edi, dword ptr [esi]
004f98e0 8955f0                   mov       dword ptr [ebp - 0x10], edx
004f98e3 8b11                     mov       edx, dword ptr [ecx]
004f98e5 ff9294000000             call      dword ptr [edx + 0x94]
004f98eb 50                       push      eax
004f98ec 8bce                     mov       ecx, esi
004f98ee ff97d4000000             call      dword ptr [edi + 0xd4]
004f98f4 84c0                     test      al, al
004f98f6 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f98fc 0f84d7000000             je        0x4f99d9
004f9902 8b4804                   mov       ecx, dword ptr [eax + 4]
004f9905 83c004                   add       eax, 4
004f9908 e853da5200               call      0xa27360
004f990d 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f9913 8b4808                   mov       ecx, dword ptr [eax + 8]
004f9916 83c008                   add       eax, 8
004f9919 e842da5200               call      0xa27360
004f991e 8b1e                     mov       ebx, dword ptr [esi]
004f9920 8bbe18240000             mov       edi, dword ptr [esi + 0x2418]
004f9926 6a01                     push      1
004f9928 6a00                     push      0
004f992a 6a00                     push      0
004f992c 6a01                     push      1
004f992e 6a00                     push      0
004f9930 6a00                     push      0
004f9932 8bc3                     mov       eax, ebx
004f9934 8bce                     mov       ecx, esi
004f9936 83c704                   add       edi, 4
004f9939 ff90e4000000             call      dword ptr [eax + 0xe4]
004f993f 8b0f                     mov       ecx, dword ptr [edi]
004f9941 99                       cdq       
004f9942 83e207                   and       edx, 7
004f9945 03c2                     add       eax, edx
004f9947 c1f803                   sar       eax, 3
004f994a 50                       push      eax
004f994b 6a00                     push      0
004f994d 51                       push      ecx
004f994e 6a01                     push      1
004f9950 8bce                     mov       ecx, esi
004f9952 ff93f8000000             call      dword ptr [ebx + 0xf8]
004f9958 8b1e                     mov       ebx, dword ptr [esi]
004f995a 8bbe18240000             mov       edi, dword ptr [esi + 0x2418]
004f9960 6a01                     push      1
004f9962 6a00                     push      0
004f9964 6a00                     push      0
004f9966 6a01                     push      1
004f9968 6a00                     push      0
004f996a 6a00                     push      0
004f996c 8bd3                     mov       edx, ebx
004f996e 8bce                     mov       ecx, esi
004f9970 83c708                   add       edi, 8
004f9973 ff92e4000000             call      dword ptr [edx + 0xe4]
004f9979 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004f997c 83c105                   add       ecx, 5
004f997f 99                       cdq       
004f9980 f7f9                     idiv      ecx
004f9982 8b17                     mov       edx, dword ptr [edi]
004f9984 8bce                     mov       ecx, esi
004f9986 50                       push      eax
004f9987 6a00                     push      0
004f9989 52                       push      edx
004f998a 6a02                     push      2
004f998c ff93f8000000             call      dword ptr [ebx + 0xf8]
004f9992 8b06                     mov       eax, dword ptr [esi]
004f9994 8bce                     mov       ecx, esi
004f9996 ff90e4000000             call      dword ptr [eax + 0xe4]
004f999c 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f999f db45f0                   fild      dword ptr [ebp - 0x10]
004f99a2 b904340001               mov       ecx, 0x1003404
004f99a7 d95df0                   fstp      dword ptr [ebp - 0x10]
004f99aa e8019af3ff               call      0x4333b0
004f99af d87df0                   fdivr     dword ptr [ebp - 0x10]
004f99b2 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f99b8 8b4804                   mov       ecx, dword ptr [eax + 4]
004f99bb 83c004                   add       eax, 4
004f99be d95df0                   fstp      dword ptr [ebp - 0x10]
004f99c1 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
004f99c4 57                       push      edi
004f99c5 57                       push      edi
004f99c6 e835bf5200               call      0xa25900
004f99cb 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f99d1 83c008                   add       eax, 8
004f99d4 e9d2000000               jmp       0x4f9aab
004f99d9 8b480c                   mov       ecx, dword ptr [eax + 0xc]
004f99dc 83c00c                   add       eax, 0xc
004f99df e87cd95200               call      0xa27360
004f99e4 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f99ea 8b4810                   mov       ecx, dword ptr [eax + 0x10]
004f99ed 83c010                   add       eax, 0x10
004f99f0 e86bd95200               call      0xa27360
004f99f5 8b1e                     mov       ebx, dword ptr [esi]
004f99f7 8bbe18240000             mov       edi, dword ptr [esi + 0x2418]
004f99fd 6a01                     push      1
004f99ff 6a00                     push      0
004f9a01 6a00                     push      0
004f9a03 6a01                     push      1
004f9a05 6a00                     push      0
004f9a07 6a00                     push      0
004f9a09 8bd3                     mov       edx, ebx
004f9a0b 8bce                     mov       ecx, esi
004f9a0d 83c70c                   add       edi, 0xc
004f9a10 ff92e4000000             call      dword ptr [edx + 0xe4]
004f9a16 99                       cdq       
004f9a17 83e207                   and       edx, 7
004f9a1a 03c2                     add       eax, edx
004f9a1c c1f803                   sar       eax, 3
004f9a1f 50                       push      eax
004f9a20 8b07                     mov       eax, dword ptr [edi]
004f9a22 6a00                     push      0
004f9a24 50                       push      eax
004f9a25 6a01                     push      1
004f9a27 8bce                     mov       ecx, esi
004f9a29 ff93f8000000             call      dword ptr [ebx + 0xf8]
004f9a2f 8b1e                     mov       ebx, dword ptr [esi]
004f9a31 8bbe18240000             mov       edi, dword ptr [esi + 0x2418]
004f9a37 6a01                     push      1
004f9a39 6a00                     push      0
004f9a3b 6a00                     push      0
004f9a3d 6a01                     push      1
004f9a3f 6a00                     push      0
004f9a41 6a00                     push      0
004f9a43 8bd3                     mov       edx, ebx
004f9a45 8bce                     mov       ecx, esi
004f9a47 83c710                   add       edi, 0x10
004f9a4a ff92e4000000             call      dword ptr [edx + 0xe4]
004f9a50 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004f9a53 83c105                   add       ecx, 5
004f9a56 99                       cdq       
004f9a57 f7f9                     idiv      ecx
004f9a59 8b17                     mov       edx, dword ptr [edi]
004f9a5b 8bce                     mov       ecx, esi
004f9a5d 50                       push      eax
004f9a5e 6a00                     push      0
004f9a60 52                       push      edx
004f9a61 6a02                     push      2
004f9a63 ff93f8000000             call      dword ptr [ebx + 0xf8]
004f9a69 8b06                     mov       eax, dword ptr [esi]
004f9a6b 8bce                     mov       ecx, esi
004f9a6d ff90e4000000             call      dword ptr [eax + 0xe4]
004f9a73 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f9a76 db45f0                   fild      dword ptr [ebp - 0x10]
004f9a79 b904340001               mov       ecx, 0x1003404
004f9a7e d95df0                   fstp      dword ptr [ebp - 0x10]
004f9a81 e82a99f3ff               call      0x4333b0
004f9a86 d87df0                   fdivr     dword ptr [ebp - 0x10]
004f9a89 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f9a8f 8b480c                   mov       ecx, dword ptr [eax + 0xc]
004f9a92 83c00c                   add       eax, 0xc
004f9a95 d95df0                   fstp      dword ptr [ebp - 0x10]
004f9a98 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
004f9a9b 57                       push      edi
004f9a9c 57                       push      edi
004f9a9d e85ebe5200               call      0xa25900
004f9aa2 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004f9aa8 83c010                   add       eax, 0x10
004f9aab 57                       push      edi
004f9aac 57                       push      edi
004f9aad 8b08                     mov       ecx, dword ptr [eax]
004f9aaf e84cbe5200               call      0xa25900
004f9ab4 8b4d10                   mov       ecx, dword ptr [ebp + 0x10]
004f9ab7 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004f9aba 8b4508                   mov       eax, dword ptr [ebp + 8]
004f9abd 51                       push      ecx
004f9abe 52                       push      edx
004f9abf 50                       push      eax
004f9ac0 8bce                     mov       ecx, esi
004f9ac2 e8098efbff               call      0x4b28d0
004f9ac7 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004f9aca 5f                       pop       edi
004f9acb 5e                       pop       esi
004f9acc 5b                       pop       ebx
004f9acd 64890d00000000           mov       dword ptr fs:[0], ecx
004f9ad4 8be5                     mov       esp, ebp
004f9ad6 5d                       pop       ebp
004f9ad7 c20c00                   ret       0xc
004f9ada cc                       int3      
004f9adb cc                       int3      
004f9adc cc                       int3      
004f9add cc                       int3      
004f9ade cc                       int3      
004f9adf cc                       int3      
004f9ae0 55                       push      ebp
004f9ae1 8bec                     mov       ebp, esp
004f9ae3 6aff                     push      -1
004f9ae5 682c9cc500               push      0xc59c2c
004f9aea 64a100000000             mov       eax, dword ptr fs:[0]
004f9af0 50                       push      eax
004f9af1 64892500000000           mov       dword ptr fs:[0], esp
004f9af8 83ec18                   sub       esp, 0x18
004f9afb 53                       push      ebx
004f9afc 56                       push      esi
004f9afd 8bf1                     mov       esi, ecx
004f9aff e88c25faff               call      0x49c090
004f9b04 33db                     xor       ebx, ebx
004f9b06 84c0                     test      al, al
004f9b08 747a                     je        0x4f9b84
004f9b0a 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9b10 7572                     jne       0x4f9b84
004f9b12 8b06                     mov       eax, dword ptr [esi]
004f9b14 8bce                     mov       ecx, esi
004f9b16 ff9030020000             call      dword ptr [eax + 0x230]
004f9b1c 85c0                     test      eax, eax
004f9b1e 7564                     jne       0x4f9b84
004f9b20 8b86301a0000             mov       eax, dword ptr [esi + 0x1a30]
004f9b26 83f818                   cmp       eax, 0x18
004f9b29 7459                     je        0x4f9b84
004f9b2b 399e7c1b0000             cmp       dword ptr [esi + 0x1b7c], ebx
004f9b31 7451                     je        0x4f9b84
004f9b33 8d8ea81c0000             lea       ecx, [esi + 0x1ca8]
004f9b39 e82285f0ff               call      0x402060
004f9b3e 8b16                     mov       edx, dword ptr [esi]
004f9b40 8945ec                   mov       dword ptr [ebp - 0x14], eax
004f9b43 8b867c1b0000             mov       eax, dword ptr [esi + 0x1b7c]
004f9b49 53                       push      ebx
004f9b4a 50                       push      eax
004f9b4b 8bce                     mov       ecx, esi
004f9b4d ff5208                   call      dword ptr [edx + 8]
004f9b50 8945f0                   mov       dword ptr [ebp - 0x10], eax
004f9b53 db45f0                   fild      dword ptr [ebp - 0x10]
004f9b56 db45ec                   fild      dword ptr [ebp - 0x14]
004f9b59 d80dd04bcd00             fmul      dword ptr [0xcd4bd0]
004f9b5f ded9                     fcompp    
004f9b61 dfe0                     fnstsw    ax
004f9b63 f6c405                   test      ah, 5
004f9b66 7a1c                     jp        0x4f9b84
004f9b68 8b16                     mov       edx, dword ptr [esi]
004f9b6a 6a18                     push      0x18
004f9b6c 8bce                     mov       ecx, esi
004f9b6e ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9b74 5e                       pop       esi
004f9b75 5b                       pop       ebx
004f9b76 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004f9b79 64890d00000000           mov       dword ptr fs:[0], ecx
004f9b80 8be5                     mov       esp, ebp
004f9b82 5d                       pop       ebp
004f9b83 c3                       ret       
004f9b84 8b86301a0000             mov       eax, dword ptr [esi + 0x1a30]
004f9b8a 48                       dec       eax
004f9b8b 83f81c                   cmp       eax, 0x1c
004f9b8e 57                       push      edi
004f9b8f 0f870b030000             ja        0x4f9ea0
004f9b95 0fb680949f4f00           movzx     eax, byte ptr [eax + 0x4f9f94]
004f9b9c ff2485649f4f00           jmp       dword ptr [eax*4 + 0x4f9f64]
004f9ba3 8bbe801b0000             mov       edi, dword ptr [esi + 0x1b80]
004f9ba9 3bfb                     cmp       edi, ebx
004f9bab 745d                     je        0x4f9c0a
004f9bad 8b16                     mov       edx, dword ptr [esi]
004f9baf 57                       push      edi
004f9bb0 8bce                     mov       ecx, esi
004f9bb2 ff9244040000             call      dword ptr [edx + 0x444]
004f9bb8 84c0                     test      al, al
004f9bba 0f84e0020000             je        0x4f9ea0
004f9bc0 6a0b                     push      0xb
004f9bc2 8bce                     mov       ecx, esi
004f9bc4 e837e4f6ff               call      0x468000
004f9bc9 84c0                     test      al, al
004f9bcb 7425                     je        0x4f9bf2
004f9bcd 8b07                     mov       eax, dword ptr [edi]
004f9bcf 8bcf                     mov       ecx, edi
004f9bd1 ff9094000000             call      dword ptr [eax + 0x94]
004f9bd7 8986bc1d0000             mov       dword ptr [esi + 0x1dbc], eax
004f9bdd 8b17                     mov       edx, dword ptr [edi]
004f9bdf 8bcf                     mov       ecx, edi
004f9be1 ff9298000000             call      dword ptr [edx + 0x98]
004f9be7 8986b81d0000             mov       dword ptr [esi + 0x1db8], eax
004f9bed e9ae020000               jmp       0x4f9ea0
004f9bf2 6a0c                     push      0xc
004f9bf4 8bce                     mov       ecx, esi
004f9bf6 e805e4f6ff               call      0x468000
004f9bfb 84c0                     test      al, al
004f9bfd 0f849d020000             je        0x4f9ea0
004f9c03 6a01                     push      1
004f9c05 e98c020000               jmp       0x4f9e96
004f9c0a 8d8e741d0000             lea       ecx, [esi + 0x1d74]
004f9c10 e8ebd26000               call      0xb06f00
004f9c15 2b86d81d0000             sub       eax, dword ptr [esi + 0x1dd8]
004f9c1b 3d88130000               cmp       eax, 0x1388
004f9c20 e9da010000               jmp       0x4f9dff
004f9c25 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9c2b 8bce                     mov       ecx, esi
004f9c2d 7507                     jne       0x4f9c36
004f9c2f 6a0d                     push      0xd
004f9c31 e962020000               jmp       0x4f9e98
004f9c36 8b16                     mov       edx, dword ptr [esi]
004f9c38 ff92dc000000             call      dword ptr [edx + 0xdc]
004f9c3e 85c0                     test      eax, eax
004f9c40 7512                     jne       0x4f9c54
004f9c42 8b06                     mov       eax, dword ptr [esi]
004f9c44 8bce                     mov       ecx, esi
004f9c46 ff9094000000             call      dword ptr [eax + 0x94]
004f9c4c 3b86bc1d0000             cmp       eax, dword ptr [esi + 0x1dbc]
004f9c52 7e29                     jle       0x4f9c7d
004f9c54 8b16                     mov       edx, dword ptr [esi]
004f9c56 8bce                     mov       ecx, esi
004f9c58 ff92dc000000             call      dword ptr [edx + 0xdc]
004f9c5e 83f801                   cmp       eax, 1
004f9c61 0f8539020000             jne       0x4f9ea0
004f9c67 8b06                     mov       eax, dword ptr [esi]
004f9c69 8bce                     mov       ecx, esi
004f9c6b ff9094000000             call      dword ptr [eax + 0x94]
004f9c71 3b86bc1d0000             cmp       eax, dword ptr [esi + 0x1dbc]
004f9c77 0f8c23020000             jl        0x4f9ea0
004f9c7d 6a0b                     push      0xb
004f9c7f 8bce                     mov       ecx, esi
004f9c81 e87ae3f6ff               call      0x468000
004f9c86 84c0                     test      al, al
004f9c88 8bce                     mov       ecx, esi
004f9c8a 740f                     je        0x4f9c9b
004f9c8c 8b16                     mov       edx, dword ptr [esi]
004f9c8e 6a09                     push      9
004f9c90 ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9c96 e905020000               jmp       0x4f9ea0
004f9c9b 6a0c                     push      0xc
004f9c9d e85ee3f6ff               call      0x468000
004f9ca2 84c0                     test      al, al
004f9ca4 0f84f6010000             je        0x4f9ea0
004f9caa 6a0a                     push      0xa
004f9cac e9e5010000               jmp       0x4f9e96
004f9cb1 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9cb7 8bce                     mov       ecx, esi
004f9cb9 750f                     jne       0x4f9cca
004f9cbb 8b16                     mov       edx, dword ptr [esi]
004f9cbd 6a01                     push      1
004f9cbf ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9cc5 e9d6010000               jmp       0x4f9ea0
004f9cca 8b06                     mov       eax, dword ptr [esi]
004f9ccc ff90e0000000             call      dword ptr [eax + 0xe0]
004f9cd2 83f802                   cmp       eax, 2
004f9cd5 7512                     jne       0x4f9ce9
004f9cd7 8b16                     mov       edx, dword ptr [esi]
004f9cd9 8bce                     mov       ecx, esi
004f9cdb ff9298000000             call      dword ptr [edx + 0x98]
004f9ce1 3b86b81d0000             cmp       eax, dword ptr [esi + 0x1db8]
004f9ce7 7e29                     jle       0x4f9d12
004f9ce9 8b06                     mov       eax, dword ptr [esi]
004f9ceb 8bce                     mov       ecx, esi
004f9ced ff90e0000000             call      dword ptr [eax + 0xe0]
004f9cf3 83f803                   cmp       eax, 3
004f9cf6 0f85a4010000             jne       0x4f9ea0
004f9cfc 8b16                     mov       edx, dword ptr [esi]
004f9cfe 8bce                     mov       ecx, esi
004f9d00 ff9298000000             call      dword ptr [edx + 0x98]
004f9d06 3b86b81d0000             cmp       eax, dword ptr [esi + 0x1db8]
004f9d0c 0f8c8e010000             jl        0x4f9ea0
004f9d12 895de0                   mov       dword ptr [ebp - 0x20], ebx
004f9d15 895de4                   mov       dword ptr [ebp - 0x1c], ebx
004f9d18 895de8                   mov       dword ptr [ebp - 0x18], ebx
004f9d1b 8d45ec                   lea       eax, [ebp - 0x14]
004f9d1e 50                       push      eax
004f9d1f 8d4ddc                   lea       ecx, [ebp - 0x24]
004f9d22 895dfc                   mov       dword ptr [ebp - 4], ebx
004f9d25 895dec                   mov       dword ptr [ebp - 0x14], ebx
004f9d28 e8f3d3f0ff               call      0x407120
004f9d2d 8b16                     mov       edx, dword ptr [esi]
004f9d2f 53                       push      ebx
004f9d30 53                       push      ebx
004f9d31 53                       push      ebx
004f9d32 8d45dc                   lea       eax, [ebp - 0x24]
004f9d35 50                       push      eax
004f9d36 6a08                     push      8
004f9d38 8bce                     mov       ecx, esi
004f9d3a ff928c020000             call      dword ptr [edx + 0x28c]
004f9d40 8b16                     mov       edx, dword ptr [esi]
004f9d42 6a01                     push      1
004f9d44 8bce                     mov       ecx, esi
004f9d46 ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9d4c 8d4ddc                   lea       ecx, [ebp - 0x24]
004f9d4f c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004f9d56 e8f5af1400               call      0x644d50
004f9d5b e940010000               jmp       0x4f9ea0
004f9d60 8b06                     mov       eax, dword ptr [esi]
004f9d62 8bce                     mov       ecx, esi
004f9d64 ff90dc000000             call      dword ptr [eax + 0xdc]
004f9d6a 85c0                     test      eax, eax
004f9d6c 7512                     jne       0x4f9d80
004f9d6e 8b16                     mov       edx, dword ptr [esi]
004f9d70 8bce                     mov       ecx, esi
004f9d72 ff9294000000             call      dword ptr [edx + 0x94]
004f9d78 3b86bc1d0000             cmp       eax, dword ptr [esi + 0x1dbc]
004f9d7e 7e29                     jle       0x4f9da9
004f9d80 8b06                     mov       eax, dword ptr [esi]
004f9d82 8bce                     mov       ecx, esi
004f9d84 ff90dc000000             call      dword ptr [eax + 0xdc]
004f9d8a 83f801                   cmp       eax, 1
004f9d8d 0f850d010000             jne       0x4f9ea0
004f9d93 8b16                     mov       edx, dword ptr [esi]
004f9d95 8bce                     mov       ecx, esi
004f9d97 ff9294000000             call      dword ptr [edx + 0x94]
004f9d9d 3b86bc1d0000             cmp       eax, dword ptr [esi + 0x1dbc]
004f9da3 0f8cf7000000             jl        0x4f9ea0
004f9da9 6a01                     push      1
004f9dab e9e6000000               jmp       0x4f9e96
004f9db0 8d8e741d0000             lea       ecx, [esi + 0x1d74]
004f9db6 e845d16000               call      0xb06f00
004f9dbb 2b86d81d0000             sub       eax, dword ptr [esi + 0x1dd8]
004f9dc1 3df4010000               cmp       eax, 0x1f4
004f9dc6 0f8ed4000000             jle       0x4f9ea0
004f9dcc 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9dd2 8bce                     mov       ecx, esi
004f9dd4 6a04                     push      4
004f9dd6 0f84bc000000             je        0x4f9e98
004f9ddc 8b16                     mov       edx, dword ptr [esi]
004f9dde ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9de4 e9b7000000               jmp       0x4f9ea0
004f9de9 8d8e741d0000             lea       ecx, [esi + 0x1d74]
004f9def e80cd16000               call      0xb06f00
004f9df4 2b86d81d0000             sub       eax, dword ptr [esi + 0x1dd8]
004f9dfa 3d10270000               cmp       eax, 0x2710
004f9dff 0f8e9b000000             jle       0x4f9ea0
004f9e05 8b16                     mov       edx, dword ptr [esi]
004f9e07 6a0d                     push      0xd
004f9e09 8bce                     mov       ecx, esi
004f9e0b ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9e11 e98a000000               jmp       0x4f9ea0
004f9e16 8d8e741d0000             lea       ecx, [esi + 0x1d74]
004f9e1c e8dfd06000               call      0xb06f00
004f9e21 2b86d81d0000             sub       eax, dword ptr [esi + 0x1dd8]
004f9e27 3d88130000               cmp       eax, 0x1388
004f9e2c 7e72                     jle       0x4f9ea0
004f9e2e 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9e34 8bce                     mov       ecx, esi
004f9e36 7404                     je        0x4f9e3c
004f9e38 6a04                     push      4
004f9e3a eb5c                     jmp       0x4f9e98
004f9e3c 8b16                     mov       edx, dword ptr [esi]
004f9e3e 6a0d                     push      0xd
004f9e40 ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9e46 eb58                     jmp       0x4f9ea0
004f9e48 8b86141d0000             mov       eax, dword ptr [esi + 0x1d14]
004f9e4e 83f801                   cmp       eax, 1
004f9e51 7504                     jne       0x4f9e57
004f9e53 6a1b                     push      0x1b
004f9e55 eb3f                     jmp       0x4f9e96
004f9e57 83f802                   cmp       eax, 2
004f9e5a 7544                     jne       0x4f9ea0
004f9e5c 8b16                     mov       edx, dword ptr [esi]
004f9e5e 6a1c                     push      0x1c
004f9e60 8bce                     mov       ecx, esi
004f9e62 ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9e68 eb36                     jmp       0x4f9ea0
004f9e6a 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9e70 742e                     je        0x4f9ea0
004f9e72 6a04                     push      4
004f9e74 eb20                     jmp       0x4f9e96
004f9e76 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9e7c 7522                     jne       0x4f9ea0
004f9e7e 8b16                     mov       edx, dword ptr [esi]
004f9e80 6a0d                     push      0xd
004f9e82 8bce                     mov       ecx, esi
004f9e84 ff92f0050000             call      dword ptr [edx + 0x5f0]
004f9e8a eb14                     jmp       0x4f9ea0
004f9e8c 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9e92 750c                     jne       0x4f9ea0
004f9e94 6a0f                     push      0xf
004f9e96 8bce                     mov       ecx, esi
004f9e98 8b06                     mov       eax, dword ptr [esi]
004f9e9a ff90f0050000             call      dword ptr [eax + 0x5f0]
004f9ea0 399e0c1e0000             cmp       dword ptr [esi + 0x1e0c], ebx
004f9ea6 0f86a4000000             jbe       0x4f9f50
004f9eac 399e801b0000             cmp       dword ptr [esi + 0x1b80], ebx
004f9eb2 0f8498000000             je        0x4f9f50
004f9eb8 8b86e4190000             mov       eax, dword ptr [esi + 0x19e4]
004f9ebe 83f803                   cmp       eax, 3
004f9ec1 7405                     je        0x4f9ec8
004f9ec3 83f808                   cmp       eax, 8
004f9ec6 7535                     jne       0x4f9efd
004f9ec8 8b86101e0000             mov       eax, dword ptr [esi + 0x1e10]
004f9ece 83f808                   cmp       eax, 8
004f9ed1 8dbef81d0000             lea       edi, [esi + 0x1df8]
004f9ed7 7212                     jb        0x4f9eeb
004f9ed9 8b4704                   mov       eax, dword ptr [edi + 4]
004f9edc 53                       push      ebx
004f9edd 53                       push      ebx
004f9ede 6aff                     push      -1
004f9ee0 50                       push      eax
004f9ee1 e8cadaf4ff               call      0x4479b0
004f9ee6 83c410                   add       esp, 0x10
004f9ee9 eb3a                     jmp       0x4f9f25
004f9eeb 53                       push      ebx
004f9eec 53                       push      ebx
004f9eed 8d4704                   lea       eax, [edi + 4]
004f9ef0 6aff                     push      -1
004f9ef2 50                       push      eax
004f9ef3 e8b8daf4ff               call      0x4479b0
004f9ef8 83c410                   add       esp, 0x10
004f9efb eb28                     jmp       0x4f9f25
004f9efd 8b86101e0000             mov       eax, dword ptr [esi + 0x1e10]
004f9f03 83f808                   cmp       eax, 8
004f9f06 8dbef81d0000             lea       edi, [esi + 0x1df8]
004f9f0c 7205                     jb        0x4f9f13
004f9f0e 8b4704                   mov       eax, dword ptr [edi + 4]
004f9f11 eb03                     jmp       0x4f9f16
004f9f13 8d4704                   lea       eax, [edi + 4]
004f9f16 8b16                     mov       edx, dword ptr [esi]
004f9f18 53                       push      ebx
004f9f19 53                       push      ebx
004f9f1a 6aff                     push      -1
004f9f1c 50                       push      eax
004f9f1d 8bce                     mov       ecx, esi
004f9f1f ff920c010000             call      dword ptr [edx + 0x10c]
004f9f25 8b5718                   mov       edx, dword ptr [edi + 0x18]
004f9f28 83fa08                   cmp       edx, 8
004f9f2b 8d4704                   lea       eax, [edi + 4]
004f9f2e 7204                     jb        0x4f9f34
004f9f30 8b08                     mov       ecx, dword ptr [eax]
004f9f32 eb02                     jmp       0x4f9f36
004f9f34 8bc8                     mov       ecx, eax
004f9f36 83fa08                   cmp       edx, 8
004f9f39 8b7714                   mov       esi, dword ptr [edi + 0x14]
004f9f3c 8d0c71                   lea       ecx, [ecx + esi*2]
004f9f3f 7202                     jb        0x4f9f43
004f9f41 8b00                     mov       eax, dword ptr [eax]
004f9f43 51                       push      ecx
004f9f44 50                       push      eax
004f9f45 8d45ec                   lea       eax, [ebp - 0x14]
004f9f48 50                       push      eax
004f9f49 8bcf                     mov       ecx, edi
004f9f4b e8008af0ff               call      0x402950
004f9f50 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004f9f53 5f                       pop       edi
004f9f54 5e                       pop       esi
004f9f55 5b                       pop       ebx
004f9f56 64890d00000000           mov       dword ptr fs:[0], ecx
004f9f5d 8be5                     mov       esp, ebp
004f9f5f 5d                       pop       ebp
004f9f60 c3                       ret       
004f9f61 8d4900                   lea       ecx, [ecx]
004f9f64 8c9e4f00b19c             mov       word ptr [esi - 0x634effb1], ds
004f9f6a 4f                       dec       edi
004f9f6b 00609d                   add       byte ptr [eax - 0x63], ah
004f9f6e 4f                       dec       edi
004f9f6f 00769e                   add       byte ptr [esi - 0x62], dh
004f9f72 4f                       dec       edi
004f9f73 0016                     add       byte ptr [esi], dl
004f9f75 9e                       sahf      
004f9f76 4f                       dec       edi
004f9f77 00e9                     add       cl, ch
004f9f79 9d                       popfd     
004f9f7a 4f                       dec       edi
004f9f7b 00259c4f00a3             add       byte ptr [0xa3004f9c], ah
004f9f81 9b                       wait      
004f9f82 4f                       dec       edi
004f9f83 00489e                   add       byte ptr [eax - 0x62], cl
004f9f86 4f                       dec       edi
004f9f87 00b09d4f006a             add       byte ptr [eax + 0x6a004f9d], dh
004f9f8d 9e                       sahf      
004f9f8e 4f                       dec       edi
004f9f8f 00a09e4f0000             add       byte ptr [eax + 0x4f9e], ah
004f9f95 0102                     add       dword ptr [edx], eax
004f9f97 030b                     add       ecx, dword ptr [ebx]
004f9f99 040b                     add       al, 0xb
004f9f9b 0b0505060708             or        eax, dword ptr [0x8070605]
004f9fa1 0b08                     or        ecx, dword ptr [eax]
004f9fa3 0b08                     or        ecx, dword ptr [eax]
004f9fa5 0b0b                     or        ecx, dword ptr [ebx]
004f9fa7 0b09                     or        ecx, dword ptr [ecx]
004f9fa9 0b0b                     or        ecx, dword ptr [ebx]
004f9fab 0b0b                     or        ecx, dword ptr [ebx]
004f9fad 0b0a                     or        ecx, dword ptr [edx]
004f9faf 0a04cc                   or        al, byte ptr [esp + ecx*8]
004f9fb2 cc                       int3      
004f9fb3 cc                       int3      
004f9fb4 cc                       int3      
004f9fb5 cc                       int3      
004f9fb6 cc                       int3      
004f9fb7 cc                       int3      
004f9fb8 cc                       int3      
004f9fb9 cc                       int3      
004f9fba cc                       int3      
004f9fbb cc                       int3      
004f9fbc cc                       int3      
004f9fbd cc                       int3      
004f9fbe cc                       int3      
004f9fbf cc                       int3      
004f9fc0 55                       push      ebp
004f9fc1 8bec                     mov       ebp, esp
004f9fc3 6aff                     push      -1
004f9fc5 68469cc500               push      0xc59c46
004f9fca 64a100000000             mov       eax, dword ptr fs:[0]
004f9fd0 50                       push      eax
004f9fd1 64892500000000           mov       dword ptr fs:[0], esp
004f9fd8 83ec24                   sub       esp, 0x24
004f9fdb 56                       push      esi
004f9fdc 8bf1                     mov       esi, ecx
004f9fde 8b8e28020000             mov       ecx, dword ptr [esi + 0x228]
004f9fe4 8b8624020000             mov       eax, dword ptr [esi + 0x224]
004f9fea 3bc1                     cmp       eax, ecx
004f9fec 7416                     je        0x4fa004
004f9fee 8bff                     mov       edi, edi
004f9ff0 833819                   cmp       dword ptr [eax], 0x19
004f9ff3 7407                     je        0x4f9ffc
004f9ff5 83c004                   add       eax, 4
004f9ff8 3bc1                     cmp       eax, ecx
004f9ffa 75f4                     jne       0x4f9ff0
004f9ffc 3bc1                     cmp       eax, ecx
004f9ffe 0f85b3010000             jne       0x4fa1b7
004fa004 8b8e68120000             mov       ecx, dword ptr [esi + 0x1268]
004fa00a 85c9                     test      ecx, ecx
004fa00c 0f84a5010000             je        0x4fa1b7
004fa012 8b866c120000             mov       eax, dword ptr [esi + 0x126c]
004fa018 2bc1                     sub       eax, ecx
004fa01a c1f802                   sar       eax, 2
004fa01d 85c0                     test      eax, eax
004fa01f 0f8492010000             je        0x4fa1b7
004fa025 8d8e5c150000             lea       ecx, [esi + 0x155c]
004fa02b e83080f0ff               call      0x402060
