004bc7d0 55                       push      ebp
004bc7d1 8bec                     mov       ebp, esp
004bc7d3 6aff                     push      -1
004bc7d5 68ba78c500               push      0xc578ba
004bc7da 64a100000000             mov       eax, dword ptr fs:[0]
004bc7e0 50                       push      eax
004bc7e1 64892500000000           mov       dword ptr fs:[0], esp
004bc7e8 83ec28                   sub       esp, 0x28
004bc7eb 53                       push      ebx
004bc7ec 56                       push      esi
004bc7ed 57                       push      edi
004bc7ee 8bf1                     mov       esi, ecx
004bc7f0 e80b140300               call      0x4edc00
004bc7f5 8dbe54190000             lea       edi, [esi + 0x1954]
004bc7fb 8bcf                     mov       ecx, edi
004bc7fd e85e58f4ff               call      0x402060
004bc802 85c0                     test      eax, eax
004bc804 745c                     je        0x4bc862
004bc806 8d9e44190000             lea       ebx, [esi + 0x1944]
004bc80c 8d4b38                   lea       ecx, [ebx + 0x38]
004bc80f e84c58f4ff               call      0x402060
004bc814 8bcb                     mov       ecx, ebx
004bc816 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bc819 e8e2a66400               call      0xb06f00
004bc81e 3b45f0                   cmp       eax, dword ptr [ebp - 0x10]
004bc821 7c3f                     jl        0x4bc862
004bc823 a1d8012101               mov       eax, dword ptr [0x12101d8]
004bc828 8b4844                   mov       ecx, dword ptr [eax + 0x44]
004bc82b 8b4704                   mov       eax, dword ptr [edi + 4]
004bc82e 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004bc834 c1e002                   shl       eax, 2
004bc837 8d1408                   lea       edx, [eax + ecx]
004bc83a 33d3                     xor       edx, ebx
004bc83c 891408                   mov       dword ptr [eax + ecx], edx
004bc83f a1d8012101               mov       eax, dword ptr [0x12101d8]
004bc844 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004bc847 8b4704                   mov       eax, dword ptr [edi + 4]
004bc84a 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004bc850 c1e002                   shl       eax, 2
004bc853 8d1408                   lea       edx, [eax + ecx]
004bc856 33d7                     xor       edx, edi
004bc858 891408                   mov       dword ptr [eax + ecx], edx
004bc85b c6863d19000002           mov       byte ptr [esi + 0x193d], 2
004bc862 83be88010000ff           cmp       dword ptr [esi + 0x188], -1
004bc869 0f8596000000             jne       0x4bc905
004bc86f 8b06                     mov       eax, dword ptr [esi]
004bc871 8bce                     mov       ecx, esi
004bc873 ff9090030000             call      dword ptr [eax + 0x390]
004bc879 85c0                     test      eax, eax
004bc87b 742e                     je        0x4bc8ab
004bc87d 8b16                     mov       edx, dword ptr [esi]
004bc87f 8bce                     mov       ecx, esi
004bc881 ff9290030000             call      dword ptr [edx + 0x390]
004bc887 8bc8                     mov       ecx, eax
004bc889 e8e2065700               call      0xa2cf70
004bc88e 85c0                     test      eax, eax
004bc890 7e19                     jle       0x4bc8ab
004bc892 8b06                     mov       eax, dword ptr [esi]
004bc894 8bce                     mov       ecx, esi
004bc896 ff9090030000             call      dword ptr [eax + 0x390]
004bc89c 8bc8                     mov       ecx, eax
004bc89e e8cd065700               call      0xa2cf70
004bc8a3 898688010000             mov       dword ptr [esi + 0x188], eax
004bc8a9 eb5a                     jmp       0x4bc905
004bc8ab 8b16                     mov       edx, dword ptr [esi]
004bc8ad 8bce                     mov       ecx, esi
004bc8af ff9270030000             call      dword ptr [edx + 0x370]
004bc8b5 85c0                     test      eax, eax
004bc8b7 7428                     je        0x4bc8e1
004bc8b9 8b06                     mov       eax, dword ptr [esi]
004bc8bb 6a01                     push      1
004bc8bd 6a02                     push      2
004bc8bf 6a00                     push      0
004bc8c1 8bce                     mov       ecx, esi
004bc8c3 ff9070030000             call      dword ptr [eax + 0x370]
004bc8c9 8bc8                     mov       ecx, eax
004bc8cb e8c0935600               call      0xa25c90
004bc8d0 50                       push      eax
004bc8d1 e80a7a5600               call      0xa242e0
004bc8d6 83c40c                   add       esp, 0xc
004bc8d9 898688010000             mov       dword ptr [esi + 0x188], eax
004bc8df eb24                     jmp       0x4bc905
004bc8e1 8d8e08020000             lea       ecx, [esi + 0x208]
004bc8e7 e804685900               call      0xa530f0
004bc8ec 50                       push      eax
004bc8ed 685c15cd00               push      0xcd155c
004bc8f2 ff15bc2eff00             call      dword ptr [0xff2ebc]
004bc8f8 83c408                   add       esp, 8
004bc8fb c7868801000000000000     mov       dword ptr [esi + 0x188], 0
004bc905 8bce                     mov       ecx, esi
004bc907 e884f7fdff               call      0x49c090
004bc90c 84c0                     test      al, al
004bc90e bb04000000               mov       ebx, 4
004bc913 0f8469010000             je        0x4bca82
004bc919 8b16                     mov       edx, dword ptr [esi]
004bc91b 8bce                     mov       ecx, esi
004bc91d ff92dc030000             call      dword ptr [edx + 0x3dc]
004bc923 84c0                     test      al, al
004bc925 0f8457010000             je        0x4bca82
004bc92b 8dbe5c150000             lea       edi, [esi + 0x155c]
004bc931 8bcf                     mov       ecx, edi
004bc933 e82857f4ff               call      0x402060
004bc938 3bc3                     cmp       eax, ebx
004bc93a 0f8442010000             je        0x4bca82
004bc940 399ea0040000             cmp       dword ptr [esi + 0x4a0], ebx
004bc946 0f8436010000             je        0x4bca82
004bc94c 8bcf                     mov       ecx, edi
004bc94e e80d57f4ff               call      0x402060
004bc953 83f805                   cmp       eax, 5
004bc956 0f8426010000             je        0x4bca82
004bc95c 83bea004000005           cmp       dword ptr [esi + 0x4a0], 5
004bc963 0f8419010000             je        0x4bca82
004bc969 8bcf                     mov       ecx, edi
004bc96b e8f056f4ff               call      0x402060
004bc970 83f80d                   cmp       eax, 0xd
004bc973 0f8409010000             je        0x4bca82
004bc979 83bea00400000d           cmp       dword ptr [esi + 0x4a0], 0xd
004bc980 0f84fc000000             je        0x4bca82
004bc986 8bcf                     mov       ecx, edi
004bc988 e8d356f4ff               call      0x402060
004bc98d 83f809                   cmp       eax, 9
004bc990 0f84ec000000             je        0x4bca82
004bc996 83bea004000009           cmp       dword ptr [esi + 0x4a0], 9
004bc99d 0f84df000000             je        0x4bca82
004bc9a3 33ff                     xor       edi, edi
004bc9a5 897de0                   mov       dword ptr [ebp - 0x20], edi
004bc9a8 897de4                   mov       dword ptr [ebp - 0x1c], edi
004bc9ab 897de8                   mov       dword ptr [ebp - 0x18], edi
004bc9ae 8b06                     mov       eax, dword ptr [esi]
004bc9b0 8bce                     mov       ecx, esi
004bc9b2 897dfc                   mov       dword ptr [ebp - 4], edi
004bc9b5 ff9078030000             call      dword ptr [eax + 0x378]
004bc9bb 85c0                     test      eax, eax
004bc9bd 7556                     jne       0x4bca15
004bc9bf 8b16                     mov       edx, dword ptr [esi]
004bc9c1 8bce                     mov       ecx, esi
004bc9c3 ff92a0030000             call      dword ptr [edx + 0x3a0]
004bc9c9 85c0                     test      eax, eax
004bc9cb 7548                     jne       0x4bca15
004bc9cd 8b06                     mov       eax, dword ptr [esi]
004bc9cf 6811020000               push      0x211
004bc9d4 8bce                     mov       ecx, esi
004bc9d6 ff502c                   call      dword ptr [eax + 0x2c]
004bc9d9 84c0                     test      al, al
004bc9db 740d                     je        0x4bc9ea
004bc9dd 8d4df0                   lea       ecx, [ebp - 0x10]
004bc9e0 c745f002000000           mov       dword ptr [ebp - 0x10], 2
004bc9e7 51                       push      ecx
004bc9e8 eb17                     jmp       0x4bca01
004bc9ea 8b16                     mov       edx, dword ptr [esi]
004bc9ec 6811010000               push      0x111
004bc9f1 8bce                     mov       ecx, esi
004bc9f3 ff522c                   call      dword ptr [edx + 0x2c]
004bc9f6 84c0                     test      al, al
004bc9f8 740f                     je        0x4bca09
004bc9fa 8d45f0                   lea       eax, [ebp - 0x10]
004bc9fd 897df0                   mov       dword ptr [ebp - 0x10], edi
004bca00 50                       push      eax
004bca01 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca04 e817a7f4ff               call      0x407120
004bca09 57                       push      edi
004bca0a 57                       push      edi
004bca0b 6a03                     push      3
004bca0d 8d45dc                   lea       eax, [ebp - 0x24]
004bca10 50                       push      eax
004bca11 6a05                     push      5
004bca13 eb54                     jmp       0x4bca69
004bca15 8d4df0                   lea       ecx, [ebp - 0x10]
004bca18 51                       push      ecx
004bca19 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca1c 895df0                   mov       dword ptr [ebp - 0x10], ebx
004bca1f e8fca6f4ff               call      0x407120
004bca24 8d55f0                   lea       edx, [ebp - 0x10]
004bca27 52                       push      edx
004bca28 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca2b 897df0                   mov       dword ptr [ebp - 0x10], edi
004bca2e e8eda6f4ff               call      0x407120
004bca33 8d45f0                   lea       eax, [ebp - 0x10]
004bca36 50                       push      eax
004bca37 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca3a c745f001000000           mov       dword ptr [ebp - 0x10], 1
004bca41 e8daa6f4ff               call      0x407120
004bca46 684414cd00               push      0xcd1444
004bca4b 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca4e e8cda6f4ff               call      0x407120
004bca53 684814cd00               push      0xcd1448
004bca58 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca5b e8c0a6f4ff               call      0x407120
004bca60 57                       push      edi
004bca61 57                       push      edi
004bca62 6a03                     push      3
004bca64 8d45dc                   lea       eax, [ebp - 0x24]
004bca67 50                       push      eax
004bca68 53                       push      ebx
004bca69 8b16                     mov       edx, dword ptr [esi]
004bca6b 8bce                     mov       ecx, esi
004bca6d ff928c020000             call      dword ptr [edx + 0x28c]
004bca73 8d4ddc                   lea       ecx, [ebp - 0x24]
004bca76 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004bca7d e8ce821800               call      0x644d50
004bca82 8b16                     mov       edx, dword ptr [esi]
004bca84 8bce                     mov       ecx, esi
004bca86 ff92dc030000             call      dword ptr [edx + 0x3dc]
004bca8c 84c0                     test      al, al
004bca8e 740c                     je        0x4bca9c
004bca90 8b06                     mov       eax, dword ptr [esi]
004bca92 6a00                     push      0
004bca94 8bce                     mov       ecx, esi
004bca96 ff90d0020000             call      dword ptr [eax + 0x2d0]
004bca9c 8bce                     mov       ecx, esi
004bca9e e87dd6ffff               call      0x4ba120
004bcaa3 8b16                     mov       edx, dword ptr [esi]
004bcaa5 8bce                     mov       ecx, esi
004bcaa7 ff9274050000             call      dword ptr [edx + 0x574]
004bcaad 8dbec4150000             lea       edi, [esi + 0x15c4]
004bcab3 8bcf                     mov       ecx, edi
004bcab5 e8a655f4ff               call      0x402060
004bcaba 83f8ff                   cmp       eax, -1
004bcabd 7434                     je        0x4bcaf3
004bcabf 8d4e20                   lea       ecx, [esi + 0x20]
004bcac2 e839a46400               call      0xb06f00
004bcac7 8bcf                     mov       ecx, edi
004bcac9 8bd8                     mov       ebx, eax
004bcacb e89055f4ff               call      0x402060
004bcad0 05e8030000               add       eax, 0x3e8
004bcad5 3bd8                     cmp       ebx, eax
004bcad7 7e1a                     jle       0x4bcaf3
004bcad9 8b3e                     mov       edi, dword ptr [esi]
004bcadb 6a00                     push      0
004bcadd 6a01                     push      1
004bcadf 8d8e30120000             lea       ecx, [esi + 0x1230]
004bcae5 e87655f4ff               call      0x402060
004bcaea 50                       push      eax
004bcaeb 8bce                     mov       ecx, esi
004bcaed ff97e8030000             call      dword ptr [edi + 0x3e8]
004bcaf3 8dbecc150000             lea       edi, [esi + 0x15cc]
004bcaf9 8bcf                     mov       ecx, edi
004bcafb e86055f4ff               call      0x402060
004bcb00 83f8ff                   cmp       eax, -1
004bcb03 7432                     je        0x4bcb37
004bcb05 8d4e20                   lea       ecx, [esi + 0x20]
004bcb08 e8f3a36400               call      0xb06f00
004bcb0d 8bcf                     mov       ecx, edi
004bcb0f 8bd8                     mov       ebx, eax
004bcb11 e84a55f4ff               call      0x402060
004bcb16 05e8030000               add       eax, 0x3e8
004bcb1b 3bd8                     cmp       ebx, eax
004bcb1d 7e18                     jle       0x4bcb37
004bcb1f 8b3e                     mov       edi, dword ptr [esi]
004bcb21 6a01                     push      1
004bcb23 8d8e38120000             lea       ecx, [esi + 0x1238]
004bcb29 e83255f4ff               call      0x402060
004bcb2e 50                       push      eax
004bcb2f 8bce                     mov       ecx, esi
004bcb31 ff97f0030000             call      dword ptr [edi + 0x3f0]
004bcb37 8dbe94120000             lea       edi, [esi + 0x1294]
004bcb3d bb12000000               mov       ebx, 0x12
004bcb42 8b07                     mov       eax, dword ptr [edi]
004bcb44 85c0                     test      eax, eax
004bcb46 7412                     je        0x4bcb5a
004bcb48 8bc8                     mov       ecx, eax
004bcb4a 8b01                     mov       eax, dword ptr [ecx]
004bcb4c ff5008                   call      dword ptr [eax + 8]
004bcb4f 84c0                     test      al, al
004bcb51 7407                     je        0x4bcb5a
004bcb53 8b0f                     mov       ecx, dword ptr [edi]
004bcb55 8b11                     mov       edx, dword ptr [ecx]
004bcb57 ff5230                   call      dword ptr [edx + 0x30]
004bcb5a 83c704                   add       edi, 4
004bcb5d 4b                       dec       ebx
004bcb5e 75e2                     jne       0x4bcb42
004bcb60 8b8edc120000             mov       ecx, dword ptr [esi + 0x12dc]
004bcb66 e845910a00               call      0x565cb0
004bcb6b 8b06                     mov       eax, dword ptr [esi]
004bcb6d 6a02                     push      2
004bcb6f 8bce                     mov       ecx, esi
004bcb71 ff9048030000             call      dword ptr [eax + 0x348]
004bcb77 8d4e60                   lea       ecx, [esi + 0x60]
004bcb7a e881a36400               call      0xb06f00
004bcb7f 50                       push      eax
004bcb80 8d8e44160000             lea       ecx, [esi + 0x1644]
004bcb86 e825545900               call      0xa51fb0
004bcb8b 84c0                     test      al, al
004bcb8d 0f849a000000             je        0x4bcc2d
004bcb93 8bbe10160000             mov       edi, dword ptr [esi + 0x1610]
004bcb99 85ff                     test      edi, edi
004bcb9b 7443                     je        0x4bcbe0
004bcb9d 8d8e28160000             lea       ecx, [esi + 0x1628]
004bcba3 e80868f7ff               call      0x4333b0
004bcba8 d95dec                   fstp      dword ptr [ebp - 0x14]
004bcbab 8b16                     mov       edx, dword ptr [esi]
004bcbad 57                       push      edi
004bcbae 8bce                     mov       ecx, esi
004bcbb0 ff9284050000             call      dword ptr [edx + 0x584]
004bcbb6 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bcbb9 db45f0                   fild      dword ptr [ebp - 0x10]
004bcbbc d84dec                   fmul      dword ptr [ebp - 0x14]
004bcbbf e880497400               call      0xc01544
004bcbc4 8d8e18160000             lea       ecx, [esi + 0x1618]
004bcbca 8bf8                     mov       edi, eax
004bcbcc e88f54f4ff               call      0x402060
004bcbd1 3bf8                     cmp       edi, eax
004bcbd3 740b                     je        0x4bcbe0
004bcbd5 8b06                     mov       eax, dword ptr [esi]
004bcbd7 57                       push      edi
004bcbd8 8bce                     mov       ecx, esi
004bcbda ff9088050000             call      dword ptr [eax + 0x588]
004bcbe0 8bbe14160000             mov       edi, dword ptr [esi + 0x1614]
004bcbe6 85ff                     test      edi, edi
004bcbe8 7443                     je        0x4bcc2d
004bcbea 8d8e30160000             lea       ecx, [esi + 0x1630]
004bcbf0 e8bb67f7ff               call      0x4333b0
004bcbf5 d95df0                   fstp      dword ptr [ebp - 0x10]
004bcbf8 8b16                     mov       edx, dword ptr [esi]
004bcbfa 57                       push      edi
004bcbfb 8bce                     mov       ecx, esi
004bcbfd ff9284050000             call      dword ptr [edx + 0x584]
004bcc03 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bcc06 db45ec                   fild      dword ptr [ebp - 0x14]
004bcc09 d84df0                   fmul      dword ptr [ebp - 0x10]
004bcc0c e833497400               call      0xc01544
004bcc11 8d8e20160000             lea       ecx, [esi + 0x1620]
004bcc17 8bf8                     mov       edi, eax
004bcc19 e84254f4ff               call      0x402060
004bcc1e 3bf8                     cmp       edi, eax
004bcc20 740b                     je        0x4bcc2d
004bcc22 8b06                     mov       eax, dword ptr [esi]
004bcc24 57                       push      edi
004bcc25 8bce                     mov       ecx, esi
004bcc27 ff908c050000             call      dword ptr [eax + 0x58c]
004bcc2d 8b16                     mov       edx, dword ptr [esi]
004bcc2f 8bce                     mov       ecx, esi
004bcc31 ff9280050000             call      dword ptr [edx + 0x580]
004bcc37 8b06                     mov       eax, dword ptr [esi]
004bcc39 8bce                     mov       ecx, esi
004bcc3b ff90dc000000             call      dword ptr [eax + 0xdc]
004bcc41 8b16                     mov       edx, dword ptr [esi]
004bcc43 8bce                     mov       ecx, esi
004bcc45 8945f0                   mov       dword ptr [ebp - 0x10], eax
004bcc48 ff92e0000000             call      dword ptr [edx + 0xe0]
004bcc4e 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004bcc54 8b8e60150000             mov       ecx, dword ptr [esi + 0x1560]
004bcc5a 8d9e5c150000             lea       ebx, [esi + 0x155c]
004bcc60 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bcc63 8b03                     mov       eax, dword ptr [ebx]
004bcc65 33c7                     xor       eax, edi
004bcc67 2bc3                     sub       eax, ebx
004bcc69 3bc1                     cmp       eax, ecx
004bcc6b 740e                     je        0x4bcc7b
004bcc6d 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004bcc73 6a3f                     push      0x3f
004bcc75 53                       push      ebx
004bcc76 e835a46500               call      0xb170b0
004bcc7b 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004bcc81 8b4a44                   mov       ecx, dword ptr [edx + 0x44]
004bcc84 8b4304                   mov       eax, dword ptr [ebx + 4]
004bcc87 c1e002                   shl       eax, 2
004bcc8a 8d3c01                   lea       edi, [ecx + eax]
004bcc8d 333c01                   xor       edi, dword ptr [ecx + eax]
004bcc90 333ddc012101             xor       edi, dword ptr [0x12101dc]
004bcc96 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004bcc99 8d1401                   lea       edx, [ecx + eax]
004bcc9c 331401                   xor       edx, dword ptr [ecx + eax]
004bcc9f 3315dc012101             xor       edx, dword ptr [0x12101dc]
004bcca5 3bfa                     cmp       edi, edx
004bcca7 740e                     je        0x4bccb7
004bcca9 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004bccaf 6a40                     push      0x40
004bccb1 53                       push      ebx
004bccb2 e8f9a36500               call      0xb170b0
004bccb7 83ff08                   cmp       edi, 8
004bccba 0f87400d0000             ja        0x4bda00
004bccc0 ff24bdd0da4b00           jmp       dword ptr [edi*4 + 0x4bdad0]
004bccc7 8b86b0010000             mov       eax, dword ptr [esi + 0x1b0]
004bcccd 85c0                     test      eax, eax
004bcccf 0f852b0d0000             jne       0x4bda00
004bccd5 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004bccd8 b804000000               mov       eax, 4
004bccdd 3bc8                     cmp       ecx, eax
004bccdf 0f85c2000000             jne       0x4bcda7
004bcce5 3945ec                   cmp       dword ptr [ebp - 0x14], eax
004bcce8 0f85b9000000             jne       0x4bcda7
004bccee 8dbeb4160000             lea       edi, [esi + 0x16b4]
004bccf4 8bcf                     mov       ecx, edi
004bccf6 e86553f4ff               call      0x402060
004bccfb 85c0                     test      eax, eax
004bccfd 0f85fd0c0000             jne       0x4bda00
004bcd03 8d45ec                   lea       eax, [ebp - 0x14]
004bcd06 50                       push      eax
004bcd07 8bcf                     mov       ecx, edi
004bcd09 c745ec01000000           mov       dword ptr [ebp - 0x14], 1
004bcd10 e84b78f4ff               call      0x404560
004bcd15 8b16                     mov       edx, dword ptr [esi]
004bcd17 680000803f               push      0x3f800000
004bcd1c 680000803f               push      0x3f800000
004bcd21 68e8030000               push      0x3e8
004bcd26 68e8030000               push      0x3e8
004bcd2b 6a00                     push      0
004bcd2d 6a01                     push      1
004bcd2f 8bce                     mov       ecx, esi
004bcd31 ff9294040000             call      dword ptr [edx + 0x494]
004bcd37 8b3e                     mov       edi, dword ptr [esi]
004bcd39 8bce                     mov       ecx, esi
004bcd3b ff9790030000             call      dword ptr [edi + 0x390]
004bcd41 50                       push      eax
004bcd42 8bce                     mov       ecx, esi
004bcd44 ff9700010000             call      dword ptr [edi + 0x100]
004bcd4a 8b8e48010000             mov       ecx, dword ptr [esi + 0x148]
004bcd50 85c9                     test      ecx, ecx
004bcd52 7416                     je        0x4bcd6a
004bcd54 e8874c5700               call      0xa319e0
004bcd59 8b16                     mov       edx, dword ptr [esi]
004bcd5b 6a01                     push      1
004bcd5d 8bce                     mov       ecx, esi
004bcd5f ff9210010000             call      dword ptr [edx + 0x110]
004bcd65 e9960c0000               jmp       0x4bda00
004bcd6a 8b06                     mov       eax, dword ptr [esi]
004bcd6c 8bce                     mov       ecx, esi
004bcd6e ff9070030000             call      dword ptr [eax + 0x370]
004bcd74 85c0                     test      eax, eax
004bcd76 741e                     je        0x4bcd96
004bcd78 8b3e                     mov       edi, dword ptr [esi]
004bcd7a 8bce                     mov       ecx, esi
004bcd7c ff9770030000             call      dword ptr [edi + 0x370]
004bcd82 50                       push      eax
004bcd83 8bce                     mov       ecx, esi
004bcd85 ff97f0000000             call      dword ptr [edi + 0xf0]
004bcd8b 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bcd91 e8caa55600               call      0xa27360
004bcd96 8b16                     mov       edx, dword ptr [esi]
004bcd98 6a01                     push      1
004bcd9a 8bce                     mov       ecx, esi
004bcd9c ff9210010000             call      dword ptr [edx + 0x110]
004bcda2 e9590c0000               jmp       0x4bda00
004bcda7 8dbeb4160000             lea       edi, [esi + 0x16b4]
004bcdad 8bcf                     mov       ecx, edi
004bcdaf e8ac52f4ff               call      0x402060
004bcdb4 85c0                     test      eax, eax
004bcdb6 0f8494010000             je        0x4bcf50
004bcdbc 8d45ec                   lea       eax, [ebp - 0x14]
004bcdbf 50                       push      eax
004bcdc0 8bcf                     mov       ecx, edi
004bcdc2 c745ec00000000           mov       dword ptr [ebp - 0x14], 0
004bcdc9 e89277f4ff               call      0x404560
004bcdce 8b16                     mov       edx, dword ptr [esi]
004bcdd0 680000803f               push      0x3f800000
004bcdd5 680000803f               push      0x3f800000
004bcdda 68e8030000               push      0x3e8
004bcddf 68e8030000               push      0x3e8
004bcde4 6a01                     push      1
004bcde6 6a01                     push      1
004bcde8 8bce                     mov       ecx, esi
004bcdea ff9294040000             call      dword ptr [edx + 0x494]
004bcdf0 8b06                     mov       eax, dword ptr [esi]
004bcdf2 8bce                     mov       ecx, esi
004bcdf4 ff9094030000             call      dword ptr [eax + 0x394]
004bcdfa 398648010000             cmp       dword ptr [esi + 0x148], eax
004bce00 742f                     je        0x4bce31
004bce02 8b16                     mov       edx, dword ptr [esi]
004bce04 8bce                     mov       ecx, esi
004bce06 ff9294030000             call      dword ptr [edx + 0x394]
004bce0c 85c0                     test      eax, eax
004bce0e 750e                     jne       0x4bce1e
004bce10 8b06                     mov       eax, dword ptr [esi]
004bce12 8bce                     mov       ecx, esi
004bce14 ff9068030000             call      dword ptr [eax + 0x368]
004bce1a 85c0                     test      eax, eax
004bce1c 7413                     je        0x4bce31
004bce1e 8b3e                     mov       edi, dword ptr [esi]
004bce20 8bce                     mov       ecx, esi
004bce22 ff9794030000             call      dword ptr [edi + 0x394]
004bce28 50                       push      eax
004bce29 8bce                     mov       ecx, esi
004bce2b ff9700010000             call      dword ptr [edi + 0x100]
004bce31 8b8e48010000             mov       ecx, dword ptr [esi + 0x148]
004bce37 85c9                     test      ecx, ecx
004bce39 7413                     je        0x4bce4e
004bce3b e8a04b5700               call      0xa319e0
004bce40 8b16                     mov       edx, dword ptr [esi]
004bce42 6a00                     push      0
004bce44 8bce                     mov       ecx, esi
004bce46 ff92f0000000             call      dword ptr [edx + 0xf0]
004bce4c eb54                     jmp       0x4bcea2
004bce4e 8b06                     mov       eax, dword ptr [esi]
004bce50 8bce                     mov       ecx, esi
004bce52 ff9068030000             call      dword ptr [eax + 0x368]
004bce58 85c0                     test      eax, eax
004bce5a 7446                     je        0x4bcea2
004bce5c 8b16                     mov       edx, dword ptr [esi]
004bce5e 8bce                     mov       ecx, esi
004bce60 ff9270030000             call      dword ptr [edx + 0x370]
004bce66 85c0                     test      eax, eax
004bce68 7438                     je        0x4bcea2
004bce6a 8b06                     mov       eax, dword ptr [esi]
004bce6c 8bce                     mov       ecx, esi
004bce6e ff9070030000             call      dword ptr [eax + 0x370]
004bce74 8b16                     mov       edx, dword ptr [esi]
004bce76 8bce                     mov       ecx, esi
004bce78 8bf8                     mov       edi, eax
004bce7a ff9268030000             call      dword ptr [edx + 0x368]
004bce80 3bc7                     cmp       eax, edi
004bce82 741e                     je        0x4bcea2
004bce84 8b3e                     mov       edi, dword ptr [esi]
004bce86 8bce                     mov       ecx, esi
004bce88 ff9768030000             call      dword ptr [edi + 0x368]
004bce8e 50                       push      eax
004bce8f 8bce                     mov       ecx, esi
004bce91 ff97f0000000             call      dword ptr [edi + 0xf0]
004bce97 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bce9d e8bea45600               call      0xa27360
004bcea2 8b06                     mov       eax, dword ptr [esi]
004bcea4 6811010000               push      0x111
004bcea9 8bce                     mov       ecx, esi
004bceab ff502c                   call      dword ptr [eax + 0x2c]
004bceae 84c0                     test      al, al
004bceb0 0f849a000000             je        0x4bcf50
004bceb6 833dc03c0d0101           cmp       dword ptr [0x10d3cc0], 1
004bcebd 8bce                     mov       ecx, esi
004bcebf 750d                     jne       0x4bcece
004bcec1 6a00                     push      0
004bcec3 6a00                     push      0
004bcec5 6a01                     push      1
004bcec7 683815cd00               push      0xcd1538
004bcecc eb7a                     jmp       0x4bcf48
004bcece 8b06                     mov       eax, dword ptr [esi]
004bced0 ff505c                   call      dword ptr [eax + 0x5c]
004bced3 8b8014010000             mov       eax, dword ptr [eax + 0x114]
004bced9 8b80b4000000             mov       eax, dword ptr [eax + 0xb4]
004bcedf 8b16                     mov       edx, dword ptr [esi]
004bcee1 8b7834                   mov       edi, dword ptr [eax + 0x34]
004bcee4 8bce                     mov       ecx, esi
004bcee6 ff525c                   call      dword ptr [edx + 0x5c]
004bcee9 8b8014010000             mov       eax, dword ptr [eax + 0x114]
004bceef 8b4050                   mov       eax, dword ptr [eax + 0x50]
004bcef2 8b4060                   mov       eax, dword ptr [eax + 0x60]
004bcef5 3d63c30000               cmp       eax, 0xc363
004bcefa 7505                     jne       0x4bcf01
004bcefc bf28000000               mov       edi, 0x28
004bcf01 8d47f5                   lea       eax, [edi - 0xb]
004bcf04 83f828                   cmp       eax, 0x28
004bcf07 7732                     ja        0x4bcf3b
004bcf09 0fb68000db4b00           movzx     eax, byte ptr [eax + 0x4bdb00]
004bcf10 ff2485f4da4b00           jmp       dword ptr [eax*4 + 0x4bdaf4]
004bcf17 6a00                     push      0
004bcf19 6a00                     push      0
004bcf1b 6a01                     push      1
004bcf1d 689003cd00               push      0xcd0390
004bcf22 eb22                     jmp       0x4bcf46
004bcf24 8b06                     mov       eax, dword ptr [esi]
004bcf26 6a00                     push      0
004bcf28 6a00                     push      0
004bcf2a 6a01                     push      1
004bcf2c 686c03cd00               push      0xcd036c
004bcf31 8bce                     mov       ecx, esi
004bcf33 ff900c010000             call      dword ptr [eax + 0x10c]
004bcf39 eb15                     jmp       0x4bcf50
004bcf3b 6a00                     push      0
004bcf3d 6a00                     push      0
004bcf3f 6a01                     push      1
004bcf41 681815cd00               push      0xcd1518
004bcf46 8bce                     mov       ecx, esi
004bcf48 8b16                     mov       edx, dword ptr [esi]
004bcf4a ff920c010000             call      dword ptr [edx + 0x10c]
004bcf50 83be5c18000007           cmp       dword ptr [esi + 0x185c], 7
004bcf57 0f85a30a0000             jne       0x4bda00
004bcf5d 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004bcf63 85c0                     test      eax, eax
004bcf65 0f84950a0000             je        0x4bda00
004bcf6b 8d8e98180000             lea       ecx, [esi + 0x1898]
004bcf71 e88a27f8ff               call      0x43f700
004bcf76 84c0                     test      al, al
004bcf78 0f84820a0000             je        0x4bda00
004bcf7e 8b06                     mov       eax, dword ptr [esi]
004bcf80 6a02                     push      2
004bcf82 8bce                     mov       ecx, esi
004bcf84 ff90d0040000             call      dword ptr [eax + 0x4d0]
004bcf8a 8b16                     mov       edx, dword ptr [esi]
004bcf8c 8b3c85782e0001           mov       edi, dword ptr [eax*4 + 0x1002e78]
004bcf93 8bce                     mov       ecx, esi
004bcf95 ff92c0000000             call      dword ptr [edx + 0xc0]
004bcf9b 8bd8                     mov       ebx, eax
004bcf9d 8b07                     mov       eax, dword ptr [edi]
004bcf9f f7db                     neg       ebx
004bcfa1 1adb                     sbb       bl, bl
004bcfa3 8bcf                     mov       ecx, edi
004bcfa5 fec3                     inc       bl
004bcfa7 ff501c                   call      dword ptr [eax + 0x1c]
004bcfaa 885858                   mov       byte ptr [eax + 0x58], bl
004bcfad 8b16                     mov       edx, dword ptr [esi]
004bcfaf 8b1f                     mov       ebx, dword ptr [edi]
004bcfb1 8bce                     mov       ecx, esi
004bcfb3 ff929c000000             call      dword ptr [edx + 0x9c]
004bcfb9 50                       push      eax
004bcfba 8b06                     mov       eax, dword ptr [esi]
004bcfbc 8bce                     mov       ecx, esi
004bcfbe ff9098000000             call      dword ptr [eax + 0x98]
004bcfc4 8b16                     mov       edx, dword ptr [esi]
004bcfc6 50                       push      eax
004bcfc7 8bce                     mov       ecx, esi
004bcfc9 ff9294000000             call      dword ptr [edx + 0x94]
004bcfcf 50                       push      eax
004bcfd0 8bcf                     mov       ecx, edi
004bcfd2 ff5328                   call      dword ptr [ebx + 0x28]
004bcfd5 8b07                     mov       eax, dword ptr [edi]
004bcfd7 6a00                     push      0
004bcfd9 8bcf                     mov       ecx, edi
004bcfdb ff500c                   call      dword ptr [eax + 0xc]
004bcfde 8b17                     mov       edx, dword ptr [edi]
004bcfe0 8d45cc                   lea       eax, [ebp - 0x34]
004bcfe3 50                       push      eax
004bcfe4 8bcf                     mov       ecx, edi
004bcfe6 ff525c                   call      dword ptr [edx + 0x5c]
004bcfe9 6a00                     push      0
004bcfeb 8d4dcc                   lea       ecx, [ebp - 0x34]
004bcfee 51                       push      ecx
004bcfef 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004bcff5 6a00                     push      0
004bcff7 6a02                     push      2
004bcff9 56                       push      esi
004bcffa c745fc01000000           mov       dword ptr [ebp - 4], 1
004bd001 e85a100500               call      0x50e060
004bd006 8dbe98180000             lea       edi, [esi + 0x1898]
004bd00c 8bcf                     mov       ecx, edi
004bd00e e8dd7ef4ff               call      0x404ef0
004bd013 6a00                     push      0
004bd015 68c8000000               push      0xc8
004bd01a 8bcf                     mov       ecx, edi
004bd01c e83f9f6400               call      0xb06f60
004bd021 8d4dcc                   lea       ecx, [ebp - 0x34]
004bd024 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004bd02b e8207d1800               call      0x644d50
004bd030 e9cb090000               jmp       0x4bda00
004bd035 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004bd03b 85c0                     test      eax, eax
004bd03d 0f84bd090000             je        0x4bda00
004bd043 8a883a010000             mov       cl, byte ptr [eax + 0x13a]
004bd049 84c9                     test      cl, cl
004bd04b 0f84af090000             je        0x4bda00
004bd051 8b16                     mov       edx, dword ptr [esi]
004bd053 6a00                     push      0
004bd055 6a00                     push      0
004bd057 6a00                     push      0
004bd059 6a00                     push      0
004bd05b 6a00                     push      0
004bd05d 8bce                     mov       ecx, esi
004bd05f ff928c020000             call      dword ptr [edx + 0x28c]
004bd065 e996090000               jmp       0x4bda00
004bd06a 8d8ec0160000             lea       ecx, [esi + 0x16c0]
004bd070 e8eb4ff4ff               call      0x402060
004bd075 8d8e64150000             lea       ecx, [esi + 0x1564]
004bd07b 8bf8                     mov       edi, eax
004bd07d e87e9e6400               call      0xb06f00
004bd082 3bc7                     cmp       eax, edi
004bd084 0f8c76090000             jl        0x4bda00
004bd08a 8b06                     mov       eax, dword ptr [esi]
004bd08c 6a03                     push      3
004bd08e 8bce                     mov       ecx, esi
004bd090 ff9010040000             call      dword ptr [eax + 0x410]
004bd096 84c0                     test      al, al
004bd098 6a00                     push      0
004bd09a 8bce                     mov       ecx, esi
004bd09c 6a00                     push      0
004bd09e 0f844e090000             je        0x4bd9f2
004bd0a4 8b16                     mov       edx, dword ptr [esi]
004bd0a6 6a03                     push      3
004bd0a8 6a00                     push      0
004bd0aa 6a09                     push      9
004bd0ac ff928c020000             call      dword ptr [edx + 0x28c]
004bd0b2 e949090000               jmp       0x4bda00
004bd0b7 8b16                     mov       edx, dword ptr [esi]
004bd0b9 8bce                     mov       ecx, esi
004bd0bb 8dbe14170000             lea       edi, [esi + 0x1714]
004bd0c1 ff929c000000             call      dword ptr [edx + 0x9c]
004bd0c7 8bcf                     mov       ecx, edi
004bd0c9 8bd8                     mov       ebx, eax
004bd0cb e8904ff4ff               call      0x402060
004bd0d0 3bd8                     cmp       ebx, eax
004bd0d2 7e18                     jle       0x4bd0ec
004bd0d4 8b06                     mov       eax, dword ptr [esi]
004bd0d6 8bce                     mov       ecx, esi
004bd0d8 ff909c000000             call      dword ptr [eax + 0x9c]
004bd0de 8d4dec                   lea       ecx, [ebp - 0x14]
004bd0e1 51                       push      ecx
004bd0e2 8bcf                     mov       ecx, edi
004bd0e4 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd0e7 e87474f4ff               call      0x404560
004bd0ec 8dbe20170000             lea       edi, [esi + 0x1720]
004bd0f2 8bcf                     mov       ecx, edi
004bd0f4 e8674ff4ff               call      0x402060
004bd0f9 85c0                     test      eax, eax
004bd0fb 0f85d2020000             jne       0x4bd3d3
004bd101 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd107 8b08                     mov       ecx, dword ptr [eax]
004bd109 85c9                     test      ecx, ecx
004bd10b 7503                     jne       0x4bd110
004bd10d 8d4808                   lea       ecx, [eax + 8]
004bd110 8b11                     mov       edx, dword ptr [ecx]
004bd112 6a02                     push      2
004bd114 ff5208                   call      dword ptr [edx + 8]
004bd117 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004bd11d 85c0                     test      eax, eax
004bd11f 747a                     je        0x4bd19b
004bd121 dc1d60b2cc00             fcomp     qword ptr [0xccb260]
004bd127 8b9824010000             mov       ebx, dword ptr [eax + 0x124]
004bd12d dfe0                     fnstsw    ax
004bd12f f6c441                   test      ah, 0x41
004bd132 7469                     je        0x4bd19d
004bd134 8dbee4160000             lea       edi, [esi + 0x16e4]
004bd13a 8bcf                     mov       ecx, edi
004bd13c e81f4ff4ff               call      0x402060
004bd141 3bd8                     cmp       ebx, eax
004bd143 7558                     jne       0x4bd19d
004bd145 8d8eec160000             lea       ecx, [esi + 0x16ec]
004bd14b e8104ff4ff               call      0x402060
004bd150 8bcf                     mov       ecx, edi
004bd152 8bd8                     mov       ebx, eax
004bd154 e8074ff4ff               call      0x402060
004bd159 3bc3                     cmp       eax, ebx
004bd15b 7440                     je        0x4bd19d
004bd15d 8b06                     mov       eax, dword ptr [esi]
004bd15f 8bce                     mov       ecx, esi
004bd161 ff9004010000             call      dword ptr [eax + 0x104]
004bd167 85c0                     test      eax, eax
004bd169 8bcf                     mov       ecx, edi
004bd16b 741a                     je        0x4bd187
004bd16d e8ee4ef4ff               call      0x402060
004bd172 8b16                     mov       edx, dword ptr [esi]
004bd174 40                       inc       eax
004bd175 50                       push      eax
004bd176 8bce                     mov       ecx, esi
004bd178 ff9204010000             call      dword ptr [edx + 0x104]
004bd17e 8bc8                     mov       ecx, eax
004bd180 e82b345700               call      0xa305b0
004bd185 eb16                     jmp       0x4bd19d
004bd187 e8d44ef4ff               call      0x402060
004bd18c 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bd192 40                       inc       eax
004bd193 50                       push      eax
004bd194 e8c7d1ffff               call      0x4ba360
004bd199 eb02                     jmp       0x4bd19d
004bd19b ddd8                     fstp      st(0)
004bd19d 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd1a3 83b8ec00000004           cmp       dword ptr [eax + 0xec], 4
004bd1aa 7570                     jne       0x4bd21c
004bd1ac 8b861c170000             mov       eax, dword ptr [esi + 0x171c]
004bd1b2 83cbff                   or        ebx, 0xffffffff
004bd1b5 3bc3                     cmp       eax, ebx
004bd1b7 7463                     je        0x4bd21c
004bd1b9 8b16                     mov       edx, dword ptr [esi]
004bd1bb 8bce                     mov       ecx, esi
004bd1bd ff9294000000             call      dword ptr [edx + 0x94]
004bd1c3 39861c170000             cmp       dword ptr [esi + 0x171c], eax
004bd1c9 7451                     je        0x4bd21c
004bd1cb 8dbe0c170000             lea       edi, [esi + 0x170c]
004bd1d1 8bcf                     mov       ecx, edi
004bd1d3 e8884ef4ff               call      0x402060
004bd1d8 8bc8                     mov       ecx, eax
004bd1da b899999999               mov       eax, 0x99999999
004bd1df f7e9                     imul      ecx
004bd1e1 d1fa                     sar       edx, 1
004bd1e3 8bc2                     mov       eax, edx
004bd1e5 c1e81f                   shr       eax, 0x1f
004bd1e8 8d4dec                   lea       ecx, [ebp - 0x14]
004bd1eb 03c2                     add       eax, edx
004bd1ed 51                       push      ecx
004bd1ee 8bcf                     mov       ecx, edi
004bd1f0 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd1f3 e86873f4ff               call      0x404560
004bd1f8 8bcf                     mov       ecx, edi
004bd1fa e8614ef4ff               call      0x402060
004bd1ff 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd202 db45ec                   fild      dword ptr [ebp - 0x14]
004bd205 51                       push      ecx
004bd206 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bd20c d91c24                   fstp      dword ptr [esp]
004bd20f 6a00                     push      0
004bd211 e82a3e0500               call      0x511040
004bd216 899e1c170000             mov       dword ptr [esi + 0x171c], ebx
004bd21c 8bce                     mov       ecx, esi
004bd21e e86deefdff               call      0x49c090
004bd223 84c0                     test      al, al
004bd225 0f84d5070000             je        0x4bda00
004bd22b 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd231 8b08                     mov       ecx, dword ptr [eax]
004bd233 85c9                     test      ecx, ecx
004bd235 7503                     jne       0x4bd23a
004bd237 8d4808                   lea       ecx, [eax + 8]
004bd23a 8b11                     mov       edx, dword ptr [ecx]
004bd23c 6a02                     push      2
004bd23e ff5208                   call      dword ptr [edx + 8]
004bd241 d81da4d7e900             fcomp     dword ptr [0xe9d7a4]
004bd247 dfe0                     fnstsw    ax
004bd249 f6c405                   test      ah, 5
004bd24c 0f8aae070000             jp        0x4bda00
004bd252 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd258 83b8f400000004           cmp       dword ptr [eax + 0xf4], 4
004bd25f 0f859b070000             jne       0x4bda00
004bd265 8b86b0010000             mov       eax, dword ptr [esi + 0x1b0]
004bd26b 85c0                     test      eax, eax
004bd26d 0f858d070000             jne       0x4bda00
004bd273 8b866c160000             mov       eax, dword ptr [esi + 0x166c]
004bd279 83cbff                   or        ebx, 0xffffffff
004bd27c 3bc3                     cmp       eax, ebx
004bd27e 742d                     je        0x4bd2ad
004bd280 8d8ea0000000             lea       ecx, [esi + 0xa0]
004bd286 e8759c6400               call      0xb06f00
004bd28b 3b866c160000             cmp       eax, dword ptr [esi + 0x166c]
004bd291 7c1a                     jl        0x4bd2ad
004bd293 8b16                     mov       edx, dword ptr [esi]
004bd295 8bce                     mov       ecx, esi
004bd297 ff92dc030000             call      dword ptr [edx + 0x3dc]
004bd29d 84c0                     test      al, al
004bd29f 750c                     jne       0x4bd2ad
004bd2a1 8bce                     mov       ecx, esi
004bd2a3 e8d8d0ffff               call      0x4ba380
004bd2a8 e953070000               jmp       0x4bda00
004bd2ad 8b8e28170000             mov       ecx, dword ptr [esi + 0x1728]
004bd2b3 33ff                     xor       edi, edi
004bd2b5 b802000000               mov       eax, 2
004bd2ba 3bc8                     cmp       ecx, eax
004bd2bc 897de8                   mov       dword ptr [ebp - 0x18], edi
004bd2bf 897de4                   mov       dword ptr [ebp - 0x1c], edi
004bd2c2 897de0                   mov       dword ptr [ebp - 0x20], edi
004bd2c5 0f8590000000             jne       0x4bd35b
004bd2cb 8945fc                   mov       dword ptr [ebp - 4], eax
004bd2ce 8d45ec                   lea       eax, [ebp - 0x14]
004bd2d1 50                       push      eax
004bd2d2 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd2d5 c745ec04000000           mov       dword ptr [ebp - 0x14], 4
004bd2dc e83f9ef4ff               call      0x407120
004bd2e1 8d4dec                   lea       ecx, [ebp - 0x14]
004bd2e4 51                       push      ecx
004bd2e5 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd2e8 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd2eb e8309ef4ff               call      0x407120
004bd2f0 8d55ec                   lea       edx, [ebp - 0x14]
004bd2f3 52                       push      edx
004bd2f4 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd2f7 c745ec01000000           mov       dword ptr [ebp - 0x14], 1
004bd2fe e81d9ef4ff               call      0x407120
004bd303 8d8e38170000             lea       ecx, [esi + 0x1738]
004bd309 e8524df4ff               call      0x402060
004bd30e 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd311 8d45ec                   lea       eax, [ebp - 0x14]
004bd314 50                       push      eax
004bd315 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd318 e8039ef4ff               call      0x407120
004bd31d 8d8e30170000             lea       ecx, [esi + 0x1730]
004bd323 e8384df4ff               call      0x402060
004bd328 8d4dec                   lea       ecx, [ebp - 0x14]
004bd32b 51                       push      ecx
004bd32c 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd32f 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd332 e8e99df4ff               call      0x407120
004bd337 8b16                     mov       edx, dword ptr [esi]
004bd339 57                       push      edi
004bd33a 57                       push      edi
004bd33b 6a03                     push      3
004bd33d 8d45dc                   lea       eax, [ebp - 0x24]
004bd340 50                       push      eax
004bd341 6a04                     push      4
004bd343 8bce                     mov       ecx, esi
004bd345 ff928c020000             call      dword ptr [edx + 0x28c]
004bd34b 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd34e 895dfc                   mov       dword ptr [ebp - 4], ebx
004bd351 e8fa791800               call      0x644d50
004bd356 e9a5060000               jmp       0x4bda00
004bd35b 8d4dec                   lea       ecx, [ebp - 0x14]
004bd35e 51                       push      ecx
004bd35f 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd362 c745fc03000000           mov       dword ptr [ebp - 4], 3
004bd369 c745ec04000000           mov       dword ptr [ebp - 0x14], 4
004bd370 e8ab9df4ff               call      0x407120
004bd375 8d55ec                   lea       edx, [ebp - 0x14]
004bd378 52                       push      edx
004bd379 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd37c c745ec01000000           mov       dword ptr [ebp - 0x14], 1
004bd383 e8989df4ff               call      0x407120
004bd388 8d45ec                   lea       eax, [ebp - 0x14]
004bd38b 50                       push      eax
004bd38c 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd38f 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd392 e8899df4ff               call      0x407120
004bd397 8d8e0c170000             lea       ecx, [esi + 0x170c]
004bd39d e8be4cf4ff               call      0x402060
004bd3a2 8d4dec                   lea       ecx, [ebp - 0x14]
004bd3a5 51                       push      ecx
004bd3a6 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd3a9 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd3ac e86f9df4ff               call      0x407120
004bd3b1 8d8e14170000             lea       ecx, [esi + 0x1714]
004bd3b7 e8a44cf4ff               call      0x402060
004bd3bc 8bc8                     mov       ecx, eax
004bd3be b867666666               mov       eax, 0x66666667
004bd3c3 f7e9                     imul      ecx
004bd3c5 d1fa                     sar       edx, 1
004bd3c7 8bc2                     mov       eax, edx
004bd3c9 c1e81f                   shr       eax, 0x1f
004bd3cc 03c2                     add       eax, edx
004bd3ce e955ffffff               jmp       0x4bd328
004bd3d3 8bcf                     mov       ecx, edi
004bd3d5 e8864cf4ff               call      0x402060
004bd3da 83f801                   cmp       eax, 1
004bd3dd 0f8599010000             jne       0x4bd57c
004bd3e3 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd3e9 8b08                     mov       ecx, dword ptr [eax]
004bd3eb 85c9                     test      ecx, ecx
004bd3ed 7503                     jne       0x4bd3f2
004bd3ef 8d4808                   lea       ecx, [eax + 8]
004bd3f2 8b11                     mov       edx, dword ptr [ecx]
004bd3f4 6a02                     push      2
004bd3f6 ff5208                   call      dword ptr [edx + 8]
004bd3f9 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004bd3ff 85c0                     test      eax, eax
004bd401 747a                     je        0x4bd47d
004bd403 dc1d60b2cc00             fcomp     qword ptr [0xccb260]
004bd409 8b9824010000             mov       ebx, dword ptr [eax + 0x124]
004bd40f dfe0                     fnstsw    ax
004bd411 f6c441                   test      ah, 0x41
004bd414 7469                     je        0x4bd47f
004bd416 8dbef4160000             lea       edi, [esi + 0x16f4]
004bd41c 8bcf                     mov       ecx, edi
004bd41e e83d4cf4ff               call      0x402060
004bd423 3bd8                     cmp       ebx, eax
004bd425 7558                     jne       0x4bd47f
004bd427 8d8efc160000             lea       ecx, [esi + 0x16fc]
004bd42d e82e4cf4ff               call      0x402060
004bd432 8bcf                     mov       ecx, edi
004bd434 8bd8                     mov       ebx, eax
004bd436 e8254cf4ff               call      0x402060
004bd43b 3bc3                     cmp       eax, ebx
004bd43d 7440                     je        0x4bd47f
004bd43f 8b06                     mov       eax, dword ptr [esi]
004bd441 8bce                     mov       ecx, esi
004bd443 ff9004010000             call      dword ptr [eax + 0x104]
004bd449 85c0                     test      eax, eax
004bd44b 8bcf                     mov       ecx, edi
004bd44d 741a                     je        0x4bd469
004bd44f e80c4cf4ff               call      0x402060
004bd454 8b16                     mov       edx, dword ptr [esi]
004bd456 40                       inc       eax
004bd457 50                       push      eax
004bd458 8bce                     mov       ecx, esi
004bd45a ff9204010000             call      dword ptr [edx + 0x104]
004bd460 8bc8                     mov       ecx, eax
004bd462 e849315700               call      0xa305b0
004bd467 eb16                     jmp       0x4bd47f
004bd469 e8f24bf4ff               call      0x402060
004bd46e 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bd474 40                       inc       eax
004bd475 50                       push      eax
004bd476 e8e5ceffff               call      0x4ba360
004bd47b eb02                     jmp       0x4bd47f
004bd47d ddd8                     fstp      st(0)
004bd47f 8bce                     mov       ecx, esi
004bd481 e80aecfdff               call      0x49c090
004bd486 84c0                     test      al, al
004bd488 0f8472050000             je        0x4bda00
004bd48e 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd494 8b08                     mov       ecx, dword ptr [eax]
004bd496 85c9                     test      ecx, ecx
004bd498 7503                     jne       0x4bd49d
004bd49a 8d4808                   lea       ecx, [eax + 8]
004bd49d 8b01                     mov       eax, dword ptr [ecx]
004bd49f 6a02                     push      2
004bd4a1 ff5008                   call      dword ptr [eax + 8]
004bd4a4 d81da4d7e900             fcomp     dword ptr [0xe9d7a4]
004bd4aa dfe0                     fnstsw    ax
004bd4ac f6c405                   test      ah, 5
004bd4af 0f8a4b050000             jp        0x4bda00
004bd4b5 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bd4bb 83b9f400000004           cmp       dword ptr [ecx + 0xf4], 4
004bd4c2 0f8538050000             jne       0x4bda00
004bd4c8 8b86b0010000             mov       eax, dword ptr [esi + 0x1b0]
004bd4ce 85c0                     test      eax, eax
004bd4d0 0f852a050000             jne       0x4bda00
004bd4d6 83be6c160000ff           cmp       dword ptr [esi + 0x166c], -1
004bd4dd 742d                     je        0x4bd50c
004bd4df 8d8ea0000000             lea       ecx, [esi + 0xa0]
004bd4e5 e8169a6400               call      0xb06f00
004bd4ea 3b866c160000             cmp       eax, dword ptr [esi + 0x166c]
004bd4f0 7c1a                     jl        0x4bd50c
004bd4f2 8b16                     mov       edx, dword ptr [esi]
004bd4f4 8bce                     mov       ecx, esi
004bd4f6 ff92dc030000             call      dword ptr [edx + 0x3dc]
004bd4fc 84c0                     test      al, al
004bd4fe 750c                     jne       0x4bd50c
004bd500 8bce                     mov       ecx, esi
004bd502 e879ceffff               call      0x4ba380
004bd507 e9f4040000               jmp       0x4bda00
004bd50c 33ff                     xor       edi, edi
004bd50e 897de0                   mov       dword ptr [ebp - 0x20], edi
004bd511 897de4                   mov       dword ptr [ebp - 0x1c], edi
004bd514 897de8                   mov       dword ptr [ebp - 0x18], edi
004bd517 8d45ec                   lea       eax, [ebp - 0x14]
004bd51a bb04000000               mov       ebx, 4
004bd51f 50                       push      eax
004bd520 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd523 895dfc                   mov       dword ptr [ebp - 4], ebx
004bd526 895dec                   mov       dword ptr [ebp - 0x14], ebx
004bd529 e8f29bf4ff               call      0x407120
004bd52e 8d4dec                   lea       ecx, [ebp - 0x14]
004bd531 51                       push      ecx
004bd532 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd535 c745ec02000000           mov       dword ptr [ebp - 0x14], 2
004bd53c e8df9bf4ff               call      0x407120
004bd541 8d55ec                   lea       edx, [ebp - 0x14]
004bd544 52                       push      edx
004bd545 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd548 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd54b e8d09bf4ff               call      0x407120
004bd550 8d45ec                   lea       eax, [ebp - 0x14]
004bd553 50                       push      eax
004bd554 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd557 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd55a e8c19bf4ff               call      0x407120
004bd55f 8d4dec                   lea       ecx, [ebp - 0x14]
004bd562 51                       push      ecx
004bd563 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd566 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd569 e8b29bf4ff               call      0x407120
004bd56e 57                       push      edi
004bd56f 57                       push      edi
004bd570 6a03                     push      3
004bd572 8d45dc                   lea       eax, [ebp - 0x24]
004bd575 50                       push      eax
004bd576 53                       push      ebx
004bd577 e97b030000               jmp       0x4bd8f7
004bd57c 8bcf                     mov       ecx, edi
004bd57e e8dd4af4ff               call      0x402060
004bd583 83f802                   cmp       eax, 2
004bd586 0f8574040000             jne       0x4bda00
004bd58c 8bce                     mov       ecx, esi
004bd58e e8fdeafdff               call      0x49c090
004bd593 84c0                     test      al, al
004bd595 0f8465040000             je        0x4bda00
004bd59b 8b16                     mov       edx, dword ptr [esi]
004bd59d 8bce                     mov       ecx, esi
004bd59f ff92dc030000             call      dword ptr [edx + 0x3dc]
004bd5a5 84c0                     test      al, al
004bd5a7 744e                     je        0x4bd5f7
004bd5a9 8b86a0040000             mov       eax, dword ptr [esi + 0x4a0]
004bd5af 83f805                   cmp       eax, 5
004bd5b2 7443                     je        0x4bd5f7
004bd5b4 83f804                   cmp       eax, 4
004bd5b7 743e                     je        0x4bd5f7
004bd5b9 8b86b0010000             mov       eax, dword ptr [esi + 0x1b0]
004bd5bf 33ff                     xor       edi, edi
004bd5c1 3bc7                     cmp       eax, edi
004bd5c3 7532                     jne       0x4bd5f7
004bd5c5 897de0                   mov       dword ptr [ebp - 0x20], edi
004bd5c8 897de4                   mov       dword ptr [ebp - 0x1c], edi
004bd5cb 897de8                   mov       dword ptr [ebp - 0x18], edi
004bd5ce 8d45ec                   lea       eax, [ebp - 0x14]
004bd5d1 50                       push      eax
004bd5d2 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd5d5 c745fc05000000           mov       dword ptr [ebp - 4], 5
004bd5dc c745ec01000000           mov       dword ptr [ebp - 0x14], 1
004bd5e3 e8389bf4ff               call      0x407120
004bd5e8 57                       push      edi
004bd5e9 57                       push      edi
004bd5ea 6a03                     push      3
004bd5ec 8d45dc                   lea       eax, [ebp - 0x24]
004bd5ef 50                       push      eax
004bd5f0 6a05                     push      5
004bd5f2 e900030000               jmp       0x4bd8f7
004bd5f7 8b16                     mov       edx, dword ptr [esi]
004bd5f9 8bce                     mov       ecx, esi
004bd5fb ff92f4000000             call      dword ptr [edx + 0xf4]
004bd601 85c0                     test      eax, eax
004bd603 7414                     je        0x4bd619
004bd605 8b06                     mov       eax, dword ptr [esi]
004bd607 8bce                     mov       ecx, esi
004bd609 ff90f4000000             call      dword ptr [eax + 0xf4]
004bd60f 8a883a010000             mov       cl, byte ptr [eax + 0x13a]
004bd615 84c9                     test      cl, cl
004bd617 7524                     jne       0x4bd63d
004bd619 83be6c160000ff           cmp       dword ptr [esi + 0x166c], -1
004bd620 0f84da030000             je        0x4bda00
004bd626 8d8ea0000000             lea       ecx, [esi + 0xa0]
004bd62c e8cf986400               call      0xb06f00
004bd631 3b866c160000             cmp       eax, dword ptr [esi + 0x166c]
004bd637 0f8cc3030000             jl        0x4bda00
004bd63d 8bce                     mov       ecx, esi
004bd63f e83ccdffff               call      0x4ba380
004bd644 e9b7030000               jmp       0x4bda00
004bd649 8b16                     mov       edx, dword ptr [esi]
004bd64b 6811020000               push      0x211
004bd650 8bce                     mov       ecx, esi
004bd652 ff522c                   call      dword ptr [edx + 0x2c]
004bd655 84c0                     test      al, al
004bd657 0f84a3030000             je        0x4bda00
004bd65d 8b06                     mov       eax, dword ptr [esi]
004bd65f 8bce                     mov       ecx, esi
004bd661 ff90a0050000             call      dword ptr [eax + 0x5a0]
004bd667 84c0                     test      al, al
004bd669 0f8591030000             jne       0x4bda00
004bd66f 8b0d48280001             mov       ecx, dword ptr [0x1002848]
004bd675 83b9a819000002           cmp       dword ptr [ecx + 0x19a8], 2
004bd67c 0f847e030000             je        0x4bda00
004bd682 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004bd688 6a00                     push      0
004bd68a 6a02                     push      2
004bd68c e8af390500               call      0x511040
004bd691 e96a030000               jmp       0x4bda00
004bd696 8dbe88170000             lea       edi, [esi + 0x1788]
004bd69c 8bcf                     mov       ecx, edi
004bd69e e8bd49f4ff               call      0x402060
004bd6a3 85c0                     test      eax, eax
004bd6a5 0f8583000000             jne       0x4bd72e
004bd6ab 8b16                     mov       edx, dword ptr [esi]
004bd6ad 8bce                     mov       ecx, esi
004bd6af ff92f4000000             call      dword ptr [edx + 0xf4]
004bd6b5 85c0                     test      eax, eax
004bd6b7 0f8443030000             je        0x4bda00
004bd6bd 8b06                     mov       eax, dword ptr [esi]
004bd6bf 8bce                     mov       ecx, esi
004bd6c1 ff90f4000000             call      dword ptr [eax + 0xf4]
004bd6c7 8b16                     mov       edx, dword ptr [esi]
004bd6c9 8bb824010000             mov       edi, dword ptr [eax + 0x124]
004bd6cf 8bce                     mov       ecx, esi
004bd6d1 ff92b8040000             call      dword ptr [edx + 0x4b8]
004bd6d7 3bf8                     cmp       edi, eax
004bd6d9 0f8c21030000             jl        0x4bda00
004bd6df 33ff                     xor       edi, edi
004bd6e1 897de0                   mov       dword ptr [ebp - 0x20], edi
004bd6e4 897de4                   mov       dword ptr [ebp - 0x1c], edi
004bd6e7 897de8                   mov       dword ptr [ebp - 0x18], edi
004bd6ea 8d45ec                   lea       eax, [ebp - 0x14]
004bd6ed 50                       push      eax
004bd6ee 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd6f1 c745fc06000000           mov       dword ptr [ebp - 4], 6
004bd6f8 c745ec01000000           mov       dword ptr [ebp - 0x14], 1
004bd6ff e81c9af4ff               call      0x407120
004bd704 8d4dec                   lea       ecx, [ebp - 0x14]
004bd707 51                       push      ecx
004bd708 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd70b 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd70e e80d9af4ff               call      0x407120
004bd713 8b16                     mov       edx, dword ptr [esi]
004bd715 6a03                     push      3
004bd717 8bce                     mov       ecx, esi
004bd719 ff9244030000             call      dword ptr [edx + 0x344]
004bd71f 8bc8                     mov       ecx, eax
004bd721 e85a060000               call      0x4bdd80
004bd726 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd729 e9b4010000               jmp       0x4bd8e2
004bd72e 8bcf                     mov       ecx, edi
004bd730 e82b49f4ff               call      0x402060
004bd735 83f801                   cmp       eax, 1
004bd738 0f85d7010000             jne       0x4bd915
004bd73e 8d9ef4170000             lea       ebx, [esi + 0x17f4]
004bd744 8bcb                     mov       ecx, ebx
004bd746 e81549f4ff               call      0x402060
004bd74b 85c0                     test      eax, eax
004bd74d 754a                     jne       0x4bd799
004bd74f 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
004bd752 83ff04                   cmp       edi, 4
004bd755 7442                     je        0x4bd799
004bd757 8b16                     mov       edx, dword ptr [esi]
004bd759 8bce                     mov       ecx, esi
004bd75b ff92c0000000             call      dword ptr [edx + 0xc0]
004bd761 3bf8                     cmp       edi, eax
004bd763 7434                     je        0x4bd799
004bd765 8d8e90170000             lea       ecx, [esi + 0x1790]
004bd76b e8f048f4ff               call      0x402060
004bd770 85c0                     test      eax, eax
004bd772 7525                     jne       0x4bd799
004bd774 8d8e04180000             lea       ecx, [esi + 0x1804]
004bd77a e8e148f4ff               call      0x402060
004bd77f 85c0                     test      eax, eax
004bd781 7516                     jne       0x4bd799
004bd783 8b06                     mov       eax, dword ptr [esi]
004bd785 57                       push      edi
004bd786 8bce                     mov       ecx, esi
004bd788 ff90bc000000             call      dword ptr [eax + 0xbc]
004bd78e 8b16                     mov       edx, dword ptr [esi]
004bd790 57                       push      edi
004bd791 8bce                     mov       ecx, esi
004bd793 ff92b8000000             call      dword ptr [edx + 0xb8]
004bd799 8b06                     mov       eax, dword ptr [esi]
004bd79b 8bce                     mov       ecx, esi
004bd79d ff90f4000000             call      dword ptr [eax + 0xf4]
004bd7a3 85c0                     test      eax, eax
004bd7a5 0f84b9000000             je        0x4bd864
004bd7ab 8b16                     mov       edx, dword ptr [esi]
004bd7ad 8bce                     mov       ecx, esi
004bd7af ff9280030000             call      dword ptr [edx + 0x380]
004bd7b5 8bf8                     mov       edi, eax
004bd7b7 8b06                     mov       eax, dword ptr [esi]
004bd7b9 8bce                     mov       ecx, esi
004bd7bb ff90f4000000             call      dword ptr [eax + 0xf4]
004bd7c1 3bc7                     cmp       eax, edi
004bd7c3 0f859b000000             jne       0x4bd864
004bd7c9 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd7cf 8b08                     mov       ecx, dword ptr [eax]
004bd7d1 85c9                     test      ecx, ecx
004bd7d3 7503                     jne       0x4bd7d8
004bd7d5 8d4808                   lea       ecx, [eax + 8]
004bd7d8 8b11                     mov       edx, dword ptr [ecx]
004bd7da 6a02                     push      2
004bd7dc ff5208                   call      dword ptr [edx + 8]
004bd7df d95dec                   fstp      dword ptr [ebp - 0x14]
004bd7e2 8b06                     mov       eax, dword ptr [esi]
004bd7e4 8bce                     mov       ecx, esi
004bd7e6 ff90f4000000             call      dword ptr [eax + 0xf4]
004bd7ec d945ec                   fld       dword ptr [ebp - 0x14]
004bd7ef dc1d60b2cc00             fcomp     qword ptr [0xccb260]
004bd7f5 8bb824010000             mov       edi, dword ptr [eax + 0x124]
004bd7fb dfe0                     fnstsw    ax
004bd7fd f6c441                   test      ah, 0x41
004bd800 7462                     je        0x4bd864
004bd802 8b16                     mov       edx, dword ptr [esi]
004bd804 8bce                     mov       ecx, esi
004bd806 ff92bc040000             call      dword ptr [edx + 0x4bc]
004bd80c 3bf8                     cmp       edi, eax
004bd80e 7d54                     jge       0x4bd864
004bd810 8b06                     mov       eax, dword ptr [esi]
004bd812 8bce                     mov       ecx, esi
004bd814 ff9004010000             call      dword ptr [eax + 0x104]
004bd81a 85c0                     test      eax, eax
004bd81c 8b16                     mov       edx, dword ptr [esi]
004bd81e 8bce                     mov       ecx, esi
004bd820 741a                     je        0x4bd83c
004bd822 ff92bc040000             call      dword ptr [edx + 0x4bc]
004bd828 50                       push      eax
004bd829 8b06                     mov       eax, dword ptr [esi]
004bd82b 8bce                     mov       ecx, esi
004bd82d ff9004010000             call      dword ptr [eax + 0x104]
004bd833 8bc8                     mov       ecx, eax
004bd835 e8762d5700               call      0xa305b0
004bd83a eb12                     jmp       0x4bd84e
004bd83c ff92bc040000             call      dword ptr [edx + 0x4bc]
004bd842 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bd848 50                       push      eax
004bd849 e812cbffff               call      0x4ba360
004bd84e 8b06                     mov       eax, dword ptr [esi]
004bd850 8bce                     mov       ecx, esi
004bd852 ff90bc040000             call      dword ptr [eax + 0x4bc]
004bd858 8b8e04010000             mov       ecx, dword ptr [esi + 0x104]
004bd85e 50                       push      eax
004bd85f e8fccaffff               call      0x4ba360
004bd864 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd86a 8b08                     mov       ecx, dword ptr [eax]
004bd86c 85c9                     test      ecx, ecx
004bd86e 7503                     jne       0x4bd873
004bd870 8d4808                   lea       ecx, [eax + 8]
004bd873 8b11                     mov       edx, dword ptr [ecx]
004bd875 6a02                     push      2
004bd877 ff5208                   call      dword ptr [edx + 8]
004bd87a d81da4d7e900             fcomp     dword ptr [0xe9d7a4]
004bd880 dfe0                     fnstsw    ax
004bd882 f6c405                   test      ah, 5
004bd885 0f8a75010000             jp        0x4bda00
004bd88b 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd891 83b8f400000004           cmp       dword ptr [eax + 0xf4], 4
004bd898 0f8562010000             jne       0x4bda00
004bd89e 33ff                     xor       edi, edi
004bd8a0 897de0                   mov       dword ptr [ebp - 0x20], edi
004bd8a3 897de4                   mov       dword ptr [ebp - 0x1c], edi
004bd8a6 897de8                   mov       dword ptr [ebp - 0x18], edi
004bd8a9 8d4dec                   lea       ecx, [ebp - 0x14]
004bd8ac 51                       push      ecx
004bd8ad 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd8b0 c745fc07000000           mov       dword ptr [ebp - 4], 7
004bd8b7 c745ec02000000           mov       dword ptr [ebp - 0x14], 2
004bd8be e85d98f4ff               call      0x407120
004bd8c3 8bcb                     mov       ecx, ebx
004bd8c5 e89647f4ff               call      0x402060
004bd8ca f7d8                     neg       eax
004bd8cc 1bc0                     sbb       eax, eax
004bd8ce 8d55ec                   lea       edx, [ebp - 0x14]
004bd8d1 f7d8                     neg       eax
004bd8d3 52                       push      edx
004bd8d4 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd8d7 8945ec                   mov       dword ptr [ebp - 0x14], eax
004bd8da e84198f4ff               call      0x407120
004bd8df 897dec                   mov       dword ptr [ebp - 0x14], edi
004bd8e2 8d45ec                   lea       eax, [ebp - 0x14]
004bd8e5 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd8e8 50                       push      eax
004bd8e9 e83298f4ff               call      0x407120
004bd8ee 57                       push      edi
004bd8ef 57                       push      edi
004bd8f0 57                       push      edi
004bd8f1 8d45dc                   lea       eax, [ebp - 0x24]
004bd8f4 50                       push      eax
004bd8f5 6a06                     push      6
004bd8f7 8b16                     mov       edx, dword ptr [esi]
004bd8f9 8bce                     mov       ecx, esi
004bd8fb ff928c020000             call      dword ptr [edx + 0x28c]
004bd901 8d4ddc                   lea       ecx, [ebp - 0x24]
004bd904 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004bd90b e840741800               call      0x644d50
004bd910 e9eb000000               jmp       0x4bda00
004bd915 8bcf                     mov       ecx, edi
004bd917 e84447f4ff               call      0x402060
004bd91c 83f802                   cmp       eax, 2
004bd91f 0f85db000000             jne       0x4bda00
004bd925 8d8ef4170000             lea       ecx, [esi + 0x17f4]
004bd92b e83047f4ff               call      0x402060
004bd930 85c0                     test      eax, eax
004bd932 7439                     je        0x4bd96d
004bd934 8d8efc170000             lea       ecx, [esi + 0x17fc]
004bd93a e82147f4ff               call      0x402060
004bd93f 8d8e64150000             lea       ecx, [esi + 0x1564]
004bd945 8bf8                     mov       edi, eax
004bd947 e8b4956400               call      0xb06f00
004bd94c 3bc7                     cmp       eax, edi
004bd94e 0f8cac000000             jl        0x4bda00
004bd954 8b16                     mov       edx, dword ptr [esi]
004bd956 6a00                     push      0
004bd958 6a00                     push      0
004bd95a 6a00                     push      0
004bd95c 6a00                     push      0
004bd95e 6a00                     push      0
004bd960 8bce                     mov       ecx, esi
004bd962 ff928c020000             call      dword ptr [edx + 0x28c]
004bd968 e993000000               jmp       0x4bda00
004bd96d 8b06                     mov       eax, dword ptr [esi]
004bd96f 8bce                     mov       ecx, esi
004bd971 ff90f4000000             call      dword ptr [eax + 0xf4]
004bd977 85c0                     test      eax, eax
004bd979 0f8481000000             je        0x4bda00
004bd97f 8b16                     mov       edx, dword ptr [esi]
004bd981 8bce                     mov       ecx, esi
004bd983 ff92f4000000             call      dword ptr [edx + 0xf4]
004bd989 eb57                     jmp       0x4bd9e2
004bd98b 8b16                     mov       edx, dword ptr [esi]
004bd98d 8bce                     mov       ecx, esi
004bd98f ff92f4000000             call      dword ptr [edx + 0xf4]
004bd995 85c0                     test      eax, eax
004bd997 7422                     je        0x4bd9bb
004bd999 8b06                     mov       eax, dword ptr [esi]
004bd99b 8bce                     mov       ecx, esi
004bd99d ff90f4000000             call      dword ptr [eax + 0xf4]
004bd9a3 8a883a010000             mov       cl, byte ptr [eax + 0x13a]
004bd9a9 84c9                     test      cl, cl
004bd9ab 740e                     je        0x4bd9bb
004bd9ad 8b16                     mov       edx, dword ptr [esi]
004bd9af 6a00                     push      0
004bd9b1 8bce                     mov       ecx, esi
004bd9b3 ff9268040000             call      dword ptr [edx + 0x468]
004bd9b9 eb45                     jmp       0x4bda00
004bd9bb 8b86f8000000             mov       eax, dword ptr [esi + 0xf8]
004bd9c1 83b8f400000004           cmp       dword ptr [eax + 0xf4], 4
004bd9c8 7536                     jne       0x4bda00
004bd9ca 8b16                     mov       edx, dword ptr [esi]
004bd9cc 6a01                     push      1
004bd9ce 8bce                     mov       ecx, esi
004bd9d0 ff9268040000             call      dword ptr [edx + 0x468]
004bd9d6 eb28                     jmp       0x4bda00
004bd9d8 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004bd9de 85c0                     test      eax, eax
004bd9e0 741e                     je        0x4bda00
004bd9e2 8a883a010000             mov       cl, byte ptr [eax + 0x13a]
004bd9e8 84c9                     test      cl, cl
004bd9ea 7414                     je        0x4bda00
004bd9ec 6a00                     push      0
004bd9ee 6a00                     push      0
004bd9f0 8bce                     mov       ecx, esi
004bd9f2 8b06                     mov       eax, dword ptr [esi]
004bd9f4 6a00                     push      0
004bd9f6 6a00                     push      0
004bd9f8 6a00                     push      0
004bd9fa ff908c020000             call      dword ptr [eax + 0x28c]
004bda00 8b8e0c190000             mov       ecx, dword ptr [esi + 0x190c]
004bda06 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004bda0c 8b8610190000             mov       eax, dword ptr [esi + 0x1910]
004bda12 8d9e0c190000             lea       ebx, [esi + 0x190c]
004bda18 33cf                     xor       ecx, edi
004bda1a 2bcb                     sub       ecx, ebx
004bda1c 3bc8                     cmp       ecx, eax
004bda1e 740e                     je        0x4bda2e
004bda20 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004bda26 6a3f                     push      0x3f
004bda28 53                       push      ebx
004bda29 e882966500               call      0xb170b0
004bda2e 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004bda34 8b4a44                   mov       ecx, dword ptr [edx + 0x44]
004bda37 8b4304                   mov       eax, dword ptr [ebx + 4]
004bda3a 8b5248                   mov       edx, dword ptr [edx + 0x48]
004bda3d c1e002                   shl       eax, 2
004bda40 8b3c01                   mov       edi, dword ptr [ecx + eax]
004bda43 03c8                     add       ecx, eax
004bda45 03c2                     add       eax, edx
004bda47 33f9                     xor       edi, ecx
004bda49 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004bda4f 8bd0                     mov       edx, eax
004bda51 33d1                     xor       edx, ecx
004bda53 33f9                     xor       edi, ecx
004bda55 3310                     xor       edx, dword ptr [eax]
004bda57 3bfa                     cmp       edi, edx
004bda59 740e                     je        0x4bda69
004bda5b 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004bda61 6a40                     push      0x40
004bda63 53                       push      ebx
004bda64 e847966500               call      0xb170b0
004bda69 85ff                     test      edi, edi
004bda6b 7450                     je        0x4bdabd
004bda6d 81c6fc180000             add       esi, 0x18fc
004bda73 8d4e38                   lea       ecx, [esi + 0x38]
004bda76 e8e545f4ff               call      0x402060
004bda7b 8bce                     mov       ecx, esi
004bda7d 8bf8                     mov       edi, eax
004bda7f e87c946400               call      0xb06f00
004bda84 3bc7                     cmp       eax, edi
004bda86 7c35                     jl        0x4bdabd
004bda88 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004bda8e 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004bda91 8b4304                   mov       eax, dword ptr [ebx + 4]
004bda94 8d0482                   lea       eax, [edx + eax*4]
004bda97 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004bda9d 8bc8                     mov       ecx, eax
004bda9f 33ca                     xor       ecx, edx
004bdaa1 8908                     mov       dword ptr [eax], ecx
004bdaa3 a1d8012101               mov       eax, dword ptr [0x12101d8]
004bdaa8 8b5304                   mov       edx, dword ptr [ebx + 4]
004bdaab 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004bdaae 8d0491                   lea       eax, [ecx + edx*4]
004bdab1 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004bdab7 8bd0                     mov       edx, eax
004bdab9 33d1                     xor       edx, ecx
004bdabb 8910                     mov       dword ptr [eax], edx
004bdabd 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004bdac0 5f                       pop       edi
004bdac1 5e                       pop       esi
004bdac2 5b                       pop       ebx
004bdac3 64890d00000000           mov       dword ptr fs:[0], ecx
004bdaca 8be5                     mov       esp, ebp
004bdacc 5d                       pop       ebp
004bdacd c3                       ret       
004bdace 8bff                     mov       edi, edi
