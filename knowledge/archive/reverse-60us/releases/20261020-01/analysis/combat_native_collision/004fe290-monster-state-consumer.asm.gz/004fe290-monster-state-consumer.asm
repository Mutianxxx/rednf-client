004fe290 55                       push      ebp
004fe291 8bec                     mov       ebp, esp
004fe293 6aff                     push      -1
004fe295 680b9dc500               push      0xc59d0b
004fe29a 64a100000000             mov       eax, dword ptr fs:[0]
004fe2a0 50                       push      eax
004fe2a1 64892500000000           mov       dword ptr fs:[0], esp
004fe2a8 83ec14                   sub       esp, 0x14
004fe2ab 56                       push      esi
004fe2ac 8bf1                     mov       esi, ecx
004fe2ae 57                       push      edi
004fe2af 8d8e5c150000             lea       ecx, [esi + 0x155c]
004fe2b5 e8a63df0ff               call      0x402060
004fe2ba 8bf8                     mov       edi, eax
004fe2bc 8d8e28180000             lea       ecx, [esi + 0x1828]
004fe2c2 897de8                   mov       dword ptr [ebp - 0x18], edi
004fe2c5 e8963df0ff               call      0x402060
004fe2ca 83ff0b                   cmp       edi, 0xb
004fe2cd 750a                     jne       0x4fe2d9
004fe2cf 837d080c                 cmp       dword ptr [ebp + 8], 0xc
004fe2d3 0f8535020000             jne       0x4fe50e
004fe2d9 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fe2df 85c9                     test      ecx, ecx
004fe2e1 53                       push      ebx
004fe2e2 7479                     je        0x4fe35d
004fe2e4 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004fe2ea 2bc1                     sub       eax, ecx
004fe2ec c1f804                   sar       eax, 4
004fe2ef 85c0                     test      eax, eax
004fe2f1 746a                     je        0x4fe35d
004fe2f3 c745f000000000           mov       dword ptr [ebp - 0x10], 0
004fe2fa 8d9b00000000             lea       ebx, [ebx]
004fe300 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fe306 85c9                     test      ecx, ecx
004fe308 7450                     je        0x4fe35a
004fe30a 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004fe310 2bc1                     sub       eax, ecx
004fe312 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004fe315 c1f804                   sar       eax, 4
004fe318 3bc8                     cmp       ecx, eax
004fe31a 733e                     jae       0x4fe35a
004fe31c 8bd9                     mov       ebx, ecx
004fe31e 33ff                     xor       edi, edi
004fe320 c1e304                   shl       ebx, 4
004fe323 8b86a0220000             mov       eax, dword ptr [esi + 0x22a0]
004fe329 8b540304                 mov       edx, dword ptr [ebx + eax + 4]
004fe32d 85d2                     test      edx, edx
004fe32f 8d0c03                   lea       ecx, [ebx + eax]
004fe332 7421                     je        0x4fe355
004fe334 8b4108                   mov       eax, dword ptr [ecx + 8]
004fe337 2bc2                     sub       eax, edx
004fe339 c1f802                   sar       eax, 2
004fe33c 3bf8                     cmp       edi, eax
004fe33e 7315                     jae       0x4fe355
004fe340 8bca                     mov       ecx, edx
004fe342 8b16                     mov       edx, dword ptr [esi]
004fe344 8d04b9                   lea       eax, [ecx + edi*4]
004fe347 8b00                     mov       eax, dword ptr [eax]
004fe349 50                       push      eax
004fe34a 8bce                     mov       ecx, esi
004fe34c ff92fc000000             call      dword ptr [edx + 0xfc]
004fe352 47                       inc       edi
004fe353 ebce                     jmp       0x4fe323
004fe355 ff45f0                   inc       dword ptr [ebp - 0x10]
004fe358 eba6                     jmp       0x4fe300
004fe35a 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
004fe35d 8d47fe                   lea       eax, [edi - 2]
004fe360 83f808                   cmp       eax, 8
004fe363 0f87de010000             ja        0x4fe547
004fe369 ff248544ef4f00           jmp       dword ptr [eax*4 + 0x4fef44]
004fe370 80bedf1c000001           cmp       byte ptr [esi + 0x1cdf], 1
004fe377 7507                     jne       0x4fe380
004fe379 8bce                     mov       ecx, esi
004fe37b e86029ffff               call      0x4f0ce0
004fe380 33db                     xor       ebx, ebx
004fe382 895df0                   mov       dword ptr [ebp - 0x10], ebx
004fe385 8b86e8220000             mov       eax, dword ptr [esi + 0x22e8]
004fe38b 85c0                     test      eax, eax
004fe38d 7454                     je        0x4fe3e3
004fe38f 8b8eec220000             mov       ecx, dword ptr [esi + 0x22ec]
004fe395 2bc8                     sub       ecx, eax
004fe397 b867666666               mov       eax, 0x66666667
004fe39c f7e9                     imul      ecx
004fe39e c1fa04                   sar       edx, 4
004fe3a1 8bc2                     mov       eax, edx
004fe3a3 c1e81f                   shr       eax, 0x1f
004fe3a6 03c2                     add       eax, edx
004fe3a8 3bd8                     cmp       ebx, eax
004fe3aa 7337                     jae       0x4fe3e3
004fe3ac 8bbee8220000             mov       edi, dword ptr [esi + 0x22e8]
004fe3b2 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004fe3b5 8d8e28180000             lea       ecx, [esi + 0x1828]
004fe3bb 03fa                     add       edi, edx
004fe3bd e89e3cf0ff               call      0x402060
004fe3c2 3b4704                   cmp       eax, dword ptr [edi + 4]
004fe3c5 7510                     jne       0x4fe3d7
004fe3c7 8b8e18230000             mov       ecx, dword ptr [esi + 0x2318]
004fe3cd 8d0499                   lea       eax, [ecx + ebx*4]
004fe3d0 8b08                     mov       ecx, dword ptr [eax]
004fe3d2 e889ea2400               call      0x74ce60
004fe3d7 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004fe3da 43                       inc       ebx
004fe3db 83c028                   add       eax, 0x28
004fe3de 8945f0                   mov       dword ptr [ebp - 0x10], eax
004fe3e1 eba2                     jmp       0x4fe385
004fe3e3 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fe3e9 c745f000000000           mov       dword ptr [ebp - 0x10], 0
004fe3f0 c745ec00000000           mov       dword ptr [ebp - 0x14], 0
004fe3f7 eb07                     jmp       0x4fe400
004fe3f9 8da42400000000           lea       esp, [esp]
004fe400 8b86881a0000             mov       eax, dword ptr [esi + 0x1a88]
004fe406 85c0                     test      eax, eax
004fe408 0f8439010000             je        0x4fe547
004fe40e 8b968c1a0000             mov       edx, dword ptr [esi + 0x1a8c]
004fe414 2bd0                     sub       edx, eax
004fe416 b8abaaaa2a               mov       eax, 0x2aaaaaab
004fe41b f7ea                     imul      edx
004fe41d c1fa02                   sar       edx, 2
004fe420 8bc2                     mov       eax, edx
004fe422 c1e81f                   shr       eax, 0x1f
004fe425 03c2                     add       eax, edx
004fe427 3945f0                   cmp       dword ptr [ebp - 0x10], eax
004fe42a 0f8317010000             jae       0x4fe547
004fe430 a1dc012101               mov       eax, dword ptr [0x12101dc]
004fe435 8b9628180000             mov       edx, dword ptr [esi + 0x1828]
004fe43b 8d9e28180000             lea       ebx, [esi + 0x1828]
004fe441 33d0                     xor       edx, eax
004fe443 8b4304                   mov       eax, dword ptr [ebx + 4]
004fe446 2bd3                     sub       edx, ebx
004fe448 3bd0                     cmp       edx, eax
004fe44a 740e                     je        0x4fe45a
004fe44c 6a3f                     push      0x3f
004fe44e 53                       push      ebx
004fe44f e85c8c6100               call      0xb170b0
004fe454 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fe45a 8b4304                   mov       eax, dword ptr [ebx + 4]
004fe45d 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fe460 c1e002                   shl       eax, 2
004fe463 8b3c02                   mov       edi, dword ptr [edx + eax]
004fe466 03d0                     add       edx, eax
004fe468 33fa                     xor       edi, edx
004fe46a 333ddc012101             xor       edi, dword ptr [0x12101dc]
004fe470 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fe473 03c2                     add       eax, edx
004fe475 8b10                     mov       edx, dword ptr [eax]
004fe477 33d0                     xor       edx, eax
004fe479 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fe47f 3bfa                     cmp       edi, edx
004fe481 740e                     je        0x4fe491
004fe483 6a40                     push      0x40
004fe485 53                       push      ebx
004fe486 e8258c6100               call      0xb170b0
004fe48b 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fe491 8b86881a0000             mov       eax, dword ptr [esi + 0x1a88]
004fe497 8b5dec                   mov       ebx, dword ptr [ebp - 0x14]
004fe49a 8b541804                 mov       edx, dword ptr [eax + ebx + 4]
004fe49e 03c3                     add       eax, ebx
004fe4a0 3bfa                     cmp       edi, edx
004fe4a2 751b                     jne       0x4fe4bf
004fe4a4 8b86481a0000             mov       eax, dword ptr [esi + 0x1a48]
004fe4aa 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004fe4ad 8d0488                   lea       eax, [eax + ecx*4]
004fe4b0 8b08                     mov       ecx, dword ptr [eax]
004fe4b2 8b11                     mov       edx, dword ptr [ecx]
004fe4b4 6a00                     push      0
004fe4b6 ff520c                   call      dword ptr [edx + 0xc]
004fe4b9 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fe4bf 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004fe4c2 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004fe4c5 42                       inc       edx
004fe4c6 83c018                   add       eax, 0x18
004fe4c9 8955f0                   mov       dword ptr [ebp - 0x10], edx
004fe4cc 8945ec                   mov       dword ptr [ebp - 0x14], eax
004fe4cf e92cffffff               jmp       0x4fe400
004fe4d4 6a00                     push      0
004fe4d6 6a00                     push      0
004fe4d8 8bce                     mov       ecx, esi
004fe4da e82160fbff               call      0x4b4500
004fe4df eb66                     jmp       0x4fe547
004fe4e1 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004fe4e7 8b8814010000             mov       ecx, dword ptr [eax + 0x114]
004fe4ed 8b5150                   mov       edx, dword ptr [ecx + 0x50]
004fe4f0 8b4260                   mov       eax, dword ptr [edx + 0x60]
004fe4f3 8b8e04020000             mov       ecx, dword ptr [esi + 0x204]
004fe4f9 8b5508                   mov       edx, dword ptr [ebp + 8]
004fe4fc 50                       push      eax
004fe4fd 51                       push      ecx
004fe4fe 52                       push      edx
004fe4ff 68985dcd00               push      0xcd5d98
004fe504 ff15bc2eff00             call      dword ptr [0xff2ebc]
004fe50a 83c410                   add       esp, 0x10
004fe50d 5b                       pop       ebx
004fe50e 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004fe511 5f                       pop       edi
004fe512 5e                       pop       esi
004fe513 64890d00000000           mov       dword ptr fs:[0], ecx
004fe51a 8be5                     mov       esp, ebp
004fe51c 5d                       pop       ebp
004fe51d c21000                   ret       0x10
004fe520 837d0801                 cmp       dword ptr [ebp + 8], 1
004fe524 7521                     jne       0x4fe547
004fe526 6aff                     push      -1
004fe528 6a1c                     push      0x1c
004fe52a 8bce                     mov       ecx, esi
004fe52c e8af1dffff               call      0x4f02e0
004fe531 8b06                     mov       eax, dword ptr [esi]
004fe533 8bce                     mov       ecx, esi
004fe535 ff90cc050000             call      dword ptr [eax + 0x5cc]
004fe53b eb0a                     jmp       0x4fe547
004fe53d c78644200000ffffffff     mov       dword ptr [esi + 0x2044], 0xffffffff
004fe547 8b4508                   mov       eax, dword ptr [ebp + 8]
004fe54a 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
004fe54d 83c0fd                   add       eax, -3
004fe550 83f80a                   cmp       eax, 0xa
004fe553 0f8735060000             ja        0x4feb8e
004fe559 0fb68880ef4f00           movzx     ecx, byte ptr [eax + 0x4fef80]
004fe560 ff248d68ef4f00           jmp       dword ptr [ecx*4 + 0x4fef68]
004fe567 8b4704                   mov       eax, dword ptr [edi + 4]
004fe56a 8b10                     mov       edx, dword ptr [eax]
004fe56c 899644200000             mov       dword ptr [esi + 0x2044], edx
004fe572 e917060000               jmp       0x4feb8e
004fe577 8b06                     mov       eax, dword ptr [esi]
004fe579 8bce                     mov       ecx, esi
004fe57b ff9070030000             call      dword ptr [eax + 0x370]
004fe581 398604010000             cmp       dword ptr [esi + 0x104], eax
004fe587 7506                     jne       0x4fe58f
004fe589 c6451400                 mov       byte ptr [ebp + 0x14], 0
004fe58d eb13                     jmp       0x4fe5a2
004fe58f 8b3e                     mov       edi, dword ptr [esi]
004fe591 8bce                     mov       ecx, esi
004fe593 ff9770030000             call      dword ptr [edi + 0x370]
004fe599 50                       push      eax
004fe59a 8bce                     mov       ecx, esi
004fe59c ff97f0000000             call      dword ptr [edi + 0xf0]
004fe5a2 8b16                     mov       edx, dword ptr [esi]
004fe5a4 6a00                     push      0
004fe5a6 6a00                     push      0
004fe5a8 6a00                     push      0
004fe5aa 6a00                     push      0
004fe5ac 6a00                     push      0
004fe5ae 6a00                     push      0
004fe5b0 8bce                     mov       ecx, esi
004fe5b2 ff9288040000             call      dword ptr [edx + 0x488]
004fe5b8 8b06                     mov       eax, dword ptr [esi]
004fe5ba 6a00                     push      0
004fe5bc 6a00                     push      0
004fe5be 6a00                     push      0
004fe5c0 6a00                     push      0
004fe5c2 6a00                     push      0
004fe5c4 6a01                     push      1
004fe5c6 8bce                     mov       ecx, esi
004fe5c8 ff9088040000             call      dword ptr [eax + 0x488]
004fe5ce 8b16                     mov       edx, dword ptr [esi]
004fe5d0 680000803f               push      0x3f800000
004fe5d5 680000803f               push      0x3f800000
004fe5da 68e8030000               push      0x3e8
004fe5df 68e8030000               push      0x3e8
004fe5e4 6a00                     push      0
004fe5e6 6a00                     push      0
004fe5e8 8bce                     mov       ecx, esi
004fe5ea ff9294040000             call      dword ptr [edx + 0x494]
004fe5f0 8b06                     mov       eax, dword ptr [esi]
004fe5f2 6a00                     push      0
004fe5f4 8bce                     mov       ecx, esi
004fe5f6 ff90d0020000             call      dword ptr [eax + 0x2d0]
004fe5fc 8b16                     mov       edx, dword ptr [esi]
004fe5fe 6a00                     push      0
004fe600 8bce                     mov       ecx, esi
004fe602 ff92d8020000             call      dword ptr [edx + 0x2d8]
004fe608 8b06                     mov       eax, dword ptr [esi]
004fe60a 6a02                     push      2
004fe60c 6a01                     push      1
004fe60e 8bce                     mov       ecx, esi
004fe610 ff90e0020000             call      dword ptr [eax + 0x2e0]
004fe616 8b8690200000             mov       eax, dword ptr [esi + 0x2090]
004fe61c 85c0                     test      eax, eax
004fe61e 753a                     jne       0x4fe65a
004fe620 68e8010000               push      0x1e8
004fe625 e82656f0ff               call      0x403c50
004fe62a 83c404                   add       esp, 4
004fe62d 8945e0                   mov       dword ptr [ebp - 0x20], eax
004fe630 85c0                     test      eax, eax
004fe632 c745fc00000000           mov       dword ptr [ebp - 4], 0
004fe639 7410                     je        0x4fe64b
004fe63b 6a01                     push      1
004fe63d 68001dcd00               push      0xcd1d00
004fe642 8bc8                     mov       ecx, eax
004fe644 e88750f9ff               call      0x4936d0
004fe649 eb02                     jmp       0x4fe64d
004fe64b 33c0                     xor       eax, eax
004fe64d c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004fe654 898690200000             mov       dword ptr [esi + 0x2090], eax
004fe65a 8b16                     mov       edx, dword ptr [esi]
004fe65c 8bce                     mov       ecx, esi
004fe65e ff92e4000000             call      dword ptr [edx + 0xe4]
004fe664 8b8e90200000             mov       ecx, dword ptr [esi + 0x2090]
004fe66a 8945ec                   mov       dword ptr [ebp - 0x14], eax
004fe66d db45ec                   fild      dword ptr [ebp - 0x14]
004fe670 d80df81ccd00             fmul      dword ptr [0xcd1cf8]
004fe676 d95dec                   fstp      dword ptr [ebp - 0x14]
004fe679 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004fe67c 50                       push      eax
004fe67d 50                       push      eax
004fe67e e87d725200               call      0xa25900
004fe683 8b8e90200000             mov       ecx, dword ptr [esi + 0x2090]
004fe689 8b06                     mov       eax, dword ptr [esi]
004fe68b 6a01                     push      1
004fe68d 6a00                     push      0
004fe68f 6a00                     push      0
004fe691 6a00                     push      0
004fe693 6a00                     push      0
004fe695 6a01                     push      1
004fe697 6a00                     push      0
004fe699 6a00                     push      0
004fe69b 51                       push      ecx
004fe69c 6a01                     push      1
004fe69e 8bce                     mov       ecx, esi
004fe6a0 ff90f8000000             call      dword ptr [eax + 0xf8]
004fe6a6 33ff                     xor       edi, edi
004fe6a8 8b16                     mov       edx, dword ptr [esi]
004fe6aa 57                       push      edi
004fe6ab 8bce                     mov       ecx, esi
004fe6ad ff9210040000             call      dword ptr [edx + 0x410]
004fe6b3 84c0                     test      al, al
004fe6b5 741b                     je        0x4fe6d2
004fe6b7 8b06                     mov       eax, dword ptr [esi]
004fe6b9 57                       push      edi
004fe6ba 8bce                     mov       ecx, esi
004fe6bc ff900c040000             call      dword ptr [eax + 0x40c]
004fe6c2 8b10                     mov       edx, dword ptr [eax]
004fe6c4 6a00                     push      0
004fe6c6 6a00                     push      0
004fe6c8 6a00                     push      0
004fe6ca 56                       push      esi
004fe6cb 6a00                     push      0
004fe6cd 8bc8                     mov       ecx, eax
004fe6cf ff5204                   call      dword ptr [edx + 4]
004fe6d2 47                       inc       edi
004fe6d3 83ff11                   cmp       edi, 0x11
004fe6d6 7cd0                     jl        0x4fe6a8
004fe6d8 e9b1040000               jmp       0x4feb8e
004fe6dd 6a00                     push      0
004fe6df e80cfa3a00               call      0x8ae0f0
004fe6e4 99                       cdq       
004fe6e5 b964000000               mov       ecx, 0x64
004fe6ea f7f9                     idiv      ecx
004fe6ec 83c404                   add       esp, 4
004fe6ef 83fa0f                   cmp       edx, 0xf
004fe6f2 0f8d96040000             jge       0x4feb8e
004fe6f8 8b16                     mov       edx, dword ptr [esi]
004fe6fa 6aff                     push      -1
004fe6fc 6a15                     push      0x15
004fe6fe 8bce                     mov       ecx, esi
004fe700 ff9244050000             call      dword ptr [edx + 0x544]
004fe706 e983040000               jmp       0x4feb8e
004fe70b 80bedf1c000001           cmp       byte ptr [esi + 0x1cdf], 1
004fe712 7507                     jne       0x4fe71b
004fe714 8bce                     mov       ecx, esi
004fe716 e85525ffff               call      0x4f0c70
004fe71b 8b4704                   mov       eax, dword ptr [edi + 4]
004fe71e 8b38                     mov       edi, dword ptr [eax]
004fe720 6a00                     push      0
004fe722 e8c9f93a00               call      0x8ae0f0
004fe727 99                       cdq       
004fe728 b964000000               mov       ecx, 0x64
004fe72d f7f9                     idiv      ecx
004fe72f 83c404                   add       esp, 4
004fe732 83fa0f                   cmp       edx, 0xf
004fe735 7d0d                     jge       0x4fe744
004fe737 8b16                     mov       edx, dword ptr [esi]
004fe739 6aff                     push      -1
004fe73b 57                       push      edi
004fe73c 8bce                     mov       ecx, esi
004fe73e ff9244050000             call      dword ptr [edx + 0x544]
004fe744 33ff                     xor       edi, edi
004fe746 8b866c220000             mov       eax, dword ptr [esi + 0x226c]
004fe74c 85c0                     test      eax, eax
004fe74e 7446                     je        0x4fe796
004fe750 8b8e70220000             mov       ecx, dword ptr [esi + 0x2270]
004fe756 2bc8                     sub       ecx, eax
004fe758 b8e9a28b2e               mov       eax, 0x2e8ba2e9
004fe75d f7e9                     imul      ecx
004fe75f c1fa03                   sar       edx, 3
004fe762 8bc2                     mov       eax, edx
004fe764 c1e81f                   shr       eax, 0x1f
004fe767 03c2                     add       eax, edx
004fe769 3bf8                     cmp       edi, eax
004fe76b 7329                     jae       0x4fe796
004fe76d 8b8e80220000             mov       ecx, dword ptr [esi + 0x2280]
004fe773 33c0                     xor       eax, eax
004fe775 8bc7                     mov       eax, edi
004fe777 8bd0                     mov       edx, eax
004fe779 c1ea05                   shr       edx, 5
004fe77c 8d1491                   lea       edx, [ecx + edx*4]
004fe77f 83e01f                   and       eax, 0x1f
004fe782 8bc8                     mov       ecx, eax
004fe784 bb01000000               mov       ebx, 1
004fe789 d3e3                     shl       ebx, cl
004fe78b 8b0a                     mov       ecx, dword ptr [edx]
004fe78d f7d3                     not       ebx
004fe78f 23cb                     and       ecx, ebx
004fe791 890a                     mov       dword ptr [edx], ecx
004fe793 47                       inc       edi
004fe794 ebb0                     jmp       0x4fe746
004fe796 8b8624220000             mov       eax, dword ptr [esi + 0x2224]
004fe79c 33d2                     xor       edx, edx
004fe79e 85c0                     test      eax, eax
004fe7a0 7639                     jbe       0x4fe7db
004fe7a2 33db                     xor       ebx, ebx
004fe7a4 8b8e2c220000             mov       ecx, dword ptr [esi + 0x222c]
004fe7aa 8bc3                     mov       eax, ebx
004fe7ac 03c2                     add       eax, edx
004fe7ae 8bf8                     mov       edi, eax
004fe7b0 c1ef05                   shr       edi, 5
004fe7b3 8d3cb9                   lea       edi, [ecx + edi*4]
004fe7b6 83e01f                   and       eax, 0x1f
004fe7b9 b901000000               mov       ecx, 1
004fe7be 894dec                   mov       dword ptr [ebp - 0x14], ecx
004fe7c1 8bc8                     mov       ecx, eax
004fe7c3 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004fe7c6 d3e0                     shl       eax, cl
004fe7c8 8b0f                     mov       ecx, dword ptr [edi]
004fe7ca f7d0                     not       eax
004fe7cc 23c8                     and       ecx, eax
004fe7ce 890f                     mov       dword ptr [edi], ecx
004fe7d0 8b8624220000             mov       eax, dword ptr [esi + 0x2224]
004fe7d6 42                       inc       edx
004fe7d7 3bd0                     cmp       edx, eax
004fe7d9 72c9                     jb        0x4fe7a4
004fe7db c6864822000000           mov       byte ptr [esi + 0x2248], 0
004fe7e2 e9a7030000               jmp       0x4feb8e
004fe7e7 8b8610250000             mov       eax, dword ptr [esi + 0x2510]
004fe7ed 85c0                     test      eax, eax
004fe7ef 7408                     je        0x4fe7f9
004fe7f1 50                       push      eax
004fe7f2 8bce                     mov       ecx, esi
004fe7f4 e8c774ffff               call      0x4f5cc0
004fe7f9 8b8e18240000             mov       ecx, dword ptr [esi + 0x2418]
004fe7ff 85c9                     test      ecx, ecx
004fe801 746e                     je        0x4fe871
004fe803 8b861c240000             mov       eax, dword ptr [esi + 0x241c]
004fe809 2bc1                     sub       eax, ecx
004fe80b c1f802                   sar       eax, 2
004fe80e 85c0                     test      eax, eax
004fe810 745f                     je        0x4fe871
004fe812 8b16                     mov       edx, dword ptr [esi]
004fe814 8bc1                     mov       eax, ecx
004fe816 8b00                     mov       eax, dword ptr [eax]
004fe818 50                       push      eax
004fe819 8bce                     mov       ecx, esi
004fe81b ff92fc000000             call      dword ptr [edx + 0xfc]
004fe821 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004fe827 8b4004                   mov       eax, dword ptr [eax + 4]
004fe82a 8b16                     mov       edx, dword ptr [esi]
004fe82c 50                       push      eax
004fe82d 8bce                     mov       ecx, esi
004fe82f ff92fc000000             call      dword ptr [edx + 0xfc]
004fe835 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004fe83b 8b4008                   mov       eax, dword ptr [eax + 8]
004fe83e 8b16                     mov       edx, dword ptr [esi]
004fe840 50                       push      eax
004fe841 8bce                     mov       ecx, esi
004fe843 ff92fc000000             call      dword ptr [edx + 0xfc]
004fe849 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004fe84f 8b400c                   mov       eax, dword ptr [eax + 0xc]
004fe852 8b16                     mov       edx, dword ptr [esi]
004fe854 50                       push      eax
004fe855 8bce                     mov       ecx, esi
004fe857 ff92fc000000             call      dword ptr [edx + 0xfc]
004fe85d 8b8618240000             mov       eax, dword ptr [esi + 0x2418]
004fe863 8b4010                   mov       eax, dword ptr [eax + 0x10]
004fe866 8b16                     mov       edx, dword ptr [esi]
004fe868 50                       push      eax
004fe869 8bce                     mov       ecx, esi
004fe86b ff92fc000000             call      dword ptr [edx + 0xfc]
004fe871 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fe877 85c9                     test      ecx, ecx
004fe879 7470                     je        0x4fe8eb
004fe87b 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004fe881 2bc1                     sub       eax, ecx
004fe883 c1f804                   sar       eax, 4
004fe886 85c0                     test      eax, eax
004fe888 7461                     je        0x4fe8eb
004fe88a c745f000000000           mov       dword ptr [ebp - 0x10], 0
004fe891 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fe897 85c9                     test      ecx, ecx
004fe899 744d                     je        0x4fe8e8
004fe89b 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004fe8a1 2bc1                     sub       eax, ecx
004fe8a3 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004fe8a6 c1f804                   sar       eax, 4
004fe8a9 3bc8                     cmp       ecx, eax
004fe8ab 733b                     jae       0x4fe8e8
004fe8ad 8bd9                     mov       ebx, ecx
004fe8af 33ff                     xor       edi, edi
004fe8b1 c1e304                   shl       ebx, 4
004fe8b4 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fe8ba 8b541904                 mov       edx, dword ptr [ecx + ebx + 4]
004fe8be 03cb                     add       ecx, ebx
004fe8c0 85d2                     test      edx, edx
004fe8c2 741f                     je        0x4fe8e3
004fe8c4 8b4108                   mov       eax, dword ptr [ecx + 8]
004fe8c7 2bc2                     sub       eax, edx
004fe8c9 c1f802                   sar       eax, 2
004fe8cc 3bf8                     cmp       edi, eax
004fe8ce 7313                     jae       0x4fe8e3
004fe8d0 8d04ba                   lea       eax, [edx + edi*4]
004fe8d3 8b00                     mov       eax, dword ptr [eax]
004fe8d5 8b16                     mov       edx, dword ptr [esi]
004fe8d7 50                       push      eax
004fe8d8 8bce                     mov       ecx, esi
004fe8da ff92fc000000             call      dword ptr [edx + 0xfc]
004fe8e0 47                       inc       edi
004fe8e1 ebd1                     jmp       0x4fe8b4
004fe8e3 ff45f0                   inc       dword ptr [ebp - 0x10]
004fe8e6 eba9                     jmp       0x4fe891
004fe8e8 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
004fe8eb 6a00                     push      0
004fe8ed e8fef73a00               call      0x8ae0f0
004fe8f2 99                       cdq       
004fe8f3 b964000000               mov       ecx, 0x64
004fe8f8 f7f9                     idiv      ecx
004fe8fa 83c404                   add       esp, 4
004fe8fd 83fa0f                   cmp       edx, 0xf
004fe900 7d0e                     jge       0x4fe910
004fe902 8b16                     mov       edx, dword ptr [esi]
004fe904 6aff                     push      -1
004fe906 6a16                     push      0x16
004fe908 8bce                     mov       ecx, esi
004fe90a ff9244050000             call      dword ptr [edx + 0x544]
004fe910 8b4704                   mov       eax, dword ptr [edi + 4]
004fe913 8b38                     mov       edi, dword ptr [eax]
004fe915 a148280001               mov       eax, dword ptr [0x1002848]
004fe91a 8b80a8190000             mov       eax, dword ptr [eax + 0x19a8]
004fe920 83f802                   cmp       eax, 2
004fe923 897dec                   mov       dword ptr [ebp - 0x14], edi
004fe926 750c                     jne       0x4fe934
004fe928 c786181e000064000000     mov       dword ptr [esi + 0x1e18], 0x64
004fe932 eb4a                     jmp       0x4fe97e
004fe934 8b16                     mov       edx, dword ptr [esi]
004fe936 8bce                     mov       ecx, esi
004fe938 ff9238020000             call      dword ptr [edx + 0x238]
004fe93e 8bd8                     mov       ebx, eax
004fe940 8b06                     mov       eax, dword ptr [esi]
004fe942 8bce                     mov       ecx, esi
004fe944 ff5040                   call      dword ptr [eax + 0x40]
004fe947 0fafd8                   imul      ebx, eax
004fe94a 8d4de4                   lea       ecx, [ebp - 0x1c]
004fe94d 51                       push      ecx
004fe94e 895de4                   mov       dword ptr [ebp - 0x1c], ebx
004fe951 e89af73a00               call      0x8ae0f0
004fe956 99                       cdq       
004fe957 b965000000               mov       ecx, 0x65
004fe95c f7f9                     idiv      ecx
004fe95e 6a64                     push      0x64
004fe960 52                       push      edx
004fe961 6800007a43               push      0x437a0000
004fe966 680000c842               push      0x42c80000
004fe96b e840b06000               call      0xb099b0
004fe970 83c414                   add       esp, 0x14
004fe973 e8cc2b7000               call      0xc01544
004fe978 8986181e0000             mov       dword ptr [esi + 0x1e18], eax
004fe97e 85ff                     test      edi, edi
004fe980 750f                     jne       0x4fe991
004fe982 8b16                     mov       edx, dword ptr [esi]
004fe984 8bce                     mov       ecx, esi
004fe986 ff9254060000             call      dword ptr [edx + 0x654]
004fe98c e9fd010000               jmp       0x4feb8e
004fe991 a148280001               mov       eax, dword ptr [0x1002848]
004fe996 83b8a819000002           cmp       dword ptr [eax + 0x19a8], 2
004fe99d 0f85a1000000             jne       0x4fea44
004fe9a3 8b86a01b0000             mov       eax, dword ptr [esi + 0x1ba0]
004fe9a9 85c0                     test      eax, eax
004fe9ab 0f8f93000000             jg        0x4fea44
004fe9b1 6a00                     push      0
004fe9b3 6a00                     push      0
004fe9b5 8d8eb8240000             lea       ecx, [esi + 0x24b8]
004fe9bb e8a0856000               call      0xb06f60
004fe9c0 8b86a01b0000             mov       eax, dword ptr [esi + 0x1ba0]
004fe9c6 85c0                     test      eax, eax
004fe9c8 0f8549010000             jne       0x4feb17
004fe9ce 8b86841b0000             mov       eax, dword ptr [esi + 0x1b84]
004fe9d4 85c0                     test      eax, eax
004fe9d6 7507                     jne       0x4fe9df
004fe9d8 bb04000000               mov       ebx, 4
004fe9dd eb0d                     jmp       0x4fe9ec
004fe9df 8b16                     mov       edx, dword ptr [esi]
004fe9e1 50                       push      eax
004fe9e2 8bce                     mov       ecx, esi
004fe9e4 ff921c030000             call      dword ptr [edx + 0x31c]
004fe9ea 8bd8                     mov       ebx, eax
004fe9ec 6828020000               push      0x228
004fe9f1 e85a52f0ff               call      0x403c50
004fe9f6 8bf8                     mov       edi, eax
004fe9f8 83c404                   add       esp, 4
004fe9fb 897de0                   mov       dword ptr [ebp - 0x20], edi
004fe9fe 85ff                     test      edi, edi
004fea00 c745fc02000000           mov       dword ptr [ebp - 4], 2
004fea07 0f84b1000000             je        0x4feabe
004fea0d 8b86181e0000             mov       eax, dword ptr [esi + 0x1e18]
004fea13 8b8ea41b0000             mov       ecx, dword ptr [esi + 0x1ba4]
004fea19 8b16                     mov       edx, dword ptr [esi]
004fea1b 53                       push      ebx
004fea1c 6a04                     push      4
004fea1e 50                       push      eax
004fea1f 51                       push      ecx
004fea20 6a03                     push      3
004fea22 8bce                     mov       ecx, esi
004fea24 ff9244030000             call      dword ptr [edx + 0x344]
004fea2a 8bc8                     mov       ecx, eax
004fea2c e88ff3fbff               call      0x4bddc0
004fea31 50                       push      eax
004fea32 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004fea35 50                       push      eax
004fea36 8bcf                     mov       ecx, edi
004fea38 e853b00000               call      0x509a90
004fea3d 8bf8                     mov       edi, eax
004fea3f e97c000000               jmp       0x4feac0
004fea44 8b9ea81b0000             mov       ebx, dword ptr [esi + 0x1ba8]
004fea4a 6828020000               push      0x228
004fea4f f7d3                     not       ebx
004fea51 e8fa51f0ff               call      0x403c50
004fea56 83c404                   add       esp, 4
004fea59 8945e0                   mov       dword ptr [ebp - 0x20], eax
004fea5c 85c0                     test      eax, eax
004fea5e c745fc01000000           mov       dword ptr [ebp - 4], 1
004fea65 7457                     je        0x4feabe
004fea67 8b16                     mov       edx, dword ptr [esi]
004fea69 6a03                     push      3
004fea6b 8bce                     mov       ecx, esi
004fea6d ff9244030000             call      dword ptr [edx + 0x344]
004fea73 8bf8                     mov       edi, eax
004fea75 8d8f48020000             lea       ecx, [edi + 0x248]
004fea7b e8e035f0ff               call      0x402060
004fea80 8945f0                   mov       dword ptr [ebp - 0x10], eax
004fea83 db45f0                   fild      dword ptr [ebp - 0x10]
004fea86 8d8f50020000             lea       ecx, [edi + 0x250]
004fea8c d95df0                   fstp      dword ptr [ebp - 0x10]
004fea8f e81c49f3ff               call      0x4333b0
004fea94 d84df0                   fmul      dword ptr [ebp - 0x10]
004fea97 e8a82a7000               call      0xc01544
004fea9c 8b8e181e0000             mov       ecx, dword ptr [esi + 0x1e18]
004feaa2 8b96a41b0000             mov       edx, dword ptr [esi + 0x1ba4]
004feaa8 6a04                     push      4
004feaaa 53                       push      ebx
004feaab 51                       push      ecx
004feaac 8b4de0                   mov       ecx, dword ptr [ebp - 0x20]
004feaaf 52                       push      edx
004feab0 50                       push      eax
004feab1 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004feab4 50                       push      eax
004feab5 e8d6af0000               call      0x509a90
004feaba 8bf8                     mov       edi, eax
004feabc eb02                     jmp       0x4feac0
004feabe 33ff                     xor       edi, edi
004feac0 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004feac6 6a00                     push      0
004feac8 6a00                     push      0
004feaca 56                       push      esi
004feacb 57                       push      edi
004feacc 6a00                     push      0
004feace 6a02                     push      2
004fead0 56                       push      esi
004fead1 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004fead8 e893f20000               call      0x50dd70
004feadd 8b16                     mov       edx, dword ptr [esi]
004feadf 8b1f                     mov       ebx, dword ptr [edi]
004feae1 8bce                     mov       ecx, esi
004feae3 ff929c000000             call      dword ptr [edx + 0x9c]
004feae9 8bc8                     mov       ecx, eax
004feaeb 8b8688010000             mov       eax, dword ptr [esi + 0x188]
004feaf1 99                       cdq       
004feaf2 2bc2                     sub       eax, edx
004feaf4 8b16                     mov       edx, dword ptr [esi]
004feaf6 d1f8                     sar       eax, 1
004feaf8 03c8                     add       ecx, eax
004feafa 51                       push      ecx
004feafb 8bce                     mov       ecx, esi
004feafd ff9298000000             call      dword ptr [edx + 0x98]
004feb03 50                       push      eax
004feb04 8b06                     mov       eax, dword ptr [esi]
004feb06 8bce                     mov       ecx, esi
004feb08 ff9094000000             call      dword ptr [eax + 0x94]
004feb0e 8bcf                     mov       ecx, edi
004feb10 50                       push      eax
004feb11 ff9388000000             call      dword ptr [ebx + 0x88]
004feb17 8b0d48280001             mov       ecx, dword ptr [0x1002848]
004feb1d 8b81a8190000             mov       eax, dword ptr [ecx + 0x19a8]
004feb23 bb02000000               mov       ebx, 2
004feb28 3bc3                     cmp       eax, ebx
004feb2a 741e                     je        0x4feb4a
004feb2c 8b16                     mov       edx, dword ptr [esi]
004feb2e 8bce                     mov       ecx, esi
004feb30 ff92a0050000             call      dword ptr [edx + 0x5a0]
004feb36 84c0                     test      al, al
004feb38 7510                     jne       0x4feb4a
004feb3a 8b06                     mov       eax, dword ptr [esi]
004feb3c 6aff                     push      -1
004feb3e 6a05                     push      5
004feb40 6a01                     push      1
004feb42 8bce                     mov       ecx, esi
004feb44 ff9034010000             call      dword ptr [eax + 0x134]
004feb4a 8b0d48280001             mov       ecx, dword ptr [0x1002848]
004feb50 8bb9a8190000             mov       edi, dword ptr [ecx + 0x19a8]
004feb56 8b16                     mov       edx, dword ptr [esi]
004feb58 8bce                     mov       ecx, esi
004feb5a ff92a0050000             call      dword ptr [edx + 0x5a0]
004feb60 84c0                     test      al, al
004feb62 752a                     jne       0x4feb8e
004feb64 a148280001               mov       eax, dword ptr [0x1002848]
004feb69 3998a8190000             cmp       dword ptr [eax + 0x19a8], ebx
004feb6f 751d                     jne       0x4feb8e
004feb71 8b16                     mov       edx, dword ptr [esi]
004feb73 33c0                     xor       eax, eax
004feb75 3bfb                     cmp       edi, ebx
004feb77 0f95c0                   setne     al
004feb7a 8bce                     mov       ecx, esi
004feb7c 48                       dec       eax
004feb7d 25010000ff               and       eax, 0xff000001
004feb82 48                       dec       eax
004feb83 50                       push      eax
004feb84 6a05                     push      5
004feb86 6a01                     push      1
004feb88 ff9234010000             call      dword ptr [edx + 0x134]
004feb8e 8b4d14                   mov       ecx, dword ptr [ebp + 0x14]
004feb91 8b5510                   mov       edx, dword ptr [ebp + 0x10]
004feb94 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004feb97 8b7d08                   mov       edi, dword ptr [ebp + 8]
004feb9a 51                       push      ecx
004feb9b 52                       push      edx
004feb9c 50                       push      eax
004feb9d 57                       push      edi
004feb9e 8bce                     mov       ecx, esi
004feba0 e8bbc1fbff               call      0x4bad60
004feba5 8b16                     mov       edx, dword ptr [esi]
004feba7 8bce                     mov       ecx, esi
004feba9 ff925c040000             call      dword ptr [edx + 0x45c]
004febaf 3bf8                     cmp       edi, eax
004febb1 7c4f                     jl        0x4fec02
004febb3 8b3e                     mov       edi, dword ptr [esi]
004febb5 8bce                     mov       ecx, esi
004febb7 ff975c040000             call      dword ptr [edi + 0x45c]
004febbd 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004febc0 8bcb                     mov       ecx, ebx
004febc2 2bc8                     sub       ecx, eax
004febc4 51                       push      ecx
004febc5 8bce                     mov       ecx, esi
004febc7 ff97b4030000             call      dword ptr [edi + 0x3b4]
004febcd 85c0                     test      eax, eax
004febcf 7422                     je        0x4febf3
004febd1 8b3e                     mov       edi, dword ptr [esi]
004febd3 8bce                     mov       ecx, esi
004febd5 ff975c040000             call      dword ptr [edi + 0x45c]
004febdb 8bd3                     mov       edx, ebx
004febdd 2bd0                     sub       edx, eax
004febdf 52                       push      edx
004febe0 8bce                     mov       ecx, esi
004febe2 ff97b4030000             call      dword ptr [edi + 0x3b4]
004febe8 50                       push      eax
004febe9 8bce                     mov       ecx, esi
004febeb ff9700010000             call      dword ptr [edi + 0x100]
004febf1 eb0f                     jmp       0x4fec02
004febf3 53                       push      ebx
004febf4 68605dcd00               push      0xcd5d60
004febf9 ff15bc2eff00             call      dword ptr [0xff2ebc]
004febff 83c408                   add       esp, 8
004fec02 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
004fec05 83f803                   cmp       eax, 3
004fec08 0f84ae000000             je        0x4fecbc
004fec0e 83f808                   cmp       eax, 8
004fec11 0f85af000000             jne       0x4fecc6
004fec17 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fec1d 85c9                     test      ecx, ecx
004fec1f 0f848e000000             je        0x4fecb3
004fec25 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004fec2b 2bc1                     sub       eax, ecx
004fec2d c1f804                   sar       eax, 4
004fec30 85c0                     test      eax, eax
004fec32 747f                     je        0x4fecb3
004fec34 33db                     xor       ebx, ebx
004fec36 895dec                   mov       dword ptr [ebp - 0x14], ebx
004fec39 8da42400000000           lea       esp, [esp]
004fec40 8b8ea0220000             mov       ecx, dword ptr [esi + 0x22a0]
004fec46 85c9                     test      ecx, ecx
004fec48 7469                     je        0x4fecb3
004fec4a 8b86a4220000             mov       eax, dword ptr [esi + 0x22a4]
004fec50 2bc1                     sub       eax, ecx
004fec52 c1f804                   sar       eax, 4
004fec55 3bd8                     cmp       ebx, eax
004fec57 735a                     jae       0x4fecb3
004fec59 33ff                     xor       edi, edi
004fec5b c1e304                   shl       ebx, 4
004fec5e 8bff                     mov       edi, edi
004fec60 8b86a0220000             mov       eax, dword ptr [esi + 0x22a0]
004fec66 8b541804                 mov       edx, dword ptr [eax + ebx + 4]
004fec6a 03c3                     add       eax, ebx
004fec6c 85d2                     test      edx, edx
004fec6e 7438                     je        0x4feca8
004fec70 8b4808                   mov       ecx, dword ptr [eax + 8]
004fec73 2bca                     sub       ecx, edx
004fec75 c1f902                   sar       ecx, 2
004fec78 3bf9                     cmp       edi, ecx
004fec7a 732c                     jae       0x4feca8
004fec7c 8b4804                   mov       ecx, dword ptr [eax + 4]
004fec7f 8d14bd00000000           lea       edx, [edi*4]
004fec86 03ca                     add       ecx, edx
004fec88 8b09                     mov       ecx, dword ptr [ecx]
004fec8a 80b93a01000000           cmp       byte ptr [ecx + 0x13a], 0
004fec91 7412                     je        0x4feca5
004fec93 8b4004                   mov       eax, dword ptr [eax + 4]
004fec96 03c2                     add       eax, edx
004fec98 8b00                     mov       eax, dword ptr [eax]
004fec9a 8b16                     mov       edx, dword ptr [esi]
004fec9c 50                       push      eax
004fec9d 8bce                     mov       ecx, esi
004fec9f ff92fc000000             call      dword ptr [edx + 0xfc]
004feca5 47                       inc       edi
004feca6 ebb8                     jmp       0x4fec60
004feca8 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004fecab 40                       inc       eax
004fecac 8945ec                   mov       dword ptr [ebp - 0x14], eax
004fecaf 8bd8                     mov       ebx, eax
004fecb1 eb8d                     jmp       0x4fec40
004fecb3 c6866423000000           mov       byte ptr [esi + 0x2364], 0
004fecba eb0a                     jmp       0x4fecc6
004fecbc 8b16                     mov       edx, dword ptr [esi]
004fecbe 8bce                     mov       ecx, esi
004fecc0 ff9290060000             call      dword ptr [edx + 0x690]
004fecc6 837d0808                 cmp       dword ptr [ebp + 8], 8
004fecca 0f8517020000             jne       0x4feee7
004fecd0 8b8628180000             mov       eax, dword ptr [esi + 0x1828]
004fecd6 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fecdc 8b8e2c180000             mov       ecx, dword ptr [esi + 0x182c]
004fece2 8d9e28180000             lea       ebx, [esi + 0x1828]
004fece8 33c7                     xor       eax, edi
004fecea 2bc3                     sub       eax, ebx
004fecec 3bc1                     cmp       eax, ecx
004fecee 740e                     je        0x4fecfe
004fecf0 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fecf6 6a3f                     push      0x3f
004fecf8 53                       push      ebx
004fecf9 e8b2836100               call      0xb170b0
004fecfe 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fed04 8b4304                   mov       eax, dword ptr [ebx + 4]
004fed07 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fed0a c1e002                   shl       eax, 2
004fed0d 8b3c02                   mov       edi, dword ptr [edx + eax]
004fed10 03d0                     add       edx, eax
004fed12 33fa                     xor       edi, edx
004fed14 333ddc012101             xor       edi, dword ptr [0x12101dc]
004fed1a 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fed1d 03c2                     add       eax, edx
004fed1f 8b10                     mov       edx, dword ptr [eax]
004fed21 33d0                     xor       edx, eax
004fed23 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fed29 3bfa                     cmp       edi, edx
004fed2b 7408                     je        0x4fed35
004fed2d 6a40                     push      0x40
004fed2f 53                       push      ebx
004fed30 e87b836100               call      0xb170b0
004fed35 57                       push      edi
004fed36 8bce                     mov       ecx, esi
004fed38 e8f346ffff               call      0x4f3430
004fed3d 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fed43 33c0                     xor       eax, eax
004fed45 8945f0                   mov       dword ptr [ebp - 0x10], eax
004fed48 8945ec                   mov       dword ptr [ebp - 0x14], eax
004fed4b 8b86e8220000             mov       eax, dword ptr [esi + 0x22e8]
004fed51 85c0                     test      eax, eax
004fed53 0f84b5000000             je        0x4fee0e
004fed59 8b96ec220000             mov       edx, dword ptr [esi + 0x22ec]
004fed5f 2bd0                     sub       edx, eax
004fed61 b867666666               mov       eax, 0x66666667
004fed66 f7ea                     imul      edx
004fed68 c1fa04                   sar       edx, 4
004fed6b 8bc2                     mov       eax, edx
004fed6d c1e81f                   shr       eax, 0x1f
004fed70 03c2                     add       eax, edx
004fed72 3945f0                   cmp       dword ptr [ebp - 0x10], eax
004fed75 0f8393000000             jae       0x4fee0e
004fed7b 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fed81 8b03                     mov       eax, dword ptr [ebx]
004fed83 33c2                     xor       eax, edx
004fed85 8b5304                   mov       edx, dword ptr [ebx + 4]
004fed88 2bc3                     sub       eax, ebx
004fed8a 3bc2                     cmp       eax, edx
004fed8c 740e                     je        0x4fed9c
004fed8e 6a3f                     push      0x3f
004fed90 53                       push      ebx
004fed91 e81a836100               call      0xb170b0
004fed96 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fed9c 8b4304                   mov       eax, dword ptr [ebx + 4]
004fed9f 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004feda2 c1e002                   shl       eax, 2
004feda5 8b3c02                   mov       edi, dword ptr [edx + eax]
004feda8 03d0                     add       edx, eax
004fedaa 33fa                     xor       edi, edx
004fedac 333ddc012101             xor       edi, dword ptr [0x12101dc]
004fedb2 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fedb5 03c2                     add       eax, edx
004fedb7 8b10                     mov       edx, dword ptr [eax]
004fedb9 33d0                     xor       edx, eax
004fedbb 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fedc1 3bfa                     cmp       edi, edx
004fedc3 740e                     je        0x4fedd3
004fedc5 6a40                     push      0x40
004fedc7 53                       push      ebx
004fedc8 e8e3826100               call      0xb170b0
004fedcd 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fedd3 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
004fedd6 8b86e8220000             mov       eax, dword ptr [esi + 0x22e8]
004feddc 03c2                     add       eax, edx
004fedde 3b7804                   cmp       edi, dword ptr [eax + 4]
004fede1 7519                     jne       0x4fedfc
004fede3 8b8618230000             mov       eax, dword ptr [esi + 0x2318]
004fede9 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004fedec 8d0488                   lea       eax, [eax + ecx*4]
004fedef 8b08                     mov       ecx, dword ptr [eax]
004fedf1 e87ae02400               call      0x74ce70
004fedf6 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fedfc 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004fedff 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004fee02 42                       inc       edx
004fee03 8955f0                   mov       dword ptr [ebp - 0x10], edx
004fee06 83c028                   add       eax, 0x28
004fee09 e93affffff               jmp       0x4fed48
004fee0e c745f000000000           mov       dword ptr [ebp - 0x10], 0
004fee15 c745ec00000000           mov       dword ptr [ebp - 0x14], 0
004fee1c 8d642400                 lea       esp, [esp]
004fee20 8b86881a0000             mov       eax, dword ptr [esi + 0x1a88]
004fee26 85c0                     test      eax, eax
004fee28 0f84b9000000             je        0x4feee7
004fee2e 8b968c1a0000             mov       edx, dword ptr [esi + 0x1a8c]
004fee34 2bd0                     sub       edx, eax
004fee36 b8abaaaa2a               mov       eax, 0x2aaaaaab
004fee3b f7ea                     imul      edx
004fee3d c1fa02                   sar       edx, 2
004fee40 8bc2                     mov       eax, edx
004fee42 c1e81f                   shr       eax, 0x1f
004fee45 03c2                     add       eax, edx
004fee47 3945f0                   cmp       dword ptr [ebp - 0x10], eax
004fee4a 0f8397000000             jae       0x4feee7
004fee50 a1dc012101               mov       eax, dword ptr [0x12101dc]
004fee55 8b13                     mov       edx, dword ptr [ebx]
004fee57 33d0                     xor       edx, eax
004fee59 8b4304                   mov       eax, dword ptr [ebx + 4]
004fee5c 2bd3                     sub       edx, ebx
004fee5e 3bd0                     cmp       edx, eax
004fee60 740e                     je        0x4fee70
004fee62 6a3f                     push      0x3f
004fee64 53                       push      ebx
004fee65 e846826100               call      0xb170b0
004fee6a 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fee70 8b4304                   mov       eax, dword ptr [ebx + 4]
004fee73 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fee76 c1e002                   shl       eax, 2
004fee79 8b3c02                   mov       edi, dword ptr [edx + eax]
004fee7c 03d0                     add       edx, eax
004fee7e 33fa                     xor       edi, edx
004fee80 333ddc012101             xor       edi, dword ptr [0x12101dc]
004fee86 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fee89 03c2                     add       eax, edx
004fee8b 8bd0                     mov       edx, eax
004fee8d 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fee93 3310                     xor       edx, dword ptr [eax]
004fee95 3bfa                     cmp       edi, edx
004fee97 740e                     je        0x4feea7
004fee99 6a40                     push      0x40
004fee9b 53                       push      ebx
004fee9c e80f826100               call      0xb170b0
004feea1 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004feea7 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
004feeaa 8b86881a0000             mov       eax, dword ptr [esi + 0x1a88]
004feeb0 03c2                     add       eax, edx
004feeb2 3b7804                   cmp       edi, dword ptr [eax + 4]
004feeb5 751b                     jne       0x4feed2
004feeb7 8b86481a0000             mov       eax, dword ptr [esi + 0x1a48]
004feebd 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004feec0 8d0488                   lea       eax, [eax + ecx*4]
004feec3 8b08                     mov       ecx, dword ptr [eax]
004feec5 8b11                     mov       edx, dword ptr [ecx]
004feec7 6a01                     push      1
004feec9 ff520c                   call      dword ptr [edx + 0xc]
004feecc 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004feed2 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004feed5 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004feed8 42                       inc       edx
004feed9 83c018                   add       eax, 0x18
004feedc 8955f0                   mov       dword ptr [ebp - 0x10], edx
004feedf 8945ec                   mov       dword ptr [ebp - 0x14], eax
004feee2 e939ffffff               jmp       0x4fee20
004feee7 8b5d14                   mov       ebx, dword ptr [ebp + 0x14]
004feeea 33ff                     xor       edi, edi
004feeec 8d642400                 lea       esp, [esp]
004feef0 8b8608230000             mov       eax, dword ptr [esi + 0x2308]
004feef6 85c0                     test      eax, eax
004feef8 0f840ff6ffff             je        0x4fe50d
004feefe 8b8e0c230000             mov       ecx, dword ptr [esi + 0x230c]
004fef04 2bc8                     sub       ecx, eax
004fef06 b8398ee338               mov       eax, 0x38e38e39
004fef0b f7e9                     imul      ecx
004fef0d c1fa03                   sar       edx, 3
004fef10 8bc2                     mov       eax, edx
004fef12 c1e81f                   shr       eax, 0x1f
004fef15 03c2                     add       eax, edx
004fef17 3bf8                     cmp       edi, eax
004fef19 0f83eef5ffff             jae       0x4fe50d
004fef1f 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004fef22 8b5510                   mov       edx, dword ptr [ebp + 0x10]
004fef25 8b8648230000             mov       eax, dword ptr [esi + 0x2348]
004fef2b 51                       push      ecx
004fef2c 8b4d0c                   mov       ecx, dword ptr [ebp + 0xc]
004fef2f 53                       push      ebx
004fef30 52                       push      edx
004fef31 8b5508                   mov       edx, dword ptr [ebp + 8]
004fef34 51                       push      ecx
004fef35 8b0cb8                   mov       ecx, dword ptr [eax + edi*4]
004fef38 8d04b8                   lea       eax, [eax + edi*4]
004fef3b 52                       push      edx
004fef3c e86ffa2400               call      0x74e9b0
004fef41 47                       inc       edi
004fef42 ebac                     jmp       0x4feef0
004fef44 d4e4                     aam       0xe4
004fef46 4f                       dec       edi
004fef47 0047e5                   add       byte ptr [edi - 0x1b], al
004fef4a 4f                       dec       edi
004fef4b 0020                     add       byte ptr [eax], ah
004fef4d e54f                     in        eax, 0x4f
004fef4f 00e1                     add       cl, ah
004fef51 e44f                     in        al, 0x4f
004fef53 0047e5                   add       byte ptr [edi - 0x1b], al
004fef56 4f                       dec       edi
004fef57 0047e5                   add       byte ptr [edi - 0x1b], al
004fef5a 4f                       dec       edi
004fef5b 0070e3                   add       byte ptr [eax - 0x1d], dh
004fef5e 4f                       dec       edi
004fef5f 0047e5                   add       byte ptr [edi - 0x1b], al
004fef62 4f                       dec       edi
004fef63 003de54f00dd             add       byte ptr [0xdd004fe5], bh
004fef69 e64f                     out       0x4f, al
004fef6b 00e7                     add       bh, ah
004fef6d e74f                     out       0x4f, eax
004fef6f 000b                     add       byte ptr [ebx], cl
004fef71 e74f                     out       0x4f, eax
004fef73 0067e5                   add       byte ptr [edi - 0x1b], ah
004fef76 4f                       dec       edi
004fef77 0077e5                   add       byte ptr [edi - 0x1b], dh
004fef7a 4f                       dec       edi
004fef7b 008eeb4f0000             add       byte ptr [esi + 0x4feb], cl
004fef81 0501050502               add       eax, 0x2050501
004fef86 0503050504               add       eax, 0x4050503
004fef8b cc                       int3      
004fef8c cc                       int3      
004fef8d cc                       int3      
004fef8e cc                       int3      
004fef8f cc                       int3      
004fef90 55                       push      ebp
004fef91 8bec                     mov       ebp, esp
004fef93 6aff                     push      -1
004fef95 682b9dc500               push      0xc59d2b
004fef9a 64a100000000             mov       eax, dword ptr fs:[0]
004fefa0 50                       push      eax
004fefa1 64892500000000           mov       dword ptr fs:[0], esp
004fefa8 51                       push      ecx
004fefa9 53                       push      ebx
004fefaa 56                       push      esi
004fefab 57                       push      edi
004fefac 68e8010000               push      0x1e8
004fefb1 8bf9                     mov       edi, ecx
004fefb3 e8984cf0ff               call      0x403c50
004fefb8 83c404                   add       esp, 4
004fefbb 8945f0                   mov       dword ptr [ebp - 0x10], eax
004fefbe 33db                     xor       ebx, ebx
004fefc0 3bc3                     cmp       eax, ebx
004fefc2 895dfc                   mov       dword ptr [ebp - 4], ebx
004fefc5 7410                     je        0x4fefd7
004fefc7 6a01                     push      1
004fefc9 68b810cd00               push      0xcd10b8
004fefce 8bc8                     mov       ecx, eax
004fefd0 e8fb46f9ff               call      0x4936d0
004fefd5 8bd8                     mov       ebx, eax
004fefd7 68fc010000               push      0x1fc
004fefdc c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004fefe3 e8684cf0ff               call      0x403c50
004fefe8 8bf0                     mov       esi, eax
004fefea 83c404                   add       esp, 4
004fefed 8975f0                   mov       dword ptr [ebp - 0x10], esi
004feff0 85f6                     test      esi, esi
004feff2 c745fc01000000           mov       dword ptr [ebp - 4], 1
004feff9 7414                     je        0x4ff00f
004feffb 6a00                     push      0
004feffd 6a01                     push      1
004fefff 53                       push      ebx
004ff000 8bce                     mov       ecx, esi
004ff002 e8a955f9ff               call      0x4945b0
004ff007 c706c4ffcc00             mov       dword ptr [esi], 0xccffc4
004ff00d eb02                     jmp       0x4ff011
004ff00f 33f6                     xor       esi, esi
004ff011 8b8f00010000             mov       ecx, dword ptr [edi + 0x100]
004ff017 6a00                     push      0
004ff019 6a00                     push      0
004ff01b 57                       push      edi
004ff01c 56                       push      esi
004ff01d 6a00                     push      0
004ff01f 6a02                     push      2
004ff021 57                       push      edi
004ff022 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004ff029 e842ed0000               call      0x50dd70
004ff02e 8b7d08                   mov       edi, dword ptr [ebp + 8]
004ff031 8b1e                     mov       ebx, dword ptr [esi]
004ff033 8d4f10                   lea       ecx, [edi + 0x10]
004ff036 e87543f3ff               call      0x4333b0
004ff03b e804257000               call      0xc01544
004ff040 50                       push      eax
004ff041 8d4f08                   lea       ecx, [edi + 8]
004ff044 e86743f3ff               call      0x4333b0
004ff049 e8f6247000               call      0xc01544
004ff04e 50                       push      eax
004ff04f 8bcf                     mov       ecx, edi
004ff051 e85a43f3ff               call      0x4333b0
004ff056 e8e9247000               call      0xc01544
004ff05b 50                       push      eax
004ff05c 8bce                     mov       ecx, esi
004ff05e ff9388000000             call      dword ptr [ebx + 0x88]
004ff064 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004ff067 5f                       pop       edi
004ff068 5e                       pop       esi
004ff069 5b                       pop       ebx
004ff06a 64890d00000000           mov       dword ptr fs:[0], ecx
004ff071 8be5                     mov       esp, ebp
004ff073 5d                       pop       ebp
004ff074 c20400                   ret       4
004ff077 cc                       int3      
004ff078 cc                       int3      
004ff079 cc                       int3      
004ff07a cc                       int3      
004ff07b cc                       int3      
004ff07c cc                       int3      
004ff07d cc                       int3      
004ff07e cc                       int3      
004ff07f cc                       int3      
004ff080 55                       push      ebp
004ff081 8bec                     mov       ebp, esp
004ff083 64a100000000             mov       eax, dword ptr fs:[0]
004ff089 6aff                     push      -1
004ff08b 68409dc500               push      0xc59d40
004ff090 50                       push      eax
004ff091 64892500000000           mov       dword ptr fs:[0], esp
004ff098 53                       push      ebx
004ff099 56                       push      esi
004ff09a 8bf1                     mov       esi, ecx
004ff09c 57                       push      edi
004ff09d 8d8e741d0000             lea       ecx, [esi + 0x1d74]
004ff0a3 e8587e6000               call      0xb06f00
004ff0a8 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004ff0ab 8986d81d0000             mov       dword ptr [esi + 0x1dd8], eax
004ff0b1 8d43fa                   lea       eax, [ebx - 6]
004ff0b4 83f817                   cmp       eax, 0x17
004ff0b7 0f87fe020000             ja        0x4ff3bb
004ff0bd 0fb68098f44f00           movzx     eax, byte ptr [eax + 0x4ff498]
004ff0c4 ff24856cf44f00           jmp       dword ptr [eax*4 + 0x4ff46c]
004ff0cb 8b16                     mov       edx, dword ptr [esi]
004ff0cd 8bce                     mov       ecx, esi
004ff0cf ff9294000000             call      dword ptr [edx + 0x94]
004ff0d5 8986201d0000             mov       dword ptr [esi + 0x1d20], eax
004ff0db 8b06                     mov       eax, dword ptr [esi]
004ff0dd 8bce                     mov       ecx, esi
004ff0df ff9098000000             call      dword ptr [eax + 0x98]
004ff0e5 8986241d0000             mov       dword ptr [esi + 0x1d24], eax
004ff0eb e9cb020000               jmp       0x4ff3bb
004ff0f0 8b8e401d0000             mov       ecx, dword ptr [esi + 0x1d40]
004ff0f6 85c9                     test      ecx, ecx
004ff0f8 8dbe3c1d0000             lea       edi, [esi + 0x1d3c]
004ff0fe 7413                     je        0x4ff113
004ff100 8b4708                   mov       eax, dword ptr [edi + 8]
004ff103 2bc1                     sub       eax, ecx
004ff105 c1f803                   sar       eax, 3
004ff108 85c0                     test      eax, eax
004ff10a 7607                     jbe       0x4ff113
004ff10c 8bcf                     mov       ecx, edi
004ff10e e83d630000               call      0x505450
004ff113 8b4f04                   mov       ecx, dword ptr [edi + 4]
004ff116 85c9                     test      ecx, ecx
004ff118 0f849d020000             je        0x4ff3bb
004ff11e 8b4708                   mov       eax, dword ptr [edi + 8]
004ff121 2bc1                     sub       eax, ecx
004ff123 c1f803                   sar       eax, 3
004ff126 85c0                     test      eax, eax
004ff128 0f868d020000             jbe       0x4ff3bb
004ff12e 8bcf                     mov       ecx, edi
004ff130 e81b630000               call      0x505450
004ff135 e981020000               jmp       0x4ff3bb
004ff13a 8b16                     mov       edx, dword ptr [esi]
004ff13c 8bce                     mov       ecx, esi
004ff13e ff92d8050000             call      dword ptr [edx + 0x5d8]
004ff144 e972020000               jmp       0x4ff3bb
004ff149 8b06                     mov       eax, dword ptr [esi]
004ff14b 8bce                     mov       ecx, esi
004ff14d ff90d8050000             call      dword ptr [eax + 0x5d8]
004ff153 e963020000               jmp       0x4ff3bb
004ff158 8bce                     mov       ecx, esi
004ff15a e831cff9ff               call      0x49c090
004ff15f 84c0                     test      al, al
004ff161 0f8454020000             je        0x4ff3bb
004ff167 8b16                     mov       edx, dword ptr [esi]
004ff169 6a00                     push      0
004ff16b 6a00                     push      0
004ff16d 6a00                     push      0
004ff16f 6a00                     push      0
004ff171 6a02                     push      2
004ff173 8bce                     mov       ecx, esi
004ff175 ff928c020000             call      dword ptr [edx + 0x28c]
004ff17b e93b020000               jmp       0x4ff3bb
004ff180 8bce                     mov       ecx, esi
004ff182 e809cff9ff               call      0x49c090
004ff187 84c0                     test      al, al
004ff189 0f842c020000             je        0x4ff3bb
004ff18f 8b06                     mov       eax, dword ptr [esi]
004ff191 6a00                     push      0
004ff193 6a00                     push      0
004ff195 6a00                     push      0
004ff197 6a00                     push      0
004ff199 6a00                     push      0
004ff19b 8bce                     mov       ecx, esi
004ff19d ff908c020000             call      dword ptr [eax + 0x28c]
004ff1a3 e913020000               jmp       0x4ff3bb
004ff1a8 b864000000               mov       eax, 0x64
004ff1ad c786041d000032000000     mov       dword ptr [esi + 0x1d04], 0x32
004ff1b7 89849eb01b0000           mov       dword ptr [esi + ebx*4 + 0x1bb0], eax
004ff1be 89849e281c0000           mov       dword ptr [esi + ebx*4 + 0x1c28], eax
004ff1c5 33ff                     xor       edi, edi
004ff1c7 33db                     xor       ebx, ebx
004ff1c9 8da42400000000           lea       esp, [esp]
004ff1d0 8b86601d0000             mov       eax, dword ptr [esi + 0x1d60]
004ff1d6 85c0                     test      eax, eax
004ff1d8 0f84da010000             je        0x4ff3b8
004ff1de 8b8e641d0000             mov       ecx, dword ptr [esi + 0x1d64]
004ff1e4 2bc8                     sub       ecx, eax
004ff1e6 b8abaaaa2a               mov       eax, 0x2aaaaaab
004ff1eb f7e9                     imul      ecx
004ff1ed c1fa04                   sar       edx, 4
004ff1f0 8bc2                     mov       eax, edx
004ff1f2 c1e81f                   shr       eax, 0x1f
004ff1f5 03c2                     add       eax, edx
004ff1f7 3bf8                     cmp       edi, eax
004ff1f9 0f83b9010000             jae       0x4ff3b8
004ff1ff 8b86601d0000             mov       eax, dword ptr [esi + 0x1d60]
004ff205 03c3                     add       eax, ebx
004ff207 680c51cd00               push      0xcd510c
004ff20c 8d4808                   lea       ecx, [eax + 8]
004ff20f e88c1dfaff               call      0x4a0fa0
004ff214 47                       inc       edi
004ff215 83c360                   add       ebx, 0x60
004ff218 ebb6                     jmp       0x4ff1d0
004ff21a 8d4d08                   lea       ecx, [ebp + 8]
004ff21d 51                       push      ecx
004ff21e 8d8ea81c0000             lea       ecx, [esi + 0x1ca8]
004ff224 c745080000c03f           mov       dword ptr [ebp + 8], 0x3fc00000
004ff22b e8e066fbff               call      0x4b5910
004ff230 6a10                     push      0x10
004ff232 8bce                     mov       ecx, esi
004ff234 e8c78df6ff               call      0x468000
004ff239 84c0                     test      al, al
004ff23b 7511                     jne       0x4ff24e
004ff23d 6a11                     push      0x11
004ff23f 8bce                     mov       ecx, esi
004ff241 e8ba8df6ff               call      0x468000
004ff246 84c0                     test      al, al
004ff248 0f846d010000             je        0x4ff3bb
004ff24e 6a0f                     push      0xf
004ff250 8bce                     mov       ecx, esi
004ff252 e8a98df6ff               call      0x468000
004ff257 84c0                     test      al, al
004ff259 754e                     jne       0x4ff2a9
004ff25b 8b16                     mov       edx, dword ptr [esi]
004ff25d 8bce                     mov       ecx, esi
004ff25f ff92e4020000             call      dword ptr [edx + 0x2e4]
004ff265 84c0                     test      al, al
004ff267 740f                     je        0x4ff278
004ff269 8b06                     mov       eax, dword ptr [esi]
004ff26b 8bce                     mov       ecx, esi
004ff26d ff90e8020000             call      dword ptr [eax + 0x2e8]
004ff273 83f801                   cmp       eax, 1
004ff276 7431                     je        0x4ff2a9
004ff278 8b8ea41a0000             mov       ecx, dword ptr [esi + 0x1aa4]
004ff27e c6413c01                 mov       byte ptr [ecx + 0x3c], 1
004ff282 8b16                     mov       edx, dword ptr [esi]
004ff284 6a01                     push      1
004ff286 6a01                     push      1
004ff288 8bce                     mov       ecx, esi
004ff28a ff92e0020000             call      dword ptr [edx + 0x2e0]
004ff290 8b06                     mov       eax, dword ptr [esi]
004ff292 8bce                     mov       ecx, esi
004ff294 ff90a8050000             call      dword ptr [eax + 0x5a8]
004ff29a c786e01b0000c8000000     mov       dword ptr [esi + 0x1be0], 0xc8
004ff2a4 e912010000               jmp       0x4ff3bb
004ff2a9 6a0f                     push      0xf
004ff2ab 8bce                     mov       ecx, esi
004ff2ad e84e8df6ff               call      0x468000
004ff2b2 84c0                     test      al, al
004ff2b4 742a                     je        0x4ff2e0
004ff2b6 8b16                     mov       edx, dword ptr [esi]
004ff2b8 8bce                     mov       ecx, esi
004ff2ba ff92e4020000             call      dword ptr [edx + 0x2e4]
004ff2c0 84c0                     test      al, al
004ff2c2 740f                     je        0x4ff2d3
004ff2c4 8b06                     mov       eax, dword ptr [esi]
004ff2c6 8bce                     mov       ecx, esi
004ff2c8 ff90e8020000             call      dword ptr [eax + 0x2e8]
004ff2ce 83f801                   cmp       eax, 1
004ff2d1 740d                     je        0x4ff2e0
004ff2d3 6a00                     push      0
004ff2d5 6a01                     push      1
004ff2d7 6a02                     push      2
004ff2d9 8bce                     mov       ecx, esi
004ff2db e870ba5600               call      0xa6ad50
004ff2e0 c786e01b0000c8000000     mov       dword ptr [esi + 0x1be0], 0xc8
004ff2ea e9cc000000               jmp       0x4ff3bb
004ff2ef c786101c0000c8000000     mov       dword ptr [esi + 0x1c10], 0xc8
004ff2f9 e9bd000000               jmp       0x4ff3bb
004ff2fe 8a86b0240000             mov       al, byte ptr [esi + 0x24b0]
004ff304 84c0                     test      al, al
004ff306 0f85af000000             jne       0x4ff3bb
004ff30c 68e8010000               push      0x1e8
004ff311 e83a49f0ff               call      0x403c50
004ff316 83c404                   add       esp, 4
004ff319 894508                   mov       dword ptr [ebp + 8], eax
004ff31c 85c0                     test      eax, eax
004ff31e c745fc00000000           mov       dword ptr [ebp - 4], 0
004ff325 7410                     je        0x4ff337
004ff327 6a01                     push      1
004ff329 68585ecd00               push      0xcd5e58
004ff32e 8bc8                     mov       ecx, eax
004ff330 e89b43f9ff               call      0x4936d0
004ff335 eb02                     jmp       0x4ff339
004ff337 33c0                     xor       eax, eax
004ff339 8b16                     mov       edx, dword ptr [esi]
004ff33b 8bce                     mov       ecx, esi
004ff33d c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004ff344 8986b4240000             mov       dword ptr [esi + 0x24b4], eax
004ff34a ff92e4000000             call      dword ptr [edx + 0xe4]
004ff350 8b06                     mov       eax, dword ptr [esi]
004ff352 8bce                     mov       ecx, esi
004ff354 ff90e4000000             call      dword ptr [eax + 0xe4]
004ff35a 8b8eb4240000             mov       ecx, dword ptr [esi + 0x24b4]
004ff360 894508                   mov       dword ptr [ebp + 8], eax
004ff363 db4508                   fild      dword ptr [ebp + 8]
004ff366 dc0d505ecd00             fmul      qword ptr [0xcd5e50]
004ff36c d95d08                   fstp      dword ptr [ebp + 8]
004ff36f 8b4508                   mov       eax, dword ptr [ebp + 8]
004ff372 50                       push      eax
004ff373 50                       push      eax
004ff374 e887655200               call      0xa25900
004ff379 8b3e                     mov       edi, dword ptr [esi]
004ff37b 8bce                     mov       ecx, esi
004ff37d ff97c0000000             call      dword ptr [edi + 0xc0]
004ff383 50                       push      eax
004ff384 8bce                     mov       ecx, esi
004ff386 ff97bc000000             call      dword ptr [edi + 0xbc]
004ff38c 8b86b4240000             mov       eax, dword ptr [esi + 0x24b4]
004ff392 8b16                     mov       edx, dword ptr [esi]
004ff394 6a01                     push      1
004ff396 6a00                     push      0
004ff398 6a00                     push      0
004ff39a 6a00                     push      0
004ff39c 6a00                     push      0
004ff39e 6a00                     push      0
004ff3a0 6a00                     push      0
004ff3a2 6a00                     push      0
004ff3a4 50                       push      eax
004ff3a5 6a01                     push      1
004ff3a7 8bce                     mov       ecx, esi
004ff3a9 ff92f8000000             call      dword ptr [edx + 0xf8]
004ff3af c686b024000001           mov       byte ptr [esi + 0x24b0], 1
004ff3b6 eb03                     jmp       0x4ff3bb
004ff3b8 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004ff3bb 8b86ec1d0000             mov       eax, dword ptr [esi + 0x1dec]
004ff3c1 8b9080000000             mov       edx, dword ptr [eax + 0x80]
004ff3c7 8b3dd8012101             mov       edi, dword ptr [0x12101d8]
004ff3cd 8b7f44                   mov       edi, dword ptr [edi + 0x44]
004ff3d0 8b8c9eb01b0000           mov       ecx, dword ptr [esi + ebx*4 + 0x1bb0]
004ff3d7 8d1497                   lea       edx, [edi + edx*4]
004ff3da 8bfa                     mov       edi, edx
004ff3dc 333ddc012101             xor       edi, dword ptr [0x12101dc]
004ff3e2 83c07c                   add       eax, 0x7c
004ff3e5 33f9                     xor       edi, ecx
004ff3e7 893a                     mov       dword ptr [edx], edi
004ff3e9 8b4004                   mov       eax, dword ptr [eax + 4]
004ff3ec 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ff3f2 8b5248                   mov       edx, dword ptr [edx + 0x48]
004ff3f5 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004ff3fb 8d0482                   lea       eax, [edx + eax*4]
004ff3fe 8bd0                     mov       edx, eax
004ff400 33d7                     xor       edx, edi
004ff402 33d1                     xor       edx, ecx
004ff404 8910                     mov       dword ptr [eax], edx
004ff406 8b849e281c0000           mov       eax, dword ptr [esi + ebx*4 + 0x1c28]
004ff40d 8bb6ec1d0000             mov       esi, dword ptr [esi + 0x1dec]
004ff413 8b8e88000000             mov       ecx, dword ptr [esi + 0x88]
004ff419 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ff41f 8b5244                   mov       edx, dword ptr [edx + 0x44]
004ff422 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004ff428 8d0c8a                   lea       ecx, [edx + ecx*4]
004ff42b 81c684000000             add       esi, 0x84
004ff431 8bd1                     mov       edx, ecx
004ff433 33d7                     xor       edx, edi
004ff435 33d0                     xor       edx, eax
004ff437 8911                     mov       dword ptr [ecx], edx
004ff439 8b4e04                   mov       ecx, dword ptr [esi + 4]
004ff43c 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ff442 8b5248                   mov       edx, dword ptr [edx + 0x48]
004ff445 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004ff44b 8d0c8a                   lea       ecx, [edx + ecx*4]
004ff44e 8bd1                     mov       edx, ecx
004ff450 33d7                     xor       edx, edi
004ff452 33d0                     xor       edx, eax
004ff454 5f                       pop       edi
004ff455 8911                     mov       dword ptr [ecx], edx
004ff457 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004ff45a 5e                       pop       esi
004ff45b 64890d00000000           mov       dword ptr fs:[0], ecx
004ff462 5b                       pop       ebx
004ff463 8be5                     mov       esp, ebp
004ff465 5d                       pop       ebp
004ff466 c20400                   ret       4
004ff469 8d4900                   lea       ecx, [ecx]
004ff46c 3af1                     cmp       dh, cl
004ff46e 4f                       dec       edi
004ff46f 00a8f14f001a             add       byte ptr [eax + 0x1a004ff1], ch
004ff475 f24f                     dec       edi
004ff477 0058f1                   add       byte ptr [eax - 0xf], bl
004ff47a 4f                       dec       edi
004ff47b 0080f14f00f0             add       byte ptr [eax - 0xfffb00f], al
004ff481 f0                       .byte     0xf0
004ff482 4f                       dec       edi
004ff483 00fe                     add       dh, bh
004ff485 f24f                     dec       edi
004ff487 00ef                     add       bh, ch
004ff489 f24f                     dec       edi
004ff48b 00cb                     add       bl, cl
004ff48d f0                       .byte     0xf0
004ff48e 4f                       dec       edi
004ff48f 0049f1                   add       byte ptr [ecx - 0xf], cl
004ff492 4f                       dec       edi
004ff493 00bbf34f0000             add       byte ptr [ebx + 0x4ff3], bh
004ff499 0a0a                     or        cl, byte ptr [edx]
004ff49b 0101                     add       dword ptr [ecx], eax
004ff49d 0a02                     or        al, byte ptr [edx]
004ff49f 0a03                     or        al, byte ptr [ebx]
004ff4a1 040a                     add       al, 0xa
004ff4a3 0a0a                     or        cl, byte ptr [edx]
004ff4a5 0a0a                     or        cl, byte ptr [edx]
004ff4a7 05060a070a               add       eax, 0xa070a06
004ff4ac 0a08                     or        cl, byte ptr [eax]
004ff4ae 0809                     or        byte ptr [ecx], cl
004ff4b0 55                       push      ebp
004ff4b1 8bec                     mov       ebp, esp
004ff4b3 6aff                     push      -1
004ff4b5 68aa9dc500               push      0xc59daa
004ff4ba 64a100000000             mov       eax, dword ptr fs:[0]
004ff4c0 50                       push      eax
004ff4c1 64892500000000           mov       dword ptr fs:[0], esp
004ff4c8 81ec68050000             sub       esp, 0x568
004ff4ce 8b4510                   mov       eax, dword ptr [ebp + 0x10]
004ff4d1 53                       push      ebx
004ff4d2 56                       push      esi
004ff4d3 8bf1                     mov       esi, ecx
004ff4d5 8986e4190000             mov       dword ptr [esi + 0x19e4], eax
004ff4db 83be5c1b000008           cmp       dword ptr [esi + 0x1b5c], 8
004ff4e2 57                       push      edi
004ff4e3 7208                     jb        0x4ff4ed
004ff4e5 8b86481b0000             mov       eax, dword ptr [esi + 0x1b48]
004ff4eb eb06                     jmp       0x4ff4f3
004ff4ed 8d86481b0000             lea       eax, [esi + 0x1b48]
004ff4f3 8b0de0300001             mov       ecx, dword ptr [0x10030e0]
004ff4f9 50                       push      eax
004ff4fa 33ff                     xor       edi, edi
004ff4fc 57                       push      edi
004ff4fd e82ed96700               call      0xb7ce30
004ff502 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004ff505 51                       push      ecx
004ff506 50                       push      eax
004ff507 e814a53a00               call      0x8a9a20
004ff50c 83c408                   add       esp, 8
004ff50f 8986cc210000             mov       dword ptr [esi + 0x21cc], eax
004ff515 b801000000               mov       eax, 1
004ff51a b902000000               mov       ecx, 2
004ff51f 33db                     xor       ebx, ebx
004ff521 c7458c681fcd00           mov       dword ptr [ebp - 0x74], 0xcd1f68
004ff528 c745905c1fcd00           mov       dword ptr [ebp - 0x70], 0xcd1f5c
004ff52f c74594501fcd00           mov       dword ptr [ebp - 0x6c], 0xcd1f50
004ff536 c74598441fcd00           mov       dword ptr [ebp - 0x68], 0xcd1f44
004ff53d c7459c381fcd00           mov       dword ptr [ebp - 0x64], 0xcd1f38
004ff544 c745a0d81ecd00           mov       dword ptr [ebp - 0x60], 0xcd1ed8
004ff54b c745a4781ecd00           mov       dword ptr [ebp - 0x5c], 0xcd1e78
004ff552 c745a8181ecd00           mov       dword ptr [ebp - 0x58], 0xcd1e18
004ff559 c745acb81dcd00           mov       dword ptr [ebp - 0x54], 0xcd1db8
004ff560 897dd0                   mov       dword ptr [ebp - 0x30], edi
004ff563 897dd4                   mov       dword ptr [ebp - 0x2c], edi
004ff566 c745d8ffffffff           mov       dword ptr [ebp - 0x28], 0xffffffff
004ff56d 8945dc                   mov       dword ptr [ebp - 0x24], eax
004ff570 894db0                   mov       dword ptr [ebp - 0x50], ecx
004ff573 894db4                   mov       dword ptr [ebp - 0x4c], ecx
004ff576 8945b8                   mov       dword ptr [ebp - 0x48], eax
004ff579 8945bc                   mov       dword ptr [ebp - 0x44], eax
004ff57c 895de4                   mov       dword ptr [ebp - 0x1c], ebx
004ff57f 90                       nop       
004ff580 8b86cc210000             mov       eax, dword ptr [esi + 0x21cc]
004ff586 8b54858c                 mov       edx, dword ptr [ebp + eax*4 - 0x74]
004ff58a 8b441da0                 mov       eax, dword ptr [ebp + ebx - 0x60]
004ff58e 52                       push      edx
004ff58f 50                       push      eax
004ff590 8d8d8cfaffff             lea       ecx, [ebp - 0x574]
004ff596 6800040000               push      0x400
004ff59b 51                       push      ecx
004ff59c e84f28f0ff               call      0x401df0
004ff5a1 68e8010000               push      0x1e8
004ff5a6 e8a546f0ff               call      0x403c50
004ff5ab 83c414                   add       esp, 0x14
004ff5ae 8945e8                   mov       dword ptr [ebp - 0x18], eax
004ff5b1 3bc7                     cmp       eax, edi
004ff5b3 897dfc                   mov       dword ptr [ebp - 4], edi
004ff5b6 7415                     je        0x4ff5cd
004ff5b8 6a01                     push      1
004ff5ba 8d958cfaffff             lea       edx, [ebp - 0x574]
004ff5c0 52                       push      edx
004ff5c1 8bc8                     mov       ecx, eax
004ff5c3 e80841f9ff               call      0x4936d0
004ff5c8 8945e8                   mov       dword ptr [ebp - 0x18], eax
004ff5cb eb03                     jmp       0x4ff5d0
004ff5cd 897de8                   mov       dword ptr [ebp - 0x18], edi
004ff5d0 8b06                     mov       eax, dword ptr [esi]
004ff5d2 8bce                     mov       ecx, esi
004ff5d4 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004ff5db ff9070030000             call      dword ptr [eax + 0x370]
004ff5e1 85c0                     test      eax, eax
004ff5e3 0f84e1000000             je        0x4ff6ca
004ff5e9 8b16                     mov       edx, dword ptr [esi]
004ff5eb 57                       push      edi
004ff5ec 8bce                     mov       ecx, esi
004ff5ee ff9270030000             call      dword ptr [edx + 0x370]
004ff5f4 8bc8                     mov       ecx, eax
004ff5f6 e895665200               call      0xa25c90
004ff5fb 85c0                     test      eax, eax
004ff5fd 0f84c7000000             je        0x4ff6ca
004ff603 8b06                     mov       eax, dword ptr [esi]
004ff605 57                       push      edi
004ff606 8bce                     mov       ecx, esi
004ff608 ff9070030000             call      dword ptr [eax + 0x370]
004ff60e 8bc8                     mov       ecx, eax
004ff610 e87b665200               call      0xa25c90
004ff615 8b08                     mov       ecx, dword ptr [eax]
004ff617 3bcf                     cmp       ecx, edi
004ff619 0f84ab000000             je        0x4ff6ca
004ff61f 8b5810                   mov       ebx, dword ptr [eax + 0x10]
004ff622 8b7914                   mov       edi, dword ptr [ecx + 0x14]
004ff625 8d5010                   lea       edx, [eax + 0x10]
004ff628 2bda                     sub       ebx, edx
004ff62a 8b15fc3e0d01             mov       edx, dword ptr [0x10d3efc]
004ff630 33da                     xor       ebx, edx
004ff632 85ff                     test      edi, edi
004ff634 897df0                   mov       dword ptr [ebp - 0x10], edi
004ff637 db45f0                   fild      dword ptr [ebp - 0x10]
004ff63a 895dec                   mov       dword ptr [ebp - 0x14], ebx
004ff63d 7d06                     jge       0x4ff645
004ff63f d805cc46cc00             fadd      dword ptr [0xcc46cc]
004ff645 d80d7881cc00             fmul      dword ptr [0xcc8178]
004ff64b 8b7814                   mov       edi, dword ptr [eax + 0x14]
004ff64e 8b4918                   mov       ecx, dword ptr [ecx + 0x18]
004ff651 83c014                   add       eax, 0x14
004ff654 d84dec                   fmul      dword ptr [ebp - 0x14]
004ff657 2bf8                     sub       edi, eax
004ff659 33fa                     xor       edi, edx
004ff65b 85c9                     test      ecx, ecx
004ff65d d80db41dcd00             fmul      dword ptr [0xcd1db4]
004ff663 894de0                   mov       dword ptr [ebp - 0x20], ecx
004ff666 897df0                   mov       dword ptr [ebp - 0x10], edi
004ff669 d95dec                   fstp      dword ptr [ebp - 0x14]
004ff66c db45e0                   fild      dword ptr [ebp - 0x20]
004ff66f 7d06                     jge       0x4ff677
004ff671 d805cc46cc00             fadd      dword ptr [0xcc46cc]
004ff677 d80d7881cc00             fmul      dword ptr [0xcc8178]
004ff67d d84df0                   fmul      dword ptr [ebp - 0x10]
004ff680 d80db01dcd00             fmul      dword ptr [0xcd1db0]
004ff686 d95df0                   fstp      dword ptr [ebp - 0x10]
004ff689 d905581fcc00             fld       dword ptr [0xcc1f58]
004ff68f d85dec                   fcomp     dword ptr [ebp - 0x14]
004ff692 dfe0                     fnstsw    ax
004ff694 f6c405                   test      ah, 5
004ff697 7a07                     jp        0x4ff6a0
004ff699 c745ec0000803f           mov       dword ptr [ebp - 0x14], 0x3f800000
004ff6a0 d905581fcc00             fld       dword ptr [0xcc1f58]
004ff6a6 d85df0                   fcomp     dword ptr [ebp - 0x10]
004ff6a9 dfe0                     fnstsw    ax
004ff6ab f6c405                   test      ah, 5
004ff6ae 7a07                     jp        0x4ff6b7
004ff6b0 c745f00000803f           mov       dword ptr [ebp - 0x10], 0x3f800000
004ff6b7 8b4df0                   mov       ecx, dword ptr [ebp - 0x10]
004ff6ba 8b55ec                   mov       edx, dword ptr [ebp - 0x14]
004ff6bd 51                       push      ecx
004ff6be 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004ff6c1 52                       push      edx
004ff6c2 e839625200               call      0xa25900
004ff6c7 8b5de4                   mov       ebx, dword ptr [ebp - 0x1c]
004ff6ca 68fc010000               push      0x1fc
004ff6cf e87c45f0ff               call      0x403c50
004ff6d4 8bf8                     mov       edi, eax
004ff6d6 83c404                   add       esp, 4
004ff6d9 897de0                   mov       dword ptr [ebp - 0x20], edi
004ff6dc 85ff                     test      edi, edi
004ff6de c745fc01000000           mov       dword ptr [ebp - 4], 1
004ff6e5 7417                     je        0x4ff6fe
004ff6e7 8b45e8                   mov       eax, dword ptr [ebp - 0x18]
004ff6ea 6a00                     push      0
004ff6ec 6a01                     push      1
004ff6ee 50                       push      eax
004ff6ef 8bcf                     mov       ecx, edi
004ff6f1 e8ba4ef9ff               call      0x4945b0
004ff6f6 c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004ff6fc eb02                     jmp       0x4ff700
004ff6fe 33ff                     xor       edi, edi
004ff700 8b17                     mov       edx, dword ptr [edi]
004ff702 6a02                     push      2
004ff704 8bcf                     mov       ecx, edi
004ff706 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004ff70d ff5254                   call      dword ptr [edx + 0x54]
004ff710 8b07                     mov       eax, dword ptr [edi]
004ff712 8bcf                     mov       ecx, edi
004ff714 ff5028                   call      dword ptr [eax + 0x28]
004ff717 8b4c1db0                 mov       ecx, dword ptr [ebp + ebx - 0x50]
004ff71b 6a00                     push      0
004ff71d 6a00                     push      0
004ff71f 56                       push      esi
004ff720 57                       push      edi
004ff721 6a00                     push      0
004ff723 6a02                     push      2
004ff725 89480c                   mov       dword ptr [eax + 0xc], ecx
004ff728 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004ff72e 56                       push      esi
004ff72f e83ce60000               call      0x50dd70
004ff734 8b16                     mov       edx, dword ptr [esi]
004ff736 8b1f                     mov       ebx, dword ptr [edi]
004ff738 8bce                     mov       ecx, esi
004ff73a ff929c000000             call      dword ptr [edx + 0x9c]
004ff740 50                       push      eax
004ff741 8b06                     mov       eax, dword ptr [esi]
004ff743 8bce                     mov       ecx, esi
004ff745 ff9098000000             call      dword ptr [eax + 0x98]
004ff74b 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
004ff74e 03440dd0                 add       eax, dword ptr [ebp + ecx - 0x30]
004ff752 8b16                     mov       edx, dword ptr [esi]
004ff754 50                       push      eax
004ff755 8bce                     mov       ecx, esi
004ff757 ff9294000000             call      dword ptr [edx + 0x94]
004ff75d 50                       push      eax
004ff75e 8bcf                     mov       ecx, edi
004ff760 ff9388000000             call      dword ptr [ebx + 0x88]
004ff766 8b07                     mov       eax, dword ptr [edi]
004ff768 56                       push      esi
004ff769 8bcf                     mov       ecx, edi
004ff76b ff5048                   call      dword ptr [eax + 0x48]
004ff76e 8bc8                     mov       ecx, eax
004ff770 e80b170100               call      0x510e80
004ff775 8b5de4                   mov       ebx, dword ptr [ebp - 0x1c]
004ff778 83c304                   add       ebx, 4
004ff77b 33ff                     xor       edi, edi
004ff77d 83fb10                   cmp       ebx, 0x10
004ff780 895de4                   mov       dword ptr [ebp - 0x1c], ebx
004ff783 0f8cf7fdffff             jl        0x4ff580
004ff789 8b86cc210000             mov       eax, dword ptr [esi + 0x21cc]
004ff78f 3bc7                     cmp       eax, edi
004ff791 897dd0                   mov       dword ptr [ebp - 0x30], edi
004ff794 c745d40a000000           mov       dword ptr [ebp - 0x2c], 0xa
004ff79b c745d814000000           mov       dword ptr [ebp - 0x28], 0x14
004ff7a2 897ddc                   mov       dword ptr [ebp - 0x24], edi
004ff7a5 0f8c9d000000             jl        0x4ff848
004ff7ab 83f803                   cmp       eax, 3
004ff7ae 0f8f94000000             jg        0x4ff848
004ff7b4 68c4000000               push      0xc4
004ff7b9 e89244f0ff               call      0x403c50
004ff7be 83c404                   add       esp, 4
004ff7c1 8945e0                   mov       dword ptr [ebp - 0x20], eax
004ff7c4 3bc7                     cmp       eax, edi
004ff7c6 c745fc02000000           mov       dword ptr [ebp - 4], 2
004ff7cd 741b                     je        0x4ff7ea
004ff7cf 8b8ecc210000             mov       ecx, dword ptr [esi + 0x21cc]
004ff7d5 6aff                     push      -1
004ff7d7 57                       push      edi
004ff7d8 51                       push      ecx
004ff7d9 8b4d10                   mov       ecx, dword ptr [ebp + 0x10]
004ff7dc 8b548dd0                 mov       edx, dword ptr [ebp + ecx*4 - 0x30]
004ff7e0 52                       push      edx
004ff7e1 8bc8                     mov       ecx, eax
004ff7e3 e8e894fcff               call      0x4c8cd0
004ff7e8 8bf8                     mov       edi, eax
004ff7ea 8b07                     mov       eax, dword ptr [edi]
004ff7ec 8bcf                     mov       ecx, edi
004ff7ee c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004ff7f5 ff5050                   call      dword ptr [eax + 0x50]
004ff7f8 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004ff7fe 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004ff801 8b4850                   mov       ecx, dword ptr [eax + 0x50]
004ff804 83c04c                   add       eax, 0x4c
004ff807 c1e102                   shl       ecx, 2
004ff80a 8d1c11                   lea       ebx, [ecx + edx]
004ff80d 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004ff813 6a00                     push      0
004ff815 891c11                   mov       dword ptr [ecx + edx], ebx
004ff818 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ff81e 8b4004                   mov       eax, dword ptr [eax + 4]
004ff821 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004ff824 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004ff82a 6aff                     push      -1
004ff82c 6a00                     push      0
004ff82e c1e002                   shl       eax, 2
004ff831 6a00                     push      0
004ff833 8d1408                   lea       edx, [eax + ecx]
004ff836 6a00                     push      0
004ff838 33d3                     xor       edx, ebx
004ff83a 891408                   mov       dword ptr [eax + ecx], edx
004ff83d 8b07                     mov       eax, dword ptr [edi]
004ff83f 56                       push      esi
004ff840 56                       push      esi
004ff841 8bcf                     mov       ecx, edi
004ff843 ff5048                   call      dword ptr [eax + 0x48]
004ff846 33ff                     xor       edi, edi
004ff848 897dc4                   mov       dword ptr [ebp - 0x3c], edi
004ff84b 897dc8                   mov       dword ptr [ebp - 0x38], edi
004ff84e 897dcc                   mov       dword ptr [ebp - 0x34], edi
004ff851 8b16                     mov       edx, dword ptr [esi]
004ff853 6a03                     push      3
004ff855 8bce                     mov       ecx, esi
004ff857 c745fc03000000           mov       dword ptr [ebp - 4], 3
004ff85e ff9244030000             call      dword ptr [edx + 0x344]
004ff864 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004ff86a 8bd8                     mov       ebx, eax
004ff86c 8b03                     mov       eax, dword ptr [ebx]
004ff86e 8b4b04                   mov       ecx, dword ptr [ebx + 4]
004ff871 33c7                     xor       eax, edi
004ff873 2bc3                     sub       eax, ebx
004ff875 3bc1                     cmp       eax, ecx
004ff877 740e                     je        0x4ff887
004ff879 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004ff87f 6a3f                     push      0x3f
004ff881 53                       push      ebx
004ff882 e829786100               call      0xb170b0
004ff887 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ff88d 8b4a44                   mov       ecx, dword ptr [edx + 0x44]
004ff890 8b4304                   mov       eax, dword ptr [ebx + 4]
004ff893 c1e002                   shl       eax, 2
004ff896 8d3c08                   lea       edi, [eax + ecx]
004ff899 333c08                   xor       edi, dword ptr [eax + ecx]
004ff89c 333ddc012101             xor       edi, dword ptr [0x12101dc]
004ff8a2 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004ff8a5 8d1408                   lea       edx, [eax + ecx]
004ff8a8 331408                   xor       edx, dword ptr [eax + ecx]
004ff8ab 3315dc012101             xor       edx, dword ptr [0x12101dc]
004ff8b1 3bfa                     cmp       edi, edx
004ff8b3 740e                     je        0x4ff8c3
004ff8b5 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004ff8bb 6a40                     push      0x40
004ff8bd 53                       push      ebx
004ff8be e8ed776100               call      0xb170b0
004ff8c3 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004ff8c6 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004ff8c9 8d45c0                   lea       eax, [ebp - 0x40]
004ff8cc 50                       push      eax
004ff8cd 51                       push      ecx
004ff8ce 57                       push      edi
004ff8cf 52                       push      edx
004ff8d0 e8fbc63a00               call      0x8abfd0
004ff8d5 8b86e4190000             mov       eax, dword ptr [esi + 0x19e4]
004ff8db 83c410                   add       esp, 0x10
004ff8de 83f801                   cmp       eax, 1
004ff8e1 740f                     je        0x4ff8f2
004ff8e3 83f802                   cmp       eax, 2
004ff8e6 740a                     je        0x4ff8f2
004ff8e8 83f806                   cmp       eax, 6
004ff8eb 7405                     je        0x4ff8f2
004ff8ed 83f807                   cmp       eax, 7
004ff8f0 750f                     jne       0x4ff901
004ff8f2 8d45c0                   lea       eax, [ebp - 0x40]
004ff8f5 50                       push      eax
004ff8f6 8d8e501e0000             lea       ecx, [esi + 0x1e50]
004ff8fc e83f800000               call      0x507940
004ff901 8b86e4190000             mov       eax, dword ptr [esi + 0x19e4]
004ff907 83f802                   cmp       eax, 2
004ff90a 7405                     je        0x4ff911
004ff90c 83f807                   cmp       eax, 7
004ff90f 7511                     jne       0x4ff922
004ff911 6845060000               push      0x645
004ff916 e825195500               call      0xa51240
004ff91b 83c404                   add       esp, 4
004ff91e 8bd8                     mov       ebx, eax
004ff920 eb05                     jmp       0x4ff927
004ff922 bbe0baca00               mov       ebx, 0xcabae0
004ff927 8bbecc210000             mov       edi, dword ptr [esi + 0x21cc]
004ff92d 8d8e08020000             lea       ecx, [esi + 0x208]
004ff933 e8b8375500               call      0xa530f0
004ff938 50                       push      eax
004ff939 81c740060000             add       edi, 0x640
004ff93f 57                       push      edi
004ff940 e8fb185500               call      0xa51240
004ff945 83c404                   add       esp, 4
004ff948 50                       push      eax
004ff949 53                       push      ebx
004ff94a 6824b4cb00               push      0xcbb424
004ff94f 8d8d8cfeffff             lea       ecx, [ebp - 0x174]
004ff955 6800010000               push      0x100
004ff95a 51                       push      ecx
004ff95b e89024f0ff               call      0x401df0
004ff960 8b16                     mov       edx, dword ptr [esi]
004ff962 83c418                   add       esp, 0x18
004ff965 8bce                     mov       ecx, esi
004ff967 ff9294010000             call      dword ptr [edx + 0x194]
004ff96d 8d8d8cfeffff             lea       ecx, [ebp - 0x174]
004ff973 83c004                   add       eax, 4
004ff976 51                       push      ecx
004ff977 8bc8                     mov       ecx, eax
004ff979 e8223f5500               call      0xa538a0
004ff97e 8b86e4190000             mov       eax, dword ptr [esi + 0x19e4]
004ff984 83f802                   cmp       eax, 2
004ff987 7405                     je        0x4ff98e
004ff989 83f807                   cmp       eax, 7
004ff98c 753f                     jne       0x4ff9cd
004ff98e 688c000000               push      0x8c
004ff993 e8b842f0ff               call      0x403c50
004ff998 83c404                   add       esp, 4
004ff99b 894508                   mov       dword ptr [ebp + 8], eax
004ff99e 85c0                     test      eax, eax
004ff9a0 c645fc04                 mov       byte ptr [ebp - 4], 4
004ff9a4 740e                     je        0x4ff9b4
004ff9a6 680000c842               push      0x42c80000
004ff9ab 8bc8                     mov       ecx, eax
004ff9ad e87efd0b00               call      0x5bf730
004ff9b2 eb02                     jmp       0x4ff9b6
004ff9b4 33c0                     xor       eax, eax
004ff9b6 8b10                     mov       edx, dword ptr [eax]
004ff9b8 6a00                     push      0
004ff9ba 6aff                     push      -1
004ff9bc 6a00                     push      0
004ff9be 6a00                     push      0
004ff9c0 6a00                     push      0
004ff9c2 56                       push      esi
004ff9c3 56                       push      esi
004ff9c4 8bc8                     mov       ecx, eax
004ff9c6 c645fc03                 mov       byte ptr [ebp - 4], 3
004ff9ca ff5248                   call      dword ptr [edx + 0x48]
004ff9cd 8b06                     mov       eax, dword ptr [esi]
004ff9cf 8bce                     mov       ecx, esi
004ff9d1 ff9038020000             call      dword ptr [eax + 0x238]
004ff9d7 8b16                     mov       edx, dword ptr [esi]
004ff9d9 8b9ecc210000             mov       ebx, dword ptr [esi + 0x21cc]
004ff9df 6a00                     push      0
004ff9e1 8bce                     mov       ecx, esi
004ff9e3 894508                   mov       dword ptr [ebp + 8], eax
004ff9e6 8dbe501e0000             lea       edi, [esi + 0x1e50]
004ff9ec ff9244030000             call      dword ptr [edx + 0x344]
004ff9f2 50                       push      eax
004ff9f3 8b4510                   mov       eax, dword ptr [ebp + 0x10]
004ff9f6 57                       push      edi
004ff9f7 50                       push      eax
004ff9f8 53                       push      ebx
004ff9f9 e8e28c3a00               call      0x8a86e0
004ff9fe 8b16                     mov       edx, dword ptr [esi]
004ffa00 83c410                   add       esp, 0x10
004ffa03 6a00                     push      0
004ffa05 8bce                     mov       ecx, esi
004ffa07 ff9248030000             call      dword ptr [edx + 0x348]
004ffa0d 8b1e                     mov       ebx, dword ptr [esi]
004ffa0f 6a01                     push      1
004ffa11 6a00                     push      0
004ffa13 8bce                     mov       ecx, esi
004ffa15 ff9338020000             call      dword ptr [ebx + 0x238]
004ffa1b 50                       push      eax
004ffa1c 8bce                     mov       ecx, esi
004ffa1e ff93ec030000             call      dword ptr [ebx + 0x3ec]
004ffa24 8b06                     mov       eax, dword ptr [esi]
004ffa26 8bce                     mov       ecx, esi
004ffa28 ff9038020000             call      dword ptr [eax + 0x238]
004ffa2e 8b4d08                   mov       ecx, dword ptr [ebp + 8]
004ffa31 50                       push      eax
004ffa32 51                       push      ecx
004ffa33 68701dcd00               push      0xcd1d70
004ffa38 ff15bc2eff00             call      dword ptr [0xff2ebc]
004ffa3e 6809fe0300               push      0x3fe09
004ffa43 57                       push      edi
004ffa44 e827e33a00               call      0x8add70
004ffa49 83c414                   add       esp, 0x14
004ffa4c 84c0                     test      al, al
004ffa4e 0f8486000000             je        0x4ffada
004ffa54 68c4000000               push      0xc4
004ffa59 e8f241f0ff               call      0x403c50
004ffa5e 83c404                   add       esp, 4
004ffa61 894510                   mov       dword ptr [ebp + 0x10], eax
004ffa64 85c0                     test      eax, eax
004ffa66 c645fc05                 mov       byte ptr [ebp - 4], 5
004ffa6a 7413                     je        0x4ffa7f
004ffa6c 6aff                     push      -1
004ffa6e 6a00                     push      0
004ffa70 6a00                     push      0
004ffa72 6a05                     push      5
004ffa74 8bc8                     mov       ecx, eax
004ffa76 e85592fcff               call      0x4c8cd0
004ffa7b 8bf8                     mov       edi, eax
004ffa7d eb02                     jmp       0x4ffa81
004ffa7f 33ff                     xor       edi, edi
004ffa81 8b17                     mov       edx, dword ptr [edi]
004ffa83 8bcf                     mov       ecx, edi
004ffa85 c645fc03                 mov       byte ptr [ebp - 4], 3
004ffa89 ff5250                   call      dword ptr [edx + 0x50]
004ffa8c 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004ffa92 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004ffa95 8b4850                   mov       ecx, dword ptr [eax + 0x50]
004ffa98 83c04c                   add       eax, 0x4c
004ffa9b c1e102                   shl       ecx, 2
004ffa9e 8d1c11                   lea       ebx, [ecx + edx]
004ffaa1 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004ffaa7 6a00                     push      0
004ffaa9 891c11                   mov       dword ptr [ecx + edx], ebx
004ffaac 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ffab2 8b4004                   mov       eax, dword ptr [eax + 4]
004ffab5 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004ffab8 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004ffabe 6aff                     push      -1
004ffac0 6a00                     push      0
004ffac2 c1e002                   shl       eax, 2
004ffac5 6a00                     push      0
004ffac7 8d1408                   lea       edx, [eax + ecx]
004ffaca 6a00                     push      0
004ffacc 33d3                     xor       edx, ebx
004fface 891408                   mov       dword ptr [eax + ecx], edx
004ffad1 8b07                     mov       eax, dword ptr [edi]
004ffad3 56                       push      esi
004ffad4 56                       push      esi
004ffad5 8bcf                     mov       ecx, edi
004ffad7 ff5048                   call      dword ptr [eax + 0x48]
004ffada 8d86501e0000             lea       eax, [esi + 0x1e50]
004ffae0 680afe0300               push      0x3fe0a
004ffae5 50                       push      eax
004ffae6 e885e23a00               call      0x8add70
004ffaeb 83c408                   add       esp, 8
004ffaee 84c0                     test      al, al
004ffaf0 0f8486000000             je        0x4ffb7c
004ffaf6 68c4000000               push      0xc4
004ffafb e85041f0ff               call      0x403c50
004ffb00 83c404                   add       esp, 4
004ffb03 894510                   mov       dword ptr [ebp + 0x10], eax
004ffb06 85c0                     test      eax, eax
004ffb08 c645fc06                 mov       byte ptr [ebp - 4], 6
004ffb0c 7413                     je        0x4ffb21
004ffb0e 6aff                     push      -1
004ffb10 6a00                     push      0
004ffb12 6a01                     push      1
004ffb14 6a05                     push      5
004ffb16 8bc8                     mov       ecx, eax
004ffb18 e8b391fcff               call      0x4c8cd0
004ffb1d 8bf8                     mov       edi, eax
004ffb1f eb02                     jmp       0x4ffb23
004ffb21 33ff                     xor       edi, edi
004ffb23 8b17                     mov       edx, dword ptr [edi]
004ffb25 8bcf                     mov       ecx, edi
004ffb27 c645fc03                 mov       byte ptr [ebp - 4], 3
004ffb2b ff5250                   call      dword ptr [edx + 0x50]
004ffb2e 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004ffb34 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004ffb37 8b4850                   mov       ecx, dword ptr [eax + 0x50]
004ffb3a 83c04c                   add       eax, 0x4c
004ffb3d c1e102                   shl       ecx, 2
004ffb40 8d1c11                   lea       ebx, [ecx + edx]
004ffb43 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004ffb49 6a00                     push      0
004ffb4b 891c11                   mov       dword ptr [ecx + edx], ebx
004ffb4e 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ffb54 8b4004                   mov       eax, dword ptr [eax + 4]
004ffb57 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004ffb5a 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004ffb60 6aff                     push      -1
004ffb62 6a00                     push      0
004ffb64 c1e002                   shl       eax, 2
004ffb67 6a00                     push      0
004ffb69 8d1408                   lea       edx, [eax + ecx]
004ffb6c 6a00                     push      0
004ffb6e 33d3                     xor       edx, ebx
004ffb70 891408                   mov       dword ptr [eax + ecx], edx
004ffb73 8b07                     mov       eax, dword ptr [edi]
004ffb75 56                       push      esi
004ffb76 56                       push      esi
004ffb77 8bcf                     mov       ecx, edi
004ffb79 ff5048                   call      dword ptr [eax + 0x48]
004ffb7c 8d86501e0000             lea       eax, [esi + 0x1e50]
004ffb82 680bfe0300               push      0x3fe0b
004ffb87 50                       push      eax
004ffb88 e8e3e13a00               call      0x8add70
004ffb8d 83c408                   add       esp, 8
004ffb90 84c0                     test      al, al
004ffb92 0f8486000000             je        0x4ffc1e
004ffb98 68c4000000               push      0xc4
004ffb9d e8ae40f0ff               call      0x403c50
004ffba2 83c404                   add       esp, 4
004ffba5 894510                   mov       dword ptr [ebp + 0x10], eax
004ffba8 85c0                     test      eax, eax
004ffbaa c645fc07                 mov       byte ptr [ebp - 4], 7
004ffbae 7413                     je        0x4ffbc3
004ffbb0 6aff                     push      -1
004ffbb2 6a00                     push      0
004ffbb4 6a03                     push      3
004ffbb6 6a05                     push      5
004ffbb8 8bc8                     mov       ecx, eax
004ffbba e81191fcff               call      0x4c8cd0
004ffbbf 8bf8                     mov       edi, eax
004ffbc1 eb02                     jmp       0x4ffbc5
004ffbc3 33ff                     xor       edi, edi
004ffbc5 8b17                     mov       edx, dword ptr [edi]
004ffbc7 8bcf                     mov       ecx, edi
004ffbc9 c645fc03                 mov       byte ptr [ebp - 4], 3
004ffbcd ff5250                   call      dword ptr [edx + 0x50]
004ffbd0 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004ffbd6 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004ffbd9 8b4850                   mov       ecx, dword ptr [eax + 0x50]
004ffbdc 83c04c                   add       eax, 0x4c
004ffbdf c1e102                   shl       ecx, 2
004ffbe2 8d1c11                   lea       ebx, [ecx + edx]
004ffbe5 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004ffbeb 6a00                     push      0
004ffbed 891c11                   mov       dword ptr [ecx + edx], ebx
004ffbf0 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ffbf6 8b4004                   mov       eax, dword ptr [eax + 4]
004ffbf9 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004ffbfc 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004ffc02 6aff                     push      -1
004ffc04 6a00                     push      0
004ffc06 c1e002                   shl       eax, 2
004ffc09 6a00                     push      0
004ffc0b 8d1408                   lea       edx, [eax + ecx]
004ffc0e 6a00                     push      0
004ffc10 33d3                     xor       edx, ebx
004ffc12 891408                   mov       dword ptr [eax + ecx], edx
004ffc15 8b07                     mov       eax, dword ptr [edi]
004ffc17 56                       push      esi
004ffc18 56                       push      esi
004ffc19 8bcf                     mov       ecx, edi
004ffc1b ff5048                   call      dword ptr [eax + 0x48]
004ffc1e 680cfe0300               push      0x3fe0c
004ffc23 8d9e501e0000             lea       ebx, [esi + 0x1e50]
004ffc29 53                       push      ebx
004ffc2a e841e13a00               call      0x8add70
004ffc2f 83c408                   add       esp, 8
004ffc32 84c0                     test      al, al
004ffc34 0f8482000000             je        0x4ffcbc
004ffc3a 68c4000000               push      0xc4
004ffc3f e80c40f0ff               call      0x403c50
004ffc44 83c404                   add       esp, 4
004ffc47 894510                   mov       dword ptr [ebp + 0x10], eax
004ffc4a 85c0                     test      eax, eax
004ffc4c c645fc08                 mov       byte ptr [ebp - 4], 8
004ffc50 7413                     je        0x4ffc65
004ffc52 6aff                     push      -1
004ffc54 6a00                     push      0
004ffc56 6a02                     push      2
004ffc58 6a05                     push      5
004ffc5a 8bc8                     mov       ecx, eax
004ffc5c e86f90fcff               call      0x4c8cd0
004ffc61 8bf8                     mov       edi, eax
004ffc63 eb02                     jmp       0x4ffc67
004ffc65 33ff                     xor       edi, edi
004ffc67 8b17                     mov       edx, dword ptr [edi]
004ffc69 8bcf                     mov       ecx, edi
004ffc6b c645fc03                 mov       byte ptr [ebp - 4], 3
004ffc6f ff5250                   call      dword ptr [edx + 0x50]
004ffc72 8b4850                   mov       ecx, dword ptr [eax + 0x50]
004ffc75 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004ffc7b 8b5244                   mov       edx, dword ptr [edx + 0x44]
004ffc7e 8d0c8a                   lea       ecx, [edx + ecx*4]
004ffc81 83c04c                   add       eax, 0x4c
004ffc84 8bd1                     mov       edx, ecx
004ffc86 3315dc012101             xor       edx, dword ptr [0x12101dc]
004ffc8c 6a00                     push      0
004ffc8e 8911                     mov       dword ptr [ecx], edx
