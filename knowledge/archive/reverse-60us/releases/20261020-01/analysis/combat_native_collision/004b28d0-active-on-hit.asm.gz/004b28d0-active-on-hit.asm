004b28d0 55                       push      ebp
004b28d1 8bec                     mov       ebp, esp
004b28d3 6aff                     push      -1
004b28d5 688975c500               push      0xc57589
004b28da 64a100000000             mov       eax, dword ptr fs:[0]
004b28e0 50                       push      eax
004b28e1 64892500000000           mov       dword ptr fs:[0], esp
004b28e8 83ec4c                   sub       esp, 0x4c
004b28eb 53                       push      ebx
004b28ec 56                       push      esi
004b28ed 57                       push      edi
004b28ee 8bf1                     mov       esi, ecx
004b28f0 e84bcbffff               call      0x4af440
004b28f5 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004b28f8 8dbeec140000             lea       edi, [esi + 0x14ec]
004b28fe c745dc17000000           mov       dword ptr [ebp - 0x24], 0x17
004b2905 8b07                     mov       eax, dword ptr [edi]
004b2907 85c0                     test      eax, eax
004b2909 7415                     je        0x4b2920
004b290b 8b5510                   mov       edx, dword ptr [ebp + 0x10]
004b290e 6a01                     push      1
004b2910 52                       push      edx
004b2911 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2914 8bc8                     mov       ecx, eax
004b2916 8b01                     mov       eax, dword ptr [ecx]
004b2918 52                       push      edx
004b2919 53                       push      ebx
004b291a ff90bc000000             call      dword ptr [eax + 0xbc]
004b2920 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
004b2923 83c704                   add       edi, 4
004b2926 48                       dec       eax
004b2927 8945dc                   mov       dword ptr [ebp - 0x24], eax
004b292a 75d9                     jne       0x4b2905
004b292c 8b03                     mov       eax, dword ptr [ebx]
004b292e 8bcb                     mov       ecx, ebx
004b2930 ff909c010000             call      dword ptr [eax + 0x19c]
004b2936 8b481c                   mov       ecx, dword ptr [eax + 0x1c]
004b2939 8b5020                   mov       edx, dword ptr [eax + 0x20]
004b293c 8d781c                   lea       edi, [eax + 0x1c]
004b293f 8945dc                   mov       dword ptr [ebp - 0x24], eax
004b2942 a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2947 33c8                     xor       ecx, eax
004b2949 2bcf                     sub       ecx, edi
004b294b 3bca                     cmp       ecx, edx
004b294d 7413                     je        0x4b2962
004b294f 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2955 6a3f                     push      0x3f
004b2957 57                       push      edi
004b2958 e853476600               call      0xb170b0
004b295d a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2962 8b5704                   mov       edx, dword ptr [edi + 4]
004b2965 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b296b 8b5944                   mov       ebx, dword ptr [ecx + 0x44]
004b296e c1e202                   shl       edx, 2
004b2971 8d3c1a                   lea       edi, [edx + ebx]
004b2974 333c1a                   xor       edi, dword ptr [edx + ebx]
004b2977 33f8                     xor       edi, eax
004b2979 897dd0                   mov       dword ptr [ebp - 0x30], edi
004b297c 8b7948                   mov       edi, dword ptr [ecx + 0x48]
004b297f 8d1c3a                   lea       ebx, [edx + edi]
004b2982 331c3a                   xor       ebx, dword ptr [edx + edi]
004b2985 8b7dd0                   mov       edi, dword ptr [ebp - 0x30]
004b2988 33d8                     xor       ebx, eax
004b298a 3bfb                     cmp       edi, ebx
004b298c 8b5ddc                   mov       ebx, dword ptr [ebp - 0x24]
004b298f 7416                     je        0x4b29a7
004b2991 6a40                     push      0x40
004b2993 8d431c                   lea       eax, [ebx + 0x1c]
004b2996 50                       push      eax
004b2997 e814476600               call      0xb170b0
004b299c a1dc012101               mov       eax, dword ptr [0x12101dc]
004b29a1 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b29a7 85ff                     test      edi, edi
004b29a9 752f                     jne       0x4b29da
004b29ab 8bcb                     mov       ecx, ebx
004b29ad e8fe09f8ff               call      0x4333b0
004b29b2 d81da4d7e900             fcomp     dword ptr [0xe9d7a4]
004b29b8 dfe0                     fnstsw    ax
004b29ba f6c441                   test      ah, 0x41
004b29bd 7410                     je        0x4b29cf
004b29bf 8d4b08                   lea       ecx, [ebx + 8]
004b29c2 e899f6f4ff               call      0x402060
004b29c7 85c0                     test      eax, eax
004b29c9 0f8ec5020000             jle       0x4b2c94
004b29cf a1dc012101               mov       eax, dword ptr [0x12101dc]
004b29d4 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b29da 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b29dd 8dbee8190000             lea       edi, [esi + 0x19e8]
004b29e3 3bfa                     cmp       edi, edx
004b29e5 7469                     je        0x4b2a50
004b29e7 8b5a04                   mov       ebx, dword ptr [edx + 4]
004b29ea 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004b29ed c1e302                   shl       ebx, 2
004b29f0 8d140b                   lea       edx, [ebx + ecx]
004b29f3 33140b                   xor       edx, dword ptr [ebx + ecx]
004b29f6 8b5f04                   mov       ebx, dword ptr [edi + 4]
004b29f9 33d0                     xor       edx, eax
004b29fb c1e302                   shl       ebx, 2
004b29fe 895dd0                   mov       dword ptr [ebp - 0x30], ebx
004b2a01 03d9                     add       ebx, ecx
004b2a03 33da                     xor       ebx, edx
004b2a05 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
004b2a08 33d8                     xor       ebx, eax
004b2a0a 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2a0d a1d8012101               mov       eax, dword ptr [0x12101d8]
004b2a12 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004b2a15 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2a18 8b5204                   mov       edx, dword ptr [edx + 4]
004b2a1b c1e202                   shl       edx, 2
004b2a1e 8b1c0a                   mov       ebx, dword ptr [edx + ecx]
004b2a21 8d040a                   lea       eax, [edx + ecx]
004b2a24 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004b2a2a 33c3                     xor       eax, ebx
004b2a2c 33c2                     xor       eax, edx
004b2a2e 8b5704                   mov       edx, dword ptr [edi + 4]
004b2a31 c1e202                   shl       edx, 2
004b2a34 8d1c0a                   lea       ebx, [edx + ecx]
004b2a37 33d8                     xor       ebx, eax
004b2a39 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b2a3f 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2a42 a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2a47 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2a4d 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2a50 83c208                   add       edx, 8
004b2a53 8d5f08                   lea       ebx, [edi + 8]
004b2a56 3bda                     cmp       ebx, edx
004b2a58 746a                     je        0x4b2ac4
004b2a5a 8b5a04                   mov       ebx, dword ptr [edx + 4]
004b2a5d 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004b2a60 c1e302                   shl       ebx, 2
004b2a63 8d140b                   lea       edx, [ebx + ecx]
004b2a66 33140b                   xor       edx, dword ptr [ebx + ecx]
004b2a69 8b5f0c                   mov       ebx, dword ptr [edi + 0xc]
004b2a6c 33d0                     xor       edx, eax
004b2a6e c1e302                   shl       ebx, 2
004b2a71 895dd0                   mov       dword ptr [ebp - 0x30], ebx
004b2a74 03d9                     add       ebx, ecx
004b2a76 33da                     xor       ebx, edx
004b2a78 33d8                     xor       ebx, eax
004b2a7a 8b45d0                   mov       eax, dword ptr [ebp - 0x30]
004b2a7d 891c08                   mov       dword ptr [eax + ecx], ebx
004b2a80 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b2a83 8b500c                   mov       edx, dword ptr [eax + 0xc]
004b2a86 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2a8c 8b4948                   mov       ecx, dword ptr [ecx + 0x48]
004b2a8f 83c008                   add       eax, 8
004b2a92 c1e202                   shl       edx, 2
004b2a95 8b1c0a                   mov       ebx, dword ptr [edx + ecx]
004b2a98 8d040a                   lea       eax, [edx + ecx]
004b2a9b 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004b2aa1 33c3                     xor       eax, ebx
004b2aa3 33c2                     xor       eax, edx
004b2aa5 8b570c                   mov       edx, dword ptr [edi + 0xc]
004b2aa8 c1e202                   shl       edx, 2
004b2aab 8d1c0a                   lea       ebx, [edx + ecx]
004b2aae 33d8                     xor       ebx, eax
004b2ab0 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b2ab6 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2ab9 a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2abe 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2ac4 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2ac7 83c210                   add       edx, 0x10
004b2aca 8d5f10                   lea       ebx, [edi + 0x10]
004b2acd 3bda                     cmp       ebx, edx
004b2acf 7469                     je        0x4b2b3a
004b2ad1 8b5a04                   mov       ebx, dword ptr [edx + 4]
004b2ad4 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004b2ad7 c1e302                   shl       ebx, 2
004b2ada 8d140b                   lea       edx, [ebx + ecx]
004b2add 33140b                   xor       edx, dword ptr [ebx + ecx]
004b2ae0 8b5f14                   mov       ebx, dword ptr [edi + 0x14]
004b2ae3 33d0                     xor       edx, eax
004b2ae5 c1e302                   shl       ebx, 2
004b2ae8 895dd0                   mov       dword ptr [ebp - 0x30], ebx
004b2aeb 03d9                     add       ebx, ecx
004b2aed 33da                     xor       ebx, edx
004b2aef 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
004b2af2 33d8                     xor       ebx, eax
004b2af4 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2af7 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b2afc 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004b2aff 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b2b02 8b5014                   mov       edx, dword ptr [eax + 0x14]
004b2b05 83c010                   add       eax, 0x10
004b2b08 c1e202                   shl       edx, 2
004b2b0b 8b1c0a                   mov       ebx, dword ptr [edx + ecx]
004b2b0e 8d040a                   lea       eax, [edx + ecx]
004b2b11 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004b2b17 33c3                     xor       eax, ebx
004b2b19 33c2                     xor       eax, edx
004b2b1b 8b5714                   mov       edx, dword ptr [edi + 0x14]
004b2b1e c1e202                   shl       edx, 2
004b2b21 8d1c0a                   lea       ebx, [edx + ecx]
004b2b24 33d8                     xor       ebx, eax
004b2b26 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b2b2c 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2b2f a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2b34 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2b3a 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2b3d 83c218                   add       edx, 0x18
004b2b40 8d5f18                   lea       ebx, [edi + 0x18]
004b2b43 3bda                     cmp       ebx, edx
004b2b45 746e                     je        0x4b2bb5
004b2b47 8b7a04                   mov       edi, dword ptr [edx + 4]
004b2b4a 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004b2b4d c1e702                   shl       edi, 2
004b2b50 8d140f                   lea       edx, [edi + ecx]
004b2b53 33140f                   xor       edx, dword ptr [edi + ecx]
004b2b56 8b7b04                   mov       edi, dword ptr [ebx + 4]
004b2b59 33d0                     xor       edx, eax
004b2b5b c1e702                   shl       edi, 2
004b2b5e 8d1c0f                   lea       ebx, [edi + ecx]
004b2b61 33da                     xor       ebx, edx
004b2b63 33d8                     xor       ebx, eax
004b2b65 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b2b68 891c0f                   mov       dword ptr [edi + ecx], ebx
004b2b6b 8b501c                   mov       edx, dword ptr [eax + 0x1c]
004b2b6e 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2b74 8b4948                   mov       ecx, dword ptr [ecx + 0x48]
004b2b77 83c018                   add       eax, 0x18
004b2b7a c1e202                   shl       edx, 2
004b2b7d 8b3c0a                   mov       edi, dword ptr [edx + ecx]
004b2b80 8d040a                   lea       eax, [edx + ecx]
004b2b83 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004b2b89 33c7                     xor       eax, edi
004b2b8b 33c2                     xor       eax, edx
004b2b8d 8b96041a0000             mov       edx, dword ptr [esi + 0x1a04]
004b2b93 8dbee8190000             lea       edi, [esi + 0x19e8]
004b2b99 c1e202                   shl       edx, 2
004b2b9c 8d1c0a                   lea       ebx, [edx + ecx]
004b2b9f 33d8                     xor       ebx, eax
004b2ba1 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b2ba7 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2baa a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2baf 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2bb5 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2bb8 8d5f20                   lea       ebx, [edi + 0x20]
004b2bbb 83c220                   add       edx, 0x20
004b2bbe 3bda                     cmp       ebx, edx
004b2bc0 895dd0                   mov       dword ptr [ebp - 0x30], ebx
004b2bc3 7464                     je        0x4b2c29
004b2bc5 8b7a04                   mov       edi, dword ptr [edx + 4]
004b2bc8 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004b2bcb c1e702                   shl       edi, 2
004b2bce 8d140f                   lea       edx, [edi + ecx]
004b2bd1 33140f                   xor       edx, dword ptr [edi + ecx]
004b2bd4 8b7b04                   mov       edi, dword ptr [ebx + 4]
004b2bd7 33d0                     xor       edx, eax
004b2bd9 c1e702                   shl       edi, 2
004b2bdc 8d1c0f                   lea       ebx, [edi + ecx]
004b2bdf 33da                     xor       ebx, edx
004b2be1 33d8                     xor       ebx, eax
004b2be3 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b2be6 891c0f                   mov       dword ptr [edi + ecx], ebx
004b2be9 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b2bef 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004b2bf2 8b5024                   mov       edx, dword ptr [eax + 0x24]
004b2bf5 83c020                   add       eax, 0x20
004b2bf8 c1e202                   shl       edx, 2
004b2bfb 8b3c0a                   mov       edi, dword ptr [edx + ecx]
004b2bfe 8d040a                   lea       eax, [edx + ecx]
004b2c01 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
004b2c04 8b5204                   mov       edx, dword ptr [edx + 4]
004b2c07 33c7                     xor       eax, edi
004b2c09 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004b2c0f c1e202                   shl       edx, 2
004b2c12 33c7                     xor       eax, edi
004b2c14 8d1c0a                   lea       ebx, [edx + ecx]
004b2c17 33d8                     xor       ebx, eax
004b2c19 33df                     xor       ebx, edi
004b2c1b 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2c1e a1dc012101               mov       eax, dword ptr [0x12101dc]
004b2c23 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2c29 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2c2c 8d9e101a0000             lea       ebx, [esi + 0x1a10]
004b2c32 83c228                   add       edx, 0x28
004b2c35 3bda                     cmp       ebx, edx
004b2c37 895dd0                   mov       dword ptr [ebp - 0x30], ebx
004b2c3a 7458                     je        0x4b2c94
004b2c3c 8b7a04                   mov       edi, dword ptr [edx + 4]
004b2c3f 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004b2c42 c1e702                   shl       edi, 2
004b2c45 8d140f                   lea       edx, [edi + ecx]
004b2c48 33140f                   xor       edx, dword ptr [edi + ecx]
004b2c4b 8b7b04                   mov       edi, dword ptr [ebx + 4]
004b2c4e 33d0                     xor       edx, eax
004b2c50 c1e702                   shl       edi, 2
004b2c53 8d1c0f                   lea       ebx, [edi + ecx]
004b2c56 33da                     xor       ebx, edx
004b2c58 33d8                     xor       ebx, eax
004b2c5a 891c0f                   mov       dword ptr [edi + ecx], ebx
004b2c5d a1d8012101               mov       eax, dword ptr [0x12101d8]
004b2c62 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004b2c65 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b2c68 8b502c                   mov       edx, dword ptr [eax + 0x2c]
004b2c6b 83c028                   add       eax, 0x28
004b2c6e c1e202                   shl       edx, 2
004b2c71 8b3c0a                   mov       edi, dword ptr [edx + ecx]
004b2c74 8d040a                   lea       eax, [edx + ecx]
004b2c77 8b55d0                   mov       edx, dword ptr [ebp - 0x30]
004b2c7a 8b5204                   mov       edx, dword ptr [edx + 4]
004b2c7d 33c7                     xor       eax, edi
004b2c7f 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004b2c85 c1e202                   shl       edx, 2
004b2c88 33c7                     xor       eax, edi
004b2c8a 8d1c0a                   lea       ebx, [edx + ecx]
004b2c8d 33d8                     xor       ebx, eax
004b2c8f 33df                     xor       ebx, edi
004b2c91 891c0a                   mov       dword ptr [edx + ecx], ebx
004b2c94 8b4510                   mov       eax, dword ptr [ebp + 0x10]
004b2c97 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
004b2c9a 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004b2c9d 50                       push      eax
004b2c9e 57                       push      edi
004b2c9f 53                       push      ebx
004b2ca0 8bce                     mov       ecx, esi
004b2ca2 e809870300               call      0x4eb3b0
004b2ca7 53                       push      ebx
004b2ca8 56                       push      esi
004b2ca9 c745ec00000000           mov       dword ptr [ebp - 0x14], 0
004b2cb0 e8ab640300               call      0x4e9160
004b2cb5 8845f3                   mov       byte ptr [ebp - 0xd], al
004b2cb8 8a4510                   mov       al, byte ptr [ebp + 0x10]
004b2cbb 83c408                   add       esp, 8
004b2cbe 84c0                     test      al, al
004b2cc0 0f856f090000             jne       0x4b3635
004b2cc6 8b13                     mov       edx, dword ptr [ebx]
004b2cc8 8bcb                     mov       ecx, ebx
004b2cca ff929c010000             call      dword ptr [edx + 0x19c]
004b2cd0 50                       push      eax
004b2cd1 8bce                     mov       ecx, esi
004b2cd3 8945e8                   mov       dword ptr [ebp - 0x18], eax
004b2cd6 e8355e0300               call      0x4e8b10
004b2cdb 84c0                     test      al, al
004b2cdd 0f84ae000000             je        0x4b2d91
004b2ce3 8b06                     mov       eax, dword ptr [esi]
004b2ce5 8bce                     mov       ecx, esi
004b2ce7 ff90e4000000             call      dword ptr [eax + 0xe4]
004b2ced 68e8010000               push      0x1e8
004b2cf2 8bf8                     mov       edi, eax
004b2cf4 e8570ff5ff               call      0x403c50
004b2cf9 83c404                   add       esp, 4
004b2cfc 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b2cff 85c0                     test      eax, eax
004b2d01 c745fc00000000           mov       dword ptr [ebp - 4], 0
004b2d08 7410                     je        0x4b2d1a
004b2d0a 6a01                     push      1
004b2d0c 68280dcd00               push      0xcd0d28
004b2d11 8bc8                     mov       ecx, eax
004b2d13 e8b809feff               call      0x4936d0
004b2d18 eb02                     jmp       0x4b2d1c
004b2d1a 33c0                     xor       eax, eax
004b2d1c 8b16                     mov       edx, dword ptr [esi]
004b2d1e 6a01                     push      1
004b2d20 6a00                     push      0
004b2d22 6a01                     push      1
004b2d24 6a01                     push      1
004b2d26 6a00                     push      0
004b2d28 6a01                     push      1
004b2d2a f7df                     neg       edi
004b2d2c 57                       push      edi
004b2d2d 6a00                     push      0
004b2d2f 50                       push      eax
004b2d30 6a64                     push      0x64
004b2d32 8bce                     mov       ecx, esi
004b2d34 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b2d3b ff92f8000000             call      dword ptr [edx + 0xf8]
004b2d41 68e8010000               push      0x1e8
004b2d46 e8050ff5ff               call      0x403c50
004b2d4b 83c404                   add       esp, 4
004b2d4e 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b2d51 85c0                     test      eax, eax
004b2d53 c745fc01000000           mov       dword ptr [ebp - 4], 1
004b2d5a 7410                     je        0x4b2d6c
004b2d5c 6a01                     push      1
004b2d5e 68c80ccd00               push      0xcd0cc8
004b2d63 8bc8                     mov       ecx, eax
004b2d65 e86609feff               call      0x4936d0
004b2d6a eb02                     jmp       0x4b2d6e
004b2d6c 33c0                     xor       eax, eax
004b2d6e 8b16                     mov       edx, dword ptr [esi]
004b2d70 6a01                     push      1
004b2d72 6a00                     push      0
004b2d74 6a01                     push      1
004b2d76 6a01                     push      1
004b2d78 6a00                     push      0
004b2d7a 6a01                     push      1
004b2d7c 57                       push      edi
004b2d7d 6a00                     push      0
004b2d7f 50                       push      eax
004b2d80 6a63                     push      0x63
004b2d82 8bce                     mov       ecx, esi
004b2d84 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b2d8b ff92f8000000             call      dword ptr [edx + 0xf8]
004b2d91 8dbeec140000             lea       edi, [esi + 0x14ec]
004b2d97 c745dc17000000           mov       dword ptr [ebp - 0x24], 0x17
004b2d9e 8bff                     mov       edi, edi
004b2da0 8b07                     mov       eax, dword ptr [edi]
004b2da2 85c0                     test      eax, eax
004b2da4 7416                     je        0x4b2dbc
004b2da6 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b2da9 6a00                     push      0
004b2dab 52                       push      edx
004b2dac 56                       push      esi
004b2dad 6a00                     push      0
004b2daf 8bc8                     mov       ecx, eax
004b2db1 8b01                     mov       eax, dword ptr [ecx]
004b2db3 53                       push      ebx
004b2db4 6a01                     push      1
004b2db6 ff9098010000             call      dword ptr [eax + 0x198]
004b2dbc 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
004b2dbf 83c704                   add       edi, 4
004b2dc2 48                       dec       eax
004b2dc3 8945dc                   mov       dword ptr [ebp - 0x24], eax
004b2dc6 75d8                     jne       0x4b2da0
004b2dc8 8bce                     mov       ecx, esi
004b2dca e8c192feff               call      0x49c090
004b2dcf 84c0                     test      al, al
004b2dd1 0f8455080000             je        0x4b362c
004b2dd7 8b06                     mov       eax, dword ptr [esi]
004b2dd9 8bce                     mov       ecx, esi
004b2ddb ff90f4000000             call      dword ptr [eax + 0xf4]
004b2de1 85c0                     test      eax, eax
004b2de3 0f8443080000             je        0x4b362c
004b2de9 8b8ebc040000             mov       ecx, dword ptr [esi + 0x4bc]
004b2def 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004b2df5 8b86c0040000             mov       eax, dword ptr [esi + 0x4c0]
004b2dfb 8d9ebc040000             lea       ebx, [esi + 0x4bc]
004b2e01 33cf                     xor       ecx, edi
004b2e03 2bcb                     sub       ecx, ebx
004b2e05 3bc8                     cmp       ecx, eax
004b2e07 740e                     je        0x4b2e17
004b2e09 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2e0f 6a3f                     push      0x3f
004b2e11 53                       push      ebx
004b2e12 e899426600               call      0xb170b0
004b2e17 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b2e1d 8b4a44                   mov       ecx, dword ptr [edx + 0x44]
004b2e20 8b4304                   mov       eax, dword ptr [ebx + 4]
004b2e23 c1e002                   shl       eax, 2
004b2e26 8d3c08                   lea       edi, [eax + ecx]
004b2e29 333c08                   xor       edi, dword ptr [eax + ecx]
004b2e2c 333ddc012101             xor       edi, dword ptr [0x12101dc]
004b2e32 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004b2e35 8d1408                   lea       edx, [eax + ecx]
004b2e38 331408                   xor       edx, dword ptr [eax + ecx]
004b2e3b 3315dc012101             xor       edx, dword ptr [0x12101dc]
004b2e41 3bfa                     cmp       edi, edx
004b2e43 740e                     je        0x4b2e53
004b2e45 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b2e4b 6a40                     push      0x40
004b2e4d 53                       push      ebx
004b2e4e e85d426600               call      0xb170b0
004b2e53 85ff                     test      edi, edi
004b2e55 740d                     je        0x4b2e64
004b2e57 8d8ec4040000             lea       ecx, [esi + 0x4c4]
004b2e5d e8fef1f4ff               call      0x402060
004b2e62 eb07                     jmp       0x4b2e6b
004b2e64 8bce                     mov       ecx, esi
004b2e66 e87571feff               call      0x499fe0
004b2e6b 85c0                     test      eax, eax
004b2e6d 7409                     je        0x4b2e78
004b2e6f 83f801                   cmp       eax, 1
004b2e72 0f855f030000             jne       0x4b31d7
004b2e78 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004b2e7b 8b06                     mov       eax, dword ptr [esi]
004b2e7d 53                       push      ebx
004b2e7e 8bce                     mov       ecx, esi
004b2e80 ff9078050000             call      dword ptr [eax + 0x578]
004b2e86 8b16                     mov       edx, dword ptr [esi]
004b2e88 53                       push      ebx
004b2e89 8d45e0                   lea       eax, [ebp - 0x20]
004b2e8c 50                       push      eax
004b2e8d 8bce                     mov       ecx, esi
004b2e8f c645d800                 mov       byte ptr [ebp - 0x28], 0
004b2e93 c745e064000000           mov       dword ptr [ebp - 0x20], 0x64
004b2e9a c745e400000000           mov       dword ptr [ebp - 0x1c], 0
004b2ea1 ff9210030000             call      dword ptr [edx + 0x310]
004b2ea7 8b4de0                   mov       ecx, dword ptr [ebp - 0x20]
004b2eaa 8b16                     mov       edx, dword ptr [esi]
004b2eac 6a00                     push      0
004b2eae 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b2eb1 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b2eb4 50                       push      eax
004b2eb5 53                       push      ebx
004b2eb6 51                       push      ecx
004b2eb7 8d45e4                   lea       eax, [ebp - 0x1c]
004b2eba 50                       push      eax
004b2ebb 8d4dd8                   lea       ecx, [ebp - 0x28]
004b2ebe 51                       push      ecx
004b2ebf 8bce                     mov       ecx, esi
004b2ec1 ff92f8020000             call      dword ptr [edx + 0x2f8]
004b2ec7 8b55e8                   mov       edx, dword ptr [ebp - 0x18]
004b2eca 52                       push      edx
004b2ecb 8bce                     mov       ecx, esi
004b2ecd 8945ec                   mov       dword ptr [ebp - 0x14], eax
004b2ed0 e83b5c0300               call      0x4e8b10
004b2ed5 84c0                     test      al, al
004b2ed7 0f8457010000             je        0x4b3034
004b2edd 8b06                     mov       eax, dword ptr [esi]
004b2edf 8bce                     mov       ecx, esi
004b2ee1 ff90e4000000             call      dword ptr [eax + 0xe4]
004b2ee7 68e8010000               push      0x1e8
004b2eec 8bf8                     mov       edi, eax
004b2eee e85d0df5ff               call      0x403c50
004b2ef3 83c404                   add       esp, 4
004b2ef6 8945cc                   mov       dword ptr [ebp - 0x34], eax
004b2ef9 85c0                     test      eax, eax
004b2efb c745fc02000000           mov       dword ptr [ebp - 4], 2
004b2f02 7410                     je        0x4b2f14
004b2f04 6a01                     push      1
004b2f06 68280dcd00               push      0xcd0d28
004b2f0b 8bc8                     mov       ecx, eax
004b2f0d e8be07feff               call      0x4936d0
004b2f12 eb02                     jmp       0x4b2f16
004b2f14 33c0                     xor       eax, eax
004b2f16 8b16                     mov       edx, dword ptr [esi]
004b2f18 6a01                     push      1
004b2f1a 6a00                     push      0
004b2f1c 6a01                     push      1
004b2f1e 6a01                     push      1
004b2f20 6a00                     push      0
004b2f22 6a01                     push      1
004b2f24 f7df                     neg       edi
004b2f26 57                       push      edi
004b2f27 6a00                     push      0
004b2f29 50                       push      eax
004b2f2a 6a64                     push      0x64
004b2f2c 8bce                     mov       ecx, esi
004b2f2e c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b2f35 ff92f8000000             call      dword ptr [edx + 0xf8]
004b2f3b 68e8010000               push      0x1e8
004b2f40 e80b0df5ff               call      0x403c50
004b2f45 83c404                   add       esp, 4
004b2f48 8945cc                   mov       dword ptr [ebp - 0x34], eax
004b2f4b 85c0                     test      eax, eax
004b2f4d c745fc03000000           mov       dword ptr [ebp - 4], 3
004b2f54 7410                     je        0x4b2f66
004b2f56 6a01                     push      1
004b2f58 68c80ccd00               push      0xcd0cc8
004b2f5d 8bc8                     mov       ecx, eax
004b2f5f e86c07feff               call      0x4936d0
004b2f64 eb02                     jmp       0x4b2f68
004b2f66 33c0                     xor       eax, eax
004b2f68 8b16                     mov       edx, dword ptr [esi]
004b2f6a 6a01                     push      1
004b2f6c 6a00                     push      0
004b2f6e 6a01                     push      1
004b2f70 6a01                     push      1
004b2f72 6a00                     push      0
004b2f74 6a01                     push      1
004b2f76 57                       push      edi
004b2f77 6a00                     push      0
004b2f79 50                       push      eax
004b2f7a 6a63                     push      0x63
004b2f7c 8bce                     mov       ecx, esi
004b2f7e c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b2f85 ff92f8000000             call      dword ptr [edx + 0xf8]
004b2f8b 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004b2f8e 81c128010000             add       ecx, 0x128
004b2f94 e81704f8ff               call      0x4333b0
004b2f99 d80d1009cd00             fmul      dword ptr [0xcd0910]
004b2f9f 8b06                     mov       eax, dword ptr [esi]
004b2fa1 8bce                     mov       ecx, esi
004b2fa3 d95dcc                   fstp      dword ptr [ebp - 0x34]
004b2fa6 ff9034020000             call      dword ptr [eax + 0x234]
004b2fac 8945d4                   mov       dword ptr [ebp - 0x2c], eax
004b2faf db45d4                   fild      dword ptr [ebp - 0x2c]
004b2fb2 d84dcc                   fmul      dword ptr [ebp - 0x34]
004b2fb5 e88ae57400               call      0xc01544
004b2fba 6a00                     push      0
004b2fbc 682829f400               push      0xf42928
004b2fc1 686c52f500               push      0xf5526c
004b2fc6 6a00                     push      0
004b2fc8 56                       push      esi
004b2fc9 8bf8                     mov       edi, eax
004b2fcb e83bdd7400               call      0xc00d0b
004b2fd0 83c414                   add       esp, 0x14
004b2fd3 85c0                     test      eax, eax
004b2fd5 745a                     je        0x4b3031
004b2fd7 8b88e4190000             mov       ecx, dword ptr [eax + 0x19e4]
004b2fdd 83f901                   cmp       ecx, 1
004b2fe0 7512                     jne       0x4b2ff4
004b2fe2 b856555555               mov       eax, 0x55555556
004b2fe7 f7ef                     imul      edi
004b2fe9 8bca                     mov       ecx, edx
004b2feb c1e91f                   shr       ecx, 0x1f
004b2fee 03ca                     add       ecx, edx
004b2ff0 8bf9                     mov       edi, ecx
004b2ff2 eb3d                     jmp       0x4b3031
004b2ff4 83f902                   cmp       ecx, 2
004b2ff7 7507                     jne       0x4b3000
004b2ff9 b856555555               mov       eax, 0x55555556
004b2ffe eb26                     jmp       0x4b3026
004b3000 83f903                   cmp       ecx, 3
004b3003 7512                     jne       0x4b3017
004b3005 b8abaaaa2a               mov       eax, 0x2aaaaaab
004b300a f7ef                     imul      edi
004b300c 8bca                     mov       ecx, edx
004b300e c1e91f                   shr       ecx, 0x1f
004b3011 03ca                     add       ecx, edx
004b3013 8bf9                     mov       edi, ecx
004b3015 eb1a                     jmp       0x4b3031
004b3017 8a881c1e0000             mov       cl, byte ptr [eax + 0x1e1c]
004b301d 84c9                     test      cl, cl
004b301f 7410                     je        0x4b3031
004b3021 b8abaaaa2a               mov       eax, 0x2aaaaaab
004b3026 f7ef                     imul      edi
004b3028 8bc2                     mov       eax, edx
004b302a c1e81f                   shr       eax, 0x1f
004b302d 03c2                     add       eax, edx
004b302f 8bf8                     mov       edi, eax
004b3031 017dec                   add       dword ptr [ebp - 0x14], edi
004b3034 8b8edc120000             mov       ecx, dword ptr [esi + 0x12dc]
004b303a 85c9                     test      ecx, ecx
004b303c 740a                     je        0x4b3048
004b303e 53                       push      ebx
004b303f 8d55ec                   lea       edx, [ebp - 0x14]
004b3042 52                       push      edx
004b3043 e8483c0000               call      0x4b6c90
004b3048 8b06                     mov       eax, dword ptr [esi]
004b304a 8bce                     mov       ecx, esi
004b304c ff9034020000             call      dword ptr [eax + 0x234]
004b3052 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004b3055 3bc8                     cmp       ecx, eax
004b3057 7d05                     jge       0x4b305e
004b3059 894dd4                   mov       dword ptr [ebp - 0x2c], ecx
004b305c eb0d                     jmp       0x4b306b
004b305e 8b16                     mov       edx, dword ptr [esi]
004b3060 8bce                     mov       ecx, esi
004b3062 ff9234020000             call      dword ptr [edx + 0x234]
004b3068 8945d4                   mov       dword ptr [ebp - 0x2c], eax
004b306b 8b03                     mov       eax, dword ptr [ebx]
004b306d 8bcb                     mov       ecx, ebx
004b306f ff909c010000             call      dword ptr [eax + 0x19c]
004b3075 83b87801000002           cmp       dword ptr [eax + 0x178], 2
004b307c 755d                     jne       0x4b30db
004b307e 6800010000               push      0x100
004b3083 e8c80bf5ff               call      0x403c50
004b3088 83c404                   add       esp, 4
004b308b 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b308e 85c0                     test      eax, eax
004b3090 c745fc04000000           mov       dword ptr [ebp - 4], 4
004b3097 7421                     je        0x4b30ba
004b3099 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004b309c 6a01                     push      1
004b309e f7d9                     neg       ecx
004b30a0 6a00                     push      0
004b30a2 894dcc                   mov       dword ptr [ebp - 0x34], ecx
004b30a5 db45cc                   fild      dword ptr [ebp - 0x34]
004b30a8 68e8030000               push      0x3e8
004b30ad 51                       push      ecx
004b30ae 8bc8                     mov       ecx, eax
004b30b0 d91c24                   fstp      dword ptr [esp]
004b30b3 e8f86afbff               call      0x469bb0
004b30b8 eb02                     jmp       0x4b30bc
004b30ba 33c0                     xor       eax, eax
004b30bc 8b10                     mov       edx, dword ptr [eax]
004b30be 6a00                     push      0
004b30c0 6aff                     push      -1
004b30c2 6a00                     push      0
004b30c4 6a00                     push      0
004b30c6 6a00                     push      0
004b30c8 53                       push      ebx
004b30c9 56                       push      esi
004b30ca 8bc8                     mov       ecx, eax
004b30cc c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b30d3 ff5248                   call      dword ptr [edx + 0x48]
004b30d6 e9ff000000               jmp       0x4b31da
004b30db 8b03                     mov       eax, dword ptr [ebx]
004b30dd 8bcb                     mov       ecx, ebx
004b30df ff909c010000             call      dword ptr [eax + 0x19c]
004b30e5 83b87801000004           cmp       dword ptr [eax + 0x178], 4
004b30ec 7531                     jne       0x4b311f
004b30ee 68a4000000               push      0xa4
004b30f3 e8580bf5ff               call      0x403c50
004b30f8 83c404                   add       esp, 4
004b30fb 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b30fe 85c0                     test      eax, eax
004b3100 c745fc05000000           mov       dword ptr [ebp - 4], 5
004b3107 74b1                     je        0x4b30ba
004b3109 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004b310c 6a01                     push      1
004b310e f7d9                     neg       ecx
004b3110 68e8030000               push      0x3e8
004b3115 51                       push      ecx
004b3116 8bc8                     mov       ecx, eax
004b3118 e8936cfbff               call      0x469db0
004b311d eb9d                     jmp       0x4b30bc
004b311f 8b3e                     mov       edi, dword ptr [esi]
004b3121 53                       push      ebx
004b3122 6a00                     push      0
004b3124 8d8e30120000             lea       ecx, [esi + 0x1230]
004b312a e831eff4ff               call      0x402060
004b312f 2b45ec                   sub       eax, dword ptr [ebp - 0x14]
004b3132 50                       push      eax
004b3133 8bce                     mov       ecx, esi
004b3135 ff97e8030000             call      dword ptr [edi + 0x3e8]
004b313b a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3140 8b4844                   mov       ecx, dword ptr [eax + 0x44]
004b3143 8b86c8150000             mov       eax, dword ptr [esi + 0x15c8]
004b3149 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004b314f c1e002                   shl       eax, 2
004b3152 8d1408                   lea       edx, [eax + ecx]
004b3155 f7d2                     not       edx
004b3157 33d7                     xor       edx, edi
004b3159 891408                   mov       dword ptr [eax + ecx], edx
004b315c a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3161 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004b3164 8b86c8150000             mov       eax, dword ptr [esi + 0x15c8]
004b316a 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004b3170 c1e002                   shl       eax, 2
004b3173 8d1408                   lea       edx, [eax + ecx]
004b3176 f7d2                     not       edx
004b3178 33d7                     xor       edx, edi
004b317a 891408                   mov       dword ptr [eax + ecx], edx
004b317d 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004b3180 85c0                     test      eax, eax
004b3182 752f                     jne       0x4b31b3
004b3184 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
004b3187 8d4f1c                   lea       ecx, [edi + 0x1c]
004b318a e8d1eef4ff               call      0x402060
004b318f 85c0                     test      eax, eax
004b3191 7520                     jne       0x4b31b3
004b3193 8bcf                     mov       ecx, edi
004b3195 e81602f8ff               call      0x4333b0
004b319a d81da4d7e900             fcomp     dword ptr [0xe9d7a4]
004b31a0 dfe0                     fnstsw    ax
004b31a2 f6c441                   test      ah, 0x41
004b31a5 740c                     je        0x4b31b3
004b31a7 8d4f08                   lea       ecx, [edi + 8]
004b31aa e8b1eef4ff               call      0x402060
004b31af 85c0                     test      eax, eax
004b31b1 7e27                     jle       0x4b31da
004b31b3 8b45c8                   mov       eax, dword ptr [ebp - 0x38]
004b31b6 8b4de4                   mov       ecx, dword ptr [ebp - 0x1c]
004b31b9 8b55d8                   mov       edx, dword ptr [ebp - 0x28]
004b31bc 50                       push      eax
004b31bd 8b45d4                   mov       eax, dword ptr [ebp - 0x2c]
004b31c0 51                       push      ecx
004b31c1 8b4dec                   mov       ecx, dword ptr [ebp - 0x14]
004b31c4 52                       push      edx
004b31c5 8b550c                   mov       edx, dword ptr [ebp + 0xc]
004b31c8 50                       push      eax
004b31c9 51                       push      ecx
004b31ca 52                       push      edx
004b31cb 56                       push      esi
004b31cc 53                       push      ebx
004b31cd e82e9effff               call      0x4ad000
004b31d2 83c420                   add       esp, 0x20
004b31d5 eb03                     jmp       0x4b31da
004b31d7 8b5d08                   mov       ebx, dword ptr [ebp + 8]
004b31da 33c0                     xor       eax, eax
004b31dc 53                       push      ebx
004b31dd 8d4ddc                   lea       ecx, [ebp - 0x24]
004b31e0 51                       push      ecx
004b31e1 8d55d0                   lea       edx, [ebp - 0x30]
004b31e4 8945d0                   mov       dword ptr [ebp - 0x30], eax
004b31e7 8945dc                   mov       dword ptr [ebp - 0x24], eax
004b31ea 8b06                     mov       eax, dword ptr [esi]
004b31ec 52                       push      edx
004b31ed 8bce                     mov       ecx, esi
004b31ef ff90e0030000             call      dword ptr [eax + 0x3e0]
004b31f5 8bf8                     mov       edi, eax
004b31f7 83ffff                   cmp       edi, -1
004b31fa 744a                     je        0x4b3246
004b31fc 8a869c040000             mov       al, byte ptr [esi + 0x49c]
004b3202 84c0                     test      al, al
004b3204 7440                     je        0x4b3246
004b3206 8b03                     mov       eax, dword ptr [ebx]
004b3208 8bcb                     mov       ecx, ebx
004b320a ff909c010000             call      dword ptr [eax + 0x19c]
004b3210 83b87801000002           cmp       dword ptr [eax + 0x178], 2
004b3217 7523                     jne       0x4b323c
004b3219 6a00                     push      0
004b321b e8d0ae3f00               call      0x8ae0f0
004b3220 99                       cdq       
004b3221 b964000000               mov       ecx, 0x64
004b3226 f7f9                     idiv      ecx
004b3228 83c404                   add       esp, 4
004b322b 83fa14                   cmp       edx, 0x14
004b322e 7d0c                     jge       0x4b323c
004b3230 8b16                     mov       edx, dword ptr [esi]
004b3232 8bce                     mov       ecx, esi
004b3234 ff92dc040000             call      dword ptr [edx + 0x4dc]
004b323a eb0a                     jmp       0x4b3246
004b323c 8b06                     mov       eax, dword ptr [esi]
004b323e 8bce                     mov       ecx, esi
004b3240 ff90dc040000             call      dword ptr [eax + 0x4dc]
004b3246 83ff03                   cmp       edi, 3
004b3249 0f85bf010000             jne       0x4b340e
004b324f 8b16                     mov       edx, dword ptr [esi]
004b3251 bb01000000               mov       ebx, 1
004b3256 53                       push      ebx
004b3257 8bce                     mov       ecx, esi
004b3259 ff9274030000             call      dword ptr [edx + 0x374]
004b325f 85c0                     test      eax, eax
004b3261 7518                     jne       0x4b327b
004b3263 8b06                     mov       eax, dword ptr [esi]
004b3265 53                       push      ebx
004b3266 8bce                     mov       ecx, esi
004b3268 ff909c030000             call      dword ptr [eax + 0x39c]
004b326e 85c0                     test      eax, eax
004b3270 7409                     je        0x4b327b
004b3272 c745e000000000           mov       dword ptr [ebp - 0x20], 0
004b3279 eb5d                     jmp       0x4b32d8
004b327b 8b16                     mov       edx, dword ptr [esi]
004b327d 6a00                     push      0
004b327f 8bce                     mov       ecx, esi
004b3281 ff9274030000             call      dword ptr [edx + 0x374]
004b3287 85c0                     test      eax, eax
004b3289 7515                     jne       0x4b32a0
004b328b 8b06                     mov       eax, dword ptr [esi]
004b328d 6a00                     push      0
004b328f 8bce                     mov       ecx, esi
004b3291 ff909c030000             call      dword ptr [eax + 0x39c]
004b3297 85c0                     test      eax, eax
004b3299 7405                     je        0x4b32a0
004b329b 895de0                   mov       dword ptr [ebp - 0x20], ebx
004b329e eb38                     jmp       0x4b32d8
004b32a0 8d8e5c150000             lea       ecx, [esi + 0x155c]
004b32a6 e8b5edf4ff               call      0x402060
004b32ab 83f803                   cmp       eax, 3
004b32ae 750f                     jne       0x4b32bf
004b32b0 8b86bc160000             mov       eax, dword ptr [esi + 0x16bc]
004b32b6 8bcb                     mov       ecx, ebx
004b32b8 2bc8                     sub       ecx, eax
004b32ba 894de0                   mov       dword ptr [ebp - 0x20], ecx
004b32bd eb19                     jmp       0x4b32d8
004b32bf 6a00                     push      0
004b32c1 e82aae3f00               call      0x8ae0f0
004b32c6 83c404                   add       esp, 4
004b32c9 2501000080               and       eax, 0x80000001
004b32ce 7905                     jns       0x4b32d5
004b32d0 48                       dec       eax
004b32d1 83c8fe                   or        eax, 0xfffffffe
004b32d4 40                       inc       eax
004b32d5 8945e0                   mov       dword ptr [ebp - 0x20], eax
004b32d8 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
004b32db 8d8f88010000             lea       ecx, [edi + 0x188]
004b32e1 e8ca00f8ff               call      0x4333b0
004b32e6 d955e4                   fst       dword ptr [ebp - 0x1c]
004b32e9 dc25f0b8ca00             fsub      qword ptr [0xcab8f0]
004b32ef d9e1                     fabs      
004b32f1 d945e4                   fld       dword ptr [ebp - 0x1c]
004b32f4 d9e1                     fabs      
004b32f6 dc0de8b8ca00             fmul      qword ptr [0xcab8e8]
004b32fc ded9                     fcompp    
004b32fe dfe0                     fnstsw    ax
004b3300 f6c401                   test      ah, 1
004b3303 7507                     jne       0x4b330c
004b3305 c745e40000803f           mov       dword ptr [ebp - 0x1c], 0x3f800000
004b330c 395f18                   cmp       dword ptr [edi + 0x18], ebx
004b330f 750c                     jne       0x4b331d
004b3311 d945e4                   fld       dword ptr [ebp - 0x1c]
004b3314 d80ddcb9cc00             fmul      dword ptr [0xccb9dc]
004b331a d95de4                   fstp      dword ptr [ebp - 0x1c]
004b331d 8b86a0040000             mov       eax, dword ptr [esi + 0x4a0]
004b3323 83f804                   cmp       eax, 4
004b3326 0f8414030000             je        0x4b3640
004b332c 83f805                   cmp       eax, 5
004b332f 0f840b030000             je        0x4b3640
004b3335 33db                     xor       ebx, ebx
004b3337 895dbc                   mov       dword ptr [ebp - 0x44], ebx
004b333a 895dc0                   mov       dword ptr [ebp - 0x40], ebx
004b333d 895dc4                   mov       dword ptr [ebp - 0x3c], ebx
004b3340 8b7d08                   mov       edi, dword ptr [ebp + 8]
004b3343 8b17                     mov       edx, dword ptr [edi]
004b3345 56                       push      esi
004b3346 8bcf                     mov       ecx, edi
004b3348 c745fc06000000           mov       dword ptr [ebp - 4], 6
004b334f ff921c030000             call      dword ptr [edx + 0x31c]
004b3355 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b3358 8d45c8                   lea       eax, [ebp - 0x38]
004b335b 50                       push      eax
004b335c 8d4db8                   lea       ecx, [ebp - 0x48]
004b335f e8bc3df5ff               call      0x407120
004b3364 b904340001               mov       ecx, 0x1003404
004b3369 e84200f8ff               call      0x4333b0
004b336e d84de4                   fmul      dword ptr [ebp - 0x1c]
004b3371 e8cee17400               call      0xc01544
004b3376 8d4dc8                   lea       ecx, [ebp - 0x38]
004b3379 51                       push      ecx
004b337a 8d4db8                   lea       ecx, [ebp - 0x48]
004b337d 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b3380 e89b3df5ff               call      0x407120
004b3385 8d55e0                   lea       edx, [ebp - 0x20]
004b3388 52                       push      edx
004b3389 8d4db8                   lea       ecx, [ebp - 0x48]
004b338c e88f3df5ff               call      0x407120
004b3391 8b07                     mov       eax, dword ptr [edi]
004b3393 8bcf                     mov       ecx, edi
004b3395 ff909c010000             call      dword ptr [eax + 0x19c]
004b339b 8b8878010000             mov       ecx, dword ptr [eax + 0x178]
004b33a1 8d55c8                   lea       edx, [ebp - 0x38]
004b33a4 894dc8                   mov       dword ptr [ebp - 0x38], ecx
004b33a7 52                       push      edx
004b33a8 8d4db8                   lea       ecx, [ebp - 0x48]
004b33ab e8703df5ff               call      0x407120
004b33b0 8b7de8                   mov       edi, dword ptr [ebp - 0x18]
004b33b3 81c718010000             add       edi, 0x118
004b33b9 8bcf                     mov       ecx, edi
004b33bb e8a0ecf4ff               call      0x402060
004b33c0 85c0                     test      eax, eax
004b33c2 7416                     je        0x4b33da
004b33c4 8bcf                     mov       ecx, edi
004b33c6 e895ecf4ff               call      0x402060
004b33cb 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b33ce 8d45c8                   lea       eax, [ebp - 0x38]
004b33d1 50                       push      eax
004b33d2 8d4db8                   lea       ecx, [ebp - 0x48]
004b33d5 e8463df5ff               call      0x407120
004b33da 8b16                     mov       edx, dword ptr [esi]
004b33dc 53                       push      ebx
004b33dd 53                       push      ebx
004b33de 6a03                     push      3
004b33e0 8d45b8                   lea       eax, [ebp - 0x48]
004b33e3 50                       push      eax
004b33e4 6a03                     push      3
004b33e6 8bce                     mov       ecx, esi
004b33e8 ff928c020000             call      dword ptr [edx + 0x28c]
004b33ee 8b45bc                   mov       eax, dword ptr [ebp - 0x44]
004b33f1 3bc3                     cmp       eax, ebx
004b33f3 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b33fa 0f8440020000             je        0x4b3640
004b3400 50                       push      eax
004b3401 e8d7cb7400               call      0xbfffdd
004b3406 83c404                   add       esp, 4
004b3409 e932020000               jmp       0x4b3640
004b340e 83ff04                   cmp       edi, 4
004b3411 0f85c5010000             jne       0x4b35dc
004b3417 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004b341a 81c130010000             add       ecx, 0x130
004b3420 c745d401000000           mov       dword ptr [ebp - 0x2c], 1
004b3427 e834ecf4ff               call      0x402060
004b342c 85c0                     test      eax, eax
004b342e 740e                     je        0x4b343e
004b3430 8b45dc                   mov       eax, dword ptr [ebp - 0x24]
004b3433 85c0                     test      eax, eax
004b3435 7507                     jne       0x4b343e
004b3437 c745d402000000           mov       dword ptr [ebp - 0x2c], 2
004b343e 33c0                     xor       eax, eax
004b3440 8945bc                   mov       dword ptr [ebp - 0x44], eax
004b3443 8945c0                   mov       dword ptr [ebp - 0x40], eax
004b3446 8945c4                   mov       dword ptr [ebp - 0x3c], eax
004b3449 8b13                     mov       edx, dword ptr [ebx]
004b344b 56                       push      esi
004b344c 8bcb                     mov       ecx, ebx
004b344e c745fc07000000           mov       dword ptr [ebp - 4], 7
004b3455 ff921c030000             call      dword ptr [edx + 0x31c]
004b345b 8b5dc0                   mov       ebx, dword ptr [ebp - 0x40]
004b345e 8bf8                     mov       edi, eax
004b3460 8b45bc                   mov       eax, dword ptr [ebp - 0x44]
004b3463 85c0                     test      eax, eax
004b3465 897dc8                   mov       dword ptr [ebp - 0x38], edi
004b3468 741f                     je        0x4b3489
004b346a 8b55c4                   mov       edx, dword ptr [ebp - 0x3c]
004b346d 8bcb                     mov       ecx, ebx
004b346f 2bc8                     sub       ecx, eax
004b3471 2bd0                     sub       edx, eax
004b3473 c1f902                   sar       ecx, 2
004b3476 c1fa02                   sar       edx, 2
004b3479 3bca                     cmp       ecx, edx
004b347b 730c                     jae       0x4b3489
004b347d 8bd3                     mov       edx, ebx
004b347f 83c204                   add       edx, 4
004b3482 893b                     mov       dword ptr [ebx], edi
004b3484 8955c0                   mov       dword ptr [ebp - 0x40], edx
004b3487 eb12                     jmp       0x4b349b
004b3489 8d45c8                   lea       eax, [ebp - 0x38]
004b348c 50                       push      eax
004b348d 6a01                     push      1
004b348f 53                       push      ebx
004b3490 8d4db8                   lea       ecx, [ebp - 0x48]
004b3493 e8c82af5ff               call      0x405f60
004b3498 8b55c0                   mov       edx, dword ptr [ebp - 0x40]
004b349b 8b5dbc                   mov       ebx, dword ptr [ebp - 0x44]
004b349e 85db                     test      ebx, ebx
004b34a0 7420                     je        0x4b34c2
004b34a2 8b4dc4                   mov       ecx, dword ptr [ebp - 0x3c]
004b34a5 8bc2                     mov       eax, edx
004b34a7 2bc3                     sub       eax, ebx
004b34a9 2bcb                     sub       ecx, ebx
004b34ab c1f802                   sar       eax, 2
004b34ae c1f902                   sar       ecx, 2
004b34b1 3bc1                     cmp       eax, ecx
004b34b3 730d                     jae       0x4b34c2
004b34b5 8b4ddc                   mov       ecx, dword ptr [ebp - 0x24]
004b34b8 890a                     mov       dword ptr [edx], ecx
004b34ba 83c204                   add       edx, 4
004b34bd 8955c0                   mov       dword ptr [ebp - 0x40], edx
004b34c0 eb12                     jmp       0x4b34d4
004b34c2 8d45dc                   lea       eax, [ebp - 0x24]
004b34c5 50                       push      eax
004b34c6 6a01                     push      1
004b34c8 52                       push      edx
004b34c9 8d4db8                   lea       ecx, [ebp - 0x48]
004b34cc e88f2af5ff               call      0x405f60
004b34d1 8b55c0                   mov       edx, dword ptr [ebp - 0x40]
004b34d4 8b5dbc                   mov       ebx, dword ptr [ebp - 0x44]
004b34d7 85db                     test      ebx, ebx
004b34d9 8b7dd4                   mov       edi, dword ptr [ebp - 0x2c]
004b34dc 897dc8                   mov       dword ptr [ebp - 0x38], edi
004b34df 741d                     je        0x4b34fe
004b34e1 8b4dc4                   mov       ecx, dword ptr [ebp - 0x3c]
004b34e4 8bc2                     mov       eax, edx
004b34e6 2bc3                     sub       eax, ebx
004b34e8 2bcb                     sub       ecx, ebx
004b34ea c1f802                   sar       eax, 2
004b34ed c1f902                   sar       ecx, 2
004b34f0 3bc1                     cmp       eax, ecx
004b34f2 730a                     jae       0x4b34fe
004b34f4 893a                     mov       dword ptr [edx], edi
004b34f6 83c204                   add       edx, 4
004b34f9 8955c0                   mov       dword ptr [ebp - 0x40], edx
004b34fc eb0f                     jmp       0x4b350d
004b34fe 8d4dc8                   lea       ecx, [ebp - 0x38]
004b3501 51                       push      ecx
004b3502 6a01                     push      1
004b3504 52                       push      edx
004b3505 8d4db8                   lea       ecx, [ebp - 0x48]
004b3508 e8532af5ff               call      0x405f60
004b350d 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004b3510 81c1f0000000             add       ecx, 0xf0
004b3516 e845ebf4ff               call      0x402060
004b351b 8b5dbc                   mov       ebx, dword ptr [ebp - 0x44]
004b351e 85db                     test      ebx, ebx
004b3520 8bf8                     mov       edi, eax
004b3522 8b45c0                   mov       eax, dword ptr [ebp - 0x40]
004b3525 897dc8                   mov       dword ptr [ebp - 0x38], edi
004b3528 741d                     je        0x4b3547
004b352a 8b55c4                   mov       edx, dword ptr [ebp - 0x3c]
004b352d 8bc8                     mov       ecx, eax
004b352f 2bcb                     sub       ecx, ebx
004b3531 2bd3                     sub       edx, ebx
004b3533 c1f902                   sar       ecx, 2
004b3536 c1fa02                   sar       edx, 2
004b3539 3bca                     cmp       ecx, edx
004b353b 730a                     jae       0x4b3547
004b353d 8938                     mov       dword ptr [eax], edi
004b353f 83c004                   add       eax, 4
004b3542 8945c0                   mov       dword ptr [ebp - 0x40], eax
004b3545 eb0f                     jmp       0x4b3556
004b3547 8d55c8                   lea       edx, [ebp - 0x38]
004b354a 52                       push      edx
004b354b 6a01                     push      1
004b354d 50                       push      eax
004b354e 8d4db8                   lea       ecx, [ebp - 0x48]
004b3551 e80a2af5ff               call      0x405f60
004b3556 8a45f3                   mov       al, byte ptr [ebp - 0xd]
004b3559 8b4de8                   mov       ecx, dword ptr [ebp - 0x18]
004b355c f6d8                     neg       al
004b355e 1bc0                     sbb       eax, eax
004b3560 83e032                   and       eax, 0x32
004b3563 81c1f8000000             add       ecx, 0xf8
004b3569 8bd8                     mov       ebx, eax
004b356b e8f0eaf4ff               call      0x402060
004b3570 8b7dc0                   mov       edi, dword ptr [ebp - 0x40]
004b3573 03c3                     add       eax, ebx
004b3575 8b5dbc                   mov       ebx, dword ptr [ebp - 0x44]
004b3578 85db                     test      ebx, ebx
004b357a 8945c8                   mov       dword ptr [ebp - 0x38], eax
004b357d 741f                     je        0x4b359e
004b357f 8b55c4                   mov       edx, dword ptr [ebp - 0x3c]
004b3582 8bcf                     mov       ecx, edi
004b3584 2bcb                     sub       ecx, ebx
004b3586 2bd3                     sub       edx, ebx
004b3588 c1f902                   sar       ecx, 2
004b358b c1fa02                   sar       edx, 2
004b358e 3bca                     cmp       ecx, edx
004b3590 730c                     jae       0x4b359e
004b3592 8bcf                     mov       ecx, edi
004b3594 83c104                   add       ecx, 4
004b3597 8907                     mov       dword ptr [edi], eax
004b3599 894dc0                   mov       dword ptr [ebp - 0x40], ecx
004b359c eb0f                     jmp       0x4b35ad
004b359e 8d45c8                   lea       eax, [ebp - 0x38]
004b35a1 50                       push      eax
004b35a2 6a01                     push      1
004b35a4 57                       push      edi
004b35a5 8d4db8                   lea       ecx, [ebp - 0x48]
004b35a8 e8b329f5ff               call      0x405f60
004b35ad 8b16                     mov       edx, dword ptr [esi]
004b35af 6a00                     push      0
004b35b1 6a00                     push      0
004b35b3 6a03                     push      3
004b35b5 8d45b8                   lea       eax, [ebp - 0x48]
004b35b8 50                       push      eax
004b35b9 6a04                     push      4
004b35bb 8bce                     mov       ecx, esi
004b35bd ff928c020000             call      dword ptr [edx + 0x28c]
004b35c3 8b45bc                   mov       eax, dword ptr [ebp - 0x44]
004b35c6 85c0                     test      eax, eax
004b35c8 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b35cf 746f                     je        0x4b3640
004b35d1 50                       push      eax
004b35d2 e806ca7400               call      0xbfffdd
004b35d7 83c404                   add       esp, 4
004b35da eb64                     jmp       0x4b3640
004b35dc 83ff05                   cmp       edi, 5
004b35df 755f                     jne       0x4b3640
004b35e1 33ff                     xor       edi, edi
004b35e3 897dbc                   mov       dword ptr [ebp - 0x44], edi
004b35e6 897dc0                   mov       dword ptr [ebp - 0x40], edi
004b35e9 897dc4                   mov       dword ptr [ebp - 0x3c], edi
004b35ec 8d4dd0                   lea       ecx, [ebp - 0x30]
004b35ef 51                       push      ecx
004b35f0 8d4db8                   lea       ecx, [ebp - 0x48]
004b35f3 c745fc08000000           mov       dword ptr [ebp - 4], 8
004b35fa e8213bf5ff               call      0x407120
004b35ff 8b16                     mov       edx, dword ptr [esi]
004b3601 57                       push      edi
004b3602 57                       push      edi
004b3603 6a03                     push      3
004b3605 8d45b8                   lea       eax, [ebp - 0x48]
004b3608 50                       push      eax
004b3609 6a05                     push      5
004b360b 8bce                     mov       ecx, esi
004b360d ff928c020000             call      dword ptr [edx + 0x28c]
004b3613 8b45bc                   mov       eax, dword ptr [ebp - 0x44]
004b3616 3bc7                     cmp       eax, edi
004b3618 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b361f 741f                     je        0x4b3640
004b3621 50                       push      eax
004b3622 e8b6c97400               call      0xbfffdd
004b3627 83c404                   add       esp, 4
004b362a eb14                     jmp       0x4b3640
004b362c c745ecffffffff           mov       dword ptr [ebp - 0x14], 0xffffffff
004b3633 eb0b                     jmp       0x4b3640
004b3635 8b16                     mov       edx, dword ptr [esi]
004b3637 57                       push      edi
004b3638 8bce                     mov       ecx, esi
004b363a ff9284020000             call      dword ptr [edx + 0x284]
004b3640 33db                     xor       ebx, ebx
004b3642 8dbe94120000             lea       edi, [esi + 0x1294]
004b3648 8b06                     mov       eax, dword ptr [esi]
004b364a 53                       push      ebx
004b364b 8bce                     mov       ecx, esi
004b364d ff9010040000             call      dword ptr [eax + 0x410]
004b3653 84c0                     test      al, al
004b3655 7413                     je        0x4b366a
004b3657 8b4510                   mov       eax, dword ptr [ebp + 0x10]
004b365a 8b0f                     mov       ecx, dword ptr [edi]
004b365c 8b11                     mov       edx, dword ptr [ecx]
004b365e 50                       push      eax
004b365f 8b450c                   mov       eax, dword ptr [ebp + 0xc]
004b3662 50                       push      eax
004b3663 8b4508                   mov       eax, dword ptr [ebp + 8]
004b3666 50                       push      eax
004b3667 ff5248                   call      dword ptr [edx + 0x48]
004b366a 43                       inc       ebx
004b366b 83c704                   add       edi, 4
004b366e 83fb12                   cmp       ebx, 0x12
004b3671 7cd5                     jl        0x4b3648
004b3673 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004b3676 85c0                     test      eax, eax
004b3678 7e34                     jle       0x4b36ae
004b367a 3935d4f10401             cmp       dword ptr [0x104f1d4], esi
004b3680 752c                     jne       0x4b36ae
004b3682 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b3688 8b8914010000             mov       ecx, dword ptr [ecx + 0x114]
004b368e 50                       push      eax
004b368f 6a03                     push      3
004b3691 e8da870800               call      0x53be70
004b3696 8b0d48280001             mov       ecx, dword ptr [0x1002848]
004b369c 8b7dec                   mov       edi, dword ptr [ebp - 0x14]
004b369f e88c71f8ff               call      0x43a830
004b36a4 84c0                     test      al, al
004b36a6 7406                     je        0x4b36ae
004b36a8 013dfc4b0001             add       dword ptr [0x1004bfc], edi
004b36ae 8bce                     mov       ecx, esi
004b36b0 e8eb9dffff               call      0x4ad4a0
004b36b5 84c0                     test      al, al
004b36b7 0f8493020000             je        0x4b3950
004b36bd 8b9654190000             mov       edx, dword ptr [esi + 0x1954]
004b36c3 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b36c9 8b8658190000             mov       eax, dword ptr [esi + 0x1958]
004b36cf 8dbe54190000             lea       edi, [esi + 0x1954]
004b36d5 33d3                     xor       edx, ebx
004b36d7 2bd7                     sub       edx, edi
004b36d9 3bd0                     cmp       edx, eax
004b36db 740e                     je        0x4b36eb
004b36dd 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b36e3 6a3f                     push      0x3f
004b36e5 57                       push      edi
004b36e6 e8c5396600               call      0xb170b0
004b36eb 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b36f1 8b4a44                   mov       ecx, dword ptr [edx + 0x44]
004b36f4 8b4704                   mov       eax, dword ptr [edi + 4]
004b36f7 c1e002                   shl       eax, 2
004b36fa 8d1c01                   lea       ebx, [ecx + eax]
004b36fd 331c01                   xor       ebx, dword ptr [ecx + eax]
004b3700 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b3706 8b4a48                   mov       ecx, dword ptr [edx + 0x48]
004b3709 8d1401                   lea       edx, [ecx + eax]
004b370c 331401                   xor       edx, dword ptr [ecx + eax]
004b370f 3315dc012101             xor       edx, dword ptr [0x12101dc]
004b3715 3bda                     cmp       ebx, edx
004b3717 740e                     je        0x4b3727
004b3719 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b371f 6a40                     push      0x40
004b3721 57                       push      edi
004b3722 e889396600               call      0xb170b0
004b3727 85db                     test      ebx, ebx
004b3729 0f8521020000             jne       0x4b3950
004b372f 8b8684190000             mov       eax, dword ptr [esi + 0x1984]
004b3735 85c0                     test      eax, eax
004b3737 0f85ab000000             jne       0x4b37e8
004b373d 68e8010000               push      0x1e8
004b3742 e80905f5ff               call      0x403c50
004b3747 83c404                   add       esp, 4
004b374a 89450c                   mov       dword ptr [ebp + 0xc], eax
004b374d 85c0                     test      eax, eax
004b374f c745fc09000000           mov       dword ptr [ebp - 4], 9
004b3756 7412                     je        0x4b376a
004b3758 6a01                     push      1
004b375a 68600ccd00               push      0xcd0c60
004b375f 8bc8                     mov       ecx, eax
004b3761 e86afffdff               call      0x4936d0
004b3766 8bd8                     mov       ebx, eax
004b3768 eb02                     jmp       0x4b376c
004b376a 33db                     xor       ebx, ebx
004b376c 899e84190000             mov       dword ptr [esi + 0x1984], ebx
004b3772 8b8398000000             mov       eax, dword ptr [ebx + 0x98]
004b3778 85c0                     test      eax, eax
004b377a c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b3781 741b                     je        0x4b379e
004b3783 8b8b9c000000             mov       ecx, dword ptr [ebx + 0x9c]
004b3789 2bc8                     sub       ecx, eax
004b378b b843082184               mov       eax, 0x84210843
004b3790 f7e9                     imul      ecx
004b3792 03d1                     add       edx, ecx
004b3794 c1fa06                   sar       edx, 6
004b3797 8bc2                     mov       eax, edx
004b3799 c1e81f                   shr       eax, 0x1f
004b379c 03c2                     add       eax, edx
004b379e 48                       dec       eax
004b379f 50                       push      eax
004b37a0 8bcb                     mov       ecx, ebx
004b37a2 e8c9405700               call      0xa27870
004b37a7 68b4010000               push      0x1b4
004b37ac e89f04f5ff               call      0x403c50
004b37b1 83c404                   add       esp, 4
004b37b4 89450c                   mov       dword ptr [ebp + 0xc], eax
004b37b7 85c0                     test      eax, eax
004b37b9 c745fc0a000000           mov       dword ptr [ebp - 4], 0xa
004b37c0 740f                     je        0x4b37d1
004b37c2 56                       push      esi
004b37c3 68e80bcd00               push      0xcd0be8
004b37c8 8bc8                     mov       ecx, eax
004b37ca e851fbf9ff               call      0x453320
004b37cf eb02                     jmp       0x4b37d3
004b37d1 33c0                     xor       eax, eax
004b37d3 898688190000             mov       dword ptr [esi + 0x1988], eax
004b37d9 8b10                     mov       edx, dword ptr [eax]
004b37db 56                       push      esi
004b37dc 8bc8                     mov       ecx, eax
004b37de c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b37e5 ff5270                   call      dword ptr [edx + 0x70]
004b37e8 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b37ed 8b4844                   mov       ecx, dword ptr [eax + 0x44]
004b37f0 8b4704                   mov       eax, dword ptr [edi + 4]
004b37f3 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b37f9 c1e002                   shl       eax, 2
004b37fc 8d1401                   lea       edx, [ecx + eax]
004b37ff 33d3                     xor       edx, ebx
004b3801 83f201                   xor       edx, 1
004b3804 891408                   mov       dword ptr [eax + ecx], edx
004b3807 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b380c 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004b380f 8b4704                   mov       eax, dword ptr [edi + 4]
004b3812 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004b3818 c1e002                   shl       eax, 2
004b381b 8d1408                   lea       edx, [eax + ecx]
004b381e 33d7                     xor       edx, edi
004b3820 83f201                   xor       edx, 1
004b3823 891408                   mov       dword ptr [eax + ecx], edx
004b3826 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b382b 8b5044                   mov       edx, dword ptr [eax + 0x44]
004b382e 8b8660190000             mov       eax, dword ptr [esi + 0x1960]
004b3834 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b383a c1e002                   shl       eax, 2
004b383d 8d3c10                   lea       edi, [eax + edx]
004b3840 8d8e44190000             lea       ecx, [esi + 0x1944]
004b3846 33fb                     xor       edi, ebx
004b3848 893c10                   mov       dword ptr [eax + edx], edi
004b384b 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b3851 8b5248                   mov       edx, dword ptr [edx + 0x48]
004b3854 8b411c                   mov       eax, dword ptr [ecx + 0x1c]
004b3857 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b385d c1e002                   shl       eax, 2
004b3860 8d3c10                   lea       edi, [eax + edx]
004b3863 33fb                     xor       edi, ebx
004b3865 893c10                   mov       dword ptr [eax + edx], edi
004b3868 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b386d 8b5044                   mov       edx, dword ptr [eax + 0x44]
004b3870 8b4124                   mov       eax, dword ptr [ecx + 0x24]
004b3873 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b3879 c1e002                   shl       eax, 2
004b387c 8d3c10                   lea       edi, [eax + edx]
004b387f 33fb                     xor       edi, ebx
004b3881 893c10                   mov       dword ptr [eax + edx], edi
004b3884 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b388a 8b4124                   mov       eax, dword ptr [ecx + 0x24]
004b388d 8b5248                   mov       edx, dword ptr [edx + 0x48]
004b3890 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b3896 c1e002                   shl       eax, 2
004b3899 8d3c10                   lea       edi, [eax + edx]
004b389c 6a00                     push      0
004b389e 33fb                     xor       edi, ebx
004b38a0 6858020000               push      0x258
004b38a5 893c10                   mov       dword ptr [eax + edx], edi
004b38a8 e8b3366500               call      0xb06f60
004b38ad 8b8e84190000             mov       ecx, dword ptr [esi + 0x1984]
004b38b3 c6863d19000005           mov       byte ptr [esi + 0x193d], 5
004b38ba e8a13a5700               call      0xa27360
004b38bf 8b8e88190000             mov       ecx, dword ptr [esi + 0x1988]
004b38c5 8b01                     mov       eax, dword ptr [ecx]
004b38c7 6a00                     push      0
004b38c9 ff500c                   call      dword ptr [eax + 0xc]
004b38cc 8b8e88190000             mov       ecx, dword ptr [esi + 0x1988]
004b38d2 8b39                     mov       edi, dword ptr [ecx]
004b38d4 8b16                     mov       edx, dword ptr [esi]
004b38d6 8bce                     mov       ecx, esi
004b38d8 ff92e4000000             call      dword ptr [edx + 0xe4]
004b38de 99                       cdq       
004b38df 2bc2                     sub       eax, edx
004b38e1 8bd8                     mov       ebx, eax
004b38e3 8b06                     mov       eax, dword ptr [esi]
004b38e5 8bce                     mov       ecx, esi
004b38e7 d1fb                     sar       ebx, 1
004b38e9 ff909c000000             call      dword ptr [eax + 0x9c]
004b38ef 8b16                     mov       edx, dword ptr [esi]
004b38f1 03d8                     add       ebx, eax
004b38f3 53                       push      ebx
004b38f4 8bce                     mov       ecx, esi
004b38f6 ff9298000000             call      dword ptr [edx + 0x98]
004b38fc 50                       push      eax
004b38fd 8b06                     mov       eax, dword ptr [esi]
004b38ff 8bce                     mov       ecx, esi
004b3901 ff9094000000             call      dword ptr [eax + 0x94]
004b3907 8b8e88190000             mov       ecx, dword ptr [esi + 0x1988]
004b390d 50                       push      eax
004b390e ff5728                   call      dword ptr [edi + 0x28]
004b3911 8b8e88190000             mov       ecx, dword ptr [esi + 0x1988]
004b3917 8b11                     mov       edx, dword ptr [ecx]
004b3919 8d45a8                   lea       eax, [ebp - 0x58]
004b391c 50                       push      eax
004b391d ff525c                   call      dword ptr [edx + 0x5c]
004b3920 8b16                     mov       edx, dword ptr [esi]
004b3922 6a00                     push      0
004b3924 8d4da8                   lea       ecx, [ebp - 0x58]
004b3927 51                       push      ecx
004b3928 6a00                     push      0
004b392a 6a02                     push      2
004b392c 56                       push      esi
004b392d 8bce                     mov       ecx, esi
004b392f c745fc0b000000           mov       dword ptr [ebp - 4], 0xb
004b3936 ff525c                   call      dword ptr [edx + 0x5c]
004b3939 8bc8                     mov       ecx, eax
004b393b e820a70500               call      0x50e060
004b3940 8b45ac                   mov       eax, dword ptr [ebp - 0x54]
004b3943 85c0                     test      eax, eax
004b3945 7409                     je        0x4b3950
004b3947 50                       push      eax
004b3948 e890c67400               call      0xbfffdd
004b394d 83c404                   add       esp, 4
004b3950 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b3953 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004b3956 5f                       pop       edi
004b3957 5e                       pop       esi
004b3958 5b                       pop       ebx
004b3959 64890d00000000           mov       dword ptr fs:[0], ecx
004b3960 8be5                     mov       esp, ebp
004b3962 5d                       pop       ebp
004b3963 c20c00                   ret       0xc
004b3966 cc                       int3      
004b3967 cc                       int3      
004b3968 cc                       int3      
004b3969 cc                       int3      
004b396a cc                       int3      
004b396b cc                       int3      
004b396c cc                       int3      
004b396d cc                       int3      
004b396e cc                       int3      
004b396f cc                       int3      
004b3970 55                       push      ebp
004b3971 8bec                     mov       ebp, esp
004b3973 6aff                     push      -1
004b3975 68a975c500               push      0xc575a9
004b397a 64a100000000             mov       eax, dword ptr fs:[0]
004b3980 50                       push      eax
004b3981 64892500000000           mov       dword ptr fs:[0], esp
004b3988 51                       push      ecx
004b3989 56                       push      esi
004b398a 8bf1                     mov       esi, ecx
004b398c 8b06                     mov       eax, dword ptr [esi]
004b398e ff905c050000             call      dword ptr [eax + 0x55c]
004b3994 84c0                     test      al, al
004b3996 0f847e020000             je        0x4b3c1a
004b399c 8b16                     mov       edx, dword ptr [esi]
004b399e 53                       push      ebx
004b399f 57                       push      edi
004b39a0 8bce                     mov       ecx, esi
004b39a2 ff9268050000             call      dword ptr [edx + 0x568]
004b39a8 83f832                   cmp       eax, 0x32
004b39ab 8945f0                   mov       dword ptr [ebp - 0x10], eax
004b39ae 0f8cf5000000             jl        0x4b3aa9
004b39b4 68e8010000               push      0x1e8
004b39b9 e89202f5ff               call      0x403c50
004b39be 83c404                   add       esp, 4
004b39c1 8945f0                   mov       dword ptr [ebp - 0x10], eax
004b39c4 33db                     xor       ebx, ebx
004b39c6 3bc3                     cmp       eax, ebx
004b39c8 895dfc                   mov       dword ptr [ebp - 4], ebx
004b39cb 7410                     je        0x4b39dd
004b39cd 6a01                     push      1
004b39cf 68780dcd00               push      0xcd0d78
004b39d4 8bc8                     mov       ecx, eax
004b39d6 e8f5fcfdff               call      0x4936d0
004b39db 8bd8                     mov       ebx, eax
004b39dd 68fc010000               push      0x1fc
004b39e2 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b39e9 e86202f5ff               call      0x403c50
004b39ee 8bf8                     mov       edi, eax
004b39f0 83c404                   add       esp, 4
004b39f3 897df0                   mov       dword ptr [ebp - 0x10], edi
004b39f6 85ff                     test      edi, edi
004b39f8 c745fc01000000           mov       dword ptr [ebp - 4], 1
004b39ff 7414                     je        0x4b3a15
004b3a01 6a00                     push      0
004b3a03 6a01                     push      1
004b3a05 53                       push      ebx
004b3a06 8bcf                     mov       ecx, edi
004b3a08 e8a30bfeff               call      0x4945b0
004b3a0d c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004b3a13 eb02                     jmp       0x4b3a17
004b3a15 33ff                     xor       edi, edi
004b3a17 8b07                     mov       eax, dword ptr [edi]
004b3a19 6a02                     push      2
004b3a1b 8bcf                     mov       ecx, edi
004b3a1d 897df0                   mov       dword ptr [ebp - 0x10], edi
004b3a20 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b3a27 ff5054                   call      dword ptr [eax + 0x54]
004b3a2a 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b3a30 6a00                     push      0
004b3a32 6a00                     push      0
004b3a34 56                       push      esi
004b3a35 57                       push      edi
004b3a36 6a00                     push      0
004b3a38 6a02                     push      2
004b3a3a 56                       push      esi
004b3a3b e830a30500               call      0x50dd70
004b3a40 8b16                     mov       edx, dword ptr [esi]
004b3a42 8b1f                     mov       ebx, dword ptr [edi]
004b3a44 8bce                     mov       ecx, esi
004b3a46 ff92e4000000             call      dword ptr [edx + 0xe4]
004b3a4c 8bf8                     mov       edi, eax
004b3a4e 8b06                     mov       eax, dword ptr [esi]
004b3a50 8bce                     mov       ecx, esi
004b3a52 ff909c000000             call      dword ptr [eax + 0x9c]
004b3a58 8b16                     mov       edx, dword ptr [esi]
004b3a5a 8d4c070a                 lea       ecx, [edi + eax + 0xa]
004b3a5e 51                       push      ecx
004b3a5f 8bce                     mov       ecx, esi
004b3a61 ff9298000000             call      dword ptr [edx + 0x98]
004b3a67 40                       inc       eax
004b3a68 50                       push      eax
004b3a69 8b06                     mov       eax, dword ptr [esi]
004b3a6b 8bce                     mov       ecx, esi
004b3a6d ff9094000000             call      dword ptr [eax + 0x94]
004b3a73 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
004b3a76 50                       push      eax
004b3a77 8bcf                     mov       ecx, edi
004b3a79 ff9388000000             call      dword ptr [ebx + 0x88]
004b3a7f 8b17                     mov       edx, dword ptr [edi]
004b3a81 56                       push      esi
004b3a82 8bcf                     mov       ecx, edi
004b3a84 ff5248                   call      dword ptr [edx + 0x48]
004b3a87 8bc8                     mov       ecx, eax
004b3a89 e8f2d30500               call      0x510e80
004b3a8e 8b06                     mov       eax, dword ptr [esi]
004b3a90 8bce                     mov       ecx, esi
004b3a92 ff9058050000             call      dword ptr [eax + 0x558]
004b3a98 5f                       pop       edi
004b3a99 5b                       pop       ebx
004b3a9a 5e                       pop       esi
004b3a9b 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b3a9e 64890d00000000           mov       dword ptr fs:[0], ecx
004b3aa5 8be5                     mov       esp, ebp
004b3aa7 5d                       pop       ebp
004b3aa8 c3                       ret       
004b3aa9 8b16                     mov       edx, dword ptr [esi]
004b3aab 8bce                     mov       ecx, esi
004b3aad ff525c                   call      dword ptr [edx + 0x5c]
004b3ab0 8bf8                     mov       edi, eax
004b3ab2 8b06                     mov       eax, dword ptr [esi]
004b3ab4 8bce                     mov       ecx, esi
004b3ab6 ff5028                   call      dword ptr [eax + 0x28]
004b3ab9 8b480c                   mov       ecx, dword ptr [eax + 0xc]
004b3abc 8b16                     mov       edx, dword ptr [esi]
004b3abe 51                       push      ecx
004b3abf 8bce                     mov       ecx, esi
004b3ac1 ff9294000000             call      dword ptr [edx + 0x94]
004b3ac7 50                       push      eax
004b3ac8 8bcf                     mov       ecx, edi
004b3aca e8316f0500               call      0x50aa00
004b3acf 8bf8                     mov       edi, eax
004b3ad1 8b06                     mov       eax, dword ptr [esi]
004b3ad3 8bce                     mov       ecx, esi
004b3ad5 83ef19                   sub       edi, 0x19
004b3ad8 ff505c                   call      dword ptr [eax + 0x5c]
004b3adb 8b16                     mov       edx, dword ptr [esi]
004b3add 680000803f               push      0x3f800000
004b3ae2 8bce                     mov       ecx, esi
004b3ae4 8bd8                     mov       ebx, eax
004b3ae6 ff5228                   call      dword ptr [edx + 0x28]
004b3ae9 8b400c                   mov       eax, dword ptr [eax + 0xc]
004b3aec 8b16                     mov       edx, dword ptr [esi]
004b3aee 50                       push      eax
004b3aef 8bce                     mov       ecx, esi
004b3af1 ff929c000000             call      dword ptr [edx + 0x9c]
004b3af7 50                       push      eax
004b3af8 8b06                     mov       eax, dword ptr [esi]
004b3afa 8bce                     mov       ecx, esi
004b3afc ff9098000000             call      dword ptr [eax + 0x98]
004b3b02 50                       push      eax
004b3b03 8bcb                     mov       ecx, ebx
004b3b05 e8366f0500               call      0x50aa40
004b3b0a 8b16                     mov       edx, dword ptr [esi]
004b3b0c 8bce                     mov       ecx, esi
004b3b0e 8bd8                     mov       ebx, eax
004b3b10 ff92e4000000             call      dword ptr [edx + 0xe4]
004b3b16 6a00                     push      0
004b3b18 6a00                     push      0
004b3b1a 6a00                     push      0
004b3b1c 6aff                     push      -1
004b3b1e 6a00                     push      0
004b3b20 680000803f               push      0x3f800000
004b3b25 680000803f               push      0x3f800000
004b3b2a b9f6ffffff               mov       ecx, 0xfffffff6
004b3b2f 2bc8                     sub       ecx, eax
004b3b31 6a00                     push      0
004b3b33 03d9                     add       ebx, ecx
004b3b35 8b0dc8e4ff00             mov       ecx, dword ptr [0xffe4c8]
004b3b3b 6a28                     push      0x28
004b3b3d e89e366400               call      0xaf71e0
004b3b42 8bc8                     mov       ecx, eax
004b3b44 e887e86300               call      0xaf23d0
004b3b49 50                       push      eax
004b3b4a 8d53ff                   lea       edx, [ebx - 1]
004b3b4d 52                       push      edx
004b3b4e 8d47ff                   lea       eax, [edi - 1]
004b3b51 50                       push      eax
004b3b52 e879480800               call      0x5383d0
004b3b57 8b0dc8e4ff00             mov       ecx, dword ptr [0xffe4c8]
004b3b5d 83c428                   add       esp, 0x28
004b3b60 6a00                     push      0
004b3b62 6a00                     push      0
004b3b64 6a00                     push      0
004b3b66 6aff                     push      -1
004b3b68 6a00                     push      0
004b3b6a 680000803f               push      0x3f800000
004b3b6f 680000803f               push      0x3f800000
004b3b74 6a02                     push      2
004b3b76 6a28                     push      0x28
004b3b78 e863366400               call      0xaf71e0
004b3b7d 8bc8                     mov       ecx, eax
004b3b7f e84ce86300               call      0xaf23d0
004b3b84 50                       push      eax
004b3b85 8d4bfd                   lea       ecx, [ebx - 3]
004b3b88 51                       push      ecx
004b3b89 8d57fc                   lea       edx, [edi - 4]
004b3b8c 52                       push      edx
004b3b8d e83e480800               call      0x5383d0
004b3b92 8b45f0                   mov       eax, dword ptr [ebp - 0x10]
004b3b95 68e0010000               push      0x1e0
004b3b9a 8d3407                   lea       esi, [edi + eax]
004b3b9d 56                       push      esi
004b3b9e 6a00                     push      0
004b3ba0 57                       push      edi
004b3ba1 e8ea3c0800               call      0x537890
004b3ba6 8b0dc8e4ff00             mov       ecx, dword ptr [0xffe4c8]
004b3bac 83c438                   add       esp, 0x38
004b3baf 6a00                     push      0
004b3bb1 6a00                     push      0
004b3bb3 6a00                     push      0
004b3bb5 6aff                     push      -1
004b3bb7 6a00                     push      0
004b3bb9 680000803f               push      0x3f800000
004b3bbe 680000803f               push      0x3f800000
004b3bc3 6a01                     push      1
004b3bc5 6a28                     push      0x28
004b3bc7 e814366400               call      0xaf71e0
004b3bcc 8bc8                     mov       ecx, eax
004b3bce e8fde76300               call      0xaf23d0
004b3bd3 50                       push      eax
004b3bd4 53                       push      ebx
004b3bd5 57                       push      edi
004b3bd6 e8f5470800               call      0x5383d0
004b3bdb 83c428                   add       esp, 0x28
004b3bde e82dd9f4ff               call      0x401510
004b3be3 8b0dc8e4ff00             mov       ecx, dword ptr [0xffe4c8]
004b3be9 6a00                     push      0
004b3beb 6a00                     push      0
004b3bed 6a00                     push      0
004b3bef 6aff                     push      -1
004b3bf1 6a00                     push      0
004b3bf3 680000803f               push      0x3f800000
004b3bf8 680000803f               push      0x3f800000
004b3bfd 6a03                     push      3
004b3bff 6a28                     push      0x28
004b3c01 e8da356400               call      0xaf71e0
004b3c06 8bc8                     mov       ecx, eax
004b3c08 e8c3e76300               call      0xaf23d0
004b3c0d 50                       push      eax
004b3c0e 53                       push      ebx
004b3c0f 56                       push      esi
004b3c10 e8bb470800               call      0x5383d0
004b3c15 83c428                   add       esp, 0x28
004b3c18 5f                       pop       edi
004b3c19 5b                       pop       ebx
004b3c1a 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b3c1d 5e                       pop       esi
004b3c1e 64890d00000000           mov       dword ptr fs:[0], ecx
004b3c25 8be5                     mov       esp, ebp
004b3c27 5d                       pop       ebp
004b3c28 c3                       ret       
004b3c29 cc                       int3      
004b3c2a cc                       int3      
004b3c2b cc                       int3      
004b3c2c cc                       int3      
004b3c2d cc                       int3      
004b3c2e cc                       int3      
004b3c2f cc                       int3      
004b3c30 55                       push      ebp
004b3c31 8bec                     mov       ebp, esp
004b3c33 6aff                     push      -1
004b3c35 68df75c500               push      0xc575df
004b3c3a 64a100000000             mov       eax, dword ptr fs:[0]
004b3c40 50                       push      eax
004b3c41 64892500000000           mov       dword ptr fs:[0], esp
004b3c48 51                       push      ecx
004b3c49 53                       push      ebx
004b3c4a 56                       push      esi
004b3c4b 8bf1                     mov       esi, ecx
004b3c4d 8b06                     mov       eax, dword ptr [esi]
004b3c4f 57                       push      edi
004b3c50 ff90f4040000             call      dword ptr [eax + 0x4f4]
004b3c56 0fb65508                 movzx     edx, byte ptr [ebp + 8]
004b3c5a 8845f3                   mov       byte ptr [ebp - 0xd], al
004b3c5d a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3c62 8b7844                   mov       edi, dword ptr [eax + 0x44]
004b3c65 8b8684180000             mov       eax, dword ptr [esi + 0x1884]
004b3c6b 8d8e80180000             lea       ecx, [esi + 0x1880]
004b3c71 c1e002                   shl       eax, 2
004b3c74 8d1c38                   lea       ebx, [eax + edi]
004b3c77 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b3c7d 33da                     xor       ebx, edx
004b3c7f 891c38                   mov       dword ptr [eax + edi], ebx
004b3c82 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3c87 8b7848                   mov       edi, dword ptr [eax + 0x48]
004b3c8a 8b4104                   mov       eax, dword ptr [ecx + 4]
004b3c8d c1e002                   shl       eax, 2
004b3c90 8d1c38                   lea       ebx, [eax + edi]
004b3c93 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b3c99 33da                     xor       ebx, edx
004b3c9b 891c38                   mov       dword ptr [eax + edi], ebx
004b3c9e e8bde3f4ff               call      0x402060
004b3ca3 85c0                     test      eax, eax
004b3ca5 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004b3cab 0f842d010000             je        0x4b3dde
004b3cb1 33db                     xor       ebx, ebx
004b3cb3 3bc3                     cmp       eax, ebx
004b3cb5 0f84c1000000             je        0x4b3d7c
004b3cbb 68e8010000               push      0x1e8
004b3cc0 e88bfff4ff               call      0x403c50
004b3cc5 83c404                   add       esp, 4
004b3cc8 894508                   mov       dword ptr [ebp + 8], eax
004b3ccb 3bc3                     cmp       eax, ebx
004b3ccd 895dfc                   mov       dword ptr [ebp - 4], ebx
004b3cd0 7410                     je        0x4b3ce2
004b3cd2 6a01                     push      1
004b3cd4 68780ecd00               push      0xcd0e78
004b3cd9 8bc8                     mov       ecx, eax
004b3cdb e8f0f9fdff               call      0x4936d0
004b3ce0 8bd8                     mov       ebx, eax
004b3ce2 68fc010000               push      0x1fc
004b3ce7 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b3cee e85dfff4ff               call      0x403c50
004b3cf3 8bf8                     mov       edi, eax
004b3cf5 83c404                   add       esp, 4
004b3cf8 897d08                   mov       dword ptr [ebp + 8], edi
004b3cfb 85ff                     test      edi, edi
004b3cfd c745fc01000000           mov       dword ptr [ebp - 4], 1
004b3d04 7414                     je        0x4b3d1a
004b3d06 6a00                     push      0
004b3d08 6a01                     push      1
004b3d0a 53                       push      ebx
004b3d0b 8bcf                     mov       ecx, edi
004b3d0d e89e08feff               call      0x4945b0
004b3d12 c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004b3d18 eb02                     jmp       0x4b3d1c
004b3d1a 33ff                     xor       edi, edi
004b3d1c 8b17                     mov       edx, dword ptr [edi]
004b3d1e 6a02                     push      2
004b3d20 8bcf                     mov       ecx, edi
004b3d22 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b3d29 ff5254                   call      dword ptr [edx + 0x54]
004b3d2c 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b3d32 6a00                     push      0
004b3d34 6a00                     push      0
004b3d36 56                       push      esi
004b3d37 57                       push      edi
004b3d38 6a00                     push      0
004b3d3a 6a02                     push      2
004b3d3c 56                       push      esi
004b3d3d e82ea00500               call      0x50dd70
004b3d42 8b06                     mov       eax, dword ptr [esi]
004b3d44 8b1f                     mov       ebx, dword ptr [edi]
004b3d46 8bce                     mov       ecx, esi
004b3d48 ff909c000000             call      dword ptr [eax + 0x9c]
004b3d4e 8b16                     mov       edx, dword ptr [esi]
004b3d50 50                       push      eax
004b3d51 8bce                     mov       ecx, esi
004b3d53 ff9298000000             call      dword ptr [edx + 0x98]
004b3d59 50                       push      eax
004b3d5a 8b06                     mov       eax, dword ptr [esi]
004b3d5c 8bce                     mov       ecx, esi
004b3d5e ff9094000000             call      dword ptr [eax + 0x94]
004b3d64 50                       push      eax
004b3d65 8bcf                     mov       ecx, edi
004b3d67 ff9388000000             call      dword ptr [ebx + 0x88]
004b3d6d 8b17                     mov       edx, dword ptr [edi]
004b3d6f 56                       push      esi
004b3d70 8bcf                     mov       ecx, edi
004b3d72 ff5248                   call      dword ptr [edx + 0x48]
004b3d75 8bc8                     mov       ecx, eax
004b3d77 e804d10500               call      0x510e80
004b3d7c 807df301                 cmp       byte ptr [ebp - 0xd], 1
004b3d80 7514                     jne       0x4b3d96
004b3d82 8d4e60                   lea       ecx, [esi + 0x60]
004b3d85 e876316500               call      0xb06f00
004b3d8a 03450c                   add       eax, dword ptr [ebp + 0xc]
004b3d8d 894508                   mov       dword ptr [ebp + 8], eax
004b3d90 8d4508                   lea       eax, [ebp + 8]
004b3d93 50                       push      eax
004b3d94 eb2d                     jmp       0x4b3dc3
004b3d96 8d7e60                   lea       edi, [esi + 0x60]
004b3d99 8bcf                     mov       ecx, edi
004b3d9b e860316500               call      0xb06f00
004b3da0 8d4d08                   lea       ecx, [ebp + 8]
004b3da3 51                       push      ecx
004b3da4 8d8e88180000             lea       ecx, [esi + 0x1888]
004b3daa 894508                   mov       dword ptr [ebp + 8], eax
004b3dad e8ae07f5ff               call      0x404560
004b3db2 8bcf                     mov       ecx, edi
004b3db4 e847316500               call      0xb06f00
004b3db9 03450c                   add       eax, dword ptr [ebp + 0xc]
004b3dbc 8d5508                   lea       edx, [ebp + 8]
004b3dbf 894508                   mov       dword ptr [ebp + 8], eax
004b3dc2 52                       push      edx
004b3dc3 8d8e90180000             lea       ecx, [esi + 0x1890]
004b3dc9 e89207f5ff               call      0x404560
004b3dce 6a00                     push      0
004b3dd0 6a00                     push      0
004b3dd2 6aff                     push      -1
004b3dd4 68480ecd00               push      0xcd0e48
004b3dd9 e95f010000               jmp       0x4b3f3d
004b3dde 85c0                     test      eax, eax
004b3de0 0f84c9000000             je        0x4b3eaf
004b3de6 68e8010000               push      0x1e8
004b3deb e860fef4ff               call      0x403c50
004b3df0 83c404                   add       esp, 4
004b3df3 894508                   mov       dword ptr [ebp + 8], eax
004b3df6 85c0                     test      eax, eax
004b3df8 c745fc02000000           mov       dword ptr [ebp - 4], 2
004b3dff 7412                     je        0x4b3e13
004b3e01 6a01                     push      1
004b3e03 68e80dcd00               push      0xcd0de8
004b3e08 8bc8                     mov       ecx, eax
004b3e0a e8c1f8fdff               call      0x4936d0
004b3e0f 8bd8                     mov       ebx, eax
004b3e11 eb02                     jmp       0x4b3e15
004b3e13 33db                     xor       ebx, ebx
004b3e15 68fc010000               push      0x1fc
004b3e1a c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b3e21 e82afef4ff               call      0x403c50
004b3e26 8bf8                     mov       edi, eax
004b3e28 83c404                   add       esp, 4
004b3e2b 897d08                   mov       dword ptr [ebp + 8], edi
004b3e2e 85ff                     test      edi, edi
004b3e30 c745fc03000000           mov       dword ptr [ebp - 4], 3
004b3e37 7414                     je        0x4b3e4d
004b3e39 6a00                     push      0
004b3e3b 6a01                     push      1
004b3e3d 53                       push      ebx
004b3e3e 8bcf                     mov       ecx, edi
004b3e40 e86b07feff               call      0x4945b0
004b3e45 c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004b3e4b eb02                     jmp       0x4b3e4f
004b3e4d 33ff                     xor       edi, edi
004b3e4f 8b17                     mov       edx, dword ptr [edi]
004b3e51 6a02                     push      2
004b3e53 8bcf                     mov       ecx, edi
004b3e55 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b3e5c ff5254                   call      dword ptr [edx + 0x54]
004b3e5f 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b3e65 6a00                     push      0
004b3e67 6a00                     push      0
004b3e69 56                       push      esi
004b3e6a 57                       push      edi
004b3e6b 6a00                     push      0
004b3e6d 6a02                     push      2
004b3e6f 56                       push      esi
004b3e70 e8fb9e0500               call      0x50dd70
004b3e75 8b06                     mov       eax, dword ptr [esi]
004b3e77 8b1f                     mov       ebx, dword ptr [edi]
004b3e79 8bce                     mov       ecx, esi
004b3e7b ff909c000000             call      dword ptr [eax + 0x9c]
004b3e81 8b16                     mov       edx, dword ptr [esi]
004b3e83 50                       push      eax
004b3e84 8bce                     mov       ecx, esi
004b3e86 ff9298000000             call      dword ptr [edx + 0x98]
004b3e8c 50                       push      eax
004b3e8d 8b06                     mov       eax, dword ptr [esi]
004b3e8f 8bce                     mov       ecx, esi
004b3e91 ff9094000000             call      dword ptr [eax + 0x94]
004b3e97 50                       push      eax
004b3e98 8bcf                     mov       ecx, edi
004b3e9a ff9388000000             call      dword ptr [ebx + 0x88]
004b3ea0 8b17                     mov       edx, dword ptr [edi]
004b3ea2 56                       push      esi
004b3ea3 8bcf                     mov       ecx, edi
004b3ea5 ff5248                   call      dword ptr [edx + 0x48]
004b3ea8 8bc8                     mov       ecx, eax
004b3eaa e8d1cf0500               call      0x510e80
004b3eaf 8d4e60                   lea       ecx, [esi + 0x60]
004b3eb2 e849306500               call      0xb06f00
004b3eb7 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b3ebd 8b5244                   mov       edx, dword ptr [edx + 0x44]
004b3ec0 8b8e8c180000             mov       ecx, dword ptr [esi + 0x188c]
004b3ec6 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b3ecc 8d0c8a                   lea       ecx, [edx + ecx*4]
004b3ecf 8bd1                     mov       edx, ecx
004b3ed1 33d3                     xor       edx, ebx
004b3ed3 33d0                     xor       edx, eax
004b3ed5 8911                     mov       dword ptr [ecx], edx
004b3ed7 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004b3edd 8b5248                   mov       edx, dword ptr [edx + 0x48]
004b3ee0 8b8e8c180000             mov       ecx, dword ptr [esi + 0x188c]
004b3ee6 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004b3eec 8d0c8a                   lea       ecx, [edx + ecx*4]
004b3eef 8bd1                     mov       edx, ecx
004b3ef1 33d3                     xor       edx, ebx
004b3ef3 33d0                     xor       edx, eax
004b3ef5 8911                     mov       dword ptr [ecx], edx
004b3ef7 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004b3efd 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004b3f00 8b8694180000             mov       eax, dword ptr [esi + 0x1894]
004b3f06 8d0482                   lea       eax, [edx + eax*4]
004b3f09 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004b3f0f 8bc8                     mov       ecx, eax
004b3f11 33ca                     xor       ecx, edx
004b3f13 8908                     mov       dword ptr [eax], ecx
004b3f15 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3f1a 8b9694180000             mov       edx, dword ptr [esi + 0x1894]
004b3f20 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004b3f23 8d0491                   lea       eax, [ecx + edx*4]
004b3f26 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004b3f2c 6a00                     push      0
004b3f2e 6a00                     push      0
004b3f30 8bd0                     mov       edx, eax
004b3f32 33d1                     xor       edx, ecx
004b3f34 6aff                     push      -1
004b3f36 8910                     mov       dword ptr [eax], edx
004b3f38 68c40dcd00               push      0xcd0dc4
004b3f3d 8b06                     mov       eax, dword ptr [esi]
004b3f3f 8bce                     mov       ecx, esi
004b3f41 ff900c010000             call      dword ptr [eax + 0x10c]
004b3f47 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b3f4a 5f                       pop       edi
004b3f4b 5e                       pop       esi
004b3f4c 5b                       pop       ebx
004b3f4d 64890d00000000           mov       dword ptr fs:[0], ecx
004b3f54 8be5                     mov       esp, ebp
004b3f56 5d                       pop       ebp
004b3f57 c20800                   ret       8
004b3f5a cc                       int3      
004b3f5b cc                       int3      
004b3f5c cc                       int3      
004b3f5d cc                       int3      
004b3f5e cc                       int3      
004b3f5f cc                       int3      
004b3f60 55                       push      ebp
004b3f61 8bec                     mov       ebp, esp
004b3f63 64a100000000             mov       eax, dword ptr fs:[0]
004b3f69 6aff                     push      -1
004b3f6b 681576c500               push      0xc57615
004b3f70 50                       push      eax
004b3f71 8b4510                   mov       eax, dword ptr [ebp + 0x10]
004b3f74 85c0                     test      eax, eax
004b3f76 64892500000000           mov       dword ptr fs:[0], esp
004b3f7d 53                       push      ebx
004b3f7e 56                       push      esi
004b3f7f 57                       push      edi
004b3f80 8bf1                     mov       esi, ecx
004b3f82 0f84a1020000             je        0x4b4229
004b3f88 8b06                     mov       eax, dword ptr [esi]
004b3f8a ff90f4040000             call      dword ptr [eax + 0x4f4]
004b3f90 0fb65508                 movzx     edx, byte ptr [ebp + 8]
004b3f94 884513                   mov       byte ptr [ebp + 0x13], al
004b3f97 a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3f9c 8b7844                   mov       edi, dword ptr [eax + 0x44]
004b3f9f 8b8684180000             mov       eax, dword ptr [esi + 0x1884]
004b3fa5 8d8e80180000             lea       ecx, [esi + 0x1880]
004b3fab c1e002                   shl       eax, 2
004b3fae 8d1c38                   lea       ebx, [eax + edi]
004b3fb1 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b3fb7 33da                     xor       ebx, edx
004b3fb9 891c38                   mov       dword ptr [eax + edi], ebx
004b3fbc a1d8012101               mov       eax, dword ptr [0x12101d8]
004b3fc1 8b7848                   mov       edi, dword ptr [eax + 0x48]
004b3fc4 8b4104                   mov       eax, dword ptr [ecx + 4]
004b3fc7 c1e002                   shl       eax, 2
004b3fca 8d1c38                   lea       ebx, [eax + edi]
004b3fcd 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004b3fd3 33da                     xor       ebx, edx
004b3fd5 891c38                   mov       dword ptr [eax + edi], ebx
004b3fd8 e883e0f4ff               call      0x402060
004b3fdd 83cbff                   or        ebx, 0xffffffff
004b3fe0 85c0                     test      eax, eax
004b3fe2 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004b3fe8 0f8435010000             je        0x4b4123
004b3fee 33ff                     xor       edi, edi
004b3ff0 3bc7                     cmp       eax, edi
004b3ff2 0f84b1000000             je        0x4b40a9
004b3ff8 68e8010000               push      0x1e8
004b3ffd e84efcf4ff               call      0x403c50
004b4002 83c404                   add       esp, 4
004b4005 894508                   mov       dword ptr [ebp + 8], eax
004b4008 3bc7                     cmp       eax, edi
004b400a 897dfc                   mov       dword ptr [ebp - 4], edi
004b400d 7410                     je        0x4b401f
004b400f 6a01                     push      1
004b4011 68780ecd00               push      0xcd0e78
004b4016 8bc8                     mov       ecx, eax
004b4018 e8b3f6fdff               call      0x4936d0
004b401d 8bf8                     mov       edi, eax
004b401f 68fc010000               push      0x1fc
004b4024 895dfc                   mov       dword ptr [ebp - 4], ebx
004b4027 e824fcf4ff               call      0x403c50
004b402c 83c404                   add       esp, 4
004b402f 894508                   mov       dword ptr [ebp + 8], eax
004b4032 85c0                     test      eax, eax
004b4034 c745fc01000000           mov       dword ptr [ebp - 4], 1
004b403b 740e                     je        0x4b404b
004b403d 6a01                     push      1
004b403f 57                       push      edi
004b4040 8bc8                     mov       ecx, eax
004b4042 e8d97cffff               call      0x4abd20
004b4047 8bf8                     mov       edi, eax
004b4049 eb02                     jmp       0x4b404d
004b404b 33ff                     xor       edi, edi
004b404d 8b17                     mov       edx, dword ptr [edi]
004b404f 6a02                     push      2
004b4051 8bcf                     mov       ecx, edi
004b4053 895dfc                   mov       dword ptr [ebp - 4], ebx
004b4056 ff5254                   call      dword ptr [edx + 0x54]
004b4059 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b405f 6a00                     push      0
004b4061 6a00                     push      0
004b4063 57                       push      edi
004b4064 57                       push      edi
004b4065 6a00                     push      0
004b4067 6a02                     push      2
004b4069 57                       push      edi
004b406a e8019d0500               call      0x50dd70
004b406f 8b06                     mov       eax, dword ptr [esi]
004b4071 8b1f                     mov       ebx, dword ptr [edi]
004b4073 8bce                     mov       ecx, esi
004b4075 ff909c000000             call      dword ptr [eax + 0x9c]
004b407b 8b16                     mov       edx, dword ptr [esi]
004b407d 50                       push      eax
004b407e 8bce                     mov       ecx, esi
004b4080 ff9298000000             call      dword ptr [edx + 0x98]
004b4086 50                       push      eax
004b4087 8b06                     mov       eax, dword ptr [esi]
004b4089 8bce                     mov       ecx, esi
004b408b ff9094000000             call      dword ptr [eax + 0x94]
004b4091 50                       push      eax
004b4092 8bcf                     mov       ecx, edi
004b4094 ff9388000000             call      dword ptr [ebx + 0x88]
004b409a 8b17                     mov       edx, dword ptr [edi]
004b409c 57                       push      edi
004b409d 8bcf                     mov       ecx, edi
004b409f ff5248                   call      dword ptr [edx + 0x48]
004b40a2 8bc8                     mov       ecx, eax
004b40a4 e8d7cd0500               call      0x510e80
004b40a9 807d1301                 cmp       byte ptr [ebp + 0x13], 1
004b40ad 7514                     jne       0x4b40c3
004b40af 8d4e60                   lea       ecx, [esi + 0x60]
004b40b2 e8492e6500               call      0xb06f00
004b40b7 03450c                   add       eax, dword ptr [ebp + 0xc]
004b40ba 894508                   mov       dword ptr [ebp + 8], eax
004b40bd 8d4508                   lea       eax, [ebp + 8]
004b40c0 50                       push      eax
004b40c1 eb2d                     jmp       0x4b40f0
004b40c3 8d7e60                   lea       edi, [esi + 0x60]
004b40c6 8bcf                     mov       ecx, edi
004b40c8 e8332e6500               call      0xb06f00
004b40cd 8d4d08                   lea       ecx, [ebp + 8]
004b40d0 51                       push      ecx
004b40d1 8d8e88180000             lea       ecx, [esi + 0x1888]
004b40d7 894508                   mov       dword ptr [ebp + 8], eax
004b40da e88104f5ff               call      0x404560
004b40df 8bcf                     mov       ecx, edi
004b40e1 e81a2e6500               call      0xb06f00
004b40e6 03450c                   add       eax, dword ptr [ebp + 0xc]
004b40e9 8d5508                   lea       edx, [ebp + 8]
004b40ec 894508                   mov       dword ptr [ebp + 8], eax
004b40ef 52                       push      edx
004b40f0 8d8e90180000             lea       ecx, [esi + 0x1890]
004b40f6 e86504f5ff               call      0x404560
004b40fb 8b06                     mov       eax, dword ptr [esi]
004b40fd 6a00                     push      0
004b40ff 6a00                     push      0
004b4101 6aff                     push      -1
004b4103 68480ecd00               push      0xcd0e48
004b4108 8bce                     mov       ecx, esi
004b410a ff900c010000             call      dword ptr [eax + 0x10c]
004b4110 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b4113 64890d00000000           mov       dword ptr fs:[0], ecx
004b411a 5f                       pop       edi
004b411b 5e                       pop       esi
004b411c 5b                       pop       ebx
004b411d 8be5                     mov       esp, ebp
004b411f 5d                       pop       ebp
004b4120 c20c00                   ret       0xc
004b4123 85c0                     test      eax, eax
004b4125 0f84b9000000             je        0x4b41e4
004b412b 68e8010000               push      0x1e8
004b4130 e81bfbf4ff               call      0x403c50
004b4135 83c404                   add       esp, 4
004b4138 894508                   mov       dword ptr [ebp + 8], eax
004b413b 85c0                     test      eax, eax
004b413d c745fc02000000           mov       dword ptr [ebp - 4], 2
004b4144 7412                     je        0x4b4158
004b4146 6a01                     push      1
004b4148 68e80dcd00               push      0xcd0de8
004b414d 8bc8                     mov       ecx, eax
004b414f e87cf5fdff               call      0x4936d0
004b4154 8bf8                     mov       edi, eax
004b4156 eb02                     jmp       0x4b415a
004b4158 33ff                     xor       edi, edi
004b415a 68fc010000               push      0x1fc
004b415f 895dfc                   mov       dword ptr [ebp - 4], ebx
004b4162 e8e9faf4ff               call      0x403c50
004b4167 83c404                   add       esp, 4
004b416a 894508                   mov       dword ptr [ebp + 8], eax
004b416d 85c0                     test      eax, eax
004b416f c745fc03000000           mov       dword ptr [ebp - 4], 3
004b4176 740e                     je        0x4b4186
004b4178 6a01                     push      1
004b417a 57                       push      edi
004b417b 8bc8                     mov       ecx, eax
004b417d e89e7bffff               call      0x4abd20
004b4182 8bf8                     mov       edi, eax
004b4184 eb02                     jmp       0x4b4188
004b4186 33ff                     xor       edi, edi
004b4188 8b17                     mov       edx, dword ptr [edi]
004b418a 6a02                     push      2
004b418c 8bcf                     mov       ecx, edi
004b418e 895dfc                   mov       dword ptr [ebp - 4], ebx
004b4191 ff5254                   call      dword ptr [edx + 0x54]
004b4194 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b419a 6a00                     push      0
004b419c 6a00                     push      0
004b419e 57                       push      edi
004b419f 57                       push      edi
004b41a0 6a00                     push      0
004b41a2 6a02                     push      2
004b41a4 57                       push      edi
004b41a5 e8c69b0500               call      0x50dd70
004b41aa 8b06                     mov       eax, dword ptr [esi]
004b41ac 8b1f                     mov       ebx, dword ptr [edi]
004b41ae 8bce                     mov       ecx, esi
004b41b0 ff909c000000             call      dword ptr [eax + 0x9c]
004b41b6 8b16                     mov       edx, dword ptr [esi]
004b41b8 50                       push      eax
004b41b9 8bce                     mov       ecx, esi
004b41bb ff9298000000             call      dword ptr [edx + 0x98]
004b41c1 50                       push      eax
004b41c2 8b06                     mov       eax, dword ptr [esi]
004b41c4 8bce                     mov       ecx, esi
004b41c6 ff9094000000             call      dword ptr [eax + 0x94]
004b41cc 50                       push      eax
004b41cd 8bcf                     mov       ecx, edi
004b41cf ff9388000000             call      dword ptr [ebx + 0x88]
004b41d5 8b17                     mov       edx, dword ptr [edi]
004b41d7 57                       push      edi
004b41d8 8bcf                     mov       ecx, edi
004b41da ff5248                   call      dword ptr [edx + 0x48]
004b41dd 8bc8                     mov       ecx, eax
004b41df e89ccc0500               call      0x510e80
004b41e4 8d4e60                   lea       ecx, [esi + 0x60]
004b41e7 e8142d6500               call      0xb06f00
004b41ec 894508                   mov       dword ptr [ebp + 8], eax
004b41ef 8d4508                   lea       eax, [ebp + 8]
004b41f2 50                       push      eax
004b41f3 8d8e88180000             lea       ecx, [esi + 0x1888]
004b41f9 e86203f5ff               call      0x404560
004b41fe 8d4d08                   lea       ecx, [ebp + 8]
004b4201 51                       push      ecx
004b4202 8d8e90180000             lea       ecx, [esi + 0x1890]
004b4208 c7450800000000           mov       dword ptr [ebp + 8], 0
004b420f e84c03f5ff               call      0x404560
004b4214 8b16                     mov       edx, dword ptr [esi]
004b4216 6a00                     push      0
004b4218 6a00                     push      0
004b421a 6aff                     push      -1
004b421c 68c40dcd00               push      0xcd0dc4
004b4221 8bce                     mov       ecx, esi
004b4223 ff920c010000             call      dword ptr [edx + 0x10c]
004b4229 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b422c 5f                       pop       edi
004b422d 5e                       pop       esi
004b422e 64890d00000000           mov       dword ptr fs:[0], ecx
004b4235 5b                       pop       ebx
004b4236 8be5                     mov       esp, ebp
004b4238 5d                       pop       ebp
004b4239 c20c00                   ret       0xc
004b423c cc                       int3      
004b423d cc                       int3      
004b423e cc                       int3      
004b423f cc                       int3      
004b4240 55                       push      ebp
004b4241 8bec                     mov       ebp, esp
004b4243 6aff                     push      -1
004b4245 683576c500               push      0xc57635
004b424a 64a100000000             mov       eax, dword ptr fs:[0]
004b4250 50                       push      eax
004b4251 64892500000000           mov       dword ptr fs:[0], esp
004b4258 83ec0c                   sub       esp, 0xc
004b425b 56                       push      esi
004b425c 8bf1                     mov       esi, ecx
004b425e 8b8600010000             mov       eax, dword ptr [esi + 0x100]
004b4264 85c0                     test      eax, eax
004b4266 0f8446010000             je        0x4b43b2
004b426c 8b06                     mov       eax, dword ptr [esi]
004b426e 53                       push      ebx
004b426f 57                       push      edi
004b4270 c745ec0000803f           mov       dword ptr [ebp - 0x14], 0x3f800000
004b4277 c745f00000803f           mov       dword ptr [ebp - 0x10], 0x3f800000
004b427e ff9070030000             call      dword ptr [eax + 0x370]
004b4284 85c0                     test      eax, eax
004b4286 745d                     je        0x4b42e5
004b4288 8b16                     mov       edx, dword ptr [esi]
004b428a 6a00                     push      0
004b428c 8bce                     mov       ecx, esi
004b428e ff9270030000             call      dword ptr [edx + 0x370]
004b4294 8bc8                     mov       ecx, eax
004b4296 e8f5195700               call      0xa25c90
004b429b 6a01                     push      1
004b429d 8bf8                     mov       edi, eax
004b429f 6a00                     push      0
004b42a1 57                       push      edi
004b42a2 e839005700               call      0xa242e0
004b42a7 6a01                     push      1
004b42a9 6a01                     push      1
004b42ab 57                       push      edi
004b42ac 8bd8                     mov       ebx, eax
004b42ae e82d005700               call      0xa242e0
004b42b3 83c418                   add       esp, 0x18
004b42b6 3bd8                     cmp       ebx, eax
004b42b8 7e02                     jle       0x4b42bc
004b42ba 8bc3                     mov       eax, ebx
004b42bc 8b8e88010000             mov       ecx, dword ptr [esi + 0x188]
004b42c2 03c0                     add       eax, eax
004b42c4 8945ec                   mov       dword ptr [ebp - 0x14], eax
004b42c7 db45ec                   fild      dword ptr [ebp - 0x14]
004b42ca 83c128                   add       ecx, 0x28
004b42cd 894df0                   mov       dword ptr [ebp - 0x10], ecx
004b42d0 d80d3c0fcd00             fmul      dword ptr [0xcd0f3c]
004b42d6 d95dec                   fstp      dword ptr [ebp - 0x14]
004b42d9 db45f0                   fild      dword ptr [ebp - 0x10]
004b42dc d80d380fcd00             fmul      dword ptr [0xcd0f38]
004b42e2 d95df0                   fstp      dword ptr [ebp - 0x10]
004b42e5 68e8010000               push      0x1e8
004b42ea e861f9f4ff               call      0x403c50
004b42ef 83c404                   add       esp, 4
004b42f2 8945e8                   mov       dword ptr [ebp - 0x18], eax
004b42f5 33db                     xor       ebx, ebx
004b42f7 3bc3                     cmp       eax, ebx
004b42f9 895dfc                   mov       dword ptr [ebp - 4], ebx
004b42fc 7410                     je        0x4b430e
004b42fe 6a01                     push      1
004b4300 68d80ecd00               push      0xcd0ed8
004b4305 8bc8                     mov       ecx, eax
004b4307 e8c4f3fdff               call      0x4936d0
004b430c 8bd8                     mov       ebx, eax
004b430e 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004b4311 8b45ec                   mov       eax, dword ptr [ebp - 0x14]
004b4314 52                       push      edx
004b4315 50                       push      eax
004b4316 8bcb                     mov       ecx, ebx
004b4318 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b431f e8dc155700               call      0xa25900
004b4324 68fc010000               push      0x1fc
004b4329 e822f9f4ff               call      0x403c50
004b432e 8bf8                     mov       edi, eax
004b4330 83c404                   add       esp, 4
004b4333 897de8                   mov       dword ptr [ebp - 0x18], edi
004b4336 85ff                     test      edi, edi
004b4338 c745fc01000000           mov       dword ptr [ebp - 4], 1
004b433f 7414                     je        0x4b4355
004b4341 6a00                     push      0
004b4343 6a01                     push      1
004b4345 53                       push      ebx
004b4346 8bcf                     mov       ecx, edi
004b4348 e86302feff               call      0x4945b0
004b434d c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004b4353 eb02                     jmp       0x4b4357
004b4355 33ff                     xor       edi, edi
004b4357 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b435d 6a00                     push      0
004b435f 6a00                     push      0
004b4361 6a00                     push      0
004b4363 57                       push      edi
004b4364 6a00                     push      0
004b4366 6a02                     push      2
004b4368 56                       push      esi
004b4369 c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b4370 e8fb990500               call      0x50dd70
004b4375 8b16                     mov       edx, dword ptr [esi]
004b4377 8b1f                     mov       ebx, dword ptr [edi]
004b4379 8bce                     mov       ecx, esi
004b437b ff929c000000             call      dword ptr [edx + 0x9c]
004b4381 50                       push      eax
004b4382 8b06                     mov       eax, dword ptr [esi]
004b4384 8bce                     mov       ecx, esi
004b4386 ff9098000000             call      dword ptr [eax + 0x98]
004b438c 8b16                     mov       edx, dword ptr [esi]
004b438e 40                       inc       eax
004b438f 50                       push      eax
004b4390 8bce                     mov       ecx, esi
004b4392 ff9294000000             call      dword ptr [edx + 0x94]
004b4398 50                       push      eax
004b4399 8bcf                     mov       ecx, edi
004b439b ff9388000000             call      dword ptr [ebx + 0x88]
004b43a1 8b07                     mov       eax, dword ptr [edi]
004b43a3 56                       push      esi
004b43a4 8bcf                     mov       ecx, edi
004b43a6 ff5048                   call      dword ptr [eax + 0x48]
004b43a9 8bc8                     mov       ecx, eax
004b43ab e8d0ca0500               call      0x510e80
004b43b0 5f                       pop       edi
004b43b1 5b                       pop       ebx
004b43b2 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b43b5 5e                       pop       esi
004b43b6 64890d00000000           mov       dword ptr fs:[0], ecx
004b43bd 8be5                     mov       esp, ebp
004b43bf 5d                       pop       ebp
004b43c0 c3                       ret       
004b43c1 cc                       int3      
004b43c2 cc                       int3      
004b43c3 cc                       int3      
004b43c4 cc                       int3      
004b43c5 cc                       int3      
004b43c6 cc                       int3      
004b43c7 cc                       int3      
004b43c8 cc                       int3      
004b43c9 cc                       int3      
004b43ca cc                       int3      
004b43cb cc                       int3      
004b43cc cc                       int3      
004b43cd cc                       int3      
004b43ce cc                       int3      
004b43cf cc                       int3      
004b43d0 55                       push      ebp
004b43d1 8bec                     mov       ebp, esp
004b43d3 6aff                     push      -1
004b43d5 685576c500               push      0xc57655
004b43da 64a100000000             mov       eax, dword ptr fs:[0]
004b43e0 50                       push      eax
004b43e1 64892500000000           mov       dword ptr fs:[0], esp
004b43e8 51                       push      ecx
004b43e9 53                       push      ebx
004b43ea 56                       push      esi
004b43eb 57                       push      edi
004b43ec 68e8010000               push      0x1e8
004b43f1 8bf1                     mov       esi, ecx
004b43f3 e858f8f4ff               call      0x403c50
004b43f8 83c404                   add       esp, 4
004b43fb 8945f0                   mov       dword ptr [ebp - 0x10], eax
004b43fe 33db                     xor       ebx, ebx
004b4400 3bc3                     cmp       eax, ebx
004b4402 895dfc                   mov       dword ptr [ebp - 4], ebx
004b4405 7410                     je        0x4b4417
004b4407 6a01                     push      1
004b4409 68400fcd00               push      0xcd0f40
004b440e 8bc8                     mov       ecx, eax
004b4410 e8bbf2fdff               call      0x4936d0
004b4415 8bd8                     mov       ebx, eax
004b4417 68fc010000               push      0x1fc
004b441c c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b4423 e828f8f4ff               call      0x403c50
004b4428 8bf8                     mov       edi, eax
004b442a 83c404                   add       esp, 4
004b442d 897df0                   mov       dword ptr [ebp - 0x10], edi
004b4430 85ff                     test      edi, edi
004b4432 c745fc01000000           mov       dword ptr [ebp - 4], 1
004b4439 7414                     je        0x4b444f
004b443b 6a00                     push      0
004b443d 6a01                     push      1
004b443f 53                       push      ebx
004b4440 8bcf                     mov       ecx, edi
004b4442 e86901feff               call      0x4945b0
004b4447 c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004b444d eb02                     jmp       0x4b4451
004b444f 33ff                     xor       edi, edi
004b4451 8b07                     mov       eax, dword ptr [edi]
004b4453 6a02                     push      2
004b4455 8bcf                     mov       ecx, edi
004b4457 897df0                   mov       dword ptr [ebp - 0x10], edi
004b445a c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b4461 ff5054                   call      dword ptr [eax + 0x54]
004b4464 8b8e00010000             mov       ecx, dword ptr [esi + 0x100]
004b446a 6a00                     push      0
004b446c 6a00                     push      0
004b446e 56                       push      esi
004b446f 57                       push      edi
004b4470 6a00                     push      0
004b4472 6a02                     push      2
004b4474 56                       push      esi
004b4475 e8f6980500               call      0x50dd70
004b447a 8b16                     mov       edx, dword ptr [esi]
004b447c 8b1f                     mov       ebx, dword ptr [edi]
004b447e 8bce                     mov       ecx, esi
004b4480 ff92e4000000             call      dword ptr [edx + 0xe4]
004b4486 8bf8                     mov       edi, eax
004b4488 8b06                     mov       eax, dword ptr [esi]
004b448a 8bce                     mov       ecx, esi
004b448c ff909c000000             call      dword ptr [eax + 0x9c]
004b4492 8b16                     mov       edx, dword ptr [esi]
004b4494 03f8                     add       edi, eax
004b4496 57                       push      edi
004b4497 8bce                     mov       ecx, esi
004b4499 ff9294010000             call      dword ptr [edx + 0x194]
004b449f 8b5018                   mov       edx, dword ptr [eax + 0x18]
004b44a2 8b7d0c                   mov       edi, dword ptr [ebp + 0xc]
004b44a5 8b06                     mov       eax, dword ptr [esi]
004b44a7 8bce                     mov       ecx, esi
004b44a9 2bfa                     sub       edi, edx
004b44ab ff9098000000             call      dword ptr [eax + 0x98]
004b44b1 8b16                     mov       edx, dword ptr [esi]
004b44b3 03f8                     add       edi, eax
004b44b5 57                       push      edi
004b44b6 8bce                     mov       ecx, esi
004b44b8 ff9294000000             call      dword ptr [edx + 0x94]
004b44be 8b5508                   mov       edx, dword ptr [ebp + 8]
004b44c1 8b7df0                   mov       edi, dword ptr [ebp - 0x10]
004b44c4 03c2                     add       eax, edx
004b44c6 50                       push      eax
004b44c7 8bcf                     mov       ecx, edi
004b44c9 ff9388000000             call      dword ptr [ebx + 0x88]
004b44cf 8b07                     mov       eax, dword ptr [edi]
004b44d1 56                       push      esi
004b44d2 8bcf                     mov       ecx, edi
004b44d4 ff5048                   call      dword ptr [eax + 0x48]
004b44d7 8bc8                     mov       ecx, eax
004b44d9 e8a2c90500               call      0x510e80
004b44de 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004b44e1 5f                       pop       edi
004b44e2 5e                       pop       esi
004b44e3 5b                       pop       ebx
004b44e4 64890d00000000           mov       dword ptr fs:[0], ecx
004b44eb 8be5                     mov       esp, ebp
004b44ed 5d                       pop       ebp
004b44ee c20800                   ret       8
004b44f1 cc                       int3      
004b44f2 cc                       int3      
004b44f3 cc                       int3      
004b44f4 cc                       int3      
004b44f5 cc                       int3      
004b44f6 cc                       int3      
004b44f7 cc                       int3      
004b44f8 cc                       int3      
004b44f9 cc                       int3      
004b44fa cc                       int3      
004b44fb cc                       int3      
004b44fc cc                       int3      
004b44fd cc                       int3      
004b44fe cc                       int3      
004b44ff cc                       int3      
004b4500 55                       push      ebp
004b4501 8bec                     mov       ebp, esp
004b4503 6aff                     push      -1
004b4505 687576c500               push      0xc57675
004b450a 64a100000000             mov       eax, dword ptr fs:[0]
004b4510 50                       push      eax
004b4511 64892500000000           mov       dword ptr fs:[0], esp
004b4518 51                       push      ecx
004b4519 53                       push      ebx
004b451a 56                       push      esi
004b451b 57                       push      edi
004b451c 68e8010000               push      0x1e8
004b4521 8bf1                     mov       esi, ecx
004b4523 e828f7f4ff               call      0x403c50
004b4528 83c404                   add       esp, 4
004b452b 8945f0                   mov       dword ptr [ebp - 0x10], eax
004b452e 33db                     xor       ebx, ebx
004b4530 3bc3                     cmp       eax, ebx
004b4532 895dfc                   mov       dword ptr [ebp - 4], ebx
004b4535 7410                     je        0x4b4547
004b4537 6a01                     push      1
004b4539 68980fcd00               push      0xcd0f98
004b453e 8bc8                     mov       ecx, eax
004b4540 e88bf1fdff               call      0x4936d0
004b4545 8bd8                     mov       ebx, eax
004b4547 68fc010000               push      0x1fc
004b454c c745fcffffffff           mov       dword ptr [ebp - 4], 0xffffffff
004b4553 e8f8f6f4ff               call      0x403c50
004b4558 8bf8                     mov       edi, eax
004b455a 83c404                   add       esp, 4
004b455d 897df0                   mov       dword ptr [ebp - 0x10], edi
004b4560 85ff                     test      edi, edi
004b4562 c745fc01000000           mov       dword ptr [ebp - 4], 1
004b4569 7414                     je        0x4b457f
004b456b 6a00                     push      0
004b456d 6a01                     push      1
004b456f 53                       push      ebx
004b4570 8bcf                     mov       ecx, edi
004b4572 e83900feff               call      0x4945b0
004b4577 c707c4ffcc00             mov       dword ptr [edi], 0xccffc4
004b457d eb02                     jmp       0x4b4581
004b457f 33                       .byte     0x33
