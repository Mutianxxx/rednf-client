004fbcba 33ff                     xor       edi, edi
004fbcbc 53                       push      ebx
004fbcbd 33db                     xor       ebx, ebx
004fbcbf 897df4                   mov       dword ptr [ebp - 0xc], edi
004fbcc2 8b8eec230000             mov       ecx, dword ptr [esi + 0x23ec]
004fbcc8 85c9                     test      ecx, ecx
004fbcca 0f8431010000             je        0x4fbe01
004fbcd0 8b86f0230000             mov       eax, dword ptr [esi + 0x23f0]
004fbcd6 2bc1                     sub       eax, ecx
004fbcd8 c1f806                   sar       eax, 6
004fbcdb 3bd8                     cmp       ebx, eax
004fbcdd 0f831e010000             jae       0x4fbe01
004fbce3 8b9658230000             mov       edx, dword ptr [esi + 0x2358]
004fbce9 8d049a                   lea       eax, [edx + ebx*4]
004fbcec 03cf                     add       ecx, edi
004fbcee 8945f8                   mov       dword ptr [ebp - 8], eax
004fbcf1 e80ab26000               call      0xb06f00
004fbcf6 8b4df8                   mov       ecx, dword ptr [ebp - 8]
004fbcf9 3b01                     cmp       eax, dword ptr [ecx]
004fbcfb 0f8eee000000             jle       0x4fbdef
004fbd01 8b8eec230000             mov       ecx, dword ptr [esi + 0x23ec]
004fbd07 03cf                     add       ecx, edi
004fbd09 e8f2b16000               call      0xb06f00
004fbd0e 8b86601d0000             mov       eax, dword ptr [esi + 0x1d60]
004fbd14 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004fbd17 8b540804                 mov       edx, dword ptr [eax + ecx + 4]
004fbd1b 03c1                     add       eax, ecx
004fbd1d 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbd23 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004fbd26 8d0c91                   lea       ecx, [ecx + edx*4]
004fbd29 8bd1                     mov       edx, ecx
004fbd2b 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fbd31 83f201                   xor       edx, 1
004fbd34 8911                     mov       dword ptr [ecx], edx
004fbd36 8b4004                   mov       eax, dword ptr [eax + 4]
004fbd39 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbd3f 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fbd42 8d0482                   lea       eax, [edx + eax*4]
004fbd45 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fbd4b 8bc8                     mov       ecx, eax
004fbd4d 33ca                     xor       ecx, edx
004fbd4f 83f101                   xor       ecx, 1
004fbd52 8908                     mov       dword ptr [eax], ecx
004fbd54 8b86ec230000             mov       eax, dword ptr [esi + 0x23ec]
004fbd5a 8b54381c                 mov       edx, dword ptr [eax + edi + 0x1c]
004fbd5e 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbd64 8b4944                   mov       ecx, dword ptr [ecx + 0x44]
004fbd67 8d0c91                   lea       ecx, [ecx + edx*4]
004fbd6a 03c7                     add       eax, edi
004fbd6c 8bd1                     mov       edx, ecx
004fbd6e 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fbd74 8911                     mov       dword ptr [ecx], edx
004fbd76 8b481c                   mov       ecx, dword ptr [eax + 0x1c]
004fbd79 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fbd7f 8b5248                   mov       edx, dword ptr [edx + 0x48]
004fbd82 8d0c8a                   lea       ecx, [edx + ecx*4]
004fbd85 8bd1                     mov       edx, ecx
004fbd87 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fbd8d 8911                     mov       dword ptr [ecx], edx
004fbd8f 8b4824                   mov       ecx, dword ptr [eax + 0x24]
004fbd92 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fbd98 8b5244                   mov       edx, dword ptr [edx + 0x44]
004fbd9b 8d0c8a                   lea       ecx, [edx + ecx*4]
004fbd9e 8bd1                     mov       edx, ecx
004fbda0 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fbda6 8911                     mov       dword ptr [ecx], edx
004fbda8 8b4024                   mov       eax, dword ptr [eax + 0x24]
004fbdab 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbdb1 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fbdb4 8d0482                   lea       eax, [edx + eax*4]
004fbdb7 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fbdbd 8bc8                     mov       ecx, eax
004fbdbf 33ca                     xor       ecx, edx
004fbdc1 8908                     mov       dword ptr [eax], ecx
004fbdc3 8b8e08240000             mov       ecx, dword ptr [esi + 0x2408]
004fbdc9 33c0                     xor       eax, eax
004fbdcb 8bc3                     mov       eax, ebx
004fbdcd 8bd0                     mov       edx, eax
004fbdcf c1ea05                   shr       edx, 5
004fbdd2 8d1491                   lea       edx, [ecx + edx*4]
004fbdd5 83e01f                   and       eax, 0x1f
004fbdd8 b901000000               mov       ecx, 1
004fbddd 894df8                   mov       dword ptr [ebp - 8], ecx
004fbde0 8bc8                     mov       ecx, eax
004fbde2 8b45f8                   mov       eax, dword ptr [ebp - 8]
004fbde5 d3e0                     shl       eax, cl
004fbde7 8b0a                     mov       ecx, dword ptr [edx]
004fbde9 f7d0                     not       eax
004fbdeb 23c8                     and       ecx, eax
004fbded 890a                     mov       dword ptr [edx], ecx
004fbdef 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004fbdf2 83c160                   add       ecx, 0x60
004fbdf5 43                       inc       ebx
004fbdf6 894df4                   mov       dword ptr [ebp - 0xc], ecx
004fbdf9 83c740                   add       edi, 0x40
004fbdfc e9c1feffff               jmp       0x4fbcc2
004fbe01 33ff                     xor       edi, edi
004fbe03 8b8608230000             mov       eax, dword ptr [esi + 0x2308]
004fbe09 85c0                     test      eax, eax
004fbe0b 7431                     je        0x4fbe3e
004fbe0d 8b8e0c230000             mov       ecx, dword ptr [esi + 0x230c]
004fbe13 2bc8                     sub       ecx, eax
004fbe15 b8398ee338               mov       eax, 0x38e38e39
004fbe1a f7e9                     imul      ecx
004fbe1c c1fa03                   sar       edx, 3
004fbe1f 8bc2                     mov       eax, edx
004fbe21 c1e81f                   shr       eax, 0x1f
004fbe24 03c2                     add       eax, edx
004fbe26 3bf8                     cmp       edi, eax
004fbe28 7314                     jae       0x4fbe3e
004fbe2a 8b8648230000             mov       eax, dword ptr [esi + 0x2348]
004fbe30 8b0cb8                   mov       ecx, dword ptr [eax + edi*4]
004fbe33 8d04b8                   lea       eax, [eax + edi*4]
004fbe36 e825252500               call      0x74e360
004fbe3b 47                       inc       edi
004fbe3c ebc5                     jmp       0x4fbe03
004fbe3e 33ff                     xor       edi, edi
004fbe40 897df4                   mov       dword ptr [ebp - 0xc], edi
004fbe43 897df8                   mov       dword ptr [ebp - 8], edi
004fbe46 eb08                     jmp       0x4fbe50
004fbe48 8da42400000000           lea       esp, [esp]
004fbe4f 90                       nop       
004fbe50 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fbe56 85c0                     test      eax, eax
004fbe58 0f8418010000             je        0x4fbf76
004fbe5e 8b8efc220000             mov       ecx, dword ptr [esi + 0x22fc]
004fbe64 2bc8                     sub       ecx, eax
004fbe66 b8398ee338               mov       eax, 0x38e38e39
004fbe6b f7e9                     imul      ecx
004fbe6d c1fa03                   sar       edx, 3
004fbe70 8bc2                     mov       eax, edx
004fbe72 c1e81f                   shr       eax, 0x1f
004fbe75 03c2                     add       eax, edx
004fbe77 3bf8                     cmp       edi, eax
004fbe79 0f83f7000000             jae       0x4fbf76
004fbe7f 8b9ef8220000             mov       ebx, dword ptr [esi + 0x22f8]
004fbe85 8b55f8                   mov       edx, dword ptr [ebp - 8]
004fbe88 8d8ea8230000             lea       ecx, [esi + 0x23a8]
004fbe8e 03da                     add       ebx, edx
004fbe90 e86bb06000               call      0xb06f00
004fbe95 3b4314                   cmp       eax, dword ptr [ebx + 0x14]
004fbe98 7f0c                     jg        0x4fbea6
004fbe9a 8b45f8                   mov       eax, dword ptr [ebp - 8]
004fbe9d 47                       inc       edi
004fbe9e 83c024                   add       eax, 0x24
004fbea1 8945f8                   mov       dword ptr [ebp - 8], eax
004fbea4 ebaa                     jmp       0x4fbe50
004fbea6 8b96f8220000             mov       edx, dword ptr [esi + 0x22f8]
004fbeac 8b9e601d0000             mov       ebx, dword ptr [esi + 0x1d60]
004fbeb2 8d0cff                   lea       ecx, [edi + edi*8]
004fbeb5 8d048a                   lea       eax, [edx + ecx*4]
004fbeb8 8b4004                   mov       eax, dword ptr [eax + 4]
004fbebb 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fbec1 8b5244                   mov       edx, dword ptr [edx + 0x44]
004fbec4 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fbeca 8d0440                   lea       eax, [eax + eax*2]
004fbecd c1e005                   shl       eax, 5
004fbed0 8b4c1804                 mov       ecx, dword ptr [eax + ebx + 4]
004fbed4 8d0c8a                   lea       ecx, [edx + ecx*4]
004fbed7 03c3                     add       eax, ebx
004fbed9 8bd1                     mov       edx, ecx
004fbedb 33d7                     xor       edx, edi
004fbedd 83f201                   xor       edx, 1
004fbee0 8911                     mov       dword ptr [ecx], edx
004fbee2 8b4004                   mov       eax, dword ptr [eax + 4]
004fbee5 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbeeb 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fbeee 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fbef4 8d0482                   lea       eax, [edx + eax*4]
004fbef7 8bc8                     mov       ecx, eax
004fbef9 33cf                     xor       ecx, edi
004fbefb 83f101                   xor       ecx, 1
004fbefe 8908                     mov       dword ptr [eax], ecx
004fbf00 a1d8012101               mov       eax, dword ptr [0x12101d8]
004fbf05 8b4844                   mov       ecx, dword ptr [eax + 0x44]
004fbf08 8b96c4230000             mov       edx, dword ptr [esi + 0x23c4]
004fbf0e 8d0491                   lea       eax, [ecx + edx*4]
004fbf11 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004fbf17 8bd0                     mov       edx, eax
004fbf19 33d1                     xor       edx, ecx
004fbf1b 8910                     mov       dword ptr [eax], edx
004fbf1d 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbf23 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fbf26 8b86c4230000             mov       eax, dword ptr [esi + 0x23c4]
004fbf2c 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004fbf32 8d0482                   lea       eax, [edx + eax*4]
004fbf35 8bc8                     mov       ecx, eax
004fbf37 33cb                     xor       ecx, ebx
004fbf39 8908                     mov       dword ptr [eax], ecx
004fbf3b a1d8012101               mov       eax, dword ptr [0x12101d8]
004fbf40 8b4844                   mov       ecx, dword ptr [eax + 0x44]
004fbf43 8b96cc230000             mov       edx, dword ptr [esi + 0x23cc]
004fbf49 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fbf4f 8d0491                   lea       eax, [ecx + edx*4]
004fbf52 8bd0                     mov       edx, eax
004fbf54 33d7                     xor       edx, edi
004fbf56 8910                     mov       dword ptr [eax], edx
004fbf58 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbf5e 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fbf61 8b86cc230000             mov       eax, dword ptr [esi + 0x23cc]
004fbf67 8d0482                   lea       eax, [edx + eax*4]
004fbf6a 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fbf70 8bc8                     mov       ecx, eax
004fbf72 33ca                     xor       ecx, edx
004fbf74 8908                     mov       dword ptr [eax], ecx
004fbf76 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbf7c 33c0                     xor       eax, eax
004fbf7e 8945fc                   mov       dword ptr [ebp - 4], eax
004fbf81 8945f8                   mov       dword ptr [ebp - 8], eax
004fbf84 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fbf8a 85c0                     test      eax, eax
004fbf8c 0f84a2040000             je        0x4fc434
004fbf92 8b96fc220000             mov       edx, dword ptr [esi + 0x22fc]
004fbf98 2bd0                     sub       edx, eax
004fbf9a b8398ee338               mov       eax, 0x38e38e39
004fbf9f f7ea                     imul      edx
004fbfa1 c1fa03                   sar       edx, 3
004fbfa4 8bc2                     mov       eax, edx
004fbfa6 c1e81f                   shr       eax, 0x1f
004fbfa9 03c2                     add       eax, edx
004fbfab 3945fc                   cmp       dword ptr [ebp - 4], eax
004fbfae 0f8380040000             jae       0x4fc434
004fbfb4 8a86f8230000             mov       al, byte ptr [esi + 0x23f8]
004fbfba 84c0                     test      al, al
004fbfbc 0f850b030000             jne       0x4fc2cd
004fbfc2 a1dc012101               mov       eax, dword ptr [0x12101dc]
004fbfc7 8b9628180000             mov       edx, dword ptr [esi + 0x1828]
004fbfcd 8d9e28180000             lea       ebx, [esi + 0x1828]
004fbfd3 33d0                     xor       edx, eax
004fbfd5 8b4304                   mov       eax, dword ptr [ebx + 4]
004fbfd8 2bd3                     sub       edx, ebx
004fbfda 3bd0                     cmp       edx, eax
004fbfdc 740e                     je        0x4fbfec
004fbfde 6a3f                     push      0x3f
004fbfe0 53                       push      ebx
004fbfe1 e8cab06100               call      0xb170b0
004fbfe6 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fbfec 8b4304                   mov       eax, dword ptr [ebx + 4]
004fbfef 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fbff2 c1e002                   shl       eax, 2
004fbff5 8b3c02                   mov       edi, dword ptr [edx + eax]
004fbff8 03d0                     add       edx, eax
004fbffa 33fa                     xor       edi, edx
004fbffc 333ddc012101             xor       edi, dword ptr [0x12101dc]
004fc002 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fc005 03c2                     add       eax, edx
004fc007 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc00d 8945f0                   mov       dword ptr [ebp - 0x10], eax
004fc010 33c2                     xor       eax, edx
004fc012 8b55f0                   mov       edx, dword ptr [ebp - 0x10]
004fc015 3302                     xor       eax, dword ptr [edx]
004fc017 3bf8                     cmp       edi, eax
004fc019 740e                     je        0x4fc029
004fc01b 6a40                     push      0x40
004fc01d 53                       push      ebx
004fc01e e88db06100               call      0xb170b0
004fc023 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc029 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fc02f 8b5df8                   mov       ebx, dword ptr [ebp - 8]
004fc032 8b541804                 mov       edx, dword ptr [eax + ebx + 4]
004fc036 03c3                     add       eax, ebx
004fc038 3bfa                     cmp       edi, edx
004fc03a 0f858d020000             jne       0x4fc2cd
004fc040 8b06                     mov       eax, dword ptr [esi]
004fc042 8bce                     mov       ecx, esi
004fc044 ff90f4000000             call      dword ptr [eax + 0xf4]
004fc04a 8a883a010000             mov       cl, byte ptr [eax + 0x13a]
004fc050 84c9                     test      cl, cl
004fc052 0f846f020000             je        0x4fc2c7
004fc058 8b16                     mov       edx, dword ptr [esi]
004fc05a 8bce                     mov       ecx, esi
004fc05c ff9230020000             call      dword ptr [edx + 0x230]
004fc062 83f80e                   cmp       eax, 0xe
004fc065 0f845c020000             je        0x4fc2c7
004fc06b 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fc071 8bfb                     mov       edi, ebx
004fc073 8b4c3808                 mov       ecx, dword ptr [eax + edi + 8]
004fc077 03c7                     add       eax, edi
004fc079 83f901                   cmp       ecx, 1
004fc07c 751e                     jne       0x4fc09c
004fc07e 8b8e38230000             mov       ecx, dword ptr [esi + 0x2338]
004fc084 8b55fc                   mov       edx, dword ptr [ebp - 4]
004fc087 8b4018                   mov       eax, dword ptr [eax + 0x18]
004fc08a 8d0c91                   lea       ecx, [ecx + edx*4]
004fc08d 8b09                     mov       ecx, dword ptr [ecx]
004fc08f 50                       push      eax
004fc090 e82b452500               call      0x7505c0
004fc095 8945f4                   mov       dword ptr [ebp - 0xc], eax
004fc098 33db                     xor       ebx, ebx
004fc09a eb69                     jmp       0x4fc105
004fc09c 8b4808                   mov       ecx, dword ptr [eax + 8]
004fc09f 33db                     xor       ebx, ebx
004fc0a1 3bcb                     cmp       ecx, ebx
004fc0a3 751c                     jne       0x4fc0c1
004fc0a5 8b8e38230000             mov       ecx, dword ptr [esi + 0x2338]
004fc0ab 8b55fc                   mov       edx, dword ptr [ebp - 4]
004fc0ae 8b4018                   mov       eax, dword ptr [eax + 0x18]
004fc0b1 8d0c91                   lea       ecx, [ecx + edx*4]
004fc0b4 8b09                     mov       ecx, dword ptr [ecx]
004fc0b6 50                       push      eax
004fc0b7 e8e4422500               call      0x7503a0
004fc0bc 8945f4                   mov       dword ptr [ebp - 0xc], eax
004fc0bf eb44                     jmp       0x4fc105
004fc0c1 83780802                 cmp       dword ptr [eax + 8], 2
004fc0c5 753e                     jne       0x4fc105
004fc0c7 8a8ef9230000             mov       cl, byte ptr [esi + 0x23f9]
004fc0cd 84c9                     test      cl, cl
004fc0cf 7434                     je        0x4fc105
004fc0d1 8b96fc230000             mov       edx, dword ptr [esi + 0x23fc]
004fc0d7 3bd3                     cmp       edx, ebx
004fc0d9 741d                     je        0x4fc0f8
004fc0db 8b8e38230000             mov       ecx, dword ptr [esi + 0x2338]
004fc0e1 8b5dfc                   mov       ebx, dword ptr [ebp - 4]
004fc0e4 52                       push      edx
004fc0e5 8b5018                   mov       edx, dword ptr [eax + 0x18]
004fc0e8 8d0c99                   lea       ecx, [ecx + ebx*4]
004fc0eb 8b09                     mov       ecx, dword ptr [ecx]
004fc0ed 52                       push      edx
004fc0ee e89d472500               call      0x750890
004fc0f3 8945f4                   mov       dword ptr [ebp - 0xc], eax
004fc0f6 33db                     xor       ebx, ebx
004fc0f8 899efc230000             mov       dword ptr [esi + 0x23fc], ebx
004fc0fe c686f923000000           mov       byte ptr [esi + 0x23f9], 0
004fc105 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fc10b 8b4c3820                 mov       ecx, dword ptr [eax + edi + 0x20]
004fc10f 03c7                     add       eax, edi
004fc111 83f9fe                   cmp       ecx, -2
004fc114 746d                     je        0x4fc183
004fc116 8b55fc                   mov       edx, dword ptr [ebp - 4]
004fc119 83f9ff                   cmp       ecx, -1
004fc11c 8b8e38230000             mov       ecx, dword ptr [esi + 0x2338]
004fc122 8d0c91                   lea       ecx, [ecx + edx*4]
004fc125 8b09                     mov       ecx, dword ptr [ecx]
004fc127 7430                     je        0x4fc159
004fc129 8b5020                   mov       edx, dword ptr [eax + 0x20]
004fc12c 8b401c                   mov       eax, dword ptr [eax + 0x1c]
004fc12f 52                       push      edx
004fc130 8b55f4                   mov       edx, dword ptr [ebp - 0xc]
004fc133 50                       push      eax
004fc134 52                       push      edx
004fc135 8d45e0                   lea       eax, [ebp - 0x20]
004fc138 50                       push      eax
004fc139 e8123f2500               call      0x750050
004fc13e 8b45e4                   mov       eax, dword ptr [ebp - 0x1c]
004fc141 3bc3                     cmp       eax, ebx
004fc143 7409                     je        0x4fc14e
004fc145 50                       push      eax
004fc146 e8923e7000               call      0xbfffdd
004fc14b 83c404                   add       esp, 4
004fc14e 895de4                   mov       dword ptr [ebp - 0x1c], ebx
004fc151 895de8                   mov       dword ptr [ebp - 0x18], ebx
004fc154 895dec                   mov       dword ptr [ebp - 0x14], ebx
004fc157 eb2a                     jmp       0x4fc183
004fc159 8b401c                   mov       eax, dword ptr [eax + 0x1c]
004fc15c 8b55f4                   mov       edx, dword ptr [ebp - 0xc]
004fc15f 50                       push      eax
004fc160 52                       push      edx
004fc161 8d45d0                   lea       eax, [ebp - 0x30]
004fc164 50                       push      eax
004fc165 e8063c2500               call      0x74fd70
004fc16a 8b45d4                   mov       eax, dword ptr [ebp - 0x2c]
004fc16d 3bc3                     cmp       eax, ebx
004fc16f 7409                     je        0x4fc17a
004fc171 50                       push      eax
004fc172 e8663e7000               call      0xbfffdd
004fc177 83c404                   add       esp, 4
004fc17a 895dd4                   mov       dword ptr [ebp - 0x2c], ebx
004fc17d 895dd8                   mov       dword ptr [ebp - 0x28], ebx
004fc180 895ddc                   mov       dword ptr [ebp - 0x24], ebx
004fc183 a1d8012101               mov       eax, dword ptr [0x12101d8]
004fc188 8b4044                   mov       eax, dword ptr [eax + 0x44]
004fc18b 8b9684230000             mov       edx, dword ptr [esi + 0x2384]
004fc191 8d0490                   lea       eax, [eax + edx*4]
004fc194 8d8e68230000             lea       ecx, [esi + 0x2368]
004fc19a 8bd0                     mov       edx, eax
004fc19c 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fc1a2 53                       push      ebx
004fc1a3 8910                     mov       dword ptr [eax], edx
004fc1a5 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc1ab 8b5248                   mov       edx, dword ptr [edx + 0x48]
004fc1ae 8b411c                   mov       eax, dword ptr [ecx + 0x1c]
004fc1b1 8d0482                   lea       eax, [edx + eax*4]
004fc1b4 8bd0                     mov       edx, eax
004fc1b6 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fc1bc 53                       push      ebx
004fc1bd 8910                     mov       dword ptr [eax], edx
004fc1bf 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc1c5 8b5244                   mov       edx, dword ptr [edx + 0x44]
004fc1c8 8b4124                   mov       eax, dword ptr [ecx + 0x24]
004fc1cb 8d0482                   lea       eax, [edx + eax*4]
004fc1ce 8bd0                     mov       edx, eax
004fc1d0 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fc1d6 8910                     mov       dword ptr [eax], edx
004fc1d8 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc1de 8b5248                   mov       edx, dword ptr [edx + 0x48]
004fc1e1 8b4124                   mov       eax, dword ptr [ecx + 0x24]
004fc1e4 8d0482                   lea       eax, [edx + eax*4]
004fc1e7 8bd0                     mov       edx, eax
004fc1e9 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fc1ef 8910                     mov       dword ptr [eax], edx
004fc1f1 e86aad6000               call      0xb06f60
004fc1f6 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fc1fc 8b8e601d0000             mov       ecx, dword ptr [esi + 0x1d60]
004fc202 c686f823000001           mov       byte ptr [esi + 0x23f8], 1
004fc209 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc20f 8b5244                   mov       edx, dword ptr [edx + 0x44]
004fc212 03c7                     add       eax, edi
004fc214 8b4004                   mov       eax, dword ptr [eax + 4]
004fc217 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fc21d 8d0440                   lea       eax, [eax + eax*2]
004fc220 c1e005                   shl       eax, 5
004fc223 03c1                     add       eax, ecx
004fc225 8b4804                   mov       ecx, dword ptr [eax + 4]
004fc228 8d0c8a                   lea       ecx, [edx + ecx*4]
004fc22b 8bd1                     mov       edx, ecx
004fc22d 33d7                     xor       edx, edi
004fc22f 8911                     mov       dword ptr [ecx], edx
004fc231 8b4004                   mov       eax, dword ptr [eax + 4]
004fc234 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc23a 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fc23d 8d0482                   lea       eax, [edx + eax*4]
004fc240 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc246 8bc8                     mov       ecx, eax
004fc248 33ca                     xor       ecx, edx
004fc24a 8908                     mov       dword ptr [eax], ecx
004fc24c a1d8012101               mov       eax, dword ptr [0x12101d8]
004fc251 8b4044                   mov       eax, dword ptr [eax + 0x44]
004fc254 8b96c4230000             mov       edx, dword ptr [esi + 0x23c4]
004fc25a 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fc260 8d0490                   lea       eax, [eax + edx*4]
004fc263 8d8ea8230000             lea       ecx, [esi + 0x23a8]
004fc269 8bd0                     mov       edx, eax
004fc26b 33d7                     xor       edx, edi
004fc26d 8910                     mov       dword ptr [eax], edx
004fc26f 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc275 8b5248                   mov       edx, dword ptr [edx + 0x48]
004fc278 8b411c                   mov       eax, dword ptr [ecx + 0x1c]
004fc27b 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fc281 8d0482                   lea       eax, [edx + eax*4]
004fc284 8bd0                     mov       edx, eax
004fc286 33d7                     xor       edx, edi
004fc288 8910                     mov       dword ptr [eax], edx
004fc28a 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc290 8b5244                   mov       edx, dword ptr [edx + 0x44]
004fc293 8b4124                   mov       eax, dword ptr [ecx + 0x24]
004fc296 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fc29c 8d0482                   lea       eax, [edx + eax*4]
004fc29f 8bd0                     mov       edx, eax
004fc2a1 33d7                     xor       edx, edi
004fc2a3 8910                     mov       dword ptr [eax], edx
004fc2a5 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc2ab 8b5248                   mov       edx, dword ptr [edx + 0x48]
004fc2ae 8b4124                   mov       eax, dword ptr [ecx + 0x24]
004fc2b1 8b3ddc012101             mov       edi, dword ptr [0x12101dc]
004fc2b7 8d0482                   lea       eax, [edx + eax*4]
004fc2ba 8bd0                     mov       edx, eax
004fc2bc 53                       push      ebx
004fc2bd 33d7                     xor       edx, edi
004fc2bf 53                       push      ebx
004fc2c0 8910                     mov       dword ptr [eax], edx
004fc2c2 e899ac6000               call      0xb06f60
004fc2c7 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc2cd 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc2d3 8b8628180000             mov       eax, dword ptr [esi + 0x1828]
004fc2d9 8d9e28180000             lea       ebx, [esi + 0x1828]
004fc2df 33c2                     xor       eax, edx
004fc2e1 8b5304                   mov       edx, dword ptr [ebx + 4]
004fc2e4 2bc3                     sub       eax, ebx
004fc2e6 3bc2                     cmp       eax, edx
004fc2e8 740e                     je        0x4fc2f8
004fc2ea 6a3f                     push      0x3f
004fc2ec 53                       push      ebx
004fc2ed e8bead6100               call      0xb170b0
004fc2f2 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc2f8 8b4304                   mov       eax, dword ptr [ebx + 4]
004fc2fb 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fc2fe c1e002                   shl       eax, 2
004fc301 03d0                     add       edx, eax
004fc303 8bfa                     mov       edi, edx
004fc305 333ddc012101             xor       edi, dword ptr [0x12101dc]
004fc30b 333a                     xor       edi, dword ptr [edx]
004fc30d 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fc310 03c2                     add       eax, edx
004fc312 8b10                     mov       edx, dword ptr [eax]
004fc314 33d0                     xor       edx, eax
004fc316 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fc31c 3bfa                     cmp       edi, edx
004fc31e 740e                     je        0x4fc32e
004fc320 6a40                     push      0x40
004fc322 53                       push      ebx
004fc323 e888ad6100               call      0xb170b0
004fc328 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc32e 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fc334 8b5df8                   mov       ebx, dword ptr [ebp - 8]
004fc337 8b541804                 mov       edx, dword ptr [eax + ebx + 4]
004fc33b 03c3                     add       eax, ebx
004fc33d 3bfa                     cmp       edi, edx
004fc33f 0f85dd000000             jne       0x4fc422
004fc345 8b06                     mov       eax, dword ptr [esi]
004fc347 8bce                     mov       ecx, esi
004fc349 ff9030020000             call      dword ptr [eax + 0x230]
004fc34f 83f80e                   cmp       eax, 0xe
004fc352 0f84c4000000             je        0x4fc41c
004fc358 8b9ef8220000             mov       ebx, dword ptr [esi + 0x22f8]
004fc35e 8b55f8                   mov       edx, dword ptr [ebp - 8]
004fc361 8dbe68230000             lea       edi, [esi + 0x2368]
004fc367 8bcf                     mov       ecx, edi
004fc369 03da                     add       ebx, edx
004fc36b e890ab6000               call      0xb06f00
004fc370 3b4310                   cmp       eax, dword ptr [ebx + 0x10]
004fc373 0f8ea3000000             jle       0x4fc41c
004fc379 8a86f8230000             mov       al, byte ptr [esi + 0x23f8]
004fc37f 84c0                     test      al, al
004fc381 0f8495000000             je        0x4fc41c
004fc387 8b86f8220000             mov       eax, dword ptr [esi + 0x22f8]
004fc38d 8b5df8                   mov       ebx, dword ptr [ebp - 8]
004fc390 8b8e38230000             mov       ecx, dword ptr [esi + 0x2338]
004fc396 8b55fc                   mov       edx, dword ptr [ebp - 4]
004fc399 03c3                     add       eax, ebx
004fc39b 8b400c                   mov       eax, dword ptr [eax + 0xc]
004fc39e 8d0c91                   lea       ecx, [ecx + edx*4]
004fc3a1 8b09                     mov       ecx, dword ptr [ecx]
004fc3a3 50                       push      eax
004fc3a4 6a08                     push      8
004fc3a6 e825392500               call      0x74fcd0
004fc3ab 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc3b1 8b4244                   mov       eax, dword ptr [edx + 0x44]
004fc3b4 8b4f1c                   mov       ecx, dword ptr [edi + 0x1c]
004fc3b7 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc3bd 8d0488                   lea       eax, [eax + ecx*4]
004fc3c0 8bc8                     mov       ecx, eax
004fc3c2 33ca                     xor       ecx, edx
004fc3c4 8908                     mov       dword ptr [eax], ecx
004fc3c6 a1d8012101               mov       eax, dword ptr [0x12101d8]
004fc3cb 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004fc3ce 8b571c                   mov       edx, dword ptr [edi + 0x1c]
004fc3d1 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004fc3d7 8d0491                   lea       eax, [ecx + edx*4]
004fc3da 8bd0                     mov       edx, eax
004fc3dc 33d3                     xor       edx, ebx
004fc3de 8910                     mov       dword ptr [eax], edx
004fc3e0 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc3e6 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fc3e9 8b4724                   mov       eax, dword ptr [edi + 0x24]
004fc3ec 8d0482                   lea       eax, [edx + eax*4]
004fc3ef 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc3f5 8bc8                     mov       ecx, eax
004fc3f7 33ca                     xor       ecx, edx
004fc3f9 8908                     mov       dword ptr [eax], ecx
004fc3fb a1d8012101               mov       eax, dword ptr [0x12101d8]
004fc400 8b5724                   mov       edx, dword ptr [edi + 0x24]
004fc403 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004fc406 8d0491                   lea       eax, [ecx + edx*4]
004fc409 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004fc40f 8bd0                     mov       edx, eax
004fc411 33d1                     xor       edx, ecx
004fc413 8910                     mov       dword ptr [eax], edx
004fc415 c686f823000000           mov       byte ptr [esi + 0x23f8], 0
004fc41c 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc422 8b55fc                   mov       edx, dword ptr [ebp - 4]
004fc425 8b45f8                   mov       eax, dword ptr [ebp - 8]
004fc428 42                       inc       edx
004fc429 8955fc                   mov       dword ptr [ebp - 4], edx
004fc42c 83c024                   add       eax, 0x24
004fc42f e94dfbffff               jmp       0x4fbf81
004fc434 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc43a 8b865c150000             mov       eax, dword ptr [esi + 0x155c]
004fc440 8dbe5c150000             lea       edi, [esi + 0x155c]
004fc446 33c2                     xor       eax, edx
004fc448 8b5704                   mov       edx, dword ptr [edi + 4]
004fc44b 2bc7                     sub       eax, edi
004fc44d 3bc2                     cmp       eax, edx
004fc44f 740e                     je        0x4fc45f
004fc451 6a3f                     push      0x3f
004fc453 57                       push      edi
004fc454 e857ac6100               call      0xb170b0
004fc459 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc45f 8b4704                   mov       eax, dword ptr [edi + 4]
004fc462 8b5144                   mov       edx, dword ptr [ecx + 0x44]
004fc465 c1e002                   shl       eax, 2
004fc468 8b1c02                   mov       ebx, dword ptr [edx + eax]
004fc46b 03d0                     add       edx, eax
004fc46d 33da                     xor       ebx, edx
004fc46f 331ddc012101             xor       ebx, dword ptr [0x12101dc]
004fc475 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fc478 03c2                     add       eax, edx
004fc47a 8b10                     mov       edx, dword ptr [eax]
004fc47c 33d0                     xor       edx, eax
004fc47e 3315dc012101             xor       edx, dword ptr [0x12101dc]
004fc484 3bda                     cmp       ebx, edx
004fc486 7408                     je        0x4fc490
004fc488 6a40                     push      0x40
004fc48a 57                       push      edi
004fc48b e820ac6100               call      0xb170b0
004fc490 83fb08                   cmp       ebx, 8
004fc493 756a                     jne       0x4fc4ff
004fc495 33ff                     xor       edi, edi
004fc497 897df4                   mov       dword ptr [ebp - 0xc], edi
004fc49a 8d9b00000000             lea       ebx, [ebx]
004fc4a0 8b86e8220000             mov       eax, dword ptr [esi + 0x22e8]
004fc4a6 85c0                     test      eax, eax
004fc4a8 7455                     je        0x4fc4ff
004fc4aa 8b8eec220000             mov       ecx, dword ptr [esi + 0x22ec]
004fc4b0 2bc8                     sub       ecx, eax
004fc4b2 b867666666               mov       eax, 0x66666667
004fc4b7 f7e9                     imul      ecx
004fc4b9 c1fa04                   sar       edx, 4
004fc4bc 8bc2                     mov       eax, edx
004fc4be c1e81f                   shr       eax, 0x1f
004fc4c1 03c2                     add       eax, edx
004fc4c3 3bf8                     cmp       edi, eax
004fc4c5 7338                     jae       0x4fc4ff
004fc4c7 8b9ee8220000             mov       ebx, dword ptr [esi + 0x22e8]
004fc4cd 8b55f4                   mov       edx, dword ptr [ebp - 0xc]
004fc4d0 8d8e28180000             lea       ecx, [esi + 0x1828]
004fc4d6 03da                     add       ebx, edx
004fc4d8 e8835bf0ff               call      0x402060
004fc4dd 3b4304                   cmp       eax, dword ptr [ebx + 4]
004fc4e0 7511                     jne       0x4fc4f3
004fc4e2 8b8618230000             mov       eax, dword ptr [esi + 0x2318]
004fc4e8 8b0cb8                   mov       ecx, dword ptr [eax + edi*4]
004fc4eb 8d04b8                   lea       eax, [eax + edi*4]
004fc4ee e82d0c2500               call      0x74d120
004fc4f3 8b45f4                   mov       eax, dword ptr [ebp - 0xc]
004fc4f6 47                       inc       edi
004fc4f7 83c028                   add       eax, 0x28
004fc4fa 8945f4                   mov       dword ptr [ebp - 0xc], eax
004fc4fd eba1                     jmp       0x4fc4a0
004fc4ff 8bce                     mov       ecx, esi
004fc501 e8ca02fcff               call      0x4bc7d0
004fc506 8b86801b0000             mov       eax, dword ptr [esi + 0x1b80]
004fc50c 85c0                     test      eax, eax
004fc50e 0f850d010000             jne       0x4fc621
004fc514 8b16                     mov       edx, dword ptr [esi]
004fc516 8bce                     mov       ecx, esi
004fc518 ff5238                   call      dword ptr [edx + 0x38]
004fc51b 84c0                     test      al, al
004fc51d 0f85fe000000             jne       0x4fc621
004fc523 8b86301a0000             mov       eax, dword ptr [esi + 0x1a30]
004fc529 83f81b                   cmp       eax, 0x1b
004fc52c 0f859f000000             jne       0x4fc5d1
004fc532 8b06                     mov       eax, dword ptr [esi]
004fc534 8bce                     mov       ecx, esi
004fc536 ff9094000000             call      dword ptr [eax + 0x94]
004fc53c 3b86181d0000             cmp       eax, dword ptr [esi + 0x1d18]
004fc542 7516                     jne       0x4fc55a
004fc544 8b16                     mov       edx, dword ptr [esi]
004fc546 6a00                     push      0
004fc548 6a00                     push      0
004fc54a 6a00                     push      0
004fc54c 6a00                     push      0
004fc54e 6a00                     push      0
004fc550 6a00                     push      0
004fc552 8bce                     mov       ecx, esi
004fc554 ff9288040000             call      dword ptr [edx + 0x488]
004fc55a 8b06                     mov       eax, dword ptr [esi]
004fc55c 8bce                     mov       ecx, esi
004fc55e ff9098000000             call      dword ptr [eax + 0x98]
004fc564 3b861c1d0000             cmp       eax, dword ptr [esi + 0x1d1c]
004fc56a 7516                     jne       0x4fc582
004fc56c 8b16                     mov       edx, dword ptr [esi]
004fc56e 6a00                     push      0
004fc570 6a00                     push      0
004fc572 6a00                     push      0
004fc574 6a00                     push      0
004fc576 6a00                     push      0
004fc578 6a01                     push      1
004fc57a 8bce                     mov       ecx, esi
004fc57c ff9288040000             call      dword ptr [edx + 0x488]
004fc582 83be141d000001           cmp       dword ptr [esi + 0x1d14], 1
004fc589 0f859c000000             jne       0x4fc62b
004fc58f 8b06                     mov       eax, dword ptr [esi]
004fc591 8bce                     mov       ecx, esi
004fc593 ff9094000000             call      dword ptr [eax + 0x94]
004fc599 2b86181d0000             sub       eax, dword ptr [esi + 0x1d18]
004fc59f 99                       cdq       
004fc5a0 8bf8                     mov       edi, eax
004fc5a2 33fa                     xor       edi, edx
004fc5a4 2bfa                     sub       edi, edx
004fc5a6 8b16                     mov       edx, dword ptr [esi]
004fc5a8 8bce                     mov       ecx, esi
004fc5aa ff9298000000             call      dword ptr [edx + 0x98]
004fc5b0 2b861c1d0000             sub       eax, dword ptr [esi + 0x1d1c]
004fc5b6 99                       cdq       
004fc5b7 33c2                     xor       eax, edx
004fc5b9 2bc2                     sub       eax, edx
004fc5bb 85ff                     test      edi, edi
004fc5bd 756c                     jne       0x4fc62b
004fc5bf 85c0                     test      eax, eax
004fc5c1 7568                     jne       0x4fc62b
004fc5c3 8b06                     mov       eax, dword ptr [esi]
004fc5c5 6a0f                     push      0xf
004fc5c7 8bce                     mov       ecx, esi
004fc5c9 ff90f0050000             call      dword ptr [eax + 0x5f0]
004fc5cf eb5a                     jmp       0x4fc62b
004fc5d1 83f81c                   cmp       eax, 0x1c
004fc5d4 7555                     jne       0x4fc62b
004fc5d6 8bce                     mov       ecx, esi
004fc5d8 e88369ffff               call      0x4f2f60
004fc5dd 84c0                     test      al, al
004fc5df 7416                     je        0x4fc5f7
004fc5e1 8b16                     mov       edx, dword ptr [esi]
004fc5e3 6a00                     push      0
004fc5e5 6a00                     push      0
004fc5e7 6a00                     push      0
004fc5e9 6a00                     push      0
004fc5eb 6a00                     push      0
004fc5ed 6a00                     push      0
004fc5ef 8bce                     mov       ecx, esi
004fc5f1 ff9288040000             call      dword ptr [edx + 0x488]
004fc5f7 8bce                     mov       ecx, esi
004fc5f9 e8426affff               call      0x4f3040
004fc5fe 84c0                     test      al, al
004fc600 7416                     je        0x4fc618
004fc602 8b06                     mov       eax, dword ptr [esi]
004fc604 6a00                     push      0
004fc606 6a00                     push      0
004fc608 6a00                     push      0
004fc60a 6a00                     push      0
004fc60c 6a00                     push      0
004fc60e 6a01                     push      1
004fc610 8bce                     mov       ecx, esi
004fc612 ff9088040000             call      dword ptr [eax + 0x488]
004fc618 8bce                     mov       ecx, esi
004fc61a e8619bffff               call      0x4f6180
004fc61f eb0a                     jmp       0x4fc62b
004fc621 8b16                     mov       edx, dword ptr [esi]
004fc623 8bce                     mov       ecx, esi
004fc625 ff92a0060000             call      dword ptr [edx + 0x6a0]
004fc62b f686cc04000001           test      byte ptr [esi + 0x4cc], 1
004fc632 740a                     je        0x4fc63e
004fc634 8b06                     mov       eax, dword ptr [esi]
004fc636 8bce                     mov       ecx, esi
004fc638 ff907c060000             call      dword ptr [eax + 0x67c]
004fc63e 6aff                     push      -1
004fc640 6a00                     push      0
004fc642 6a00                     push      0
004fc644 6811010000               push      0x111
004fc649 8bce                     mov       ecx, esi
004fc64b e8b0e7ffff               call      0x4fae00
004fc650 85c0                     test      eax, eax
004fc652 7537                     jne       0x4fc68b
004fc654 80be4c20000001           cmp       byte ptr [esi + 0x204c], 1
004fc65b 7566                     jne       0x4fc6c3
004fc65d 6a00                     push      0
004fc65f c6864c20000000           mov       byte ptr [esi + 0x204c], 0
004fc666 e8851a3b00               call      0x8ae0f0
004fc66b 99                       cdq       
004fc66c b964000000               mov       ecx, 0x64
004fc671 f7f9                     idiv      ecx
004fc673 83c404                   add       esp, 4
004fc676 83fa0f                   cmp       edx, 0xf
004fc679 7d48                     jge       0x4fc6c3
004fc67b 8b16                     mov       edx, dword ptr [esi]
004fc67d 6aff                     push      -1
004fc67f 6a1a                     push      0x1a
004fc681 8bce                     mov       ecx, esi
004fc683 ff9244050000             call      dword ptr [edx + 0x544]
004fc689 eb38                     jmp       0x4fc6c3
004fc68b 7e36                     jle       0x4fc6c3
004fc68d 8a864c200000             mov       al, byte ptr [esi + 0x204c]
004fc693 84c0                     test      al, al
004fc695 752c                     jne       0x4fc6c3
004fc697 6a00                     push      0
004fc699 e8521a3b00               call      0x8ae0f0
004fc69e 99                       cdq       
004fc69f b964000000               mov       ecx, 0x64
004fc6a4 f7f9                     idiv      ecx
004fc6a6 83c404                   add       esp, 4
004fc6a9 83fa0f                   cmp       edx, 0xf
004fc6ac 7d0e                     jge       0x4fc6bc
004fc6ae 8b16                     mov       edx, dword ptr [esi]
004fc6b0 6aff                     push      -1
004fc6b2 6a19                     push      0x19
004fc6b4 8bce                     mov       ecx, esi
004fc6b6 ff9244050000             call      dword ptr [edx + 0x544]
004fc6bc c6864c20000001           mov       byte ptr [esi + 0x204c], 1
004fc6c3 8b8e84200000             mov       ecx, dword ptr [esi + 0x2084]
004fc6c9 85c9                     test      ecx, ecx
004fc6cb 7418                     je        0x4fc6e5
004fc6cd 8b01                     mov       eax, dword ptr [ecx]
004fc6cf ff90dc030000             call      dword ptr [eax + 0x3dc]
004fc6d5 84c0                     test      al, al
004fc6d7 740c                     je        0x4fc6e5
004fc6d9 8b16                     mov       edx, dword ptr [esi]
004fc6db 6a00                     push      0
004fc6dd 8bce                     mov       ecx, esi
004fc6df ff9254030000             call      dword ptr [edx + 0x354]
004fc6e5 8b868c200000             mov       eax, dword ptr [esi + 0x208c]
004fc6eb 85c0                     test      eax, eax
004fc6ed 0f8473000000             je        0x4fc766
004fc6f3 8b8e84200000             mov       ecx, dword ptr [esi + 0x2084]
004fc6f9 85c9                     test      ecx, ecx
004fc6fb 7569                     jne       0x4fc766
004fc6fd 8a4001                   mov       al, byte ptr [eax + 1]
004fc700 3c01                     cmp       al, 1
004fc702 751d                     jne       0x4fc721
004fc704 8b06                     mov       eax, dword ptr [esi]
004fc706 8bce                     mov       ecx, esi
004fc708 ff90c4010000             call      dword ptr [eax + 0x1c4]
004fc70e 83f865                   cmp       eax, 0x65
004fc711 7453                     je        0x4fc766
004fc713 8b16                     mov       edx, dword ptr [esi]
004fc715 6a65                     push      0x65
004fc717 8bce                     mov       ecx, esi
004fc719 ff92c0010000             call      dword ptr [edx + 0x1c0]
004fc71f eb45                     jmp       0x4fc766
004fc721 3c02                     cmp       al, 2
004fc723 7541                     jne       0x4fc766
004fc725 8d8e5c150000             lea       ecx, [esi + 0x155c]
004fc72b e83059f0ff               call      0x402060
004fc730 83f80d                   cmp       eax, 0xd
004fc733 7431                     je        0x4fc766
004fc735 8bce                     mov       ecx, esi
004fc737 e854f9f9ff               call      0x49c090
004fc73c 84c0                     test      al, al
004fc73e 7426                     je        0x4fc766
004fc740 8b8610250000             mov       eax, dword ptr [esi + 0x2510]
004fc746 85c0                     test      eax, eax
004fc748 7408                     je        0x4fc752
004fc74a 50                       push      eax
004fc74b 8bce                     mov       ecx, esi
004fc74d e86e95ffff               call      0x4f5cc0
004fc752 8b06                     mov       eax, dword ptr [esi]
004fc754 6a00                     push      0
004fc756 6a00                     push      0
004fc758 6a03                     push      3
004fc75a 6a00                     push      0
004fc75c 6a0d                     push      0xd
004fc75e 8bce                     mov       ecx, esi
004fc760 ff908c020000             call      dword ptr [eax + 0x28c]
004fc766 8bce                     mov       ecx, esi
004fc768 e823f9f9ff               call      0x49c090
004fc76d 84c0                     test      al, al
004fc76f 0f847e000000             je        0x4fc7f3
004fc775 8b16                     mov       edx, dword ptr [esi]
004fc777 8bce                     mov       ecx, esi
004fc779 ff9240060000             call      dword ptr [edx + 0x640]
004fc77f 85c0                     test      eax, eax
004fc781 7470                     je        0x4fc7f3
004fc783 8d8ea0000000             lea       ecx, [esi + 0xa0]
004fc789 e872a76000               call      0xb06f00
004fc78e 8bf8                     mov       edi, eax
004fc790 8b06                     mov       eax, dword ptr [esi]
004fc792 8bce                     mov       ecx, esi
004fc794 ff9040060000             call      dword ptr [eax + 0x640]
004fc79a 3bf8                     cmp       edi, eax
004fc79c 7c55                     jl        0x4fc7f3
004fc79e 8dbe5c150000             lea       edi, [esi + 0x155c]
004fc7a4 8bcf                     mov       ecx, edi
004fc7a6 e8b558f0ff               call      0x402060
004fc7ab 85c0                     test      eax, eax
004fc7ad 7430                     je        0x4fc7df
004fc7af 8bcf                     mov       ecx, edi
004fc7b1 e8aa58f0ff               call      0x402060
004fc7b6 83f801                   cmp       eax, 1
004fc7b9 7424                     je        0x4fc7df
004fc7bb 8bcf                     mov       ecx, edi
004fc7bd e89e58f0ff               call      0x402060
004fc7c2 83f802                   cmp       eax, 2
004fc7c5 7418                     je        0x4fc7df
004fc7c7 8bcf                     mov       ecx, edi
004fc7c9 e89258f0ff               call      0x402060
004fc7ce 83f803                   cmp       eax, 3
004fc7d1 740c                     je        0x4fc7df
004fc7d3 8bcf                     mov       ecx, edi
004fc7d5 e88658f0ff               call      0x402060
004fc7da 83f809                   cmp       eax, 9
004fc7dd 7514                     jne       0x4fc7f3
004fc7df 8b16                     mov       edx, dword ptr [esi]
004fc7e1 6a00                     push      0
004fc7e3 6a00                     push      0
004fc7e5 6a03                     push      3
004fc7e7 6a00                     push      0
004fc7e9 6a0d                     push      0xd
004fc7eb 8bce                     mov       ecx, esi
004fc7ed ff928c020000             call      dword ptr [edx + 0x28c]
004fc7f3 8b0d64310001             mov       ecx, dword ptr [0x1003164]
004fc7f9 8b01                     mov       eax, dword ptr [ecx]
004fc7fb ff909c000000             call      dword ptr [eax + 0x9c]
004fc801 3905d4f10401             cmp       dword ptr [0x104f1d4], eax
004fc807 7532                     jne       0x4fc83b
004fc809 8b86f0040000             mov       eax, dword ptr [esi + 0x4f0]
004fc80f 85c0                     test      eax, eax
004fc811 741e                     je        0x4fc831
004fc813 8d4e20                   lea       ecx, [esi + 0x20]
004fc816 e8e5a66000               call      0xb06f00
004fc81b 3b86b41d0000             cmp       eax, dword ptr [esi + 0x1db4]
004fc821 7c18                     jl        0x4fc83b
004fc823 8b16                     mov       edx, dword ptr [esi]
004fc825 8bce                     mov       ecx, esi
004fc827 ff9200060000             call      dword ptr [edx + 0x600]
004fc82d 84c0                     test      al, al
004fc82f 740a                     je        0x4fc83b
004fc831 8b06                     mov       eax, dword ptr [esi]
004fc833 8bce                     mov       ecx, esi
004fc835 ff9098060000             call      dword ptr [eax + 0x698]
004fc83b 8b16                     mov       edx, dword ptr [esi]
004fc83d 8bce                     mov       ecx, esi
004fc83f ff92dc030000             call      dword ptr [edx + 0x3dc]
004fc845 84c0                     test      al, al
004fc847 7549                     jne       0x4fc892
004fc849 8b06                     mov       eax, dword ptr [esi]
004fc84b 8bce                     mov       ecx, esi
004fc84d ff90f0040000             call      dword ptr [eax + 0x4f0]
004fc853 84c0                     test      al, al
004fc855 743b                     je        0x4fc892
004fc857 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc85d 8b4244                   mov       eax, dword ptr [edx + 0x44]
004fc860 8b8e64180000             mov       ecx, dword ptr [esi + 0x1864]
004fc866 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fc86c 8d0488                   lea       eax, [eax + ecx*4]
004fc86f 8bc8                     mov       ecx, eax
004fc871 33ca                     xor       ecx, edx
004fc873 8908                     mov       dword ptr [eax], ecx
004fc875 a1d8012101               mov       eax, dword ptr [0x12101d8]
004fc87a 8b9664180000             mov       edx, dword ptr [esi + 0x1864]
004fc880 8b4848                   mov       ecx, dword ptr [eax + 0x48]
004fc883 8d0491                   lea       eax, [ecx + edx*4]
004fc886 8b0ddc012101             mov       ecx, dword ptr [0x12101dc]
004fc88c 8bd0                     mov       edx, eax
004fc88e 33d1                     xor       edx, ecx
004fc890 8910                     mov       dword ptr [eax], edx
004fc892 8d8e5c150000             lea       ecx, [esi + 0x155c]
004fc898 e8c357f0ff               call      0x402060
004fc89d 83f80d                   cmp       eax, 0xd
004fc8a0 0f87c6040000             ja        0x4fcd6c
004fc8a6 0fb68084ce4f00           movzx     eax, byte ptr [eax + 0x4fce84]
004fc8ad ff248568ce4f00           jmp       dword ptr [eax*4 + 0x4fce68]
004fc8b4 8bce                     mov       ecx, esi
004fc8b6 e80566ffff               call      0x4f2ec0
004fc8bb 33ff                     xor       edi, edi
004fc8bd 33db                     xor       ebx, ebx
004fc8bf 90                       nop       
004fc8c0 8b8618220000             mov       eax, dword ptr [esi + 0x2218]
004fc8c6 85c0                     test      eax, eax
004fc8c8 0f849e040000             je        0x4fcd6c
004fc8ce 8b8e1c220000             mov       ecx, dword ptr [esi + 0x221c]
004fc8d4 2bc8                     sub       ecx, eax
004fc8d6 b889888888               mov       eax, 0x88888889
004fc8db f7e9                     imul      ecx
004fc8dd 03d1                     add       edx, ecx
004fc8df c1fa06                   sar       edx, 6
004fc8e2 8bc2                     mov       eax, edx
004fc8e4 c1e81f                   shr       eax, 0x1f
004fc8e7 03c2                     add       eax, edx
004fc8e9 3bf8                     cmp       edi, eax
004fc8eb 0f837b040000             jae       0x4fcd6c
004fc8f1 8b8e18220000             mov       ecx, dword ptr [esi + 0x2218]
004fc8f7 8b54194c                 mov       edx, dword ptr [ecx + ebx + 0x4c]
004fc8fb 8d0419                   lea       eax, [ecx + ebx]
004fc8fe 47                       inc       edi
004fc8ff 895058                   mov       dword ptr [eax + 0x58], edx
004fc902 83c378                   add       ebx, 0x78
004fc905 ebb9                     jmp       0x4fc8c0
004fc907 8b06                     mov       eax, dword ptr [esi]
004fc909 8bce                     mov       ecx, esi
004fc90b ff90f4000000             call      dword ptr [eax + 0xf4]
004fc911 85c0                     test      eax, eax
004fc913 0f8453040000             je        0x4fcd6c
004fc919 8b16                     mov       edx, dword ptr [esi]
004fc91b 8bce                     mov       ecx, esi
004fc91d ff92f4000000             call      dword ptr [edx + 0xf4]
004fc923 8a883a010000             mov       cl, byte ptr [eax + 0x13a]
004fc929 84c9                     test      cl, cl
004fc92b 0f843b040000             je        0x4fcd6c
004fc931 8bce                     mov       ecx, esi
004fc933 e858f7f9ff               call      0x49c090
004fc938 84c0                     test      al, al
004fc93a 0f842c040000             je        0x4fcd6c
004fc940 8b06                     mov       eax, dword ptr [esi]
004fc942 6a00                     push      0
004fc944 6a00                     push      0
004fc946 6a00                     push      0
004fc948 6a00                     push      0
004fc94a 6a00                     push      0
004fc94c 8bce                     mov       ecx, esi
004fc94e ff908c020000             call      dword ptr [eax + 0x28c]
004fc954 e913040000               jmp       0x4fcd6c
004fc959 6a00                     push      0
004fc95b 8bce                     mov       ecx, esi
004fc95d e8deb8ffff               call      0x4f8240
004fc962 8d8e28180000             lea       ecx, [esi + 0x1828]
004fc968 e8f356f0ff               call      0x402060
004fc96d 50                       push      eax
004fc96e 8bce                     mov       ecx, esi
004fc970 e82b94ffff               call      0x4f5da0
004fc975 8b16                     mov       edx, dword ptr [esi]
004fc977 8bce                     mov       ecx, esi
004fc979 ff92b4040000             call      dword ptr [edx + 0x4b4]
004fc97f 8bf8                     mov       edi, eax
004fc981 85ff                     test      edi, edi
004fc983 0f8ce3030000             jl        0x4fcd6c
004fc989 8b8658230000             mov       eax, dword ptr [esi + 0x2358]
004fc98f 8b0cb8                   mov       ecx, dword ptr [eax + edi*4]
004fc992 85c9                     test      ecx, ecx
004fc994 8d04b8                   lea       eax, [eax + edi*4]
004fc997 0f84cf030000             je        0x4fcd6c
004fc99d 8b8e08240000             mov       ecx, dword ptr [esi + 0x2408]
004fc9a3 33c0                     xor       eax, eax
004fc9a5 8bc7                     mov       eax, edi
004fc9a7 8bd0                     mov       edx, eax
004fc9a9 c1ea05                   shr       edx, 5
004fc9ac 83e01f                   and       eax, 0x1f
004fc9af 8d1491                   lea       edx, [ecx + edx*4]
004fc9b2 8bc8                     mov       ecx, eax
004fc9b4 8b02                     mov       eax, dword ptr [edx]
004fc9b6 bb01000000               mov       ebx, 1
004fc9bb d3e3                     shl       ebx, cl
004fc9bd 85d8                     test      eax, ebx
004fc9bf 0f85a7030000             jne       0x4fcd6c
004fc9c5 8b8e601d0000             mov       ecx, dword ptr [esi + 0x1d60]
004fc9cb 8b15d8012101             mov       edx, dword ptr [0x12101d8]
004fc9d1 8b5244                   mov       edx, dword ptr [edx + 0x44]
004fc9d4 8b1ddc012101             mov       ebx, dword ptr [0x12101dc]
004fc9da 8d047f                   lea       eax, [edi + edi*2]
004fc9dd c1e005                   shl       eax, 5
004fc9e0 03c1                     add       eax, ecx
004fc9e2 8b4804                   mov       ecx, dword ptr [eax + 4]
004fc9e5 8d0c8a                   lea       ecx, [edx + ecx*4]
004fc9e8 8bd1                     mov       edx, ecx
004fc9ea 33d3                     xor       edx, ebx
004fc9ec 8911                     mov       dword ptr [ecx], edx
004fc9ee 8b0dd8012101             mov       ecx, dword ptr [0x12101d8]
004fc9f4 8b5148                   mov       edx, dword ptr [ecx + 0x48]
004fc9f7 8b4004                   mov       eax, dword ptr [eax + 4]
004fc9fa 8d0482                   lea       eax, [edx + eax*4]
004fc9fd 8b15dc012101             mov       edx, dword ptr [0x12101dc]
004fca03 8bc8                     mov       ecx, eax
004fca05 33ca                     xor       ecx, edx
004fca07 8908                     mov       dword ptr [eax], ecx
004fca09 8b8eec230000             mov       ecx, dword ptr [esi + 0x23ec]
004fca0f 8bdf                     mov       ebx, edi
004fca11 c1e306                   shl       ebx, 6
004fca14 03cb                     add       ecx, ebx
004fca16 e8d584f0ff               call      0x404ef0
004fca1b 8b8eec230000             mov       ecx, dword ptr [esi + 0x23ec]
004fca21 6a00                     push      0
004fca23 03cb                     add       ecx, ebx
004fca25 6a00                     push      0
004fca27 e834a56000               call      0xb06f60
004fca2c 8b8e08240000             mov       ecx, dword ptr [esi + 0x2408]
004fca32 33c0                     xor       eax, eax
004fca34 8bc7                     mov       eax, edi
004fca36 8bd0                     mov       edx, eax
004fca38 c1ea05                   shr       edx, 5
004fca3b 83e01f                   and       eax, 0x1f
004fca3e 8d1491                   lea       edx, [ecx + edx*4]
004fca41 8bc8                     mov       ecx, eax
004fca43 8b02                     mov       eax, dword ptr [edx]
004fca45 bf01000000               mov       edi, 1
004fca4a d3e7                     shl       edi, cl
004fca4c 0bc7                     or        eax, edi
004fca4e 8902                     mov       dword ptr [edx], eax
004fca50 e917030000               jmp       0x4fcd6c
004fca55 8b06                     mov       eax, dword ptr [esi]
004fca57 8bce                     mov       ecx, esi
004fca59 ff909c000000             call      dword ptr [eax + 0x9c]
004fca5f 85c0                     test      eax, eax
004fca61 0f8505030000             jne       0x4fcd6c
004fca67 50                       push      eax
004fca68 50                       push      eax
004fca69 6a05                     push      5
004fca6b 8bce                     mov       ecx, esi
004fca6d e8fee25600               call      0xa6ad70
004fca72 e9f5020000               jmp       0x4fcd6c
004fca77 8bce                     mov       ecx, esi
004fca79 e812f6f9ff               call      0x49c090
004fca7e 84c0                     test      al, al
004fca80 741c                     je        0x4fca9e
004fca82 8d8e64150000             lea       ecx, [esi + 0x1564]
004fca88 e873a46000               call      0xb06f00
004fca8d 3d52030000               cmp       eax, 0x352
004fca92 7c0a                     jl        0x4fca9e
004fca94 8b16                     mov       edx, dword ptr [esi]
004fca96 8bce                     mov       ecx, esi
004fca98 ff9254060000             call      dword ptr [edx + 0x654]
004fca9e 8dbe64150000             lea       edi, [esi + 0x1564]
004fcaa4 8bcf                     mov       ecx, edi
004fcaa6 e855a46000               call      0xb06f00
004fcaab 3d2c010000               cmp       eax, 0x12c
004fcab0 0f8cb6020000             jl        0x4fcd6c
004fcab6 8bcf                     mov       ecx, edi
004fcab8 e843a46000               call      0xb06f00
004fcabd 6826020000               push      0x226
004fcac2 2d2c010000               sub       eax, 0x12c
004fcac7 50                       push      eax
004fcac8 6a00                     push      0
004fcaca 6800007f43               push      0x437f0000
004fcacf e8dcce6000               call      0xb099b0
004fcad4 83c410                   add       esp, 0x10
004fcad7 e8684a7000               call      0xc01544
004fcadc 0fb6c0                   movzx     eax, al
004fcadf c1e018                   shl       eax, 0x18
004fcae2 0dffffff00               or        eax, 0xffffff
004fcae7 25000000ff               and       eax, 0xff000000
004fcaec 3d000000ff               cmp       eax, 0xff000000
004fcaf1 750d                     jne       0x4fcb00
004fcaf3 50                       push      eax
004fcaf4 8bce                     mov       ecx, esi
004fcaf6 e865c3f9ff               call      0x498e60
004fcafb e96c020000               jmp       0x4fcd6c
004fcb00 8b8ec0010000             mov       ecx, dword ptr [esi + 0x1c0]
004fcb06 81e1ffffff00             and       ecx, 0xffffff
004fcb0c 0bc8                     or        ecx, eax
004fcb0e 8b86c4010000             mov       eax, dword ptr [esi + 0x1c4]
004fcb14 0d000000ff               or        eax, 0xff000000
004fcb19 898ec0010000             mov       dword ptr [esi + 0x1c0], ecx
004fcb1f 8986c4010000             mov       dword ptr [esi + 0x1c4], eax
004fcb25 e942020000               jmp       0x4fcd6c
004fcb2a 8b8604010000             mov       eax, dword ptr [esi + 0x104]
004fcb30 85c0                     test      eax, eax
004fcb32 0f840d020000             je        0x4fcd45
004fcb38 8b16                     mov       edx, dword ptr [esi]
004fcb3a 8bce                     mov       ecx, esi
004fcb3c ff92a0050000             call      dword ptr [edx + 0x5a0]
004fcb42 84c0                     test      al, al
004fcb44 0f8578010000             jne       0x4fccc2
004fcb4a a148280001               mov       eax, dword ptr [0x1002848]
004fcb4f 83b8a819000002           cmp       dword ptr [eax + 0x19a8], 2
004fcb56 0f85f3000000             jne       0x4fcc4f
004fcb5c 8d8eb8240000             lea       ecx, [esi + 0x24b8]
004fcb62 e899a36000               call      0xb06f00
004fcb67 83f819                   cmp       eax, 0x19
004fcb6a 0f8ed5010000             jle       0x4fcd45
004fcb70 8dbe64150000             lea       edi, [esi + 0x1564]
004fcb76 8bcf                     mov       ecx, edi
004fcb78 e883a36000               call      0xb06f00
004fcb7d 3b86181e0000             cmp       eax, dword ptr [esi + 0x1e18]
004fcb83 0f8fbc010000             jg        0x4fcd45
004fcb89 6a64                     push      0x64
004fcb8b 8bcf                     mov       ecx, edi
004fcb8d e86ea36000               call      0xb06f00
004fcb92 8b96181e0000             mov       edx, dword ptr [esi + 0x1e18]
004fcb98 b964000000               mov       ecx, 0x64
004fcb9d 2bca                     sub       ecx, edx
004fcb9f 03c1                     add       eax, ecx
004fcba1 50                       push      eax
004fcba2 686666863f               push      0x3f866666
004fcba7 680000803f               push      0x3f800000
004fcbac e8ffcd6000               call      0xb099b0
004fcbb1 d955f4                   fst       dword ptr [ebp - 0xc]
004fcbb4 d88ef8240000             fmul      dword ptr [esi + 0x24f8]
004fcbba 83c410                   add       esp, 0x10
004fcbbd d996f8240000             fst       dword ptr [esi + 0x24f8]
004fcbc3 d81d2809cd00             fcomp     dword ptr [0xcd0928]
004fcbc9 dfe0                     fnstsw    ax
004fcbcb f6c441                   test      ah, 0x41
004fcbce 7a35                     jp        0x4fcc05
004fcbd0 8b55f4                   mov       edx, dword ptr [ebp - 0xc]
004fcbd3 8b06                     mov       eax, dword ptr [esi]
004fcbd5 52                       push      edx
004fcbd6 8bce                     mov       ecx, esi
004fcbd8 ff90f4000000             call      dword ptr [eax + 0xf4]
004fcbde 8bc8                     mov       ecx, eax
004fcbe0 e8cbcb5200               call      0xa297b0
004fcbe5 8dbeec140000             lea       edi, [esi + 0x14ec]
004fcbeb bb17000000               mov       ebx, 0x17
004fcbf0 8b0f                     mov       ecx, dword ptr [edi]
004fcbf2 85c9                     test      ecx, ecx
004fcbf4 7409                     je        0x4fcbff
004fcbf6 8b55f4                   mov       edx, dword ptr [ebp - 0xc]
004fcbf9 52                       push      edx
004fcbfa e8f1abf5ff               call      0x4577f0
004fcbff 83c704                   add       edi, 4
004fcc02 4b                       dec       ebx
004fcc03 75eb                     jne       0x4fcbf0
004fcc05 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004fcc0b 6a00                     push      0
004fcc0d 6a00                     push      0
004fcc0f e82c440100               call      0x511040
004fcc14 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004fcc1a 6a00                     push      0
004fcc1c 6a01                     push      1
004fcc1e e81d440100               call      0x511040
004fcc23 8b8ef8000000             mov       ecx, dword ptr [esi + 0xf8]
004fcc29 6a00                     push      0
004fcc2b 6a02                     push      2
004fcc2d e80e440100               call      0x511040
004fcc32 8dbeb8240000             lea       edi, [esi + 0x24b8]
004fcc38 8bcf                     mov       ecx, edi
004fcc3a e8b182f0ff               call      0x404ef0
004fcc3f 6a00                     push      0
004fcc41 6a00                     push      0
004fcc43 8bcf                     mov       ecx, edi
004fcc45 e816a36000               call      0xb06f60
004fcc4a e9f6000000               jmp       0x4fcd45
004fcc4f 8d8e64150000             lea       ecx, [esi + 0x1564]
004fcc55 e8a6a26000               call      0xb06f00
004fcc5a 8bbe181e0000             mov       edi, dword ptr [esi + 0x1e18]
004fcc60 b964000000               mov       ecx, 0x64
004fcc65 2bcf                     sub       ecx, edi
004fcc67 6a64                     push      0x64
004fcc69 03c1                     add       eax, ecx
004fcc6b 50                       push      eax
004fcc6c 6a00                     push      0
004fcc6e 6800007f43               push      0x437f0000
004fcc73 e838cd6000               call      0xb099b0
004fcc78 83c410                   add       esp, 0x10
004fcc7b e8c4487000               call      0xc01544
004fcc80 0fb6c0                   movzx     eax, al
004fcc83 c1e018                   shl       eax, 0x18
004fcc86 0dffffff00               or        eax, 0xffffff
004fcc8b 25000000ff               and       eax, 0xff000000
004fcc90 3d000000ff               cmp       eax, 0xff000000
004fcc95 750d                     jne       0x4fcca4
004fcc97 50                       push      eax
004fcc98 8bce                     mov       ecx, esi
004fcc9a e8c1c1f9ff               call      0x498e60
004fcc9f e9a1000000               jmp       0x4fcd45
004fcca4 8b96c0010000             mov       edx, dword ptr [esi + 0x1c0]
004fccaa 81e2ffffff00             and       edx, 0xffffff
004fccb0 0bd0                     or        edx, eax
004fccb2 8b86c4010000             mov       eax, dword ptr [esi + 0x1c4]
004fccb8 0d000000ff               or        eax, 0xff000000
004fccbd e977000000               jmp       0x4fcd39
004fccc2 8d8e64150000             lea       ecx, [esi + 0x1564]
004fccc8 e833a26000               call      0xb06f00
004fcccd 8bbe181e0000             mov       edi, dword ptr [esi + 0x1e18]
004fccd3 b964000000               mov       ecx, 0x64
004fccd8 2bcf                     sub       ecx, edi
004fccda 6a64                     push      0x64
004fccdc 03c1                     add       eax, ecx
004fccde 50                       push      eax
004fccdf 680000c842               push      0x42c80000
004fcce4 6800007f43               push      0x437f0000
004fcce9 e8c2cc6000               call      0xb099b0
004fccee 83c410                   add       esp, 0x10
004fccf1 e84e487000               call      0xc01544
004fccf6 0fb6c8                   movzx     ecx, al
004fccf9 8bc1                     mov       eax, ecx
004fccfb 0d00ffffff               or        eax, 0xffffff00
004fcd00 c1e008                   shl       eax, 8
004fcd03 0bc1                     or        eax, ecx
004fcd05 c1e008                   shl       eax, 8
004fcd08 0bc1                     or        eax, ecx
004fcd0a 25ffffff00               and       eax, 0xffffff
004fcd0f 3dffffff00               cmp       eax, 0xffffff
004fcd14 750a                     jne       0x4fcd20
004fcd16 50                       push      eax
004fcd17 8bce                     mov       ecx, esi
004fcd19 e842c1f9ff               call      0x498e60
004fcd1e eb25                     jmp       0x4fcd45
004fcd20 8b96c0010000             mov       edx, dword ptr [esi + 0x1c0]
004fcd26 81e2000000ff             and       edx, 0xff000000
004fcd2c 0bd0                     or        edx, eax
004fcd2e 8b86c4010000             mov       eax, dword ptr [esi + 0x1c4]
004fcd34 0dffffff00               or        eax, 0xffffff
004fcd39 8996c0010000             mov       dword ptr [esi + 0x1c0], edx
004fcd3f 8986c4010000             mov       dword ptr [esi + 0x1c4], eax
004fcd45 8d8e64150000             lea       ecx, [esi + 0x1564]
004fcd4b e8b0a16000               call      0xb06f00
004fcd50 3b86181e0000             cmp       eax, dword ptr [esi + 0x1e18]
004fcd56 7c14                     jl        0x4fcd6c
004fcd58 8a86e8010000             mov       al, byte ptr [esi + 0x1e8]
004fcd5e 84c0                     test      al, al
004fcd60 750a                     jne       0x4fcd6c
004fcd62 8b06                     mov       eax, dword ptr [esi]
004fcd64 8bce                     mov       ecx, esi
004fcd66 ff9054060000             call      dword ptr [eax + 0x654]
004fcd6c 33db                     xor       ebx, ebx
004fcd6e 895df4                   mov       dword ptr [ebp - 0xc], ebx
004fcd71 8b865c220000             mov       eax, dword ptr [esi + 0x225c]
004fcd77 85c0                     test      eax, eax
004fcd79 0f848e000000             je        0x4fce0d
004fcd7f 8b8e60220000             mov       ecx, dword ptr [esi + 0x2260]
004fcd85 2bc8                     sub       ecx, eax
004fcd87 b867666666               mov       eax, 0x66666667
004fcd8c f7e9                     imul      ecx
004fcd8e 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004fcd91 c1fa03                   sar       edx, 3
004fcd94 8bc2                     mov       eax, edx
004fcd96 c1e81f                   shr       eax, 0x1f
004fcd99 03c2                     add       eax, edx
004fcd9b 3bc8                     cmp       ecx, eax
004fcd9d 736e                     jae       0x4fce0d
004fcd9f 8b8e5c220000             mov       ecx, dword ptr [esi + 0x225c]
004fcda5 8b441910                 mov       eax, dword ptr [ecx + ebx + 0x10]
004fcda9 03cb                     add       ecx, ebx
004fcdab 85c0                     test      eax, eax
004fcdad 7e4f                     jle       0x4fcdfe
004fcdaf b864000000               mov       eax, 0x64
004fcdb4 99                       cdq       
004fcdb5 f77910                   idiv      dword ptr [ecx + 0x10]
004fcdb8 8bf8                     mov       edi, eax
004fcdba 85ff                     test      edi, edi
004fcdbc 7e44                     jle       0x4fce02
004fcdbe 8b16                     mov       edx, dword ptr [esi]
004fcdc0 8bce                     mov       ecx, esi
004fcdc2 ff9238020000             call      dword ptr [edx + 0x238]
004fcdc8 99                       cdq       
004fcdc9 f7ff                     idiv      edi
004fcdcb 8bce                     mov       ecx, esi
004fcdcd 8bf8                     mov       edi, eax
004fcdcf 8b06                     mov       eax, dword ptr [esi]
004fcdd1 ff9034020000             call      dword ptr [eax + 0x234]
004fcdd7 3bc7                     cmp       eax, edi
004fcdd9 7d27                     jge       0x4fce02
004fcddb 8b8e5c220000             mov       ecx, dword ptr [esi + 0x225c]
004fcde1 8d040b                   lea       eax, [ebx + ecx]
004fcde4 8a480c                   mov       cl, byte ptr [eax + 0xc]
004fcde7 84c9                     test      cl, cl
004fcde9 7517                     jne       0x4fce02
004fcdeb 8b4df4                   mov       ecx, dword ptr [ebp - 0xc]
004fcdee 41                       inc       ecx
004fcdef c6400c01                 mov       byte ptr [eax + 0xc], 1
004fcdf3 894df4                   mov       dword ptr [ebp - 0xc], ecx
004fcdf6 83c314                   add       ebx, 0x14
004fcdf9 e973ffffff               jmp       0x4fcd71
004fcdfe c6410c01                 mov       byte ptr [ecx + 0xc], 1
004fce02 ff45f4                   inc       dword ptr [ebp - 0xc]
004fce05 83c314                   add       ebx, 0x14
004fce08 e964ffffff               jmp       0x4fcd71
004fce0d 8b16                     mov       edx, dword ptr [esi]
004fce0f 8bce                     mov       ecx, esi
004fce11 ff9258030000             call      dword ptr [edx + 0x358]
004fce17 85c0                     test      eax, eax
004fce19 5b                       pop       ebx
004fce1a 7444                     je        0x4fce60
004fce1c 8b06                     mov       eax, dword ptr [esi]
004fce1e 8bce                     mov       ecx, esi
004fce20 ff9058030000             call      dword ptr [eax + 0x358]
004fce26 3b05d4f10401             cmp       eax, dword ptr [0x104f1d4]
004fce2c 7432                     je        0x4fce60
004fce2e 8b16                     mov       edx, dword ptr [esi]
004fce30 8bce                     mov       ecx, esi
004fce32 ff9258030000             call      dword ptr [edx + 0x358]
004fce38 8b10                     mov       edx, dword ptr [eax]
004fce3a 6811010000               push      0x111
004fce3f 8bc8                     mov       ecx, eax
004fce41 ff522c                   call      dword ptr [edx + 0x2c]
004fce44 84c0                     test      al, al
004fce46 7418                     je        0x4fce60
004fce48 8b86c4010000             mov       eax, dword ptr [esi + 0x1c4]
004fce4e 0d000000ff               or        eax, 0xff000000
004fce53 c686c301000080           mov       byte ptr [esi + 0x1c3], 0x80
004fce5a 8986c4010000             mov       dword ptr [esi + 0x1c4], eax
004fce60 5f                       pop       edi
004fce61 5e                       pop       esi
004fce62 8be5                     mov       esp, ebp
004fce64 5d                       pop       ebp
004fce65 c3                       ret       
004fce66 8bff                     mov       edi, edi
004fce68 b4c8                     mov       ah, 0xc8
004fce6a 4f                       dec       edi
004fce6b 002a                     add       byte ptr [edx], ch
004fce6d cb                       retf      
004fce6e 4f                       dec       edi
004fce6f 0059c9                   add       byte ptr [ecx - 0x37], bl
004fce72 4f                       dec       edi
004fce73 0007                     add       byte ptr [edi], al
004fce75 c9                       leave     
004fce76 4f                       dec       edi
004fce77 0055ca                   add       byte ptr [ebp - 0x36], dl
004fce7a 4f                       dec       edi
004fce7b 0077ca                   add       byte ptr [edi - 0x36], dh
004fce7e 4f                       dec       edi
004fce7f 006ccd4f                 add       byte ptr [ebp + ecx*8 + 0x4f], ch
004fce83 0000                     add       byte ptr [eax], al
004fce85 06                       push      es
004fce86 06                       push      es
004fce87 06                       push      es
004fce88 06                       push      es
004fce89 0106                     add       dword ptr [esi], eax
004fce8b 06                       push      es
004fce8c 0206                     add       al, byte ptr [esi]
004fce8e 030406                   add       eax, dword ptr [esi + eax]
004fce91 05cccccccc               add       eax, 0xcccccccc
004fce96 cc                       int3      
004fce97 cc                       int3      
004fce98 cc                       int3      
004fce99 cc                       int3      
004fce9a cc                       int3      
004fce9b cc                       int3      
004fce9c cc                       int3      
004fce9d cc                       int3      
004fce9e cc                       int3      
004fce9f cc                       int3      
004fcea0 55                       push      ebp
004fcea1 8bec                     mov       ebp, esp
004fcea3 83ec2c                   sub       esp, 0x2c
004fcea6 57                       push      edi
004fcea7 8bf9                     mov       edi, ecx
004fcea9 8b8f28020000             mov       ecx, dword ptr [edi + 0x228]
004fceaf 8b8724020000             mov       eax, dword ptr [edi + 0x224]
004fceb5 3bc1                     cmp       eax, ecx
004fceb7 741b                     je        0x4fced4
004fceb9 8d                       .byte     0x8d
