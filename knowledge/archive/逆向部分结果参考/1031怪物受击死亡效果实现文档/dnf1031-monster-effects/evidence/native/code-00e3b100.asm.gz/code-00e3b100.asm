
D:\game\DNF1031客户端-20260708\combat_ui_1031\reports\code-00e3b100.elf:	file format elf32-i386

Disassembly of section .text:

00e3b100 <.text>:
  e3b100: 56                           	push	esi
  e3b101: 8b f1                        	mov	esi, ecx
  e3b103: 8b 8e 1c 02 00 00            	mov	ecx, dword ptr [esi + 0x21c]
  e3b109: 57                           	push	edi
  e3b10a: 85 c9                        	test	ecx, ecx
  e3b10c: 74 08                        	je	0xe3b116 <.text+0x16>
  e3b10e: 8b 01                        	mov	eax, dword ptr [ecx]
  e3b110: 8b 10                        	mov	edx, dword ptr [eax]
  e3b112: 6a 01                        	push	0x1
  e3b114: ff d2                        	call	edx
  e3b116: c7 86 1c 02 00 00 00 00 00 00	mov	dword ptr [esi + 0x21c], 0x0
  e3b120: 81 c6 20 02 00 00            	add	esi, 0x220
  e3b126: bf 02 00 00 00               	mov	edi, 0x2
  e3b12b: eb 03                        	jmp	0xe3b130 <.text+0x30>
  e3b12d: 8d 49 00                     	lea	ecx, [ecx]
  e3b130: 8b 0e                        	mov	ecx, dword ptr [esi]
  e3b132: 85 c9                        	test	ecx, ecx
  e3b134: 74 08                        	je	0xe3b13e <.text+0x3e>
  e3b136: 8b 01                        	mov	eax, dword ptr [ecx]
  e3b138: 8b 10                        	mov	edx, dword ptr [eax]
  e3b13a: 6a 01                        	push	0x1
  e3b13c: ff d2                        	call	edx
  e3b13e: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  e3b144: 83 c6 04                     	add	esi, 0x4
  e3b147: 4f                           	dec	edi
  e3b148: 75 e6                        	jne	0xe3b130 <.text+0x30>
  e3b14a: 5f                           	pop	edi
  e3b14b: 5e                           	pop	esi
  e3b14c: c3                           	ret
  e3b14d: cc                           	int3
  e3b14e: cc                           	int3
  e3b14f: cc                           	int3
  e3b150: 55                           	push	ebp
  e3b151: 8b ec                        	mov	ebp, esp
  e3b153: 6a ff                        	push	-0x1
  e3b155: 68 63 9d 49 01               	push	0x1499d63
  e3b15a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  e3b160: 50                           	push	eax
  e3b161: 81 ec b0 02 00 00            	sub	esp, 0x2b0
  e3b167: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  e3b16c: 33 c5                        	xor	eax, ebp
  e3b16e: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  e3b171: 53                           	push	ebx
  e3b172: 56                           	push	esi
  e3b173: 57                           	push	edi
  e3b174: 50                           	push	eax
  e3b175: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  e3b178: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  e3b17e: 33 db                        	xor	ebx, ebx
  e3b180: f6 05 50 a8 ad 01 01         	test	byte ptr [0x1ada850], 0x1
  e3b187: 8b f1                        	mov	esi, ecx
  e3b189: 0f 85 89 00 00 00            	jne	0xe3b218 <.text+0x118>
  e3b18f: 83 0d 50 a8 ad 01 01         	or	dword ptr [0x1ada850], 0x1
  e3b196: 68 50 87 7d 01               	push	0x17d8750
  e3b19b: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  e3b19e: e8 4d 4d 36 00               	call	0x119fef0 <.text+0x364df0>
  e3b1a3: 83 c4 04                     	add	esp, 0x4
  e3b1a6: 50                           	push	eax
  e3b1a7: 8d 8d d0 fd ff ff            	lea	ecx, [ebp - 0x230]
  e3b1ad: e8 6e 6d 5d ff               	call	0x411f20
  e3b1b2: 8d 85 d0 fd ff ff            	lea	eax, [ebp - 0x230]
  e3b1b8: 50                           	push	eax
  e3b1b9: b9 08 a8 ad 01               	mov	ecx, 0x1ada808
  e3b1be: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  e3b1c2: e8 39 1f 35 00               	call	0x118d100 <.text+0x352000>
  e3b1c7: 83 bd e8 fd ff ff 08         	cmp	dword ptr [ebp - 0x218], 0x8
  e3b1ce: 72 0f                        	jb	0xe3b1df <.text+0xdf>
  e3b1d0: 8b 8d d4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x22c]
  e3b1d6: 51                           	push	ecx
  e3b1d7: e8 4b a9 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3b1dc: 83 c4 04                     	add	esp, 0x4
  e3b1df: 8b 85 d0 fd ff ff            	mov	eax, dword ptr [ebp - 0x230]
  e3b1e5: 33 d2                        	xor	edx, edx
  e3b1e7: 50                           	push	eax
  e3b1e8: c7 85 e8 fd ff ff 07 00 00 00	mov	dword ptr [ebp - 0x218], 0x7
  e3b1f2: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3b1f8: 66 89 95 d4 fd ff ff         	mov	word ptr [ebp - 0x22c], dx
  e3b1ff: e8 23 a9 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3b204: 68 60 e0 54 01               	push	0x154e060
  e3b209: e8 fc c0 59 00               	call	0x13d730a <.text+0x59c20a>
  e3b20e: 83 c4 08                     	add	esp, 0x8
  e3b211: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  e3b218: 68 08 a8 ad 01               	push	0x1ada808
  e3b21d: 8d 8d 44 fd ff ff            	lea	ecx, [ebp - 0x2bc]
  e3b223: e8 38 31 35 00               	call	0x118e360 <.text+0x353260>
  e3b228: 8b ce                        	mov	ecx, esi
  e3b22a: c7 45 fc 02 00 00 00         	mov	dword ptr [ebp - 0x4], 0x2
  e3b231: e8 6a 2c 9c ff               	call	0x7fdea0
  e3b236: 80 be 18 02 00 00 00         	cmp	byte ptr [esi + 0x218], 0x0
  e3b23d: 0f 85 ce 08 00 00            	jne	0xe3bb11 <.text+0xa11>
  e3b243: 8d 4e 70                     	lea	ecx, [esi + 0x70]
  e3b246: e8 f5 f3 37 00               	call	0x11ba640 <.text+0x37f540>
  e3b24b: 3b 86 14 02 00 00            	cmp	eax, dword ptr [esi + 0x214]
  e3b251: 0f 8c ba 08 00 00            	jl	0xe3bb11 <.text+0xa11>
  e3b257: 8b 16                        	mov	edx, dword ptr [esi]
  e3b259: 8b 82 a4 00 00 00            	mov	eax, dword ptr [edx + 0xa4]
  e3b25f: 8b ce                        	mov	ecx, esi
  e3b261: ff d0                        	call	eax
  e3b263: 8b 16                        	mov	edx, dword ptr [esi]
  e3b265: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3b26b: 8b 82 a8 00 00 00            	mov	eax, dword ptr [edx + 0xa8]
  e3b271: 8b ce                        	mov	ecx, esi
  e3b273: ff d0                        	call	eax
  e3b275: 8b 16                        	mov	edx, dword ptr [esi]
  e3b277: 89 85 c8 fd ff ff            	mov	dword ptr [ebp - 0x238], eax
  e3b27d: 8b 82 ac 00 00 00            	mov	eax, dword ptr [edx + 0xac]
  e3b283: 8b ce                        	mov	ecx, esi
  e3b285: ff d0                        	call	eax
  e3b287: 6a 08                        	push	0x8
  e3b289: 89 85 bc fd ff ff            	mov	dword ptr [ebp - 0x244], eax
  e3b28f: 89 9d dc fd ff ff            	mov	dword ptr [ebp - 0x224], ebx
  e3b295: e8 80 b8 59 00               	call	0x13d6b1a <.text+0x59ba1a>
  e3b29a: 83 c4 04                     	add	esp, 0x4
  e3b29d: 3b c3                        	cmp	eax, ebx
  e3b29f: 0f 84 6b 0a 00 00            	je	0xe3bd10 <.text+0xc10>
  e3b2a5: 89 85 dc fd ff ff            	mov	dword ptr [ebp - 0x224], eax
  e3b2ab: 33 c9                        	xor	ecx, ecx
  e3b2ad: 89 08                        	mov	dword ptr [eax], ecx
  e3b2af: 33 d2                        	xor	edx, edx
  e3b2b1: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  e3b2b4: 8b 95 dc fd ff ff            	mov	edx, dword ptr [ebp - 0x224]
  e3b2ba: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3b2c0: 89 0a                        	mov	dword ptr [edx], ecx
  e3b2c2: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3b2c8: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3b2ce: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3b2d4: f6 86 2c 02 00 00 08         	test	byte ptr [esi + 0x22c], 0x8
  e3b2db: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  e3b2df: 89 9d a4 fd ff ff            	mov	dword ptr [ebp - 0x25c], ebx
  e3b2e5: 89 9d a8 fd ff ff            	mov	dword ptr [ebp - 0x258], ebx
  e3b2eb: 89 9d ac fd ff ff            	mov	dword ptr [ebp - 0x254], ebx
  e3b2f1: 0f 84 bc 00 00 00            	je	0xe3b3b3 <.text+0x2b3>
  e3b2f7: 68 fc 01 00 00               	push	0x1fc
  e3b2fc: e8 7f 50 37 00               	call	0x11b0380 <.text+0x375280>
  e3b301: 8b f8                        	mov	edi, eax
  e3b303: 83 c4 04                     	add	esp, 0x4
  e3b306: 89 bd b0 fd ff ff            	mov	dword ptr [ebp - 0x250], edi
  e3b30c: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  e3b310: 3b fb                        	cmp	edi, ebx
  e3b312: 74 1d                        	je	0xe3b331 <.text+0x231>
  e3b314: 6a 00                        	push	0x0
  e3b316: 6a 01                        	push	0x1
  e3b318: 68 e8 86 7d 01               	push	0x17d86e8
  e3b31d: e8 ce 4b 36 00               	call	0x119fef0 <.text+0x364df0>
  e3b322: 83 c4 04                     	add	esp, 0x4
  e3b325: 50                           	push	eax
  e3b326: 8b cf                        	mov	ecx, edi
  e3b328: e8 b3 f1 25 00               	call	0x109a4e0 <.text+0x25f3e0>
  e3b32d: 8b d8                        	mov	ebx, eax
  e3b32f: eb 02                        	jmp	0xe3b333 <.text+0x233>
  e3b331: 33 db                        	xor	ebx, ebx
  e3b333: 68 0c 02 00 00               	push	0x20c
  e3b338: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  e3b33c: e8 3f 50 37 00               	call	0x11b0380 <.text+0x375280>
  e3b341: 8b f8                        	mov	edi, eax
  e3b343: 83 c4 04                     	add	esp, 0x4
  e3b346: 89 bd b0 fd ff ff            	mov	dword ptr [ebp - 0x250], edi
  e3b34c: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
  e3b350: 85 ff                        	test	edi, edi
  e3b352: 74 22                        	je	0xe3b376 <.text+0x276>
  e3b354: 6a 00                        	push	0x0
  e3b356: 6a 01                        	push	0x1
  e3b358: 53                           	push	ebx
  e3b359: 8b cf                        	mov	ecx, edi
  e3b35b: e8 70 ac 5c ff               	call	0x405fd0
  e3b360: c7 07 04 29 56 01            	mov	dword ptr [edi], 0x1562904
  e3b366: c7 47 08 b4 28 56 01         	mov	dword ptr [edi + 0x8], 0x15628b4
  e3b36d: c6 87 08 02 00 00 00         	mov	byte ptr [edi + 0x208], 0x0
  e3b374: eb 02                        	jmp	0xe3b378 <.text+0x278>
  e3b376: 33 ff                        	xor	edi, edi
  e3b378: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3b37e: 6a 00                        	push	0x0
  e3b380: 6a 00                        	push	0x0
  e3b382: 56                           	push	esi
  e3b383: 57                           	push	edi
  e3b384: 6a 00                        	push	0x0
  e3b386: 6a 02                        	push	0x2
  e3b388: 56                           	push	esi
  e3b389: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  e3b38d: e8 4e 36 a7 ff               	call	0x8ae9e0
  e3b392: 8b 8d bc fd ff ff            	mov	ecx, dword ptr [ebp - 0x244]
  e3b398: 8b 95 c8 fd ff ff            	mov	edx, dword ptr [ebp - 0x238]
  e3b39e: 8b 07                        	mov	eax, dword ptr [edi]
  e3b3a0: 51                           	push	ecx
  e3b3a1: 8b 8d cc fd ff ff            	mov	ecx, dword ptr [ebp - 0x234]
  e3b3a7: 52                           	push	edx
  e3b3a8: 8b 90 98 00 00 00            	mov	edx, dword ptr [eax + 0x98]
  e3b3ae: 51                           	push	ecx
  e3b3af: 8b cf                        	mov	ecx, edi
  e3b3b1: ff d2                        	call	edx
  e3b3b3: f6 86 2c 02 00 00 02         	test	byte ptr [esi + 0x22c], 0x2
  e3b3ba: 0f 84 49 02 00 00            	je	0xe3b609 <.text+0x509>
  e3b3c0: 8b 3d 78 f4 a6 01            	mov	edi, dword ptr [0x1a6f478]
  e3b3c6: 8b 07                        	mov	eax, dword ptr [edi]
  e3b3c8: 8b 50 1c                     	mov	edx, dword ptr [eax + 0x1c]
  e3b3cb: 8b cf                        	mov	ecx, edi
  e3b3cd: ff d2                        	call	edx
  e3b3cf: 8b 07                        	mov	eax, dword ptr [edi]
  e3b3d1: 8b 50 24                     	mov	edx, dword ptr [eax + 0x24]
  e3b3d4: 8b cf                        	mov	ecx, edi
  e3b3d6: ff d2                        	call	edx
  e3b3d8: 8b d8                        	mov	ebx, eax
  e3b3da: 8b 86 0c 02 00 00            	mov	eax, dword ptr [esi + 0x20c]
  e3b3e0: 68 e0 22 02 00               	push	0x222e0
  e3b3e5: 2d 30 75 00 00               	sub	eax, 0x7530
  e3b3ea: 50                           	push	eax
  e3b3eb: 6a 14                        	push	0x14
  e3b3ed: 6a 08                        	push	0x8
  e3b3ef: e8 cc e4 37 00               	call	0x11b98c0 <.text+0x37e7c0>
  e3b3f4: 8d 4b 04                     	lea	ecx, [ebx + 0x4]
  e3b3f7: 83 c4 10                     	add	esp, 0x10
  e3b3fa: 8d 51 08                     	lea	edx, [ecx + 0x8]
  e3b3fd: 89 85 c4 fd ff ff            	mov	dword ptr [ebp - 0x23c], eax
  e3b403: 52                           	push	edx
  e3b404: 8d 85 c4 fd ff ff            	lea	eax, [ebp - 0x23c]
  e3b40a: 50                           	push	eax
  e3b40b: e8 20 55 36 00               	call	0x11a0930 <.text+0x365830>
  e3b410: 8b 8e 0c 02 00 00            	mov	ecx, dword ptr [esi + 0x20c]
  e3b416: 68 e0 22 02 00               	push	0x222e0
  e3b41b: 81 e9 30 75 00 00            	sub	ecx, 0x7530
  e3b421: 51                           	push	ecx
  e3b422: 68 96 00 00 00               	push	0x96
  e3b427: 6a 32                        	push	0x32
  e3b429: e8 92 e4 37 00               	call	0x11b98c0 <.text+0x37e7c0>
  e3b42e: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
  e3b436: 8d 14 00                     	lea	edx, [eax + eax]
  e3b439: 89 43 14                     	mov	dword ptr [ebx + 0x14], eax
  e3b43c: 89 43 1c                     	mov	dword ptr [ebx + 0x1c], eax
  e3b43f: 83 c4 10                     	add	esp, 0x10
  e3b442: 89 53 18                     	mov	dword ptr [ebx + 0x18], edx
  e3b445: 8b 86 0c 02 00 00            	mov	eax, dword ptr [esi + 0x20c]
  e3b44b: 68 e0 22 02 00               	push	0x222e0
  e3b450: 2d 30 75 00 00               	sub	eax, 0x7530
  e3b455: 50                           	push	eax
  e3b456: 83 ec 08                     	sub	esp, 0x8
  e3b459: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
  e3b45f: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
  e3b464: e8 37 f3 41 00               	call	0x125a7a0 <.text+0x41f6a0>
  e3b469: d9 9d c4 fd ff ff            	fstp	dword ptr [ebp - 0x23c]
  e3b46f: 8b 17                        	mov	edx, dword ptr [edi]
  e3b471: 8b 42 0c                     	mov	eax, dword ptr [edx + 0xc]
  e3b474: 83 c4 10                     	add	esp, 0x10
  e3b477: 6a 00                        	push	0x0
  e3b479: 8b cf                        	mov	ecx, edi
  e3b47b: ff d0                        	call	eax
  e3b47d: 8b 85 bc fd ff ff            	mov	eax, dword ptr [ebp - 0x244]
  e3b483: 8b 8d c8 fd ff ff            	mov	ecx, dword ptr [ebp - 0x238]
  e3b489: 8b 17                        	mov	edx, dword ptr [edi]
  e3b48b: 8b 52 28                     	mov	edx, dword ptr [edx + 0x28]
  e3b48e: 50                           	push	eax
  e3b48f: 8b 85 cc fd ff ff            	mov	eax, dword ptr [ebp - 0x234]
  e3b495: 51                           	push	ecx
  e3b496: 50                           	push	eax
  e3b497: 8b cf                        	mov	ecx, edi
  e3b499: ff d2                        	call	edx
  e3b49b: 8b 07                        	mov	eax, dword ptr [edi]
  e3b49d: 8b 50 60                     	mov	edx, dword ptr [eax + 0x60]
  e3b4a0: 8d 8d 90 fd ff ff            	lea	ecx, [ebp - 0x270]
  e3b4a6: 51                           	push	ecx
  e3b4a7: 8b cf                        	mov	ecx, edi
  e3b4a9: ff d2                        	call	edx
  e3b4ab: 8b f8                        	mov	edi, eax
  e3b4ad: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3b4b3: 33 db                        	xor	ebx, ebx
  e3b4b5: 3b c7                        	cmp	eax, edi
  e3b4b7: 74 73                        	je	0xe3b52c <.text+0x42c>
  e3b4b9: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3b4bf: 3b c3                        	cmp	eax, ebx
  e3b4c1: 74 09                        	je	0xe3b4cc <.text+0x3cc>
  e3b4c3: 50                           	push	eax
  e3b4c4: e8 5e a6 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3b4c9: 83 c4 04                     	add	esp, 0x4
  e3b4cc: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3b4d2: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3b4d8: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3b4de: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3b4e4: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3b4e6: 89 8d dc fd ff ff            	mov	dword ptr [ebp - 0x224], ecx
  e3b4ec: 89 07                        	mov	dword ptr [edi], eax
  e3b4ee: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3b4f4: 3b c3                        	cmp	eax, ebx
  e3b4f6: 74 08                        	je	0xe3b500 <.text+0x400>
  e3b4f8: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
  e3b4fe: 89 10                        	mov	dword ptr [eax], edx
  e3b500: 8b 07                        	mov	eax, dword ptr [edi]
  e3b502: 3b c3                        	cmp	eax, ebx
  e3b504: 74 02                        	je	0xe3b508 <.text+0x408>
  e3b506: 89 38                        	mov	dword ptr [eax], edi
  e3b508: 8b 47 04                     	mov	eax, dword ptr [edi + 0x4]
  e3b50b: 89 85 e0 fd ff ff            	mov	dword ptr [ebp - 0x220], eax
  e3b511: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
  e3b514: 89 8d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ecx
  e3b51a: 8b 57 0c                     	mov	edx, dword ptr [edi + 0xc]
  e3b51d: 89 95 e8 fd ff ff            	mov	dword ptr [ebp - 0x218], edx
  e3b523: 89 5f 04                     	mov	dword ptr [edi + 0x4], ebx
  e3b526: 89 5f 08                     	mov	dword ptr [edi + 0x8], ebx
  e3b529: 89 5f 0c                     	mov	dword ptr [edi + 0xc], ebx
  e3b52c: 8d 8d 90 fd ff ff            	lea	ecx, [ebp - 0x270]
  e3b532: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  e3b536: e8 d5 1d 93 ff               	call	0x76d310
  e3b53b: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3b541: 53                           	push	ebx
  e3b542: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3b548: 50                           	push	eax
  e3b549: 53                           	push	ebx
  e3b54a: 6a 02                        	push	0x2
  e3b54c: 56                           	push	esi
  e3b54d: e8 2e 41 a7 ff               	call	0x8af680
  e3b552: 8d 8d 7c fd ff ff            	lea	ecx, [ebp - 0x284]
  e3b558: 51                           	push	ecx
  e3b559: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3b55f: e8 0c ac 33 00               	call	0x1176170 <.text+0x33b070>
  e3b564: eb 0a                        	jmp	0xe3b570 <.text+0x470>
  e3b566: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  e3b56d: 8d 49 00                     	lea	ecx, [ecx]
  e3b570: 8d 95 5c fd ff ff            	lea	edx, [ebp - 0x2a4]
  e3b576: 52                           	push	edx
  e3b577: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3b57d: e8 be 8d 98 ff               	call	0x7c4340
  e3b582: 8b bd 7c fd ff ff            	mov	edi, dword ptr [ebp - 0x284]
  e3b588: 3b fb                        	cmp	edi, ebx
  e3b58a: 74 78                        	je	0xe3b604 <.text+0x504>
  e3b58c: 8b 17                        	mov	edx, dword ptr [edi]
  e3b58e: 3b d3                        	cmp	edx, ebx
  e3b590: 74 72                        	je	0xe3b604 <.text+0x504>
  e3b592: 8b 08                        	mov	ecx, dword ptr [eax]
  e3b594: 3b cb                        	cmp	ecx, ebx
  e3b596: 75 04                        	jne	0xe3b59c <.text+0x49c>
  e3b598: 33 c9                        	xor	ecx, ecx
  e3b59a: eb 02                        	jmp	0xe3b59e <.text+0x49e>
  e3b59c: 8b 09                        	mov	ecx, dword ptr [ecx]
  e3b59e: 3b d1                        	cmp	edx, ecx
  e3b5a0: 75 62                        	jne	0xe3b604 <.text+0x504>
  e3b5a2: 8b 8d 84 fd ff ff            	mov	ecx, dword ptr [ebp - 0x27c]
  e3b5a8: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  e3b5ab: 0f 94 c0                     	sete	al
  e3b5ae: 84 c0                        	test	al, al
  e3b5b0: 0f 94 c0                     	sete	al
  e3b5b3: 84 c0                        	test	al, al
  e3b5b5: 74 52                        	je	0xe3b609 <.text+0x509>
  e3b5b7: 8b c2                        	mov	eax, edx
  e3b5b9: 3b c3                        	cmp	eax, ebx
  e3b5bb: 74 47                        	je	0xe3b604 <.text+0x504>
  e3b5bd: 3b cb                        	cmp	ecx, ebx
  e3b5bf: 74 43                        	je	0xe3b604 <.text+0x504>
  e3b5c1: 39 48 04                     	cmp	dword ptr [eax + 0x4], ecx
  e3b5c4: 77 3e                        	ja	0xe3b604 <.text+0x504>
  e3b5c6: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  e3b5c9: 73 39                        	jae	0xe3b604 <.text+0x504>
  e3b5cb: 8b 09                        	mov	ecx, dword ptr [ecx]
  e3b5cd: 8b 01                        	mov	eax, dword ptr [ecx]
  e3b5cf: f3 0f 10 85 c4 fd ff ff      	movss	xmm0, dword ptr [ebp - 0x23c]
  e3b5d7: 8b 90 30 01 00 00            	mov	edx, dword ptr [eax + 0x130]
  e3b5dd: 51                           	push	ecx
  e3b5de: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
  e3b5e3: ff d2                        	call	edx
  e3b5e5: 8b c8                        	mov	ecx, eax
  e3b5e7: e8 44 66 25 00               	call	0x1091c30 <.text+0x256b30>
  e3b5ec: 53                           	push	ebx
  e3b5ed: 8d 85 98 fd ff ff            	lea	eax, [ebp - 0x268]
  e3b5f3: 50                           	push	eax
  e3b5f4: 8d 8d 7c fd ff ff            	lea	ecx, [ebp - 0x284]
  e3b5fa: e8 11 08 9d ff               	call	0x80be10
  e3b5ff: e9 6c ff ff ff               	jmp	0xe3b570 <.text+0x470>
  e3b604: e8 9e b7 59 00               	call	0x13d6da7 <.text+0x59bca7>
  e3b609: f6 86 2c 02 00 00 01         	test	byte ptr [esi + 0x22c], 0x1
  e3b610: 0f 84 a0 04 00 00            	je	0xe3bab6 <.text+0x9b6>
  e3b616: 83 be 10 02 00 00 00         	cmp	dword ptr [esi + 0x210], 0x0
  e3b61d: 0f 84 93 04 00 00            	je	0xe3bab6 <.text+0x9b6>
  e3b623: 8b 3d 80 f4 a6 01            	mov	edi, dword ptr [0x1a6f480]
  e3b629: 8b 17                        	mov	edx, dword ptr [edi]
  e3b62b: 8b 42 1c                     	mov	eax, dword ptr [edx + 0x1c]
  e3b62e: 8b cf                        	mov	ecx, edi
  e3b630: ff d0                        	call	eax
  e3b632: 8b 17                        	mov	edx, dword ptr [edi]
  e3b634: 89 85 c4 fd ff ff            	mov	dword ptr [ebp - 0x23c], eax
  e3b63a: 8b 42 24                     	mov	eax, dword ptr [edx + 0x24]
  e3b63d: 8b cf                        	mov	ecx, edi
  e3b63f: ff d0                        	call	eax
  e3b641: 8b d8                        	mov	ebx, eax
  e3b643: 8b 86 08 02 00 00            	mov	eax, dword ptr [esi + 0x208]
  e3b649: 83 f8 01                     	cmp	eax, 0x1
  e3b64c: 74 64                        	je	0xe3b6b2 <.text+0x5b2>
  e3b64e: 83 f8 02                     	cmp	eax, 0x2
  e3b651: 74 5f                        	je	0xe3b6b2 <.text+0x5b2>
  e3b653: 83 f8 03                     	cmp	eax, 0x3
  e3b656: 74 29                        	je	0xe3b681 <.text+0x581>
  e3b658: 83 f8 04                     	cmp	eax, 0x4
  e3b65b: 74 24                        	je	0xe3b681 <.text+0x581>
  e3b65d: 83 f8 05                     	cmp	eax, 0x5
  e3b660: 75 73                        	jne	0xe3b6d5 <.text+0x5d5>
  e3b662: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3b668: b9 20 03 00 00               	mov	ecx, 0x320
  e3b66d: 89 48 22                     	mov	dword ptr [eax + 0x22], ecx
  e3b670: 89 48 26                     	mov	dword ptr [eax + 0x26], ecx
  e3b673: c7 40 50 00 00 00 00         	mov	dword ptr [eax + 0x50], 0x0
  e3b67a: b8 0a 00 00 00               	mov	eax, 0xa
  e3b67f: eb 4e                        	jmp	0xe3b6cf <.text+0x5cf>
  e3b681: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3b687: b9 bc 02 00 00               	mov	ecx, 0x2bc
  e3b68c: 89 48 22                     	mov	dword ptr [eax + 0x22], ecx
  e3b68f: 89 48 26                     	mov	dword ptr [eax + 0x26], ecx
  e3b692: 8b 8e 08 02 00 00            	mov	ecx, dword ptr [esi + 0x208]
  e3b698: 83 e9 03                     	sub	ecx, 0x3
  e3b69b: f7 d9                        	neg	ecx
  e3b69d: 1b c9                        	sbb	ecx, ecx
  e3b69f: 81 e1 74 ff ff ff            	and	ecx, 0xffffff74
  e3b6a5: 83 c1 46                     	add	ecx, 0x46
  e3b6a8: 89 48 50                     	mov	dword ptr [eax + 0x50], ecx
  e3b6ab: b8 28 00 00 00               	mov	eax, 0x28
  e3b6b0: eb 1d                        	jmp	0xe3b6cf <.text+0x5cf>
  e3b6b2: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3b6b8: b9 90 01 00 00               	mov	ecx, 0x190
  e3b6bd: 89 48 22                     	mov	dword ptr [eax + 0x22], ecx
  e3b6c0: 89 48 26                     	mov	dword ptr [eax + 0x26], ecx
  e3b6c3: c7 40 50 00 00 00 00         	mov	dword ptr [eax + 0x50], 0x0
  e3b6ca: b8 64 00 00 00               	mov	eax, 0x64
  e3b6cf: 89 43 30                     	mov	dword ptr [ebx + 0x30], eax
  e3b6d2: 89 43 34                     	mov	dword ptr [ebx + 0x34], eax
  e3b6d5: 8b 96 0c 02 00 00            	mov	edx, dword ptr [esi + 0x20c]
  e3b6db: 68 e0 22 02 00               	push	0x222e0
  e3b6e0: 81 ea 30 75 00 00            	sub	edx, 0x7530
  e3b6e6: 52                           	push	edx
  e3b6e7: 6a 1e                        	push	0x1e
  e3b6e9: 6a 0a                        	push	0xa
  e3b6eb: e8 d0 e1 37 00               	call	0x11b98c0 <.text+0x37e7c0>
  e3b6f0: 8d 4b 04                     	lea	ecx, [ebx + 0x4]
  e3b6f3: 83 c4 10                     	add	esp, 0x10
  e3b6f6: 89 85 c4 fd ff ff            	mov	dword ptr [ebp - 0x23c], eax
  e3b6fc: 8d 41 08                     	lea	eax, [ecx + 0x8]
  e3b6ff: 50                           	push	eax
  e3b700: 8d 95 c4 fd ff ff            	lea	edx, [ebp - 0x23c]
  e3b706: 52                           	push	edx
  e3b707: e8 24 52 36 00               	call	0x11a0930 <.text+0x365830>
  e3b70c: 8b 86 0c 02 00 00            	mov	eax, dword ptr [esi + 0x20c]
  e3b712: 68 e0 22 02 00               	push	0x222e0
  e3b717: 2d 30 75 00 00               	sub	eax, 0x7530
  e3b71c: 50                           	push	eax
  e3b71d: 68 96 00 00 00               	push	0x96
  e3b722: 6a 32                        	push	0x32
  e3b724: e8 97 e1 37 00               	call	0x11b98c0 <.text+0x37e7c0>
  e3b729: 8b 8e 0c 02 00 00            	mov	ecx, dword ptr [esi + 0x20c]
  e3b72f: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
  e3b737: 83 c4 10                     	add	esp, 0x10
  e3b73a: 68 e0 22 02 00               	push	0x222e0
  e3b73f: 81 e9 30 75 00 00            	sub	ecx, 0x7530
  e3b745: 51                           	push	ecx
  e3b746: 83 ec 08                     	sub	esp, 0x8
  e3b749: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
  e3b74f: f3 0f 10 05 84 21 56 01      	movss	xmm0, dword ptr [0x1562184]
  e3b757: 89 85 b4 fd ff ff            	mov	dword ptr [ebp - 0x24c], eax
  e3b75d: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
  e3b762: e8 39 f0 41 00               	call	0x125a7a0 <.text+0x41f6a0>
  e3b767: d9 9d c4 fd ff ff            	fstp	dword ptr [ebp - 0x23c]
  e3b76d: 8b 85 b4 fd ff ff            	mov	eax, dword ptr [ebp - 0x24c]
  e3b773: 8d 14 00                     	lea	edx, [eax + eax]
  e3b776: 89 53 18                     	mov	dword ptr [ebx + 0x18], edx
  e3b779: 89 43 14                     	mov	dword ptr [ebx + 0x14], eax
  e3b77c: 89 43 1c                     	mov	dword ptr [ebx + 0x1c], eax
  e3b77f: 8b 07                        	mov	eax, dword ptr [edi]
  e3b781: 8b 50 0c                     	mov	edx, dword ptr [eax + 0xc]
  e3b784: 83 c4 10                     	add	esp, 0x10
  e3b787: 6a 00                        	push	0x0
  e3b789: 8b cf                        	mov	ecx, edi
  e3b78b: ff d2                        	call	edx
  e3b78d: 8b 8d bc fd ff ff            	mov	ecx, dword ptr [ebp - 0x244]
  e3b793: 8b 95 c8 fd ff ff            	mov	edx, dword ptr [ebp - 0x238]
  e3b799: 8b 07                        	mov	eax, dword ptr [edi]
  e3b79b: 51                           	push	ecx
  e3b79c: 8b 8d cc fd ff ff            	mov	ecx, dword ptr [ebp - 0x234]
  e3b7a2: 52                           	push	edx
  e3b7a3: 8b 50 28                     	mov	edx, dword ptr [eax + 0x28]
  e3b7a6: 51                           	push	ecx
  e3b7a7: 8b cf                        	mov	ecx, edi
  e3b7a9: ff d2                        	call	edx
  e3b7ab: 8b 07                        	mov	eax, dword ptr [edi]
  e3b7ad: 8b 50 60                     	mov	edx, dword ptr [eax + 0x60]
  e3b7b0: 8d 8d 90 fd ff ff            	lea	ecx, [ebp - 0x270]
  e3b7b6: 51                           	push	ecx
  e3b7b7: 8b cf                        	mov	ecx, edi
  e3b7b9: ff d2                        	call	edx
  e3b7bb: 8b f8                        	mov	edi, eax
  e3b7bd: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3b7c3: 33 db                        	xor	ebx, ebx
  e3b7c5: 3b c7                        	cmp	eax, edi
  e3b7c7: 74 73                        	je	0xe3b83c <.text+0x73c>
  e3b7c9: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3b7cf: 3b c3                        	cmp	eax, ebx
  e3b7d1: 74 09                        	je	0xe3b7dc <.text+0x6dc>
  e3b7d3: 50                           	push	eax
  e3b7d4: e8 4e a3 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3b7d9: 83 c4 04                     	add	esp, 0x4
  e3b7dc: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3b7e2: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3b7e8: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3b7ee: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3b7f4: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3b7f6: 89 8d dc fd ff ff            	mov	dword ptr [ebp - 0x224], ecx
  e3b7fc: 89 07                        	mov	dword ptr [edi], eax
  e3b7fe: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3b804: 3b c3                        	cmp	eax, ebx
  e3b806: 74 08                        	je	0xe3b810 <.text+0x710>
  e3b808: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
  e3b80e: 89 10                        	mov	dword ptr [eax], edx
  e3b810: 8b 07                        	mov	eax, dword ptr [edi]
  e3b812: 3b c3                        	cmp	eax, ebx
  e3b814: 74 02                        	je	0xe3b818 <.text+0x718>
  e3b816: 89 38                        	mov	dword ptr [eax], edi
  e3b818: 8b 47 04                     	mov	eax, dword ptr [edi + 0x4]
  e3b81b: 89 85 e0 fd ff ff            	mov	dword ptr [ebp - 0x220], eax
  e3b821: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
  e3b824: 89 8d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ecx
  e3b82a: 8b 57 0c                     	mov	edx, dword ptr [edi + 0xc]
  e3b82d: 89 95 e8 fd ff ff            	mov	dword ptr [ebp - 0x218], edx
  e3b833: 89 5f 04                     	mov	dword ptr [edi + 0x4], ebx
  e3b836: 89 5f 08                     	mov	dword ptr [edi + 0x8], ebx
  e3b839: 89 5f 0c                     	mov	dword ptr [edi + 0xc], ebx
  e3b83c: 8b 85 94 fd ff ff            	mov	eax, dword ptr [ebp - 0x26c]
  e3b842: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  e3b846: 3b c3                        	cmp	eax, ebx
  e3b848: 74 09                        	je	0xe3b853 <.text+0x753>
  e3b84a: 50                           	push	eax
  e3b84b: e8 d7 a2 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3b850: 83 c4 04                     	add	esp, 0x4
  e3b853: 8b 85 90 fd ff ff            	mov	eax, dword ptr [ebp - 0x270]
  e3b859: 50                           	push	eax
  e3b85a: 89 9d 94 fd ff ff            	mov	dword ptr [ebp - 0x26c], ebx
  e3b860: 89 9d 98 fd ff ff            	mov	dword ptr [ebp - 0x268], ebx
  e3b866: 89 9d 9c fd ff ff            	mov	dword ptr [ebp - 0x264], ebx
  e3b86c: e8 b6 a2 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3b871: 83 c4 04                     	add	esp, 0x4
  e3b874: 53                           	push	ebx
  e3b875: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3b87b: 51                           	push	ecx
  e3b87c: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3b882: 53                           	push	ebx
  e3b883: 6a 02                        	push	0x2
  e3b885: 56                           	push	esi
  e3b886: e8 f5 3d a7 ff               	call	0x8af680
  e3b88b: 8b 96 10 02 00 00            	mov	edx, dword ptr [esi + 0x210]
  e3b891: 52                           	push	edx
  e3b892: 68 a8 86 7d 01               	push	0x17d86a8
  e3b897: e8 54 46 36 00               	call	0x119fef0 <.text+0x364df0>
  e3b89c: 83 c4 04                     	add	esp, 0x4
  e3b89f: 50                           	push	eax
  e3b8a0: 8d 85 f0 fd ff ff            	lea	eax, [ebp - 0x210]
  e3b8a6: 68 00 02 00 00               	push	0x200
  e3b8ab: 50                           	push	eax
  e3b8ac: e8 4f e7 5c ff               	call	0x40a000
  e3b8b1: 8b 0d e4 64 b5 01            	mov	ecx, dword ptr [0x1b564e4]
  e3b8b7: 8b 11                        	mov	edx, dword ptr [ecx]
  e3b8b9: 8b 52 10                     	mov	edx, dword ptr [edx + 0x10]
  e3b8bc: 83 c4 10                     	add	esp, 0x10
  e3b8bf: 8d 85 f0 fd ff ff            	lea	eax, [ebp - 0x210]
  e3b8c5: 50                           	push	eax
  e3b8c6: ff d2                        	call	edx
  e3b8c8: 89 85 8c fd ff ff            	mov	dword ptr [ebp - 0x274], eax
  e3b8ce: 8d 85 98 fd ff ff            	lea	eax, [ebp - 0x268]
  e3b8d4: 50                           	push	eax
  e3b8d5: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3b8db: e8 90 a8 33 00               	call	0x1176170 <.text+0x33b070>
  e3b8e0: 8b 08                        	mov	ecx, dword ptr [eax]
  e3b8e2: 3b cb                        	cmp	ecx, ebx
  e3b8e4: 74 10                        	je	0xe3b8f6 <.text+0x7f6>
  e3b8e6: 8b 09                        	mov	ecx, dword ptr [ecx]
  e3b8e8: 3b cb                        	cmp	ecx, ebx
  e3b8ea: 74 0a                        	je	0xe3b8f6 <.text+0x7f6>
  e3b8ec: 8b 19                        	mov	ebx, dword ptr [ecx]
  e3b8ee: 89 9d a4 fd ff ff            	mov	dword ptr [ebp - 0x25c], ebx
  e3b8f4: eb 06                        	jmp	0xe3b8fc <.text+0x7fc>
  e3b8f6: 8b 9d a4 fd ff ff            	mov	ebx, dword ptr [ebp - 0x25c]
  e3b8fc: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
  e3b8ff: 89 bd ac fd ff ff            	mov	dword ptr [ebp - 0x254], edi
  e3b905: eb 09                        	jmp	0xe3b910 <.text+0x810>
  e3b907: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  e3b90e: 8b ff                        	mov	edi, edi
  e3b910: 8d 8d 98 fd ff ff            	lea	ecx, [ebp - 0x268]
  e3b916: 51                           	push	ecx
  e3b917: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3b91d: e8 1e 8a 98 ff               	call	0x7c4340
  e3b922: 85 db                        	test	ebx, ebx
  e3b924: 0f 84 da fc ff ff            	je	0xe3b604 <.text+0x504>
  e3b92a: 8b 13                        	mov	edx, dword ptr [ebx]
  e3b92c: 85 d2                        	test	edx, edx
  e3b92e: 0f 84 d0 fc ff ff            	je	0xe3b604 <.text+0x504>
  e3b934: 8b 08                        	mov	ecx, dword ptr [eax]
  e3b936: 85 c9                        	test	ecx, ecx
  e3b938: 74 02                        	je	0xe3b93c <.text+0x83c>
  e3b93a: 8b 09                        	mov	ecx, dword ptr [ecx]
  e3b93c: 3b d1                        	cmp	edx, ecx
  e3b93e: 0f 85 c0 fc ff ff            	jne	0xe3b604 <.text+0x504>
  e3b944: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
  e3b947: 0f 94 c0                     	sete	al
  e3b94a: 84 c0                        	test	al, al
  e3b94c: 0f 94 c0                     	sete	al
  e3b94f: 84 c0                        	test	al, al
  e3b951: 0f 84 5f 01 00 00            	je	0xe3bab6 <.text+0x9b6>
  e3b957: 8b c2                        	mov	eax, edx
  e3b959: 85 c0                        	test	eax, eax
  e3b95b: 0f 84 a3 fc ff ff            	je	0xe3b604 <.text+0x504>
  e3b961: 85 ff                        	test	edi, edi
  e3b963: 0f 84 9b fc ff ff            	je	0xe3b604 <.text+0x504>
  e3b969: 39 78 04                     	cmp	dword ptr [eax + 0x4], edi
  e3b96c: 0f 87 92 fc ff ff            	ja	0xe3b604 <.text+0x504>
  e3b972: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
  e3b975: 0f 83 89 fc ff ff            	jae	0xe3b604 <.text+0x504>
  e3b97b: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3b97d: 8b 11                        	mov	edx, dword ptr [ecx]
  e3b97f: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3b985: ff d0                        	call	eax
  e3b987: 89 85 b4 fd ff ff            	mov	dword ptr [ebp - 0x24c], eax
  e3b98d: 8b 40 44                     	mov	eax, dword ptr [eax + 0x44]
  e3b990: 85 c0                        	test	eax, eax
  e3b992: 74 19                        	je	0xe3b9ad <.text+0x8ad>
  e3b994: 8b 48 14                     	mov	ecx, dword ptr [eax + 0x14]
  e3b997: 2b 48 10                     	sub	ecx, dword ptr [eax + 0x10]
  e3b99a: b8 ed 73 48 4d               	mov	eax, 0x4d4873ed
  e3b99f: f7 e9                        	imul	ecx
  e3b9a1: c1 fa 06                     	sar	edx, 0x6
  e3b9a4: 8b fa                        	mov	edi, edx
  e3b9a6: c1 ef 1f                     	shr	edi, 0x1f
  e3b9a9: 03 fa                        	add	edi, edx
  e3b9ab: eb 02                        	jmp	0xe3b9af <.text+0x8af>
  e3b9ad: 33 ff                        	xor	edi, edi
  e3b9af: 6a 00                        	push	0x0
  e3b9b1: 89 bd c8 fd ff ff            	mov	dword ptr [ebp - 0x238], edi
  e3b9b7: e8 a4 54 01 00               	call	0xe50e60 <.text+0x15d60>
  e3b9bc: 83 c4 04                     	add	esp, 0x4
  e3b9bf: 25 03 00 00 80               	and	eax, 0x80000003
  e3b9c4: 79 05                        	jns	0xe3b9cb <.text+0x8cb>
  e3b9c6: 48                           	dec	eax
  e3b9c7: 83 c8 fc                     	or	eax, -0x4
  e3b9ca: 40                           	inc	eax
  e3b9cb: 89 85 bc fd ff ff            	mov	dword ptr [ebp - 0x244], eax
  e3b9d1: c7 85 cc fd ff ff 00 00 00 00	mov	dword ptr [ebp - 0x234], 0x0
  e3b9db: 85 ff                        	test	edi, edi
  e3b9dd: 0f 8e ae 00 00 00            	jle	0xe3ba91 <.text+0x991>
  e3b9e3: 8b 8d cc fd ff ff            	mov	ecx, dword ptr [ebp - 0x234]
  e3b9e9: 51                           	push	ecx
  e3b9ea: 8b 8d b4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x24c]
  e3b9f0: e8 0b 35 25 00               	call	0x108ef00 <.text+0x253e00>
  e3b9f5: 8b 95 bc fd ff ff            	mov	edx, dword ptr [ebp - 0x244]
  e3b9fb: 8b 8d 8c fd ff ff            	mov	ecx, dword ptr [ebp - 0x274]
  e3ba01: 52                           	push	edx
  e3ba02: 8b d8                        	mov	ebx, eax
  e3ba04: e8 c7 91 37 00               	call	0x11b4bd0 <.text+0x379ad0>
  e3ba09: f3 0f 10 85 c4 fd ff ff      	movss	xmm0, dword ptr [ebp - 0x23c]
  e3ba11: 89 43 0c                     	mov	dword ptr [ebx + 0xc], eax
  e3ba14: 8d 43 24                     	lea	eax, [ebx + 0x24]
  e3ba17: 50                           	push	eax
  e3ba18: 8d 8d 88 fd ff ff            	lea	ecx, [ebp - 0x278]
  e3ba1e: 51                           	push	ecx
  e3ba1f: 8d 4b 1c                     	lea	ecx, [ebx + 0x1c]
  e3ba22: f3 0f 11 85 88 fd ff ff      	movss	dword ptr [ebp - 0x278], xmm0
  e3ba2a: e8 01 4f 36 00               	call	0x11a0930 <.text+0x365830>
  e3ba2f: 8d 95 6c fd ff ff            	lea	edx, [ebp - 0x294]
  e3ba35: 52                           	push	edx
  e3ba36: 8d 43 24                     	lea	eax, [ebx + 0x24]
  e3ba39: 50                           	push	eax
  e3ba3a: 8d 4b 1c                     	lea	ecx, [ebx + 0x1c]
  e3ba3d: e8 9e 53 36 00               	call	0x11a0de0 <.text+0x365ce0>
  e3ba42: f3 0f 10 85 c4 fd ff ff      	movss	xmm0, dword ptr [ebp - 0x23c]
  e3ba4a: 8d 4b 18                     	lea	ecx, [ebx + 0x18]
  e3ba4d: 51                           	push	ecx
  e3ba4e: 8d 95 b0 fd ff ff            	lea	edx, [ebp - 0x250]
  e3ba54: 52                           	push	edx
  e3ba55: 8d 4b 10                     	lea	ecx, [ebx + 0x10]
  e3ba58: f3 0f 11 85 b0 fd ff ff      	movss	dword ptr [ebp - 0x250], xmm0
  e3ba60: e8 cb 4e 36 00               	call	0x11a0930 <.text+0x365830>
  e3ba65: 8d 85 68 fd ff ff            	lea	eax, [ebp - 0x298]
  e3ba6b: 50                           	push	eax
  e3ba6c: 8d 4b 18                     	lea	ecx, [ebx + 0x18]
  e3ba6f: 51                           	push	ecx
  e3ba70: 8d 4b 10                     	lea	ecx, [ebx + 0x10]
  e3ba73: e8 68 53 36 00               	call	0x11a0de0 <.text+0x365ce0>
  e3ba78: 8b 85 cc fd ff ff            	mov	eax, dword ptr [ebp - 0x234]
  e3ba7e: 40                           	inc	eax
  e3ba7f: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3ba85: 3b 85 c8 fd ff ff            	cmp	eax, dword ptr [ebp - 0x238]
  e3ba8b: 0f 8c 52 ff ff ff            	jl	0xe3b9e3 <.text+0x8e3>
  e3ba91: 6a 00                        	push	0x0
  e3ba93: 8d 95 5c fd ff ff            	lea	edx, [ebp - 0x2a4]
  e3ba99: 52                           	push	edx
  e3ba9a: 8d 8d a4 fd ff ff            	lea	ecx, [ebp - 0x25c]
  e3baa0: e8 6b 03 9d ff               	call	0x80be10
  e3baa5: 8b bd ac fd ff ff            	mov	edi, dword ptr [ebp - 0x254]
  e3baab: 8b 9d a4 fd ff ff            	mov	ebx, dword ptr [ebp - 0x25c]
  e3bab1: e9 5a fe ff ff               	jmp	0xe3b910 <.text+0x810>
  e3bab6: b8 01 00 00 00               	mov	eax, 0x1
  e3babb: 01 86 30 02 00 00            	add	dword ptr [esi + 0x230], eax
  e3bac1: 33 ff                        	xor	edi, edi
  e3bac3: 39 86 30 02 00 00            	cmp	dword ptr [esi + 0x230], eax
  e3bac9: 7c 0c                        	jl	0xe3bad7 <.text+0x9d7>
  e3bacb: 88 86 18 02 00 00            	mov	byte ptr [esi + 0x218], al
  e3bad1: 89 be 30 02 00 00            	mov	dword ptr [esi + 0x230], edi
  e3bad7: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3badd: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3bae1: 3b c7                        	cmp	eax, edi
  e3bae3: 74 09                        	je	0xe3baee <.text+0x9ee>
  e3bae5: 50                           	push	eax
  e3bae6: e8 3c a0 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3baeb: 83 c4 04                     	add	esp, 0x4
  e3baee: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3baf4: 50                           	push	eax
  e3baf5: 89 bd e0 fd ff ff            	mov	dword ptr [ebp - 0x220], edi
  e3bafb: 89 bd e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], edi
  e3bb01: 89 bd e8 fd ff ff            	mov	dword ptr [ebp - 0x218], edi
  e3bb07: e8 1b a0 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3bb0c: 83 c4 04                     	add	esp, 0x4
  e3bb0f: 33 db                        	xor	ebx, ebx
  e3bb11: f6 86 2c 02 00 00 04         	test	byte ptr [esi + 0x22c], 0x4
  e3bb18: 8d 4e 70                     	lea	ecx, [esi + 0x70]
  e3bb1b: 0f 84 b9 08 00 00            	je	0xe3c3da <.text+0x12da>
  e3bb21: e8 1a eb 37 00               	call	0x11ba640 <.text+0x37f540>
  e3bb26: 8b 8e 14 02 00 00            	mov	ecx, dword ptr [esi + 0x214]
  e3bb2c: 83 c1 64                     	add	ecx, 0x64
  e3bb2f: 3b c1                        	cmp	eax, ecx
  e3bb31: 0f 8c 8c 08 00 00            	jl	0xe3c3c3 <.text+0x12c3>
  e3bb37: 8b 16                        	mov	edx, dword ptr [esi]
  e3bb39: 8b 82 a4 00 00 00            	mov	eax, dword ptr [edx + 0xa4]
  e3bb3f: 8b ce                        	mov	ecx, esi
  e3bb41: ff d0                        	call	eax
  e3bb43: 8b 16                        	mov	edx, dword ptr [esi]
  e3bb45: 89 85 c4 fd ff ff            	mov	dword ptr [ebp - 0x23c], eax
  e3bb4b: 8b 82 a8 00 00 00            	mov	eax, dword ptr [edx + 0xa8]
  e3bb51: 8b ce                        	mov	ecx, esi
  e3bb53: ff d0                        	call	eax
  e3bb55: 6a 02                        	push	0x2
  e3bb57: 8d 8d bb fd ff ff            	lea	ecx, [ebp - 0x245]
  e3bb5d: 89 85 bc fd ff ff            	mov	dword ptr [ebp - 0x244], eax
  e3bb63: e8 28 f4 91 ff               	call	0x75af90
  e3bb68: e8 a3 a8 8c ff               	call	0x706410
  e3bb6d: 8a 88 8c 03 00 00            	mov	cl, byte ptr [eax + 0x38c]
  e3bb73: 8d 95 bb fd ff ff            	lea	edx, [ebp - 0x245]
  e3bb79: 88 8d ba fd ff ff            	mov	byte ptr [ebp - 0x246], cl
  e3bb7f: 52                           	push	edx
  e3bb80: 8d 8d ba fd ff ff            	lea	ecx, [ebp - 0x246]
  e3bb86: e8 d5 da 91 ff               	call	0x759660
  e3bb8b: 84 c0                        	test	al, al
  e3bb8d: 0f 84 0a 07 00 00            	je	0xe3c29d <.text+0x119d>
  e3bb93: 39 9e 20 02 00 00            	cmp	dword ptr [esi + 0x220], ebx
  e3bb99: 8d 86 20 02 00 00            	lea	eax, [esi + 0x220]
  e3bb9f: 0f 84 f8 06 00 00            	je	0xe3c29d <.text+0x119d>
  e3bba5: 39 9e 24 02 00 00            	cmp	dword ptr [esi + 0x224], ebx
  e3bbab: 0f 84 ec 06 00 00            	je	0xe3c29d <.text+0x119d>
  e3bbb1: 8b 8e 08 02 00 00            	mov	ecx, dword ptr [esi + 0x208]
  e3bbb7: 83 f9 01                     	cmp	ecx, 0x1
  e3bbba: 0f 85 83 01 00 00            	jne	0xe3bd43 <.text+0xc43>
  e3bbc0: 89 9d c8 fd ff ff            	mov	dword ptr [ebp - 0x238], ebx
  e3bbc6: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3bbcc: 8d 64 24 00                  	lea	esp, [esp]
  e3bbd0: 8b bd cc fd ff ff            	mov	edi, dword ptr [ebp - 0x234]
  e3bbd6: 8b 95 bc fd ff ff            	mov	edx, dword ptr [ebp - 0x244]
  e3bbdc: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3bbde: 8b 01                        	mov	eax, dword ptr [ecx]
  e3bbe0: 8b 40 28                     	mov	eax, dword ptr [eax + 0x28]
  e3bbe3: 6a 1e                        	push	0x1e
  e3bbe5: 52                           	push	edx
  e3bbe6: 8b 95 c4 fd ff ff            	mov	edx, dword ptr [ebp - 0x23c]
  e3bbec: 52                           	push	edx
  e3bbed: ff d0                        	call	eax
  e3bbef: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3bbf1: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bbf3: 8b 52 60                     	mov	edx, dword ptr [edx + 0x60]
  e3bbf6: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3bbfc: 50                           	push	eax
  e3bbfd: ff d2                        	call	edx
  e3bbff: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3bc05: 53                           	push	ebx
  e3bc06: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3bc0c: 50                           	push	eax
  e3bc0d: 53                           	push	ebx
  e3bc0e: 6a 02                        	push	0x2
  e3bc10: 56                           	push	esi
  e3bc11: c6 45 fc 08                  	mov	byte ptr [ebp - 0x4], 0x8
  e3bc15: e8 66 3a a7 ff               	call	0x8af680
  e3bc1a: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3bc20: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3bc26: 2b c1                        	sub	eax, ecx
  e3bc28: c1 f8 02                     	sar	eax, 0x2
  e3bc2b: 33 ff                        	xor	edi, edi
  e3bc2d: 3b c3                        	cmp	eax, ebx
  e3bc2f: 0f 86 87 00 00 00            	jbe	0xe3bcbc <.text+0xbbc>
  e3bc35: 3b f8                        	cmp	edi, eax
  e3bc37: 0f 83 c7 f9 ff ff            	jae	0xe3b604 <.text+0x504>
  e3bc3d: 8b 0c b9                     	mov	ecx, dword ptr [ecx + 4*edi]
  e3bc40: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bc42: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3bc48: 53                           	push	ebx
  e3bc49: ff d0                        	call	eax
  e3bc4b: 8b c8                        	mov	ecx, eax
  e3bc4d: e8 ae 32 25 00               	call	0x108ef00 <.text+0x253e00>
  e3bc52: 85 c0                        	test	eax, eax
  e3bc54: 74 50                        	je	0xe3bca6 <.text+0xba6>
  e3bc56: 8b 8d e4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x21c]
  e3bc5c: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3bc62: 2b c8                        	sub	ecx, eax
  e3bc64: c1 f9 02                     	sar	ecx, 0x2
  e3bc67: 3b f9                        	cmp	edi, ecx
  e3bc69: 0f 83 95 f9 ff ff            	jae	0xe3b604 <.text+0x504>
  e3bc6f: 8b 0c b8                     	mov	ecx, dword ptr [eax + 4*edi]
  e3bc72: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bc74: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3bc7a: 8b 9e 28 02 00 00            	mov	ebx, dword ptr [esi + 0x228]
  e3bc80: 6a 00                        	push	0x0
  e3bc82: ff d0                        	call	eax
  e3bc84: 8b c8                        	mov	ecx, eax
  e3bc86: e8 75 32 25 00               	call	0x108ef00 <.text+0x253e00>
  e3bc8b: 8d 48 60                     	lea	ecx, [eax + 0x60]
  e3bc8e: 51                           	push	ecx
  e3bc8f: 8d 95 c0 fd ff ff            	lea	edx, [ebp - 0x240]
  e3bc95: 52                           	push	edx
  e3bc96: 8d 48 58                     	lea	ecx, [eax + 0x58]
  e3bc99: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3bc9f: e8 8c 4c 36 00               	call	0x11a0930 <.text+0x365830>
  e3bca4: 33 db                        	xor	ebx, ebx
  e3bca6: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3bcac: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3bcb2: 2b c1                        	sub	eax, ecx
  e3bcb4: 47                           	inc	edi
  e3bcb5: c1 f8 02                     	sar	eax, 0x2
  e3bcb8: 3b f8                        	cmp	edi, eax
  e3bcba: 72 81                        	jb	0xe3bc3d <.text+0xb3d>
  e3bcbc: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3bcc0: 3b cb                        	cmp	ecx, ebx
  e3bcc2: 74 09                        	je	0xe3bccd <.text+0xbcd>
  e3bcc4: 51                           	push	ecx
  e3bcc5: e8 5d 9e 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3bcca: 83 c4 04                     	add	esp, 0x4
  e3bccd: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3bcd3: 50                           	push	eax
  e3bcd4: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3bcda: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3bce0: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3bce6: e8 3c 9e 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3bceb: 8b 85 c8 fd ff ff            	mov	eax, dword ptr [ebp - 0x238]
  e3bcf1: 83 85 cc fd ff ff 04         	add	dword ptr [ebp - 0x234], 0x4
  e3bcf8: 40                           	inc	eax
  e3bcf9: 83 c4 04                     	add	esp, 0x4
  e3bcfc: 89 85 c8 fd ff ff            	mov	dword ptr [ebp - 0x238], eax
  e3bd02: 83 f8 02                     	cmp	eax, 0x2
  e3bd05: 0f 8c c5 fe ff ff            	jl	0xe3bbd0 <.text+0xad0>
  e3bd0b: e9 b3 06 00 00               	jmp	0xe3c3c3 <.text+0x12c3>
  e3bd10: 8d 8d c0 fd ff ff            	lea	ecx, [ebp - 0x240]
  e3bd16: 51                           	push	ecx
  e3bd17: 8d 8d 70 fd ff ff            	lea	ecx, [ebp - 0x290]
  e3bd1d: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3bd23: e8 a2 a7 59 00               	call	0x13d64ca <.text+0x59b3ca>
  e3bd28: 68 90 0f 91 01               	push	0x1910f90
  e3bd2d: 8d 95 70 fd ff ff            	lea	edx, [ebp - 0x290]
  e3bd33: 52                           	push	edx
  e3bd34: c7 85 70 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x290], 0x1562084
  e3bd3e: e8 57 ae 59 00               	call	0x13d6b9a <.text+0x59ba9a>
  e3bd43: 83 f9 02                     	cmp	ecx, 0x2
  e3bd46: 0f 85 54 01 00 00            	jne	0xe3bea0 <.text+0xda0>
  e3bd4c: 89 9d c8 fd ff ff            	mov	dword ptr [ebp - 0x238], ebx
  e3bd52: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3bd58: eb 06                        	jmp	0xe3bd60 <.text+0xc60>
  e3bd5a: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
  e3bd60: 8b bd cc fd ff ff            	mov	edi, dword ptr [ebp - 0x234]
  e3bd66: 8b 85 bc fd ff ff            	mov	eax, dword ptr [ebp - 0x244]
  e3bd6c: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3bd6e: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bd70: 8b 52 28                     	mov	edx, dword ptr [edx + 0x28]
  e3bd73: 6a 1e                        	push	0x1e
  e3bd75: 50                           	push	eax
  e3bd76: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3bd7c: 50                           	push	eax
  e3bd7d: ff d2                        	call	edx
  e3bd7f: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3bd81: 8b 01                        	mov	eax, dword ptr [ecx]
  e3bd83: 8b 40 60                     	mov	eax, dword ptr [eax + 0x60]
  e3bd86: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
  e3bd8c: 52                           	push	edx
  e3bd8d: ff d0                        	call	eax
  e3bd8f: 53                           	push	ebx
  e3bd90: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3bd96: 51                           	push	ecx
  e3bd97: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3bd9d: 53                           	push	ebx
  e3bd9e: 6a 02                        	push	0x2
  e3bda0: 56                           	push	esi
  e3bda1: c6 45 fc 09                  	mov	byte ptr [ebp - 0x4], 0x9
  e3bda5: e8 d6 38 a7 ff               	call	0x8af680
  e3bdaa: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3bdb0: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3bdb6: 2b c1                        	sub	eax, ecx
  e3bdb8: c1 f8 02                     	sar	eax, 0x2
  e3bdbb: 33 ff                        	xor	edi, edi
  e3bdbd: 3b c3                        	cmp	eax, ebx
  e3bdbf: 0f 86 87 00 00 00            	jbe	0xe3be4c <.text+0xd4c>
  e3bdc5: 3b f8                        	cmp	edi, eax
  e3bdc7: 0f 83 37 f8 ff ff            	jae	0xe3b604 <.text+0x504>
  e3bdcd: 8b 0c b9                     	mov	ecx, dword ptr [ecx + 4*edi]
  e3bdd0: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bdd2: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3bdd8: 53                           	push	ebx
  e3bdd9: ff d0                        	call	eax
  e3bddb: 8b c8                        	mov	ecx, eax
  e3bddd: e8 1e 31 25 00               	call	0x108ef00 <.text+0x253e00>
  e3bde2: 85 c0                        	test	eax, eax
  e3bde4: 74 50                        	je	0xe3be36 <.text+0xd36>
  e3bde6: 8b 8d e4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x21c]
  e3bdec: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3bdf2: 2b c8                        	sub	ecx, eax
  e3bdf4: c1 f9 02                     	sar	ecx, 0x2
  e3bdf7: 3b f9                        	cmp	edi, ecx
  e3bdf9: 0f 83 05 f8 ff ff            	jae	0xe3b604 <.text+0x504>
  e3bdff: 8b 0c b8                     	mov	ecx, dword ptr [eax + 4*edi]
  e3be02: 8b 11                        	mov	edx, dword ptr [ecx]
  e3be04: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3be0a: 8b 9e 28 02 00 00            	mov	ebx, dword ptr [esi + 0x228]
  e3be10: 6a 00                        	push	0x0
  e3be12: ff d0                        	call	eax
  e3be14: 8b c8                        	mov	ecx, eax
  e3be16: e8 e5 30 25 00               	call	0x108ef00 <.text+0x253e00>
  e3be1b: 8d 48 60                     	lea	ecx, [eax + 0x60]
  e3be1e: 51                           	push	ecx
  e3be1f: 8d 95 c0 fd ff ff            	lea	edx, [ebp - 0x240]
  e3be25: 52                           	push	edx
  e3be26: 8d 48 58                     	lea	ecx, [eax + 0x58]
  e3be29: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3be2f: e8 fc 4a 36 00               	call	0x11a0930 <.text+0x365830>
  e3be34: 33 db                        	xor	ebx, ebx
  e3be36: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3be3c: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3be42: 2b c1                        	sub	eax, ecx
  e3be44: 47                           	inc	edi
  e3be45: c1 f8 02                     	sar	eax, 0x2
  e3be48: 3b f8                        	cmp	edi, eax
  e3be4a: 72 81                        	jb	0xe3bdcd <.text+0xccd>
  e3be4c: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3be50: 3b cb                        	cmp	ecx, ebx
  e3be52: 74 09                        	je	0xe3be5d <.text+0xd5d>
  e3be54: 51                           	push	ecx
  e3be55: e8 cd 9c 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3be5a: 83 c4 04                     	add	esp, 0x4
  e3be5d: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3be63: 50                           	push	eax
  e3be64: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3be6a: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3be70: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3be76: e8 ac 9c 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3be7b: 8b 85 c8 fd ff ff            	mov	eax, dword ptr [ebp - 0x238]
  e3be81: 83 85 cc fd ff ff 04         	add	dword ptr [ebp - 0x234], 0x4
  e3be88: 40                           	inc	eax
  e3be89: 83 c4 04                     	add	esp, 0x4
  e3be8c: 89 85 c8 fd ff ff            	mov	dword ptr [ebp - 0x238], eax
  e3be92: 83 f8 02                     	cmp	eax, 0x2
  e3be95: 0f 8c c5 fe ff ff            	jl	0xe3bd60 <.text+0xc60>
  e3be9b: e9 23 05 00 00               	jmp	0xe3c3c3 <.text+0x12c3>
  e3bea0: 83 f9 03                     	cmp	ecx, 0x3
  e3bea3: 0f 85 57 01 00 00            	jne	0xe3c000 <.text+0xf00>
  e3bea9: 89 9d c8 fd ff ff            	mov	dword ptr [ebp - 0x238], ebx
  e3beaf: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3beb5: eb 09                        	jmp	0xe3bec0 <.text+0xdc0>
  e3beb7: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  e3bebe: 8b ff                        	mov	edi, edi
  e3bec0: 8b bd cc fd ff ff            	mov	edi, dword ptr [ebp - 0x234]
  e3bec6: 8b 85 bc fd ff ff            	mov	eax, dword ptr [ebp - 0x244]
  e3becc: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3bece: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bed0: 8b 52 28                     	mov	edx, dword ptr [edx + 0x28]
  e3bed3: 6a 1e                        	push	0x1e
  e3bed5: 50                           	push	eax
  e3bed6: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3bedc: 50                           	push	eax
  e3bedd: ff d2                        	call	edx
  e3bedf: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3bee1: 8b 01                        	mov	eax, dword ptr [ecx]
  e3bee3: 8b 40 60                     	mov	eax, dword ptr [eax + 0x60]
  e3bee6: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
  e3beec: 52                           	push	edx
  e3beed: ff d0                        	call	eax
  e3beef: 53                           	push	ebx
  e3bef0: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3bef6: 51                           	push	ecx
  e3bef7: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3befd: 53                           	push	ebx
  e3befe: 6a 02                        	push	0x2
  e3bf00: 56                           	push	esi
  e3bf01: c6 45 fc 0a                  	mov	byte ptr [ebp - 0x4], 0xa
  e3bf05: e8 76 37 a7 ff               	call	0x8af680
  e3bf0a: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3bf10: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3bf16: 2b c1                        	sub	eax, ecx
  e3bf18: c1 f8 02                     	sar	eax, 0x2
  e3bf1b: 33 ff                        	xor	edi, edi
  e3bf1d: 3b c3                        	cmp	eax, ebx
  e3bf1f: 0f 86 87 00 00 00            	jbe	0xe3bfac <.text+0xeac>
  e3bf25: 3b f8                        	cmp	edi, eax
  e3bf27: 0f 83 d7 f6 ff ff            	jae	0xe3b604 <.text+0x504>
  e3bf2d: 8b 0c b9                     	mov	ecx, dword ptr [ecx + 4*edi]
  e3bf30: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bf32: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3bf38: 53                           	push	ebx
  e3bf39: ff d0                        	call	eax
  e3bf3b: 8b c8                        	mov	ecx, eax
  e3bf3d: e8 be 2f 25 00               	call	0x108ef00 <.text+0x253e00>
  e3bf42: 85 c0                        	test	eax, eax
  e3bf44: 74 50                        	je	0xe3bf96 <.text+0xe96>
  e3bf46: 8b 8d e4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x21c]
  e3bf4c: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3bf52: 2b c8                        	sub	ecx, eax
  e3bf54: c1 f9 02                     	sar	ecx, 0x2
  e3bf57: 3b f9                        	cmp	edi, ecx
  e3bf59: 0f 83 a5 f6 ff ff            	jae	0xe3b604 <.text+0x504>
  e3bf5f: 8b 0c b8                     	mov	ecx, dword ptr [eax + 4*edi]
  e3bf62: 8b 11                        	mov	edx, dword ptr [ecx]
  e3bf64: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3bf6a: 8b 9e 28 02 00 00            	mov	ebx, dword ptr [esi + 0x228]
  e3bf70: 6a 00                        	push	0x0
  e3bf72: ff d0                        	call	eax
  e3bf74: 8b c8                        	mov	ecx, eax
  e3bf76: e8 85 2f 25 00               	call	0x108ef00 <.text+0x253e00>
  e3bf7b: 8d 48 60                     	lea	ecx, [eax + 0x60]
  e3bf7e: 51                           	push	ecx
  e3bf7f: 8d 95 c0 fd ff ff            	lea	edx, [ebp - 0x240]
  e3bf85: 52                           	push	edx
  e3bf86: 8d 48 58                     	lea	ecx, [eax + 0x58]
  e3bf89: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3bf8f: e8 9c 49 36 00               	call	0x11a0930 <.text+0x365830>
  e3bf94: 33 db                        	xor	ebx, ebx
  e3bf96: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3bf9c: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3bfa2: 2b c1                        	sub	eax, ecx
  e3bfa4: 47                           	inc	edi
  e3bfa5: c1 f8 02                     	sar	eax, 0x2
  e3bfa8: 3b f8                        	cmp	edi, eax
  e3bfaa: 72 81                        	jb	0xe3bf2d <.text+0xe2d>
  e3bfac: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3bfb0: 3b cb                        	cmp	ecx, ebx
  e3bfb2: 74 09                        	je	0xe3bfbd <.text+0xebd>
  e3bfb4: 51                           	push	ecx
  e3bfb5: e8 6d 9b 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3bfba: 83 c4 04                     	add	esp, 0x4
  e3bfbd: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3bfc3: 50                           	push	eax
  e3bfc4: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3bfca: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3bfd0: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3bfd6: e8 4c 9b 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3bfdb: 8b 85 c8 fd ff ff            	mov	eax, dword ptr [ebp - 0x238]
  e3bfe1: 83 85 cc fd ff ff 04         	add	dword ptr [ebp - 0x234], 0x4
  e3bfe8: 40                           	inc	eax
  e3bfe9: 83 c4 04                     	add	esp, 0x4
  e3bfec: 89 85 c8 fd ff ff            	mov	dword ptr [ebp - 0x238], eax
  e3bff2: 83 f8 02                     	cmp	eax, 0x2
  e3bff5: 0f 8c c5 fe ff ff            	jl	0xe3bec0 <.text+0xdc0>
  e3bffb: e9 c3 03 00 00               	jmp	0xe3c3c3 <.text+0x12c3>
  e3c000: 83 f9 04                     	cmp	ecx, 0x4
  e3c003: 0f 85 57 01 00 00            	jne	0xe3c160 <.text+0x1060>
  e3c009: 89 9d c8 fd ff ff            	mov	dword ptr [ebp - 0x238], ebx
  e3c00f: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3c015: eb 09                        	jmp	0xe3c020 <.text+0xf20>
  e3c017: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  e3c01e: 8b ff                        	mov	edi, edi
  e3c020: 8b bd cc fd ff ff            	mov	edi, dword ptr [ebp - 0x234]
  e3c026: 8b 85 bc fd ff ff            	mov	eax, dword ptr [ebp - 0x244]
  e3c02c: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3c02e: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c030: 8b 52 28                     	mov	edx, dword ptr [edx + 0x28]
  e3c033: 6a 1e                        	push	0x1e
  e3c035: 50                           	push	eax
  e3c036: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3c03c: 50                           	push	eax
  e3c03d: ff d2                        	call	edx
  e3c03f: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3c041: 8b 01                        	mov	eax, dword ptr [ecx]
  e3c043: 8b 40 60                     	mov	eax, dword ptr [eax + 0x60]
  e3c046: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
  e3c04c: 52                           	push	edx
  e3c04d: ff d0                        	call	eax
  e3c04f: 53                           	push	ebx
  e3c050: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3c056: 51                           	push	ecx
  e3c057: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3c05d: 53                           	push	ebx
  e3c05e: 6a 02                        	push	0x2
  e3c060: 56                           	push	esi
  e3c061: c6 45 fc 0b                  	mov	byte ptr [ebp - 0x4], 0xb
  e3c065: e8 16 36 a7 ff               	call	0x8af680
  e3c06a: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3c070: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3c076: 2b c1                        	sub	eax, ecx
  e3c078: c1 f8 02                     	sar	eax, 0x2
  e3c07b: 33 ff                        	xor	edi, edi
  e3c07d: 3b c3                        	cmp	eax, ebx
  e3c07f: 0f 86 87 00 00 00            	jbe	0xe3c10c <.text+0x100c>
  e3c085: 3b f8                        	cmp	edi, eax
  e3c087: 0f 83 77 f5 ff ff            	jae	0xe3b604 <.text+0x504>
  e3c08d: 8b 0c b9                     	mov	ecx, dword ptr [ecx + 4*edi]
  e3c090: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c092: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3c098: 53                           	push	ebx
  e3c099: ff d0                        	call	eax
  e3c09b: 8b c8                        	mov	ecx, eax
  e3c09d: e8 5e 2e 25 00               	call	0x108ef00 <.text+0x253e00>
  e3c0a2: 85 c0                        	test	eax, eax
  e3c0a4: 74 50                        	je	0xe3c0f6 <.text+0xff6>
  e3c0a6: 8b 8d e4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x21c]
  e3c0ac: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3c0b2: 2b c8                        	sub	ecx, eax
  e3c0b4: c1 f9 02                     	sar	ecx, 0x2
  e3c0b7: 3b f9                        	cmp	edi, ecx
  e3c0b9: 0f 83 45 f5 ff ff            	jae	0xe3b604 <.text+0x504>
  e3c0bf: 8b 0c b8                     	mov	ecx, dword ptr [eax + 4*edi]
  e3c0c2: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c0c4: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3c0ca: 8b 9e 28 02 00 00            	mov	ebx, dword ptr [esi + 0x228]
  e3c0d0: 6a 00                        	push	0x0
  e3c0d2: ff d0                        	call	eax
  e3c0d4: 8b c8                        	mov	ecx, eax
  e3c0d6: e8 25 2e 25 00               	call	0x108ef00 <.text+0x253e00>
  e3c0db: 8d 48 60                     	lea	ecx, [eax + 0x60]
  e3c0de: 51                           	push	ecx
  e3c0df: 8d 95 c0 fd ff ff            	lea	edx, [ebp - 0x240]
  e3c0e5: 52                           	push	edx
  e3c0e6: 8d 48 58                     	lea	ecx, [eax + 0x58]
  e3c0e9: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3c0ef: e8 3c 48 36 00               	call	0x11a0930 <.text+0x365830>
  e3c0f4: 33 db                        	xor	ebx, ebx
  e3c0f6: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3c0fc: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3c102: 2b c1                        	sub	eax, ecx
  e3c104: 47                           	inc	edi
  e3c105: c1 f8 02                     	sar	eax, 0x2
  e3c108: 3b f8                        	cmp	edi, eax
  e3c10a: 72 81                        	jb	0xe3c08d <.text+0xf8d>
  e3c10c: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3c110: 3b cb                        	cmp	ecx, ebx
  e3c112: 74 09                        	je	0xe3c11d <.text+0x101d>
  e3c114: 51                           	push	ecx
  e3c115: e8 0d 9a 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3c11a: 83 c4 04                     	add	esp, 0x4
  e3c11d: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3c123: 50                           	push	eax
  e3c124: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3c12a: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3c130: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3c136: e8 ec 99 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3c13b: 8b 85 c8 fd ff ff            	mov	eax, dword ptr [ebp - 0x238]
  e3c141: 83 85 cc fd ff ff 04         	add	dword ptr [ebp - 0x234], 0x4
  e3c148: 40                           	inc	eax
  e3c149: 83 c4 04                     	add	esp, 0x4
  e3c14c: 89 85 c8 fd ff ff            	mov	dword ptr [ebp - 0x238], eax
  e3c152: 83 f8 02                     	cmp	eax, 0x2
  e3c155: 0f 8c c5 fe ff ff            	jl	0xe3c020 <.text+0xf20>
  e3c15b: e9 63 02 00 00               	jmp	0xe3c3c3 <.text+0x12c3>
  e3c160: 83 f9 05                     	cmp	ecx, 0x5
  e3c163: 0f 85 5a 02 00 00            	jne	0xe3c3c3 <.text+0x12c3>
  e3c169: 89 9d c8 fd ff ff            	mov	dword ptr [ebp - 0x238], ebx
  e3c16f: 89 85 cc fd ff ff            	mov	dword ptr [ebp - 0x234], eax
  e3c175: eb 09                        	jmp	0xe3c180 <.text+0x1080>
  e3c177: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  e3c17e: 8b ff                        	mov	edi, edi
  e3c180: 8b bd cc fd ff ff            	mov	edi, dword ptr [ebp - 0x234]
  e3c186: 8b 85 bc fd ff ff            	mov	eax, dword ptr [ebp - 0x244]
  e3c18c: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3c18e: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c190: 8b 52 28                     	mov	edx, dword ptr [edx + 0x28]
  e3c193: 6a 1e                        	push	0x1e
  e3c195: 50                           	push	eax
  e3c196: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
  e3c19c: 50                           	push	eax
  e3c19d: ff d2                        	call	edx
  e3c19f: 8b 0f                        	mov	ecx, dword ptr [edi]
  e3c1a1: 8b 01                        	mov	eax, dword ptr [ecx]
  e3c1a3: 8b 40 60                     	mov	eax, dword ptr [eax + 0x60]
  e3c1a6: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
  e3c1ac: 52                           	push	edx
  e3c1ad: ff d0                        	call	eax
  e3c1af: 53                           	push	ebx
  e3c1b0: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3c1b6: 51                           	push	ecx
  e3c1b7: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3c1bd: 53                           	push	ebx
  e3c1be: 6a 02                        	push	0x2
  e3c1c0: 56                           	push	esi
  e3c1c1: c6 45 fc 0c                  	mov	byte ptr [ebp - 0x4], 0xc
  e3c1c5: e8 b6 34 a7 ff               	call	0x8af680
  e3c1ca: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3c1d0: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3c1d6: 2b c1                        	sub	eax, ecx
  e3c1d8: c1 f8 02                     	sar	eax, 0x2
  e3c1db: 33 ff                        	xor	edi, edi
  e3c1dd: 3b c3                        	cmp	eax, ebx
  e3c1df: 0f 86 87 00 00 00            	jbe	0xe3c26c <.text+0x116c>
  e3c1e5: 3b f8                        	cmp	edi, eax
  e3c1e7: 0f 83 17 f4 ff ff            	jae	0xe3b604 <.text+0x504>
  e3c1ed: 8b 0c b9                     	mov	ecx, dword ptr [ecx + 4*edi]
  e3c1f0: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c1f2: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3c1f8: 53                           	push	ebx
  e3c1f9: ff d0                        	call	eax
  e3c1fb: 8b c8                        	mov	ecx, eax
  e3c1fd: e8 fe 2c 25 00               	call	0x108ef00 <.text+0x253e00>
  e3c202: 85 c0                        	test	eax, eax
  e3c204: 74 50                        	je	0xe3c256 <.text+0x1156>
  e3c206: 8b 8d e4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x21c]
  e3c20c: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3c212: 2b c8                        	sub	ecx, eax
  e3c214: c1 f9 02                     	sar	ecx, 0x2
  e3c217: 3b f9                        	cmp	edi, ecx
  e3c219: 0f 83 e5 f3 ff ff            	jae	0xe3b604 <.text+0x504>
  e3c21f: 8b 0c b8                     	mov	ecx, dword ptr [eax + 4*edi]
  e3c222: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c224: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3c22a: 8b 9e 28 02 00 00            	mov	ebx, dword ptr [esi + 0x228]
  e3c230: 6a 00                        	push	0x0
  e3c232: ff d0                        	call	eax
  e3c234: 8b c8                        	mov	ecx, eax
  e3c236: e8 c5 2c 25 00               	call	0x108ef00 <.text+0x253e00>
  e3c23b: 8d 48 60                     	lea	ecx, [eax + 0x60]
  e3c23e: 51                           	push	ecx
  e3c23f: 8d 95 c0 fd ff ff            	lea	edx, [ebp - 0x240]
  e3c245: 52                           	push	edx
  e3c246: 8d 48 58                     	lea	ecx, [eax + 0x58]
  e3c249: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3c24f: e8 dc 46 36 00               	call	0x11a0930 <.text+0x365830>
  e3c254: 33 db                        	xor	ebx, ebx
  e3c256: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3c25c: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3c262: 2b c1                        	sub	eax, ecx
  e3c264: 47                           	inc	edi
  e3c265: c1 f8 02                     	sar	eax, 0x2
  e3c268: 3b f8                        	cmp	edi, eax
  e3c26a: 72 81                        	jb	0xe3c1ed <.text+0x10ed>
  e3c26c: 8d 8d dc fd ff ff            	lea	ecx, [ebp - 0x224]
  e3c272: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3c276: e8 95 10 93 ff               	call	0x76d310
  e3c27b: 8b 85 c8 fd ff ff            	mov	eax, dword ptr [ebp - 0x238]
  e3c281: 83 85 cc fd ff ff 04         	add	dword ptr [ebp - 0x234], 0x4
  e3c288: 40                           	inc	eax
  e3c289: 89 85 c8 fd ff ff            	mov	dword ptr [ebp - 0x238], eax
  e3c28f: 83 f8 02                     	cmp	eax, 0x2
  e3c292: 0f 8c e8 fe ff ff            	jl	0xe3c180 <.text+0x1080>
  e3c298: e9 26 01 00 00               	jmp	0xe3c3c3 <.text+0x12c3>
  e3c29d: 8b 95 bc fd ff ff            	mov	edx, dword ptr [ebp - 0x244]
  e3c2a3: 8b 8e 1c 02 00 00            	mov	ecx, dword ptr [esi + 0x21c]
  e3c2a9: 8b 01                        	mov	eax, dword ptr [ecx]
  e3c2ab: 8b 40 28                     	mov	eax, dword ptr [eax + 0x28]
  e3c2ae: 6a 1e                        	push	0x1e
  e3c2b0: 52                           	push	edx
  e3c2b1: 8b 95 c4 fd ff ff            	mov	edx, dword ptr [ebp - 0x23c]
  e3c2b7: 52                           	push	edx
  e3c2b8: ff d0                        	call	eax
  e3c2ba: 8b 8e 1c 02 00 00            	mov	ecx, dword ptr [esi + 0x21c]
  e3c2c0: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c2c2: 8b 52 60                     	mov	edx, dword ptr [edx + 0x60]
  e3c2c5: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3c2cb: 50                           	push	eax
  e3c2cc: ff d2                        	call	edx
  e3c2ce: 8b 8e b8 00 00 00            	mov	ecx, dword ptr [esi + 0xb8]
  e3c2d4: 53                           	push	ebx
  e3c2d5: 8d 85 dc fd ff ff            	lea	eax, [ebp - 0x224]
  e3c2db: 50                           	push	eax
  e3c2dc: 53                           	push	ebx
  e3c2dd: 6a 02                        	push	0x2
  e3c2df: 56                           	push	esi
  e3c2e0: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
  e3c2e4: e8 97 33 a7 ff               	call	0x8af680
  e3c2e9: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3c2ef: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3c2f5: 2b c1                        	sub	eax, ecx
  e3c2f7: c1 f8 02                     	sar	eax, 0x2
  e3c2fa: 33 ff                        	xor	edi, edi
  e3c2fc: 3b c3                        	cmp	eax, ebx
  e3c2fe: 0f 86 87 00 00 00            	jbe	0xe3c38b <.text+0x128b>
  e3c304: 3b f8                        	cmp	edi, eax
  e3c306: 0f 83 f8 f2 ff ff            	jae	0xe3b604 <.text+0x504>
  e3c30c: 8b 0c b9                     	mov	ecx, dword ptr [ecx + 4*edi]
  e3c30f: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c311: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3c317: 53                           	push	ebx
  e3c318: ff d0                        	call	eax
  e3c31a: 8b c8                        	mov	ecx, eax
  e3c31c: e8 df 2b 25 00               	call	0x108ef00 <.text+0x253e00>
  e3c321: 85 c0                        	test	eax, eax
  e3c323: 74 50                        	je	0xe3c375 <.text+0x1275>
  e3c325: 8b 8d e4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x21c]
  e3c32b: 8b 85 e0 fd ff ff            	mov	eax, dword ptr [ebp - 0x220]
  e3c331: 2b c8                        	sub	ecx, eax
  e3c333: c1 f9 02                     	sar	ecx, 0x2
  e3c336: 3b f9                        	cmp	edi, ecx
  e3c338: 0f 83 c6 f2 ff ff            	jae	0xe3b604 <.text+0x504>
  e3c33e: 8b 0c b8                     	mov	ecx, dword ptr [eax + 4*edi]
  e3c341: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c343: 8b 82 30 01 00 00            	mov	eax, dword ptr [edx + 0x130]
  e3c349: 8b 9e 28 02 00 00            	mov	ebx, dword ptr [esi + 0x228]
  e3c34f: 6a 00                        	push	0x0
  e3c351: ff d0                        	call	eax
  e3c353: 8b c8                        	mov	ecx, eax
  e3c355: e8 a6 2b 25 00               	call	0x108ef00 <.text+0x253e00>
  e3c35a: 8d 48 60                     	lea	ecx, [eax + 0x60]
  e3c35d: 51                           	push	ecx
  e3c35e: 8d 95 c0 fd ff ff            	lea	edx, [ebp - 0x240]
  e3c364: 52                           	push	edx
  e3c365: 8d 48 58                     	lea	ecx, [eax + 0x58]
  e3c368: 89 9d c0 fd ff ff            	mov	dword ptr [ebp - 0x240], ebx
  e3c36e: e8 bd 45 36 00               	call	0x11a0930 <.text+0x365830>
  e3c373: 33 db                        	xor	ebx, ebx
  e3c375: 8b 85 e4 fd ff ff            	mov	eax, dword ptr [ebp - 0x21c]
  e3c37b: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
  e3c381: 2b c1                        	sub	eax, ecx
  e3c383: 47                           	inc	edi
  e3c384: c1 f8 02                     	sar	eax, 0x2
  e3c387: 3b f8                        	cmp	edi, eax
  e3c389: 72 81                        	jb	0xe3c30c <.text+0x120c>
  e3c38b: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  e3c38f: 3b cb                        	cmp	ecx, ebx
  e3c391: 74 09                        	je	0xe3c39c <.text+0x129c>
  e3c393: 51                           	push	ecx
  e3c394: e8 8e 97 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3c399: 83 c4 04                     	add	esp, 0x4
  e3c39c: 8b 85 dc fd ff ff            	mov	eax, dword ptr [ebp - 0x224]
  e3c3a2: 50                           	push	eax
  e3c3a3: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
  e3c3a9: 89 9d e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], ebx
  e3c3af: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
  e3c3b5: e8 6d 97 59 00               	call	0x13d5b27 <.text+0x59aa27>
  e3c3ba: 83 c4 04                     	add	esp, 0x4
  e3c3bd: 89 9d dc fd ff ff            	mov	dword ptr [ebp - 0x224], ebx
  e3c3c3: 8b 8e 1c 02 00 00            	mov	ecx, dword ptr [esi + 0x21c]
  e3c3c9: 3b cb                        	cmp	ecx, ebx
  e3c3cb: 74 1a                        	je	0xe3c3e7 <.text+0x12e7>
  e3c3cd: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c3cf: 8b 42 40                     	mov	eax, dword ptr [edx + 0x40]
  e3c3d2: ff d0                        	call	eax
  e3c3d4: 84 c0                        	test	al, al
  e3c3d6: 74 19                        	je	0xe3c3f1 <.text+0x12f1>
  e3c3d8: eb 0d                        	jmp	0xe3c3e7 <.text+0x12e7>
  e3c3da: e8 61 e2 37 00               	call	0x11ba640 <.text+0x37f540>
  e3c3df: 3b 86 14 02 00 00            	cmp	eax, dword ptr [esi + 0x214]
  e3c3e5: 7c 0a                        	jl	0xe3c3f1 <.text+0x12f1>
  e3c3e7: 8b 16                        	mov	edx, dword ptr [esi]
  e3c3e9: 8b 42 68                     	mov	eax, dword ptr [edx + 0x68]
  e3c3ec: 53                           	push	ebx
  e3c3ed: 8b ce                        	mov	ecx, esi
  e3c3ef: ff d0                        	call	eax
  e3c3f1: 8d 8d 44 fd ff ff            	lea	ecx, [ebp - 0x2bc]
  e3c3f7: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  e3c3fe: e8 bd 1c 35 00               	call	0x118e0c0 <.text+0x352fc0>
  e3c403: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  e3c406: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  e3c40d: 59                           	pop	ecx
  e3c40e: 5f                           	pop	edi
  e3c40f: 5e                           	pop	esi
  e3c410: 5b                           	pop	ebx
  e3c411: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  e3c414: 33 cd                        	xor	ecx, ebp
  e3c416: e8 bd ad 59 00               	call	0x13d71d8 <.text+0x59c0d8>
  e3c41b: 8b e5                        	mov	esp, ebp
  e3c41d: 5d                           	pop	ebp
  e3c41e: c3                           	ret
  e3c41f: cc                           	int3
  e3c420: 55                           	push	ebp
  e3c421: 8b ec                        	mov	ebp, esp
  e3c423: 6a ff                        	push	-0x1
  e3c425: 68 6b e5 45 01               	push	0x145e56b
  e3c42a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  e3c430: 50                           	push	eax
  e3c431: 56                           	push	esi
  e3c432: 57                           	push	edi
  e3c433: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  e3c438: 33 c5                        	xor	eax, ebp
  e3c43a: 50                           	push	eax
  e3c43b: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  e3c43e: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  e3c444: 8b f1                        	mov	esi, ecx
  e3c446: 81 7d 0c 30 75 00 00         	cmp	dword ptr [ebp + 0xc], 0x7530
  e3c44d: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  e3c450: 89 86 08 02 00 00            	mov	dword ptr [esi + 0x208], eax
  e3c456: b8 a0 86 7d 01               	mov	eax, 0x17d86a0
  e3c45b: 7c 03                        	jl	0xe3c460 <.text+0x1360>
  e3c45d: 8d 45 0c                     	lea	eax, [ebp + 0xc]
  e3c460: 81 38 10 98 02 00            	cmp	dword ptr [eax], 0x29810
  e3c466: 7e 05                        	jle	0xe3c46d <.text+0x136d>
  e3c468: b8 a4 86 7d 01               	mov	eax, 0x17d86a4
  e3c46d: 8b 08                        	mov	ecx, dword ptr [eax]
  e3c46f: 8b 55 10                     	mov	edx, dword ptr [ebp + 0x10]
  e3c472: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
  e3c475: 68 bc 01 00 00               	push	0x1bc
  e3c47a: 89 8e 0c 02 00 00            	mov	dword ptr [esi + 0x20c], ecx
  e3c480: 89 96 10 02 00 00            	mov	dword ptr [esi + 0x210], edx
  e3c486: 89 86 14 02 00 00            	mov	dword ptr [esi + 0x214], eax
  e3c48c: c6 86 18 02 00 00 00         	mov	byte ptr [esi + 0x218], 0x0
  e3c493: e8 e8 3e 37 00               	call	0x11b0380 <.text+0x375280>
  e3c498: 8b f8                        	mov	edi, eax
  e3c49a: 83 c4 04                     	add	esp, 0x4
  e3c49d: 89 7d 0c                     	mov	dword ptr [ebp + 0xc], edi
  e3c4a0: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  e3c4a7: 85 ff                        	test	edi, edi
  e3c4a9: 74 19                        	je	0xe3c4c4 <.text+0x13c4>
  e3c4ab: 6a 00                        	push	0x0
  e3c4ad: 68 00 59 7a 01               	push	0x17a5900
  e3c4b2: e8 39 3a 36 00               	call	0x119fef0 <.text+0x364df0>
  e3c4b7: 83 c4 04                     	add	esp, 0x4
  e3c4ba: 50                           	push	eax
  e3c4bb: 8b cf                        	mov	ecx, edi
  e3c4bd: e8 6e d1 7c ff               	call	0x609630
  e3c4c2: eb 02                        	jmp	0xe3c4c6 <.text+0x13c6>
  e3c4c4: 33 c0                        	xor	eax, eax
  e3c4c6: 89 86 1c 02 00 00            	mov	dword ptr [esi + 0x21c], eax
  e3c4cc: 8b 10                        	mov	edx, dword ptr [eax]
  e3c4ce: 8b c8                        	mov	ecx, eax
  e3c4d0: 8b 42 1c                     	mov	eax, dword ptr [edx + 0x1c]
  e3c4d3: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  e3c4da: ff d0                        	call	eax
  e3c4dc: 8b 8e 1c 02 00 00            	mov	ecx, dword ptr [esi + 0x21c]
  e3c4e2: 8b 11                        	mov	edx, dword ptr [ecx]
  e3c4e4: 8b 42 24                     	mov	eax, dword ptr [edx + 0x24]
  e3c4e7: ff d0                        	call	eax
  e3c4e9: 8b 8e 0c 02 00 00            	mov	ecx, dword ptr [esi + 0x20c]
  e3c4ef: f3 0f 10 05 18 73 58 01      	movss	xmm0, dword ptr [0x1587318]
  e3c4f7: 68 e0 22 02 00               	push	0x222e0
  e3c4fc: 81 e9 30 75 00 00            	sub	ecx, 0x7530
  e3c502: 51                           	push	ecx
  e3c503: 83 ec 08                     	sub	esp, 0x8
  e3c506: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
  e3c50c: f3 0f 10 05 b8 c5 56 01      	movss	xmm0, dword ptr [0x156c5b8]
  e3c514: 8b f8                        	mov	edi, eax
  e3c516: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
  e3c51b: e8 80 e2 41 00               	call	0x125a7a0 <.text+0x41f6a0>
  e3c520: d9 1f                        	fstp	dword ptr [edi]
  e3c522: 8b 96 0c 02 00 00            	mov	edx, dword ptr [esi + 0x20c]
  e3c528: 68 e0 22 02 00               	push	0x222e0
  e3c52d: 81 ea 30 75 00 00            	sub	edx, 0x7530
  e3c533: 52                           	push	edx
  e3c534: 68 96 00 00 00               	push	0x96
  e3c539: 6a 32                        	push	0x32
  e3c53b: e8 80 d3 37 00               	call	0x11b98c0 <.text+0x37e7c0>
  e3c540: 8d 0c 00                     	lea	ecx, [eax + eax]
  e3c543: 89 47 14                     	mov	dword ptr [edi + 0x14], eax
  e3c546: 89 4f 18                     	mov	dword ptr [edi + 0x18], ecx
  e3c549: 89 47 1c                     	mov	dword ptr [edi + 0x1c], eax
  e3c54c: 8b 96 0c 02 00 00            	mov	edx, dword ptr [esi + 0x20c]
  e3c552: 68 e0 22 02 00               	push	0x222e0
  e3c557: 81 ea 30 75 00 00            	sub	edx, 0x7530
  e3c55d: 52                           	push	edx
  e3c55e: 68 d0 07 00 00               	push	0x7d0
  e3c563: 68 e8 03 00 00               	push	0x3e8
  e3c568: e8 53 d3 37 00               	call	0x11b98c0 <.text+0x37e7c0>
  e3c56d: 89 86 28 02 00 00            	mov	dword ptr [esi + 0x228], eax
  e3c573: 8b 45 18                     	mov	eax, dword ptr [ebp + 0x18]
  e3c576: 83 c4 30                     	add	esp, 0x30
  e3c579: 89 86 2c 02 00 00            	mov	dword ptr [esi + 0x22c], eax
  e3c57f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  e3c582: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  e3c589: 59                           	pop	ecx
  e3c58a: 5f                           	pop	edi
  e3c58b: 5e                           	pop	esi
  e3c58c: 8b e5                        	mov	esp, ebp
  e3c58e: 5d                           	pop	ebp
  e3c58f: c2 18 00                     	ret	0x18
  e3c592: cc                           	int3
  e3c593: cc                           	int3
  e3c594: cc                           	int3
  e3c595: cc                           	int3
  e3c596: cc                           	int3
  e3c597: cc                           	int3
  e3c598: cc                           	int3
  e3c599: cc                           	int3
  e3c59a: cc                           	int3
  e3c59b: cc                           	int3
  e3c59c: cc                           	int3
  e3c59d: cc                           	int3
  e3c59e: cc                           	int3
  e3c59f: cc                           	int3
  e3c5a0: 55                           	push	ebp
  e3c5a1: 8b ec                        	mov	ebp, esp
  e3c5a3: 56                           	push	esi
  e3c5a4: 57                           	push	edi
  e3c5a5: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  e3c5a8: 57                           	push	edi
  e3c5a9: 8b f1                        	mov	esi, ecx
  e3c5ab: e8 e0 2c 9c ff               	call	0x7ff290
  e3c5b0: 3b be 08 02 00 00            	cmp	edi, dword ptr [esi + 0x208]
  e3c5b6: 75 15                        	jne	0xe3c5cd <.text+0x14cd>
  e3c5b8: 8b 06                        	mov	eax, dword ptr [esi]
  e3c5ba: 8b 50 68                     	mov	edx, dword ptr [eax + 0x68]
  e3c5bd: 6a 00                        	push	0x0
  e3c5bf: 8b ce                        	mov	ecx, esi
  e3c5c1: c7 86 08 02 00 00 00 00 00 00	mov	dword ptr [esi + 0x208], 0x0
  e3c5cb: ff d2                        	call	edx
  e3c5cd: 5f                           	pop	edi
  e3c5ce: 5e                           	pop	esi
  e3c5cf: 5d                           	pop	ebp
  e3c5d0: c2 04 00                     	ret	0x4
  e3c5d3: cc                           	int3
  e3c5d4: cc                           	int3
  e3c5d5: cc                           	int3
  e3c5d6: cc                           	int3
  e3c5d7: cc                           	int3
  e3c5d8: cc                           	int3
  e3c5d9: cc                           	int3
  e3c5da: cc                           	int3
  e3c5db: cc                           	int3
  e3c5dc: cc                           	int3
  e3c5dd: cc                           	int3
  e3c5de: cc                           	int3
  e3c5df: cc                           	int3
  e3c5e0: 55                           	push	ebp
  e3c5e1: 8b ec                        	mov	ebp, esp
  e3c5e3: 5d                           	pop	ebp
  e3c5e4: e9 77 68 a3 ff               	jmp	0x872e60
  e3c5e9: cc                           	int3
  e3c5ea: cc                           	int3
  e3c5eb: cc                           	int3
  e3c5ec: cc                           	int3
  e3c5ed: cc                           	int3
  e3c5ee: cc                           	int3
  e3c5ef: cc                           	int3
  e3c5f0: 55                           	push	ebp
  e3c5f1: 8b ec                        	mov	ebp, esp
  e3c5f3: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  e3c5f6: f3 0f 2c 80 bc 00 00 00      	cvttss2si	eax, dword ptr [eax + 0xbc]
  e3c5fe: 99                           	cdq
  e3c5ff: 56                           	push	esi
  e3c600: 8b f0                        	mov	esi, eax
  e3c602: 8b 41 0c                     	mov	eax, dword ptr [ecx + 0xc]
  e3c605: 33 f2                        	xor	esi, edx
  e3c607: 2b f2                        	sub	esi, edx
  e3c609: 99                           	cdq
  e3c60a: 33 c2                        	xor	eax, edx
  e3c60c: 2b c2                        	sub	eax, edx
  e3c60e: 33 c9                        	xor	ecx, ecx
  e3c610: 3b f0                        	cmp	esi, eax
  e3c612: 0f 9d c0                     	setge	al
  e3c615: 5e                           	pop	esi
  e3c616: 5d                           	pop	ebp
  e3c617: c2 08 00                     	ret	0x8
  e3c61a: cc                           	int3
  e3c61b: cc                           	int3
  e3c61c: cc                           	int3
  e3c61d: cc                           	int3
  e3c61e: cc                           	int3
  e3c61f: cc                           	int3
  e3c620: 55                           	push	ebp
  e3c621: 8b ec                        	mov	ebp, esp
  e3c623: 56                           	push	esi
  e3c624: 8d b1 94 f7 ff ff            	lea	esi, [ecx - 0x86c]
  e3c62a: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  e3c62d: 8b 01                        	mov	eax, dword ptr [ecx]
  e3c62f: 8b 50 60                     	mov	edx, dword ptr [eax + 0x60]
  e3c632: 57                           	push	edi
  e3c633: ff d2                        	call	edx
  e3c635: 8b f8                        	mov	edi, eax
  e3c637: 8b 06                        	mov	eax, dword ptr [esi]
  e3c639: 8b 90 f4 01 00 00            	mov	edx, dword ptr [eax + 0x1f4]
  e3c63f: 8b ce                        	mov	ecx, esi
  e3c641: ff d2                        	call	edx
  e3c643: 33 c9                        	xor	ecx, ecx
  e3c645: 39 47 20                     	cmp	dword ptr [edi + 0x20], eax
  e3c648: 5f                           	pop	edi
  e3c649: 0f 94 c0                     	sete	al
  e3c64c: 5e                           	pop	esi
  e3c64d: 5d                           	pop	ebp
  e3c64e: c2 04 00                     	ret	0x4
  e3c651: cc                           	int3
  e3c652: cc                           	int3
  e3c653: cc                           	int3
  e3c654: cc                           	int3
  e3c655: cc                           	int3
  e3c656: cc                           	int3
  e3c657: cc                           	int3
  e3c658: cc                           	int3
  e3c659: cc                           	int3
  e3c65a: cc                           	int3
  e3c65b: cc                           	int3
  e3c65c: cc                           	int3
  e3c65d: cc                           	int3
  e3c65e: cc                           	int3
  e3c65f: cc                           	int3
  e3c660: 55                           	push	ebp
  e3c661: 8b ec                        	mov	ebp, esp
  e3c663: 56                           	push	esi
  e3c664: 57                           	push	edi
  e3c665: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  e3c668: 57                           	push	edi
  e3c669: 8b f1                        	mov	esi, ecx
  e3c66b: e8 c0 17 a4 ff               	call	0x87de30
  e3c670: 8b 8e 70 08 00 00            	mov	ecx, dword ptr [esi + 0x870]
  e3c676: 85 c9                        	test	ecx, ecx
  e3c678: 74 06                        	je	0xe3c680 <.text+0x1580>
  e3c67a: 57                           	push	edi
  e3c67b: e8 00 48 af ff               	call	0x930e80
  e3c680: 3b be 84 08 00 00            	cmp	edi, dword ptr [esi + 0x884]
  e3c686: 75 15                        	jne	0xe3c69d <.text+0x159d>
  e3c688: 8b 06                        	mov	eax, dword ptr [esi]
  e3c68a: 8b 50 68                     	mov	edx, dword ptr [eax + 0x68]
  e3c68d: 6a 00                        	push	0x0
  e3c68f: 8b ce                        	mov	ecx, esi
  e3c691: c7 86 84 08 00 00 00 00 00 00	mov	dword ptr [esi + 0x884], 0x0
  e3c69b: ff d2                        	call	edx
  e3c69d: 5f                           	pop	edi
  e3c69e: 5e                           	pop	esi
  e3c69f: 5d                           	pop	ebp
  e3c6a0: c2 04 00                     	ret	0x4
  e3c6a3: cc                           	int3
  e3c6a4: cc                           	int3
  e3c6a5: cc                           	int3
  e3c6a6: cc                           	int3
  e3c6a7: cc                           	int3
  e3c6a8: cc                           	int3
  e3c6a9: cc                           	int3
  e3c6aa: cc                           	int3
  e3c6ab: cc                           	int3
  e3c6ac: cc                           	int3
  e3c6ad: cc                           	int3
  e3c6ae: cc                           	int3
  e3c6af: cc                           	int3
  e3c6b0: 55                           	push	ebp
  e3c6b1: 8b ec                        	mov	ebp, esp
  e3c6b3: 53                           	push	ebx
  e3c6b4: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  e3c6b7: 56                           	push	esi
  e3c6b8: 8b f1                        	mov	esi, ecx
  e3c6ba: 83 be 84 08 00 00 00         	cmp	dword ptr [esi + 0x884], 0x0
  e3c6c1: 74 4a                        	je	0xe3c70d <.text+0x160d>
  e3c6c3: 83 be ac 08 00 00 00         	cmp	dword ptr [esi + 0x8ac], 0x0
  e3c6ca: 74 41                        	je	0xe3c70d <.text+0x160d>
  e3c6cc: 8b 8e 84 08 00 00            	mov	ecx, dword ptr [esi + 0x884]
  e3c6d2: 8b 01                        	mov	eax, dword ptr [ecx]
  e3c6d4: 8b 90 a8 00 00 00            	mov	edx, dword ptr [eax + 0xa8]
  e3c6da: 57                           	push	edi
  e3c6db: 6a 00                        	push	0x0
  e3c6dd: 8b f9                        	mov	edi, ecx
  e3c6df: ff d2                        	call	edx
  e3c6e1: 50                           	push	eax
  e3c6e2: 8b 07                        	mov	eax, dword ptr [edi]
  e3c6e4: 8b 90 a4 00 00 00            	mov	edx, dword ptr [eax + 0xa4]
  e3c6ea: 8b cf                        	mov	ecx, edi
  e3c6ec: ff d2                        	call	edx
  e3c6ee: 50                           	push	eax
  e3c6ef: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  e3c6f2: 53                           	push	ebx
  e3c6f3: 50                           	push	eax
  e3c6f4: e8 c7 f0 9b ff               	call	0x7fb7c0
  e3c6f9: 83 c4 14                     	add	esp, 0x14
  e3c6fc: 5f                           	pop	edi
  e3c6fd: 3b 86                        	<unknown>
  e3c6ff: ac                           	lodsb	al, byte ptr [esi]
