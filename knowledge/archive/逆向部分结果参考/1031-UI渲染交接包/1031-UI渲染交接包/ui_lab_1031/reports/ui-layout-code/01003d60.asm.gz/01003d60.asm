
<stdin>:	file format elf32-i386

Disassembly of section .text:

01003d60 <.text>:
 1003d60: 8d 3c ff                     	lea	edi, [edi + 8*edi]
 1003d63: ff ff                        	<unknown>
 1003d65: 51                           	push	ecx
 1003d66: 8d 8d 2c ff ff ff            	lea	ecx, [ebp - 0xd4]
 1003d6c: 89 9d 3c ff ff ff            	mov	dword ptr [ebp - 0xc4], ebx
 1003d72: e8 53 27 3d 00               	call	0x13d64ca <.text+0x3d276a>
 1003d77: 68 90 0f 91 01               	push	0x1910f90
 1003d7c: 8d 95 2c ff ff ff            	lea	edx, [ebp - 0xd4]
 1003d82: 52                           	push	edx
 1003d83: c7 85 2c ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0xd4], 0x1562084
 1003d8d: e8 08 2e 3d 00               	call	0x13d6b9a <.text+0x3d2e3a>
 1003d92: cc                           	int3
 1003d93: cc                           	int3
 1003d94: cc                           	int3
 1003d95: cc                           	int3
 1003d96: cc                           	int3
 1003d97: cc                           	int3
 1003d98: cc                           	int3
 1003d99: cc                           	int3
 1003d9a: cc                           	int3
 1003d9b: cc                           	int3
 1003d9c: cc                           	int3
 1003d9d: cc                           	int3
 1003d9e: cc                           	int3
 1003d9f: cc                           	int3
 1003da0: 33 c0                        	xor	eax, eax
 1003da2: 89 41 04                     	mov	dword ptr [ecx + 0x4], eax
 1003da5: 89 41 14                     	mov	dword ptr [ecx + 0x14], eax
 1003da8: 89 41 34                     	mov	dword ptr [ecx + 0x34], eax
 1003dab: 89 41 38                     	mov	dword ptr [ecx + 0x38], eax
 1003dae: c3                           	ret
 1003daf: cc                           	int3
 1003db0: 55                           	push	ebp
 1003db1: 8b ec                        	mov	ebp, esp
 1003db3: 6a ff                        	push	-0x1
 1003db5: 68 16 ec 41 01               	push	0x141ec16
 1003dba: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1003dc0: 50                           	push	eax
 1003dc1: 51                           	push	ecx
 1003dc2: 56                           	push	esi
 1003dc3: 57                           	push	edi
 1003dc4: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 1003dc9: 33 c5                        	xor	eax, ebp
 1003dcb: 50                           	push	eax
 1003dcc: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1003dcf: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 1003dd5: 8b f1                        	mov	esi, ecx
 1003dd7: c7 46 08 cb 00 00 00         	mov	dword ptr [esi + 0x8], 0xcb
 1003dde: c7 46 0c d1 00 00 00         	mov	dword ptr [esi + 0xc], 0xd1
 1003de5: a1 e4 64 b5 01               	mov	eax, dword ptr [0x1b564e4]
 1003dea: 8b 38                        	mov	edi, dword ptr [eax]
 1003dec: 68 e8 b1 82 01               	push	0x182b1e8
 1003df1: e8 fa c0 19 00               	call	0x119fef0 <.text+0x19c190>
 1003df6: 8b 0d e4 64 b5 01            	mov	ecx, dword ptr [0x1b564e4]
 1003dfc: 8b 57 10                     	mov	edx, dword ptr [edi + 0x10]
 1003dff: 83 c4 04                     	add	esp, 0x4
 1003e02: 50                           	push	eax
 1003e03: ff d2                        	call	edx
 1003e05: 68 fc 01 00 00               	push	0x1fc
 1003e0a: 89 46 14                     	mov	dword ptr [esi + 0x14], eax
 1003e0d: e8 6e c5 1a 00               	call	0x11b0380 <.text+0x1ac620>
 1003e12: 8b f8                        	mov	edi, eax
 1003e14: 83 c4 04                     	add	esp, 0x4
 1003e17: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
 1003e1a: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
 1003e21: 85 ff                        	test	edi, edi
 1003e23: 74 1b                        	je	0x1003e40 <.text+0xe0>
 1003e25: 6a 00                        	push	0x0
 1003e27: 6a 01                        	push	0x1
 1003e29: 68 78 b1 82 01               	push	0x182b178
 1003e2e: e8 bd c0 19 00               	call	0x119fef0 <.text+0x19c190>
 1003e33: 83 c4 04                     	add	esp, 0x4
 1003e36: 50                           	push	eax
 1003e37: 8b cf                        	mov	ecx, edi
 1003e39: e8 a2 66 09 00               	call	0x109a4e0 <.text+0x96780>
 1003e3e: eb 02                        	jmp	0x1003e42 <.text+0xe2>
 1003e40: 33 c0                        	xor	eax, eax
 1003e42: 68 fc 01 00 00               	push	0x1fc
 1003e47: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1003e4e: 89 46 34                     	mov	dword ptr [esi + 0x34], eax
 1003e51: e8 2a c5 1a 00               	call	0x11b0380 <.text+0x1ac620>
 1003e56: 8b f8                        	mov	edi, eax
 1003e58: 83 c4 04                     	add	esp, 0x4
 1003e5b: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
 1003e5e: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
 1003e65: 85 ff                        	test	edi, edi
 1003e67: 74 1b                        	je	0x1003e84 <.text+0x124>
 1003e69: 6a 00                        	push	0x0
 1003e6b: 6a 01                        	push	0x1
 1003e6d: 68 20 b1 82 01               	push	0x182b120
 1003e72: e8 79 c0 19 00               	call	0x119fef0 <.text+0x19c190>
 1003e77: 83 c4 04                     	add	esp, 0x4
 1003e7a: 50                           	push	eax
 1003e7b: 8b cf                        	mov	ecx, edi
 1003e7d: e8 5e 66 09 00               	call	0x109a4e0 <.text+0x96780>
 1003e82: eb 02                        	jmp	0x1003e86 <.text+0x126>
 1003e84: 33 c0                        	xor	eax, eax
 1003e86: 8d 4e 18                     	lea	ecx, [esi + 0x18]
 1003e89: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1003e90: 89 46 38                     	mov	dword ptr [esi + 0x38], eax
 1003e93: c7 46 10 00 00 00 00         	mov	dword ptr [esi + 0x10], 0x0
 1003e9a: e8 71 56 1c 00               	call	0x11c9510 <.text+0x1c57b0>
 1003e9f: a1 6c 65 b5 01               	mov	eax, dword ptr [0x1b5656c]
 1003ea4: b9 e4 00 00 00               	mov	ecx, 0xe4
 1003ea9: 89 46 20                     	mov	dword ptr [esi + 0x20], eax
 1003eac: 66 89 4e 1a                  	mov	word ptr [esi + 0x1a], cx
 1003eb0: c6 46 1e 01                  	mov	byte ptr [esi + 0x1e], 0x1
 1003eb4: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1003eb7: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1003ebe: 59                           	pop	ecx
 1003ebf: 5f                           	pop	edi
 1003ec0: 5e                           	pop	esi
 1003ec1: 8b e5                        	mov	esp, ebp
 1003ec3: 5d                           	pop	ebp
 1003ec4: c3                           	ret
 1003ec5: cc                           	int3
 1003ec6: cc                           	int3
 1003ec7: cc                           	int3
 1003ec8: cc                           	int3
 1003ec9: cc                           	int3
 1003eca: cc                           	int3
 1003ecb: cc                           	int3
 1003ecc: cc                           	int3
 1003ecd: cc                           	int3
 1003ece: cc                           	int3
 1003ecf: cc                           	int3
 1003ed0: 55                           	push	ebp
 1003ed1: 8b ec                        	mov	ebp, esp
 1003ed3: 53                           	push	ebx
 1003ed4: 56                           	push	esi
 1003ed5: 8b f1                        	mov	esi, ecx
 1003ed7: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003edd: 8b 01                        	mov	eax, dword ptr [ecx]
 1003edf: 8b 40 4c                     	mov	eax, dword ptr [eax + 0x4c]
 1003ee2: 57                           	push	edi
 1003ee3: 8d 56 18                     	lea	edx, [esi + 0x18]
 1003ee6: 52                           	push	edx
 1003ee7: ff d0                        	call	eax
 1003ee9: 0f b6 7d 08                  	movzx	edi, byte ptr [ebp + 0x8]
 1003eed: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003ef3: 8b 19                        	mov	ebx, dword ptr [ecx]
 1003ef5: c1 e7 18                     	shl	edi, 0x18
 1003ef8: 68 2c a5 00 00               	push	0xa52c
 1003efd: 81 cf e6 c8 9b 00            	or	edi, 0x9bc8e6
 1003f03: e8 58 73 22 00               	call	0x122b260 <.text+0x227500>
 1003f08: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
 1003f0b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f11: 83 c4 04                     	add	esp, 0x4
 1003f14: 50                           	push	eax
 1003f15: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 1003f18: 57                           	push	edi
 1003f19: 83 c2 54                     	add	edx, 0x54
 1003f1c: 52                           	push	edx
 1003f1d: 8b 53 5c                     	mov	edx, dword ptr [ebx + 0x5c]
 1003f20: 83 c0 50                     	add	eax, 0x50
 1003f23: 50                           	push	eax
 1003f24: ff d2                        	call	edx
 1003f26: a1 2c 58 b5 01               	mov	eax, dword ptr [0x1b5582c]
 1003f2b: 8b 18                        	mov	ebx, dword ptr [eax]
 1003f2d: 68 2d a5 00 00               	push	0xa52d
 1003f32: e8 29 73 22 00               	call	0x122b260 <.text+0x227500>
 1003f37: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 1003f3a: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 1003f3d: 83 c4 04                     	add	esp, 0x4
 1003f40: 50                           	push	eax
 1003f41: 8b 43 5c                     	mov	eax, dword ptr [ebx + 0x5c]
 1003f44: 57                           	push	edi
 1003f45: 83 c1 66                     	add	ecx, 0x66
 1003f48: 51                           	push	ecx
 1003f49: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f4f: 83 c2 50                     	add	edx, 0x50
 1003f52: 52                           	push	edx
 1003f53: ff d0                        	call	eax
 1003f55: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f5b: 8b 19                        	mov	ebx, dword ptr [ecx]
 1003f5d: 68 2e a5 00 00               	push	0xa52e
 1003f62: e8 f9 72 22 00               	call	0x122b260 <.text+0x227500>
 1003f67: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
 1003f6a: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f70: 83 c4 04                     	add	esp, 0x4
 1003f73: 50                           	push	eax
 1003f74: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 1003f77: 57                           	push	edi
 1003f78: 83 c2 78                     	add	edx, 0x78
 1003f7b: 52                           	push	edx
 1003f7c: 8b 53 5c                     	mov	edx, dword ptr [ebx + 0x5c]
 1003f7f: 83 c0 50                     	add	eax, 0x50
 1003f82: 50                           	push	eax
 1003f83: ff d2                        	call	edx
 1003f85: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f8b: 8b 01                        	mov	eax, dword ptr [ecx]
 1003f8d: 8b 50 50                     	mov	edx, dword ptr [eax + 0x50]
 1003f90: ff d2                        	call	edx
 1003f92: 5f                           	pop	edi
 1003f93: 5e                           	pop	esi
 1003f94: 5b                           	pop	ebx
 1003f95: 5d                           	pop	ebp
 1003f96: c2 04 00                     	ret	0x4
 1003f99: cc                           	int3
 1003f9a: cc                           	int3
 1003f9b: cc                           	int3
 1003f9c: cc                           	int3
 1003f9d: cc                           	int3
 1003f9e: cc                           	int3
 1003f9f: cc                           	int3
 1003fa0: 53                           	push	ebx
 1003fa1: 56                           	push	esi
 1003fa2: 8b f1                        	mov	esi, ecx
 1003fa4: 57                           	push	edi
 1003fa5: 8b 7e 34                     	mov	edi, dword ptr [esi + 0x34]
 1003fa8: 33 db                        	xor	ebx, ebx
 1003faa: 89 5e 04                     	mov	dword ptr [esi + 0x4], ebx
 1003fad: 3b fb                        	cmp	edi, ebx
 1003faf: 74 10                        	je	0x1003fc1 <.text+0x261>
 1003fb1: 8b cf                        	mov	ecx, edi
 1003fb3: e8 78 4d 09 00               	call	0x1098d30 <.text+0x94fd0>
 1003fb8: 57                           	push	edi
 1003fb9: e8 02 c4 1a 00               	call	0x11b03c0 <.text+0x1ac660>
 1003fbe: 83 c4 04                     	add	esp, 0x4
 1003fc1: 8b 7e 38                     	mov	edi, dword ptr [esi + 0x38]
 1003fc4: 89 5e 34                     	mov	dword ptr [esi + 0x34], ebx
 1003fc7: 3b fb                        	cmp	edi, ebx
 1003fc9: 74 10                        	je	0x1003fdb <.text+0x27b>
 1003fcb: 8b cf                        	mov	ecx, edi
 1003fcd: e8 5e 4d 09 00               	call	0x1098d30 <.text+0x94fd0>
 1003fd2: 57                           	push	edi
 1003fd3: e8 e8 c3 1a 00               	call	0x11b03c0 <.text+0x1ac660>
 1003fd8: 83 c4 04                     	add	esp, 0x4
 1003fdb: 5f                           	pop	edi
 1003fdc: 89 5e 38                     	mov	dword ptr [esi + 0x38], ebx
 1003fdf: 5e                           	pop	esi
 1003fe0: 5b                           	pop	ebx
 1003fe1: c3                           	ret
 1003fe2: cc                           	int3
 1003fe3: cc                           	int3
 1003fe4: cc                           	int3
 1003fe5: cc                           	int3
 1003fe6: cc                           	int3
 1003fe7: cc                           	int3
 1003fe8: cc                           	int3
 1003fe9: cc                           	int3
 1003fea: cc                           	int3
 1003feb: cc                           	int3
 1003fec: cc                           	int3
 1003fed: cc                           	int3
 1003fee: cc                           	int3
 1003fef: cc                           	int3
 1003ff0: 55                           	push	ebp
 1003ff1: 8b ec                        	mov	ebp, esp
 1003ff3: 56                           	push	esi
 1003ff4: 8b f1                        	mov	esi, ecx
 1003ff6: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 1003ff9: f6 81 ec 01 00 00 08         	test	byte ptr [ecx + 0x1ec], 0x8
 1004000: 75 26                        	jne	0x1004028 <.text+0x2c8>
 1004002: e8 b9 84 09 00               	call	0x109c4c0 <.text+0x98760>
 1004007: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
 100400a: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
 100400d: 8b 15 2c 58 b5 01            	mov	edx, dword ptr [0x1b5582c]
 1004013: 6a 01                        	push	0x1
 1004015: 6a 00                        	push	0x0
 1004017: 83 c0 14                     	add	eax, 0x14
 100401a: 50                           	push	eax
 100401b: 83 c1 4b                     	add	ecx, 0x4b
 100401e: 51                           	push	ecx
 100401f: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 1004022: 52                           	push	edx
 1004023: e8 58 25 09 00               	call	0x1096580 <.text+0x92820>
 1004028: 8b 46 34                     	mov	eax, dword ptr [esi + 0x34]
 100402b: f6 80 ec 01 00 00 08         	test	byte ptr [eax + 0x1ec], 0x8
 1004032: 74 66                        	je	0x100409a <.text+0x33a>
 1004034: 0f b6 45 08                  	movzx	eax, byte ptr [ebp + 0x8]
 1004038: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 1004040: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 1004043: 83 ec 08                     	sub	esp, 0x8
 1004046: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 100404c: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004051: 0f 57 c0                     	xorps	xmm0, xmm0
 1004054: c1 e0 18                     	shl	eax, 0x18
 1004057: 0d ff ff ff 00               	or	eax, 0xffffff
 100405c: 50                           	push	eax
 100405d: 83 ec 0c                     	sub	esp, 0xc
 1004060: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004066: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100406e: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004074: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004079: 6a 07                        	push	0x7
 100407b: e8 50 0b 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 1004080: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 1004083: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 1004086: 50                           	push	eax
 1004087: 83 c1 13                     	add	ecx, 0x13
 100408a: 51                           	push	ecx
 100408b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1004091: 83 c2 48                     	add	edx, 0x48
 1004094: 52                           	push	edx
 1004095: e8 46 01 1b 00               	call	0x11b41e0 <.text+0x1b0480>
 100409a: 5e                           	pop	esi
 100409b: 5d                           	pop	ebp
 100409c: c2 04 00                     	ret	0x4
 100409f: cc                           	int3
 10040a0: 55                           	push	ebp
 10040a1: 8b ec                        	mov	ebp, esp
 10040a3: 56                           	push	esi
 10040a4: 8b f1                        	mov	esi, ecx
 10040a6: 8b 4e 38                     	mov	ecx, dword ptr [esi + 0x38]
 10040a9: f6 81 ec 01 00 00 08         	test	byte ptr [ecx + 0x1ec], 0x8
 10040b0: 75 26                        	jne	0x10040d8 <.text+0x378>
 10040b2: e8 09 84 09 00               	call	0x109c4c0 <.text+0x98760>
 10040b7: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
 10040ba: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
 10040bd: 8b 15 2c 58 b5 01            	mov	edx, dword ptr [0x1b5582c]
 10040c3: 6a 01                        	push	0x1
 10040c5: 6a 00                        	push	0x0
 10040c7: 83 c0 23                     	add	eax, 0x23
 10040ca: 50                           	push	eax
 10040cb: 83 c1 7d                     	add	ecx, 0x7d
 10040ce: 51                           	push	ecx
 10040cf: 8b 4e 38                     	mov	ecx, dword ptr [esi + 0x38]
 10040d2: 52                           	push	edx
 10040d3: e8 a8 24 09 00               	call	0x1096580 <.text+0x92820>
 10040d8: 8b 46 38                     	mov	eax, dword ptr [esi + 0x38]
 10040db: f6 80 ec 01 00 00 08         	test	byte ptr [eax + 0x1ec], 0x8
 10040e2: 74 66                        	je	0x100414a <.text+0x3ea>
 10040e4: 0f b6 45 08                  	movzx	eax, byte ptr [ebp + 0x8]
 10040e8: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 10040f0: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 10040f3: 83 ec 08                     	sub	esp, 0x8
 10040f6: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 10040fc: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004101: 0f 57 c0                     	xorps	xmm0, xmm0
 1004104: c1 e0 18                     	shl	eax, 0x18
 1004107: 0d ff ff ff 00               	or	eax, 0xffffff
 100410c: 50                           	push	eax
 100410d: 83 ec 0c                     	sub	esp, 0xc
 1004110: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004116: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100411e: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004124: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004129: 6a 01                        	push	0x1
 100412b: e8 a0 0a 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 1004130: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 1004133: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 1004136: 50                           	push	eax
 1004137: 83 c1 23                     	add	ecx, 0x23
 100413a: 51                           	push	ecx
 100413b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1004141: 83 c2 7d                     	add	edx, 0x7d
 1004144: 52                           	push	edx
 1004145: e8 96 00 1b 00               	call	0x11b41e0 <.text+0x1b0480>
 100414a: 5e                           	pop	esi
 100414b: 5d                           	pop	ebp
 100414c: c2 04 00                     	ret	0x4
 100414f: cc                           	int3
 1004150: 55                           	push	ebp
 1004151: 8b ec                        	mov	ebp, esp
 1004153: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 100415b: 53                           	push	ebx
 100415c: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
 100415f: 56                           	push	esi
 1004160: 83 ec 08                     	sub	esp, 0x8
 1004163: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004169: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100416e: 0f 57 c0                     	xorps	xmm0, xmm0
 1004171: 0f b6 c3                     	movzx	eax, bl
 1004174: c1 e0 18                     	shl	eax, 0x18
 1004177: 0d ff ff ff 00               	or	eax, 0xffffff
 100417c: 50                           	push	eax
 100417d: 83 ec 0c                     	sub	esp, 0xc
 1004180: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004186: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100418e: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004194: 8b f1                        	mov	esi, ecx
 1004196: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 1004199: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100419e: 6a 00                        	push	0x0
 10041a0: e8 2b 0a 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 10041a5: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 10041a8: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 10041ab: 50                           	push	eax
 10041ac: 51                           	push	ecx
 10041ad: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 10041b3: 52                           	push	edx
 10041b4: e8 27 00 1b 00               	call	0x11b41e0 <.text+0x1b0480>
 10041b9: 53                           	push	ebx
 10041ba: 8b ce                        	mov	ecx, esi
 10041bc: e8 2f fe ff ff               	call	0x1003ff0 <.text+0x290>
 10041c1: 53                           	push	ebx
 10041c2: 8b ce                        	mov	ecx, esi
 10041c4: e8 d7 fe ff ff               	call	0x10040a0 <.text+0x340>
 10041c9: 53                           	push	ebx
 10041ca: 8b ce                        	mov	ecx, esi
 10041cc: e8 ff fc ff ff               	call	0x1003ed0 <.text+0x170>
 10041d1: 5e                           	pop	esi
 10041d2: 5b                           	pop	ebx
 10041d3: 5d                           	pop	ebp
 10041d4: c2 04 00                     	ret	0x4
 10041d7: cc                           	int3
 10041d8: cc                           	int3
 10041d9: cc                           	int3
 10041da: cc                           	int3
 10041db: cc                           	int3
 10041dc: cc                           	int3
 10041dd: cc                           	int3
 10041de: cc                           	int3
 10041df: cc                           	int3
 10041e0: 56                           	push	esi
 10041e1: 8b f1                        	mov	esi, ecx
 10041e3: 8b 46 04                     	mov	eax, dword ptr [esi + 0x4]
 10041e6: 48                           	dec	eax
 10041e7: 83 f8 07                     	cmp	eax, 0x7
 10041ea: 0f 87 8b 03 00 00            	ja	0x100457b <.text+0x81b>
 10041f0: 53                           	push	ebx
 10041f1: 57                           	push	edi
 10041f2: ff 24 85 80 45 00 01         	jmp	dword ptr [4*eax + 0x1004580]
 10041f9: ff 46 10                     	inc	dword ptr [esi + 0x10]
 10041fc: 83 7e 10 3c                  	cmp	dword ptr [esi + 0x10], 0x3c
 1004200: 0f 8e 73 03 00 00            	jle	0x1004579 <.text+0x819>
 1004206: c7 46 04 02 00 00 00         	mov	dword ptr [esi + 0x4], 0x2
 100420d: ff 15 88 a5 55 01            	call	dword ptr [0x155a588]
 1004213: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 1004216: 8b 46 34                     	mov	eax, dword ptr [esi + 0x34]
 1004219: b3 08                        	mov	bl, 0x8
 100421b: bf f7 ff ff ff               	mov	edi, 0xfffffff7
 1004220: 84 98 ec 01 00 00            	test	byte ptr [eax + 0x1ec], bl
 1004226: 74 10                        	je	0x1004238 <.text+0x4d8>
 1004228: 21 b8 ec 01 00 00            	and	dword ptr [eax + 0x1ec], edi
 100422e: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 1004231: 6a 01                        	push	0x1
 1004233: e8 f8 70 09 00               	call	0x109b330 <.text+0x975d0>
 1004238: 8b 46 38                     	mov	eax, dword ptr [esi + 0x38]
 100423b: 84 98 ec 01 00 00            	test	byte ptr [eax + 0x1ec], bl
 1004241: 0f 84 32 03 00 00            	je	0x1004579 <.text+0x819>
 1004247: 21 b8 ec 01 00 00            	and	dword ptr [eax + 0x1ec], edi
 100424d: 8b 4e 38                     	mov	ecx, dword ptr [esi + 0x38]
 1004250: 6a 01                        	push	0x1
 1004252: e8 d9 70 09 00               	call	0x109b330 <.text+0x975d0>
 1004257: 5f                           	pop	edi
 1004258: 5b                           	pop	ebx
 1004259: 5e                           	pop	esi
 100425a: c3                           	ret
 100425b: 8b 3d 88 a5 55 01            	mov	edi, dword ptr [0x155a588]
 1004261: ff d7                        	call	edi
 1004263: 8b c8                        	mov	ecx, eax
 1004265: 2b 4e 10                     	sub	ecx, dword ptr [esi + 0x10]
 1004268: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 1004270: 69 c9 ff 00 00 00            	imul	ecx, ecx, 0xff
 1004276: b8 d3 4d 62 10               	mov	eax, 0x10624dd3
 100427b: f7 e1                        	mul	ecx
 100427d: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 1004280: 8b da                        	mov	ebx, edx
 1004282: c1 eb 07                     	shr	ebx, 0x7
 1004285: 83 ec 08                     	sub	esp, 0x8
 1004288: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 100428e: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004293: 0f 57 c0                     	xorps	xmm0, xmm0
 1004296: 0f b6 d3                     	movzx	edx, bl
 1004299: c1 e2 18                     	shl	edx, 0x18
 100429c: 81 ca ff ff ff 00            	or	edx, 0xffffff
 10042a2: 52                           	push	edx
 10042a3: 83 ec 0c                     	sub	esp, 0xc
 10042a6: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 10042ac: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 10042b4: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 10042ba: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 10042bf: 6a 00                        	push	0x0
 10042c1: e8 0a 09 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 10042c6: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
 10042c9: 50                           	push	eax
 10042ca: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
 10042cd: 50                           	push	eax
 10042ce: 51                           	push	ecx
 10042cf: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 10042d5: e8 06 ff 1a 00               	call	0x11b41e0 <.text+0x1b0480>
 10042da: 81 fb c8 00 00 00            	cmp	ebx, 0xc8
 10042e0: 7e 35                        	jle	0x1004317 <.text+0x5b7>
 10042e2: 8b 46 34                     	mov	eax, dword ptr [esi + 0x34]
 10042e5: f6 80 ec 01 00 00 08         	test	byte ptr [eax + 0x1ec], 0x8
 10042ec: 74 11                        	je	0x10042ff <.text+0x59f>
 10042ee: 83 a0 ec 01 00 00 f7         	and	dword ptr [eax + 0x1ec], -0x9
 10042f5: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 10042f8: 6a 01                        	push	0x1
 10042fa: e8 31 70 09 00               	call	0x109b330 <.text+0x975d0>
 10042ff: 68 ff 00 00 00               	push	0xff
 1004304: 8b ce                        	mov	ecx, esi
 1004306: e8 e5 fc ff ff               	call	0x1003ff0 <.text+0x290>
 100430b: 68 ff 00 00 00               	push	0xff
 1004310: 8b ce                        	mov	ecx, esi
 1004312: e8 89 fd ff ff               	call	0x10040a0 <.text+0x340>
 1004317: 81 fb ff 00 00 00            	cmp	ebx, 0xff
 100431d: 0f 8e 56 02 00 00            	jle	0x1004579 <.text+0x819>
 1004323: c7 46 04 04 00 00 00         	mov	dword ptr [esi + 0x4], 0x4
 100432a: ff d7                        	call	edi
 100432c: 5f                           	pop	edi
 100432d: 5b                           	pop	ebx
 100432e: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 1004331: 5e                           	pop	esi
 1004332: c3                           	ret
 1004333: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 100433b: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 100433e: 83 ec 08                     	sub	esp, 0x8
 1004341: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004347: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100434c: 0f 57 c0                     	xorps	xmm0, xmm0
 100434f: 6a ff                        	push	-0x1
 1004351: 83 ec 0c                     	sub	esp, 0xc
 1004354: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 100435a: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 1004362: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004368: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100436d: 6a 00                        	push	0x0
 100436f: e8 5c 08 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 1004374: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
 1004377: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 100437d: 50                           	push	eax
 100437e: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 1004381: 52                           	push	edx
 1004382: 50                           	push	eax
 1004383: e8 58 fe 1a 00               	call	0x11b41e0 <.text+0x1b0480>
 1004388: 68 ff 00 00 00               	push	0xff
 100438d: 8b ce                        	mov	ecx, esi
 100438f: e8 5c fc ff ff               	call	0x1003ff0 <.text+0x290>
 1004394: 68 ff 00 00 00               	push	0xff
 1004399: 8b ce                        	mov	ecx, esi
 100439b: e8 00 fd ff ff               	call	0x10040a0 <.text+0x340>
 10043a0: 8b 7e 38                     	mov	edi, dword ptr [esi + 0x38]
 10043a3: 8b cf                        	mov	ecx, edi
 10043a5: e8 56 f6 3f ff               	call	0x403a00
 10043aa: 8b c8                        	mov	ecx, eax
 10043ac: 03 c9                        	add	ecx, ecx
 10043ae: 03 c9                        	add	ecx, ecx
 10043b0: 03 c9                        	add	ecx, ecx
 10043b2: b8 67 66 66 66               	mov	eax, 0x66666667
 10043b7: f7 e9                        	imul	ecx
 10043b9: c1 fa 02                     	sar	edx, 0x2
 10043bc: 8b ca                        	mov	ecx, edx
 10043be: c1 e9 1f                     	shr	ecx, 0x1f
 10043c1: 03 ca                        	add	ecx, edx
 10043c3: 39 8f 44 01 00 00            	cmp	dword ptr [edi + 0x144], ecx
 10043c9: 0f 8c aa 01 00 00            	jl	0x1004579 <.text+0x819>
 10043cf: c7 46 04 05 00 00 00         	mov	dword ptr [esi + 0x4], 0x5
 10043d6: ff 15 88 a5 55 01            	call	dword ptr [0x155a588]
 10043dc: 5f                           	pop	edi
 10043dd: 5b                           	pop	ebx
 10043de: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 10043e1: 5e                           	pop	esi
 10043e2: c3                           	ret
 10043e3: 8b 1d 88 a5 55 01            	mov	ebx, dword ptr [0x155a588]
 10043e9: ff d3                        	call	ebx
 10043eb: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 10043f3: 8b d0                        	mov	edx, eax
 10043f5: 2b 56 10                     	sub	edx, dword ptr [esi + 0x10]
 10043f8: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 10043fb: 69 d2 ff 00 00 00            	imul	edx, edx, 0xff
 1004401: 83 ec 08                     	sub	esp, 0x8
 1004404: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 100440a: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100440f: 0f 57 c0                     	xorps	xmm0, xmm0
 1004412: b8 d3 4d 62 10               	mov	eax, 0x10624dd3
 1004417: f7 e2                        	mul	edx
 1004419: 6a ff                        	push	-0x1
 100441b: 83 ec 0c                     	sub	esp, 0xc
 100441e: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004424: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100442c: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004432: 8b fa                        	mov	edi, edx
 1004434: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004439: 6a 00                        	push	0x0
 100443b: c1 ef 05                     	shr	edi, 0x5
 100443e: e8 8d 07 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 1004443: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
 1004446: 50                           	push	eax
 1004447: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
 100444a: 50                           	push	eax
 100444b: 51                           	push	ecx
 100444c: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1004452: e8 89 fd 1a 00               	call	0x11b41e0 <.text+0x1b0480>
 1004457: 68 ff 00 00 00               	push	0xff
 100445c: 8b ce                        	mov	ecx, esi
 100445e: e8 8d fb ff ff               	call	0x1003ff0 <.text+0x290>
 1004463: 68 ff 00 00 00               	push	0xff
 1004468: 8b ce                        	mov	ecx, esi
 100446a: e8 31 fc ff ff               	call	0x10040a0 <.text+0x340>
 100446f: 57                           	push	edi
 1004470: 8b ce                        	mov	ecx, esi
 1004472: e8 59 fa ff ff               	call	0x1003ed0 <.text+0x170>
 1004477: 81 ff ff 00 00 00            	cmp	edi, 0xff
 100447d: 0f 8e f6 00 00 00            	jle	0x1004579 <.text+0x819>
 1004483: c7 46 04 06 00 00 00         	mov	dword ptr [esi + 0x4], 0x6
 100448a: ff d3                        	call	ebx
 100448c: 5f                           	pop	edi
 100448d: 5b                           	pop	ebx
 100448e: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 1004491: 5e                           	pop	esi
 1004492: c3                           	ret
 1004493: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 100449b: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 100449e: 83 ec 08                     	sub	esp, 0x8
 10044a1: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 10044a7: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 10044ac: 0f 57 c0                     	xorps	xmm0, xmm0
 10044af: 6a ff                        	push	-0x1
 10044b1: 83 ec 0c                     	sub	esp, 0xc
 10044b4: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 10044ba: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 10044c2: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 10044c8: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 10044cd: 6a 00                        	push	0x0
 10044cf: e8 fc 06 1b 00               	call	0x11b4bd0 <.text+0x1b0e70>
 10044d4: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
 10044d7: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 10044dd: 50                           	push	eax
 10044de: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 10044e1: 52                           	push	edx
 10044e2: 50                           	push	eax
 10044e3: e8 f8 fc 1a 00               	call	0x11b41e0 <.text+0x1b0480>
 10044e8: 68 ff 00 00 00               	push	0xff
 10044ed: 8b ce                        	mov	ecx, esi
 10044ef: e8 fc fa ff ff               	call	0x1003ff0 <.text+0x290>
 10044f4: 68 ff 00 00 00               	push	0xff
 10044f9: 8b ce                        	mov	ecx, esi
 10044fb: e8 a0 fb ff ff               	call	0x10040a0 <.text+0x340>
 1004500: 68 ff 00 00 00               	push	0xff
 1004505: 8b ce                        	mov	ecx, esi
 1004507: e8 c4 f9 ff ff               	call	0x1003ed0 <.text+0x170>
 100450c: 8b 3d 88 a5 55 01            	mov	edi, dword ptr [0x155a588]
 1004512: ff d7                        	call	edi
 1004514: 2b 46 10                     	sub	eax, dword ptr [esi + 0x10]
 1004517: 3d d0 07 00 00               	cmp	eax, 0x7d0
 100451c: 76 5b                        	jbe	0x1004579 <.text+0x819>
 100451e: c7 46 04 07 00 00 00         	mov	dword ptr [esi + 0x4], 0x7
 1004525: ff d7                        	call	edi
 1004527: 5f                           	pop	edi
 1004528: 5b                           	pop	ebx
 1004529: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 100452c: 5e                           	pop	esi
 100452d: c3                           	ret
 100452e: 8b 3d 88 a5 55 01            	mov	edi, dword ptr [0x155a588]
 1004534: ff d7                        	call	edi
 1004536: 8b c8                        	mov	ecx, eax
 1004538: 2b 4e 10                     	sub	ecx, dword ptr [esi + 0x10]
 100453b: b8 d3 4d 62 10               	mov	eax, 0x10624dd3
 1004540: 69 c9 ff 00 00 00            	imul	ecx, ecx, 0xff
 1004546: f7 e1                        	mul	ecx
 1004548: c1 ea 06                     	shr	edx, 0x6
 100454b: b8 ff 00 00 00               	mov	eax, 0xff
 1004550: 2b c2                        	sub	eax, edx
 1004552: 85 c0                        	test	eax, eax
 1004554: 7f 10                        	jg	0x1004566 <.text+0x806>
 1004556: c7 46 04 08 00 00 00         	mov	dword ptr [esi + 0x4], 0x8
 100455d: ff d7                        	call	edi
 100455f: 5f                           	pop	edi
 1004560: 5b                           	pop	ebx
 1004561: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 1004564: 5e                           	pop	esi
 1004565: c3                           	ret
 1004566: 50                           	push	eax
 1004567: 8b ce                        	mov	ecx, esi
 1004569: e8 e2 fb ff ff               	call	0x1004150 <.text+0x3f0>
 100456e: 5f                           	pop	edi
 100456f: 5b                           	pop	ebx
 1004570: 5e                           	pop	esi
 1004571: c3                           	ret
 1004572: c7 46 04 00 00 00 00         	mov	dword ptr [esi + 0x4], 0x0
 1004579: 5f                           	pop	edi
 100457a: 5b                           	pop	ebx
 100457b: 5e                           	pop	esi
 100457c: c3                           	ret
 100457d: 8d 49 00                     	lea	ecx, [ecx]
 1004580: f9                           	stc
 1004581: 41                           	inc	ecx
 1004582: 00 01                        	add	byte ptr [ecx], al
 1004584: 5b                           	pop	ebx
 1004585: 42                           	inc	edx
 1004586: 00 01                        	add	byte ptr [ecx], al
 1004588: 79 45                        	jns	0x10045cf <.text+0x86f>
 100458a: 00 01                        	add	byte ptr [ecx], al
 100458c: 33 43 00                     	xor	eax, dword ptr [ebx]
 100458f: 01 e3                        	add	ebx, esp
 1004591: 43                           	inc	ebx
 1004592: 00 01                        	add	byte ptr [ecx], al
 1004594: 93                           	xchg	eax, ebx
 1004595: 44                           	inc	esp
 1004596: 00 01                        	add	byte ptr [ecx], al
 1004598: 2e 45                        	inc	ebp
 100459a: 00 01                        	add	byte ptr [ecx], al
 100459c: 72 45                        	jb	0x10045e3 <.text+0x883>
 100459e: 00 01                        	add	byte ptr [ecx], al
 10045a0: 55                           	push	ebp
 10045a1: 8b ec                        	mov	ebp, esp
 10045a3: 83 ec 14                     	sub	esp, 0x14
 10045a6: 56                           	push	esi
 10045a7: 8b f1                        	mov	esi, ecx
 10045a9: 57                           	push	edi
 10045aa: 8b be 3c 02 00 00            	mov	edi, dword ptr [esi + 0x23c]
 10045b0: 83 ff 0a                     	cmp	edi, 0xa
 10045b3: 0f 87 14 02 00 00            	ja	0x10047cd <.text+0xa6d>
 10045b9: 8b 8e 8c 02 00 00            	mov	ecx, dword ptr [esi + 0x28c]
 10045bf: 85 c9                        	test	ecx, ecx
 10045c1: 74 07                        	je	0x10045ca <.text+0x86a>
 10045c3: 6a 01                        	push	0x1
 10045c5: e8 a6 51 8a ff               	call	0x8a9770
 10045ca: 83 3c be 00                  	cmp	dword ptr [esi + 4*edi], 0x0
 10045ce: 0f 84 f9 01 00 00            	je	0x10047cd <.text+0xa6d>
 10045d4: f3 0f 10 05 ec 3b 9f 01      	movss	xmm0, dword ptr [0x19f3bec]
 10045dc: f3 0f 11 45 ec               	movss	dword ptr [ebp - 0x14], xmm0
 10045e1: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 10045e9: f3 0f 11 05 ec 3b 9f 01      	movss	dword ptr [0x19f3bec], xmm0
 10045f1: 8b 86 40 02 00 00            	mov	eax, dword ptr [esi + 0x240]
 10045f7: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 10045fa: 53                           	push	ebx
 10045fb: 85 c0                        	test	eax, eax
 10045fd: 75 12                        	jne	0x1004611 <.text+0x8b1>
 10045ff: 8b 01                        	mov	eax, dword ptr [ecx]
 1004601: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 1004607: ff d2                        	call	edx
 1004609: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
 100460c: e9 b4 00 00 00               	jmp	0x10046c5 <.text+0x965>
 1004611: 83 f8 02                     	cmp	eax, 0x2
 1004614: 75 27                        	jne	0x100463d <.text+0x8dd>
 1004616: 8b 11                        	mov	edx, dword ptr [ecx]
 1004618: 8b 82 fc 01 00 00            	mov	eax, dword ptr [edx + 0x1fc]
 100461e: ff d0                        	call	eax
 1004620: 8b 58 04                     	mov	ebx, dword ptr [eax + 0x4]
 1004623: 8b cb                        	mov	ecx, ebx
 1004625: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
 1004628: e8 73 a8 08 00               	call	0x108eea0 <.text+0x8b140>
 100462d: 8b 4b 68                     	mov	ecx, dword ptr [ebx + 0x68]
 1004630: 51                           	push	ecx
 1004631: 8b cb                        	mov	ecx, ebx
 1004633: e8 58 83 09 00               	call	0x109c990 <.text+0x98c30>
 1004638: e9 8b 00 00 00               	jmp	0x10046c8 <.text+0x968>
 100463d: 83 f8 03                     	cmp	eax, 0x3
 1004640: 75 77                        	jne	0x10046b9 <.text+0x959>
 1004642: 8b 11                        	mov	edx, dword ptr [ecx]
 1004644: 8b 82 fc 01 00 00            	mov	eax, dword ptr [edx + 0x1fc]
 100464a: ff d0                        	call	eax
 100464c: 8b 48 0c                     	mov	ecx, dword ptr [eax + 0xc]
 100464f: 8d 1c 7f                     	lea	ebx, [edi + 2*edi]
 1004652: 03 db                        	add	ebx, ebx
 1004654: 8b 94 1b 60 b2 82 01         	mov	edx, dword ptr [ebx + ebx + 0x182b260]
 100465b: 89 4d fc                     	mov	dword ptr [ebp - 0x4], ecx
 100465e: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004661: 8b 01                        	mov	eax, dword ptr [ecx]
 1004663: 03 db                        	add	ebx, ebx
 1004665: 89 55 f8                     	mov	dword ptr [ebp - 0x8], edx
 1004668: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 100466e: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
 1004671: ff d2                        	call	edx
 1004673: 8b 40 0c                     	mov	eax, dword ptr [eax + 0xc]
 1004676: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
 1004679: 51                           	push	ecx
 100467a: 8b c8                        	mov	ecx, eax
 100467c: 89 45 f4                     	mov	dword ptr [ebp - 0xc], eax
 100467f: e8 7c bf 08 00               	call	0x1090600 <.text+0x8c8a0>
 1004684: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1004687: 50                           	push	eax
 1004688: e8 03 83 09 00               	call	0x109c990 <.text+0x98c30>
 100468d: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004690: 8b 11                        	mov	edx, dword ptr [ecx]
 1004692: 8b 82 fc 01 00 00            	mov	eax, dword ptr [edx + 0x1fc]
 1004698: ff d0                        	call	eax
 100469a: 8b 48 0c                     	mov	ecx, dword ptr [eax + 0xc]
 100469d: e8 ae 80 62 ff               	call	0x62c750
 10046a2: 8b 8b 64 b2 82 01            	mov	ecx, dword ptr [ebx + 0x182b264]
 10046a8: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
 10046ab: 8b 55 f0                     	mov	edx, dword ptr [ebp - 0x10]
 10046ae: 01 4d 08                     	add	dword ptr [ebp + 0x8], ecx
 10046b1: 03 9a 68 b2 82 01            	add	ebx, dword ptr [edx + 0x182b268]
 10046b7: eb 12                        	jmp	0x10046cb <.text+0x96b>
 10046b9: 8b 01                        	mov	eax, dword ptr [ecx]
 10046bb: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 10046c1: ff d2                        	call	edx
 10046c3: 8b 00                        	mov	eax, dword ptr [eax]
 10046c5: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
 10046c8: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
 10046cb: 83 7d fc 00                  	cmp	dword ptr [ebp - 0x4], 0x0
 10046cf: 0f 84 ea 00 00 00            	je	0x10047bf <.text+0xa5f>
 10046d5: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 10046d8: 8b 11                        	mov	edx, dword ptr [ecx]
 10046da: 8b 01                        	mov	eax, dword ptr [ecx]
 10046dc: 89 55 0c                     	mov	dword ptr [ebp + 0xc], edx
 10046df: 8b 90 ac 00 00 00            	mov	edx, dword ptr [eax + 0xac]
 10046e5: ff d2                        	call	edx
 10046e7: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
 10046ea: 8b 55 0c                     	mov	edx, dword ptr [ebp + 0xc]
 10046ed: 50                           	push	eax
 10046ee: 8d 83 69 ff ff ff            	lea	eax, [ebx - 0x97]
 10046f4: 50                           	push	eax
 10046f5: 8b 82 98 00 00 00            	mov	eax, dword ptr [edx + 0x98]
 10046fb: 51                           	push	ecx
 10046fc: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 10046ff: ff d0                        	call	eax
 1004701: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
 1004704: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
 1004707: 51                           	push	ecx
 1004708: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 100470b: 53                           	push	ebx
 100470c: 52                           	push	edx
 100470d: 6a 00                        	push	0x0
 100470f: e8 ac 1d 81 ff               	call	0x8164c0
 1004714: e8 57 48 80 ff               	call	0x808f70
 1004719: 84 c0                        	test	al, al
 100471b: 0f 84 b4 00 00 00            	je	0x10047d5 <.text+0xa75>
 1004721: 80 be 88 02 00 00 00         	cmp	byte ptr [esi + 0x288], 0x0
 1004728: 0f 84 a7 00 00 00            	je	0x10047d5 <.text+0xa75>
 100472e: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
 1004731: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004734: 6a 01                        	push	0x1
 1004736: 53                           	push	ebx
 1004737: 50                           	push	eax
 1004738: 6a 00                        	push	0x0
 100473a: c6 45 0f 01                  	mov	byte ptr [ebp + 0xf], 0x1
 100473e: e8 0d da 80 ff               	call	0x812150
 1004743: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
 1004746: 8b 96 3c 02 00 00            	mov	edx, dword ptr [esi + 0x23c]
 100474c: 8b 04 96                     	mov	eax, dword ptr [esi + 4*edx]
 100474f: 53                           	push	ebx
 1004750: 51                           	push	ecx
 1004751: 50                           	push	eax
 1004752: 6a 00                        	push	0x0
 1004754: e8 57 56 00 00               	call	0x1009db0 <.text+0x6050>
 1004759: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
 100475c: 83 c4 10                     	add	esp, 0x10
 100475f: e8 5c 7d 09 00               	call	0x109c4c0 <.text+0x98760>
 1004764: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
 1004767: 8b 15 2c 58 b5 01            	mov	edx, dword ptr [0x1b5582c]
 100476d: 6a 01                        	push	0x1
 100476f: 6a 00                        	push	0x0
 1004771: 53                           	push	ebx
 1004772: 51                           	push	ecx
 1004773: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
 1004776: 52                           	push	edx
 1004777: e8 04 1e 09 00               	call	0x1096580 <.text+0x92820>
 100477c: 80 7d 0f 00                  	cmp	byte ptr [ebp + 0xf], 0x0
 1004780: 74 11                        	je	0x1004793 <.text+0xa33>
 1004782: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
 1004785: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004788: 6a 01                        	push	0x1
 100478a: 53                           	push	ebx
 100478b: 50                           	push	eax
 100478c: 6a 01                        	push	0x1
 100478e: e8 bd d9 80 ff               	call	0x812150
 1004793: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
 1004796: 8b 96 3c 02 00 00            	mov	edx, dword ptr [esi + 0x23c]
 100479c: 8b 04 96                     	mov	eax, dword ptr [esi + 4*edx]
 100479f: 53                           	push	ebx
 10047a0: 51                           	push	ecx
 10047a1: 50                           	push	eax
 10047a2: 6a 01                        	push	0x1
 10047a4: e8 07 56 00 00               	call	0x1009db0 <.text+0x6050>
 10047a9: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
 10047ac: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
 10047af: 83 c4 10                     	add	esp, 0x10
 10047b2: 51                           	push	ecx
 10047b3: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 10047b6: 53                           	push	ebx
 10047b7: 52                           	push	edx
 10047b8: 6a 01                        	push	0x1
 10047ba: e8 01 1d 81 ff               	call	0x8164c0
 10047bf: f3 0f 10 45 ec               	movss	xmm0, dword ptr [ebp - 0x14]
 10047c4: f3 0f 11 05 ec 3b 9f 01      	movss	dword ptr [0x19f3bec], xmm0
 10047cc: 5b                           	pop	ebx
 10047cd: 5f                           	pop	edi
 10047ce: 5e                           	pop	esi
 10047cf: 8b e5                        	mov	esp, ebp
 10047d1: 5d                           	pop	ebp
 10047d2: c2 08 00                     	ret	0x8
 10047d5: c6 45 0f 00                  	mov	byte ptr [ebp + 0xf], 0x0
 10047d9: e9 65 ff ff ff               	jmp	0x1004743 <.text+0x9e3>
 10047de: cc                           	int3
 10047df: cc                           	int3
 10047e0: 55                           	push	ebp
 10047e1: 8b ec                        	mov	ebp, esp
 10047e3: 8b 81 3c 02 00 00            	mov	eax, dword ptr [ecx + 0x23c]
 10047e9: 85 c0                        	test	eax, eax
 10047eb: 78 1a                        	js	0x1004807 <.text+0xaa7>
 10047ed: 83 f8 0b                     	cmp	eax, 0xb
 10047f0: 7d 15                        	jge	0x1004807 <.text+0xaa7>
 10047f2: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
 10047f5: 83 fa 0a                     	cmp	edx, 0xa
 10047f8: 77 0d                        	ja	0x1004807 <.text+0xaa7>
 10047fa: 40                           	inc	eax
 10047fb: 6b c0 0b                     	imul	eax, eax, 0xb
 10047fe: 03 c2                        	add	eax, edx
 1004800: 8b 04 81                     	mov	eax, dword ptr [ecx + 4*eax]
 1004803: 5d                           	pop	ebp
 1004804: c2 04 00                     	ret	0x4
 1004807: 33 c0                        	xor	eax, eax
 1004809: 5d                           	pop	ebp
 100480a: c2 04 00                     	ret	0x4
 100480d: cc                           	int3
 100480e: cc                           	int3
 100480f: cc                           	int3
 1004810: 53                           	push	ebx
 1004811: 56                           	push	esi
 1004812: 8b d9                        	mov	ebx, ecx
 1004814: 57                           	push	edi
 1004815: 33 ff                        	xor	edi, edi
 1004817: 8d 73 2c                     	lea	esi, [ebx + 0x2c]
 100481a: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
 1004820: 8b 0c bb                     	mov	ecx, dword ptr [ebx + 4*edi]
 1004823: 85 c9                        	test	ecx, ecx
 1004825: 74 08                        	je	0x100482f <.text+0xacf>
 1004827: 8b 01                        	mov	eax, dword ptr [ecx]
 1004829: 8b 10                        	mov	edx, dword ptr [eax]
 100482b: 6a 01                        	push	0x1
 100482d: ff d2                        	call	edx
 100482f: c7 04 bb 00 00 00 00         	mov	dword ptr [ebx + 4*edi], 0x0
 1004836: 66 0f ef c0                  	pxor	xmm0, xmm0
 100483a: 66 0f d6 06                  	movq	qword ptr [esi], xmm0
 100483e: 66 0f d6 46 08               	movq	qword ptr [esi + 0x8], xmm0
 1004843: 66 0f d6 46 10               	movq	qword ptr [esi + 0x10], xmm0
 1004848: 66 0f d6 46 18               	movq	qword ptr [esi + 0x18], xmm0
 100484d: 66 0f d6 46 20               	movq	qword ptr [esi + 0x20], xmm0
 1004852: c7 46 28 00 00 00 00         	mov	dword ptr [esi + 0x28], 0x0
 1004859: 47                           	inc	edi
 100485a: 83 c6 2c                     	add	esi, 0x2c
 100485d: 83 ff 0b                     	cmp	edi, 0xb
 1004860: 7c be                        	jl	0x1004820 <.text+0xac0>
 1004862: 5f                           	pop	edi
 1004863: 5e                           	pop	esi
 1004864: 5b                           	pop	ebx
 1004865: c3                           	ret
 1004866: cc                           	int3
 1004867: cc                           	int3
 1004868: cc                           	int3
 1004869: cc                           	int3
 100486a: cc                           	int3
 100486b: cc                           	int3
 100486c: cc                           	int3
 100486d: cc                           	int3
 100486e: cc                           	int3
 100486f: cc                           	int3
 1004870: 55                           	push	ebp
 1004871: 8b ec                        	mov	ebp, esp
 1004873: 8b 81 3c 02 00 00            	mov	eax, dword ptr [ecx + 0x23c]
 1004879: 8b 14 81                     	mov	edx, dword ptr [ecx + 4*eax]
 100487c: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
 100487f: 39 82 a8 09 00 00            	cmp	dword ptr [edx + 0x9a8], eax
 1004885: 74 26                        	je	0x10048ad <.text+0xb4d>
 1004887: 8b 91 3c 02 00 00            	mov	edx, dword ptr [ecx + 0x23c]
 100488d: 8b 14 91                     	mov	edx, dword ptr [ecx + 4*edx]
 1004890: 6a 01                        	push	0x1
 1004892: 50                           	push	eax
 1004893: 89 82 a8 09 00 00            	mov	dword ptr [edx + 0x9a8], eax
 1004899: 8b 81 3c 02 00 00            	mov	eax, dword ptr [ecx + 0x23c]
 100489f: 8b 0c 81                     	mov	ecx, dword ptr [ecx + 4*eax]
 10048a2: 51                           	push	ecx
 10048a3: 6a 00                        	push	0x0
 10048a5: e8 26 53 00 00               	call	0x1009bd0 <.text+0x5e70>
 10048aa: 83 c4 10                     	add	esp, 0x10
 10048ad: 5d                           	pop	ebp
 10048ae: c2 04 00                     	ret	0x4
 10048b1: cc                           	int3
 10048b2: cc                           	int3
 10048b3: cc                           	int3
 10048b4: cc                           	int3
 10048b5: cc                           	int3
 10048b6: cc                           	int3
 10048b7: cc                           	int3
 10048b8: cc                           	int3
 10048b9: cc                           	int3
 10048ba: cc                           	int3
 10048bb: cc                           	int3
 10048bc: cc                           	int3
 10048bd: cc                           	int3
 10048be: cc                           	int3
 10048bf: cc                           	int3
 10048c0: 8b 81 3c 02 00 00            	mov	eax, dword ptr [ecx + 0x23c]
 10048c6: 8b 0c 81                     	mov	ecx, dword ptr [ecx + 4*eax]
 10048c9: 8b 81 a8 09 00 00            	mov	eax, dword ptr [ecx + 0x9a8]
 10048cf: c3                           	ret
 10048d0: 55                           	push	ebp
 10048d1: 8b ec                        	mov	ebp, esp
 10048d3: 6a ff                        	push	-0x1
 10048d5: 68 9b 2d 4b 01               	push	0x14b2d9b
 10048da: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 10048e0: 50                           	push	eax
 10048e1: 81 ec 2c 03 00 00            	sub	esp, 0x32c
 10048e7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 10048ec: 33 c5                        	xor	eax, ebp
 10048ee: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
 10048f1: 56                           	push	esi
 10048f2: 57                           	push	edi
 10048f3: 50                           	push	eax
 10048f4: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 10048f7: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 10048fd: 8b 75 08                     	mov	esi, dword ptr [ebp + 0x8]
 1004900: 8b f9                        	mov	edi, ecx
 1004902: 8d 8d c8 fc ff ff            	lea	ecx, [ebp - 0x338]
 1004908: e8 23 35 2b 00               	call	0x12b7e30 <.text+0x2b40d0>
 100490d: 8b 0c b7                     	mov	ecx, dword ptr [edi + 4*esi]
 1004910: 89 b5 cc fc ff ff            	mov	dword ptr [ebp - 0x334], esi
 1004916: 8b 01                        	mov	eax, dword ptr [ecx]
 1004918: 8b 80 00 02 00 00            	mov	eax, dword ptr [eax + 0x200]
 100491e: 6a 01                        	push	0x1
 1004920: 8d 95 c8 fc ff ff            	lea	edx, [ebp - 0x338]
 1004926: 52                           	push	edx
 1004927: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
 100492e: ff d0                        	call	eax
 1004930: 8b 0c b7                     	mov	ecx, dword ptr [edi + 4*esi]
 1004933: 6a 00                        	push	0x0
 1004935: e8 26 d2 80 ff               	call	0x811b60
 100493a: 8d 8d c8 fc ff ff            	lea	ecx, [ebp - 0x338]
 1004940: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1004947: e8 24 55 40 ff               	call	0x409e70
 100494c: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 100494f: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1004956: 59                           	pop	ecx
 1004957: 5f                           	pop	edi
 1004958: 5e                           	pop	esi
 1004959: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
 100495c: 33 cd                        	xor	ecx, ebp
 100495e: e8 75 28 3d 00               	call	0x13d71d8 <.text+0x3d3478>
 1004963: 8b e5                        	mov	esp, ebp
 1004965: 5d                           	pop	ebp
 1004966: c2 04 00                     	ret	0x4
 1004969: cc                           	int3
 100496a: cc                           	int3
 100496b: cc                           	int3
 100496c: cc                           	int3
 100496d: cc                           	int3
 100496e: cc                           	int3
 100496f: cc                           	int3
 1004970: 55                           	push	ebp
 1004971: 8b ec                        	mov	ebp, esp
 1004973: 56                           	push	esi
 1004974: 8b f1                        	mov	esi, ecx
 1004976: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 100497c: e8 7f 06 92 ff               	call	0x925000
 1004981: 85 c0                        	test	eax, eax
 1004983: 0f 84 1b 01 00 00            	je	0x1004aa4 <.text+0xd44>
 1004989: 57                           	push	edi
 100498a: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
 100498d: 57                           	push	edi
 100498e: e8 1d f8 77 ff               	call	0x7841b0
 1004993: 83 c4 04                     	add	esp, 0x4
 1004996: 84 c0                        	test	al, al
 1004998: 75 09                        	jne	0x10049a3 <.text+0xc43>
 100499a: 83 ff 0a                     	cmp	edi, 0xa
 100499d: 0f 85 00 01 00 00            	jne	0x1004aa3 <.text+0xd43>
 10049a3: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 10049a9: e8 52 06 92 ff               	call	0x925000
 10049ae: 85 c0                        	test	eax, eax
 10049b0: 0f 84 ed 00 00 00            	je	0x1004aa3 <.text+0xd43>
 10049b6: 8b 86 3c 02 00 00            	mov	eax, dword ptr [esi + 0x23c]
 10049bc: 83 f8 0b                     	cmp	eax, 0xb
 10049bf: 0f 8d de 00 00 00            	jge	0x1004aa3 <.text+0xd43>
 10049c5: 40                           	inc	eax
 10049c6: 6b c0 0b                     	imul	eax, eax, 0xb
 10049c9: 03 c7                        	add	eax, edi
 10049cb: 83 3c 86 00                  	cmp	dword ptr [esi + 4*eax], 0x0
 10049cf: 8d 04 86                     	lea	eax, [esi + 4*eax]
 10049d2: 0f 84 cb 00 00 00            	je	0x1004aa3 <.text+0xd43>
 10049d8: 8b 08                        	mov	ecx, dword ptr [eax]
 10049da: e8 b1 45 78 ff               	call	0x788f90
 10049df: 8b 86 3c 02 00 00            	mov	eax, dword ptr [esi + 0x23c]
 10049e5: 40                           	inc	eax
 10049e6: 6b c0 0b                     	imul	eax, eax, 0xb
 10049e9: 03 c7                        	add	eax, edi
 10049eb: c7 04 86 00 00 00 00         	mov	dword ptr [esi + 4*eax], 0x0
 10049f2: 8b 8e 3c 02 00 00            	mov	ecx, dword ptr [esi + 0x23c]
 10049f8: 83 3c 8e 00                  	cmp	dword ptr [esi + 4*ecx], 0x0
 10049fc: 0f 84 84 00 00 00            	je	0x1004a86 <.text+0xd26>
 1004a02: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 1004a08: e8 f3 05 92 ff               	call	0x925000
 1004a0d: 8b 96 3c 02 00 00            	mov	edx, dword ptr [esi + 0x23c]
 1004a13: 3b 50 14                     	cmp	edx, dword ptr [eax + 0x14]
 1004a16: 75 45                        	jne	0x1004a5d <.text+0xcfd>
 1004a18: 53                           	push	ebx
 1004a19: 8b 9c b8 d9 01 00 00         	mov	ebx, dword ptr [eax + 4*edi + 0x1d9]
 1004a20: 8b 0c 96                     	mov	ecx, dword ptr [esi + 4*edx]
 1004a23: 8b 11                        	mov	edx, dword ptr [ecx]
 1004a25: 8b 92 04 02 00 00            	mov	edx, dword ptr [edx + 0x204]
 1004a2b: 6a ff                        	push	-0x1
 1004a2d: 53                           	push	ebx
 1004a2e: 0f b6 98 d8 01 00 00         	movzx	ebx, byte ptr [eax + 0x1d8]
 1004a35: 53                           	push	ebx
 1004a36: 8b 98 d4 01 00 00            	mov	ebx, dword ptr [eax + 0x1d4]
 1004a3c: 53                           	push	ebx
 1004a3d: 8b 9c b8 6c 01 00 00         	mov	ebx, dword ptr [eax + 4*edi + 0x16c]
 1004a44: 53                           	push	ebx
 1004a45: 8b 9c b8 04 01 00 00         	mov	ebx, dword ptr [eax + 4*edi + 0x104]
 1004a4c: 53                           	push	ebx
 1004a4d: 8b 5c f8 38                  	mov	ebx, dword ptr [eax + 8*edi + 0x38]
 1004a51: 8b 44 f8 34                  	mov	eax, dword ptr [eax + 8*edi + 0x34]
 1004a55: 53                           	push	ebx
 1004a56: 50                           	push	eax
 1004a57: 57                           	push	edi
 1004a58: ff d2                        	call	edx
 1004a5a: 5b                           	pop	ebx
 1004a5b: eb 29                        	jmp	0x1004a86 <.text+0xd26>
 1004a5d: 33 c0                        	xor	eax, eax
 1004a5f: 0f b7 c8                     	movzx	ecx, ax
 1004a62: 6a ff                        	push	-0x1
 1004a64: 8b c1                        	mov	eax, ecx
 1004a66: c1 e1 10                     	shl	ecx, 0x10
 1004a69: 0b c1                        	or	eax, ecx
 1004a6b: 8b 0c 96                     	mov	ecx, dword ptr [esi + 4*edx]
 1004a6e: 8b 11                        	mov	edx, dword ptr [ecx]
 1004a70: 50                           	push	eax
 1004a71: 8b 82 04 02 00 00            	mov	eax, dword ptr [edx + 0x204]
 1004a77: 6a 00                        	push	0x0
 1004a79: 6a 00                        	push	0x0
 1004a7b: 6a 00                        	push	0x0
 1004a7d: 6a ff                        	push	-0x1
 1004a7f: 6a 00                        	push	0x0
 1004a81: 6a ff                        	push	-0x1
 1004a83: 57                           	push	edi
 1004a84: ff d0                        	call	eax
 1004a86: 57                           	push	edi
 1004a87: e8 94 f7 77 ff               	call	0x784220
 1004a8c: 83 c4 04                     	add	esp, 0x4
 1004a8f: 3c 01                        	cmp	al, 0x1
 1004a91: 75 10                        	jne	0x1004aa3 <.text+0xd43>
 1004a93: 8b 8e 3c 02 00 00            	mov	ecx, dword ptr [esi + 0x23c]
 1004a99: 8b 0c 8e                     	mov	ecx, dword ptr [esi + 4*ecx]
 1004a9c: 6a 01                        	push	0x1
 1004a9e: e8 bd d0 80 ff               	call	0x811b60
 1004aa3: 5f                           	pop	edi
 1004aa4: 5e                           	pop	esi
 1004aa5: 5d                           	pop	ebp
 1004aa6: c2 04 00                     	ret	0x4
 1004aa9: cc                           	int3
 1004aaa: cc                           	int3
 1004aab: cc                           	int3
 1004aac: cc                           	int3
 1004aad: cc                           	int3
 1004aae: cc                           	int3
 1004aaf: cc                           	int3
 1004ab0: 55                           	push	ebp
 1004ab1: 8b ec                        	mov	ebp, esp
 1004ab3: 6a ff                        	push	-0x1
 1004ab5: 68 db 2d 4b 01               	push	0x14b2ddb
 1004aba: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1004ac0: 50                           	push	eax
 1004ac1: 81 ec 3c 03 00 00            	sub	esp, 0x33c
 1004ac7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 1004acc: 33 c5                        	xor	eax, ebp
 1004ace: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
 1004ad1: 53                           	push	ebx
 1004ad2: 56                           	push	esi
 1004ad3: 57                           	push	edi
 1004ad4: 50                           	push	eax
 1004ad5: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1004ad8: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 1004ade: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
 1004ae1: 8b f1                        	mov	esi, ecx
 1004ae3: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 1004ae9: 89 b5 bc fc ff ff            	mov	dword ptr [ebp - 0x344], esi
 1004aef: 89 9d b8 fc ff ff            	mov	dword ptr [ebp - 0x348], ebx
 1004af5: e8 06 05 92 ff               	call	0x925000
 1004afa: 83 c0 10                     	add	eax, 0x10
 1004afd: 50                           	push	eax
 1004afe: 8d 8d c8 fc ff ff            	lea	ecx, [ebp - 0x338]
 1004b04: e8 47 76 40 ff               	call	0x40c150
 1004b09: 43                           	inc	ebx
 1004b0a: 6b db 2c                     	imul	ebx, ebx, 0x2c
 1004b0d: 33 c0                        	xor	eax, eax
 1004b0f: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
 1004b12: c7 85 c0 fc ff ff ff ff ff ff	mov	dword ptr [ebp - 0x340], 0xffffffff
 1004b1c: 89 85 c4 fc ff ff            	mov	dword ptr [ebp - 0x33c], eax
 1004b22: 03 de                        	add	ebx, esi
 1004b24: 8b 33                        	mov	esi, dword ptr [ebx]
 1004b26: 85 f6                        	test	esi, esi
 1004b28: 74 68                        	je	0x1004b92 <.text+0xe32>
 1004b2a: 8b 06                        	mov	eax, dword ptr [esi]
 1004b2c: 8b 50 20                     	mov	edx, dword ptr [eax + 0x20]
 1004b2f: 8b ce                        	mov	ecx, esi
 1004b31: ff d2                        	call	edx
 1004b33: 6a 01                        	push	0x1
 1004b35: 6a 32                        	push	0x32
 1004b37: 8d 78 14                     	lea	edi, [eax + 0x14]
 1004b3a: 6a 04                        	push	0x4
 1004b3c: 57                           	push	edi
 1004b3d: e8 fe ca 3b 00               	call	0x13c1640 <.text+0x3bd8e0>
 1004b42: 8b 07                        	mov	eax, dword ptr [edi]
 1004b44: 8b 8d c4 fc ff ff            	mov	ecx, dword ptr [ebp - 0x33c]
 1004b4a: 89 84 cd ec fc ff ff         	mov	dword ptr [ebp + 8*ecx - 0x314], eax
 1004b51: 8b 16                        	mov	edx, dword ptr [esi]
 1004b53: 8b 82 f0 00 00 00            	mov	eax, dword ptr [edx + 0xf0]
 1004b59: 83 c4 10                     	add	esp, 0x10
 1004b5c: 8b ce                        	mov	ecx, esi
 1004b5e: ff d0                        	call	eax
 1004b60: 8b 08                        	mov	ecx, dword ptr [eax]
 1004b62: 51                           	push	ecx
 1004b63: e8 b8 f6 77 ff               	call	0x784220
 1004b68: 83 c4 04                     	add	esp, 0x4
 1004b6b: 3c 01                        	cmp	al, 0x1
 1004b6d: 75 23                        	jne	0x1004b92 <.text+0xe32>
 1004b6f: 8b 16                        	mov	edx, dword ptr [esi]
 1004b71: 8b 42 20                     	mov	eax, dword ptr [edx + 0x20]
 1004b74: 8b ce                        	mov	ecx, esi
 1004b76: ff d0                        	call	eax
 1004b78: 6a 01                        	push	0x1
 1004b7a: 6a 32                        	push	0x32
 1004b7c: 8d 70 14                     	lea	esi, [eax + 0x14]
 1004b7f: 6a 04                        	push	0x4
 1004b81: 56                           	push	esi
 1004b82: e8 b9 ca 3b 00               	call	0x13c1640 <.text+0x3bd8e0>
 1004b87: 8b 0e                        	mov	ecx, dword ptr [esi]
 1004b89: 83 c4 10                     	add	esp, 0x10
 1004b8c: 89 8d c0 fc ff ff            	mov	dword ptr [ebp - 0x340], ecx
 1004b92: 8b 85 c4 fc ff ff            	mov	eax, dword ptr [ebp - 0x33c]
 1004b98: 40                           	inc	eax
 1004b99: 83 c3 04                     	add	ebx, 0x4
 1004b9c: 89 85 c4 fc ff ff            	mov	dword ptr [ebp - 0x33c], eax
 1004ba2: 83 f8 0b                     	cmp	eax, 0xb
 1004ba5: 0f 8c 79 ff ff ff            	jl	0x1004b24 <.text+0xdc4>
 1004bab: 8b b5 bc fc ff ff            	mov	esi, dword ptr [ebp - 0x344]
 1004bb1: 8b bd b8 fc ff ff            	mov	edi, dword ptr [ebp - 0x348]
 1004bb7: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004bba: 8b 11                        	mov	edx, dword ptr [ecx]
 1004bbc: 8b 92 00 02 00 00            	mov	edx, dword ptr [edx + 0x200]
 1004bc2: 6a 01                        	push	0x1
 1004bc4: 8d 85 c8 fc ff ff            	lea	eax, [ebp - 0x338]
 1004bca: 50                           	push	eax
 1004bcb: ff d2                        	call	edx
 1004bcd: 8b 85 c0 fc ff ff            	mov	eax, dword ptr [ebp - 0x340]
 1004bd3: 83 f8 ff                     	cmp	eax, -0x1
 1004bd6: 74 09                        	je	0x1004be1 <.text+0xe81>
 1004bd8: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004bdb: 50                           	push	eax
 1004bdc: e8 af cb 80 ff               	call	0x811790
 1004be1: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 1004be7: e8 14 04 92 ff               	call	0x925000
 1004bec: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1004bef: 50                           	push	eax
 1004bf0: e8 0b 42 80 ff               	call	0x808e00
 1004bf5: 8d 8d c8 fc ff ff            	lea	ecx, [ebp - 0x338]
 1004bfb: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1004c02: e8 69 52 40 ff               	call	0x409e70
 1004c07: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1004c0a: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1004c11: 59                           	pop	ecx
 1004c12: 5f                           	pop	edi
 1004c13: 5e                           	pop	esi
 1004c14: 5b                           	pop	ebx
 1004c15: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
 1004c18: 33 cd                        	xor	ecx, ebp
 1004c1a: e8 b9 25 3d 00               	call	0x13d71d8 <.text+0x3d3478>
 1004c1f: 8b e5                        	mov	esp, ebp
 1004c21: 5d                           	pop	ebp
 1004c22: c2 04 00                     	ret	0x4
 1004c25: cc                           	int3
 1004c26: cc                           	int3
 1004c27: cc                           	int3
 1004c28: cc                           	int3
 1004c29: cc                           	int3
 1004c2a: cc                           	int3
 1004c2b: cc                           	int3
 1004c2c: cc                           	int3
 1004c2d: cc                           	int3
 1004c2e: cc                           	int3
 1004c2f: cc                           	int3
 1004c30: 55                           	push	ebp
 1004c31: 8b ec                        	mov	ebp, esp
 1004c33: 83 ec 18                     	sub	esp, 0x18
 1004c36: 56                           	push	esi
 1004c37: 57                           	push	edi
 1004c38: 8b f1                        	mov	esi, ecx
 1004c3a: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1004c3d: 50                           	push	eax
 1004c3e: 8d 8e 74 02 00 00            	lea	ecx, [esi + 0x274]
 1004c44: e8 27 15 17 00               	call	0x1176170 <.text+0x172410>
 1004c49: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
 1004c4c: 51                           	push	ecx
 1004c4d: 8d 8e 74 02 00 00            	lea	ecx, [esi + 0x274]
 1004c53: e8 e8 f6 7b ff               	call	0x7c4340
 1004c58: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
 1004c5b: 01 96 40 02 00 00            	add	dword ptr [esi + 0x240], edx
 1004c61: 8b 7d f4                     	mov	edi, dword ptr [ebp - 0xc]
 1004c64: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
 1004c67: 85 ff                        	test	edi, edi
 1004c69: 74 74                        	je	0x1004cdf <.text+0xf7f>
 1004c6b: 8b 0f                        	mov	ecx, dword ptr [edi]
 1004c6d: 85 c9                        	test	ecx, ecx
 1004c6f: 74 6e                        	je	0x1004cdf <.text+0xf7f>
 1004c71: 8b 45 e8                     	mov	eax, dword ptr [ebp - 0x18]
 1004c74: 85 c0                        	test	eax, eax
 1004c76: 74 02                        	je	0x1004c7a <.text+0xf1a>
 1004c78: 8b 00                        	mov	eax, dword ptr [eax]
 1004c7a: 3b c8                        	cmp	ecx, eax
 1004c7c: 75 61                        	jne	0x1004cdf <.text+0xf7f>
 1004c7e: 3b 55 f0                     	cmp	edx, dword ptr [ebp - 0x10]
 1004c81: 74 61                        	je	0x1004ce4 <.text+0xf84>
 1004c83: 8b 86 40 02 00 00            	mov	eax, dword ptr [esi + 0x240]
 1004c89: 85 c0                        	test	eax, eax
 1004c8b: 79 0c                        	jns	0x1004c99 <.text+0xf39>
 1004c8d: c7 86 40 02 00 00 03 00 00 00	mov	dword ptr [esi + 0x240], 0x3
 1004c97: eb 0f                        	jmp	0x1004ca8 <.text+0xf48>
 1004c99: 83 f8 04                     	cmp	eax, 0x4
 1004c9c: 7c 0a                        	jl	0x1004ca8 <.text+0xf48>
 1004c9e: c7 86 40 02 00 00 00 00 00 00	mov	dword ptr [esi + 0x240], 0x0
 1004ca8: 8b 07                        	mov	eax, dword ptr [edi]
 1004caa: 85 c0                        	test	eax, eax
 1004cac: 74 31                        	je	0x1004cdf <.text+0xf7f>
 1004cae: 85 d2                        	test	edx, edx
 1004cb0: 74 2d                        	je	0x1004cdf <.text+0xf7f>
 1004cb2: 39 50 04                     	cmp	dword ptr [eax + 0x4], edx
 1004cb5: 77 28                        	ja	0x1004cdf <.text+0xf7f>
 1004cb7: 3b 50 08                     	cmp	edx, dword ptr [eax + 0x8]
 1004cba: 73 23                        	jae	0x1004cdf <.text+0xf7f>
 1004cbc: 8b 86 40 02 00 00            	mov	eax, dword ptr [esi + 0x240]
 1004cc2: 3b 02                        	cmp	eax, dword ptr [edx]
 1004cc4: 75 1e                        	jne	0x1004ce4 <.text+0xf84>
 1004cc6: 03 45 08                     	add	eax, dword ptr [ebp + 0x8]
 1004cc9: 89 86 40 02 00 00            	mov	dword ptr [esi + 0x240], eax
 1004ccf: 8b 07                        	mov	eax, dword ptr [edi]
 1004cd1: 85 c0                        	test	eax, eax
 1004cd3: 74 0a                        	je	0x1004cdf <.text+0xf7f>
 1004cd5: 3b 50 08                     	cmp	edx, dword ptr [eax + 0x8]
 1004cd8: 73 05                        	jae	0x1004cdf <.text+0xf7f>
 1004cda: 83 c2 04                     	add	edx, 0x4
 1004cdd: eb 88                        	jmp	0x1004c67 <.text+0xf07>
 1004cdf: e8 c3 20 3d 00               	call	0x13d6da7 <.text+0x3d3047>
 1004ce4: 8b 86 40 02 00 00            	mov	eax, dword ptr [esi + 0x240]
 1004cea: 85 c0                        	test	eax, eax
 1004cec: 79 18                        	jns	0x1004d06 <.text+0xfa6>
 1004cee: c7 86 40 02 00 00 03 00 00 00	mov	dword ptr [esi + 0x240], 0x3
 1004cf8: 8b 86 40 02 00 00            	mov	eax, dword ptr [esi + 0x240]
 1004cfe: 5f                           	pop	edi
 1004cff: 5e                           	pop	esi
 1004d00: 8b e5                        	mov	esp, ebp
 1004d02: 5d                           	pop	ebp
 1004d03: c2 04 00                     	ret	0x4
 1004d06: 83 f8 04                     	cmp	eax, 0x4
 1004d09: 7c 0a                        	jl	0x1004d15 <.text+0xfb5>
 1004d0b: c7 86 40 02 00 00 00 00 00 00	mov	dword ptr [esi + 0x240], 0x0
 1004d15: 8b 86 40 02 00 00            	mov	eax, dword ptr [esi + 0x240]
 1004d1b: 5f                           	pop	edi
 1004d1c: 5e                           	pop	esi
 1004d1d: 8b e5                        	mov	esp, ebp
 1004d1f: 5d                           	pop	ebp
 1004d20: c2 04 00                     	ret	0x4
 1004d23: cc                           	int3
 1004d24: cc                           	int3
 1004d25: cc                           	int3
 1004d26: cc                           	int3
 1004d27: cc                           	int3
 1004d28: cc                           	int3
 1004d29: cc                           	int3
 1004d2a: cc                           	int3
 1004d2b: cc                           	int3
 1004d2c: cc                           	int3
 1004d2d: cc                           	int3
 1004d2e: cc                           	int3
 1004d2f: cc                           	int3
 1004d30: 55                           	push	ebp
 1004d31: 8b ec                        	mov	ebp, esp
 1004d33: 83 ec 28                     	sub	esp, 0x28
 1004d36: 53                           	push	ebx
 1004d37: 56                           	push	esi
 1004d38: 8b f1                        	mov	esi, ecx
 1004d3a: 33 db                        	xor	ebx, ebx
 1004d3c: 57                           	push	edi
 1004d3d: 33 c9                        	xor	ecx, ecx
 1004d3f: 8d 46 2c                     	lea	eax, [esi + 0x2c]
 1004d42: 89 1c 8e                     	mov	dword ptr [esi + 4*ecx], ebx
 1004d45: 66 0f ef c0                  	pxor	xmm0, xmm0
 1004d49: 66 0f d6 00                  	movq	qword ptr [eax], xmm0
 1004d4d: 66 0f d6 40 08               	movq	qword ptr [eax + 0x8], xmm0
 1004d52: 66 0f d6 40 10               	movq	qword ptr [eax + 0x10], xmm0
 1004d57: 66 0f d6 40 18               	movq	qword ptr [eax + 0x18], xmm0
 1004d5c: 66 0f d6 40 20               	movq	qword ptr [eax + 0x20], xmm0
 1004d61: 89 58 28                     	mov	dword ptr [eax + 0x28], ebx
 1004d64: 41                           	inc	ecx
 1004d65: 83 c0 2c                     	add	eax, 0x2c
 1004d68: 83 f9 0b                     	cmp	ecx, 0xb
 1004d6b: 7c d5                        	jl	0x1004d42 <.text+0xfe2>
 1004d6d: 8d 45 f0                     	lea	eax, [ebp - 0x10]
 1004d70: 50                           	push	eax
 1004d71: 8d 8e 74 02 00 00            	lea	ecx, [esi + 0x274]
 1004d77: c7 86 3c 02 00 00 0b 00 00 00	mov	dword ptr [esi + 0x23c], 0xb
 1004d81: 89 9e 40 02 00 00            	mov	dword ptr [esi + 0x240], ebx
 1004d87: e8 b4 f5 7b ff               	call	0x7c4340
 1004d8c: 83 ec 0c                     	sub	esp, 0xc
 1004d8f: 8b cc                        	mov	ecx, esp
 1004d91: 89 19                        	mov	dword ptr [ecx], ebx
 1004d93: 89 59 04                     	mov	dword ptr [ecx + 0x4], ebx
 1004d96: 8b 10                        	mov	edx, dword ptr [eax]
 1004d98: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
 1004d9b: 3b d3                        	cmp	edx, ebx
 1004d9d: 74 0a                        	je	0x1004da9 <.text+0x1049>
 1004d9f: 8b 12                        	mov	edx, dword ptr [edx]
 1004da1: 3b d3                        	cmp	edx, ebx
 1004da3: 74 04                        	je	0x1004da9 <.text+0x1049>
 1004da5: 8b 12                        	mov	edx, dword ptr [edx]
 1004da7: 89 11                        	mov	dword ptr [ecx], edx
 1004da9: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
 1004dac: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
 1004daf: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
 1004db2: 51                           	push	ecx
 1004db3: 8d 8e 74 02 00 00            	lea	ecx, [esi + 0x274]
 1004db9: e8 b2 13 17 00               	call	0x1176170 <.text+0x172410>
 1004dbe: 83 ec 0c                     	sub	esp, 0xc
 1004dc1: 8b cc                        	mov	ecx, esp
 1004dc3: 89 19                        	mov	dword ptr [ecx], ebx
 1004dc5: 89 59 04                     	mov	dword ptr [ecx + 0x4], ebx
 1004dc8: 8b 10                        	mov	edx, dword ptr [eax]
 1004dca: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
 1004dcd: 3b d3                        	cmp	edx, ebx
 1004dcf: 74 0a                        	je	0x1004ddb <.text+0x107b>
 1004dd1: 8b 12                        	mov	edx, dword ptr [edx]
 1004dd3: 3b d3                        	cmp	edx, ebx
 1004dd5: 74 04                        	je	0x1004ddb <.text+0x107b>
 1004dd7: 8b 12                        	mov	edx, dword ptr [edx]
 1004dd9: 89 11                        	mov	dword ptr [ecx], edx
 1004ddb: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
 1004dde: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
 1004de1: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
 1004de4: 51                           	push	ecx
 1004de5: 8d 8e 74 02 00 00            	lea	ecx, [esi + 0x274]
 1004deb: e8 10 7b 88 ff               	call	0x88c900
 1004df0: 5f                           	pop	edi
 1004df1: 88 9e 88 02 00 00            	mov	byte ptr [esi + 0x288], bl
 1004df7: 89 9e 8c 02 00 00            	mov	dword ptr [esi + 0x28c], ebx
 1004dfd: 89 9e 90 02 00 00            	mov	dword ptr [esi + 0x290], ebx
 1004e03: 5e                           	pop	esi
 1004e04: 5b                           	pop	ebx
 1004e05: 8b e5                        	mov	esp, ebp
 1004e07: 5d                           	pop	ebp
 1004e08: c3                           	ret
 1004e09: cc                           	int3
 1004e0a: cc                           	int3
 1004e0b: cc                           	int3
 1004e0c: cc                           	int3
 1004e0d: cc                           	int3
 1004e0e: cc                           	int3
 1004e0f: cc                           	int3
 1004e10: 56                           	push	esi
 1004e11: 57                           	push	edi
 1004e12: 6a 01                        	push	0x1
 1004e14: 8b f1                        	mov	esi, ecx
 1004e16: e8 15 fe ff ff               	call	0x1004c30 <.text+0xed0>
 1004e1b: 83 be 40 02 00 00 03         	cmp	dword ptr [esi + 0x240], 0x3
 1004e22: bf d0 07 00 00               	mov	edi, 0x7d0
 1004e27: 75 05                        	jne	0x1004e2e <.text+0x10ce>
 1004e29: bf e8 03 00 00               	mov	edi, 0x3e8
 1004e2e: 8d 8e 44 02 00 00            	lea	ecx, [esi + 0x244]
 1004e34: e8 b7 55 1b 00               	call	0x11ba3f0 <.text+0x1b6690>
 1004e39: 6a 00                        	push	0x0
 1004e3b: 57                           	push	edi
 1004e3c: 8d 8e 44 02 00 00            	lea	ecx, [esi + 0x244]
 1004e42: e8 c9 5b 1b 00               	call	0x11baa10 <.text+0x1b6cb0>
 1004e47: 5f                           	pop	edi
 1004e48: 5e                           	pop	esi
 1004e49: c3                           	ret
 1004e4a: cc                           	int3
 1004e4b: cc                           	int3
 1004e4c: cc                           	int3
 1004e4d: cc                           	int3
 1004e4e: cc                           	int3
 1004e4f: cc                           	int3
 1004e50: 56                           	push	esi
 1004e51: 57                           	push	edi
 1004e52: 6a ff                        	push	-0x1
 1004e54: 8b f1                        	mov	esi, ecx
 1004e56: e8 d5 fd ff ff               	call	0x1004c30 <.text+0xed0>
 1004e5b: 83 be 40 02 00 00 03         	cmp	dword ptr [esi + 0x240], 0x3
 1004e62: bf d0 07 00 00               	mov	edi, 0x7d0
 1004e67: 75 05                        	jne	0x1004e6e <.text+0x110e>
 1004e69: bf e8 03 00 00               	mov	edi, 0x3e8
 1004e6e: 8d 8e 44 02 00 00            	lea	ecx, [esi + 0x244]
 1004e74: e8 77 55 1b 00               	call	0x11ba3f0 <.text+0x1b6690>
 1004e79: 6a 00                        	push	0x0
 1004e7b: 57                           	push	edi
 1004e7c: 8d 8e 44 02 00 00            	lea	ecx, [esi + 0x244]
 1004e82: e8 89 5b 1b 00               	call	0x11baa10 <.text+0x1b6cb0>
 1004e87: 5f                           	pop	edi
 1004e88: 5e                           	pop	esi
 1004e89: c3                           	ret
 1004e8a: cc                           	int3
 1004e8b: cc                           	int3
 1004e8c: cc                           	int3
 1004e8d: cc                           	int3
 1004e8e: cc                           	int3
 1004e8f: cc                           	int3
 1004e90: 55                           	push	ebp
 1004e91: 8b ec                        	mov	ebp, esp
 1004e93: 83 ec 08                     	sub	esp, 0x8
 1004e96: 53                           	push	ebx
 1004e97: 8b d9                        	mov	ebx, ecx
 1004e99: 8b 8b 8c 02 00 00            	mov	ecx, dword ptr [ebx + 0x28c]
 1004e9f: 56                           	push	esi
 1004ea0: 57                           	push	edi
 1004ea1: 89 5d f8                     	mov	dword ptr [ebp - 0x8], ebx
 1004ea4: 85 c9                        	test	ecx, ecx
 1004ea6: 74 05                        	je	0x1004ead <.text+0x114d>
 1004ea8: e8 13 7f 8a ff               	call	0x8acdc0
 1004ead: 8d 8b 44 02 00 00            	lea	ecx, [ebx + 0x244]
 1004eb3: e8 a8 58 1b 00               	call	0x11ba760 <.text+0x1b6a00>
 1004eb8: 84 c0                        	test	al, al
 1004eba: 74 35                        	je	0x1004ef1 <.text+0x1191>
 1004ebc: 6a 01                        	push	0x1
 1004ebe: 8b cb                        	mov	ecx, ebx
 1004ec0: e8 6b fd ff ff               	call	0x1004c30 <.text+0xed0>
 1004ec5: 83 bb 40 02 00 00 03         	cmp	dword ptr [ebx + 0x240], 0x3
 1004ecc: bf d0 07 00 00               	mov	edi, 0x7d0
 1004ed1: 75 05                        	jne	0x1004ed8 <.text+0x1178>
 1004ed3: bf e8 03 00 00               	mov	edi, 0x3e8
 1004ed8: 8d 8b 44 02 00 00            	lea	ecx, [ebx + 0x244]
 1004ede: e8 0d 55 1b 00               	call	0x11ba3f0 <.text+0x1b6690>
 1004ee3: 6a 00                        	push	0x0
 1004ee5: 57                           	push	edi
 1004ee6: 8d 8b 44 02 00 00            	lea	ecx, [ebx + 0x244]
 1004eec: e8 1f 5b 1b 00               	call	0x11baa10 <.text+0x1b6cb0>
 1004ef1: 8b 3d 0c 79 ac 01            	mov	edi, dword ptr [0x1ac790c]
 1004ef7: 85 ff                        	test	edi, edi
 1004ef9: 74 66                        	je	0x1004f61 <.text+0x1201>
 1004efb: 8b 07                        	mov	eax, dword ptr [edi]
 1004efd: 8b 90 38 07 00 00            	mov	edx, dword ptr [eax + 0x738]
 1004f03: 8b cf                        	mov	ecx, edi
 1004f05: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
 1004f08: ff d2                        	call	edx
 1004f0a: 8b 8b 3c 02 00 00            	mov	ecx, dword ptr [ebx + 0x23c]
 1004f10: 3b 08                        	cmp	ecx, dword ptr [eax]
 1004f12: 75 4d                        	jne	0x1004f61 <.text+0x1201>
 1004f14: 33 f6                        	xor	esi, esi
 1004f16: 81 c3 10 02 00 00            	add	ebx, 0x210
 1004f1c: eb 05                        	jmp	0x1004f23 <.text+0x11c3>
 1004f1e: 8b ff                        	mov	edi, edi
 1004f20: 8b 7d fc                     	mov	edi, dword ptr [ebp - 0x4]
 1004f23: 8b 17                        	mov	edx, dword ptr [edi]
 1004f25: 8b 82 98 07 00 00            	mov	eax, dword ptr [edx + 0x798]
 1004f2b: 56                           	push	esi
 1004f2c: 8b cf                        	mov	ecx, edi
 1004f2e: ff d0                        	call	eax
 1004f30: 8b f8                        	mov	edi, eax
 1004f32: 8b 03                        	mov	eax, dword ptr [ebx]
 1004f34: 3b c7                        	cmp	eax, edi
 1004f36: 74 1e                        	je	0x1004f56 <.text+0x11f6>
 1004f38: 85 ff                        	test	edi, edi
 1004f3a: 75 1a                        	jne	0x1004f56 <.text+0x11f6>
 1004f3c: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
 1004f3f: 8b 91 3c 02 00 00            	mov	edx, dword ptr [ecx + 0x23c]
 1004f45: 42                           	inc	edx
 1004f46: 6b d2 0b                     	imul	edx, edx, 0xb
 1004f49: 03 d6                        	add	edx, esi
 1004f4b: 3b 04 91                     	cmp	eax, dword ptr [ecx + 4*edx]
 1004f4e: 75 06                        	jne	0x1004f56 <.text+0x11f6>
 1004f50: 56                           	push	esi
 1004f51: e8 1a fa ff ff               	call	0x1004970 <.text+0xc10>
 1004f56: 89 3b                        	mov	dword ptr [ebx], edi
 1004f58: 46                           	inc	esi
 1004f59: 83 c3 04                     	add	ebx, 0x4
 1004f5c: 83 fe 0b                     	cmp	esi, 0xb
 1004f5f: 7c bf                        	jl	0x1004f20 <.text+0x11c0>
 1004f61: 5f                           	pop	edi
 1004f62: 5e                           	pop	esi
 1004f63: 5b                           	pop	ebx
 1004f64: 8b e5                        	mov	esp, ebp
 1004f66: 5d                           	pop	ebp
 1004f67: c3                           	ret
 1004f68: cc                           	int3
 1004f69: cc                           	int3
 1004f6a: cc                           	int3
 1004f6b: cc                           	int3
 1004f6c: cc                           	int3
 1004f6d: cc                           	int3
 1004f6e: cc                           	int3
 1004f6f: cc                           	int3
 1004f70: 8b 81 68 02 00 00            	mov	eax, dword ptr [ecx + 0x268]
 1004f76: 56                           	push	esi
 1004f77: 57                           	push	edi
 1004f78: 8d b9 60 02 00 00            	lea	edi, [ecx + 0x260]
 1004f7e: 8b 4f 04                     	mov	ecx, dword ptr [edi + 0x4]
 1004f81: 2b c1                        	sub	eax, ecx
 1004f83: c1 f8 02                     	sar	eax, 0x2
 1004f86: 33 f6                        	xor	esi, esi
 1004f88: 85 c0                        	test	eax, eax
 1004f8a: 74 40                        	je	0x1004fcc <.text+0x126c>
 1004f8c: 3b f0                        	cmp	esi, eax
 1004f8e: 73 45                        	jae	0x1004fd5 <.text+0x1275>
 1004f90: 83 3c b1 00                  	cmp	dword ptr [ecx + 4*esi], 0x0
 1004f94: 74 10                        	je	0x1004fa6 <.text+0x1246>
 1004f96: 8b 0c b1                     	mov	ecx, dword ptr [ecx + 4*esi]
 1004f99: 85 c9                        	test	ecx, ecx
 1004f9b: 74 09                        	je	0x1004fa6 <.text+0x1246>
 1004f9d: 8b 01                        	mov	eax, dword ptr [ecx]
 1004f9f: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
 1004fa2: 6a 01                        	push	0x1
 1004fa4: ff d2                        	call	edx
 1004fa6: 8b 47 04                     	mov	eax, dword ptr [edi + 0x4]
 1004fa9: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
 1004fac: 2b c8                        	sub	ecx, eax
 1004fae: c1 f9 02                     	sar	ecx, 0x2
 1004fb1: 3b f1                        	cmp	esi, ecx
 1004fb3: 73 20                        	jae	0x1004fd5 <.text+0x1275>
 1004fb5: c7 04 b0 00 00 00 00         	mov	dword ptr [eax + 4*esi], 0x0
 1004fbc: 8b 4f 04                     	mov	ecx, dword ptr [edi + 0x4]
 1004fbf: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
 1004fc2: 2b c1                        	sub	eax, ecx
 1004fc4: 46                           	inc	esi
 1004fc5: c1 f8 02                     	sar	eax, 0x2
 1004fc8: 3b f0                        	cmp	esi, eax
 1004fca: 72 c4                        	jb	0x1004f90 <.text+0x1230>
 1004fcc: 8b cf                        	mov	ecx, edi
 1004fce: 5f                           	pop	edi
 1004fcf: 5e                           	pop	esi
 1004fd0: e9 7b 45 38 00               	jmp	0x1389550 <.text+0x3857f0>
 1004fd5: e8 cd 1d 3d 00               	call	0x13d6da7 <.text+0x3d3047>
 1004fda: cc                           	int3
 1004fdb: cc                           	int3
 1004fdc: cc                           	int3
 1004fdd: cc                           	int3
 1004fde: cc                           	int3
 1004fdf: cc                           	int3
 1004fe0: 56                           	push	esi
 1004fe1: 57                           	push	edi
 1004fe2: 8b f9                        	mov	edi, ecx
 1004fe4: 33 f6                        	xor	esi, esi
 1004fe6: 56                           	push	esi
 1004fe7: 8b cf                        	mov	ecx, edi
 1004fe9: e8 82 f9 ff ff               	call	0x1004970 <.text+0xc10>
 1004fee: 46                           	inc	esi
 1004fef: 83 fe 0b                     	cmp	esi, 0xb
 1004ff2: 7c f2                        	jl	0x1004fe6 <.text+0x1286>
 1004ff4: 8b cf                        	mov	ecx, edi
 1004ff6: 5f                           	pop	edi
 1004ff7: 5e                           	pop	esi
 1004ff8: e9 73 ff ff ff               	jmp	0x1004f70 <.text+0x1210>
 1004ffd: cc                           	int3
 1004ffe: cc                           	int3
 1004fff: cc                           	int3
 1005000: 55                           	push	ebp
 1005001: 8b ec                        	mov	ebp, esp
 1005003: 6a ff                        	push	-0x1
 1005005: 68 45 2e 4b 01               	push	0x14b2e45
 100500a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1005010: 50                           	push	eax
 1005011: 83 ec 24                     	sub	esp, 0x24
 1005014: 53                           	push	ebx
 1005015: 56                           	push	esi
 1005016: 57                           	push	edi
 1005017: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 100501c: 33 c5                        	xor	eax, ebp
 100501e: 50                           	push	eax
 100501f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1005022: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 1005028: 8b f9                        	mov	edi, ecx
 100502a: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 100502d: 8d 8f 44 02 00 00            	lea	ecx, [edi + 0x244]
 1005033: e8 08 59 1b 00               	call	0x11ba940 <.text+0x1b6be0>
 1005038: 33 db                        	xor	ebx, ebx
 100503a: 8d b7 60 02 00 00            	lea	esi, [edi + 0x260]
 1005040: 6a 08                        	push	0x8
 1005042: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
 1005045: 89 1e                        	mov	dword ptr [esi], ebx
 1005047: e8 ce 1a 3d 00               	call	0x13d6b1a <.text+0x3d2dba>
 100504c: 83 c4 04                     	add	esp, 0x4
 100504f: 3b c3                        	cmp	eax, ebx
 1005051: 0f 84 b6 00 00 00            	je	0x100510d <.text+0x13ad>
 1005057: 89 06                        	mov	dword ptr [esi], eax
 1005059: 33 c9                        	xor	ecx, ecx
 100505b: 89 08                        	mov	dword ptr [eax], ecx
 100505d: 33 d2                        	xor	edx, edx
 100505f: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1005062: 8b 06                        	mov	eax, dword ptr [esi]
 1005064: 89 30                        	mov	dword ptr [eax], esi
 1005066: 89 5e 04                     	mov	dword ptr [esi + 0x4], ebx
 1005069: 89 5e 08                     	mov	dword ptr [esi + 0x8], ebx
 100506c: 89 5e 0c                     	mov	dword ptr [esi + 0xc], ebx
 100506f: 8d b7 74 02 00 00            	lea	esi, [edi + 0x274]
 1005075: 6a 08                        	push	0x8
 1005077: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
 100507b: 89 1e                        	mov	dword ptr [esi], ebx
 100507d: e8 98 1a 3d 00               	call	0x13d6b1a <.text+0x3d2dba>
 1005082: 83 c4 04                     	add	esp, 0x4
 1005085: 3b c3                        	cmp	eax, ebx
 1005087: 74 60                        	je	0x10050e9 <.text+0x1389>
 1005089: 89 06                        	mov	dword ptr [esi], eax
 100508b: 33 c9                        	xor	ecx, ecx
 100508d: 89 08                        	mov	dword ptr [eax], ecx
 100508f: 33 d2                        	xor	edx, edx
 1005091: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1005094: 8b 0e                        	mov	ecx, dword ptr [esi]
 1005096: 89 31                        	mov	dword ptr [ecx], esi
 1005098: 89 5e 04                     	mov	dword ptr [esi + 0x4], ebx
 100509b: 89 5e 08                     	mov	dword ptr [esi + 0x8], ebx
 100509e: 89 5e 0c                     	mov	dword ptr [esi + 0xc], ebx
 10050a1: 8b cf                        	mov	ecx, edi
 10050a3: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
 10050a7: e8 84 fc ff ff               	call	0x1004d30 <.text+0xfd0>
 10050ac: 68 9c 01 00 00               	push	0x19c
 10050b1: e8 64 1a 3d 00               	call	0x13d6b1a <.text+0x3d2dba>
 10050b6: 83 c4 04                     	add	esp, 0x4
 10050b9: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
 10050bc: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
 10050c0: 3b c3                        	cmp	eax, ebx
 10050c2: 74 09                        	je	0x10050cd <.text+0x136d>
 10050c4: 8b c8                        	mov	ecx, eax
 10050c6: e8 d5 c6 7d ff               	call	0x7e17a0
 10050cb: eb 02                        	jmp	0x10050cf <.text+0x136f>
 10050cd: 33 c0                        	xor	eax, eax
 10050cf: 89 87 8c 02 00 00            	mov	dword ptr [edi + 0x28c], eax
 10050d5: 8b c7                        	mov	eax, edi
 10050d7: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 10050da: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 10050e1: 59                           	pop	ecx
 10050e2: 5f                           	pop	edi
 10050e3: 5e                           	pop	esi
 10050e4: 5b                           	pop	ebx
 10050e5: 8b e5                        	mov	esp, ebp
 10050e7: 5d                           	pop	ebp
 10050e8: c3                           	ret
 10050e9: 8d 55 f0                     	lea	edx, [ebp - 0x10]
 10050ec: 52                           	push	edx
 10050ed: 8d 4d dc                     	lea	ecx, [ebp - 0x24]
 10050f0: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
 10050f3: e8 d2 13 3d 00               	call	0x13d64ca <.text+0x3d276a>
 10050f8: 68 90 0f 91 01               	push	0x1910f90
 10050fd: 8d 45 dc                     	lea	eax, [ebp - 0x24]
 1005100: 50                           	push	eax
 1005101: c7 45 dc 84 20 56 01         	mov	dword ptr [ebp - 0x24], 0x1562084
 1005108: e8 8d 1a 3d 00               	call	0x13d6b9a <.text+0x3d2e3a>
 100510d: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
 1005110: 51                           	push	ecx
 1005111: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1005114: 89 5d ec                     	mov	dword ptr [ebp - 0x14], ebx
 1005117: e8 ae 13 3d 00               	call	0x13d64ca <.text+0x3d276a>
 100511c: 68 90 0f 91 01               	push	0x1910f90
 1005121: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 1005124: 52                           	push	edx
 1005125: c7 45 d0 84 20 56 01         	mov	dword ptr [ebp - 0x30], 0x1562084
 100512c: e8 69 1a 3d 00               	call	0x13d6b9a <.text+0x3d2e3a>
 1005131: cc                           	int3
 1005132: cc                           	int3
 1005133: cc                           	int3
 1005134: cc                           	int3
 1005135: cc                           	int3
 1005136: cc                           	int3
 1005137: cc                           	int3
 1005138: cc                           	int3
 1005139: cc                           	int3
 100513a: cc                           	int3
 100513b: cc                           	int3
 100513c: cc                           	int3
 100513d: cc                           	int3
 100513e: cc                           	int3
 100513f: cc                           	int3
 1005140: 55                           	push	ebp
 1005141: 8b ec                        	mov	ebp, esp
 1005143: 6a ff                        	push	-0x1
 1005145: 68 87 2e 4b 01               	push	0x14b2e87
 100514a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1005150: 50                           	push	eax
 1005151: 81 ec 30 03 00 00            	sub	esp, 0x330
 1005157: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 100515c: 33 c5                        	xor	eax, ebp
 100515e: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
 1005161: 53                           	push	ebx
 1005162: 56                           	push	esi
 1005163: 57                           	push	edi
 1005164: 50                           	push	eax
 1005165: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1005168: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 100516e: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
 1005171: 8b f9                        	mov	edi, ecx
 1005173: 53                           	push	ebx
 1005174: 8d 8d c8 fc ff ff            	lea	ecx, [ebp - 0x338]
 100517a: 89 bd c4 fc ff ff            	mov	dword ptr [ebp - 0x33c], edi
 1005180: e8 cb 6f 40 ff               	call	0x40c150
 1005185: 33 f6                        	xor	esi, esi
 1005187: 89 75 fc                     	mov	dword ptr [ebp - 0x4], esi
 100518a: 8b 43 04                     	mov	eax, dword ptr [ebx + 0x4]
 100518d: 40                           	inc	eax
 100518e: 6b c0 0b                     	imul	eax, eax, 0xb
 1005191: 03 c6                        	add	eax, esi
 1005193: 83 3c 87 00                  	cmp	dword ptr [edi + 4*eax], 0x0
 1005197: 74 34                        	je	0x10051cd <.text+0x146d>
 1005199: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
 100519c: 41                           	inc	ecx
 100519d: 6b c9 0b                     	imul	ecx, ecx, 0xb
 10051a0: 03 ce                        	add	ecx, esi
 10051a2: 8b 0c 8f                     	mov	ecx, dword ptr [edi + 4*ecx]
 10051a5: 8b 11                        	mov	edx, dword ptr [ecx]
 10051a7: 8b 42 20                     	mov	eax, dword ptr [edx + 0x20]
 10051aa: ff d0                        	call	eax
 10051ac: 6a 01                        	push	0x1
 10051ae: 6a 32                        	push	0x32
 10051b0: 8d 78 14                     	lea	edi, [eax + 0x14]
 10051b3: 6a 04                        	push	0x4
 10051b5: 57                           	push	edi
 10051b6: e8 85 c4 3b 00               	call	0x13c1640 <.text+0x3bd8e0>
 10051bb: 8b 0f                        	mov	ecx, dword ptr [edi]
 10051bd: 8b bd c4 fc ff ff            	mov	edi, dword ptr [ebp - 0x33c]
 10051c3: 83 c4 10                     	add	esp, 0x10
 10051c6: 89 8c f5 ec fc ff ff         	mov	dword ptr [ebp + 8*esi - 0x314], ecx
 10051cd: 46                           	inc	esi
 10051ce: 83 fe 0b                     	cmp	esi, 0xb
 10051d1: 7c b7                        	jl	0x100518a <.text+0x142a>
 10051d3: 8b 53 04                     	mov	edx, dword ptr [ebx + 0x4]
 10051d6: 83 3c 97 00                  	cmp	dword ptr [edi + 4*edx], 0x0
 10051da: 75 77                        	jne	0x1005253 <.text+0x14f3>
 10051dc: 68 50 0a 00 00               	push	0xa50
 10051e1: e8 9a b1 1a 00               	call	0x11b0380 <.text+0x1ac620>
 10051e6: 83 c4 04                     	add	esp, 0x4
 10051e9: 89 85 c4 fc ff ff            	mov	dword ptr [ebp - 0x33c], eax
 10051ef: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
 10051f3: 85 c0                        	test	eax, eax
 10051f5: 74 09                        	je	0x1005200 <.text+0x14a0>
 10051f7: 8b c8                        	mov	ecx, eax
 10051f9: e8 92 fd 50 ff               	call	0x514f90
 10051fe: eb 02                        	jmp	0x1005202 <.text+0x14a2>
 1005200: 33 c0                        	xor	eax, eax
 1005202: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
 1005205: 68 08 04 00 00               	push	0x408
 100520a: c6 45 fc 00                  	mov	byte ptr [ebp - 0x4], 0x0
 100520e: 89 04 8f                     	mov	dword ptr [edi + 4*ecx], eax
 1005211: e8 04 19 3d 00               	call	0x13d6b1a <.text+0x3d2dba>
 1005216: 83 c4 04                     	add	esp, 0x4
 1005219: 89 85 c4 fc ff ff            	mov	dword ptr [ebp - 0x33c], eax
 100521f: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
 1005223: 85 c0                        	test	eax, eax
 1005225: 74 0b                        	je	0x1005232 <.text+0x14d2>
 1005227: 8b c8                        	mov	ecx, eax
 1005229: e8 b2 ae 83 ff               	call	0x8400e0
 100522e: 8b f0                        	mov	esi, eax
 1005230: eb 02                        	jmp	0x1005234 <.text+0x14d4>
 1005232: 33 f6                        	xor	esi, esi
 1005234: 8d 95 c8 fc ff ff            	lea	edx, [ebp - 0x338]
 100523a: 52                           	push	edx
 100523b: 8d 4e 10                     	lea	ecx, [esi + 0x10]
 100523e: c6 45 fc 00                  	mov	byte ptr [ebp - 0x4], 0x0
 1005242: e8 c9 0f 4c ff               	call	0x4c6210
 1005247: 8b 43 04                     	mov	eax, dword ptr [ebx + 0x4]
 100524a: 8b 0c 87                     	mov	ecx, dword ptr [edi + 4*eax]
 100524d: 56                           	push	esi
 100524e: e8 ad 3b 80 ff               	call	0x808e00
 1005253: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
 1005256: 8b 3c 8f                     	mov	edi, dword ptr [edi + 4*ecx]
 1005259: 8b 17                        	mov	edx, dword ptr [edi]
 100525b: 8b 92 00 02 00 00            	mov	edx, dword ptr [edx + 0x200]
 1005261: 6a 01                        	push	0x1
 1005263: 8d 85 c8 fc ff ff            	lea	eax, [ebp - 0x338]
 1005269: 50                           	push	eax
 100526a: 8b cf                        	mov	ecx, edi
 100526c: ff d2                        	call	edx
 100526e: 8d 8d c8 fc ff ff            	lea	ecx, [ebp - 0x338]
 1005274: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 100527b: e8 f0 4b 40 ff               	call	0x409e70
 1005280: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1005283: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 100528a: 59                           	pop	ecx
 100528b: 5f                           	pop	edi
 100528c: 5e                           	pop	esi
 100528d: 5b                           	pop	ebx
 100528e: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
 1005291: 33 cd                        	xor	ecx, ebp
 1005293: e8 40 1f 3d 00               	call	0x13d71d8 <.text+0x3d3478>
 1005298: 8b e5                        	mov	esp, ebp
 100529a: 5d                           	pop	ebp
 100529b: c2 04 00                     	ret	0x4
 100529e: cc                           	int3
 100529f: cc                           	int3
 10052a0: 55                           	push	ebp
 10052a1: 8b ec                        	mov	ebp, esp
 10052a3: 6a ff                        	push	-0x1
 10052a5: 68 7b c8 46 01               	push	0x146c87b
 10052aa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 10052b0: 50                           	push	eax
 10052b1: 53                           	push	ebx
 10052b2: 56                           	push	esi
 10052b3: 57                           	push	edi
 10052b4: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 10052b9: 33 c5                        	xor	eax, ebp
 10052bb: 50                           	push	eax
 10052bc: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 10052bf: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 10052c5: 8b f1                        	mov	esi, ecx
 10052c7: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
 10052ca: 83 ff 0b                     	cmp	edi, 0xb
 10052cd: 0f 8d 6f 01 00 00            	jge	0x1005442 <.text+0x16e2>
 10052d3: 33 db                        	xor	ebx, ebx
 10052d5: 89 be 3c 02 00 00            	mov	dword ptr [esi + 0x23c], edi
 10052db: 39 1c be                     	cmp	dword ptr [esi + 4*edi], ebx
 10052de: 75 5d                        	jne	0x100533d <.text+0x15dd>
 10052e0: 68 50 0a 00 00               	push	0xa50
 10052e5: e8 96 b0 1a 00               	call	0x11b0380 <.text+0x1ac620>
 10052ea: 83 c4 04                     	add	esp, 0x4
 10052ed: 89 45 08                     	mov	dword ptr [ebp + 0x8], eax
 10052f0: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
 10052f3: 3b c3                        	cmp	eax, ebx
 10052f5: 74 09                        	je	0x1005300 <.text+0x15a0>
 10052f7: 8b c8                        	mov	ecx, eax
 10052f9: e8 92 fc 50 ff               	call	0x514f90
 10052fe: eb 02                        	jmp	0x1005302 <.text+0x15a2>
 1005300: 33 c0                        	xor	eax, eax
 1005302: 89 04 be                     	mov	dword ptr [esi + 4*edi], eax
 1005305: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 100530b: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1005312: e8 e9 fc 91 ff               	call	0x925000
 1005317: 85 c0                        	test	eax, eax
 1005319: 74 1a                        	je	0x1005335 <.text+0x15d5>
 100531b: 8b 0d 18 f7 a6 01            	mov	ecx, dword ptr [0x1a6f718]
 1005321: e8 da fc 91 ff               	call	0x925000
 1005326: 39 78 14                     	cmp	dword ptr [eax + 0x14], edi
 1005329: 75 0a                        	jne	0x1005335 <.text+0x15d5>
 100532b: 57                           	push	edi
 100532c: 8b ce                        	mov	ecx, esi
 100532e: e8 7d f7 ff ff               	call	0x1004ab0 <.text+0xd50>
 1005333: eb 08                        	jmp	0x100533d <.text+0x15dd>
 1005335: 57                           	push	edi
 1005336: 8b ce                        	mov	ecx, esi
 1005338: e8 93 f5 ff ff               	call	0x10048d0 <.text+0xb70>
 100533d: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1005340: 8b 01                        	mov	eax, dword ptr [ecx]
 1005342: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 1005348: ff d2                        	call	edx
 100534a: 8b 08                        	mov	ecx, dword ptr [eax]
 100534c: 53                           	push	ebx
 100534d: e8 ae 75 09 00               	call	0x109c900 <.text+0x98ba0>
 1005352: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1005355: 8b 01                        	mov	eax, dword ptr [ecx]
 1005357: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 100535d: 53                           	push	ebx
 100535e: ff d2                        	call	edx
 1005360: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
 1005363: e8 98 75 09 00               	call	0x109c900 <.text+0x98ba0>
 1005368: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 100536b: 8b 01                        	mov	eax, dword ptr [ecx]
 100536d: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 1005373: 53                           	push	ebx
 1005374: ff d2                        	call	edx
 1005376: 8b 48 04                     	mov	ecx, dword ptr [eax + 0x4]
 1005379: e8 82 75 09 00               	call	0x109c900 <.text+0x98ba0>
 100537e: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1005381: 8b 01                        	mov	eax, dword ptr [ecx]
 1005383: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 1005389: 6a 01                        	push	0x1
 100538b: ff d2                        	call	edx
 100538d: 8b 48 0c                     	mov	ecx, dword ptr [eax + 0xc]
 1005390: e8 6b 75 09 00               	call	0x109c900 <.text+0x98ba0>
 1005395: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 1005398: 8b 01                        	mov	eax, dword ptr [ecx]
 100539a: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 10053a0: ff d2                        	call	edx
 10053a2: 8b 40 0c                     	mov	eax, dword ptr [eax + 0xc]
 10053a5: 8b 40 44                     	mov	eax, dword ptr [eax + 0x44]
 10053a8: 3b c3                        	cmp	eax, ebx
 10053aa: 74 17                        	je	0x10053c3 <.text+0x1663>
 10053ac: 8b 48 14                     	mov	ecx, dword ptr [eax + 0x14]
 10053af: 2b 48 10                     	sub	ecx, dword ptr [eax + 0x10]
 10053b2: b8 ed 73 48 4d               	mov	eax, 0x4d4873ed
 10053b7: f7 e9                        	imul	ecx
 10053b9: c1 fa 06                     	sar	edx, 0x6
 10053bc: 8b da                        	mov	ebx, edx
 10053be: c1 eb 1f                     	shr	ebx, 0x1f
 10053c1: 03 da                        	add	ebx, edx
 10053c3: 8b 0c be                     	mov	ecx, dword ptr [esi + 4*edi]
 10053c6: 8b 01                        	mov	eax, dword ptr [ecx]
 10053c8: 8b 90 fc 01 00 00            	mov	edx, dword ptr [eax + 0x1fc]
 10053ce: ff d2                        	call	edx
 10053d0: 8b 78 0c                     	mov	edi, dword ptr [eax + 0xc]
 10053d3: 83 c3 fe                     	add	ebx, -0x2
 10053d6: 53                           	push	ebx
 10053d7: 8b cf                        	mov	ecx, edi
 10053d9: e8 22 b2 08 00               	call	0x1090600 <.text+0x8c8a0>
 10053de: 50                           	push	eax
 10053df: 8b cf                        	mov	ecx, edi
 10053e1: e8 aa 75 09 00               	call	0x109c990 <.text+0x98c30>
 10053e6: 8b 86 3c 02 00 00            	mov	eax, dword ptr [esi + 0x23c]
 10053ec: 8b 0c 86                     	mov	ecx, dword ptr [esi + 4*eax]
 10053ef: 8b 11                        	mov	edx, dword ptr [ecx]
 10053f1: 8b 86 8c 02 00 00            	mov	eax, dword ptr [esi + 0x28c]
 10053f7: 8b 52 60                     	mov	edx, dword ptr [edx + 0x60]
 10053fa: 50                           	push	eax
 10053fb: ff d2                        	call	edx
 10053fd: 8b 86 3c 02 00 00            	mov	eax, dword ptr [esi + 0x23c]
 1005403: 8b 0c 86                     	mov	ecx, dword ptr [esi + 4*eax]
 1005406: 6a 01                        	push	0x1
 1005408: e8 f3 60 7f ff               	call	0x7fb500
 100540d: 8b 8e 3c 02 00 00            	mov	ecx, dword ptr [esi + 0x23c]
 1005413: 8b 0c 8e                     	mov	ecx, dword ptr [esi + 4*ecx]
 1005416: 8b 11                        	mov	edx, dword ptr [ecx]
 1005418: 8b 82 f8 01 00 00            	mov	eax, dword ptr [edx + 0x1f8]
 100541e: ff d0                        	call	eax
 1005420: 8b 48 04                     	mov	ecx, dword ptr [eax + 0x4]
 1005423: 8b 96 3c 02 00 00            	mov	edx, dword ptr [esi + 0x23c]
 1005429: 51                           	push	ecx
 100542a: 8b 0c 96                     	mov	ecx, dword ptr [esi + 4*edx]
 100542d: e8 ae 3a 80 ff               	call	0x808ee0
 1005432: 8b 86 3c 02 00 00            	mov	eax, dword ptr [esi + 0x23c]
 1005438: 8b 0c 86                     	mov	ecx, dword ptr [esi + 4*eax]
 100543b: 6a 05                        	push	0x5
 100543d: e8 ce 3a 80 ff               	call	0x808f10
 1005442: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1005445: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 100544c: 59                           	pop	ecx
 100544d: 5f                           	pop	edi
 100544e: 5e                           	pop	esi
 100544f: 5b                           	pop	ebx
 1005450: 8b e5                        	mov	esp, ebp
 1005452: 5d                           	pop	ebp
 1005453: c2 04 00                     	ret	0x4
 1005456: cc                           	int3
 1005457: cc                           	int3
 1005458: cc                           	int3
 1005459: cc                           	int3
 100545a: cc                           	int3
 100545b: cc                           	int3
 100545c: cc                           	int3
 100545d: cc                           	int3
 100545e: cc                           	int3
 100545f: cc                           	int3
 1005460: 55                           	push	ebp
 1005461: 8b ec                        	mov	ebp, esp
 1005463: 83 ec 10                     	sub	esp, 0x10
 1005466: 83 7d 14 0a                  	cmp	dword ptr [ebp + 0x14], 0xa
 100546a: 57                           	push	edi
 100546b: 8b f9                        	mov	edi, ecx
 100546d: 0f 87 36 02 00 00            	ja	0x10056a9 <.text+0x1949>
 1005473: 56                           	push	esi
 1005474: 8b 75 0c                     	mov	esi, dword ptr [ebp + 0xc]
 1005477: 85 f6                        	test	esi, esi
 1005479: 75 18                        	jne	0x1005493 <.text+0x1733>
 100547b: 8b 87 3c 02 00 00            	mov	eax, dword ptr [edi + 0x23c]
 1005481: 40                           	inc	eax
 1005482: 6b c0 0b                     	imul	eax, eax, 0xb
 1005485: 03 45 08                     	add	eax, dword ptr [ebp + 0x8]
 1005488: 89 34 87                     	mov	dword ptr [edi + 4*eax], esi
 100548b: 5e                           	pop	esi
 100548c: 5f                           	pop	edi
 100548d: 8b e5                        	mov	esp, ebp
 100548f: 5d                           	pop	ebp
 1005490: c2 10 00                     	ret	0x10
 1005493: 8b ce                        	mov	ecx, esi
 1005495: e8 c6 34 78 ff               	call	0x788960
 100549a: 84 c0                        	test	al, al
 100549c: 75 15                        	jne	0x10054b3 <.text+0x1753>
 100549e: 8b 16                        	mov	edx, dword ptr [esi]
 10054a0: 8b 82 f0 00 00 00            	mov	eax, dword ptr [edx + 0xf0]
 10054a6: 8b ce                        	mov	ecx, esi
 10054a8: ff d0                        	call	eax
 10054aa: 83 38 0a                     	cmp	dword ptr [eax], 0xa
 10054ad: 0f 85 f5 01 00 00            	jne	0x10056a8 <.text+0x1948>
 10054b3: 8b 0d 0c 79 ac 01            	mov	ecx, dword ptr [0x1ac790c]
 10054b9: 85 c9                        	test	ecx, ecx
 10054bb: 0f 84 e7 01 00 00            	je	0x10056a8 <.text+0x1948>
 10054c1: 8b 11                        	mov	edx, dword ptr [ecx]
 10054c3: 8b 82 38 07 00 00            	mov	eax, dword ptr [edx + 0x738]
 10054c9: 53                           	push	ebx
 10054ca: ff d0                        	call	eax
 10054cc: 8b 18                        	mov	ebx, dword ptr [eax]
 10054ce: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
 10054d1: 8b 16                        	mov	edx, dword ptr [esi]
 10054d3: 83 f8 ff                     	cmp	eax, -0x1
 10054d6: 0f 45 d8                     	cmovne	ebx, eax
 10054d9: 8b 42 20                     	mov	eax, dword ptr [edx + 0x20]
 10054dc: 8b ce                        	mov	ecx, esi
 10054de: ff d0                        	call	eax
 10054e0: 8d 4c d8 68                  	lea	ecx, [eax + 8*ebx + 0x68]
 10054e4: e8 b7 5e 40 ff               	call	0x40b3a0
 10054e9: 84 c0                        	test	al, al
 10054eb: 74 03                        	je	0x10054f0 <.text+0x1790>
 10054ed: 53                           	push	ebx
 10054ee: eb 4c                        	jmp	0x100553c <.text+0x17dc>
 10054f0: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
 10054f7: c7 45 14 68 00 00 00         	mov	dword ptr [ebp + 0x14], 0x68
 10054fe: 8b ff                        	mov	edi, edi
 1005500: 8b 16                        	mov	edx, dword ptr [esi]
 1005502: 8b 42 20                     	mov	eax, dword ptr [edx + 0x20]
 1005505: 8b ce                        	mov	ecx, esi
 1005507: ff d0                        	call	eax
 1005509: 03 45 14                     	add	eax, dword ptr [ebp + 0x14]
 100550c: 6a 01                        	push	0x1
 100550e: 6a 24                        	push	0x24
 1005510: 8d 58 04                     	lea	ebx, [eax + 0x4]
 1005513: 6a 01                        	push	0x1
 1005515: 53                           	push	ebx
 1005516: e8 25 c1 3b 00               	call	0x13c1640 <.text+0x3bd8e0>
 100551b: 83 c4 10                     	add	esp, 0x10
 100551e: 80 3b 00                     	cmp	byte ptr [ebx], 0x0
 1005521: 75 15                        	jne	0x1005538 <.text+0x17d8>
 1005523: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
 1005526: ff 45 fc                     	inc	dword ptr [ebp - 0x4]
 1005529: 83 c0 08                     	add	eax, 0x8
 100552c: 89 45 14                     	mov	dword ptr [ebp + 0x14], eax
 100552f: 3d c0 00 00 00               	cmp	eax, 0xc0
 1005534: 7c ca                        	jl	0x1005500 <.text+0x17a0>
 1005536: eb 0b                        	jmp	0x1005543 <.text+0x17e3>
 1005538: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
 100553b: 51                           	push	ecx
 100553c: 8b cf                        	mov	ecx, edi
 100553e: e8 5d fd ff ff               	call	0x10052a0 <.text+0x1540>
 1005543: 6a 00                        	push	0x0
 1005545: 68 c0 c0 9d 01               	push	0x19dc0c0
 100554a: 68 94 93 9d 01               	push	0x19d9394
 100554f: 6a 00                        	push	0x0
 1005551: 56                           	push	esi
 1005552: c7 45 14 ff ff ff ff         	mov	dword ptr [ebp + 0x14], 0xffffffff
 1005559: e8 81 21 3d 00               	call	0x13d76df <.text+0x3d397f>
 100555e: 83 c4                        	<unknown>
