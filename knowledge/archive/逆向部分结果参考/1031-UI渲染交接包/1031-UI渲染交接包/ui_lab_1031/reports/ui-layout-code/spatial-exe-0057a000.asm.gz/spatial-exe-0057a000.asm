
<stdin>:	file format elf32-i386

Disassembly of section .text:

0057a000 <.text>:
  57a000: c1 fa 02                     	sar	edx, 0x2
  57a003: 8b c2                        	mov	eax, edx
  57a005: c1 e8 1f                     	shr	eax, 0x1f
  57a008: 03 c2                        	add	eax, edx
  57a00a: 3b f0                        	cmp	esi, eax
  57a00c: 0f 83 6d fd ff ff            	jae	0x579d7f
  57a012: 8a 4d e5                     	mov	cl, byte ptr [ebp - 0x1b]
  57a015: 8b 55 f0                     	mov	edx, dword ptr [ebp - 0x10]
  57a018: 38 4c 1a 05                  	cmp	byte ptr [edx + ebx + 0x5], cl
  57a01c: 75 48                        	jne	0x57a066 <.text+0x66>
  57a01e: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a021: 50                           	push	eax
  57a022: 8b cf                        	mov	ecx, edi
  57a024: e8 57 e3 ff ff               	call	0x578380
  57a029: 8b 98 8c 00 00 00            	mov	ebx, dword ptr [eax + 0x8c]
  57a02f: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a035: 2b cb                        	sub	ecx, ebx
  57a037: b8 67 66 66 66               	mov	eax, 0x66666667
  57a03c: f7 e9                        	imul	ecx
  57a03e: c1 fa 02                     	sar	edx, 0x2
  57a041: 8b ca                        	mov	ecx, edx
  57a043: c1 e9 1f                     	shr	ecx, 0x1f
  57a046: 03 ca                        	add	ecx, edx
  57a048: 3b f1                        	cmp	esi, ecx
  57a04a: 0f 83 2f fd ff ff            	jae	0x579d7f
  57a050: 8b 45 f0                     	mov	eax, dword ptr [ebp - 0x10]
  57a053: f3 0f 7e 45 e0               	movq	xmm0, qword ptr [ebp - 0x20]
  57a058: 66 8b 55 e8                  	mov	dx, word ptr [ebp - 0x18]
  57a05c: 66 0f d6 04 18               	movq	qword ptr [eax + ebx], xmm0
  57a061: 66 89 54 18 08               	mov	word ptr [eax + ebx + 0x8], dx
  57a066: 83 45 f0 0a                  	add	dword ptr [ebp - 0x10], 0xa
  57a06a: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a06d: 50                           	push	eax
  57a06e: 8b cf                        	mov	ecx, edi
  57a070: 46                           	inc	esi
  57a071: e8 0a e3 ff ff               	call	0x578380
  57a076: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a07c: 2b 88 8c 00 00 00            	sub	ecx, dword ptr [eax + 0x8c]
  57a082: b8 67 66 66 66               	mov	eax, 0x66666667
  57a087: f7 e9                        	imul	ecx
  57a089: c1 fa 02                     	sar	edx, 0x2
  57a08c: 8b ca                        	mov	ecx, edx
  57a08e: c1 e9 1f                     	shr	ecx, 0x1f
  57a091: 03 ca                        	add	ecx, edx
  57a093: 3b f1                        	cmp	esi, ecx
  57a095: 0f 82 45 ff ff ff            	jb	0x579fe0
  57a09b: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57a09e: e8 dd f3 ff ff               	call	0x579480
  57a0a3: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57a0a6: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57a0ad: 59                           	pop	ecx
  57a0ae: 5f                           	pop	edi
  57a0af: 5e                           	pop	esi
  57a0b0: 5b                           	pop	ebx
  57a0b1: 8b e5                        	mov	esp, ebp
  57a0b3: 5d                           	pop	ebp
  57a0b4: c2 1c 00                     	ret	0x1c
  57a0b7: cc                           	int3
  57a0b8: cc                           	int3
  57a0b9: cc                           	int3
  57a0ba: cc                           	int3
  57a0bb: cc                           	int3
  57a0bc: cc                           	int3
  57a0bd: cc                           	int3
  57a0be: cc                           	int3
  57a0bf: cc                           	int3
  57a0c0: 55                           	push	ebp
  57a0c1: 8b ec                        	mov	ebp, esp
  57a0c3: 6a ff                        	push	-0x1
  57a0c5: 68 68 d2 41 01               	push	0x141d268
  57a0ca: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57a0d0: 50                           	push	eax
  57a0d1: 83 ec 08                     	sub	esp, 0x8
  57a0d4: 53                           	push	ebx
  57a0d5: 56                           	push	esi
  57a0d6: 57                           	push	edi
  57a0d7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57a0dc: 33 c5                        	xor	eax, ebp
  57a0de: 50                           	push	eax
  57a0df: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57a0e2: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57a0e8: 8b f1                        	mov	esi, ecx
  57a0ea: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57a0ed: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
  57a0f0: 33 ff                        	xor	edi, edi
  57a0f2: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57a0f5: 83 f8 01                     	cmp	eax, 0x1
  57a0f8: 0f 85 a5 01 00 00            	jne	0x57a2a3 <.text+0x2a3>
  57a0fe: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a101: 81 c6 d0 02 00 00            	add	esi, 0x2d0
  57a107: 50                           	push	eax
  57a108: 8b ce                        	mov	ecx, esi
  57a10a: e8 71 e2 ff ff               	call	0x578380
  57a10f: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a112: 51                           	push	ecx
  57a113: 8b ce                        	mov	ecx, esi
  57a115: e8 66 e2 ff ff               	call	0x578380
  57a11a: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a11d: 2b 48 78                     	sub	ecx, dword ptr [eax + 0x78]
  57a120: b8 67 66 66 66               	mov	eax, 0x66666667
  57a125: f7 e9                        	imul	ecx
  57a127: c1 fa 02                     	sar	edx, 0x2
  57a12a: 8b c2                        	mov	eax, edx
  57a12c: c1 e8 1f                     	shr	eax, 0x1f
  57a12f: 03 c2                        	add	eax, edx
  57a131: 0f 84 a2 00 00 00            	je	0x57a1d9 <.text+0x1d9>
  57a137: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57a13a: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a13d: 51                           	push	ecx
  57a13e: 8b ce                        	mov	ecx, esi
  57a140: e8 3b e2 ff ff               	call	0x578380
  57a145: 8b 58 78                     	mov	ebx, dword ptr [eax + 0x78]
  57a148: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a14b: 2b cb                        	sub	ecx, ebx
  57a14d: b8 67 66 66 66               	mov	eax, 0x66666667
  57a152: f7 e9                        	imul	ecx
  57a154: c1 fa 02                     	sar	edx, 0x2
  57a157: 8b c2                        	mov	eax, edx
  57a159: c1 e8 1f                     	shr	eax, 0x1f
  57a15c: 03 c2                        	add	eax, edx
  57a15e: 3b f8                        	cmp	edi, eax
  57a160: 0f 83 38 01 00 00            	jae	0x57a29e <.text+0x29e>
  57a166: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57a169: 8a 54 19 05                  	mov	dl, byte ptr [ecx + ebx + 0x5]
  57a16d: 3a 55 18                     	cmp	dl, byte ptr [ebp + 0x18]
  57a170: 75 36                        	jne	0x57a1a8 <.text+0x1a8>
  57a172: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a175: 50                           	push	eax
  57a176: 8b ce                        	mov	ecx, esi
  57a178: e8 03 e2 ff ff               	call	0x578380
  57a17d: 8b 58 78                     	mov	ebx, dword ptr [eax + 0x78]
  57a180: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a183: 2b cb                        	sub	ecx, ebx
  57a185: b8 67 66 66 66               	mov	eax, 0x66666667
  57a18a: f7 e9                        	imul	ecx
  57a18c: c1 fa 02                     	sar	edx, 0x2
  57a18f: 8b ca                        	mov	ecx, edx
  57a191: c1 e9 1f                     	shr	ecx, 0x1f
  57a194: 03 ca                        	add	ecx, edx
  57a196: 3b f9                        	cmp	edi, ecx
  57a198: 0f 83 00 01 00 00            	jae	0x57a29e <.text+0x29e>
  57a19e: 8b 55 28                     	mov	edx, dword ptr [ebp + 0x28]
  57a1a1: 8b 45 f0                     	mov	eax, dword ptr [ebp - 0x10]
  57a1a4: 89 54 18 06                  	mov	dword ptr [eax + ebx + 0x6], edx
  57a1a8: 83 45 f0 0a                  	add	dword ptr [ebp - 0x10], 0xa
  57a1ac: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a1af: 51                           	push	ecx
  57a1b0: 8b ce                        	mov	ecx, esi
  57a1b2: 47                           	inc	edi
  57a1b3: e8 c8 e1 ff ff               	call	0x578380
  57a1b8: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a1bb: 2b 48 78                     	sub	ecx, dword ptr [eax + 0x78]
  57a1be: b8 67 66 66 66               	mov	eax, 0x66666667
  57a1c3: f7 e9                        	imul	ecx
  57a1c5: c1 fa 02                     	sar	edx, 0x2
  57a1c8: 8b c2                        	mov	eax, edx
  57a1ca: c1 e8 1f                     	shr	eax, 0x1f
  57a1cd: 03 c2                        	add	eax, edx
  57a1cf: 3b f8                        	cmp	edi, eax
  57a1d1: 0f 82 63 ff ff ff            	jb	0x57a13a <.text+0x13a>
  57a1d7: 33 ff                        	xor	edi, edi
  57a1d9: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a1dc: 51                           	push	ecx
  57a1dd: 8b ce                        	mov	ecx, esi
  57a1df: e8 9c e1 ff ff               	call	0x578380
  57a1e4: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a1e7: 2b 48 78                     	sub	ecx, dword ptr [eax + 0x78]
  57a1ea: b8 67 66 66 66               	mov	eax, 0x66666667
  57a1ef: f7 e9                        	imul	ecx
  57a1f1: c1 fa 02                     	sar	edx, 0x2
  57a1f4: 8b c2                        	mov	eax, edx
  57a1f6: c1 e8 1f                     	shr	eax, 0x1f
  57a1f9: 03 c2                        	add	eax, edx
  57a1fb: 0f 84 7a 02 00 00            	je	0x57a47b <.text+0x47b>
  57a201: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57a204: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a207: 51                           	push	ecx
  57a208: 8b ce                        	mov	ecx, esi
  57a20a: e8 71 e1 ff ff               	call	0x578380
  57a20f: 8b 58 78                     	mov	ebx, dword ptr [eax + 0x78]
  57a212: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a215: 2b cb                        	sub	ecx, ebx
  57a217: b8 67 66 66 66               	mov	eax, 0x66666667
  57a21c: f7 e9                        	imul	ecx
  57a21e: c1 fa 02                     	sar	edx, 0x2
  57a221: 8b c2                        	mov	eax, edx
  57a223: c1 e8 1f                     	shr	eax, 0x1f
  57a226: 03 c2                        	add	eax, edx
  57a228: 3b f8                        	cmp	edi, eax
  57a22a: 73 72                        	jae	0x57a29e <.text+0x29e>
  57a22c: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57a22f: 8a 54 19 05                  	mov	dl, byte ptr [ecx + ebx + 0x5]
  57a233: 3a 55 24                     	cmp	dl, byte ptr [ebp + 0x24]
  57a236: 75 32                        	jne	0x57a26a <.text+0x26a>
  57a238: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a23b: 50                           	push	eax
  57a23c: 8b ce                        	mov	ecx, esi
  57a23e: e8 3d e1 ff ff               	call	0x578380
  57a243: 8b 58 78                     	mov	ebx, dword ptr [eax + 0x78]
  57a246: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a249: 2b cb                        	sub	ecx, ebx
  57a24b: b8 67 66 66 66               	mov	eax, 0x66666667
  57a250: f7 e9                        	imul	ecx
  57a252: c1 fa 02                     	sar	edx, 0x2
  57a255: 8b ca                        	mov	ecx, edx
  57a257: c1 e9 1f                     	shr	ecx, 0x1f
  57a25a: 03 ca                        	add	ecx, edx
  57a25c: 3b f9                        	cmp	edi, ecx
  57a25e: 73 3e                        	jae	0x57a29e <.text+0x29e>
  57a260: 8b 55 1c                     	mov	edx, dword ptr [ebp + 0x1c]
  57a263: 8b 45 f0                     	mov	eax, dword ptr [ebp - 0x10]
  57a266: 89 54 18 06                  	mov	dword ptr [eax + ebx + 0x6], edx
  57a26a: 83 45 f0 0a                  	add	dword ptr [ebp - 0x10], 0xa
  57a26e: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a271: 51                           	push	ecx
  57a272: 8b ce                        	mov	ecx, esi
  57a274: 47                           	inc	edi
  57a275: e8 06 e1 ff ff               	call	0x578380
  57a27a: 8b 48 7c                     	mov	ecx, dword ptr [eax + 0x7c]
  57a27d: 2b 48 78                     	sub	ecx, dword ptr [eax + 0x78]
  57a280: b8 67 66 66 66               	mov	eax, 0x66666667
  57a285: f7 e9                        	imul	ecx
  57a287: c1 fa 02                     	sar	edx, 0x2
  57a28a: 8b c2                        	mov	eax, edx
  57a28c: c1 e8 1f                     	shr	eax, 0x1f
  57a28f: 03 c2                        	add	eax, edx
  57a291: 3b f8                        	cmp	edi, eax
  57a293: 0f 82 6b ff ff ff            	jb	0x57a204 <.text+0x204>
  57a299: e9 dd 01 00 00               	jmp	0x57a47b <.text+0x47b>
  57a29e: e8 04 cb e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57a2a3: 83 f8 02                     	cmp	eax, 0x2
  57a2a6: 0f 85 cf 01 00 00            	jne	0x57a47b <.text+0x47b>
  57a2ac: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a2af: 81 c6 d0 02 00 00            	add	esi, 0x2d0
  57a2b5: 51                           	push	ecx
  57a2b6: 8b ce                        	mov	ecx, esi
  57a2b8: e8 c3 e0 ff ff               	call	0x578380
  57a2bd: 8d 55 10                     	lea	edx, [ebp + 0x10]
  57a2c0: 52                           	push	edx
  57a2c1: 8b ce                        	mov	ecx, esi
  57a2c3: e8 b8 e0 ff ff               	call	0x578380
  57a2c8: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a2ce: 2b 88 8c 00 00 00            	sub	ecx, dword ptr [eax + 0x8c]
  57a2d4: b8 67 66 66 66               	mov	eax, 0x66666667
  57a2d9: f7 e9                        	imul	ecx
  57a2db: c1 fa 02                     	sar	edx, 0x2
  57a2de: 8b c2                        	mov	eax, edx
  57a2e0: c1 e8 1f                     	shr	eax, 0x1f
  57a2e3: 03 c2                        	add	eax, edx
  57a2e5: 0f 84 b0 00 00 00            	je	0x57a39b <.text+0x39b>
  57a2eb: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57a2ee: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a2f1: 51                           	push	ecx
  57a2f2: 8b ce                        	mov	ecx, esi
  57a2f4: e8 87 e0 ff ff               	call	0x578380
  57a2f9: 8b 98 8c 00 00 00            	mov	ebx, dword ptr [eax + 0x8c]
  57a2ff: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a305: 2b cb                        	sub	ecx, ebx
  57a307: b8 67 66 66 66               	mov	eax, 0x66666667
  57a30c: f7 e9                        	imul	ecx
  57a30e: c1 fa 02                     	sar	edx, 0x2
  57a311: 8b c2                        	mov	eax, edx
  57a313: c1 e8 1f                     	shr	eax, 0x1f
  57a316: 03 c2                        	add	eax, edx
  57a318: 3b f8                        	cmp	edi, eax
  57a31a: 73 82                        	jae	0x57a29e <.text+0x29e>
  57a31c: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57a31f: 8a 54 19 05                  	mov	dl, byte ptr [ecx + ebx + 0x5]
  57a323: 3a 55 18                     	cmp	dl, byte ptr [ebp + 0x18]
  57a326: 75 3c                        	jne	0x57a364 <.text+0x364>
  57a328: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a32b: 50                           	push	eax
  57a32c: 8b ce                        	mov	ecx, esi
  57a32e: e8 4d e0 ff ff               	call	0x578380
  57a333: 8b 98 8c 00 00 00            	mov	ebx, dword ptr [eax + 0x8c]
  57a339: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a33f: 2b cb                        	sub	ecx, ebx
  57a341: b8 67 66 66 66               	mov	eax, 0x66666667
  57a346: f7 e9                        	imul	ecx
  57a348: c1 fa 02                     	sar	edx, 0x2
  57a34b: 8b ca                        	mov	ecx, edx
  57a34d: c1 e9 1f                     	shr	ecx, 0x1f
  57a350: 03 ca                        	add	ecx, edx
  57a352: 3b f9                        	cmp	edi, ecx
  57a354: 0f 83 44 ff ff ff            	jae	0x57a29e <.text+0x29e>
  57a35a: 8b 55 28                     	mov	edx, dword ptr [ebp + 0x28]
  57a35d: 8b 45 f0                     	mov	eax, dword ptr [ebp - 0x10]
  57a360: 89 54 18 06                  	mov	dword ptr [eax + ebx + 0x6], edx
  57a364: 83 45 f0 0a                  	add	dword ptr [ebp - 0x10], 0xa
  57a368: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a36b: 51                           	push	ecx
  57a36c: 8b ce                        	mov	ecx, esi
  57a36e: 47                           	inc	edi
  57a36f: e8 0c e0 ff ff               	call	0x578380
  57a374: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a37a: 2b 88 8c 00 00 00            	sub	ecx, dword ptr [eax + 0x8c]
  57a380: b8 67 66 66 66               	mov	eax, 0x66666667
  57a385: f7 e9                        	imul	ecx
  57a387: c1 fa 02                     	sar	edx, 0x2
  57a38a: 8b c2                        	mov	eax, edx
  57a38c: c1 e8 1f                     	shr	eax, 0x1f
  57a38f: 03 c2                        	add	eax, edx
  57a391: 3b f8                        	cmp	edi, eax
  57a393: 0f 82 55 ff ff ff            	jb	0x57a2ee <.text+0x2ee>
  57a399: 33 ff                        	xor	edi, edi
  57a39b: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a39e: 51                           	push	ecx
  57a39f: 8b ce                        	mov	ecx, esi
  57a3a1: e8 da df ff ff               	call	0x578380
  57a3a6: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a3ac: 2b 88 8c 00 00 00            	sub	ecx, dword ptr [eax + 0x8c]
  57a3b2: b8 67 66 66 66               	mov	eax, 0x66666667
  57a3b7: f7 e9                        	imul	ecx
  57a3b9: c1 fa 02                     	sar	edx, 0x2
  57a3bc: 8b c2                        	mov	eax, edx
  57a3be: c1 e8 1f                     	shr	eax, 0x1f
  57a3c1: 03 c2                        	add	eax, edx
  57a3c3: 0f 84 b2 00 00 00            	je	0x57a47b <.text+0x47b>
  57a3c9: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57a3cc: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a3cf: 51                           	push	ecx
  57a3d0: 8b ce                        	mov	ecx, esi
  57a3d2: e8 a9 df ff ff               	call	0x578380
  57a3d7: 8b 98 8c 00 00 00            	mov	ebx, dword ptr [eax + 0x8c]
  57a3dd: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a3e3: 2b cb                        	sub	ecx, ebx
  57a3e5: b8 67 66 66 66               	mov	eax, 0x66666667
  57a3ea: f7 e9                        	imul	ecx
  57a3ec: c1 fa 02                     	sar	edx, 0x2
  57a3ef: 8b c2                        	mov	eax, edx
  57a3f1: c1 e8 1f                     	shr	eax, 0x1f
  57a3f4: 03 c2                        	add	eax, edx
  57a3f6: 3b f8                        	cmp	edi, eax
  57a3f8: 0f 83 a0 fe ff ff            	jae	0x57a29e <.text+0x29e>
  57a3fe: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57a401: 8a 54 19 05                  	mov	dl, byte ptr [ecx + ebx + 0x5]
  57a405: 3a 55 24                     	cmp	dl, byte ptr [ebp + 0x24]
  57a408: 75 3c                        	jne	0x57a446 <.text+0x446>
  57a40a: 8d 45 10                     	lea	eax, [ebp + 0x10]
  57a40d: 50                           	push	eax
  57a40e: 8b ce                        	mov	ecx, esi
  57a410: e8 6b df ff ff               	call	0x578380
  57a415: 8b 98 8c 00 00 00            	mov	ebx, dword ptr [eax + 0x8c]
  57a41b: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a421: 2b cb                        	sub	ecx, ebx
  57a423: b8 67 66 66 66               	mov	eax, 0x66666667
  57a428: f7 e9                        	imul	ecx
  57a42a: c1 fa 02                     	sar	edx, 0x2
  57a42d: 8b ca                        	mov	ecx, edx
  57a42f: c1 e9 1f                     	shr	ecx, 0x1f
  57a432: 03 ca                        	add	ecx, edx
  57a434: 3b f9                        	cmp	edi, ecx
  57a436: 0f 83 62 fe ff ff            	jae	0x57a29e <.text+0x29e>
  57a43c: 8b 55 1c                     	mov	edx, dword ptr [ebp + 0x1c]
  57a43f: 8b 45 f0                     	mov	eax, dword ptr [ebp - 0x10]
  57a442: 89 54 18 06                  	mov	dword ptr [eax + ebx + 0x6], edx
  57a446: 83 45 f0 0a                  	add	dword ptr [ebp - 0x10], 0xa
  57a44a: 8d 4d 10                     	lea	ecx, [ebp + 0x10]
  57a44d: 51                           	push	ecx
  57a44e: 8b ce                        	mov	ecx, esi
  57a450: 47                           	inc	edi
  57a451: e8 2a df ff ff               	call	0x578380
  57a456: 8b 88 90 00 00 00            	mov	ecx, dword ptr [eax + 0x90]
  57a45c: 2b 88 8c 00 00 00            	sub	ecx, dword ptr [eax + 0x8c]
  57a462: b8 67 66 66 66               	mov	eax, 0x66666667
  57a467: f7 e9                        	imul	ecx
  57a469: c1 fa 02                     	sar	edx, 0x2
  57a46c: 8b c2                        	mov	eax, edx
  57a46e: c1 e8 1f                     	shr	eax, 0x1f
  57a471: 03 c2                        	add	eax, edx
  57a473: 3b f8                        	cmp	edi, eax
  57a475: 0f 82 51 ff ff ff            	jb	0x57a3cc <.text+0x3cc>
  57a47b: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57a47e: e8 fd ef ff ff               	call	0x579480
  57a483: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57a486: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57a48d: 59                           	pop	ecx
  57a48e: 5f                           	pop	edi
  57a48f: 5e                           	pop	esi
  57a490: 5b                           	pop	ebx
  57a491: 8b e5                        	mov	esp, ebp
  57a493: 5d                           	pop	ebp
  57a494: c2 24 00                     	ret	0x24
  57a497: cc                           	int3
  57a498: cc                           	int3
  57a499: cc                           	int3
  57a49a: cc                           	int3
  57a49b: cc                           	int3
  57a49c: cc                           	int3
  57a49d: cc                           	int3
  57a49e: cc                           	int3
  57a49f: cc                           	int3
  57a4a0: 55                           	push	ebp
  57a4a1: 8b ec                        	mov	ebp, esp
  57a4a3: 6a ff                        	push	-0x1
  57a4a5: 68 68 d2 41 01               	push	0x141d268
  57a4aa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57a4b0: 50                           	push	eax
  57a4b1: 83 ec 08                     	sub	esp, 0x8
  57a4b4: 53                           	push	ebx
  57a4b5: 56                           	push	esi
  57a4b6: 57                           	push	edi
  57a4b7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57a4bc: 33 c5                        	xor	eax, ebp
  57a4be: 50                           	push	eax
  57a4bf: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57a4c2: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57a4c8: a1 b8 d5 a4 01               	mov	eax, dword ptr [0x1a4d5b8]
  57a4cd: 8b 90 04 03 00 00            	mov	edx, dword ptr [eax + 0x304]
  57a4d3: 8d b9 d0 02 00 00            	lea	edi, [ecx + 0x2d0]
  57a4d9: 8d 45 ec                     	lea	eax, [ebp - 0x14]
  57a4dc: 33 f6                        	xor	esi, esi
  57a4de: 50                           	push	eax
  57a4df: 8b cf                        	mov	ecx, edi
  57a4e1: 89 75 fc                     	mov	dword ptr [ebp - 0x4], esi
  57a4e4: 89 55 ec                     	mov	dword ptr [ebp - 0x14], edx
  57a4e7: e8 44 dd ff ff               	call	0x578230
  57a4ec: 8b 88 a4 00 00 00            	mov	ecx, dword ptr [eax + 0xa4]
  57a4f2: 2b 88 a0 00 00 00            	sub	ecx, dword ptr [eax + 0xa0]
  57a4f8: b8 67 66 66 66               	mov	eax, 0x66666667
  57a4fd: f7 e9                        	imul	ecx
  57a4ff: d1 fa                        	sar	edx
  57a501: 8b ca                        	mov	ecx, edx
  57a503: c1 e9 1f                     	shr	ecx, 0x1f
  57a506: 03 ca                        	add	ecx, edx
  57a508: 0f 84 d4 00 00 00            	je	0x57a5e2 <.text+0x5e2>
  57a50e: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  57a511: 8b 15 b8 d5 a4 01            	mov	edx, dword ptr [0x1a4d5b8]
  57a517: 8b 82 04 03 00 00            	mov	eax, dword ptr [edx + 0x304]
  57a51d: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57a520: 51                           	push	ecx
  57a521: 8b cf                        	mov	ecx, edi
  57a523: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  57a526: e8 05 dd ff ff               	call	0x578230
  57a52b: 8b 98 a0 00 00 00            	mov	ebx, dword ptr [eax + 0xa0]
  57a531: 8b 88 a4 00 00 00            	mov	ecx, dword ptr [eax + 0xa4]
  57a537: 2b cb                        	sub	ecx, ebx
  57a539: b8 67 66 66 66               	mov	eax, 0x66666667
  57a53e: f7 e9                        	imul	ecx
  57a540: d1 fa                        	sar	edx
  57a542: 8b c2                        	mov	eax, edx
  57a544: c1 e8 1f                     	shr	eax, 0x1f
  57a547: 03 c2                        	add	eax, edx
  57a549: 3b f0                        	cmp	esi, eax
  57a54b: 0f 83 a5 00 00 00            	jae	0x57a5f6 <.text+0x5f6>
  57a551: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57a554: 8b 14 19                     	mov	edx, dword ptr [ecx + ebx]
  57a557: 3b 55 10                     	cmp	edx, dword ptr [ebp + 0x10]
  57a55a: 75 43                        	jne	0x57a59f <.text+0x59f>
  57a55c: a1 b8 d5 a4 01               	mov	eax, dword ptr [0x1a4d5b8]
  57a561: 8b 88 04 03 00 00            	mov	ecx, dword ptr [eax + 0x304]
  57a567: 8d 55 ec                     	lea	edx, [ebp - 0x14]
  57a56a: 89 4d ec                     	mov	dword ptr [ebp - 0x14], ecx
  57a56d: 52                           	push	edx
  57a56e: 8b cf                        	mov	ecx, edi
  57a570: e8 bb dc ff ff               	call	0x578230
  57a575: 8b 98 a0 00 00 00            	mov	ebx, dword ptr [eax + 0xa0]
  57a57b: 8b 88 a4 00 00 00            	mov	ecx, dword ptr [eax + 0xa4]
  57a581: 2b cb                        	sub	ecx, ebx
  57a583: b8 67 66 66 66               	mov	eax, 0x66666667
  57a588: f7 e9                        	imul	ecx
  57a58a: d1 fa                        	sar	edx
  57a58c: 8b c2                        	mov	eax, edx
  57a58e: c1 e8 1f                     	shr	eax, 0x1f
  57a591: 03 c2                        	add	eax, edx
  57a593: 3b f0                        	cmp	esi, eax
  57a595: 73 5f                        	jae	0x57a5f6 <.text+0x5f6>
  57a597: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57a59a: c6 44 19 04 01               	mov	byte ptr [ecx + ebx + 0x4], 0x1
  57a59f: 8b 15 b8 d5 a4 01            	mov	edx, dword ptr [0x1a4d5b8]
  57a5a5: 8b 82 04 03 00 00            	mov	eax, dword ptr [edx + 0x304]
  57a5ab: 83 45 f0 05                  	add	dword ptr [ebp - 0x10], 0x5
  57a5af: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57a5b2: 51                           	push	ecx
  57a5b3: 8b cf                        	mov	ecx, edi
  57a5b5: 46                           	inc	esi
  57a5b6: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  57a5b9: e8 72 dc ff ff               	call	0x578230
  57a5be: 8b 88 a4 00 00 00            	mov	ecx, dword ptr [eax + 0xa4]
  57a5c4: 2b 88 a0 00 00 00            	sub	ecx, dword ptr [eax + 0xa0]
  57a5ca: b8 67 66 66 66               	mov	eax, 0x66666667
  57a5cf: f7 e9                        	imul	ecx
  57a5d1: d1 fa                        	sar	edx
  57a5d3: 8b c2                        	mov	eax, edx
  57a5d5: c1 e8 1f                     	shr	eax, 0x1f
  57a5d8: 03 c2                        	add	eax, edx
  57a5da: 3b f0                        	cmp	esi, eax
  57a5dc: 0f 82 2f ff ff ff            	jb	0x57a511 <.text+0x511>
  57a5e2: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57a5e5: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57a5ec: 59                           	pop	ecx
  57a5ed: 5f                           	pop	edi
  57a5ee: 5e                           	pop	esi
  57a5ef: 5b                           	pop	ebx
  57a5f0: 8b e5                        	mov	esp, ebp
  57a5f2: 5d                           	pop	ebp
  57a5f3: c2 0c 00                     	ret	0xc
  57a5f6: e8 ac c7 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57a5fb: cc                           	int3
  57a5fc: cc                           	int3
  57a5fd: cc                           	int3
  57a5fe: cc                           	int3
  57a5ff: cc                           	int3
  57a600: 55                           	push	ebp
  57a601: 8b ec                        	mov	ebp, esp
  57a603: 83 ec 28                     	sub	esp, 0x28
  57a606: 56                           	push	esi
  57a607: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57a60a: 50                           	push	eax
  57a60b: 8b f1                        	mov	esi, ecx
  57a60d: e8 2e 9d 24 00               	call	0x7c4340 <.text+0x24a340>
  57a612: 83 ec 0c                     	sub	esp, 0xc
  57a615: 8b cc                        	mov	ecx, esp
  57a617: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57a61d: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57a624: 8b 10                        	mov	edx, dword ptr [eax]
  57a626: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57a629: 85 d2                        	test	edx, edx
  57a62b: 74 0a                        	je	0x57a637 <.text+0x637>
  57a62d: 8b 12                        	mov	edx, dword ptr [edx]
  57a62f: 85 d2                        	test	edx, edx
  57a631: 74 04                        	je	0x57a637 <.text+0x637>
  57a633: 8b 12                        	mov	edx, dword ptr [edx]
  57a635: 89 11                        	mov	dword ptr [ecx], edx
  57a637: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57a63a: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57a63d: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  57a640: 51                           	push	ecx
  57a641: 8b ce                        	mov	ecx, esi
  57a643: e8 28 bb bf 00               	call	0x1176170 <.text+0xbfc170>
  57a648: 83 ec 0c                     	sub	esp, 0xc
  57a64b: 8b cc                        	mov	ecx, esp
  57a64d: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57a653: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57a65a: 8b 10                        	mov	edx, dword ptr [eax]
  57a65c: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57a65f: 85 d2                        	test	edx, edx
  57a661: 74 0a                        	je	0x57a66d <.text+0x66d>
  57a663: 8b 12                        	mov	edx, dword ptr [edx]
  57a665: 85 d2                        	test	edx, edx
  57a667: 74 04                        	je	0x57a66d <.text+0x66d>
  57a669: 8b 12                        	mov	edx, dword ptr [edx]
  57a66b: 89 11                        	mov	dword ptr [ecx], edx
  57a66d: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57a670: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57a673: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57a676: 51                           	push	ecx
  57a677: 8b ce                        	mov	ecx, esi
  57a679: e8 52 de ff ff               	call	0x5784d0
  57a67e: 5e                           	pop	esi
  57a67f: 8b e5                        	mov	esp, ebp
  57a681: 5d                           	pop	ebp
  57a682: c3                           	ret
  57a683: cc                           	int3
  57a684: cc                           	int3
  57a685: cc                           	int3
  57a686: cc                           	int3
  57a687: cc                           	int3
  57a688: cc                           	int3
  57a689: cc                           	int3
  57a68a: cc                           	int3
  57a68b: cc                           	int3
  57a68c: cc                           	int3
  57a68d: cc                           	int3
  57a68e: cc                           	int3
  57a68f: cc                           	int3
  57a690: 55                           	push	ebp
  57a691: 8b ec                        	mov	ebp, esp
  57a693: 83 ec 08                     	sub	esp, 0x8
  57a696: 53                           	push	ebx
  57a697: 56                           	push	esi
  57a698: 8b f1                        	mov	esi, ecx
  57a69a: 57                           	push	edi
  57a69b: 33 db                        	xor	ebx, ebx
  57a69d: 53                           	push	ebx
  57a69e: 8d 4e 78                     	lea	ecx, [esi + 0x78]
  57a6a1: 89 9e c4 01 00 00            	mov	dword ptr [esi + 0x1c4], ebx
  57a6a7: e8 84 fd c3 00               	call	0x11ba430 <.text+0xc40430>
  57a6ac: 8d 4e 78                     	lea	ecx, [esi + 0x78]
  57a6af: e8 3c fd c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57a6b4: 8d be 94 00 00 00            	lea	edi, [esi + 0x94]
  57a6ba: c7 45 f8 0a 00 00 00         	mov	dword ptr [ebp - 0x8], 0xa
  57a6c1: 53                           	push	ebx
  57a6c2: 8b cf                        	mov	ecx, edi
  57a6c4: e8 67 fd c3 00               	call	0x11ba430 <.text+0xc40430>
  57a6c9: 8b cf                        	mov	ecx, edi
  57a6cb: e8 20 fd c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57a6d0: 83 c7 1c                     	add	edi, 0x1c
  57a6d3: ff 4d f8                     	dec	dword ptr [ebp - 0x8]
  57a6d6: 75 e9                        	jne	0x57a6c1 <.text+0x6c1>
  57a6d8: 8d 8e ac 01 00 00            	lea	ecx, [esi + 0x1ac]
  57a6de: 89 5e 70                     	mov	dword ptr [esi + 0x70], ebx
  57a6e1: 89 5e 74                     	mov	dword ptr [esi + 0x74], ebx
  57a6e4: e8 17 ff ff ff               	call	0x57a600 <.text+0x600>
  57a6e9: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
  57a6ec: 89 9e c0 01 00 00            	mov	dword ptr [esi + 0x1c0], ebx
  57a6f2: 89 9e c4 01 00 00            	mov	dword ptr [esi + 0x1c4], ebx
  57a6f8: 89 9e c8 01 00 00            	mov	dword ptr [esi + 0x1c8], ebx
  57a6fe: 89 9e cc 01 00 00            	mov	dword ptr [esi + 0x1cc], ebx
  57a704: 66 89 9e d0 01 00 00         	mov	word ptr [esi + 0x1d0], bx
  57a70b: e8 40 ee e0 00               	call	0x1389550 <.text+0xe0f550>
  57a710: 8d 4e 18                     	lea	ecx, [esi + 0x18]
  57a713: e8 c8 49 da 00               	call	0x131f0e0 <.text+0xda50e0>
  57a718: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57a71b: e8 60 c3 bb 00               	call	0x1136a80 <.text+0xbbca80>
  57a720: 8d 4e 40                     	lea	ecx, [esi + 0x40]
  57a723: e8 98 b9 ff ff               	call	0x5760c0
  57a728: 53                           	push	ebx
  57a729: 8d 8e dc 01 00 00            	lea	ecx, [esi + 0x1dc]
  57a72f: 89 9e d4 01 00 00            	mov	dword ptr [esi + 0x1d4], ebx
  57a735: 89 9e d8 01 00 00            	mov	dword ptr [esi + 0x1d8], ebx
  57a73b: e8 f0 fc c3 00               	call	0x11ba430 <.text+0xc40430>
  57a740: 8d 8e dc 01 00 00            	lea	ecx, [esi + 0x1dc]
  57a746: e8 a5 fc c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57a74b: c7 86 f8 01 00 00 04 00 00 00	mov	dword ptr [esi + 0x1f8], 0x4
  57a755: 8b 86 1c 02 00 00            	mov	eax, dword ptr [esi + 0x21c]
  57a75b: 8b 48 04                     	mov	ecx, dword ptr [eax + 0x4]
  57a75e: 51                           	push	ecx
  57a75f: 8d 8e 14 02 00 00            	lea	ecx, [esi + 0x214]
  57a765: e8 a6 7a ff ff               	call	0x572210
  57a76a: 8b 86 1c 02 00 00            	mov	eax, dword ptr [esi + 0x21c]
  57a770: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57a773: 8b 86 1c 02 00 00            	mov	eax, dword ptr [esi + 0x21c]
  57a779: 89 00                        	mov	dword ptr [eax], eax
  57a77b: 8b 86 1c 02 00 00            	mov	eax, dword ptr [esi + 0x21c]
  57a781: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57a784: 89 9e 20 02 00 00            	mov	dword ptr [esi + 0x220], ebx
  57a78a: 53                           	push	ebx
  57a78b: 8d 8e 40 02 00 00            	lea	ecx, [esi + 0x240]
  57a791: 89 9e 28 02 00 00            	mov	dword ptr [esi + 0x228], ebx
  57a797: 89 9e 30 02 00 00            	mov	dword ptr [esi + 0x230], ebx
  57a79d: 89 9e 38 02 00 00            	mov	dword ptr [esi + 0x238], ebx
  57a7a3: 89 9e 3c 02 00 00            	mov	dword ptr [esi + 0x23c], ebx
  57a7a9: e8 82 fc c3 00               	call	0x11ba430 <.text+0xc40430>
  57a7ae: 8d 8e 40 02 00 00            	lea	ecx, [esi + 0x240]
  57a7b4: e8 37 fc c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57a7b9: 89 9e 70 02 00 00            	mov	dword ptr [esi + 0x270], ebx
  57a7bf: 8b 96 9c 02 00 00            	mov	edx, dword ptr [esi + 0x29c]
  57a7c5: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57a7c8: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a7cb: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a7ce: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57a7d1: 75 31                        	jne	0x57a804 <.text+0x804>
  57a7d3: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a7d6: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57a7d9: 51                           	push	ecx
  57a7da: 8d 8e 94 02 00 00            	lea	ecx, [esi + 0x294]
  57a7e0: e8 1b b6 bb 00               	call	0x1135e00 <.text+0xbbbe00>
  57a7e5: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57a7e8: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  57a7eb: 8b 02                        	mov	eax, dword ptr [edx]
  57a7ed: 51                           	push	ecx
  57a7ee: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a7f1: e8 31 b3 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57a7f6: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a7f9: 83 c4 04                     	add	esp, 0x4
  57a7fc: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a7ff: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57a802: 74 cf                        	je	0x57a7d3 <.text+0x7d3>
  57a804: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57a80a: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57a80d: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57a813: 89 00                        	mov	dword ptr [eax], eax
  57a815: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57a81b: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57a81e: 89 9e a0 02 00 00            	mov	dword ptr [esi + 0x2a0], ebx
  57a824: 8b 96 b0 02 00 00            	mov	edx, dword ptr [esi + 0x2b0]
  57a82a: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57a82d: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a830: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a833: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57a836: 75 31                        	jne	0x57a869 <.text+0x869>
  57a838: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a83b: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57a83e: 51                           	push	ecx
  57a83f: 8d 8e a8 02 00 00            	lea	ecx, [esi + 0x2a8]
  57a845: e8 b6 b5 bb 00               	call	0x1135e00 <.text+0xbbbe00>
  57a84a: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57a84d: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  57a850: 8b 02                        	mov	eax, dword ptr [edx]
  57a852: 51                           	push	ecx
  57a853: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a856: e8 cc b2 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57a85b: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a85e: 83 c4 04                     	add	esp, 0x4
  57a861: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a864: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57a867: 74 cf                        	je	0x57a838 <.text+0x838>
  57a869: 8b 86 b0 02 00 00            	mov	eax, dword ptr [esi + 0x2b0]
  57a86f: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57a872: 8b 86 b0 02 00 00            	mov	eax, dword ptr [esi + 0x2b0]
  57a878: 89 00                        	mov	dword ptr [eax], eax
  57a87a: 8b 86 b0 02 00 00            	mov	eax, dword ptr [esi + 0x2b0]
  57a880: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57a883: 89 9e b4 02 00 00            	mov	dword ptr [esi + 0x2b4], ebx
  57a889: 8b 96 c4 02 00 00            	mov	edx, dword ptr [esi + 0x2c4]
  57a88f: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57a892: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a895: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a898: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57a89b: 75 34                        	jne	0x57a8d1 <.text+0x8d1>
  57a89d: 8d 49 00                     	lea	ecx, [ecx]
  57a8a0: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a8a3: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57a8a6: 51                           	push	ecx
  57a8a7: 8d 8e bc 02 00 00            	lea	ecx, [esi + 0x2bc]
  57a8ad: e8 4e b5 bb 00               	call	0x1135e00 <.text+0xbbbe00>
  57a8b2: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57a8b5: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  57a8b8: 8b 02                        	mov	eax, dword ptr [edx]
  57a8ba: 51                           	push	ecx
  57a8bb: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a8be: e8 64 b2 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57a8c3: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a8c6: 83 c4 04                     	add	esp, 0x4
  57a8c9: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a8cc: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57a8cf: 74 cf                        	je	0x57a8a0 <.text+0x8a0>
  57a8d1: 8b 86 c4 02 00 00            	mov	eax, dword ptr [esi + 0x2c4]
  57a8d7: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57a8da: 8b 86 c4 02 00 00            	mov	eax, dword ptr [esi + 0x2c4]
  57a8e0: 89 00                        	mov	dword ptr [eax], eax
  57a8e2: 8b 86 c4 02 00 00            	mov	eax, dword ptr [esi + 0x2c4]
  57a8e8: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57a8eb: 89 9e c8 02 00 00            	mov	dword ptr [esi + 0x2c8], ebx
  57a8f1: 8b 96 d8 02 00 00            	mov	edx, dword ptr [esi + 0x2d8]
  57a8f7: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57a8fa: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a8fd: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a900: 38 98 c1 00 00 00            	cmp	byte ptr [eax + 0xc1], bl
  57a906: 75 3f                        	jne	0x57a947 <.text+0x947>
  57a908: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a90b: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57a90e: 51                           	push	ecx
  57a90f: 8d 8e d0 02 00 00            	lea	ecx, [esi + 0x2d0]
  57a915: e8 16 c3 ff ff               	call	0x576c30
  57a91a: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57a91d: 8b 02                        	mov	eax, dword ptr [edx]
  57a91f: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  57a922: 83 c1 10                     	add	ecx, 0x10
  57a925: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a928: e8 83 8e ff ff               	call	0x5737b0
  57a92d: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  57a930: 51                           	push	ecx
  57a931: e8 f1 b1 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57a936: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a939: 83 c4 04                     	add	esp, 0x4
  57a93c: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a93f: 38 98 c1 00 00 00            	cmp	byte ptr [eax + 0xc1], bl
  57a945: 74 c1                        	je	0x57a908 <.text+0x908>
  57a947: 8b 86 d8 02 00 00            	mov	eax, dword ptr [esi + 0x2d8]
  57a94d: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57a950: 8b 86 d8 02 00 00            	mov	eax, dword ptr [esi + 0x2d8]
  57a956: 89 00                        	mov	dword ptr [eax], eax
  57a958: 8b 86 d8 02 00 00            	mov	eax, dword ptr [esi + 0x2d8]
  57a95e: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57a961: 89 9e dc 02 00 00            	mov	dword ptr [esi + 0x2dc], ebx
  57a967: 8d 8e 08 03 00 00            	lea	ecx, [esi + 0x308]
  57a96d: 89 9e e4 02 00 00            	mov	dword ptr [esi + 0x2e4], ebx
  57a973: c7 86 fc 02 00 00 ff ff ff ff	mov	dword ptr [esi + 0x2fc], 0xffffffff
  57a97d: c7 86 04 03 00 00 01 00 00 00	mov	dword ptr [esi + 0x304], 0x1
  57a987: e8 b4 bf ed ff               	call	0x456940
  57a98c: 8d 8e 1c 03 00 00            	lea	ecx, [esi + 0x31c]
  57a992: e8 a9 bf ed ff               	call	0x456940
  57a997: 89 9e 44 03 00 00            	mov	dword ptr [esi + 0x344], ebx
  57a99d: 89 9e 48 03 00 00            	mov	dword ptr [esi + 0x348], ebx
  57a9a3: 89 9e 58 03 00 00            	mov	dword ptr [esi + 0x358], ebx
  57a9a9: 8b 96 f0 02 00 00            	mov	edx, dword ptr [esi + 0x2f0]
  57a9af: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57a9b2: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a9b5: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a9b8: 38 58 1d                     	cmp	byte ptr [eax + 0x1d], bl
  57a9bb: 75 34                        	jne	0x57a9f1 <.text+0x9f1>
  57a9bd: 8d 49 00                     	lea	ecx, [ecx]
  57a9c0: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a9c3: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57a9c6: 51                           	push	ecx
  57a9c7: 8d 8e e8 02 00 00            	lea	ecx, [esi + 0x2e8]
  57a9cd: e8 8e d4 3e 00               	call	0x967e60 <.text+0x3ede60>
  57a9d2: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57a9d5: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  57a9d8: 8b 02                        	mov	eax, dword ptr [edx]
  57a9da: 51                           	push	ecx
  57a9db: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57a9de: e8 44 b1 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57a9e3: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57a9e6: 83 c4 04                     	add	esp, 0x4
  57a9e9: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57a9ec: 38 58 1d                     	cmp	byte ptr [eax + 0x1d], bl
  57a9ef: 74 cf                        	je	0x57a9c0 <.text+0x9c0>
  57a9f1: 8b 86 f0 02 00 00            	mov	eax, dword ptr [esi + 0x2f0]
  57a9f7: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57a9fa: 8b 86 f0 02 00 00            	mov	eax, dword ptr [esi + 0x2f0]
  57aa00: 89 00                        	mov	dword ptr [eax], eax
  57aa02: 8b 86 f0 02 00 00            	mov	eax, dword ptr [esi + 0x2f0]
  57aa08: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57aa0b: 89 9e f4 02 00 00            	mov	dword ptr [esi + 0x2f4], ebx
  57aa11: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  57aa17: c6 86 68 03 00 00 01         	mov	byte ptr [esi + 0x368], 0x1
  57aa1e: 89 9e 6c 03 00 00            	mov	dword ptr [esi + 0x36c], ebx
  57aa24: 89 9e 74 03 00 00            	mov	dword ptr [esi + 0x374], ebx
  57aa2a: e8 91 b6 ff ff               	call	0x5760c0
  57aa2f: 33 d2                        	xor	edx, edx
  57aa31: 8d 8e 4c 03 00 00            	lea	ecx, [esi + 0x34c]
  57aa37: 88 9e 94 03 00 00            	mov	byte ptr [esi + 0x394], bl
  57aa3d: 89 9e 9c 03 00 00            	mov	dword ptr [esi + 0x39c], ebx
  57aa43: 88 9e a0 03 00 00            	mov	byte ptr [esi + 0x3a0], bl
  57aa49: 8d 41 08                     	lea	eax, [ecx + 0x8]
  57aa4c: 66 89 96 a1 03 00 00         	mov	word ptr [esi + 0x3a1], dx
  57aa53: 50                           	push	eax
  57aa54: 8d 55 f8                     	lea	edx, [ebp - 0x8]
  57aa57: 52                           	push	edx
  57aa58: 89 5d f8                     	mov	dword ptr [ebp - 0x8], ebx
  57aa5b: e8 d0 5e c2 00               	call	0x11a0930 <.text+0xc26930>
  57aa60: 89 9e 95 03 00 00            	mov	dword ptr [esi + 0x395], ebx
  57aa66: 5f                           	pop	edi
  57aa67: 66 89 9e 99 03 00 00         	mov	word ptr [esi + 0x399], bx
  57aa6e: 5e                           	pop	esi
  57aa6f: 5b                           	pop	ebx
  57aa70: 8b e5                        	mov	esp, ebp
  57aa72: 5d                           	pop	ebp
  57aa73: c3                           	ret
  57aa74: cc                           	int3
  57aa75: cc                           	int3
  57aa76: cc                           	int3
  57aa77: cc                           	int3
  57aa78: cc                           	int3
  57aa79: cc                           	int3
  57aa7a: cc                           	int3
  57aa7b: cc                           	int3
  57aa7c: cc                           	int3
  57aa7d: cc                           	int3
  57aa7e: cc                           	int3
  57aa7f: cc                           	int3
  57aa80: 55                           	push	ebp
  57aa81: 8b ec                        	mov	ebp, esp
  57aa83: 83 ec 08                     	sub	esp, 0x8
  57aa86: 53                           	push	ebx
  57aa87: 56                           	push	esi
  57aa88: 8b f1                        	mov	esi, ecx
  57aa8a: 57                           	push	edi
  57aa8b: 33 db                        	xor	ebx, ebx
  57aa8d: 53                           	push	ebx
  57aa8e: 8d 4e 78                     	lea	ecx, [esi + 0x78]
  57aa91: 89 9e c4 01 00 00            	mov	dword ptr [esi + 0x1c4], ebx
  57aa97: e8 94 f9 c3 00               	call	0x11ba430 <.text+0xc40430>
  57aa9c: 8d 4e 78                     	lea	ecx, [esi + 0x78]
  57aa9f: e8 4c f9 c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57aaa4: 8d be 94 00 00 00            	lea	edi, [esi + 0x94]
  57aaaa: c7 45 fc 0a 00 00 00         	mov	dword ptr [ebp - 0x4], 0xa
  57aab1: 53                           	push	ebx
  57aab2: 8b cf                        	mov	ecx, edi
  57aab4: e8 77 f9 c3 00               	call	0x11ba430 <.text+0xc40430>
  57aab9: 8b cf                        	mov	ecx, edi
  57aabb: e8 30 f9 c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57aac0: 83 c7 1c                     	add	edi, 0x1c
  57aac3: ff 4d fc                     	dec	dword ptr [ebp - 0x4]
  57aac6: 75 e9                        	jne	0x57aab1 <.text+0xab1>
  57aac8: 8d 8e ac 01 00 00            	lea	ecx, [esi + 0x1ac]
  57aace: 89 5e 70                     	mov	dword ptr [esi + 0x70], ebx
  57aad1: 89 5e 74                     	mov	dword ptr [esi + 0x74], ebx
  57aad4: e8 27 fb ff ff               	call	0x57a600 <.text+0x600>
  57aad9: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
  57aadc: 89 9e c0 01 00 00            	mov	dword ptr [esi + 0x1c0], ebx
  57aae2: 89 9e c4 01 00 00            	mov	dword ptr [esi + 0x1c4], ebx
  57aae8: 89 9e c8 01 00 00            	mov	dword ptr [esi + 0x1c8], ebx
  57aaee: 89 9e cc 01 00 00            	mov	dword ptr [esi + 0x1cc], ebx
  57aaf4: 66 89 9e d0 01 00 00         	mov	word ptr [esi + 0x1d0], bx
  57aafb: e8 50 ea e0 00               	call	0x1389550 <.text+0xe0f550>
  57ab00: 8d 4e 18                     	lea	ecx, [esi + 0x18]
  57ab03: e8 d8 45 da 00               	call	0x131f0e0 <.text+0xda50e0>
  57ab08: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57ab0b: e8 70 bf bb 00               	call	0x1136a80 <.text+0xbbca80>
  57ab10: 8d 4e 40                     	lea	ecx, [esi + 0x40]
  57ab13: e8 a8 b5 ff ff               	call	0x5760c0
  57ab18: 53                           	push	ebx
  57ab19: 8d 8e dc 01 00 00            	lea	ecx, [esi + 0x1dc]
  57ab1f: 89 9e d4 01 00 00            	mov	dword ptr [esi + 0x1d4], ebx
  57ab25: 89 9e d8 01 00 00            	mov	dword ptr [esi + 0x1d8], ebx
  57ab2b: e8 00 f9 c3 00               	call	0x11ba430 <.text+0xc40430>
  57ab30: 8d 8e dc 01 00 00            	lea	ecx, [esi + 0x1dc]
  57ab36: e8 b5 f8 c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57ab3b: 53                           	push	ebx
  57ab3c: 8d 8e 40 02 00 00            	lea	ecx, [esi + 0x240]
  57ab42: c7 86 f8 01 00 00 04 00 00 00	mov	dword ptr [esi + 0x1f8], 0x4
  57ab4c: 89 9e 38 02 00 00            	mov	dword ptr [esi + 0x238], ebx
  57ab52: 89 9e 3c 02 00 00            	mov	dword ptr [esi + 0x23c], ebx
  57ab58: e8 d3 f8 c3 00               	call	0x11ba430 <.text+0xc40430>
  57ab5d: 8d 8e 40 02 00 00            	lea	ecx, [esi + 0x240]
  57ab63: e8 88 f8 c3 00               	call	0x11ba3f0 <.text+0xc403f0>
  57ab68: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57ab6e: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57ab71: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57ab74: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57ab77: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57ab7a: 75 35                        	jne	0x57abb1 <.text+0xbb1>
  57ab7c: 8d 64 24 00                  	lea	esp, [esp]
  57ab80: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
  57ab83: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57ab86: 52                           	push	edx
  57ab87: 8d 8e 94 02 00 00            	lea	ecx, [esi + 0x294]
  57ab8d: e8 6e b2 bb 00               	call	0x1135e00 <.text+0xbbbe00>
  57ab92: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57ab95: 8b 55 f8                     	mov	edx, dword ptr [ebp - 0x8]
  57ab98: 8b 08                        	mov	ecx, dword ptr [eax]
  57ab9a: 52                           	push	edx
  57ab9b: 89 4d fc                     	mov	dword ptr [ebp - 0x4], ecx
  57ab9e: e8 84 af e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57aba3: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57aba6: 83 c4 04                     	add	esp, 0x4
  57aba9: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57abac: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57abaf: 74 cf                        	je	0x57ab80 <.text+0xb80>
  57abb1: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57abb7: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57abba: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57abc0: 89 00                        	mov	dword ptr [eax], eax
  57abc2: 8b 86 9c 02 00 00            	mov	eax, dword ptr [esi + 0x29c]
  57abc8: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57abcb: 89 9e a0 02 00 00            	mov	dword ptr [esi + 0x2a0], ebx
  57abd1: 8b 86 fc 01 00 00            	mov	eax, dword ptr [esi + 0x1fc]
  57abd7: 89 9e 28 02 00 00            	mov	dword ptr [esi + 0x228], ebx
  57abdd: 8b 48 44                     	mov	ecx, dword ptr [eax + 0x44]
  57abe0: 3b cb                        	cmp	ecx, ebx
  57abe2: 74 07                        	je	0x57abeb <.text+0xbeb>
  57abe4: 53                           	push	ebx
  57abe5: 53                           	push	ebx
  57abe6: e8 e5 3b fd ff               	call	0x54e7d0
  57abeb: 8b 8e b0 02 00 00            	mov	ecx, dword ptr [esi + 0x2b0]
  57abf1: 8b 41 04                     	mov	eax, dword ptr [ecx + 0x4]
  57abf4: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57abf7: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57abfa: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57abfd: 75 32                        	jne	0x57ac31 <.text+0xc31>
  57abff: 90                           	nop
  57ac00: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57ac03: 8b 42 08                     	mov	eax, dword ptr [edx + 0x8]
  57ac06: 50                           	push	eax
  57ac07: 8d 8e a8 02 00 00            	lea	ecx, [esi + 0x2a8]
  57ac0d: e8 ee b1 bb 00               	call	0x1135e00 <.text+0xbbbe00>
  57ac12: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
  57ac15: 8b 45 f8                     	mov	eax, dword ptr [ebp - 0x8]
  57ac18: 8b 11                        	mov	edx, dword ptr [ecx]
  57ac1a: 50                           	push	eax
  57ac1b: 89 55 fc                     	mov	dword ptr [ebp - 0x4], edx
  57ac1e: e8 04 af e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ac23: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57ac26: 83 c4 04                     	add	esp, 0x4
  57ac29: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57ac2c: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57ac2f: 74 cf                        	je	0x57ac00 <.text+0xc00>
  57ac31: 8b 86 b0 02 00 00            	mov	eax, dword ptr [esi + 0x2b0]
  57ac37: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57ac3a: 8b 86 b0 02 00 00            	mov	eax, dword ptr [esi + 0x2b0]
  57ac40: 89 00                        	mov	dword ptr [eax], eax
  57ac42: 8b 86 b0 02 00 00            	mov	eax, dword ptr [esi + 0x2b0]
  57ac48: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57ac4b: 89 9e b4 02 00 00            	mov	dword ptr [esi + 0x2b4], ebx
  57ac51: 8b 8e c4 02 00 00            	mov	ecx, dword ptr [esi + 0x2c4]
  57ac57: 8b 41 04                     	mov	eax, dword ptr [ecx + 0x4]
  57ac5a: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57ac5d: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57ac60: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57ac63: 75 31                        	jne	0x57ac96 <.text+0xc96>
  57ac65: 8b 55 fc                     	mov	edx, dword ptr [ebp - 0x4]
  57ac68: 8b 42 08                     	mov	eax, dword ptr [edx + 0x8]
  57ac6b: 50                           	push	eax
  57ac6c: 8d 8e bc 02 00 00            	lea	ecx, [esi + 0x2bc]
  57ac72: e8 89 b1 bb 00               	call	0x1135e00 <.text+0xbbbe00>
  57ac77: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
  57ac7a: 8b 45 f8                     	mov	eax, dword ptr [ebp - 0x8]
  57ac7d: 8b 11                        	mov	edx, dword ptr [ecx]
  57ac7f: 50                           	push	eax
  57ac80: 89 55 fc                     	mov	dword ptr [ebp - 0x4], edx
  57ac83: e8 9f ae e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ac88: 8b 45 fc                     	mov	eax, dword ptr [ebp - 0x4]
  57ac8b: 83 c4 04                     	add	esp, 0x4
  57ac8e: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57ac91: 38 58 15                     	cmp	byte ptr [eax + 0x15], bl
  57ac94: 74 cf                        	je	0x57ac65 <.text+0xc65>
  57ac96: 8b 86 c4 02 00 00            	mov	eax, dword ptr [esi + 0x2c4]
  57ac9c: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57ac9f: 8b 86 c4 02 00 00            	mov	eax, dword ptr [esi + 0x2c4]
  57aca5: 89 00                        	mov	dword ptr [eax], eax
  57aca7: 8b 86 c4 02 00 00            	mov	eax, dword ptr [esi + 0x2c4]
  57acad: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57acb0: 89 9e c8 02 00 00            	mov	dword ptr [esi + 0x2c8], ebx
  57acb6: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  57acbc: 89 9e 74 03 00 00            	mov	dword ptr [esi + 0x374], ebx
  57acc2: e8 f9 b3 ff ff               	call	0x5760c0
  57acc7: 88 9e 94 03 00 00            	mov	byte ptr [esi + 0x394], bl
  57accd: 89 9e 58 03 00 00            	mov	dword ptr [esi + 0x358], ebx
  57acd3: 88 9e a0 03 00 00            	mov	byte ptr [esi + 0x3a0], bl
  57acd9: 33 c9                        	xor	ecx, ecx
  57acdb: 66 89 8e a1 03 00 00         	mov	word ptr [esi + 0x3a1], cx
  57ace2: 89 9e 95 03 00 00            	mov	dword ptr [esi + 0x395], ebx
  57ace8: 5f                           	pop	edi
  57ace9: 66 89 9e 99 03 00 00         	mov	word ptr [esi + 0x399], bx
  57acf0: 5e                           	pop	esi
  57acf1: 5b                           	pop	ebx
  57acf2: 8b e5                        	mov	esp, ebp
  57acf4: 5d                           	pop	ebp
  57acf5: c3                           	ret
  57acf6: cc                           	int3
  57acf7: cc                           	int3
  57acf8: cc                           	int3
  57acf9: cc                           	int3
  57acfa: cc                           	int3
  57acfb: cc                           	int3
  57acfc: cc                           	int3
  57acfd: cc                           	int3
  57acfe: cc                           	int3
  57acff: cc                           	int3
  57ad00: e9 7b fd ff ff               	jmp	0x57aa80 <.text+0xa80>
  57ad05: cc                           	int3
  57ad06: cc                           	int3
  57ad07: cc                           	int3
  57ad08: cc                           	int3
  57ad09: cc                           	int3
  57ad0a: cc                           	int3
  57ad0b: cc                           	int3
  57ad0c: cc                           	int3
  57ad0d: cc                           	int3
  57ad0e: cc                           	int3
  57ad0f: cc                           	int3
  57ad10: 55                           	push	ebp
  57ad11: 8b ec                        	mov	ebp, esp
  57ad13: 6a ff                        	push	-0x1
  57ad15: 68 98 d2 41 01               	push	0x141d298
  57ad1a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57ad20: 50                           	push	eax
  57ad21: 56                           	push	esi
  57ad22: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57ad27: 33 c5                        	xor	eax, ebp
  57ad29: 50                           	push	eax
  57ad2a: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57ad2d: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57ad33: 8b f1                        	mov	esi, ecx
  57ad35: 8d 45 0c                     	lea	eax, [ebp + 0xc]
  57ad38: 50                           	push	eax
  57ad39: 8d 4d 08                     	lea	ecx, [ebp + 0x8]
  57ad3c: 51                           	push	ecx
  57ad3d: 8d 8e d0 02 00 00            	lea	ecx, [esi + 0x2d0]
  57ad43: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57ad4a: e8 31 d6 ff ff               	call	0x578380
  57ad4f: 8b c8                        	mov	ecx, eax
  57ad51: e8 7a a8 ff ff               	call	0x5755d0
  57ad56: 8b ce                        	mov	ecx, esi
  57ad58: e8 d3 e0 ff ff               	call	0x578e30
  57ad5d: e8 ae b6 18 00               	call	0x706410 <.text+0x18c410>
  57ad62: 8b 88 b0 00 00 00            	mov	ecx, dword ptr [eax + 0xb0]
  57ad68: 6a 01                        	push	0x1
  57ad6a: e8 41 af ba 00               	call	0x1125cb0 <.text+0xbabcb0>
  57ad6f: 8d 4d 0c                     	lea	ecx, [ebp + 0xc]
  57ad72: e8 39 8a ff ff               	call	0x5737b0
  57ad77: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57ad7a: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57ad81: 59                           	pop	ecx
  57ad82: 5e                           	pop	esi
  57ad83: 8b e5                        	mov	esp, ebp
  57ad85: 5d                           	pop	ebp
  57ad86: c2 b4 00                     	ret	0xb4
  57ad89: cc                           	int3
  57ad8a: cc                           	int3
  57ad8b: cc                           	int3
  57ad8c: cc                           	int3
  57ad8d: cc                           	int3
  57ad8e: cc                           	int3
  57ad8f: cc                           	int3
  57ad90: 55                           	push	ebp
  57ad91: 8b ec                        	mov	ebp, esp
  57ad93: 56                           	push	esi
  57ad94: 6a 00                        	push	0x0
  57ad96: 6a ff                        	push	-0x1
  57ad98: 8b f1                        	mov	esi, ecx
  57ad9a: 8b 0d 50 f7 a6 01            	mov	ecx, dword ptr [0x1a6f750]
  57ada0: 68 96 01 00 00               	push	0x196
  57ada5: e8 06 98 8f 00               	call	0xe745b0 <.text+0x8fa5b0>
  57adaa: 8b 0d 50 f7 a6 01            	mov	ecx, dword ptr [0x1a6f750]
  57adb0: 6a 00                        	push	0x0
  57adb2: 6a ff                        	push	-0x1
  57adb4: 68 99 01 00 00               	push	0x199
  57adb9: e8 f2 97 8f 00               	call	0xe745b0 <.text+0x8fa5b0>
  57adbe: 8b 0d 50 f7 a6 01            	mov	ecx, dword ptr [0x1a6f750]
  57adc4: 6a 00                        	push	0x0
  57adc6: 6a ff                        	push	-0x1
  57adc8: 68 9a 01 00 00               	push	0x19a
  57adcd: e8 de 97 8f 00               	call	0xe745b0 <.text+0x8fa5b0>
  57add2: 83 be dc 02 00 00 00         	cmp	dword ptr [esi + 0x2dc], 0x0
  57add9: 74 65                        	je	0x57ae40 <.text+0xe40>
  57addb: e8 30 b6 18 00               	call	0x706410 <.text+0x18c410>
  57ade0: 8b 88 b0 00 00 00            	mov	ecx, dword ptr [eax + 0xb0]
  57ade6: 6a 00                        	push	0x0
  57ade8: e8 83 c8 b9 00               	call	0x1117670 <.text+0xb9d670>
  57aded: 8b 86 04 03 00 00            	mov	eax, dword ptr [esi + 0x304]
  57adf3: 8b 0d 50 f7 a6 01            	mov	ecx, dword ptr [0x1a6f750]
  57adf9: 6a 00                        	push	0x0
  57adfb: 68 78 d8 9d 01               	push	0x19dd878
  57ae00: 68 10 94 9d 01               	push	0x19d9410
  57ae05: 6a 00                        	push	0x0
  57ae07: 50                           	push	eax
  57ae08: 6a 00                        	push	0x0
  57ae0a: 68 96 01 00 00               	push	0x196
  57ae0f: e8 5c c6 8f 00               	call	0xe77470 <.text+0x8fd470>
  57ae14: 50                           	push	eax
  57ae15: e8 c5 c8 e5 00               	call	0x13d76df <.text+0xe5d6df>
  57ae1a: 83 c4 14                     	add	esp, 0x14
  57ae1d: 8b ce                        	mov	ecx, esi
  57ae1f: 89 86 60 03 00 00            	mov	dword ptr [esi + 0x360], eax
  57ae25: e8 f6 e2 ff ff               	call	0x579120
  57ae2a: 8b ce                        	mov	ecx, esi
  57ae2c: e8 4f e6 ff ff               	call	0x579480
  57ae31: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  57ae34: 51                           	push	ecx
  57ae35: 8b 8e 60 03 00 00            	mov	ecx, dword ptr [esi + 0x360]
  57ae3b: e8 c0 28 02 00               	call	0x59d700 <.text+0x23700>
  57ae40: 5e                           	pop	esi
  57ae41: 5d                           	pop	ebp
  57ae42: c2 04 00                     	ret	0x4
  57ae45: cc                           	int3
  57ae46: cc                           	int3
  57ae47: cc                           	int3
  57ae48: cc                           	int3
  57ae49: cc                           	int3
  57ae4a: cc                           	int3
  57ae4b: cc                           	int3
  57ae4c: cc                           	int3
  57ae4d: cc                           	int3
  57ae4e: cc                           	int3
  57ae4f: cc                           	int3
  57ae50: 55                           	push	ebp
  57ae51: 8b ec                        	mov	ebp, esp
  57ae53: 6a ff                        	push	-0x1
  57ae55: 68 48 eb 40 01               	push	0x140eb48
  57ae5a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57ae60: 50                           	push	eax
  57ae61: 53                           	push	ebx
  57ae62: 56                           	push	esi
  57ae63: 57                           	push	edi
  57ae64: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57ae69: 33 c5                        	xor	eax, ebp
  57ae6b: 50                           	push	eax
  57ae6c: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57ae6f: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57ae75: 8b 41 0c                     	mov	eax, dword ptr [ecx + 0xc]
  57ae78: 8b 7d 14                     	mov	edi, dword ptr [ebp + 0x14]
  57ae7b: 3d 2d ba e8 02               	cmp	eax, 0x2e8ba2d
  57ae80: 72 36                        	jb	0x57aeb8 <.text+0xeb8>
  57ae82: 8d 77 0c                     	lea	esi, [edi + 0xc]
  57ae85: 89 75 0c                     	mov	dword ptr [ebp + 0xc], esi
  57ae88: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57ae8b: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57ae92: e8 d9 cb ff ff               	call	0x577a70
  57ae97: 8b ce                        	mov	ecx, esi
  57ae99: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57aea0: e8 1b 5e c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57aea5: 57                           	push	edi
  57aea6: e8 7c ac e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57aeab: 83 c4 04                     	add	esp, 0x4
  57aeae: 68 c4 51 56 01               	push	0x15651c4
  57aeb3: e8 12 69 e4 00               	call	0x13c17ca <.text+0xe477ca>
  57aeb8: 40                           	inc	eax
  57aeb9: 89 41 0c                     	mov	dword ptr [ecx + 0xc], eax
  57aebc: 8b 45 10                     	mov	eax, dword ptr [ebp + 0x10]
  57aebf: 89 47 04                     	mov	dword ptr [edi + 0x4], eax
  57aec2: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57aec5: 33 db                        	xor	ebx, ebx
  57aec7: 3b c2                        	cmp	eax, edx
  57aec9: 75 0d                        	jne	0x57aed8 <.text+0xed8>
  57aecb: 89 7a 04                     	mov	dword ptr [edx + 0x4], edi
  57aece: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57aed1: 89 38                        	mov	dword ptr [eax], edi
  57aed3: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57aed6: eb 1d                        	jmp	0x57aef5 <.text+0xef5>
  57aed8: 38 5d 0c                     	cmp	byte ptr [ebp + 0xc], bl
  57aedb: 74 0d                        	je	0x57aeea <.text+0xeea>
  57aedd: 89 38                        	mov	dword ptr [eax], edi
  57aedf: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57aee2: 3b 02                        	cmp	eax, dword ptr [edx]
  57aee4: 75 12                        	jne	0x57aef8 <.text+0xef8>
  57aee6: 89 3a                        	mov	dword ptr [edx], edi
  57aee8: eb 0e                        	jmp	0x57aef8 <.text+0xef8>
  57aeea: 89 78 08                     	mov	dword ptr [eax + 0x8], edi
  57aeed: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57aef0: 3b 42 08                     	cmp	eax, dword ptr [edx + 0x8]
  57aef3: 75 03                        	jne	0x57aef8 <.text+0xef8>
  57aef5: 89 7a 08                     	mov	dword ptr [edx + 0x8], edi
  57aef8: 8b 57 04                     	mov	edx, dword ptr [edi + 0x4]
  57aefb: 8b c7                        	mov	eax, edi
  57aefd: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57af00: 0f 85 8f 01 00 00            	jne	0x57b095 <.text+0x1095>
  57af06: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57af09: 8b 72 04                     	mov	esi, dword ptr [edx + 0x4]
  57af0c: 3b 16                        	cmp	edx, dword ptr [esi]
  57af0e: 0f 85 c1 00 00 00            	jne	0x57afd5 <.text+0xfd5>
  57af14: 8b 76 08                     	mov	esi, dword ptr [esi + 0x8]
  57af17: 38 5e 64                     	cmp	byte ptr [esi + 0x64], bl
  57af1a: 75 1c                        	jne	0x57af38 <.text+0xf38>
  57af1c: c6 42 64 01                  	mov	byte ptr [edx + 0x64], 0x1
  57af20: c6 46 64 01                  	mov	byte ptr [esi + 0x64], 0x1
  57af24: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57af27: 8b 52 04                     	mov	edx, dword ptr [edx + 0x4]
  57af2a: 88 5a 64                     	mov	byte ptr [edx + 0x64], bl
  57af2d: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57af30: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57af33: e9 51 01 00 00               	jmp	0x57b089 <.text+0x1089>
  57af38: 3b 42 08                     	cmp	eax, dword ptr [edx + 0x8]
  57af3b: 75 3a                        	jne	0x57af77 <.text+0xf77>
  57af3d: 8b c2                        	mov	eax, edx
  57af3f: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57af42: 8b 32                        	mov	esi, dword ptr [edx]
  57af44: 89 70 08                     	mov	dword ptr [eax + 0x8], esi
  57af47: 8b 32                        	mov	esi, dword ptr [edx]
  57af49: 38 5e 65                     	cmp	byte ptr [esi + 0x65], bl
  57af4c: 75 03                        	jne	0x57af51 <.text+0xf51>
  57af4e: 89 46 04                     	mov	dword ptr [esi + 0x4], eax
  57af51: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57af54: 89 72 04                     	mov	dword ptr [edx + 0x4], esi
  57af57: 8b 71 08                     	mov	esi, dword ptr [ecx + 0x8]
  57af5a: 3b 46 04                     	cmp	eax, dword ptr [esi + 0x4]
  57af5d: 75 05                        	jne	0x57af64 <.text+0xf64>
  57af5f: 89 56 04                     	mov	dword ptr [esi + 0x4], edx
  57af62: eb 0e                        	jmp	0x57af72 <.text+0xf72>
  57af64: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57af67: 3b 06                        	cmp	eax, dword ptr [esi]
  57af69: 75 04                        	jne	0x57af6f <.text+0xf6f>
  57af6b: 89 16                        	mov	dword ptr [esi], edx
  57af6d: eb 03                        	jmp	0x57af72 <.text+0xf72>
  57af6f: 89 56 08                     	mov	dword ptr [esi + 0x8], edx
  57af72: 89 02                        	mov	dword ptr [edx], eax
  57af74: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57af77: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57af7a: c6 42 64 01                  	mov	byte ptr [edx + 0x64], 0x1
  57af7e: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57af81: 8b 52 04                     	mov	edx, dword ptr [edx + 0x4]
  57af84: 88 5a 64                     	mov	byte ptr [edx + 0x64], bl
  57af87: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57af8a: 8b 52 04                     	mov	edx, dword ptr [edx + 0x4]
  57af8d: 8b 32                        	mov	esi, dword ptr [edx]
  57af8f: 8b 7e 08                     	mov	edi, dword ptr [esi + 0x8]
  57af92: 89 3a                        	mov	dword ptr [edx], edi
  57af94: 8b 7e 08                     	mov	edi, dword ptr [esi + 0x8]
  57af97: 38 5f 65                     	cmp	byte ptr [edi + 0x65], bl
  57af9a: 75 03                        	jne	0x57af9f <.text+0xf9f>
  57af9c: 89 57 04                     	mov	dword ptr [edi + 0x4], edx
  57af9f: 8b 7a 04                     	mov	edi, dword ptr [edx + 0x4]
  57afa2: 89 7e 04                     	mov	dword ptr [esi + 0x4], edi
  57afa5: 8b 79 08                     	mov	edi, dword ptr [ecx + 0x8]
  57afa8: 3b 57 04                     	cmp	edx, dword ptr [edi + 0x4]
  57afab: 75 0b                        	jne	0x57afb8 <.text+0xfb8>
  57afad: 89 77 04                     	mov	dword ptr [edi + 0x4], esi
  57afb0: 89 56 08                     	mov	dword ptr [esi + 0x8], edx
  57afb3: e9 cb 00 00 00               	jmp	0x57b083 <.text+0x1083>
  57afb8: 8b 7a 04                     	mov	edi, dword ptr [edx + 0x4]
  57afbb: 3b 57 08                     	cmp	edx, dword ptr [edi + 0x8]
  57afbe: 75 0b                        	jne	0x57afcb <.text+0xfcb>
  57afc0: 89 77 08                     	mov	dword ptr [edi + 0x8], esi
  57afc3: 89 56 08                     	mov	dword ptr [esi + 0x8], edx
  57afc6: e9 b8 00 00 00               	jmp	0x57b083 <.text+0x1083>
  57afcb: 89 37                        	mov	dword ptr [edi], esi
  57afcd: 89 56 08                     	mov	dword ptr [esi + 0x8], edx
  57afd0: e9 ae 00 00 00               	jmp	0x57b083 <.text+0x1083>
  57afd5: 8b 36                        	mov	esi, dword ptr [esi]
  57afd7: 38 5e 64                     	cmp	byte ptr [esi + 0x64], bl
  57afda: 75 1c                        	jne	0x57aff8 <.text+0xff8>
  57afdc: c6 42 64 01                  	mov	byte ptr [edx + 0x64], 0x1
  57afe0: c6 46 64 01                  	mov	byte ptr [esi + 0x64], 0x1
  57afe4: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57afe7: 8b 52 04                     	mov	edx, dword ptr [edx + 0x4]
  57afea: 88 5a 64                     	mov	byte ptr [edx + 0x64], bl
  57afed: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57aff0: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57aff3: e9 91 00 00 00               	jmp	0x57b089 <.text+0x1089>
  57aff8: 3b 02                        	cmp	eax, dword ptr [edx]
  57affa: 75 3c                        	jne	0x57b038 <.text+0x1038>
  57affc: 8b c2                        	mov	eax, edx
  57affe: 8b 10                        	mov	edx, dword ptr [eax]
  57b000: 8b 72 08                     	mov	esi, dword ptr [edx + 0x8]
  57b003: 89 30                        	mov	dword ptr [eax], esi
  57b005: 8b 72 08                     	mov	esi, dword ptr [edx + 0x8]
  57b008: 38 5e 65                     	cmp	byte ptr [esi + 0x65], bl
  57b00b: 75 03                        	jne	0x57b010 <.text+0x1010>
  57b00d: 89 46 04                     	mov	dword ptr [esi + 0x4], eax
  57b010: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57b013: 89 72 04                     	mov	dword ptr [edx + 0x4], esi
  57b016: 8b 71 08                     	mov	esi, dword ptr [ecx + 0x8]
  57b019: 3b 46 04                     	cmp	eax, dword ptr [esi + 0x4]
  57b01c: 75 05                        	jne	0x57b023 <.text+0x1023>
  57b01e: 89 56 04                     	mov	dword ptr [esi + 0x4], edx
  57b021: eb 0f                        	jmp	0x57b032 <.text+0x1032>
  57b023: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57b026: 3b 46 08                     	cmp	eax, dword ptr [esi + 0x8]
  57b029: 75 05                        	jne	0x57b030 <.text+0x1030>
  57b02b: 89 56 08                     	mov	dword ptr [esi + 0x8], edx
  57b02e: eb 02                        	jmp	0x57b032 <.text+0x1032>
  57b030: 89 16                        	mov	dword ptr [esi], edx
  57b032: 89 42 08                     	mov	dword ptr [edx + 0x8], eax
  57b035: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57b038: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57b03b: c6 42 64 01                  	mov	byte ptr [edx + 0x64], 0x1
  57b03f: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57b042: 8b 52 04                     	mov	edx, dword ptr [edx + 0x4]
  57b045: 88 5a 64                     	mov	byte ptr [edx + 0x64], bl
  57b048: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57b04b: 8b 52 04                     	mov	edx, dword ptr [edx + 0x4]
  57b04e: 8b 72 08                     	mov	esi, dword ptr [edx + 0x8]
  57b051: 8b 3e                        	mov	edi, dword ptr [esi]
  57b053: 89 7a 08                     	mov	dword ptr [edx + 0x8], edi
  57b056: 8b 3e                        	mov	edi, dword ptr [esi]
  57b058: 38 5f 65                     	cmp	byte ptr [edi + 0x65], bl
  57b05b: 75 03                        	jne	0x57b060 <.text+0x1060>
  57b05d: 89 57 04                     	mov	dword ptr [edi + 0x4], edx
  57b060: 8b 7a 04                     	mov	edi, dword ptr [edx + 0x4]
  57b063: 89 7e 04                     	mov	dword ptr [esi + 0x4], edi
  57b066: 8b 79 08                     	mov	edi, dword ptr [ecx + 0x8]
  57b069: 3b 57 04                     	cmp	edx, dword ptr [edi + 0x4]
  57b06c: 75 05                        	jne	0x57b073 <.text+0x1073>
  57b06e: 89 77 04                     	mov	dword ptr [edi + 0x4], esi
  57b071: eb 0e                        	jmp	0x57b081 <.text+0x1081>
  57b073: 8b 7a 04                     	mov	edi, dword ptr [edx + 0x4]
  57b076: 3b 17                        	cmp	edx, dword ptr [edi]
  57b078: 75 04                        	jne	0x57b07e <.text+0x107e>
  57b07a: 89 37                        	mov	dword ptr [edi], esi
  57b07c: eb 03                        	jmp	0x57b081 <.text+0x1081>
  57b07e: 89 77 08                     	mov	dword ptr [edi + 0x8], esi
  57b081: 89 16                        	mov	dword ptr [esi], edx
  57b083: 8b 7d 14                     	mov	edi, dword ptr [ebp + 0x14]
  57b086: 89 72 04                     	mov	dword ptr [edx + 0x4], esi
  57b089: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57b08c: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b08f: 0f 84 71 fe ff ff            	je	0x57af06 <.text+0xf06>
  57b095: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57b098: 8b 50 04                     	mov	edx, dword ptr [eax + 0x4]
  57b09b: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57b09e: c6 42 64 01                  	mov	byte ptr [edx + 0x64], 0x1
  57b0a2: 8b 09                        	mov	ecx, dword ptr [ecx]
  57b0a4: 89 58 04                     	mov	dword ptr [eax + 0x4], ebx
  57b0a7: 89 78 08                     	mov	dword ptr [eax + 0x8], edi
  57b0aa: 89 08                        	mov	dword ptr [eax], ecx
  57b0ac: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b0af: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b0b6: 59                           	pop	ecx
  57b0b7: 5f                           	pop	edi
  57b0b8: 5e                           	pop	esi
  57b0b9: 5b                           	pop	ebx
  57b0ba: 8b e5                        	mov	esp, ebp
  57b0bc: 5d                           	pop	ebp
  57b0bd: c2 10 00                     	ret	0x10
  57b0c0: 55                           	push	ebp
  57b0c1: 8b ec                        	mov	ebp, esp
  57b0c3: 6a ff                        	push	-0x1
  57b0c5: 68 e1 d2 41 01               	push	0x141d2e1
  57b0ca: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57b0d0: 50                           	push	eax
  57b0d1: 83 ec 20                     	sub	esp, 0x20
  57b0d4: 53                           	push	ebx
  57b0d5: 56                           	push	esi
  57b0d6: 57                           	push	edi
  57b0d7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57b0dc: 33 c5                        	xor	eax, ebp
  57b0de: 50                           	push	eax
  57b0df: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57b0e2: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57b0e8: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57b0eb: 8b f9                        	mov	edi, ecx
  57b0ed: 6a 68                        	push	0x68
  57b0ef: e8 26 ba e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57b0f4: 8b f0                        	mov	esi, eax
  57b0f6: 33 c0                        	xor	eax, eax
  57b0f8: 83 c4 04                     	add	esp, 0x4
  57b0fb: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57b0fe: 3b f0                        	cmp	esi, eax
  57b100: 0f 84 96 00 00 00            	je	0x57b19c <.text+0x119c>
  57b106: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
  57b109: 89 0e                        	mov	dword ptr [esi], ecx
  57b10b: 8b 57 08                     	mov	edx, dword ptr [edi + 0x8]
  57b10e: 89 56 04                     	mov	dword ptr [esi + 0x4], edx
  57b111: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
  57b114: 8d 7e 0c                     	lea	edi, [esi + 0xc]
  57b117: 89 4e 08                     	mov	dword ptr [esi + 0x8], ecx
  57b11a: 66 89 46 64                  	mov	word ptr [esi + 0x64], ax
  57b11e: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57b121: 89 7d e4                     	mov	dword ptr [ebp - 0x1c], edi
  57b124: 89 7d e0                     	mov	dword ptr [ebp - 0x20], edi
  57b127: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57b12b: 3b f8                        	cmp	edi, eax
  57b12d: 74 42                        	je	0x57b171 <.text+0x1171>
  57b12f: 8b cf                        	mov	ecx, edi
  57b131: e8 3a 73 c2 00               	call	0x11a2470 <.text+0xc28470>
  57b136: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
  57b139: 8d 55 08                     	lea	edx, [ebp + 0x8]
  57b13c: 52                           	push	edx
  57b13d: 8d 43 08                     	lea	eax, [ebx + 0x8]
  57b140: 50                           	push	eax
  57b141: 8b cb                        	mov	ecx, ebx
  57b143: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57b147: e8 94 5c c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b14c: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  57b14f: 8d 57 08                     	lea	edx, [edi + 0x8]
  57b152: 52                           	push	edx
  57b153: 8d 45 ec                     	lea	eax, [ebp - 0x14]
  57b156: 89 4d ec                     	mov	dword ptr [ebp - 0x14], ecx
  57b159: 50                           	push	eax
  57b15a: 8b cf                        	mov	ecx, edi
  57b15c: e8 cf 57 c2 00               	call	0x11a0930 <.text+0xc26930>
  57b161: 83 c3 0c                     	add	ebx, 0xc
  57b164: 53                           	push	ebx
  57b165: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  57b168: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57b16c: e8 bf c9 ff ff               	call	0x577b30
  57b171: 8b c6                        	mov	eax, esi
  57b173: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b176: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b17d: 59                           	pop	ecx
  57b17e: 5f                           	pop	edi
  57b17f: 5e                           	pop	esi
  57b180: 5b                           	pop	ebx
  57b181: 8b e5                        	mov	esp, ebp
  57b183: 5d                           	pop	ebp
  57b184: c2 04 00                     	ret	0x4
  57b187: 8b 4d e8                     	mov	ecx, dword ptr [ebp - 0x18]
  57b18a: 51                           	push	ecx
  57b18b: e8 97 a9 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57b190: 83 c4 04                     	add	esp, 0x4
  57b193: 33 c0                        	xor	eax, eax
  57b195: 50                           	push	eax
  57b196: 50                           	push	eax
  57b197: e8 fe b9 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57b19c: 8d 55 e8                     	lea	edx, [ebp - 0x18]
  57b19f: 52                           	push	edx
  57b1a0: 8d 4d d4                     	lea	ecx, [ebp - 0x2c]
  57b1a3: 89 45 e8                     	mov	dword ptr [ebp - 0x18], eax
  57b1a6: e8 1f b3 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57b1ab: 68 90 0f 91 01               	push	0x1910f90
  57b1b0: 8d 45 d4                     	lea	eax, [ebp - 0x2c]
  57b1b3: 50                           	push	eax
  57b1b4: c7 45 d4 84 20 56 01         	mov	dword ptr [ebp - 0x2c], 0x1562084
  57b1bb: e8 da b9 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57b1c0: cc                           	int3
  57b1c1: cc                           	int3
  57b1c2: cc                           	int3
  57b1c3: cc                           	int3
  57b1c4: cc                           	int3
  57b1c5: cc                           	int3
  57b1c6: cc                           	int3
  57b1c7: cc                           	int3
  57b1c8: cc                           	int3
  57b1c9: cc                           	int3
  57b1ca: cc                           	int3
  57b1cb: cc                           	int3
  57b1cc: cc                           	int3
  57b1cd: cc                           	int3
  57b1ce: cc                           	int3
  57b1cf: cc                           	int3
  57b1d0: 55                           	push	ebp
  57b1d1: 8b ec                        	mov	ebp, esp
  57b1d3: 6a ff                        	push	-0x1
  57b1d5: 68 08 d3 41 01               	push	0x141d308
  57b1da: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57b1e0: 50                           	push	eax
  57b1e1: 51                           	push	ecx
  57b1e2: 53                           	push	ebx
  57b1e3: 56                           	push	esi
  57b1e4: 57                           	push	edi
  57b1e5: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57b1ea: 33 c5                        	xor	eax, ebp
  57b1ec: 50                           	push	eax
  57b1ed: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57b1f0: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57b1f6: 89 4d f0                     	mov	dword ptr [ebp - 0x10], ecx
  57b1f9: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57b1fc: 80 7f 65 00                  	cmp	byte ptr [edi + 0x65], 0x0
  57b200: 8b f7                        	mov	esi, edi
  57b202: 75 42                        	jne	0x57b246 <.text+0x1246>
  57b204: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b207: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b20a: 50                           	push	eax
  57b20b: e8 c0 ff ff ff               	call	0x57b1d0 <.text+0x11d0>
  57b210: 8b 36                        	mov	esi, dword ptr [esi]
  57b212: 8d 5f 0c                     	lea	ebx, [edi + 0xc]
  57b215: 89 5d 08                     	mov	dword ptr [ebp + 0x8], ebx
  57b218: 8d 4b 0c                     	lea	ecx, [ebx + 0xc]
  57b21b: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57b222: e8 49 c8 ff ff               	call	0x577a70
  57b227: 8b cb                        	mov	ecx, ebx
  57b229: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57b230: e8 8b 5a c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57b235: 57                           	push	edi
  57b236: e8 ec a8 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57b23b: 83 c4 04                     	add	esp, 0x4
  57b23e: 80 7e 65 00                  	cmp	byte ptr [esi + 0x65], 0x0
  57b242: 8b fe                        	mov	edi, esi
  57b244: 74 be                        	je	0x57b204 <.text+0x1204>
  57b246: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b249: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b250: 59                           	pop	ecx
  57b251: 5f                           	pop	edi
  57b252: 5e                           	pop	esi
  57b253: 5b                           	pop	ebx
  57b254: 8b e5                        	mov	esp, ebp
  57b256: 5d                           	pop	ebp
  57b257: c2 04 00                     	ret	0x4
  57b25a: cc                           	int3
  57b25b: cc                           	int3
  57b25c: cc                           	int3
  57b25d: cc                           	int3
  57b25e: cc                           	int3
  57b25f: cc                           	int3
  57b260: 55                           	push	ebp
  57b261: 8b ec                        	mov	ebp, esp
  57b263: 6a ff                        	push	-0x1
  57b265: 68 38 d3 41 01               	push	0x141d338
  57b26a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57b270: 50                           	push	eax
  57b271: 83 ec 0c                     	sub	esp, 0xc
  57b274: 53                           	push	ebx
  57b275: 56                           	push	esi
  57b276: 57                           	push	edi
  57b277: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57b27c: 33 c5                        	xor	eax, ebp
  57b27e: 50                           	push	eax
  57b27f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57b282: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57b288: 89 4d f0                     	mov	dword ptr [ebp - 0x10], ecx
  57b28b: 8b 5d 14                     	mov	ebx, dword ptr [ebp + 0x14]
  57b28e: 80 7b 65 00                  	cmp	byte ptr [ebx + 0x65], 0x0
  57b292: 74 0a                        	je	0x57b29e <.text+0x129e>
  57b294: 68 a4 21 56 01               	push	0x15621a4
  57b299: e8 79 65 e4 00               	call	0x13c1817 <.text+0xe47817>
  57b29e: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  57b2a1: 89 5d ec                     	mov	dword ptr [ebp - 0x14], ebx
  57b2a4: 85 c0                        	test	eax, eax
  57b2a6: 0f 84 71 02 00 00            	je	0x57b51d <.text+0x151d>
  57b2ac: 83 38 00                     	cmp	dword ptr [eax], 0x0
  57b2af: 0f 84 68 02 00 00            	je	0x57b51d <.text+0x151d>
  57b2b5: 8d 4d 0c                     	lea	ecx, [ebp + 0xc]
  57b2b8: e8 33 5a ff ff               	call	0x570cf0
  57b2bd: 8b 13                        	mov	edx, dword ptr [ebx]
  57b2bf: 80 7a 65 00                  	cmp	byte ptr [edx + 0x65], 0x0
  57b2c3: 74 05                        	je	0x57b2ca <.text+0x12ca>
  57b2c5: 8b 7b 08                     	mov	edi, dword ptr [ebx + 0x8]
  57b2c8: eb 17                        	jmp	0x57b2e1 <.text+0x12e1>
  57b2ca: 8b 43 08                     	mov	eax, dword ptr [ebx + 0x8]
  57b2cd: 80 78 65 00                  	cmp	byte ptr [eax + 0x65], 0x0
  57b2d1: 74 04                        	je	0x57b2d7 <.text+0x12d7>
  57b2d3: 8b fa                        	mov	edi, edx
  57b2d5: eb 0a                        	jmp	0x57b2e1 <.text+0x12e1>
  57b2d7: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
  57b2da: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
  57b2dd: 3b c3                        	cmp	eax, ebx
  57b2df: 75 72                        	jne	0x57b353 <.text+0x1353>
  57b2e1: 80 7f 65 00                  	cmp	byte ptr [edi + 0x65], 0x0
  57b2e5: 8b 73 04                     	mov	esi, dword ptr [ebx + 0x4]
  57b2e8: 75 03                        	jne	0x57b2ed <.text+0x12ed>
  57b2ea: 89 77 04                     	mov	dword ptr [edi + 0x4], esi
  57b2ed: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b2f0: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57b2f3: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
  57b2f6: 75 05                        	jne	0x57b2fd <.text+0x12fd>
  57b2f8: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  57b2fb: eb 0b                        	jmp	0x57b308 <.text+0x1308>
  57b2fd: 39 1e                        	cmp	dword ptr [esi], ebx
  57b2ff: 75 04                        	jne	0x57b305 <.text+0x1305>
  57b301: 89 3e                        	mov	dword ptr [esi], edi
  57b303: eb 03                        	jmp	0x57b308 <.text+0x1308>
  57b305: 89 7e 08                     	mov	dword ptr [esi + 0x8], edi
  57b308: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57b30b: 39 18                        	cmp	dword ptr [eax], ebx
  57b30d: 75 1b                        	jne	0x57b32a <.text+0x132a>
  57b30f: 80 7f 65 00                  	cmp	byte ptr [edi + 0x65], 0x0
  57b313: 74 04                        	je	0x57b319 <.text+0x1319>
  57b315: 8b c6                        	mov	eax, esi
  57b317: eb 0c                        	jmp	0x57b325 <.text+0x1325>
  57b319: 57                           	push	edi
  57b31a: e8 61 54 ff ff               	call	0x570780
  57b31f: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b322: 83 c4 04                     	add	esp, 0x4
  57b325: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57b328: 89 02                        	mov	dword ptr [edx], eax
  57b32a: 8b 49 08                     	mov	ecx, dword ptr [ecx + 0x8]
  57b32d: 89 4d e8                     	mov	dword ptr [ebp - 0x18], ecx
  57b330: 39 59 08                     	cmp	dword ptr [ecx + 0x8], ebx
  57b333: 75 78                        	jne	0x57b3ad <.text+0x13ad>
  57b335: 80 7f 65 00                  	cmp	byte ptr [edi + 0x65], 0x0
  57b339: 74 07                        	je	0x57b342 <.text+0x1342>
  57b33b: 8b c6                        	mov	eax, esi
  57b33d: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57b340: eb 6b                        	jmp	0x57b3ad <.text+0x13ad>
  57b342: 57                           	push	edi
  57b343: e8 18 54 ff ff               	call	0x570760
  57b348: 8b 4d e8                     	mov	ecx, dword ptr [ebp - 0x18]
  57b34b: 83 c4 04                     	add	esp, 0x4
  57b34e: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57b351: eb 5a                        	jmp	0x57b3ad <.text+0x13ad>
  57b353: 89 42 04                     	mov	dword ptr [edx + 0x4], eax
  57b356: 8b 13                        	mov	edx, dword ptr [ebx]
  57b358: 89 10                        	mov	dword ptr [eax], edx
  57b35a: 3b 43 08                     	cmp	eax, dword ptr [ebx + 0x8]
  57b35d: 75 04                        	jne	0x57b363 <.text+0x1363>
  57b35f: 8b f0                        	mov	esi, eax
  57b361: eb 1a                        	jmp	0x57b37d <.text+0x137d>
  57b363: 80 7f 65 00                  	cmp	byte ptr [edi + 0x65], 0x0
  57b367: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57b36a: 75 03                        	jne	0x57b36f <.text+0x136f>
  57b36c: 89 77 04                     	mov	dword ptr [edi + 0x4], esi
  57b36f: 89 3e                        	mov	dword ptr [esi], edi
  57b371: 8b 53 08                     	mov	edx, dword ptr [ebx + 0x8]
  57b374: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  57b377: 8b 4b 08                     	mov	ecx, dword ptr [ebx + 0x8]
  57b37a: 89 41 04                     	mov	dword ptr [ecx + 0x4], eax
  57b37d: 8b 55 f0                     	mov	edx, dword ptr [ebp - 0x10]
  57b380: 8b 4a 08                     	mov	ecx, dword ptr [edx + 0x8]
  57b383: 39 59 04                     	cmp	dword ptr [ecx + 0x4], ebx
  57b386: 75 05                        	jne	0x57b38d <.text+0x138d>
  57b388: 89 41 04                     	mov	dword ptr [ecx + 0x4], eax
  57b38b: eb 0e                        	jmp	0x57b39b <.text+0x139b>
  57b38d: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
  57b390: 39 19                        	cmp	dword ptr [ecx], ebx
  57b392: 75 04                        	jne	0x57b398 <.text+0x1398>
  57b394: 89 01                        	mov	dword ptr [ecx], eax
  57b396: eb 03                        	jmp	0x57b39b <.text+0x139b>
  57b398: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57b39b: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
  57b39e: 89 48 04                     	mov	dword ptr [eax + 0x4], ecx
  57b3a1: 8a 53 64                     	mov	dl, byte ptr [ebx + 0x64]
  57b3a4: 8a 48 64                     	mov	cl, byte ptr [eax + 0x64]
  57b3a7: 88 50 64                     	mov	byte ptr [eax + 0x64], dl
  57b3aa: 88 4b 64                     	mov	byte ptr [ebx + 0x64], cl
  57b3ad: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  57b3b0: b3 01                        	mov	bl, 0x1
  57b3b2: 38 58 64                     	cmp	byte ptr [eax + 0x64], bl
  57b3b5: 0f 85 00 01 00 00            	jne	0x57b4bb <.text+0x14bb>
  57b3bb: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b3be: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57b3c1: 3b 7a 04                     	cmp	edi, dword ptr [edx + 0x4]
  57b3c4: 0f 84 ee 00 00 00            	je	0x57b4b8 <.text+0x14b8>
  57b3ca: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
  57b3d0: 38 5f 64                     	cmp	byte ptr [edi + 0x64], bl
  57b3d3: 0f 85 df 00 00 00            	jne	0x57b4b8 <.text+0x14b8>
  57b3d9: 8b 06                        	mov	eax, dword ptr [esi]
  57b3db: 3b f8                        	cmp	edi, eax
  57b3dd: 75 65                        	jne	0x57b444 <.text+0x1444>
  57b3df: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b3e2: 80 78 64 00                  	cmp	byte ptr [eax + 0x64], 0x0
  57b3e6: 75 13                        	jne	0x57b3fb <.text+0x13fb>
  57b3e8: 88 58 64                     	mov	byte ptr [eax + 0x64], bl
  57b3eb: 56                           	push	esi
  57b3ec: c6 46 64 00                  	mov	byte ptr [esi + 0x64], 0x0
  57b3f0: e8 ab 59 ff ff               	call	0x570da0
  57b3f5: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b3f8: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b3fb: 80 78 65 00                  	cmp	byte ptr [eax + 0x65], 0x0
  57b3ff: 75 74                        	jne	0x57b475 <.text+0x1475>
  57b401: 8b 10                        	mov	edx, dword ptr [eax]
  57b403: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b406: 75 08                        	jne	0x57b410 <.text+0x1410>
  57b408: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57b40b: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b40e: 74 61                        	je	0x57b471 <.text+0x1471>
  57b410: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57b413: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b416: 75 15                        	jne	0x57b42d <.text+0x142d>
  57b418: 8b 10                        	mov	edx, dword ptr [eax]
  57b41a: 88 5a 64                     	mov	byte ptr [edx + 0x64], bl
  57b41d: 50                           	push	eax
  57b41e: c6 40 64 00                  	mov	byte ptr [eax + 0x64], 0x0
  57b422: e8 d9 59 ff ff               	call	0x570e00
  57b427: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b42a: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b42d: 8a 56 64                     	mov	dl, byte ptr [esi + 0x64]
  57b430: 88 50 64                     	mov	byte ptr [eax + 0x64], dl
  57b433: 88 5e 64                     	mov	byte ptr [esi + 0x64], bl
  57b436: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57b439: 56                           	push	esi
  57b43a: 88 58 64                     	mov	byte ptr [eax + 0x64], bl
  57b43d: e8 5e 59 ff ff               	call	0x570da0
  57b442: eb 74                        	jmp	0x57b4b8 <.text+0x14b8>
  57b444: 80 78 64 00                  	cmp	byte ptr [eax + 0x64], 0x0
  57b448: 75 12                        	jne	0x57b45c <.text+0x145c>
  57b44a: 88 58 64                     	mov	byte ptr [eax + 0x64], bl
  57b44d: 56                           	push	esi
  57b44e: c6 46 64 00                  	mov	byte ptr [esi + 0x64], 0x0
  57b452: e8 a9 59 ff ff               	call	0x570e00
  57b457: 8b 06                        	mov	eax, dword ptr [esi]
  57b459: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b45c: 80 78 65 00                  	cmp	byte ptr [eax + 0x65], 0x0
  57b460: 75 13                        	jne	0x57b475 <.text+0x1475>
  57b462: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57b465: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b468: 75 1e                        	jne	0x57b488 <.text+0x1488>
  57b46a: 8b 10                        	mov	edx, dword ptr [eax]
  57b46c: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b46f: 75 17                        	jne	0x57b488 <.text+0x1488>
  57b471: c6 40 64 00                  	mov	byte ptr [eax + 0x64], 0x0
  57b475: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57b478: 8b fe                        	mov	edi, esi
  57b47a: 8b 76 04                     	mov	esi, dword ptr [esi + 0x4]
  57b47d: 3b 78 04                     	cmp	edi, dword ptr [eax + 0x4]
  57b480: 0f 85 4a ff ff ff            	jne	0x57b3d0 <.text+0x13d0>
  57b486: eb 30                        	jmp	0x57b4b8 <.text+0x14b8>
  57b488: 8b 10                        	mov	edx, dword ptr [eax]
  57b48a: 38 5a 64                     	cmp	byte ptr [edx + 0x64], bl
  57b48d: 75 15                        	jne	0x57b4a4 <.text+0x14a4>
  57b48f: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57b492: 88 5a 64                     	mov	byte ptr [edx + 0x64], bl
  57b495: 50                           	push	eax
  57b496: c6 40 64 00                  	mov	byte ptr [eax + 0x64], 0x0
  57b49a: e8 01 59 ff ff               	call	0x570da0
  57b49f: 8b 06                        	mov	eax, dword ptr [esi]
  57b4a1: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b4a4: 8a 56 64                     	mov	dl, byte ptr [esi + 0x64]
  57b4a7: 88 50 64                     	mov	byte ptr [eax + 0x64], dl
  57b4aa: 88 5e 64                     	mov	byte ptr [esi + 0x64], bl
  57b4ad: 8b 00                        	mov	eax, dword ptr [eax]
  57b4af: 56                           	push	esi
  57b4b0: 88 58 64                     	mov	byte ptr [eax + 0x64], bl
  57b4b3: e8 48 59 ff ff               	call	0x570e00
  57b4b8: 88 5f 64                     	mov	byte ptr [edi + 0x64], bl
  57b4bb: 8b 75 ec                     	mov	esi, dword ptr [ebp - 0x14]
  57b4be: 83 c6 0c                     	add	esi, 0xc
  57b4c1: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57b4c4: 33 ff                        	xor	edi, edi
  57b4c6: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57b4c9: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57b4cc: e8 9f c5 ff ff               	call	0x577a70
  57b4d1: 8b ce                        	mov	ecx, esi
  57b4d3: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57b4da: e8 e1 57 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57b4df: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57b4e2: 51                           	push	ecx
  57b4e3: e8 3f a6 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57b4e8: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b4eb: 8b 41 0c                     	mov	eax, dword ptr [ecx + 0xc]
  57b4ee: 83 c4 04                     	add	esp, 0x4
  57b4f1: 3b c7                        	cmp	eax, edi
  57b4f3: 76 04                        	jbe	0x57b4f9 <.text+0x14f9>
  57b4f5: 48                           	dec	eax
  57b4f6: 89 41 0c                     	mov	dword ptr [ecx + 0xc], eax
  57b4f9: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57b4fc: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  57b4ff: 8b 09                        	mov	ecx, dword ptr [ecx]
  57b501: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  57b504: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  57b507: 89 08                        	mov	dword ptr [eax], ecx
  57b509: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b50c: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b513: 59                           	pop	ecx
  57b514: 5f                           	pop	edi
  57b515: 5e                           	pop	esi
  57b516: 5b                           	pop	ebx
  57b517: 8b e5                        	mov	esp, ebp
  57b519: 5d                           	pop	ebp
  57b51a: c2 10 00                     	ret	0x10
  57b51d: e8 85 b8 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57b522: cc                           	int3
  57b523: cc                           	int3
  57b524: cc                           	int3
  57b525: cc                           	int3
  57b526: cc                           	int3
  57b527: cc                           	int3
  57b528: cc                           	int3
  57b529: cc                           	int3
  57b52a: cc                           	int3
  57b52b: cc                           	int3
  57b52c: cc                           	int3
  57b52d: cc                           	int3
  57b52e: cc                           	int3
  57b52f: cc                           	int3
  57b530: 55                           	push	ebp
  57b531: 8b ec                        	mov	ebp, esp
  57b533: 6a ff                        	push	-0x1
  57b535: 68 68 d3 41 01               	push	0x141d368
  57b53a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57b540: 50                           	push	eax
  57b541: 83 ec 38                     	sub	esp, 0x38
  57b544: 53                           	push	ebx
  57b545: 56                           	push	esi
  57b546: 57                           	push	edi
  57b547: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57b54c: 33 c5                        	xor	eax, ebp
  57b54e: 50                           	push	eax
  57b54f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57b552: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57b558: 8b f9                        	mov	edi, ecx
  57b55a: 89 7d d4                     	mov	dword ptr [ebp - 0x2c], edi
  57b55d: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  57b560: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57b563: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57b566: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  57b569: 83 c3 0c                     	add	ebx, 0xc
  57b56c: 80 7e 65 00                  	cmp	byte ptr [esi + 0x65], 0x0
  57b570: b0 01                        	mov	al, 0x1
  57b572: 88 45 ec                     	mov	byte ptr [ebp - 0x14], al
  57b575: 75 78                        	jne	0x57b5ef <.text+0x15ef>
  57b577: 80 7d 10 00                  	cmp	byte ptr [ebp + 0x10], 0x0
  57b57b: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  57b57e: 74 2a                        	je	0x57b5aa <.text+0x15aa>
  57b580: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57b583: 8d 45 e8                     	lea	eax, [ebp - 0x18]
  57b586: 50                           	push	eax
  57b587: 8d 51 08                     	lea	edx, [ecx + 0x8]
  57b58a: 52                           	push	edx
  57b58b: e8 50 58 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b590: 8b 7d e8                     	mov	edi, dword ptr [ebp - 0x18]
  57b593: 8d 45 e4                     	lea	eax, [ebp - 0x1c]
  57b596: 50                           	push	eax
  57b597: 8d 43 08                     	lea	eax, [ebx + 0x8]
  57b59a: 50                           	push	eax
  57b59b: 8b cb                        	mov	ecx, ebx
  57b59d: e8 3e 58 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b5a2: 3b 7d e4                     	cmp	edi, dword ptr [ebp - 0x1c]
  57b5a5: 0f 9d c0                     	setge	al
  57b5a8: eb 2e                        	jmp	0x57b5d8 <.text+0x15d8>
  57b5aa: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57b5ad: 51                           	push	ecx
  57b5ae: 8d 43 08                     	lea	eax, [ebx + 0x8]
  57b5b1: 50                           	push	eax
  57b5b2: 8b cb                        	mov	ecx, ebx
  57b5b4: e8 27 58 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b5b9: 8b 55 e0                     	mov	edx, dword ptr [ebp - 0x20]
  57b5bc: 8d 45 d8                     	lea	eax, [ebp - 0x28]
  57b5bf: 50                           	push	eax
  57b5c0: 8d 4e 14                     	lea	ecx, [esi + 0x14]
  57b5c3: 51                           	push	ecx
  57b5c4: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57b5c7: 89 55 dc                     	mov	dword ptr [ebp - 0x24], edx
  57b5ca: e8 11 58 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b5cf: 8b 55 dc                     	mov	edx, dword ptr [ebp - 0x24]
  57b5d2: 3b 55 d8                     	cmp	edx, dword ptr [ebp - 0x28]
  57b5d5: 0f 9c c0                     	setl	al
  57b5d8: 88 45 ec                     	mov	byte ptr [ebp - 0x14], al
  57b5db: 84 c0                        	test	al, al
  57b5dd: 74 04                        	je	0x57b5e3 <.text+0x15e3>
  57b5df: 8b 36                        	mov	esi, dword ptr [esi]
  57b5e1: eb 03                        	jmp	0x57b5e6 <.text+0x15e6>
  57b5e3: 8b 76 08                     	mov	esi, dword ptr [esi + 0x8]
  57b5e6: 80 7e 65 00                  	cmp	byte ptr [esi + 0x65], 0x0
  57b5ea: 74 8b                        	je	0x57b577 <.text+0x1577>
  57b5ec: 8b 7d d4                     	mov	edi, dword ptr [ebp - 0x2c]
  57b5ef: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b5f2: 8b 37                        	mov	esi, dword ptr [edi]
  57b5f4: c7 45 cc 00 00 00 00         	mov	dword ptr [ebp - 0x34], 0x0
  57b5fb: 89 4d d0                     	mov	dword ptr [ebp - 0x30], ecx
  57b5fe: 89 75 c8                     	mov	dword ptr [ebp - 0x38], esi
  57b601: 84 c0                        	test	al, al
  57b603: 0f 84 a8 00 00 00            	je	0x57b6b1 <.text+0x16b1>
  57b609: 8d 55 bc                     	lea	edx, [ebp - 0x44]
  57b60c: 52                           	push	edx
  57b60d: 8b cf                        	mov	ecx, edi
  57b60f: e8 3c 48 fe ff               	call	0x55fe50
  57b614: 85 f6                        	test	esi, esi
  57b616: 0f 84 8d 00 00 00            	je	0x57b6a9 <.text+0x16a9>
  57b61c: 8b 16                        	mov	edx, dword ptr [esi]
  57b61e: 85 d2                        	test	edx, edx
  57b620: 0f 84 83 00 00 00            	je	0x57b6a9 <.text+0x16a9>
  57b626: 8b 08                        	mov	ecx, dword ptr [eax]
  57b628: 85 c9                        	test	ecx, ecx
  57b62a: 74 02                        	je	0x57b62e <.text+0x162e>
  57b62c: 8b 09                        	mov	ecx, dword ptr [ecx]
  57b62e: 3b d1                        	cmp	edx, ecx
  57b630: 75 77                        	jne	0x57b6a9 <.text+0x16a9>
  57b632: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57b635: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57b638: 0f 94 c0                     	sete	al
  57b63b: 84 c0                        	test	al, al
  57b63d: 74 52                        	je	0x57b691 <.text+0x1691>
  57b63f: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  57b642: 50                           	push	eax
  57b643: 51                           	push	ecx
  57b644: 6a 01                        	push	0x1
  57b646: 8d 4d bc                     	lea	ecx, [ebp - 0x44]
  57b649: 51                           	push	ecx
  57b64a: 8b cf                        	mov	ecx, edi
  57b64c: e8 ff f7 ff ff               	call	0x57ae50 <.text+0xe50>
  57b651: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  57b654: 8b 10                        	mov	edx, dword ptr [eax]
  57b656: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57b65c: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57b663: 85 d2                        	test	edx, edx
  57b665: 74 0a                        	je	0x57b671 <.text+0x1671>
  57b667: 8b 12                        	mov	edx, dword ptr [edx]
  57b669: 85 d2                        	test	edx, edx
  57b66b: 74 04                        	je	0x57b671 <.text+0x1671>
  57b66d: 8b 12                        	mov	edx, dword ptr [edx]
  57b66f: 89 11                        	mov	dword ptr [ecx], edx
  57b671: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57b674: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57b677: c6 41 0c 01                  	mov	byte ptr [ecx + 0xc], 0x1
  57b67b: 8b c1                        	mov	eax, ecx
  57b67d: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b680: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b687: 59                           	pop	ecx
  57b688: 5f                           	pop	edi
  57b689: 5e                           	pop	esi
  57b68a: 5b                           	pop	ebx
  57b68b: 8b e5                        	mov	esp, ebp
  57b68d: 5d                           	pop	ebp
  57b68e: c2 0c 00                     	ret	0xc
  57b691: 85 d2                        	test	edx, edx
  57b693: 74 14                        	je	0x57b6a9 <.text+0x16a9>
  57b695: 85 c9                        	test	ecx, ecx
  57b697: 74 10                        	je	0x57b6a9 <.text+0x16a9>
  57b699: 8d 4d c8                     	lea	ecx, [ebp - 0x38]
  57b69c: e8 5f 51 ff ff               	call	0x570800
  57b6a1: 8b 4d d0                     	mov	ecx, dword ptr [ebp - 0x30]
  57b6a4: 39 4d f0                     	cmp	dword ptr [ebp - 0x10], ecx
  57b6a7: 75 05                        	jne	0x57b6ae <.text+0x16ae>
  57b6a9: e8 f9 b6 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57b6ae: 8b 75 c8                     	mov	esi, dword ptr [ebp - 0x38]
  57b6b1: 8b 4d d0                     	mov	ecx, dword ptr [ebp - 0x30]
  57b6b4: 83 c1 0c                     	add	ecx, 0xc
  57b6b7: 8d 55 10                     	lea	edx, [ebp + 0x10]
  57b6ba: 52                           	push	edx
  57b6bb: 8d 41 08                     	lea	eax, [ecx + 0x8]
  57b6be: 50                           	push	eax
  57b6bf: e8 1c 57 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b6c4: 8b 4d 10                     	mov	ecx, dword ptr [ebp + 0x10]
  57b6c7: 8d 55 d8                     	lea	edx, [ebp - 0x28]
  57b6ca: 52                           	push	edx
  57b6cb: 8d 43 08                     	lea	eax, [ebx + 0x8]
  57b6ce: 89 4d d4                     	mov	dword ptr [ebp - 0x2c], ecx
  57b6d1: 50                           	push	eax
  57b6d2: 8b cb                        	mov	ecx, ebx
  57b6d4: e8 07 57 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57b6d9: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
  57b6dc: 3b 4d d8                     	cmp	ecx, dword ptr [ebp - 0x28]
  57b6df: 7d 15                        	jge	0x57b6f6 <.text+0x16f6>
  57b6e1: 8b 55 0c                     	mov	edx, dword ptr [ebp + 0xc]
  57b6e4: 8b 45 f0                     	mov	eax, dword ptr [ebp - 0x10]
  57b6e7: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57b6ea: 52                           	push	edx
  57b6eb: 50                           	push	eax
  57b6ec: 51                           	push	ecx
  57b6ed: 8d 55 c8                     	lea	edx, [ebp - 0x38]
  57b6f0: 52                           	push	edx
  57b6f1: e9 54 ff ff ff               	jmp	0x57b64a <.text+0x164a>
  57b6f6: 89 5d 10                     	mov	dword ptr [ebp + 0x10], ebx
  57b6f9: 33 ff                        	xor	edi, edi
  57b6fb: 8d 4b 0c                     	lea	ecx, [ebx + 0xc]
  57b6fe: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57b701: e8 6a c3 ff ff               	call	0x577a70
  57b706: 8b cb                        	mov	ecx, ebx
  57b708: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57b70f: e8 ac 55 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57b714: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  57b717: 51                           	push	ecx
  57b718: e8 0a a4 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57b71d: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57b720: 83 c4 04                     	add	esp, 0x4
  57b723: 89 38                        	mov	dword ptr [eax], edi
  57b725: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  57b728: 3b f7                        	cmp	esi, edi
  57b72a: 74 0a                        	je	0x57b736 <.text+0x1736>
  57b72c: 8b 36                        	mov	esi, dword ptr [esi]
  57b72e: 3b f7                        	cmp	esi, edi
  57b730: 74 04                        	je	0x57b736 <.text+0x1736>
  57b732: 8b 16                        	mov	edx, dword ptr [esi]
  57b734: 89 10                        	mov	dword ptr [eax], edx
  57b736: 8b 4d d0                     	mov	ecx, dword ptr [ebp - 0x30]
  57b739: 89 48 08                     	mov	dword ptr [eax + 0x8], ecx
  57b73c: c6 40 0c 00                  	mov	byte ptr [eax + 0xc], 0x0
  57b740: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b743: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b74a: 59                           	pop	ecx
  57b74b: 5f                           	pop	edi
  57b74c: 5e                           	pop	esi
  57b74d: 5b                           	pop	ebx
  57b74e: 8b e5                        	mov	esp, ebp
  57b750: 5d                           	pop	ebp
  57b751: c2 0c 00                     	ret	0xc
  57b754: cc                           	int3
  57b755: cc                           	int3
  57b756: cc                           	int3
  57b757: cc                           	int3
  57b758: cc                           	int3
  57b759: cc                           	int3
  57b75a: cc                           	int3
  57b75b: cc                           	int3
  57b75c: cc                           	int3
  57b75d: cc                           	int3
  57b75e: cc                           	int3
  57b75f: cc                           	int3
  57b760: 55                           	push	ebp
  57b761: 8b ec                        	mov	ebp, esp
  57b763: 6a ff                        	push	-0x1
  57b765: 68 90 d3 41 01               	push	0x141d390
  57b76a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57b770: 50                           	push	eax
  57b771: 83 ec 0c                     	sub	esp, 0xc
  57b774: 53                           	push	ebx
  57b775: 56                           	push	esi
  57b776: 57                           	push	edi
  57b777: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57b77c: 33 c5                        	xor	eax, ebp
  57b77e: 50                           	push	eax
  57b77f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57b782: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57b788: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57b78b: 8b d9                        	mov	ebx, ecx
  57b78d: 89 5d e8                     	mov	dword ptr [ebp - 0x18], ebx
  57b790: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57b793: 80 7f 65 00                  	cmp	byte ptr [edi + 0x65], 0x0
  57b797: 8b 43 08                     	mov	eax, dword ptr [ebx + 0x8]
  57b79a: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  57b79d: 75 48                        	jne	0x57b7e7 <.text+0x17e7>
  57b79f: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  57b7a2: 51                           	push	ecx
  57b7a3: 8b cb                        	mov	ecx, ebx
  57b7a5: e8 16 f9 ff ff               	call	0x57b0c0 <.text+0x10c0>
  57b7aa: 8b 55 0c                     	mov	edx, dword ptr [ebp + 0xc]
  57b7ad: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57b7b0: 8b f0                        	mov	esi, eax
  57b7b2: 89 56 04                     	mov	dword ptr [esi + 0x4], edx
  57b7b5: 8a 47 64                     	mov	al, byte ptr [edi + 0x64]
  57b7b8: 88 46 64                     	mov	byte ptr [esi + 0x64], al
  57b7bb: 80 79 65 00                  	cmp	byte ptr [ecx + 0x65], 0x0
  57b7bf: 74 03                        	je	0x57b7c4 <.text+0x17c4>
  57b7c1: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57b7c4: 8b 17                        	mov	edx, dword ptr [edi]
  57b7c6: 56                           	push	esi
  57b7c7: 52                           	push	edx
  57b7c8: 8b cb                        	mov	ecx, ebx
  57b7ca: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57b7d1: e8 8a ff ff ff               	call	0x57b760 <.text+0x1760>
  57b7d6: 89 06                        	mov	dword ptr [esi], eax
  57b7d8: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  57b7db: 56                           	push	esi
  57b7dc: 50                           	push	eax
  57b7dd: 8b cb                        	mov	ecx, ebx
  57b7df: e8 7c ff ff ff               	call	0x57b760 <.text+0x1760>
  57b7e4: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57b7e7: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  57b7ea: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b7ed: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b7f4: 59                           	pop	ecx
  57b7f5: 5f                           	pop	edi
  57b7f6: 5e                           	pop	esi
  57b7f7: 5b                           	pop	ebx
  57b7f8: 8b e5                        	mov	esp, ebp
  57b7fa: 5d                           	pop	ebp
  57b7fb: c2 08 00                     	ret	0x8
  57b7fe: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57b801: 51                           	push	ecx
  57b802: 8b 4d e8                     	mov	ecx, dword ptr [ebp - 0x18]
  57b805: e8 c6 f9 ff ff               	call	0x57b1d0 <.text+0x11d0>
  57b80a: 6a 00                        	push	0x0
  57b80c: 6a 00                        	push	0x0
  57b80e: e8 87 b3 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57b813: cc                           	int3
  57b814: cc                           	int3
  57b815: cc                           	int3
  57b816: cc                           	int3
  57b817: cc                           	int3
  57b818: cc                           	int3
  57b819: cc                           	int3
  57b81a: cc                           	int3
  57b81b: cc                           	int3
  57b81c: cc                           	int3
  57b81d: cc                           	int3
  57b81e: cc                           	int3
  57b81f: cc                           	int3
  57b820: 55                           	push	ebp
  57b821: 8b ec                        	mov	ebp, esp
  57b823: 83 ec 1c                     	sub	esp, 0x1c
  57b826: 53                           	push	ebx
  57b827: 56                           	push	esi
  57b828: 57                           	push	edi
  57b829: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57b82c: 50                           	push	eax
  57b82d: 8b f1                        	mov	esi, ecx
  57b82f: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57b836: e8 15 46 fe ff               	call	0x55fe50
  57b83b: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57b83e: 85 db                        	test	ebx, ebx
  57b840: 0f 84 82 00 00 00            	je	0x57b8c8 <.text+0x18c8>
  57b846: 8b 13                        	mov	edx, dword ptr [ebx]
  57b848: 85 d2                        	test	edx, edx
  57b84a: 74 7c                        	je	0x57b8c8 <.text+0x18c8>
  57b84c: 8b 08                        	mov	ecx, dword ptr [eax]
  57b84e: 85 c9                        	test	ecx, ecx
  57b850: 74 02                        	je	0x57b854 <.text+0x1854>
  57b852: 8b 09                        	mov	ecx, dword ptr [ecx]
  57b854: 3b d1                        	cmp	edx, ecx
  57b856: 75 70                        	jne	0x57b8c8 <.text+0x18c8>
  57b858: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57b85b: 8b 7d 18                     	mov	edi, dword ptr [ebp + 0x18]
  57b85e: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57b861: 75 6d                        	jne	0x57b8d0 <.text+0x18d0>
  57b863: 8d 55 e4                     	lea	edx, [ebp - 0x1c]
  57b866: 52                           	push	edx
  57b867: 8b ce                        	mov	ecx, esi
  57b869: e8 d2 8a 24 00               	call	0x7c4340 <.text+0x24a340>
  57b86e: 85 ff                        	test	edi, edi
  57b870: 74 56                        	je	0x57b8c8 <.text+0x18c8>
  57b872: 8b 17                        	mov	edx, dword ptr [edi]
  57b874: 85 d2                        	test	edx, edx
  57b876: 74 50                        	je	0x57b8c8 <.text+0x18c8>
  57b878: 8b 08                        	mov	ecx, dword ptr [eax]
  57b87a: 85 c9                        	test	ecx, ecx
  57b87c: 74 02                        	je	0x57b880 <.text+0x1880>
  57b87e: 8b 09                        	mov	ecx, dword ptr [ecx]
  57b880: 3b d1                        	cmp	edx, ecx
  57b882: 75 44                        	jne	0x57b8c8 <.text+0x18c8>
  57b884: 8b 4d 20                     	mov	ecx, dword ptr [ebp + 0x20]
  57b887: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57b88a: 75 44                        	jne	0x57b8d0 <.text+0x18d0>
  57b88c: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57b88f: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57b892: 50                           	push	eax
  57b893: 8b ce                        	mov	ecx, esi
  57b895: e8 36 f9 ff ff               	call	0x57b1d0 <.text+0x11d0>
  57b89a: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b89d: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57b8a0: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57b8a3: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b8a6: 89 00                        	mov	dword ptr [eax], eax
  57b8a8: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57b8ab: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57b8ae: 57                           	push	edi
  57b8af: 8b ce                        	mov	ecx, esi
  57b8b1: c7 46 0c 00 00 00 00         	mov	dword ptr [esi + 0xc], 0x0
  57b8b8: e8 93 45 fe ff               	call	0x55fe50
  57b8bd: 8b c7                        	mov	eax, edi
  57b8bf: 5f                           	pop	edi
  57b8c0: 5e                           	pop	esi
  57b8c1: 5b                           	pop	ebx
  57b8c2: 8b e5                        	mov	esp, ebp
  57b8c4: 5d                           	pop	ebp
  57b8c5: c2 1c 00                     	ret	0x1c
  57b8c8: e8 da b4 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57b8cd: 8d 49 00                     	lea	ecx, [ecx]
  57b8d0: 85 db                        	test	ebx, ebx
  57b8d2: 74 f4                        	je	0x57b8c8 <.text+0x18c8>
  57b8d4: 8b 0b                        	mov	ecx, dword ptr [ebx]
  57b8d6: 85 c9                        	test	ecx, ecx
  57b8d8: 74 ee                        	je	0x57b8c8 <.text+0x18c8>
  57b8da: 85 ff                        	test	edi, edi
  57b8dc: 75 04                        	jne	0x57b8e2 <.text+0x18e2>
  57b8de: 33 c0                        	xor	eax, eax
  57b8e0: eb 02                        	jmp	0x57b8e4 <.text+0x18e4>
  57b8e2: 8b 07                        	mov	eax, dword ptr [edi]
  57b8e4: 3b c8                        	cmp	ecx, eax
  57b8e6: 75 e0                        	jne	0x57b8c8 <.text+0x18c8>
  57b8e8: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57b8eb: 3b 4d 20                     	cmp	ecx, dword ptr [ebp + 0x20]
  57b8ee: 74 26                        	je	0x57b916 <.text+0x1916>
  57b8f0: 83 ec 0c                     	sub	esp, 0xc
  57b8f3: 8b cc                        	mov	ecx, esp
  57b8f5: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57b8f8: 6a 00                        	push	0x0
  57b8fa: 51                           	push	ecx
  57b8fb: 8d 4d 0c                     	lea	ecx, [ebp + 0xc]
  57b8fe: e8 dd a8 bb 00               	call	0x11361e0 <.text+0xbbc1e0>
  57b903: 8d 55 e4                     	lea	edx, [ebp - 0x1c]
  57b906: 52                           	push	edx
  57b907: 8b ce                        	mov	ecx, esi
  57b909: e8 52 f9 ff ff               	call	0x57b260 <.text+0x1260>
  57b90e: 8b 7d 18                     	mov	edi, dword ptr [ebp + 0x18]
  57b911: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57b914: eb ba                        	jmp	0x57b8d0 <.text+0x18d0>
  57b916: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57b919: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  57b91f: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  57b926: 89 48 08                     	mov	dword ptr [eax + 0x8], ecx
  57b929: 85 f6                        	test	esi, esi
  57b92b: 74 04                        	je	0x57b931 <.text+0x1931>
  57b92d: 8b 0e                        	mov	ecx, dword ptr [esi]
  57b92f: 89 08                        	mov	dword ptr [eax], ecx
  57b931: 5f                           	pop	edi
  57b932: 5e                           	pop	esi
  57b933: 5b                           	pop	ebx
  57b934: 8b e5                        	mov	esp, ebp
  57b936: 5d                           	pop	ebp
  57b937: c2 1c 00                     	ret	0x1c
  57b93a: cc                           	int3
  57b93b: cc                           	int3
  57b93c: cc                           	int3
  57b93d: cc                           	int3
  57b93e: cc                           	int3
  57b93f: cc                           	int3
  57b940: 55                           	push	ebp
  57b941: 8b ec                        	mov	ebp, esp
  57b943: 6a ff                        	push	-0x1
  57b945: 68 c1 d3 41 01               	push	0x141d3c1
  57b94a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57b950: 50                           	push	eax
  57b951: 83 ec 1c                     	sub	esp, 0x1c
  57b954: 53                           	push	ebx
  57b955: 56                           	push	esi
  57b956: 57                           	push	edi
  57b957: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57b95c: 33 c5                        	xor	eax, ebp
  57b95e: 50                           	push	eax
  57b95f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57b962: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57b968: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57b96b: 8b f9                        	mov	edi, ecx
  57b96d: 6a 28                        	push	0x28
  57b96f: e8 a6 b1 e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57b974: 8b f0                        	mov	esi, eax
  57b976: 33 c9                        	xor	ecx, ecx
  57b978: 83 c4 04                     	add	esp, 0x4
  57b97b: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57b97e: 3b f1                        	cmp	esi, ecx
  57b980: 74 67                        	je	0x57b9e9 <.text+0x19e9>
  57b982: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  57b985: 89 06                        	mov	dword ptr [esi], eax
  57b987: 8b 57 08                     	mov	edx, dword ptr [edi + 0x8]
  57b98a: 89 56 04                     	mov	dword ptr [esi + 0x4], edx
  57b98d: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  57b990: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57b993: 8d 46 0c                     	lea	eax, [esi + 0xc]
  57b996: 66 89 4e 24                  	mov	word ptr [esi + 0x24], cx
  57b99a: 89 4d fc                     	mov	dword ptr [ebp - 0x4], ecx
  57b99d: 89 45 e8                     	mov	dword ptr [ebp - 0x18], eax
  57b9a0: 89 45 e4                     	mov	dword ptr [ebp - 0x1c], eax
  57b9a3: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57b9a7: 3b c1                        	cmp	eax, ecx
  57b9a9: 74 13                        	je	0x57b9be <.text+0x19be>
  57b9ab: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
  57b9ae: 8b 0a                        	mov	ecx, dword ptr [edx]
  57b9b0: 83 c2 04                     	add	edx, 0x4
  57b9b3: 89 08                        	mov	dword ptr [eax], ecx
  57b9b5: 8d 48 04                     	lea	ecx, [eax + 0x4]
  57b9b8: 52                           	push	edx
  57b9b9: e8 32 c5 ff ff               	call	0x577ef0
  57b9be: 8b c6                        	mov	eax, esi
  57b9c0: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57b9c3: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57b9ca: 59                           	pop	ecx
  57b9cb: 5f                           	pop	edi
  57b9cc: 5e                           	pop	esi
  57b9cd: 5b                           	pop	ebx
  57b9ce: 8b e5                        	mov	esp, ebp
  57b9d0: 5d                           	pop	ebp
  57b9d1: c2 04 00                     	ret	0x4
  57b9d4: 8b 55 ec                     	mov	edx, dword ptr [ebp - 0x14]
  57b9d7: 52                           	push	edx
  57b9d8: e8 4a a1 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57b9dd: 83 c4 04                     	add	esp, 0x4
  57b9e0: 33 c9                        	xor	ecx, ecx
  57b9e2: 51                           	push	ecx
  57b9e3: 51                           	push	ecx
  57b9e4: e8 b1 b1 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57b9e9: 8d 45 08                     	lea	eax, [ebp + 0x8]
  57b9ec: 89 4d 08                     	mov	dword ptr [ebp + 0x8], ecx
  57b9ef: 50                           	push	eax
  57b9f0: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57b9f3: e8 d2 aa e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57b9f8: 68 90 0f 91 01               	push	0x1910f90
  57b9fd: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57ba00: 51                           	push	ecx
  57ba01: c7 45 d8 84 20 56 01         	mov	dword ptr [ebp - 0x28], 0x1562084
  57ba08: e8 8d b1 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57ba0d: cc                           	int3
  57ba0e: cc                           	int3
  57ba0f: cc                           	int3
  57ba10: 55                           	push	ebp
  57ba11: 8b ec                        	mov	ebp, esp
  57ba13: 83 ec 24                     	sub	esp, 0x24
  57ba16: 53                           	push	ebx
  57ba17: 33 c0                        	xor	eax, eax
  57ba19: 56                           	push	esi
  57ba1a: 89 45 f8                     	mov	dword ptr [ebp - 0x8], eax
  57ba1d: 8b f1                        	mov	esi, ecx
  57ba1f: 8b 4d 18                     	mov	ecx, dword ptr [ebp + 0x18]
  57ba22: 57                           	push	edi
  57ba23: 8d 59 0c                     	lea	ebx, [ecx + 0xc]
  57ba26: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  57ba29: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  57ba2c: 89 45 f4                     	mov	dword ptr [ebp - 0xc], eax
  57ba2f: 39 46 0c                     	cmp	dword ptr [esi + 0xc], eax
  57ba32: 75 1d                        	jne	0x57ba51 <.text+0x1a51>
  57ba34: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57ba37: 51                           	push	ecx
  57ba38: 50                           	push	eax
  57ba39: 6a 01                        	push	0x1
  57ba3b: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57ba3e: 57                           	push	edi
  57ba3f: 8b ce                        	mov	ecx, esi
  57ba41: e8 0a f4 ff ff               	call	0x57ae50 <.text+0xe50>
  57ba46: 8b c7                        	mov	eax, edi
  57ba48: 5f                           	pop	edi
  57ba49: 5e                           	pop	esi
  57ba4a: 5b                           	pop	ebx
  57ba4b: 8b e5                        	mov	esp, ebp
  57ba4d: 5d                           	pop	ebp
  57ba4e: c2 14 00                     	ret	0x14
  57ba51: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57ba54: 51                           	push	ecx
  57ba55: 8b ce                        	mov	ecx, esi
  57ba57: e8 f4 43 fe ff               	call	0x55fe50
  57ba5c: 8b 7d 0c                     	mov	edi, dword ptr [ebp + 0xc]
  57ba5f: 85 ff                        	test	edi, edi
  57ba61: 0f 84 14 02 00 00            	je	0x57bc7b <.text+0x1c7b>
  57ba67: 8b 17                        	mov	edx, dword ptr [edi]
  57ba69: 85 d2                        	test	edx, edx
  57ba6b: 0f 84 0a 02 00 00            	je	0x57bc7b <.text+0x1c7b>
  57ba71: 8b 08                        	mov	ecx, dword ptr [eax]
  57ba73: 85 c9                        	test	ecx, ecx
  57ba75: 74 02                        	je	0x57ba79 <.text+0x1a79>
  57ba77: 8b 09                        	mov	ecx, dword ptr [ecx]
  57ba79: 3b d1                        	cmp	edx, ecx
  57ba7b: 0f 85 fa 01 00 00            	jne	0x57bc7b <.text+0x1c7b>
  57ba81: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57ba84: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57ba87: 75 3a                        	jne	0x57bac3 <.text+0x1ac3>
  57ba89: 8d 55 fc                     	lea	edx, [ebp - 0x4]
  57ba8c: 52                           	push	edx
  57ba8d: 8d 43 08                     	lea	eax, [ebx + 0x8]
  57ba90: 8d 79 0c                     	lea	edi, [ecx + 0xc]
  57ba93: 50                           	push	eax
  57ba94: 8b cb                        	mov	ecx, ebx
  57ba96: e8 45 53 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57ba9b: 8b 5d fc                     	mov	ebx, dword ptr [ebp - 0x4]
  57ba9e: 8d 4d f8                     	lea	ecx, [ebp - 0x8]
  57baa1: 51                           	push	ecx
  57baa2: 8d 57 08                     	lea	edx, [edi + 0x8]
  57baa5: 52                           	push	edx
  57baa6: 8b cf                        	mov	ecx, edi
  57baa8: e8 33 53 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57baad: 3b 5d f8                     	cmp	ebx, dword ptr [ebp - 0x8]
  57bab0: 0f 8d 83 01 00 00            	jge	0x57bc39 <.text+0x1c39>
  57bab6: 8b 45 18                     	mov	eax, dword ptr [ebp + 0x18]
  57bab9: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57babc: 50                           	push	eax
  57babd: 51                           	push	ecx
  57babe: e9 76 ff ff ff               	jmp	0x57ba39 <.text+0x1a39>
  57bac3: 8d 55 e0                     	lea	edx, [ebp - 0x20]
  57bac6: 52                           	push	edx
  57bac7: 8b ce                        	mov	ecx, esi
  57bac9: e8 72 88 24 00               	call	0x7c4340 <.text+0x24a340>
  57bace: 8b 0f                        	mov	ecx, dword ptr [edi]
  57bad0: 85 c9                        	test	ecx, ecx
  57bad2: 0f 84 a3 01 00 00            	je	0x57bc7b <.text+0x1c7b>
  57bad8: 8b 10                        	mov	edx, dword ptr [eax]
  57bada: 85 d2                        	test	edx, edx
  57badc: 74 02                        	je	0x57bae0 <.text+0x1ae0>
  57bade: 8b 12                        	mov	edx, dword ptr [edx]
  57bae0: 3b ca                        	cmp	ecx, edx
  57bae2: 0f 85 93 01 00 00            	jne	0x57bc7b <.text+0x1c7b>
  57bae8: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57baeb: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57baee: 75 2d                        	jne	0x57bb1d <.text+0x1b1d>
  57baf0: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57baf3: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57baf6: 83 c0 0c                     	add	eax, 0xc
  57baf9: 53                           	push	ebx
  57bafa: 50                           	push	eax
  57bafb: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57bafe: e8 9d e5 f1 ff               	call	0x49a0a0
  57bb03: 84 c0                        	test	al, al
  57bb05: 0f 84 2e 01 00 00            	je	0x57bc39 <.text+0x1c39>
  57bb0b: 8b 4d 18                     	mov	ecx, dword ptr [ebp + 0x18]
  57bb0e: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57bb11: 8b 42 08                     	mov	eax, dword ptr [edx + 0x8]
  57bb14: 51                           	push	ecx
  57bb15: 50                           	push	eax
  57bb16: 6a 00                        	push	0x0
  57bb18: e9 1e ff ff ff               	jmp	0x57ba3b <.text+0x1a3b>
  57bb1d: 83 c1 0c                     	add	ecx, 0xc
  57bb20: 51                           	push	ecx
  57bb21: 53                           	push	ebx
  57bb22: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57bb25: e8 76 e5 f1 ff               	call	0x49a0a0
  57bb2a: 84 c0                        	test	al, al
  57bb2c: 74 7b                        	je	0x57bba9 <.text+0x1ba9>
  57bb2e: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  57bb31: 39 45 ec                     	cmp	dword ptr [ebp - 0x14], eax
  57bb34: 74 0b                        	je	0x57bb41 <.text+0x1b41>
  57bb36: 8b 00                        	mov	eax, dword ptr [eax]
  57bb38: 85 c0                        	test	eax, eax
  57bb3a: 74 05                        	je	0x57bb41 <.text+0x1b41>
  57bb3c: 8b 08                        	mov	ecx, dword ptr [eax]
  57bb3e: 89 4d ec                     	mov	dword ptr [ebp - 0x14], ecx
  57bb41: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  57bb44: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57bb47: 89 55 f4                     	mov	dword ptr [ebp - 0xc], edx
  57bb4a: e8 01 94 ac 00               	call	0x1044f50 <.text+0xacaf50>
  57bb4f: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57bb52: 53                           	push	ebx
  57bb53: 83 c0 0c                     	add	eax, 0xc
  57bb56: 50                           	push	eax
  57bb57: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57bb5a: e8 41 e5 f1 ff               	call	0x49a0a0
  57bb5f: 84 c0                        	test	al, al
  57bb61: 74 46                        	je	0x57bba9 <.text+0x1ba9>
  57bb63: 8b 45 f4                     	mov	eax, dword ptr [ebp - 0xc]
  57bb66: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57bb69: 80 79 65 00                  	cmp	byte ptr [ecx + 0x65], 0x0
  57bb6d: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57bb70: 74 1a                        	je	0x57bb8c <.text+0x1b8c>
  57bb72: 8b 55 18                     	mov	edx, dword ptr [ebp + 0x18]
  57bb75: 52                           	push	edx
  57bb76: 50                           	push	eax
  57bb77: 6a 00                        	push	0x0
  57bb79: 57                           	push	edi
  57bb7a: 8b ce                        	mov	ecx, esi
  57bb7c: e8 cf f2 ff ff               	call	0x57ae50 <.text+0xe50>
  57bb81: 8b c7                        	mov	eax, edi
  57bb83: 5f                           	pop	edi
  57bb84: 5e                           	pop	esi
  57bb85: 5b                           	pop	ebx
  57bb86: 8b e5                        	mov	esp, ebp
  57bb88: 5d                           	pop	ebp
  57bb89: c2 14 00                     	ret	0x14
  57bb8c: 8b 45 18                     	mov	eax, dword ptr [ebp + 0x18]
  57bb8f: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57bb92: 50                           	push	eax
  57bb93: 51                           	push	ecx
  57bb94: 6a 01                        	push	0x1
  57bb96: 57                           	push	edi
  57bb97: 8b ce                        	mov	ecx, esi
  57bb99: e8 b2 f2 ff ff               	call	0x57ae50 <.text+0xe50>
  57bb9e: 8b c7                        	mov	eax, edi
  57bba0: 5f                           	pop	edi
  57bba1: 5e                           	pop	esi
  57bba2: 5b                           	pop	ebx
  57bba3: 8b e5                        	mov	esp, ebp
  57bba5: 5d                           	pop	ebp
  57bba6: c2 14 00                     	ret	0x14
  57bba9: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  57bbac: 53                           	push	ebx
  57bbad: 83 c2 0c                     	add	edx, 0xc
  57bbb0: 52                           	push	edx
  57bbb1: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57bbb4: e8 e7 e4 f1 ff               	call	0x49a0a0
  57bbb9: 84 c0                        	test	al, al
  57bbbb: 74 7c                        	je	0x57bc39 <.text+0x1c39>
  57bbbd: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  57bbc0: 39 45 ec                     	cmp	dword ptr [ebp - 0x14], eax
  57bbc3: 74 0b                        	je	0x57bbd0 <.text+0x1bd0>
  57bbc5: 8b 00                        	mov	eax, dword ptr [eax]
  57bbc7: 85 c0                        	test	eax, eax
  57bbc9: 74 05                        	je	0x57bbd0 <.text+0x1bd0>
  57bbcb: 8b 00                        	mov	eax, dword ptr [eax]
  57bbcd: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  57bbd0: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57bbd3: 8d 55 e0                     	lea	edx, [ebp - 0x20]
  57bbd6: 89 4d f4                     	mov	dword ptr [ebp - 0xc], ecx
  57bbd9: 52                           	push	edx
  57bbda: 8b ce                        	mov	ecx, esi
  57bbdc: e8 5f 87 24 00               	call	0x7c4340 <.text+0x24a340>
  57bbe1: 50                           	push	eax
  57bbe2: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57bbe5: e8 06 58 ff ff               	call	0x5713f0
  57bbea: 8b c8                        	mov	ecx, eax
  57bbec: e8 2f e3 02 00               	call	0x5a9f20 <.text+0x2ff20>
  57bbf1: 84 c0                        	test	al, al
  57bbf3: 75 14                        	jne	0x57bc09 <.text+0x1c09>
  57bbf5: 8b 45 f4                     	mov	eax, dword ptr [ebp - 0xc]
  57bbf8: 83 c0 0c                     	add	eax, 0xc
  57bbfb: 50                           	push	eax
  57bbfc: 53                           	push	ebx
  57bbfd: 8d 4e 04                     	lea	ecx, [esi + 0x4]
  57bc00: e8 9b e4 f1 ff               	call	0x49a0a0
  57bc05: 84 c0                        	test	al, al
  57bc07: 74 30                        	je	0x57bc39 <.text+0x1c39>
  57bc09: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
  57bc0c: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  57bc0f: 80 79 65 00                  	cmp	byte ptr [ecx + 0x65], 0x0
  57bc13: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57bc16: 0f 85 56 ff ff ff            	jne	0x57bb72 <.text+0x1b72>
  57bc1c: 8b 45 18                     	mov	eax, dword ptr [ebp + 0x18]
  57bc1f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57bc22: 50                           	push	eax
  57bc23: 51                           	push	ecx
  57bc24: 6a 01                        	push	0x1
  57bc26: 57                           	push	edi
  57bc27: 8b ce                        	mov	ecx, esi
  57bc29: e8 22 f2 ff ff               	call	0x57ae50 <.text+0xe50>
  57bc2e: 8b c7                        	mov	eax, edi
  57bc30: 5f                           	pop	edi
  57bc31: 5e                           	pop	esi
  57bc32: 5b                           	pop	ebx
  57bc33: 8b e5                        	mov	esp, ebp
  57bc35: 5d                           	pop	ebp
  57bc36: c2 14 00                     	ret	0x14
  57bc39: 8b 55 18                     	mov	edx, dword ptr [ebp + 0x18]
  57bc3c: 6a 00                        	push	0x0
  57bc3e: 52                           	push	edx
  57bc3f: 8d 45 dc                     	lea	eax, [ebp - 0x24]
  57bc42: 50                           	push	eax
  57bc43: 8b ce                        	mov	ecx, esi
  57bc45: e8 e6 f8 ff ff               	call	0x57b530 <.text+0x1530>
  57bc4a: 8b d0                        	mov	edx, eax
  57bc4c: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57bc4f: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  57bc55: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  57bc5c: 8b 0a                        	mov	ecx, dword ptr [edx]
  57bc5e: 85 c9                        	test	ecx, ecx
  57bc60: 74 0a                        	je	0x57bc6c <.text+0x1c6c>
  57bc62: 8b 09                        	mov	ecx, dword ptr [ecx]
  57bc64: 85 c9                        	test	ecx, ecx
  57bc66: 74 04                        	je	0x57bc6c <.text+0x1c6c>
  57bc68: 8b 09                        	mov	ecx, dword ptr [ecx]
  57bc6a: 89 08                        	mov	dword ptr [eax], ecx
  57bc6c: 8b 52 08                     	mov	edx, dword ptr [edx + 0x8]
  57bc6f: 5f                           	pop	edi
  57bc70: 5e                           	pop	esi
  57bc71: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  57bc74: 5b                           	pop	ebx
  57bc75: 8b e5                        	mov	esp, ebp
  57bc77: 5d                           	pop	ebp
  57bc78: c2 14 00                     	ret	0x14
  57bc7b: e8 27 b1 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57bc80: cc                           	int3
  57bc81: cc                           	int3
  57bc82: cc                           	int3
  57bc83: cc                           	int3
  57bc84: cc                           	int3
  57bc85: cc                           	int3
  57bc86: cc                           	int3
  57bc87: cc                           	int3
  57bc88: cc                           	int3
  57bc89: cc                           	int3
  57bc8a: cc                           	int3
  57bc8b: cc                           	int3
  57bc8c: cc                           	int3
  57bc8d: cc                           	int3
  57bc8e: cc                           	int3
  57bc8f: cc                           	int3
  57bc90: 55                           	push	ebp
  57bc91: 8b ec                        	mov	ebp, esp
  57bc93: 53                           	push	ebx
  57bc94: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
  57bc97: 8b 43 08                     	mov	eax, dword ptr [ebx + 0x8]
  57bc9a: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57bc9d: 56                           	push	esi
  57bc9e: 57                           	push	edi
  57bc9f: 8b f1                        	mov	esi, ecx
  57bca1: 8b 7e 08                     	mov	edi, dword ptr [esi + 0x8]
  57bca4: 57                           	push	edi
  57bca5: 50                           	push	eax
  57bca6: e8 b5 fa ff ff               	call	0x57b760 <.text+0x1760>
  57bcab: 89 47 04                     	mov	dword ptr [edi + 0x4], eax
  57bcae: 8b 4b 0c                     	mov	ecx, dword ptr [ebx + 0xc]
  57bcb1: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57bcb4: 89 4e 0c                     	mov	dword ptr [esi + 0xc], ecx
  57bcb7: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57bcba: 80 78 65 00                  	cmp	byte ptr [eax + 0x65], 0x0
  57bcbe: 75 38                        	jne	0x57bcf8 <.text+0x1cf8>
  57bcc0: 8b 08                        	mov	ecx, dword ptr [eax]
  57bcc2: 80 79 65 00                  	cmp	byte ptr [ecx + 0x65], 0x0
  57bcc6: 75 0a                        	jne	0x57bcd2 <.text+0x1cd2>
  57bcc8: 8b c1                        	mov	eax, ecx
  57bcca: 8b 08                        	mov	ecx, dword ptr [eax]
  57bccc: 80 79 65 00                  	cmp	byte ptr [ecx + 0x65], 0x0
  57bcd0: 74 f6                        	je	0x57bcc8 <.text+0x1cc8>
  57bcd2: 89 02                        	mov	dword ptr [edx], eax
  57bcd4: 8b 76 08                     	mov	esi, dword ptr [esi + 0x8]
  57bcd7: 8b 4e 04                     	mov	ecx, dword ptr [esi + 0x4]
  57bcda: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57bcdd: 80 78 65 00                  	cmp	byte ptr [eax + 0x65], 0x0
  57bce1: 75 0b                        	jne	0x57bcee <.text+0x1cee>
  57bce3: 8b c8                        	mov	ecx, eax
  57bce5: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57bce8: 80 78 65 00                  	cmp	byte ptr [eax + 0x65], 0x0
  57bcec: 74 f5                        	je	0x57bce3 <.text+0x1ce3>
  57bcee: 5f                           	pop	edi
  57bcef: 89 4e 08                     	mov	dword ptr [esi + 0x8], ecx
  57bcf2: 5e                           	pop	esi
  57bcf3: 5b                           	pop	ebx
  57bcf4: 5d                           	pop	ebp
  57bcf5: c2 04 00                     	ret	0x4
  57bcf8: 89 12                        	mov	dword ptr [edx], edx
  57bcfa: 8b 76 08                     	mov	esi, dword ptr [esi + 0x8]
  57bcfd: 5f                           	pop	edi
  57bcfe: 89 76 08                     	mov	dword ptr [esi + 0x8], esi
  57bd01: 5e                           	pop	esi
  57bd02: 5b                           	pop	ebx
  57bd03: 5d                           	pop	ebp
  57bd04: c2 04 00                     	ret	0x4
  57bd07: cc                           	int3
  57bd08: cc                           	int3
  57bd09: cc                           	int3
  57bd0a: cc                           	int3
  57bd0b: cc                           	int3
  57bd0c: cc                           	int3
  57bd0d: cc                           	int3
  57bd0e: cc                           	int3
  57bd0f: cc                           	int3
  57bd10: 55                           	push	ebp
  57bd11: 8b ec                        	mov	ebp, esp
  57bd13: 56                           	push	esi
  57bd14: 57                           	push	edi
  57bd15: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57bd18: 8b f1                        	mov	esi, ecx
  57bd1a: 3b f7                        	cmp	esi, edi
  57bd1c: 74 56                        	je	0x57bd74 <.text+0x1d74>
  57bd1e: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bd21: 8b 48 04                     	mov	ecx, dword ptr [eax + 0x4]
  57bd24: 51                           	push	ecx
  57bd25: 8b ce                        	mov	ecx, esi
  57bd27: e8 a4 f4 ff ff               	call	0x57b1d0 <.text+0x11d0>
  57bd2c: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bd2f: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57bd32: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bd35: 89 00                        	mov	dword ptr [eax], eax
  57bd37: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bd3a: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57bd3d: 8b 06                        	mov	eax, dword ptr [esi]
  57bd3f: c7 46 0c 00 00 00 00         	mov	dword ptr [esi + 0xc], 0x0
  57bd46: 8b 17                        	mov	edx, dword ptr [edi]
  57bd48: 89 16                        	mov	dword ptr [esi], edx
  57bd4a: 89 07                        	mov	dword ptr [edi], eax
  57bd4c: 8b 06                        	mov	eax, dword ptr [esi]
  57bd4e: 85 c0                        	test	eax, eax
  57bd50: 74 02                        	je	0x57bd54 <.text+0x1d54>
  57bd52: 89 30                        	mov	dword ptr [eax], esi
  57bd54: 8b 07                        	mov	eax, dword ptr [edi]
  57bd56: 85 c0                        	test	eax, eax
  57bd58: 74 02                        	je	0x57bd5c <.text+0x1d5c>
  57bd5a: 89 38                        	mov	dword ptr [eax], edi
  57bd5c: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bd5f: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
  57bd62: 89 4e 08                     	mov	dword ptr [esi + 0x8], ecx
  57bd65: 89 47 08                     	mov	dword ptr [edi + 0x8], eax
  57bd68: 8b 57 0c                     	mov	edx, dword ptr [edi + 0xc]
  57bd6b: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
  57bd6e: 89 56 0c                     	mov	dword ptr [esi + 0xc], edx
  57bd71: 89 47 0c                     	mov	dword ptr [edi + 0xc], eax
  57bd74: 5f                           	pop	edi
  57bd75: 5e                           	pop	esi
  57bd76: 5d                           	pop	ebp
  57bd77: c2 04 00                     	ret	0x4
  57bd7a: cc                           	int3
  57bd7b: cc                           	int3
  57bd7c: cc                           	int3
  57bd7d: cc                           	int3
  57bd7e: cc                           	int3
  57bd7f: cc                           	int3
  57bd80: 55                           	push	ebp
  57bd81: 8b ec                        	mov	ebp, esp
  57bd83: 83 ec 28                     	sub	esp, 0x28
  57bd86: 56                           	push	esi
  57bd87: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57bd8a: 50                           	push	eax
  57bd8b: 8b f1                        	mov	esi, ecx
  57bd8d: e8 ae 85 24 00               	call	0x7c4340 <.text+0x24a340>
  57bd92: 83 ec 0c                     	sub	esp, 0xc
  57bd95: 8b cc                        	mov	ecx, esp
  57bd97: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57bd9d: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57bda4: 8b 10                        	mov	edx, dword ptr [eax]
  57bda6: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57bda9: 85 d2                        	test	edx, edx
  57bdab: 74 0a                        	je	0x57bdb7 <.text+0x1db7>
  57bdad: 8b 12                        	mov	edx, dword ptr [edx]
  57bdaf: 85 d2                        	test	edx, edx
  57bdb1: 74 04                        	je	0x57bdb7 <.text+0x1db7>
  57bdb3: 8b 12                        	mov	edx, dword ptr [edx]
  57bdb5: 89 11                        	mov	dword ptr [ecx], edx
  57bdb7: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57bdba: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57bdbd: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  57bdc0: 51                           	push	ecx
  57bdc1: 8b ce                        	mov	ecx, esi
  57bdc3: e8 88 40 fe ff               	call	0x55fe50
  57bdc8: 83 ec 0c                     	sub	esp, 0xc
  57bdcb: 8b cc                        	mov	ecx, esp
  57bdcd: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57bdd3: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57bdda: 8b 10                        	mov	edx, dword ptr [eax]
  57bddc: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57bddf: 85 d2                        	test	edx, edx
  57bde1: 74 0a                        	je	0x57bded <.text+0x1ded>
  57bde3: 8b 12                        	mov	edx, dword ptr [edx]
  57bde5: 85 d2                        	test	edx, edx
  57bde7: 74 04                        	je	0x57bded <.text+0x1ded>
  57bde9: 8b 12                        	mov	edx, dword ptr [edx]
  57bdeb: 89 11                        	mov	dword ptr [ecx], edx
  57bded: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57bdf0: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57bdf3: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57bdf6: 51                           	push	ecx
  57bdf7: 8b ce                        	mov	ecx, esi
  57bdf9: e8 22 fa ff ff               	call	0x57b820 <.text+0x1820>
  57bdfe: 5e                           	pop	esi
  57bdff: 8b e5                        	mov	esp, ebp
  57be01: 5d                           	pop	ebp
  57be02: c3                           	ret
  57be03: cc                           	int3
  57be04: cc                           	int3
  57be05: cc                           	int3
  57be06: cc                           	int3
  57be07: cc                           	int3
  57be08: cc                           	int3
  57be09: cc                           	int3
  57be0a: cc                           	int3
  57be0b: cc                           	int3
  57be0c: cc                           	int3
  57be0d: cc                           	int3
  57be0e: cc                           	int3
  57be0f: cc                           	int3
  57be10: 55                           	push	ebp
  57be11: 8b ec                        	mov	ebp, esp
  57be13: 8b 45 18                     	mov	eax, dword ptr [ebp + 0x18]
  57be16: 56                           	push	esi
  57be17: 57                           	push	edi
  57be18: 50                           	push	eax
  57be19: 8b f1                        	mov	esi, ecx
  57be1b: e8 a0 f2 ff ff               	call	0x57b0c0 <.text+0x10c0>
  57be20: 50                           	push	eax
  57be21: 83 ec 0c                     	sub	esp, 0xc
  57be24: 8b c4                        	mov	eax, esp
  57be26: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  57be2c: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  57be33: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  57be36: 89 65 18                     	mov	dword ptr [ebp + 0x18], esp
  57be39: 85 c9                        	test	ecx, ecx
  57be3b: 74 0a                        	je	0x57be47 <.text+0x1e47>
  57be3d: 8b 09                        	mov	ecx, dword ptr [ecx]
  57be3f: 85 c9                        	test	ecx, ecx
  57be41: 74 04                        	je	0x57be47 <.text+0x1e47>
  57be43: 8b 09                        	mov	ecx, dword ptr [ecx]
  57be45: 89 08                        	mov	dword ptr [eax], ecx
  57be47: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  57be4a: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57be4d: 57                           	push	edi
  57be4e: 8b ce                        	mov	ecx, esi
  57be50: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  57be53: e8 b8 fb ff ff               	call	0x57ba10 <.text+0x1a10>
  57be58: 8b c7                        	mov	eax, edi
  57be5a: 5f                           	pop	edi
  57be5b: 5e                           	pop	esi
  57be5c: 5d                           	pop	ebp
  57be5d: c2 14 00                     	ret	0x14
  57be60: 55                           	push	ebp
  57be61: 8b ec                        	mov	ebp, esp
  57be63: 6a ff                        	push	-0x1
  57be65: 68 f0 d3 41 01               	push	0x141d3f0
  57be6a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57be70: 50                           	push	eax
  57be71: 83 ec 28                     	sub	esp, 0x28
  57be74: 53                           	push	ebx
  57be75: 56                           	push	esi
  57be76: 57                           	push	edi
  57be77: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57be7c: 33 c5                        	xor	eax, ebp
  57be7e: 50                           	push	eax
  57be7f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57be82: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57be88: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57be8b: 8b f1                        	mov	esi, ecx
  57be8d: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57be90: 33 ff                        	xor	edi, edi
  57be92: 6a 08                        	push	0x8
  57be94: 89 3e                        	mov	dword ptr [esi], edi
  57be96: e8 7f ac e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57be9b: 83 c4 04                     	add	esp, 0x4
  57be9e: 3b c7                        	cmp	eax, edi
  57bea0: 0f 84 a2 00 00 00            	je	0x57bf48 <.text+0x1f48>
  57bea6: 89 06                        	mov	dword ptr [esi], eax
  57bea8: 33 c9                        	xor	ecx, ecx
  57beaa: 33 d2                        	xor	edx, edx
  57beac: 89 08                        	mov	dword ptr [eax], ecx
  57beae: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57beb1: 8b 06                        	mov	eax, dword ptr [esi]
  57beb3: 89 30                        	mov	dword ptr [eax], esi
  57beb5: 6a 68                        	push	0x68
  57beb7: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57beba: 89 7e 0c                     	mov	dword ptr [esi + 0xc], edi
  57bebd: e8 58 ac e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57bec2: 83 c4 04                     	add	esp, 0x4
  57bec5: 3b c7                        	cmp	eax, edi
  57bec7: 74 5b                        	je	0x57bf24 <.text+0x1f24>
  57bec9: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57becc: 89 00                        	mov	dword ptr [eax], eax
  57bece: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bed1: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57bed4: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bed7: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57beda: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  57bedd: b8 01 00 00 00               	mov	eax, 0x1
  57bee2: 88 41 64                     	mov	byte ptr [ecx + 0x64], al
  57bee5: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57bee8: 88 42 65                     	mov	byte ptr [edx + 0x65], al
  57beeb: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57beee: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57bef1: 50                           	push	eax
  57bef2: 8b ce                        	mov	ecx, esi
  57bef4: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57bef8: e8 93 fd ff ff               	call	0x57bc90 <.text+0x1c90>
  57befd: 8b c6                        	mov	eax, esi
  57beff: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57bf02: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57bf09: 59                           	pop	ecx
  57bf0a: 5f                           	pop	edi
  57bf0b: 5e                           	pop	esi
  57bf0c: 5b                           	pop	ebx
  57bf0d: 8b e5                        	mov	esp, ebp
  57bf0f: 5d                           	pop	ebp
  57bf10: c2 04 00                     	ret	0x4
  57bf13: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57bf16: e8 65 fe ff ff               	call	0x57bd80 <.text+0x1d80>
  57bf1b: 33 ff                        	xor	edi, edi
  57bf1d: 57                           	push	edi
  57bf1e: 57                           	push	edi
  57bf1f: e8 76 ac e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57bf24: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
  57bf27: 51                           	push	ecx
  57bf28: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57bf2b: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
  57bf2e: e8 97 a5 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57bf33: 68 90 0f 91 01               	push	0x1910f90
  57bf38: 8d 55 d8                     	lea	edx, [ebp - 0x28]
  57bf3b: 52                           	push	edx
  57bf3c: c7 45 d8 84 20 56 01         	mov	dword ptr [ebp - 0x28], 0x1562084
  57bf43: e8 52 ac e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57bf48: 8d 45 e4                     	lea	eax, [ebp - 0x1c]
  57bf4b: 50                           	push	eax
  57bf4c: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  57bf4f: 89 7d e4                     	mov	dword ptr [ebp - 0x1c], edi
  57bf52: e8 73 a5 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57bf57: 68 90 0f 91 01               	push	0x1910f90
  57bf5c: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  57bf5f: 51                           	push	ecx
  57bf60: c7 45 cc 84 20 56 01         	mov	dword ptr [ebp - 0x34], 0x1562084
  57bf67: e8 2e ac e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57bf6c: cc                           	int3
  57bf6d: cc                           	int3
  57bf6e: cc                           	int3
  57bf6f: cc                           	int3
  57bf70: 55                           	push	ebp
  57bf71: 8b ec                        	mov	ebp, esp
  57bf73: 6a ff                        	push	-0x1
  57bf75: 68 30 1c 45 01               	push	0x1451c30
  57bf7a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57bf80: 50                           	push	eax
  57bf81: 83 ec 24                     	sub	esp, 0x24
  57bf84: 56                           	push	esi
  57bf85: 57                           	push	edi
  57bf86: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57bf8b: 33 c5                        	xor	eax, ebp
  57bf8d: 50                           	push	eax
  57bf8e: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57bf91: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57bf97: 8b f1                        	mov	esi, ecx
  57bf99: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57bf9c: 33 ff                        	xor	edi, edi
  57bf9e: 6a 08                        	push	0x8
  57bfa0: 89 3e                        	mov	dword ptr [esi], edi
  57bfa2: e8 73 ab e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57bfa7: 83 c4 04                     	add	esp, 0x4
  57bfaa: 3b c7                        	cmp	eax, edi
  57bfac: 0f 84 8c 00 00 00            	je	0x57c03e <.text+0x203e>
  57bfb2: 89 06                        	mov	dword ptr [esi], eax
  57bfb4: 33 c9                        	xor	ecx, ecx
  57bfb6: 33 d2                        	xor	edx, edx
  57bfb8: 89 08                        	mov	dword ptr [eax], ecx
  57bfba: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57bfbd: 8b 06                        	mov	eax, dword ptr [esi]
  57bfbf: 89 30                        	mov	dword ptr [eax], esi
  57bfc1: 6a 68                        	push	0x68
  57bfc3: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57bfc6: 89 7e 0c                     	mov	dword ptr [esi + 0xc], edi
  57bfc9: e8 4c ab e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57bfce: 83 c4 04                     	add	esp, 0x4
  57bfd1: 3b c7                        	cmp	eax, edi
  57bfd3: 74 45                        	je	0x57c01a <.text+0x201a>
  57bfd5: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57bfd8: 89 00                        	mov	dword ptr [eax], eax
  57bfda: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bfdd: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57bfe0: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57bfe3: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57bfe6: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  57bfe9: b8 01 00 00 00               	mov	eax, 0x1
  57bfee: 88 41 64                     	mov	byte ptr [ecx + 0x64], al
  57bff1: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57bff4: 88 42 65                     	mov	byte ptr [edx + 0x65], al
  57bff7: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57bffa: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57bffd: 50                           	push	eax
  57bffe: 8b ce                        	mov	ecx, esi
  57c000: e8 0b fd ff ff               	call	0x57bd10 <.text+0x1d10>
  57c005: 8b c6                        	mov	eax, esi
  57c007: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c00a: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c011: 59                           	pop	ecx
  57c012: 5f                           	pop	edi
  57c013: 5e                           	pop	esi
  57c014: 8b e5                        	mov	esp, ebp
  57c016: 5d                           	pop	ebp
  57c017: c2 04 00                     	ret	0x4
  57c01a: 8d 4d f0                     	lea	ecx, [ebp - 0x10]
  57c01d: 51                           	push	ecx
  57c01e: 8d 4d dc                     	lea	ecx, [ebp - 0x24]
  57c021: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57c024: e8 a1 a4 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57c029: 68 90 0f 91 01               	push	0x1910f90
  57c02e: 8d 55 dc                     	lea	edx, [ebp - 0x24]
  57c031: 52                           	push	edx
  57c032: c7 45 dc 84 20 56 01         	mov	dword ptr [ebp - 0x24], 0x1562084
  57c039: e8 5c ab e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57c03e: 8d 45 ec                     	lea	eax, [ebp - 0x14]
  57c041: 50                           	push	eax
  57c042: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57c045: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  57c048: e8 7d a4 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57c04d: 68 90 0f 91 01               	push	0x1910f90
  57c052: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57c055: 51                           	push	ecx
  57c056: c7 45 d0 84 20 56 01         	mov	dword ptr [ebp - 0x30], 0x1562084
  57c05d: e8 38 ab e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57c062: cc                           	int3
  57c063: cc                           	int3
  57c064: cc                           	int3
  57c065: cc                           	int3
  57c066: cc                           	int3
  57c067: cc                           	int3
  57c068: cc                           	int3
  57c069: cc                           	int3
  57c06a: cc                           	int3
  57c06b: cc                           	int3
  57c06c: cc                           	int3
  57c06d: cc                           	int3
  57c06e: cc                           	int3
  57c06f: cc                           	int3
  57c070: 55                           	push	ebp
  57c071: 8b ec                        	mov	ebp, esp
  57c073: 6a ff                        	push	-0x1
  57c075: 68 47 d4 41 01               	push	0x141d447
  57c07a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c080: 50                           	push	eax
  57c081: 81 ec dc 00 00 00            	sub	esp, 0xdc
  57c087: 53                           	push	ebx
  57c088: 56                           	push	esi
  57c089: 57                           	push	edi
  57c08a: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c08f: 33 c5                        	xor	eax, ebp
  57c091: 50                           	push	eax
  57c092: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c095: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c09b: 8b f9                        	mov	edi, ecx
  57c09d: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  57c0a0: c7 45 f0 00 00 00 00         	mov	dword ptr [ebp - 0x10], 0x0
  57c0a7: 8b 75 08                     	mov	esi, dword ptr [ebp + 0x8]
  57c0aa: 56                           	push	esi
  57c0ab: 8d 45 d4                     	lea	eax, [ebp - 0x2c]
  57c0ae: 50                           	push	eax
  57c0af: e8 fc 53 ff ff               	call	0x5714b0
  57c0b4: 8d 4d bc                     	lea	ecx, [ebp - 0x44]
  57c0b7: 51                           	push	ecx
  57c0b8: 8b cf                        	mov	ecx, edi
  57c0ba: e8 81 82 24 00               	call	0x7c4340 <.text+0x24a340>
  57c0bf: 8b 5d d4                     	mov	ebx, dword ptr [ebp - 0x2c]
  57c0c2: 85 db                        	test	ebx, ebx
  57c0c4: 0f 84 47 01 00 00            	je	0x57c211 <.text+0x2211>
  57c0ca: 8b 13                        	mov	edx, dword ptr [ebx]
  57c0cc: 85 d2                        	test	edx, edx
  57c0ce: 0f 84 3d 01 00 00            	je	0x57c211 <.text+0x2211>
  57c0d4: 8b 08                        	mov	ecx, dword ptr [eax]
  57c0d6: 85 c9                        	test	ecx, ecx
  57c0d8: 74 02                        	je	0x57c0dc <.text+0x20dc>
  57c0da: 8b 09                        	mov	ecx, dword ptr [ecx]
  57c0dc: 3b d1                        	cmp	edx, ecx
  57c0de: 0f 85 2d 01 00 00            	jne	0x57c211 <.text+0x2211>
  57c0e4: 8b 7d dc                     	mov	edi, dword ptr [ebp - 0x24]
  57c0e7: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
  57c0ea: 0f 94 c0                     	sete	al
  57c0ed: 84 c0                        	test	al, al
  57c0ef: 75 31                        	jne	0x57c122 <.text+0x2122>
  57c0f1: 8d 55 08                     	lea	edx, [ebp + 0x8]
  57c0f4: 52                           	push	edx
  57c0f5: 8d 46 08                     	lea	eax, [esi + 0x8]
  57c0f8: 50                           	push	eax
  57c0f9: 8b ce                        	mov	ecx, esi
  57c0fb: e8 e0 4c c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57c100: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  57c103: 89 4d e0                     	mov	dword ptr [ebp - 0x20], ecx
  57c106: 8d 55 f0                     	lea	edx, [ebp - 0x10]
  57c109: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  57c10c: 52                           	push	edx
  57c10d: 8d 41 08                     	lea	eax, [ecx + 0x8]
  57c110: 50                           	push	eax
  57c111: e8 ca 4c c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57c116: 8b 4d e0                     	mov	ecx, dword ptr [ebp - 0x20]
  57c119: 3b 4d f0                     	cmp	ecx, dword ptr [ebp - 0x10]
  57c11c: 0f 8d dc 00 00 00            	jge	0x57c1fe <.text+0x21fe>
  57c122: 8d 8d 18 ff ff ff            	lea	ecx, [ebp - 0xe8]
  57c128: e8 d3 be ff ff               	call	0x578000
  57c12d: 89 45 08                     	mov	dword ptr [ebp + 0x8], eax
  57c130: 8d 8d 64 ff ff ff            	lea	ecx, [ebp - 0x9c]
  57c136: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57c13d: e8 2e 63 c2 00               	call	0x11a2470 <.text+0xc28470>
  57c142: 8d 55 e4                     	lea	edx, [ebp - 0x1c]
  57c145: 52                           	push	edx
  57c146: 8d 46 08                     	lea	eax, [esi + 0x8]
  57c149: 50                           	push	eax
  57c14a: 8b ce                        	mov	ecx, esi
  57c14c: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57c150: e8 8b 4c c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57c155: 8b 4d e4                     	mov	ecx, dword ptr [ebp - 0x1c]
  57c158: 8d 95 6c ff ff ff            	lea	edx, [ebp - 0x94]
  57c15e: 52                           	push	edx
  57c15f: 8d 45 e8                     	lea	eax, [ebp - 0x18]
  57c162: 89 4d e8                     	mov	dword ptr [ebp - 0x18], ecx
  57c165: 50                           	push	eax
  57c166: 8d 8d 64 ff ff ff            	lea	ecx, [ebp - 0x9c]
  57c16c: e8 bf 47 c2 00               	call	0x11a0930 <.text+0xc26930>
  57c171: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  57c174: 51                           	push	ecx
  57c175: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
  57c17b: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57c17f: e8 ac b9 ff ff               	call	0x577b30
  57c184: 8d 95 64 ff ff ff            	lea	edx, [ebp - 0x9c]
  57c18a: 52                           	push	edx
  57c18b: 83 ec 0c                     	sub	esp, 0xc
  57c18e: 8b c4                        	mov	eax, esp
  57c190: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  57c196: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  57c19d: 8b 0b                        	mov	ecx, dword ptr [ebx]
  57c19f: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57c1a3: 89 65 08                     	mov	dword ptr [ebp + 0x8], esp
  57c1a6: 85 c9                        	test	ecx, ecx
  57c1a8: 74 04                        	je	0x57c1ae <.text+0x21ae>
  57c1aa: 8b 09                        	mov	ecx, dword ptr [ecx]
  57c1ac: 89 08                        	mov	dword ptr [eax], ecx
  57c1ae: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57c1b1: 8d 55 c8                     	lea	edx, [ebp - 0x38]
  57c1b4: 52                           	push	edx
  57c1b5: 89 78 08                     	mov	dword ptr [eax + 0x8], edi
  57c1b8: e8 53 fc ff ff               	call	0x57be10 <.text+0x1e10>
  57c1bd: 8b 08                        	mov	ecx, dword ptr [eax]
  57c1bf: 3b d9                        	cmp	ebx, ecx
  57c1c1: 74 08                        	je	0x57c1cb <.text+0x21cb>
  57c1c3: 8b 09                        	mov	ecx, dword ptr [ecx]
  57c1c5: 85 c9                        	test	ecx, ecx
  57c1c7: 74 02                        	je	0x57c1cb <.text+0x21cb>
  57c1c9: 8b 19                        	mov	ebx, dword ptr [ecx]
  57c1cb: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
  57c1ce: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
  57c1d4: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  57c1d8: e8 93 b8 ff ff               	call	0x577a70
  57c1dd: 8d 8d 64 ff ff ff            	lea	ecx, [ebp - 0x9c]
  57c1e3: c6 45 fc 00                  	mov	byte ptr [ebp - 0x4], 0x0
  57c1e7: e8 d4 4a c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57c1ec: 8d 8d 18 ff ff ff            	lea	ecx, [ebp - 0xe8]
  57c1f2: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57c1f9: e8 72 b8 ff ff               	call	0x577a70
  57c1fe: 85 db                        	test	ebx, ebx
  57c200: 74 0f                        	je	0x57c211 <.text+0x2211>
  57c202: 8b 1b                        	mov	ebx, dword ptr [ebx]
  57c204: 85 db                        	test	ebx, ebx
  57c206: 74 09                        	je	0x57c211 <.text+0x2211>
  57c208: 85 ff                        	test	edi, edi
  57c20a: 74 05                        	je	0x57c211 <.text+0x2211>
  57c20c: 3b 7b 08                     	cmp	edi, dword ptr [ebx + 0x8]
  57c20f: 75 05                        	jne	0x57c216 <.text+0x2216>
  57c211: e8 91 ab e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57c216: 8d 47 18                     	lea	eax, [edi + 0x18]
  57c219: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c21c: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c223: 59                           	pop	ecx
  57c224: 5f                           	pop	edi
  57c225: 5e                           	pop	esi
  57c226: 5b                           	pop	ebx
  57c227: 8b e5                        	mov	esp, ebp
  57c229: 5d                           	pop	ebp
  57c22a: c2 04 00                     	ret	0x4
  57c22d: cc                           	int3
  57c22e: cc                           	int3
  57c22f: cc                           	int3
  57c230: 55                           	push	ebp
  57c231: 8b ec                        	mov	ebp, esp
  57c233: 6a ff                        	push	-0x1
  57c235: 68 a8 e9 44 01               	push	0x144e9a8
  57c23a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c240: 50                           	push	eax
  57c241: 51                           	push	ecx
  57c242: 56                           	push	esi
  57c243: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c248: 33 c5                        	xor	eax, ebp
  57c24a: 50                           	push	eax
  57c24b: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c24e: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c254: 8b f1                        	mov	esi, ecx
  57c256: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  57c259: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57c260: e8 1b fb ff ff               	call	0x57bd80 <.text+0x1d80>
  57c265: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c268: 50                           	push	eax
  57c269: e8 b9 98 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c26e: 8b 0e                        	mov	ecx, dword ptr [esi]
  57c270: 51                           	push	ecx
  57c271: e8 b1 98 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c276: 83 c4 08                     	add	esp, 0x8
  57c279: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57c27f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c282: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c289: 59                           	pop	ecx
  57c28a: 5e                           	pop	esi
  57c28b: 8b e5                        	mov	esp, ebp
  57c28d: 5d                           	pop	ebp
  57c28e: c3                           	ret
  57c28f: cc                           	int3
  57c290: 55                           	push	ebp
  57c291: 8b ec                        	mov	ebp, esp
  57c293: 6a ff                        	push	-0x1
  57c295: 68 c8 db 4a 01               	push	0x14adbc8
  57c29a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c2a0: 50                           	push	eax
  57c2a1: 83 ec 24                     	sub	esp, 0x24
  57c2a4: 56                           	push	esi
  57c2a5: 57                           	push	edi
  57c2a6: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c2ab: 33 c5                        	xor	eax, ebp
  57c2ad: 50                           	push	eax
  57c2ae: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c2b1: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c2b7: 8b f1                        	mov	esi, ecx
  57c2b9: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57c2bc: 33 ff                        	xor	edi, edi
  57c2be: 6a 08                        	push	0x8
  57c2c0: 89 3e                        	mov	dword ptr [esi], edi
  57c2c2: e8 53 a8 e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57c2c7: 83 c4 04                     	add	esp, 0x4
  57c2ca: 3b c7                        	cmp	eax, edi
  57c2cc: 74 79                        	je	0x57c347 <.text+0x2347>
  57c2ce: 89 06                        	mov	dword ptr [esi], eax
  57c2d0: 33 c9                        	xor	ecx, ecx
  57c2d2: 33 d2                        	xor	edx, edx
  57c2d4: 89 08                        	mov	dword ptr [eax], ecx
  57c2d6: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57c2d9: 8b 06                        	mov	eax, dword ptr [esi]
  57c2db: 89 30                        	mov	dword ptr [eax], esi
  57c2dd: 6a 68                        	push	0x68
  57c2df: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57c2e2: 89 7e 0c                     	mov	dword ptr [esi + 0xc], edi
  57c2e5: e8 30 a8 e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57c2ea: 83 c4 04                     	add	esp, 0x4
  57c2ed: 3b c7                        	cmp	eax, edi
  57c2ef: 74 32                        	je	0x57c323 <.text+0x2323>
  57c2f1: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57c2f4: 89 00                        	mov	dword ptr [eax], eax
  57c2f6: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c2f9: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57c2fc: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c2ff: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57c302: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  57c305: b0 01                        	mov	al, 0x1
  57c307: 88 41 64                     	mov	byte ptr [ecx + 0x64], al
  57c30a: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57c30d: 88 42 65                     	mov	byte ptr [edx + 0x65], al
  57c310: 8b c6                        	mov	eax, esi
  57c312: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c315: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c31c: 59                           	pop	ecx
  57c31d: 5f                           	pop	edi
  57c31e: 5e                           	pop	esi
  57c31f: 8b e5                        	mov	esp, ebp
  57c321: 5d                           	pop	ebp
  57c322: c3                           	ret
  57c323: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57c326: 50                           	push	eax
  57c327: 8d 4d dc                     	lea	ecx, [ebp - 0x24]
  57c32a: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57c32d: e8 98 a1 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57c332: 68 90 0f 91 01               	push	0x1910f90
  57c337: 8d 4d dc                     	lea	ecx, [ebp - 0x24]
  57c33a: 51                           	push	ecx
  57c33b: c7 45 dc 84 20 56 01         	mov	dword ptr [ebp - 0x24], 0x1562084
  57c342: e8 53 a8 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57c347: 8d 55 ec                     	lea	edx, [ebp - 0x14]
  57c34a: 52                           	push	edx
  57c34b: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57c34e: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  57c351: e8 74 a1 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57c356: 68 90 0f 91 01               	push	0x1910f90
  57c35b: 8d 45 d0                     	lea	eax, [ebp - 0x30]
  57c35e: 50                           	push	eax
  57c35f: c7 45 d0 84 20 56 01         	mov	dword ptr [ebp - 0x30], 0x1562084
  57c366: e8 2f a8 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57c36b: cc                           	int3
  57c36c: cc                           	int3
  57c36d: cc                           	int3
  57c36e: cc                           	int3
  57c36f: cc                           	int3
  57c370: 55                           	push	ebp
  57c371: 8b ec                        	mov	ebp, esp
  57c373: 6a ff                        	push	-0x1
  57c375: 68 38 a9 42 01               	push	0x142a938
  57c37a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c380: 50                           	push	eax
  57c381: 51                           	push	ecx
  57c382: 53                           	push	ebx
  57c383: 56                           	push	esi
  57c384: 57                           	push	edi
  57c385: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c38a: 33 c5                        	xor	eax, ebp
  57c38c: 50                           	push	eax
  57c38d: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c390: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c396: 89 4d f0                     	mov	dword ptr [ebp - 0x10], ecx
  57c399: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
  57c39c: 80 7b 25 00                  	cmp	byte ptr [ebx + 0x25], 0x0
  57c3a0: 8b f3                        	mov	esi, ebx
  57c3a2: 75 51                        	jne	0x57c3f5 <.text+0x23f5>
  57c3a4: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c3a7: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c3aa: 50                           	push	eax
  57c3ab: e8 c0 ff ff ff               	call	0x57c370 <.text+0x2370>
  57c3b0: 8b 36                        	mov	esi, dword ptr [esi]
  57c3b2: 8d 7b 10                     	lea	edi, [ebx + 0x10]
  57c3b5: 89 7d 08                     	mov	dword ptr [ebp + 0x8], edi
  57c3b8: 8b cf                        	mov	ecx, edi
  57c3ba: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57c3c1: e8 9a ba ff ff               	call	0x577e60
  57c3c6: 8b 4f 08                     	mov	ecx, dword ptr [edi + 0x8]
  57c3c9: 51                           	push	ecx
  57c3ca: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57c3d1: e8 51 97 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c3d6: 8b 17                        	mov	edx, dword ptr [edi]
  57c3d8: 52                           	push	edx
  57c3d9: e8 49 97 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c3de: 53                           	push	ebx
  57c3df: c7 07 00 00 00 00            	mov	dword ptr [edi], 0x0
  57c3e5: e8 3d 97 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c3ea: 83 c4 0c                     	add	esp, 0xc
  57c3ed: 80 7e 25 00                  	cmp	byte ptr [esi + 0x25], 0x0
  57c3f1: 8b de                        	mov	ebx, esi
  57c3f3: 74 af                        	je	0x57c3a4 <.text+0x23a4>
  57c3f5: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c3f8: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c3ff: 59                           	pop	ecx
  57c400: 5f                           	pop	edi
  57c401: 5e                           	pop	esi
  57c402: 5b                           	pop	ebx
  57c403: 8b e5                        	mov	esp, ebp
  57c405: 5d                           	pop	ebp
  57c406: c2 04 00                     	ret	0x4
  57c409: cc                           	int3
  57c40a: cc                           	int3
  57c40b: cc                           	int3
  57c40c: cc                           	int3
  57c40d: cc                           	int3
  57c40e: cc                           	int3
  57c40f: cc                           	int3
  57c410: 55                           	push	ebp
  57c411: 8b ec                        	mov	ebp, esp
  57c413: 6a ff                        	push	-0x1
  57c415: 68 c8 cd 4b 01               	push	0x14bcdc8
  57c41a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c420: 50                           	push	eax
  57c421: 83 ec 0c                     	sub	esp, 0xc
  57c424: 53                           	push	ebx
  57c425: 56                           	push	esi
  57c426: 57                           	push	edi
  57c427: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c42c: 33 c5                        	xor	eax, ebp
  57c42e: 50                           	push	eax
  57c42f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c432: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c438: 89 4d f0                     	mov	dword ptr [ebp - 0x10], ecx
  57c43b: 8b 5d 14                     	mov	ebx, dword ptr [ebp + 0x14]
  57c43e: 80 7b 25 00                  	cmp	byte ptr [ebx + 0x25], 0x0
  57c442: 74 0a                        	je	0x57c44e <.text+0x244e>
  57c444: 68 a4 21 56 01               	push	0x15621a4
  57c449: e8 c9 53 e4 00               	call	0x13c1817 <.text+0xe47817>
  57c44e: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  57c451: 89 5d ec                     	mov	dword ptr [ebp - 0x14], ebx
  57c454: 85 c0                        	test	eax, eax
  57c456: 0f 84 75 02 00 00            	je	0x57c6d1 <.text+0x26d1>
  57c45c: 83 38 00                     	cmp	dword ptr [eax], 0x0
  57c45f: 0f 84 6c 02 00 00            	je	0x57c6d1 <.text+0x26d1>
  57c465: 8d 4d 0c                     	lea	ecx, [ebp + 0xc]
  57c468: e8 f3 e3 b5 00               	call	0x10da860 <.text+0xb60860>
  57c46d: 8b 13                        	mov	edx, dword ptr [ebx]
  57c46f: 80 7a 25 00                  	cmp	byte ptr [edx + 0x25], 0x0
  57c473: 74 05                        	je	0x57c47a <.text+0x247a>
  57c475: 8b 7b 08                     	mov	edi, dword ptr [ebx + 0x8]
  57c478: eb 17                        	jmp	0x57c491 <.text+0x2491>
  57c47a: 8b 43 08                     	mov	eax, dword ptr [ebx + 0x8]
  57c47d: 80 78 25 00                  	cmp	byte ptr [eax + 0x25], 0x0
  57c481: 74 04                        	je	0x57c487 <.text+0x2487>
  57c483: 8b fa                        	mov	edi, edx
  57c485: eb 0a                        	jmp	0x57c491 <.text+0x2491>
  57c487: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
  57c48a: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
  57c48d: 3b c3                        	cmp	eax, ebx
  57c48f: 75 72                        	jne	0x57c503 <.text+0x2503>
  57c491: 80 7f 25 00                  	cmp	byte ptr [edi + 0x25], 0x0
  57c495: 8b 73 04                     	mov	esi, dword ptr [ebx + 0x4]
  57c498: 75 03                        	jne	0x57c49d <.text+0x249d>
  57c49a: 89 77 04                     	mov	dword ptr [edi + 0x4], esi
  57c49d: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c4a0: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57c4a3: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
  57c4a6: 75 05                        	jne	0x57c4ad <.text+0x24ad>
  57c4a8: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  57c4ab: eb 0b                        	jmp	0x57c4b8 <.text+0x24b8>
  57c4ad: 39 1e                        	cmp	dword ptr [esi], ebx
  57c4af: 75 04                        	jne	0x57c4b5 <.text+0x24b5>
  57c4b1: 89 3e                        	mov	dword ptr [esi], edi
  57c4b3: eb 03                        	jmp	0x57c4b8 <.text+0x24b8>
  57c4b5: 89 7e 08                     	mov	dword ptr [esi + 0x8], edi
  57c4b8: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57c4bb: 39 18                        	cmp	dword ptr [eax], ebx
  57c4bd: 75 1b                        	jne	0x57c4da <.text+0x24da>
  57c4bf: 80 7f 25 00                  	cmp	byte ptr [edi + 0x25], 0x0
  57c4c3: 74 04                        	je	0x57c4c9 <.text+0x24c9>
  57c4c5: 8b c6                        	mov	eax, esi
  57c4c7: eb 0c                        	jmp	0x57c4d5 <.text+0x24d5>
  57c4c9: 57                           	push	edi
  57c4ca: e8 a1 17 3a 00               	call	0x91dc70 <.text+0x3a3c70>
  57c4cf: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c4d2: 83 c4 04                     	add	esp, 0x4
  57c4d5: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57c4d8: 89 02                        	mov	dword ptr [edx], eax
  57c4da: 8b 49 08                     	mov	ecx, dword ptr [ecx + 0x8]
  57c4dd: 89 4d e8                     	mov	dword ptr [ebp - 0x18], ecx
  57c4e0: 39 59 08                     	cmp	dword ptr [ecx + 0x8], ebx
  57c4e3: 75 78                        	jne	0x57c55d <.text+0x255d>
  57c4e5: 80 7f 25 00                  	cmp	byte ptr [edi + 0x25], 0x0
  57c4e9: 74 07                        	je	0x57c4f2 <.text+0x24f2>
  57c4eb: 8b c6                        	mov	eax, esi
  57c4ed: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57c4f0: eb 6b                        	jmp	0x57c55d <.text+0x255d>
  57c4f2: 57                           	push	edi
  57c4f3: e8 e8 7f b7 00               	call	0x10f44e0 <.text+0xb7a4e0>
  57c4f8: 8b 4d e8                     	mov	ecx, dword ptr [ebp - 0x18]
  57c4fb: 83 c4 04                     	add	esp, 0x4
  57c4fe: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57c501: eb 5a                        	jmp	0x57c55d <.text+0x255d>
  57c503: 89 42 04                     	mov	dword ptr [edx + 0x4], eax
  57c506: 8b 13                        	mov	edx, dword ptr [ebx]
  57c508: 89 10                        	mov	dword ptr [eax], edx
  57c50a: 3b 43 08                     	cmp	eax, dword ptr [ebx + 0x8]
  57c50d: 75 04                        	jne	0x57c513 <.text+0x2513>
  57c50f: 8b f0                        	mov	esi, eax
  57c511: eb 1a                        	jmp	0x57c52d <.text+0x252d>
  57c513: 80 7f 25 00                  	cmp	byte ptr [edi + 0x25], 0x0
  57c517: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
  57c51a: 75 03                        	jne	0x57c51f <.text+0x251f>
  57c51c: 89 77 04                     	mov	dword ptr [edi + 0x4], esi
  57c51f: 89 3e                        	mov	dword ptr [esi], edi
  57c521: 8b 53 08                     	mov	edx, dword ptr [ebx + 0x8]
  57c524: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  57c527: 8b 4b 08                     	mov	ecx, dword ptr [ebx + 0x8]
  57c52a: 89 41 04                     	mov	dword ptr [ecx + 0x4], eax
  57c52d: 8b 55 f0                     	mov	edx, dword ptr [ebp - 0x10]
  57c530: 8b 4a 08                     	mov	ecx, dword ptr [edx + 0x8]
  57c533: 39 59 04                     	cmp	dword ptr [ecx + 0x4], ebx
  57c536: 75 05                        	jne	0x57c53d <.text+0x253d>
  57c538: 89 41 04                     	mov	dword ptr [ecx + 0x4], eax
  57c53b: eb 0e                        	jmp	0x57c54b <.text+0x254b>
  57c53d: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
  57c540: 39 19                        	cmp	dword ptr [ecx], ebx
  57c542: 75 04                        	jne	0x57c548 <.text+0x2548>
  57c544: 89 01                        	mov	dword ptr [ecx], eax
  57c546: eb 03                        	jmp	0x57c54b <.text+0x254b>
  57c548: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57c54b: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
  57c54e: 89 48 04                     	mov	dword ptr [eax + 0x4], ecx
  57c551: 8a 53 24                     	mov	dl, byte ptr [ebx + 0x24]
  57c554: 8a 48 24                     	mov	cl, byte ptr [eax + 0x24]
  57c557: 88 50 24                     	mov	byte ptr [eax + 0x24], dl
  57c55a: 88 4b 24                     	mov	byte ptr [ebx + 0x24], cl
  57c55d: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  57c560: b3 01                        	mov	bl, 0x1
  57c562: 38 58 24                     	cmp	byte ptr [eax + 0x24], bl
  57c565: 0f 85 00 01 00 00            	jne	0x57c66b <.text+0x266b>
  57c56b: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c56e: 8b 51 08                     	mov	edx, dword ptr [ecx + 0x8]
  57c571: 3b 7a 04                     	cmp	edi, dword ptr [edx + 0x4]
  57c574: 0f 84 ee 00 00 00            	je	0x57c668 <.text+0x2668>
  57c57a: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
  57c580: 38 5f 24                     	cmp	byte ptr [edi + 0x24], bl
  57c583: 0f 85 df 00 00 00            	jne	0x57c668 <.text+0x2668>
  57c589: 8b 06                        	mov	eax, dword ptr [esi]
  57c58b: 3b f8                        	cmp	edi, eax
  57c58d: 75 65                        	jne	0x57c5f4 <.text+0x25f4>
  57c58f: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c592: 80 78 24 00                  	cmp	byte ptr [eax + 0x24], 0x0
  57c596: 75 13                        	jne	0x57c5ab <.text+0x25ab>
  57c598: 88 58 24                     	mov	byte ptr [eax + 0x24], bl
  57c59b: 56                           	push	esi
  57c59c: c6 46 24 00                  	mov	byte ptr [esi + 0x24], 0x0
  57c5a0: e8 eb 64 f8 ff               	call	0x502a90
  57c5a5: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c5a8: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c5ab: 80 78 25 00                  	cmp	byte ptr [eax + 0x25], 0x0
  57c5af: 75 74                        	jne	0x57c625 <.text+0x2625>
  57c5b1: 8b 10                        	mov	edx, dword ptr [eax]
  57c5b3: 38 5a 24                     	cmp	byte ptr [edx + 0x24], bl
  57c5b6: 75 08                        	jne	0x57c5c0 <.text+0x25c0>
  57c5b8: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57c5bb: 38 5a 24                     	cmp	byte ptr [edx + 0x24], bl
  57c5be: 74 61                        	je	0x57c621 <.text+0x2621>
  57c5c0: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57c5c3: 38 5a 24                     	cmp	byte ptr [edx + 0x24], bl
  57c5c6: 75 15                        	jne	0x57c5dd <.text+0x25dd>
  57c5c8: 8b 10                        	mov	edx, dword ptr [eax]
  57c5ca: 88 5a 24                     	mov	byte ptr [edx + 0x24], bl
  57c5cd: 50                           	push	eax
  57c5ce: c6 40 24 00                  	mov	byte ptr [eax + 0x24], 0x0
  57c5d2: e8 b9 c5 1e 00               	call	0x768b90 <.text+0x1eeb90>
  57c5d7: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c5da: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c5dd: 8a 56 24                     	mov	dl, byte ptr [esi + 0x24]
  57c5e0: 88 50 24                     	mov	byte ptr [eax + 0x24], dl
  57c5e3: 88 5e 24                     	mov	byte ptr [esi + 0x24], bl
  57c5e6: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57c5e9: 56                           	push	esi
  57c5ea: 88 58 24                     	mov	byte ptr [eax + 0x24], bl
  57c5ed: e8 9e 64 f8 ff               	call	0x502a90
  57c5f2: eb 74                        	jmp	0x57c668 <.text+0x2668>
  57c5f4: 80 78 24 00                  	cmp	byte ptr [eax + 0x24], 0x0
  57c5f8: 75 12                        	jne	0x57c60c <.text+0x260c>
  57c5fa: 88 58 24                     	mov	byte ptr [eax + 0x24], bl
  57c5fd: 56                           	push	esi
  57c5fe: c6 46 24 00                  	mov	byte ptr [esi + 0x24], 0x0
  57c602: e8 89 c5 1e 00               	call	0x768b90 <.text+0x1eeb90>
  57c607: 8b 06                        	mov	eax, dword ptr [esi]
  57c609: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c60c: 80 78 25 00                  	cmp	byte ptr [eax + 0x25], 0x0
  57c610: 75 13                        	jne	0x57c625 <.text+0x2625>
  57c612: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57c615: 38 5a 24                     	cmp	byte ptr [edx + 0x24], bl
  57c618: 75 1e                        	jne	0x57c638 <.text+0x2638>
  57c61a: 8b 10                        	mov	edx, dword ptr [eax]
  57c61c: 38 5a 24                     	cmp	byte ptr [edx + 0x24], bl
  57c61f: 75 17                        	jne	0x57c638 <.text+0x2638>
  57c621: c6 40 24 00                  	mov	byte ptr [eax + 0x24], 0x0
  57c625: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57c628: 8b fe                        	mov	edi, esi
  57c62a: 8b 76 04                     	mov	esi, dword ptr [esi + 0x4]
  57c62d: 3b 78 04                     	cmp	edi, dword ptr [eax + 0x4]
  57c630: 0f 85 4a ff ff ff            	jne	0x57c580 <.text+0x2580>
  57c636: eb 30                        	jmp	0x57c668 <.text+0x2668>
  57c638: 8b 10                        	mov	edx, dword ptr [eax]
  57c63a: 38 5a 24                     	cmp	byte ptr [edx + 0x24], bl
  57c63d: 75 15                        	jne	0x57c654 <.text+0x2654>
  57c63f: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57c642: 88 5a 24                     	mov	byte ptr [edx + 0x24], bl
  57c645: 50                           	push	eax
  57c646: c6 40 24 00                  	mov	byte ptr [eax + 0x24], 0x0
  57c64a: e8 41 64 f8 ff               	call	0x502a90
  57c64f: 8b 06                        	mov	eax, dword ptr [esi]
  57c651: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c654: 8a 56 24                     	mov	dl, byte ptr [esi + 0x24]
  57c657: 88 50 24                     	mov	byte ptr [eax + 0x24], dl
  57c65a: 88 5e 24                     	mov	byte ptr [esi + 0x24], bl
  57c65d: 8b 00                        	mov	eax, dword ptr [eax]
  57c65f: 56                           	push	esi
  57c660: 88 58 24                     	mov	byte ptr [eax + 0x24], bl
  57c663: e8 28 c5 1e 00               	call	0x768b90 <.text+0x1eeb90>
  57c668: 88 5f 24                     	mov	byte ptr [edi + 0x24], bl
  57c66b: 8b 75 ec                     	mov	esi, dword ptr [ebp - 0x14]
  57c66e: 83 c6 10                     	add	esi, 0x10
  57c671: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57c674: 33 ff                        	xor	edi, edi
  57c676: 8b ce                        	mov	ecx, esi
  57c678: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57c67b: e8 e0 b7 ff ff               	call	0x577e60
  57c680: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  57c683: 51                           	push	ecx
  57c684: e8 9e 94 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c689: 8b 16                        	mov	edx, dword ptr [esi]
  57c68b: 52                           	push	edx
  57c68c: e8 96 94 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c691: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  57c694: 50                           	push	eax
  57c695: 89 3e                        	mov	dword ptr [esi], edi
  57c697: e8 8b 94 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c69c: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57c69f: 8b 41 0c                     	mov	eax, dword ptr [ecx + 0xc]
  57c6a2: 83 c4 0c                     	add	esp, 0xc
  57c6a5: 3b c7                        	cmp	eax, edi
  57c6a7: 76 04                        	jbe	0x57c6ad <.text+0x26ad>
  57c6a9: 48                           	dec	eax
  57c6aa: 89 41 0c                     	mov	dword ptr [ecx + 0xc], eax
  57c6ad: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57c6b0: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  57c6b3: 8b 09                        	mov	ecx, dword ptr [ecx]
  57c6b5: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  57c6b8: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  57c6bb: 89 08                        	mov	dword ptr [eax], ecx
  57c6bd: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c6c0: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c6c7: 59                           	pop	ecx
  57c6c8: 5f                           	pop	edi
  57c6c9: 5e                           	pop	esi
  57c6ca: 5b                           	pop	ebx
  57c6cb: 8b e5                        	mov	esp, ebp
  57c6cd: 5d                           	pop	ebp
  57c6ce: c2 10 00                     	ret	0x10
  57c6d1: e8 d1 a6 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57c6d6: cc                           	int3
  57c6d7: cc                           	int3
  57c6d8: cc                           	int3
  57c6d9: cc                           	int3
  57c6da: cc                           	int3
  57c6db: cc                           	int3
  57c6dc: cc                           	int3
  57c6dd: cc                           	int3
  57c6de: cc                           	int3
  57c6df: cc                           	int3
  57c6e0: 55                           	push	ebp
  57c6e1: 8b ec                        	mov	ebp, esp
  57c6e3: 6a ff                        	push	-0x1
  57c6e5: 68 70 d4 41 01               	push	0x141d470
  57c6ea: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c6f0: 50                           	push	eax
  57c6f1: 83 ec 0c                     	sub	esp, 0xc
  57c6f4: 53                           	push	ebx
  57c6f5: 56                           	push	esi
  57c6f6: 57                           	push	edi
  57c6f7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c6fc: 33 c5                        	xor	eax, ebp
  57c6fe: 50                           	push	eax
  57c6ff: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c702: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c708: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57c70b: 8b d9                        	mov	ebx, ecx
  57c70d: 89 5d e8                     	mov	dword ptr [ebp - 0x18], ebx
  57c710: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57c713: 80 7f 25 00                  	cmp	byte ptr [edi + 0x25], 0x0
  57c717: 8b 43 08                     	mov	eax, dword ptr [ebx + 0x8]
  57c71a: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  57c71d: 75 48                        	jne	0x57c767 <.text+0x2767>
  57c71f: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  57c722: 51                           	push	ecx
  57c723: 8b cb                        	mov	ecx, ebx
  57c725: e8 16 f2 ff ff               	call	0x57b940 <.text+0x1940>
  57c72a: 8b 55 0c                     	mov	edx, dword ptr [ebp + 0xc]
  57c72d: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57c730: 8b f0                        	mov	esi, eax
  57c732: 89 56 04                     	mov	dword ptr [esi + 0x4], edx
  57c735: 8a 47 24                     	mov	al, byte ptr [edi + 0x24]
  57c738: 88 46 24                     	mov	byte ptr [esi + 0x24], al
  57c73b: 80 79 25 00                  	cmp	byte ptr [ecx + 0x25], 0x0
  57c73f: 74 03                        	je	0x57c744 <.text+0x2744>
  57c741: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57c744: 8b 17                        	mov	edx, dword ptr [edi]
  57c746: 56                           	push	esi
  57c747: 52                           	push	edx
  57c748: 8b cb                        	mov	ecx, ebx
  57c74a: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57c751: e8 8a ff ff ff               	call	0x57c6e0 <.text+0x26e0>
  57c756: 89 06                        	mov	dword ptr [esi], eax
  57c758: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  57c75b: 56                           	push	esi
  57c75c: 50                           	push	eax
  57c75d: 8b cb                        	mov	ecx, ebx
  57c75f: e8 7c ff ff ff               	call	0x57c6e0 <.text+0x26e0>
  57c764: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57c767: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  57c76a: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c76d: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c774: 59                           	pop	ecx
  57c775: 5f                           	pop	edi
  57c776: 5e                           	pop	esi
  57c777: 5b                           	pop	ebx
  57c778: 8b e5                        	mov	esp, ebp
  57c77a: 5d                           	pop	ebp
  57c77b: c2 08 00                     	ret	0x8
  57c77e: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57c781: 51                           	push	ecx
  57c782: 8b 4d e8                     	mov	ecx, dword ptr [ebp - 0x18]
  57c785: e8 e6 fb ff ff               	call	0x57c370 <.text+0x2370>
  57c78a: 6a 00                        	push	0x0
  57c78c: 6a 00                        	push	0x0
  57c78e: e8 07 a4 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57c793: cc                           	int3
  57c794: cc                           	int3
  57c795: cc                           	int3
  57c796: cc                           	int3
  57c797: cc                           	int3
  57c798: cc                           	int3
  57c799: cc                           	int3
  57c79a: cc                           	int3
  57c79b: cc                           	int3
  57c79c: cc                           	int3
  57c79d: cc                           	int3
  57c79e: cc                           	int3
  57c79f: cc                           	int3
  57c7a0: 55                           	push	ebp
  57c7a1: 8b ec                        	mov	ebp, esp
  57c7a3: 6a ff                        	push	-0x1
  57c7a5: 68 a0 d4 41 01               	push	0x141d4a0
  57c7aa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57c7b0: 50                           	push	eax
  57c7b1: 83 ec 08                     	sub	esp, 0x8
  57c7b4: 56                           	push	esi
  57c7b5: 57                           	push	edi
  57c7b6: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57c7bb: 33 c5                        	xor	eax, ebp
  57c7bd: 50                           	push	eax
  57c7be: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c7c1: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57c7c7: 8b f9                        	mov	edi, ecx
  57c7c9: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57c7cc: 8d 77 0c                     	lea	esi, [edi + 0xc]
  57c7cf: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57c7d6: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57c7d9: 8b ce                        	mov	ecx, esi
  57c7db: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57c7df: e8 9c f5 ff ff               	call	0x57bd80 <.text+0x1d80>
  57c7e4: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c7e7: 50                           	push	eax
  57c7e8: e8 3a 93 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c7ed: 8b 06                        	mov	eax, dword ptr [esi]
  57c7ef: 50                           	push	eax
  57c7f0: e8 32 93 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57c7f5: 83 c4 08                     	add	esp, 0x8
  57c7f8: 8b cf                        	mov	ecx, edi
  57c7fa: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57c800: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57c807: e8 b4 44 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57c80c: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57c80f: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57c816: 59                           	pop	ecx
  57c817: 5f                           	pop	edi
  57c818: 5e                           	pop	esi
  57c819: 8b e5                        	mov	esp, ebp
  57c81b: 5d                           	pop	ebp
  57c81c: c3                           	ret
  57c81d: cc                           	int3
  57c81e: cc                           	int3
  57c81f: cc                           	int3
  57c820: 55                           	push	ebp
  57c821: 8b ec                        	mov	ebp, esp
  57c823: 83 ec 1c                     	sub	esp, 0x1c
  57c826: 53                           	push	ebx
  57c827: 56                           	push	esi
  57c828: 57                           	push	edi
  57c829: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57c82c: 50                           	push	eax
  57c82d: 8b f1                        	mov	esi, ecx
  57c82f: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57c836: e8 15 36 fe ff               	call	0x55fe50
  57c83b: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57c83e: 85 db                        	test	ebx, ebx
  57c840: 0f 84 82 00 00 00            	je	0x57c8c8 <.text+0x28c8>
  57c846: 8b 13                        	mov	edx, dword ptr [ebx]
  57c848: 85 d2                        	test	edx, edx
  57c84a: 74 7c                        	je	0x57c8c8 <.text+0x28c8>
  57c84c: 8b 08                        	mov	ecx, dword ptr [eax]
  57c84e: 85 c9                        	test	ecx, ecx
  57c850: 74 02                        	je	0x57c854 <.text+0x2854>
  57c852: 8b 09                        	mov	ecx, dword ptr [ecx]
  57c854: 3b d1                        	cmp	edx, ecx
  57c856: 75 70                        	jne	0x57c8c8 <.text+0x28c8>
  57c858: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57c85b: 8b 7d 18                     	mov	edi, dword ptr [ebp + 0x18]
  57c85e: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57c861: 75 6d                        	jne	0x57c8d0 <.text+0x28d0>
  57c863: 8d 55 e4                     	lea	edx, [ebp - 0x1c]
  57c866: 52                           	push	edx
  57c867: 8b ce                        	mov	ecx, esi
  57c869: e8 d2 7a 24 00               	call	0x7c4340 <.text+0x24a340>
  57c86e: 85 ff                        	test	edi, edi
  57c870: 74 56                        	je	0x57c8c8 <.text+0x28c8>
  57c872: 8b 17                        	mov	edx, dword ptr [edi]
  57c874: 85 d2                        	test	edx, edx
  57c876: 74 50                        	je	0x57c8c8 <.text+0x28c8>
  57c878: 8b 08                        	mov	ecx, dword ptr [eax]
  57c87a: 85 c9                        	test	ecx, ecx
  57c87c: 74 02                        	je	0x57c880 <.text+0x2880>
  57c87e: 8b 09                        	mov	ecx, dword ptr [ecx]
  57c880: 3b d1                        	cmp	edx, ecx
  57c882: 75 44                        	jne	0x57c8c8 <.text+0x28c8>
  57c884: 8b 4d 20                     	mov	ecx, dword ptr [ebp + 0x20]
  57c887: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57c88a: 75 44                        	jne	0x57c8d0 <.text+0x28d0>
  57c88c: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57c88f: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57c892: 50                           	push	eax
  57c893: 8b ce                        	mov	ecx, esi
  57c895: e8 d6 fa ff ff               	call	0x57c370 <.text+0x2370>
  57c89a: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c89d: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57c8a0: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57c8a3: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c8a6: 89 00                        	mov	dword ptr [eax], eax
  57c8a8: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57c8ab: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57c8ae: 57                           	push	edi
  57c8af: 8b ce                        	mov	ecx, esi
  57c8b1: c7 46 0c 00 00 00 00         	mov	dword ptr [esi + 0xc], 0x0
  57c8b8: e8 93 35 fe ff               	call	0x55fe50
  57c8bd: 8b c7                        	mov	eax, edi
  57c8bf: 5f                           	pop	edi
  57c8c0: 5e                           	pop	esi
  57c8c1: 5b                           	pop	ebx
  57c8c2: 8b e5                        	mov	esp, ebp
  57c8c4: 5d                           	pop	ebp
  57c8c5: c2 1c 00                     	ret	0x1c
  57c8c8: e8 da a4 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57c8cd: 8d 49 00                     	lea	ecx, [ecx]
  57c8d0: 85 db                        	test	ebx, ebx
  57c8d2: 74 f4                        	je	0x57c8c8 <.text+0x28c8>
  57c8d4: 8b 0b                        	mov	ecx, dword ptr [ebx]
  57c8d6: 85 c9                        	test	ecx, ecx
  57c8d8: 74 ee                        	je	0x57c8c8 <.text+0x28c8>
  57c8da: 85 ff                        	test	edi, edi
  57c8dc: 75 04                        	jne	0x57c8e2 <.text+0x28e2>
  57c8de: 33 c0                        	xor	eax, eax
  57c8e0: eb 02                        	jmp	0x57c8e4 <.text+0x28e4>
  57c8e2: 8b 07                        	mov	eax, dword ptr [edi]
  57c8e4: 3b c8                        	cmp	ecx, eax
  57c8e6: 75 e0                        	jne	0x57c8c8 <.text+0x28c8>
  57c8e8: 8b 4d 14                     	mov	ecx, dword ptr [ebp + 0x14]
  57c8eb: 3b 4d 20                     	cmp	ecx, dword ptr [ebp + 0x20]
  57c8ee: 74 26                        	je	0x57c916 <.text+0x2916>
  57c8f0: 83 ec 0c                     	sub	esp, 0xc
  57c8f3: 8b cc                        	mov	ecx, esp
  57c8f5: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57c8f8: 6a 00                        	push	0x0
  57c8fa: 51                           	push	ecx
  57c8fb: 8d 4d 0c                     	lea	ecx, [ebp + 0xc]
  57c8fe: e8 bd 80 10 00               	call	0x6849c0 <.text+0x10a9c0>
  57c903: 8d 55 e4                     	lea	edx, [ebp - 0x1c]
  57c906: 52                           	push	edx
  57c907: 8b ce                        	mov	ecx, esi
  57c909: e8 02 fb ff ff               	call	0x57c410 <.text+0x2410>
  57c90e: 8b 7d 18                     	mov	edi, dword ptr [ebp + 0x18]
  57c911: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57c914: eb ba                        	jmp	0x57c8d0 <.text+0x28d0>
  57c916: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57c919: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  57c91f: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  57c926: 89 48 08                     	mov	dword ptr [eax + 0x8], ecx
  57c929: 85 f6                        	test	esi, esi
  57c92b: 74 04                        	je	0x57c931 <.text+0x2931>
  57c92d: 8b 0e                        	mov	ecx, dword ptr [esi]
  57c92f: 89 08                        	mov	dword ptr [eax], ecx
  57c931: 5f                           	pop	edi
  57c932: 5e                           	pop	esi
  57c933: 5b                           	pop	ebx
  57c934: 8b e5                        	mov	esp, ebp
  57c936: 5d                           	pop	ebp
  57c937: c2 1c 00                     	ret	0x1c
  57c93a: cc                           	int3
  57c93b: cc                           	int3
  57c93c: cc                           	int3
  57c93d: cc                           	int3
  57c93e: cc                           	int3
  57c93f: cc                           	int3
  57c940: 55                           	push	ebp
  57c941: 8b ec                        	mov	ebp, esp
  57c943: 53                           	push	ebx
  57c944: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
  57c947: 8b 43 08                     	mov	eax, dword ptr [ebx + 0x8]
  57c94a: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57c94d: 56                           	push	esi
  57c94e: 57                           	push	edi
  57c94f: 8b f1                        	mov	esi, ecx
  57c951: 8b 7e 08                     	mov	edi, dword ptr [esi + 0x8]
  57c954: 57                           	push	edi
  57c955: 50                           	push	eax
  57c956: e8 85 fd ff ff               	call	0x57c6e0 <.text+0x26e0>
  57c95b: 89 47 04                     	mov	dword ptr [edi + 0x4], eax
  57c95e: 8b 4b 0c                     	mov	ecx, dword ptr [ebx + 0xc]
  57c961: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57c964: 89 4e 0c                     	mov	dword ptr [esi + 0xc], ecx
  57c967: 8b 42 04                     	mov	eax, dword ptr [edx + 0x4]
  57c96a: 80 78 25 00                  	cmp	byte ptr [eax + 0x25], 0x0
  57c96e: 75 38                        	jne	0x57c9a8 <.text+0x29a8>
  57c970: 8b 08                        	mov	ecx, dword ptr [eax]
  57c972: 80 79 25 00                  	cmp	byte ptr [ecx + 0x25], 0x0
  57c976: 75 0a                        	jne	0x57c982 <.text+0x2982>
  57c978: 8b c1                        	mov	eax, ecx
  57c97a: 8b 08                        	mov	ecx, dword ptr [eax]
  57c97c: 80 79 25 00                  	cmp	byte ptr [ecx + 0x25], 0x0
  57c980: 74 f6                        	je	0x57c978 <.text+0x2978>
  57c982: 89 02                        	mov	dword ptr [edx], eax
  57c984: 8b 76 08                     	mov	esi, dword ptr [esi + 0x8]
  57c987: 8b 4e 04                     	mov	ecx, dword ptr [esi + 0x4]
  57c98a: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57c98d: 80 78 25 00                  	cmp	byte ptr [eax + 0x25], 0x0
  57c991: 75 0b                        	jne	0x57c99e <.text+0x299e>
  57c993: 8b c8                        	mov	ecx, eax
  57c995: 8b 41 08                     	mov	eax, dword ptr [ecx + 0x8]
  57c998: 80 78 25 00                  	cmp	byte ptr [eax + 0x25], 0x0
  57c99c: 74 f5                        	je	0x57c993 <.text+0x2993>
  57c99e: 5f                           	pop	edi
  57c99f: 89 4e 08                     	mov	dword ptr [esi + 0x8], ecx
  57c9a2: 5e                           	pop	esi
  57c9a3: 5b                           	pop	ebx
  57c9a4: 5d                           	pop	ebp
  57c9a5: c2 04 00                     	ret	0x4
  57c9a8: 89 12                        	mov	dword ptr [edx], edx
  57c9aa: 8b 76 08                     	mov	esi, dword ptr [esi + 0x8]
  57c9ad: 5f                           	pop	edi
  57c9ae: 89 76 08                     	mov	dword ptr [esi + 0x8], esi
  57c9b1: 5e                           	pop	esi
  57c9b2: 5b                           	pop	ebx
  57c9b3: 5d                           	pop	ebp
  57c9b4: c2 04 00                     	ret	0x4
  57c9b7: cc                           	int3
  57c9b8: cc                           	int3
  57c9b9: cc                           	int3
  57c9ba: cc                           	int3
  57c9bb: cc                           	int3
  57c9bc: cc                           	int3
  57c9bd: cc                           	int3
  57c9be: cc                           	int3
  57c9bf: cc                           	int3
  57c9c0: 55                           	push	ebp
  57c9c1: 8b ec                        	mov	ebp, esp
  57c9c3: 83 ec 24                     	sub	esp, 0x24
  57c9c6: 53                           	push	ebx
  57c9c7: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
  57c9ca: 56                           	push	esi
  57c9cb: 8b f1                        	mov	esi, ecx
  57c9cd: 3b f3                        	cmp	esi, ebx
  57c9cf: 74 7d                        	je	0x57ca4e <.text+0x2a4e>
  57c9d1: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57c9d4: 50                           	push	eax
  57c9d5: e8 66 79 24 00               	call	0x7c4340 <.text+0x24a340>
  57c9da: 83 ec 0c                     	sub	esp, 0xc
  57c9dd: 8b cc                        	mov	ecx, esp
  57c9df: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57c9e5: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57c9ec: 8b 10                        	mov	edx, dword ptr [eax]
  57c9ee: 89 65 08                     	mov	dword ptr [ebp + 0x8], esp
  57c9f1: 85 d2                        	test	edx, edx
  57c9f3: 74 0a                        	je	0x57c9ff <.text+0x29ff>
  57c9f5: 8b 12                        	mov	edx, dword ptr [edx]
  57c9f7: 85 d2                        	test	edx, edx
  57c9f9: 74 04                        	je	0x57c9ff <.text+0x29ff>
  57c9fb: 8b 12                        	mov	edx, dword ptr [edx]
  57c9fd: 89 11                        	mov	dword ptr [ecx], edx
  57c9ff: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57ca02: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57ca05: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
  57ca08: 51                           	push	ecx
  57ca09: 8b ce                        	mov	ecx, esi
  57ca0b: e8 40 34 fe ff               	call	0x55fe50
  57ca10: 83 ec 0c                     	sub	esp, 0xc
  57ca13: 8b cc                        	mov	ecx, esp
  57ca15: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57ca1b: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57ca22: 8b 10                        	mov	edx, dword ptr [eax]
  57ca24: 89 65 08                     	mov	dword ptr [ebp + 0x8], esp
  57ca27: 85 d2                        	test	edx, edx
  57ca29: 74 0a                        	je	0x57ca35 <.text+0x2a35>
  57ca2b: 8b 12                        	mov	edx, dword ptr [edx]
  57ca2d: 85 d2                        	test	edx, edx
  57ca2f: 74 04                        	je	0x57ca35 <.text+0x2a35>
  57ca31: 8b 12                        	mov	edx, dword ptr [edx]
  57ca33: 89 11                        	mov	dword ptr [ecx], edx
  57ca35: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57ca38: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57ca3b: 8d 4d dc                     	lea	ecx, [ebp - 0x24]
  57ca3e: 51                           	push	ecx
  57ca3f: 8b ce                        	mov	ecx, esi
  57ca41: e8 da fd ff ff               	call	0x57c820 <.text+0x2820>
  57ca46: 53                           	push	ebx
  57ca47: 8b ce                        	mov	ecx, esi
  57ca49: e8 f2 fe ff ff               	call	0x57c940 <.text+0x2940>
  57ca4e: 8b c6                        	mov	eax, esi
  57ca50: 5e                           	pop	esi
  57ca51: 5b                           	pop	ebx
  57ca52: 8b e5                        	mov	esp, ebp
  57ca54: 5d                           	pop	ebp
  57ca55: c2 04 00                     	ret	0x4
  57ca58: cc                           	int3
  57ca59: cc                           	int3
  57ca5a: cc                           	int3
  57ca5b: cc                           	int3
  57ca5c: cc                           	int3
  57ca5d: cc                           	int3
  57ca5e: cc                           	int3
  57ca5f: cc                           	int3
  57ca60: 55                           	push	ebp
  57ca61: 8b ec                        	mov	ebp, esp
  57ca63: 83 ec 28                     	sub	esp, 0x28
  57ca66: 56                           	push	esi
  57ca67: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57ca6a: 50                           	push	eax
  57ca6b: 8b f1                        	mov	esi, ecx
  57ca6d: e8 ce 78 24 00               	call	0x7c4340 <.text+0x24a340>
  57ca72: 83 ec 0c                     	sub	esp, 0xc
  57ca75: 8b cc                        	mov	ecx, esp
  57ca77: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57ca7d: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57ca84: 8b 10                        	mov	edx, dword ptr [eax]
  57ca86: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57ca89: 85 d2                        	test	edx, edx
  57ca8b: 74 0a                        	je	0x57ca97 <.text+0x2a97>
  57ca8d: 8b 12                        	mov	edx, dword ptr [edx]
  57ca8f: 85 d2                        	test	edx, edx
  57ca91: 74 04                        	je	0x57ca97 <.text+0x2a97>
  57ca93: 8b 12                        	mov	edx, dword ptr [edx]
  57ca95: 89 11                        	mov	dword ptr [ecx], edx
  57ca97: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57ca9a: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57ca9d: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  57caa0: 51                           	push	ecx
  57caa1: 8b ce                        	mov	ecx, esi
  57caa3: e8 a8 33 fe ff               	call	0x55fe50
  57caa8: 83 ec 0c                     	sub	esp, 0xc
  57caab: 8b cc                        	mov	ecx, esp
  57caad: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  57cab3: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  57caba: 8b 10                        	mov	edx, dword ptr [eax]
  57cabc: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  57cabf: 85 d2                        	test	edx, edx
  57cac1: 74 0a                        	je	0x57cacd <.text+0x2acd>
  57cac3: 8b 12                        	mov	edx, dword ptr [edx]
  57cac5: 85 d2                        	test	edx, edx
  57cac7: 74 04                        	je	0x57cacd <.text+0x2acd>
  57cac9: 8b 12                        	mov	edx, dword ptr [edx]
  57cacb: 89 11                        	mov	dword ptr [ecx], edx
  57cacd: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57cad0: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  57cad3: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57cad6: 51                           	push	ecx
  57cad7: 8b ce                        	mov	ecx, esi
  57cad9: e8 42 fd ff ff               	call	0x57c820 <.text+0x2820>
  57cade: 5e                           	pop	esi
  57cadf: 8b e5                        	mov	esp, ebp
  57cae1: 5d                           	pop	ebp
  57cae2: c3                           	ret
  57cae3: cc                           	int3
  57cae4: cc                           	int3
  57cae5: cc                           	int3
  57cae6: cc                           	int3
  57cae7: cc                           	int3
  57cae8: cc                           	int3
  57cae9: cc                           	int3
  57caea: cc                           	int3
  57caeb: cc                           	int3
  57caec: cc                           	int3
  57caed: cc                           	int3
  57caee: cc                           	int3
  57caef: cc                           	int3
  57caf0: 55                           	push	ebp
  57caf1: 8b ec                        	mov	ebp, esp
  57caf3: 6a ff                        	push	-0x1
  57caf5: 68 09 d5 41 01               	push	0x141d509
  57cafa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57cb00: 50                           	push	eax
  57cb01: 83 ec 28                     	sub	esp, 0x28
  57cb04: 56                           	push	esi
  57cb05: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57cb0a: 33 c5                        	xor	eax, ebp
  57cb0c: 50                           	push	eax
  57cb0d: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57cb10: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57cb16: 8b 45 10                     	mov	eax, dword ptr [ebp + 0x10]
  57cb19: 50                           	push	eax
  57cb1a: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  57cb1d: c7 45 ec 00 00 00 00         	mov	dword ptr [ebp - 0x14], 0x0
  57cb24: e8 37 f3 ff ff               	call	0x57be60 <.text+0x1e60>
  57cb29: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57cb2c: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
  57cb33: e8 38 59 c2 00               	call	0x11a2470 <.text+0xc28470>
  57cb38: 8d 4d 0c                     	lea	ecx, [ebp + 0xc]
  57cb3b: 51                           	push	ecx
  57cb3c: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  57cb3f: 8d 51 08                     	lea	edx, [ecx + 0x8]
  57cb42: 52                           	push	edx
  57cb43: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57cb47: e8 94 42 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57cb4c: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  57cb4f: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
  57cb52: 51                           	push	ecx
  57cb53: 8d 55 f0                     	lea	edx, [ebp - 0x10]
  57cb56: 52                           	push	edx
  57cb57: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57cb5a: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  57cb5d: e8 ce 3d c2 00               	call	0x11a0930 <.text+0xc26930>
  57cb62: 8b 75 08                     	mov	esi, dword ptr [ebp + 0x8]
  57cb65: 8b ce                        	mov	ecx, esi
  57cb67: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57cb6b: e8 00 59 c2 00               	call	0x11a2470 <.text+0xc28470>
  57cb70: 8d 45 0c                     	lea	eax, [ebp + 0xc]
  57cb73: 50                           	push	eax
  57cb74: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
  57cb77: 51                           	push	ecx
  57cb78: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57cb7b: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  57cb7f: e8 5c 42 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57cb84: 8b 55 0c                     	mov	edx, dword ptr [ebp + 0xc]
  57cb87: 8d 46 08                     	lea	eax, [esi + 0x8]
  57cb8a: 50                           	push	eax
  57cb8b: 8d 4d f0                     	lea	ecx, [ebp - 0x10]
  57cb8e: 51                           	push	ecx
  57cb8f: 8b ce                        	mov	ecx, esi
  57cb91: 89 55 f0                     	mov	dword ptr [ebp - 0x10], edx
  57cb94: e8 97 3d c2 00               	call	0x11a0930 <.text+0xc26930>
  57cb99: 8d 55 cc                     	lea	edx, [ebp - 0x34]
  57cb9c: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57cb9f: 52                           	push	edx
  57cba0: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
  57cba4: e8 c7 f3 ff ff               	call	0x57bf70 <.text+0x1f70>
  57cba9: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57cbac: c7 45 ec 01 00 00 00         	mov	dword ptr [ebp - 0x14], 0x1
  57cbb3: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57cbb7: e8 04 41 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57cbbc: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  57cbbf: c7 45 fc 06 00 00 00         	mov	dword ptr [ebp - 0x4], 0x6
  57cbc6: e8 b5 f1 ff ff               	call	0x57bd80 <.text+0x1d80>
  57cbcb: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
  57cbce: 50                           	push	eax
  57cbcf: e8 53 8f e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57cbd4: 8b 4d cc                     	mov	ecx, dword ptr [ebp - 0x34]
  57cbd7: 51                           	push	ecx
  57cbd8: e8 4a 8f e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57cbdd: 83 c4 08                     	add	esp, 0x8
  57cbe0: 8b c6                        	mov	eax, esi
  57cbe2: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57cbe5: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57cbec: 59                           	pop	ecx
  57cbed: 5e                           	pop	esi
  57cbee: 8b e5                        	mov	esp, ebp
  57cbf0: 5d                           	pop	ebp
  57cbf1: c3                           	ret
  57cbf2: cc                           	int3
  57cbf3: cc                           	int3
  57cbf4: cc                           	int3
  57cbf5: cc                           	int3
  57cbf6: cc                           	int3
  57cbf7: cc                           	int3
  57cbf8: cc                           	int3
  57cbf9: cc                           	int3
  57cbfa: cc                           	int3
  57cbfb: cc                           	int3
  57cbfc: cc                           	int3
  57cbfd: cc                           	int3
  57cbfe: cc                           	int3
  57cbff: cc                           	int3
  57cc00: 55                           	push	ebp
  57cc01: 8b ec                        	mov	ebp, esp
  57cc03: 6a ff                        	push	-0x1
  57cc05: 68 51 d5 41 01               	push	0x141d551
  57cc0a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57cc10: 50                           	push	eax
  57cc11: 83 ec 0c                     	sub	esp, 0xc
  57cc14: 56                           	push	esi
  57cc15: 57                           	push	edi
  57cc16: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57cc1b: 33 c5                        	xor	eax, ebp
  57cc1d: 50                           	push	eax
  57cc1e: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57cc21: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57cc27: 8b 75 0c                     	mov	esi, dword ptr [ebp + 0xc]
  57cc2a: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57cc2d: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57cc34: 85 f6                        	test	esi, esi
  57cc36: 74 42                        	je	0x57cc7a <.text+0x2c7a>
  57cc38: 8b ce                        	mov	ecx, esi
  57cc3a: e8 31 58 c2 00               	call	0x11a2470 <.text+0xc28470>
  57cc3f: 8b 7d 10                     	mov	edi, dword ptr [ebp + 0x10]
  57cc42: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  57cc45: 50                           	push	eax
  57cc46: 8d 4f 08                     	lea	ecx, [edi + 0x8]
  57cc49: 51                           	push	ecx
  57cc4a: 8b cf                        	mov	ecx, edi
  57cc4c: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57cc50: e8 8b 41 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57cc55: 8b 55 f0                     	mov	edx, dword ptr [ebp - 0x10]
  57cc58: 8d 46 08                     	lea	eax, [esi + 0x8]
  57cc5b: 50                           	push	eax
  57cc5c: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57cc5f: 51                           	push	ecx
  57cc60: 8b ce                        	mov	ecx, esi
  57cc62: 89 55 ec                     	mov	dword ptr [ebp - 0x14], edx
  57cc65: e8 c6 3c c2 00               	call	0x11a0930 <.text+0xc26930>
  57cc6a: 83 c7 0c                     	add	edi, 0xc
  57cc6d: 57                           	push	edi
  57cc6e: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57cc71: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57cc75: e8 f6 f2 ff ff               	call	0x57bf70 <.text+0x1f70>
  57cc7a: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57cc7d: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57cc84: 59                           	pop	ecx
  57cc85: 5f                           	pop	edi
  57cc86: 5e                           	pop	esi
  57cc87: 8b e5                        	mov	esp, ebp
  57cc89: 5d                           	pop	ebp
  57cc8a: c3                           	ret
  57cc8b: cc                           	int3
  57cc8c: cc                           	int3
  57cc8d: cc                           	int3
  57cc8e: cc                           	int3
  57cc8f: cc                           	int3
  57cc90: 55                           	push	ebp
  57cc91: 8b ec                        	mov	ebp, esp
  57cc93: 6a ff                        	push	-0x1
  57cc95: 68 80 d5 41 01               	push	0x141d580
  57cc9a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57cca0: 50                           	push	eax
  57cca1: 83 ec 28                     	sub	esp, 0x28
  57cca4: 53                           	push	ebx
  57cca5: 56                           	push	esi
  57cca6: 57                           	push	edi
  57cca7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57ccac: 33 c5                        	xor	eax, ebp
  57ccae: 50                           	push	eax
  57ccaf: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57ccb2: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57ccb8: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57ccbb: 8b f1                        	mov	esi, ecx
  57ccbd: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57ccc0: 33 ff                        	xor	edi, edi
  57ccc2: 6a 08                        	push	0x8
  57ccc4: 89 3e                        	mov	dword ptr [esi], edi
  57ccc6: e8 4f 9e e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57cccb: 83 c4 04                     	add	esp, 0x4
  57ccce: 3b c7                        	cmp	eax, edi
  57ccd0: 0f 84 a2 00 00 00            	je	0x57cd78 <.text+0x2d78>
  57ccd6: 89 06                        	mov	dword ptr [esi], eax
  57ccd8: 33 c9                        	xor	ecx, ecx
  57ccda: 33 d2                        	xor	edx, edx
  57ccdc: 89 08                        	mov	dword ptr [eax], ecx
  57ccde: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57cce1: 8b 06                        	mov	eax, dword ptr [esi]
  57cce3: 89 30                        	mov	dword ptr [eax], esi
  57cce5: 6a 28                        	push	0x28
  57cce7: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57ccea: 89 7e 0c                     	mov	dword ptr [esi + 0xc], edi
  57cced: e8 28 9e e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57ccf2: 83 c4 04                     	add	esp, 0x4
  57ccf5: 3b c7                        	cmp	eax, edi
  57ccf7: 74 5b                        	je	0x57cd54 <.text+0x2d54>
  57ccf9: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  57ccfc: 89 00                        	mov	dword ptr [eax], eax
  57ccfe: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57cd01: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57cd04: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57cd07: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57cd0a: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  57cd0d: b8 01 00 00 00               	mov	eax, 0x1
  57cd12: 88 41 24                     	mov	byte ptr [ecx + 0x24], al
  57cd15: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  57cd18: 88 42 25                     	mov	byte ptr [edx + 0x25], al
  57cd1b: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57cd1e: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57cd21: 50                           	push	eax
  57cd22: 8b ce                        	mov	ecx, esi
  57cd24: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57cd28: e8 13 fc ff ff               	call	0x57c940 <.text+0x2940>
  57cd2d: 8b c6                        	mov	eax, esi
  57cd2f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57cd32: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57cd39: 59                           	pop	ecx
  57cd3a: 5f                           	pop	edi
  57cd3b: 5e                           	pop	esi
  57cd3c: 5b                           	pop	ebx
  57cd3d: 8b e5                        	mov	esp, ebp
  57cd3f: 5d                           	pop	ebp
  57cd40: c2 04 00                     	ret	0x4
  57cd43: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  57cd46: e8 15 fd ff ff               	call	0x57ca60 <.text+0x2a60>
  57cd4b: 33 ff                        	xor	edi, edi
  57cd4d: 57                           	push	edi
  57cd4e: 57                           	push	edi
  57cd4f: e8 46 9e e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57cd54: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
  57cd57: 51                           	push	ecx
  57cd58: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  57cd5b: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
  57cd5e: e8 67 97 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57cd63: 68 90 0f 91 01               	push	0x1910f90
  57cd68: 8d 55 d8                     	lea	edx, [ebp - 0x28]
  57cd6b: 52                           	push	edx
  57cd6c: c7 45 d8 84 20 56 01         	mov	dword ptr [ebp - 0x28], 0x1562084
  57cd73: e8 22 9e e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57cd78: 8d 45 e4                     	lea	eax, [ebp - 0x1c]
  57cd7b: 50                           	push	eax
  57cd7c: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  57cd7f: 89 7d e4                     	mov	dword ptr [ebp - 0x1c], edi
  57cd82: e8 43 97 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57cd87: 68 90 0f 91 01               	push	0x1910f90
  57cd8c: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  57cd8f: 51                           	push	ecx
  57cd90: c7 45 cc 84 20 56 01         	mov	dword ptr [ebp - 0x34], 0x1562084
  57cd97: e8 fe 9d e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57cd9c: cc                           	int3
  57cd9d: cc                           	int3
  57cd9e: cc                           	int3
  57cd9f: cc                           	int3
  57cda0: 55                           	push	ebp
  57cda1: 8b ec                        	mov	ebp, esp
  57cda3: 6a ff                        	push	-0x1
  57cda5: 68 a8 e9 44 01               	push	0x144e9a8
  57cdaa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57cdb0: 50                           	push	eax
  57cdb1: 51                           	push	ecx
  57cdb2: 56                           	push	esi
  57cdb3: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57cdb8: 33 c5                        	xor	eax, ebp
  57cdba: 50                           	push	eax
  57cdbb: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57cdbe: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57cdc4: 8b f1                        	mov	esi, ecx
  57cdc6: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  57cdc9: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57cdd0: e8 8b fc ff ff               	call	0x57ca60 <.text+0x2a60>
  57cdd5: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57cdd8: 50                           	push	eax
  57cdd9: e8 49 8d e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57cdde: 8b 0e                        	mov	ecx, dword ptr [esi]
  57cde0: 51                           	push	ecx
  57cde1: e8 41 8d e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57cde6: 83 c4 08                     	add	esp, 0x8
  57cde9: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57cdef: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57cdf2: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57cdf9: 59                           	pop	ecx
  57cdfa: 5e                           	pop	esi
  57cdfb: 8b e5                        	mov	esp, ebp
  57cdfd: 5d                           	pop	ebp
  57cdfe: c3                           	ret
  57cdff: cc                           	int3
  57ce00: 55                           	push	ebp
  57ce01: 8b ec                        	mov	ebp, esp
  57ce03: 6a ff                        	push	-0x1
  57ce05: 68 be d5 41 01               	push	0x141d5be
  57ce0a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57ce10: 50                           	push	eax
  57ce11: 83 ec 08                     	sub	esp, 0x8
  57ce14: 53                           	push	ebx
  57ce15: 56                           	push	esi
  57ce16: 57                           	push	edi
  57ce17: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57ce1c: 33 c5                        	xor	eax, ebp
  57ce1e: 50                           	push	eax
  57ce1f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57ce22: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57ce28: 8b f1                        	mov	esi, ecx
  57ce2a: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  57ce2d: 33 db                        	xor	ebx, ebx
  57ce2f: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  57ce32: 8d 7e 40                     	lea	edi, [esi + 0x40]
  57ce35: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  57ce38: 8b cf                        	mov	ecx, edi
  57ce3a: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57ce3e: e8 1d fc ff ff               	call	0x57ca60 <.text+0x2a60>
  57ce43: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  57ce46: 50                           	push	eax
  57ce47: e8 db 8c e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ce4c: 8b 0f                        	mov	ecx, dword ptr [edi]
  57ce4e: 51                           	push	ecx
  57ce4f: e8 d3 8c e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ce54: 89 1f                        	mov	dword ptr [edi], ebx
  57ce56: 8b 46 30                     	mov	eax, dword ptr [esi + 0x30]
  57ce59: 83 c4 08                     	add	esp, 0x8
  57ce5c: 3b c3                        	cmp	eax, ebx
  57ce5e: 74 09                        	je	0x57ce69 <.text+0x2e69>
  57ce60: 50                           	push	eax
  57ce61: e8 c1 8c e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ce66: 83 c4 04                     	add	esp, 0x4
  57ce69: 8b 56 2c                     	mov	edx, dword ptr [esi + 0x2c]
  57ce6c: 52                           	push	edx
  57ce6d: 89 5e 30                     	mov	dword ptr [esi + 0x30], ebx
  57ce70: 89 5e 34                     	mov	dword ptr [esi + 0x34], ebx
  57ce73: 89 5e 38                     	mov	dword ptr [esi + 0x38], ebx
  57ce76: e8 ac 8c e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ce7b: 83 c4 04                     	add	esp, 0x4
  57ce7e: 89 5e 2c                     	mov	dword ptr [esi + 0x2c], ebx
  57ce81: 83 7e 24 08                  	cmp	dword ptr [esi + 0x24], 0x8
  57ce85: 72 0c                        	jb	0x57ce93 <.text+0x2e93>
  57ce87: 8b 46 10                     	mov	eax, dword ptr [esi + 0x10]
  57ce8a: 50                           	push	eax
  57ce8b: e8 97 8c e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ce90: 83 c4 04                     	add	esp, 0x4
  57ce93: 33 c9                        	xor	ecx, ecx
  57ce95: c7 46 24 07 00 00 00         	mov	dword ptr [esi + 0x24], 0x7
  57ce9c: 89 5e 20                     	mov	dword ptr [esi + 0x20], ebx
  57ce9f: 66 89 4e 10                  	mov	word ptr [esi + 0x10], cx
  57cea3: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
  57cea6: 52                           	push	edx
  57cea7: e8 7b 8c e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57ceac: 83 c4 04                     	add	esp, 0x4
  57ceaf: 89 5e 0c                     	mov	dword ptr [esi + 0xc], ebx
  57ceb2: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57ceb5: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57cebc: 59                           	pop	ecx
  57cebd: 5f                           	pop	edi
  57cebe: 5e                           	pop	esi
  57cebf: 5b                           	pop	ebx
  57cec0: 8b e5                        	mov	esp, ebp
  57cec2: 5d                           	pop	ebp
  57cec3: c3                           	ret
  57cec4: cc                           	int3
  57cec5: cc                           	int3
  57cec6: cc                           	int3
  57cec7: cc                           	int3
  57cec8: cc                           	int3
  57cec9: cc                           	int3
  57ceca: cc                           	int3
  57cecb: cc                           	int3
  57cecc: cc                           	int3
  57cecd: cc                           	int3
  57cece: cc                           	int3
  57cecf: cc                           	int3
  57ced0: 55                           	push	ebp
  57ced1: 8b ec                        	mov	ebp, esp
  57ced3: 56                           	push	esi
  57ced4: 57                           	push	edi
  57ced5: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57ced8: 8b 07                        	mov	eax, dword ptr [edi]
  57ceda: 8b f1                        	mov	esi, ecx
  57cedc: 89 06                        	mov	dword ptr [esi], eax
  57cede: 8b 4f 04                     	mov	ecx, dword ptr [edi + 0x4]
  57cee1: 6a ff                        	push	-0x1
  57cee3: 89 4e 04                     	mov	dword ptr [esi + 0x4], ecx
  57cee6: 8a 57 08                     	mov	dl, byte ptr [edi + 0x8]
  57cee9: 6a 00                        	push	0x0
  57ceeb: 8d 47 0c                     	lea	eax, [edi + 0xc]
  57ceee: 50                           	push	eax
  57ceef: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57cef2: 88 56 08                     	mov	byte ptr [esi + 0x8], dl
  57cef5: e8 36 84 e8 ff               	call	0x405330
  57cefa: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
  57cefd: 51                           	push	ecx
  57cefe: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
  57cf01: e8 1a 1d 05 00               	call	0x5cec20 <.text+0x54c20>
  57cf06: 83 c7 40                     	add	edi, 0x40
  57cf09: 57                           	push	edi
  57cf0a: 8d 4e 40                     	lea	ecx, [esi + 0x40]
  57cf0d: e8 ae fa ff ff               	call	0x57c9c0 <.text+0x29c0>
  57cf12: 5f                           	pop	edi
  57cf13: 8b c6                        	mov	eax, esi
  57cf15: 5e                           	pop	esi
  57cf16: 5d                           	pop	ebp
  57cf17: c2 04 00                     	ret	0x4
  57cf1a: cc                           	int3
  57cf1b: cc                           	int3
  57cf1c: cc                           	int3
  57cf1d: cc                           	int3
  57cf1e: cc                           	int3
  57cf1f: cc                           	int3
  57cf20: 55                           	push	ebp
  57cf21: 8b ec                        	mov	ebp, esp
  57cf23: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57cf26: 53                           	push	ebx
  57cf27: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57cf2a: 3b c3                        	cmp	eax, ebx
  57cf2c: 74 54                        	je	0x57cf82 <.text+0x2f82>
  57cf2e: 56                           	push	esi
  57cf2f: 57                           	push	edi
  57cf30: 8b 7d 10                     	mov	edi, dword ptr [ebp + 0x10]
  57cf33: 8d 70 08                     	lea	esi, [eax + 0x8]
  57cf36: 8b 46 f8                     	mov	eax, dword ptr [esi - 0x8]
  57cf39: 89 07                        	mov	dword ptr [edi], eax
  57cf3b: 8b 4e fc                     	mov	ecx, dword ptr [esi - 0x4]
  57cf3e: 6a ff                        	push	-0x1
  57cf40: 89 4f 04                     	mov	dword ptr [edi + 0x4], ecx
  57cf43: 8a 16                        	mov	dl, byte ptr [esi]
  57cf45: 6a 00                        	push	0x0
  57cf47: 8d 46 04                     	lea	eax, [esi + 0x4]
  57cf4a: 50                           	push	eax
  57cf4b: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  57cf4e: 88 57 08                     	mov	byte ptr [edi + 0x8], dl
  57cf51: e8 da 83 e8 ff               	call	0x405330
  57cf56: 8d 4e 24                     	lea	ecx, [esi + 0x24]
  57cf59: 51                           	push	ecx
  57cf5a: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
  57cf5d: e8 be 1c 05 00               	call	0x5cec20 <.text+0x54c20>
  57cf62: 8d 56 38                     	lea	edx, [esi + 0x38]
  57cf65: 52                           	push	edx
  57cf66: 8d 4f 40                     	lea	ecx, [edi + 0x40]
  57cf69: e8 52 fa ff ff               	call	0x57c9c0 <.text+0x29c0>
  57cf6e: 83 c6 54                     	add	esi, 0x54
  57cf71: 8d 46 f8                     	lea	eax, [esi - 0x8]
  57cf74: 83 c7 54                     	add	edi, 0x54
  57cf77: 3b c3                        	cmp	eax, ebx
  57cf79: 75 bb                        	jne	0x57cf36 <.text+0x2f36>
  57cf7b: 8b c7                        	mov	eax, edi
  57cf7d: 5f                           	pop	edi
  57cf7e: 5e                           	pop	esi
  57cf7f: 5b                           	pop	ebx
  57cf80: 5d                           	pop	ebp
  57cf81: c3                           	ret
  57cf82: 8b 45 10                     	mov	eax, dword ptr [ebp + 0x10]
  57cf85: 5b                           	pop	ebx
  57cf86: 5d                           	pop	ebp
  57cf87: c3                           	ret
  57cf88: cc                           	int3
  57cf89: cc                           	int3
  57cf8a: cc                           	int3
  57cf8b: cc                           	int3
  57cf8c: cc                           	int3
  57cf8d: cc                           	int3
  57cf8e: cc                           	int3
  57cf8f: cc                           	int3
  57cf90: 55                           	push	ebp
  57cf91: 8b ec                        	mov	ebp, esp
  57cf93: 6a ff                        	push	-0x1
  57cf95: 68 f0 d5 41 01               	push	0x141d5f0
  57cf9a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57cfa0: 50                           	push	eax
  57cfa1: 51                           	push	ecx
  57cfa2: 56                           	push	esi
  57cfa3: 57                           	push	edi
  57cfa4: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57cfa9: 33 c5                        	xor	eax, ebp
  57cfab: 50                           	push	eax
  57cfac: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57cfaf: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57cfb5: 8b 7d 0c                     	mov	edi, dword ptr [ebp + 0xc]
  57cfb8: 8d 77 0c                     	lea	esi, [edi + 0xc]
  57cfbb: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57cfc2: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  57cfc5: 8b ce                        	mov	ecx, esi
  57cfc7: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57cfcb: e8 b0 ed ff ff               	call	0x57bd80 <.text+0x1d80>
  57cfd0: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57cfd3: 50                           	push	eax
  57cfd4: e8 4e 8b e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57cfd9: 8b 06                        	mov	eax, dword ptr [esi]
  57cfdb: 50                           	push	eax
  57cfdc: e8 46 8b e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57cfe1: 83 c4 08                     	add	esp, 0x8
  57cfe4: 8b cf                        	mov	ecx, edi
  57cfe6: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57cfec: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57cff3: e8 c8 3c c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57cff8: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57cffb: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57d002: 59                           	pop	ecx
  57d003: 5f                           	pop	edi
  57d004: 5e                           	pop	esi
  57d005: 8b e5                        	mov	esp, ebp
  57d007: 5d                           	pop	ebp
  57d008: c3                           	ret
  57d009: cc                           	int3
  57d00a: cc                           	int3
  57d00b: cc                           	int3
  57d00c: cc                           	int3
  57d00d: cc                           	int3
  57d00e: cc                           	int3
  57d00f: cc                           	int3
  57d010: 55                           	push	ebp
  57d011: 8b ec                        	mov	ebp, esp
  57d013: 6a ff                        	push	-0x1
  57d015: 68 2e d6 41 01               	push	0x141d62e
  57d01a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57d020: 50                           	push	eax
  57d021: 83 ec 14                     	sub	esp, 0x14
  57d024: 53                           	push	ebx
  57d025: 56                           	push	esi
  57d026: 57                           	push	edi
  57d027: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57d02c: 33 c5                        	xor	eax, ebp
  57d02e: 50                           	push	eax
  57d02f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57d032: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57d038: 8b f9                        	mov	edi, ecx
  57d03a: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57d03d: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
  57d040: 8b 03                        	mov	eax, dword ptr [ebx]
  57d042: 89 07                        	mov	dword ptr [edi], eax
  57d044: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
  57d047: 89 4f 04                     	mov	dword ptr [edi + 0x4], ecx
  57d04a: 8a 53 08                     	mov	dl, byte ptr [ebx + 0x8]
  57d04d: 8d 77 0c                     	lea	esi, [edi + 0xc]
  57d050: 88 57 08                     	mov	byte ptr [edi + 0x8], dl
  57d053: 6a 08                        	push	0x8
  57d055: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57d058: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57d05e: e8 b7 9a e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57d063: 33 c9                        	xor	ecx, ecx
  57d065: 83 c4 04                     	add	esp, 0x4
  57d068: 3b c1                        	cmp	eax, ecx
  57d06a: 74 67                        	je	0x57d0d3 <.text+0x30d3>
  57d06c: 89 06                        	mov	dword ptr [esi], eax
  57d06e: 33 d2                        	xor	edx, edx
  57d070: 89 08                        	mov	dword ptr [eax], ecx
  57d072: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57d075: 8b 06                        	mov	eax, dword ptr [esi]
  57d077: 89 30                        	mov	dword ptr [eax], esi
  57d079: 33 c0                        	xor	eax, eax
  57d07b: 6a ff                        	push	-0x1
  57d07d: c7 46 18 07 00 00 00         	mov	dword ptr [esi + 0x18], 0x7
  57d084: 89 46 14                     	mov	dword ptr [esi + 0x14], eax
  57d087: 50                           	push	eax
  57d088: 8d 53 0c                     	lea	edx, [ebx + 0xc]
  57d08b: 66 89 4e 04                  	mov	word ptr [esi + 0x4], cx
  57d08f: 52                           	push	edx
  57d090: 8b ce                        	mov	ecx, esi
  57d092: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  57d095: e8 96 82 e8 ff               	call	0x405330
  57d09a: 8d 43 2c                     	lea	eax, [ebx + 0x2c]
  57d09d: 50                           	push	eax
  57d09e: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
  57d0a1: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
  57d0a8: e8 53 18 12 00               	call	0x69e900 <.text+0x124900>
  57d0ad: 83 c3 40                     	add	ebx, 0x40
  57d0b0: 53                           	push	ebx
  57d0b1: 8d 4f 40                     	lea	ecx, [edi + 0x40]
  57d0b4: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57d0b8: e8 d3 fb ff ff               	call	0x57cc90 <.text+0x2c90>
  57d0bd: 8b c7                        	mov	eax, edi
  57d0bf: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57d0c2: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57d0c9: 59                           	pop	ecx
  57d0ca: 5f                           	pop	edi
  57d0cb: 5e                           	pop	esi
  57d0cc: 5b                           	pop	ebx
  57d0cd: 8b e5                        	mov	esp, ebp
  57d0cf: 5d                           	pop	ebp
  57d0d0: c2 04 00                     	ret	0x4
  57d0d3: 89 4d 08                     	mov	dword ptr [ebp + 0x8], ecx
  57d0d6: 8d 4d 08                     	lea	ecx, [ebp + 0x8]
  57d0d9: 51                           	push	ecx
  57d0da: 8d 4d e0                     	lea	ecx, [ebp - 0x20]
  57d0dd: e8 e8 93 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57d0e2: 68 90 0f 91 01               	push	0x1910f90
  57d0e7: 8d 55 e0                     	lea	edx, [ebp - 0x20]
  57d0ea: 52                           	push	edx
  57d0eb: c7 45 e0 84 20 56 01         	mov	dword ptr [ebp - 0x20], 0x1562084
  57d0f2: e8 a3 9a e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57d0f7: cc                           	int3
  57d0f8: cc                           	int3
  57d0f9: cc                           	int3
  57d0fa: cc                           	int3
  57d0fb: cc                           	int3
  57d0fc: cc                           	int3
  57d0fd: cc                           	int3
  57d0fe: cc                           	int3
  57d0ff: cc                           	int3
  57d100: 55                           	push	ebp
  57d101: 8b ec                        	mov	ebp, esp
  57d103: 6a ff                        	push	-0x1
  57d105: 68 71 d6 41 01               	push	0x141d671
  57d10a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57d110: 50                           	push	eax
  57d111: 83 ec 24                     	sub	esp, 0x24
  57d114: 53                           	push	ebx
  57d115: 56                           	push	esi
  57d116: 57                           	push	edi
  57d117: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57d11c: 33 c5                        	xor	eax, ebp
  57d11e: 50                           	push	eax
  57d11f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57d122: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57d128: 8b d9                        	mov	ebx, ecx
  57d12a: 89 5d e8                     	mov	dword ptr [ebp - 0x18], ebx
  57d12d: 8d 73 0c                     	lea	esi, [ebx + 0xc]
  57d130: 33 ff                        	xor	edi, edi
  57d132: 6a 08                        	push	0x8
  57d134: 89 3e                        	mov	dword ptr [esi], edi
  57d136: e8 df 99 e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57d13b: 83 c4 04                     	add	esp, 0x4
  57d13e: 3b c7                        	cmp	eax, edi
  57d140: 0f 84 c6 00 00 00            	je	0x57d20c <.text+0x320c>
  57d146: 89 06                        	mov	dword ptr [esi], eax
  57d148: 33 c9                        	xor	ecx, ecx
  57d14a: 89 08                        	mov	dword ptr [eax], ecx
  57d14c: 33 d2                        	xor	edx, edx
  57d14e: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57d151: 8b 06                        	mov	eax, dword ptr [esi]
  57d153: 89 30                        	mov	dword ptr [eax], esi
  57d155: c7 46 18 07 00 00 00         	mov	dword ptr [esi + 0x18], 0x7
  57d15c: 89 7e 14                     	mov	dword ptr [esi + 0x14], edi
  57d15f: 66 89 4e 04                  	mov	word ptr [esi + 0x4], cx
  57d163: 8d 73 2c                     	lea	esi, [ebx + 0x2c]
  57d166: 6a 08                        	push	0x8
  57d168: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57d16b: 89 3e                        	mov	dword ptr [esi], edi
  57d16d: e8 a8 99 e5 00               	call	0x13d6b1a <.text+0xe5cb1a>
  57d172: 83 c4 04                     	add	esp, 0x4
  57d175: 3b c7                        	cmp	eax, edi
  57d177: 74 6f                        	je	0x57d1e8 <.text+0x31e8>
  57d179: 89 06                        	mov	dword ptr [esi], eax
  57d17b: 33 d2                        	xor	edx, edx
  57d17d: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  57d180: 33 c9                        	xor	ecx, ecx
  57d182: 89 08                        	mov	dword ptr [eax], ecx
  57d184: 8b 16                        	mov	edx, dword ptr [esi]
  57d186: 89 32                        	mov	dword ptr [edx], esi
  57d188: 89 7e 04                     	mov	dword ptr [esi + 0x4], edi
  57d18b: 89 7e 08                     	mov	dword ptr [esi + 0x8], edi
  57d18e: 89 7e 0c                     	mov	dword ptr [esi + 0xc], edi
  57d191: 8d 4b 40                     	lea	ecx, [ebx + 0x40]
  57d194: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57d198: e8 03 e7 24 00               	call	0x7cb8a0 <.text+0x2518a0>
  57d19d: 8b ce                        	mov	ecx, esi
  57d19f: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57d1a3: 89 3b                        	mov	dword ptr [ebx], edi
  57d1a5: 89 7b 04                     	mov	dword ptr [ebx + 0x4], edi
  57d1a8: c6 43 08 01                  	mov	byte ptr [ebx + 0x8], 0x1
  57d1ac: e8 9f c3 e0 00               	call	0x1389550 <.text+0xe0f550>
  57d1b1: 8b 43 48                     	mov	eax, dword ptr [ebx + 0x48]
  57d1b4: 8b 48 04                     	mov	ecx, dword ptr [eax + 0x4]
  57d1b7: 51                           	push	ecx
  57d1b8: 8d 4b 40                     	lea	ecx, [ebx + 0x40]
  57d1bb: e8 b0 f1 ff ff               	call	0x57c370 <.text+0x2370>
  57d1c0: 8b 43 48                     	mov	eax, dword ptr [ebx + 0x48]
  57d1c3: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  57d1c6: 8b 43 48                     	mov	eax, dword ptr [ebx + 0x48]
  57d1c9: 89 00                        	mov	dword ptr [eax], eax
  57d1cb: 8b 43 48                     	mov	eax, dword ptr [ebx + 0x48]
  57d1ce: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  57d1d1: 89 7b 4c                     	mov	dword ptr [ebx + 0x4c], edi
  57d1d4: 8b c3                        	mov	eax, ebx
  57d1d6: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57d1d9: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57d1e0: 59                           	pop	ecx
  57d1e1: 5f                           	pop	edi
  57d1e2: 5e                           	pop	esi
  57d1e3: 5b                           	pop	ebx
  57d1e4: 8b e5                        	mov	esp, ebp
  57d1e6: 5d                           	pop	ebp
  57d1e7: c3                           	ret
  57d1e8: 8d 55 f0                     	lea	edx, [ebp - 0x10]
  57d1eb: 52                           	push	edx
  57d1ec: 8d 4d dc                     	lea	ecx, [ebp - 0x24]
  57d1ef: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
  57d1f2: e8 d3 92 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57d1f7: 68 90 0f 91 01               	push	0x1910f90
  57d1fc: 8d 45 dc                     	lea	eax, [ebp - 0x24]
  57d1ff: 50                           	push	eax
  57d200: c7 45 dc 84 20 56 01         	mov	dword ptr [ebp - 0x24], 0x1562084
  57d207: e8 8e 99 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57d20c: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57d20f: 51                           	push	ecx
  57d210: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57d213: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  57d216: e8 af 92 e5 00               	call	0x13d64ca <.text+0xe5c4ca>
  57d21b: 68 90 0f 91 01               	push	0x1910f90
  57d220: 8d 55 d0                     	lea	edx, [ebp - 0x30]
  57d223: 52                           	push	edx
  57d224: c7 45 d0 84 20 56 01         	mov	dword ptr [ebp - 0x30], 0x1562084
  57d22b: e8 6a 99 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57d230: cc                           	int3
  57d231: cc                           	int3
  57d232: cc                           	int3
  57d233: cc                           	int3
  57d234: cc                           	int3
  57d235: cc                           	int3
  57d236: cc                           	int3
  57d237: cc                           	int3
  57d238: cc                           	int3
  57d239: cc                           	int3
  57d23a: cc                           	int3
  57d23b: cc                           	int3
  57d23c: cc                           	int3
  57d23d: cc                           	int3
  57d23e: cc                           	int3
  57d23f: cc                           	int3
  57d240: 55                           	push	ebp
  57d241: 8b ec                        	mov	ebp, esp
  57d243: 6a ff                        	push	-0x1
  57d245: 68 a0 d6 41 01               	push	0x141d6a0
  57d24a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57d250: 50                           	push	eax
  57d251: 53                           	push	ebx
  57d252: 56                           	push	esi
  57d253: 57                           	push	edi
  57d254: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57d259: 33 c5                        	xor	eax, ebp
  57d25b: 50                           	push	eax
  57d25c: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57d25f: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57d265: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57d268: 8b 5d 0c                     	mov	ebx, dword ptr [ebp + 0xc]
  57d26b: 3b fb                        	cmp	edi, ebx
  57d26d: 74 4b                        	je	0x57d2ba <.text+0x32ba>
  57d26f: 90                           	nop
  57d270: 8d 77 0c                     	lea	esi, [edi + 0xc]
  57d273: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57d27a: 89 75 0c                     	mov	dword ptr [ebp + 0xc], esi
  57d27d: 8b ce                        	mov	ecx, esi
  57d27f: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57d283: e8 f8 ea ff ff               	call	0x57bd80 <.text+0x1d80>
  57d288: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57d28b: 50                           	push	eax
  57d28c: e8 96 88 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57d291: 8b 06                        	mov	eax, dword ptr [esi]
  57d293: 50                           	push	eax
  57d294: e8 8e 88 e5 00               	call	0x13d5b27 <.text+0xe5bb27>
  57d299: 83 c4 08                     	add	esp, 0x8
  57d29c: 8b cf                        	mov	ecx, edi
  57d29e: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57d2a4: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57d2ab: e8 10 3a c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57d2b0: 83 c7 20                     	add	edi, 0x20
  57d2b3: 89 7d 08                     	mov	dword ptr [ebp + 0x8], edi
  57d2b6: 3b fb                        	cmp	edi, ebx
  57d2b8: 75 b6                        	jne	0x57d270 <.text+0x3270>
  57d2ba: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57d2bd: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57d2c4: 59                           	pop	ecx
  57d2c5: 5f                           	pop	edi
  57d2c6: 5e                           	pop	esi
  57d2c7: 5b                           	pop	ebx
  57d2c8: 8b e5                        	mov	esp, ebp
  57d2ca: 5d                           	pop	ebp
  57d2cb: c3                           	ret
  57d2cc: cc                           	int3
  57d2cd: cc                           	int3
  57d2ce: cc                           	int3
  57d2cf: cc                           	int3
  57d2d0: 55                           	push	ebp
  57d2d1: 8b ec                        	mov	ebp, esp
  57d2d3: 6a ff                        	push	-0x1
  57d2d5: 68 e1 d6 41 01               	push	0x141d6e1
  57d2da: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57d2e0: 50                           	push	eax
  57d2e1: 83 ec 10                     	sub	esp, 0x10
  57d2e4: 53                           	push	ebx
  57d2e5: 56                           	push	esi
  57d2e6: 57                           	push	edi
  57d2e7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57d2ec: 33 c5                        	xor	eax, ebp
  57d2ee: 50                           	push	eax
  57d2ef: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57d2f2: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57d2f8: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57d2fb: 8b 75 10                     	mov	esi, dword ptr [ebp + 0x10]
  57d2fe: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57d301: 33 db                        	xor	ebx, ebx
  57d303: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
  57d306: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  57d309: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  57d310: 3b 7d 0c                     	cmp	edi, dword ptr [ebp + 0xc]
  57d313: 0f 84 81 00 00 00            	je	0x57d39a <.text+0x339a>
  57d319: 89 75 e4                     	mov	dword ptr [ebp - 0x1c], esi
  57d31c: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57d320: 3b f3                        	cmp	esi, ebx
  57d322: 74 3f                        	je	0x57d363 <.text+0x3363>
  57d324: 8b ce                        	mov	ecx, esi
  57d326: e8 45 51 c2 00               	call	0x11a2470 <.text+0xc28470>
  57d32b: 8d 45 08                     	lea	eax, [ebp + 0x8]
  57d32e: 50                           	push	eax
  57d32f: 8d 4f 08                     	lea	ecx, [edi + 0x8]
  57d332: 51                           	push	ecx
  57d333: 8b cf                        	mov	ecx, edi
  57d335: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57d339: e8 a2 3a c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57d33e: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
  57d341: 8d 46 08                     	lea	eax, [esi + 0x8]
  57d344: 50                           	push	eax
  57d345: 8d 4d ec                     	lea	ecx, [ebp - 0x14]
  57d348: 51                           	push	ecx
  57d349: 8b ce                        	mov	ecx, esi
  57d34b: 89 55 ec                     	mov	dword ptr [ebp - 0x14], edx
  57d34e: e8 dd 35 c2 00               	call	0x11a0930 <.text+0xc26930>
  57d353: 8d 57 0c                     	lea	edx, [edi + 0xc]
  57d356: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  57d359: 52                           	push	edx
  57d35a: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57d35e: e8 0d ec ff ff               	call	0x57bf70 <.text+0x1f70>
  57d363: 83 c6 20                     	add	esi, 0x20
  57d366: 88 5d fc                     	mov	byte ptr [ebp - 0x4], bl
  57d369: 89 75 10                     	mov	dword ptr [ebp + 0x10], esi
  57d36c: 83 c7 20                     	add	edi, 0x20
  57d36f: eb 9f                        	jmp	0x57d310 <.text+0x3310>
  57d371: 8b 75 e8                     	mov	esi, dword ptr [ebp - 0x18]
  57d374: 8b 7d 10                     	mov	edi, dword ptr [ebp + 0x10]
  57d377: 3b f7                        	cmp	esi, edi
  57d379: 74 16                        	je	0x57d391 <.text+0x3391>
  57d37b: 8b 5d 14                     	mov	ebx, dword ptr [ebp + 0x14]
  57d37e: 8b ff                        	mov	edi, edi
  57d380: 56                           	push	esi
  57d381: 53                           	push	ebx
  57d382: e8 09 fc ff ff               	call	0x57cf90 <.text+0x2f90>
  57d387: 83 c6 20                     	add	esi, 0x20
  57d38a: 83 c4 08                     	add	esp, 0x8
  57d38d: 3b f7                        	cmp	esi, edi
  57d38f: 75 ef                        	jne	0x57d380 <.text+0x3380>
  57d391: 33 db                        	xor	ebx, ebx
  57d393: 53                           	push	ebx
  57d394: 53                           	push	ebx
  57d395: e8 00 98 e5 00               	call	0x13d6b9a <.text+0xe5cb9a>
  57d39a: 8b c6                        	mov	eax, esi
  57d39c: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57d39f: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57d3a6: 59                           	pop	ecx
  57d3a7: 5f                           	pop	edi
  57d3a8: 5e                           	pop	esi
  57d3a9: 5b                           	pop	ebx
  57d3aa: 8b e5                        	mov	esp, ebp
  57d3ac: 5d                           	pop	ebp
  57d3ad: c3                           	ret
  57d3ae: cc                           	int3
  57d3af: cc                           	int3
  57d3b0: 55                           	push	ebp
  57d3b1: 8b ec                        	mov	ebp, esp
  57d3b3: 6a ff                        	push	-0x1
  57d3b5: 68 d8 d7 41 01               	push	0x141d7d8
  57d3ba: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57d3c0: 50                           	push	eax
  57d3c1: 81 ec e4 03 00 00            	sub	esp, 0x3e4
  57d3c7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57d3cc: 33 c5                        	xor	eax, ebp
  57d3ce: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  57d3d1: 53                           	push	ebx
  57d3d2: 56                           	push	esi
  57d3d3: 57                           	push	edi
  57d3d4: 50                           	push	eax
  57d3d5: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57d3d8: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57d3de: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57d3e1: 8b 75 0c                     	mov	esi, dword ptr [ebp + 0xc]
  57d3e4: 33 db                        	xor	ebx, ebx
  57d3e6: 8b f9                        	mov	edi, ecx
  57d3e8: 89 85 e0 fc ff ff            	mov	dword ptr [ebp - 0x320], eax
  57d3ee: 89 9d fc fc ff ff            	mov	dword ptr [ebp - 0x304], ebx
  57d3f4: 8b 87 34 02 00 00            	mov	eax, dword ptr [edi + 0x234]
  57d3fa: 89 bd cc fc ff ff            	mov	dword ptr [ebp - 0x334], edi
  57d400: 89 b5 f8 fc ff ff            	mov	dword ptr [ebp - 0x308], esi
  57d406: 3b c3                        	cmp	eax, ebx
  57d408: 0f 84 47 08 00 00            	je	0x57dc55 <.text+0x3c55>
  57d40e: 53                           	push	ebx
  57d40f: 68 38 d8 9d 01               	push	0x19dd838
  57d414: 68 74 91 9d 01               	push	0x19d9174
  57d419: 53                           	push	ebx
  57d41a: 50                           	push	eax
  57d41b: e8 bf a2 e5 00               	call	0x13d76df <.text+0xe5d6df>
  57d420: 83 c4 14                     	add	esp, 0x14
  57d423: 3b c3                        	cmp	eax, ebx
  57d425: 0f 84 2a 08 00 00            	je	0x57dc55 <.text+0x3c55>
  57d42b: 8b 8f 34 02 00 00            	mov	ecx, dword ptr [edi + 0x234]
  57d431: 8b 11                        	mov	edx, dword ptr [ecx]
  57d433: 8b 42 40                     	mov	eax, dword ptr [edx + 0x40]
  57d436: ff d0                        	call	eax
  57d438: 8d 8d e0 fc ff ff            	lea	ecx, [ebp - 0x320]
  57d43e: 51                           	push	ecx
  57d43f: 8d 8f bc 02 00 00            	lea	ecx, [edi + 0x2bc]
  57d445: 89 85 c8 fc ff ff            	mov	dword ptr [ebp - 0x338], eax
  57d44b: e8 d0 91 8c 00               	call	0xe46620 <.text+0x8cc620>
  57d450: 8d 95 68 fc ff ff            	lea	edx, [ebp - 0x398]
  57d456: 8d 8f 5c 02 00 00            	lea	ecx, [edi + 0x25c]
  57d45c: 52                           	push	edx
  57d45d: 89 30                        	mov	dword ptr [eax], esi
  57d45f: 89 9d d4 fc ff ff            	mov	dword ptr [ebp - 0x32c], ebx
  57d465: 89 9d d8 fc ff ff            	mov	dword ptr [ebp - 0x328], ebx
  57d46b: e8 00 8d bf 00               	call	0x1176170 <.text+0xbfc170>
  57d470: 8b 08                        	mov	ecx, dword ptr [eax]
  57d472: 85 c9                        	test	ecx, ecx
  57d474: 74 0e                        	je	0x57d484 <.text+0x3484>
  57d476: 8b 09                        	mov	ecx, dword ptr [ecx]
  57d478: 85 c9                        	test	ecx, ecx
  57d47a: 74 08                        	je	0x57d484 <.text+0x3484>
  57d47c: 8b 19                        	mov	ebx, dword ptr [ecx]
  57d47e: 89 9d d4 fc ff ff            	mov	dword ptr [ebp - 0x32c], ebx
  57d484: 8b 70 08                     	mov	esi, dword ptr [eax + 0x8]
  57d487: 89 b5 dc fc ff ff            	mov	dword ptr [ebp - 0x324], esi
  57d48d: 8d 49 00                     	lea	ecx, [ecx]
  57d490: 8d 85 10 fc ff ff            	lea	eax, [ebp - 0x3f0]
  57d496: 50                           	push	eax
  57d497: 8d 8f 5c 02 00 00            	lea	ecx, [edi + 0x25c]
  57d49d: e8 9e 6e 24 00               	call	0x7c4340 <.text+0x24a340>
  57d4a2: 85 db                        	test	ebx, ebx
  57d4a4: 0f 84 a6 07 00 00            	je	0x57dc50 <.text+0x3c50>
  57d4aa: 8b 13                        	mov	edx, dword ptr [ebx]
  57d4ac: 85 d2                        	test	edx, edx
  57d4ae: 0f 84 9c 07 00 00            	je	0x57dc50 <.text+0x3c50>
  57d4b4: 8b 08                        	mov	ecx, dword ptr [eax]
  57d4b6: 85 c9                        	test	ecx, ecx
  57d4b8: 74 02                        	je	0x57d4bc <.text+0x34bc>
  57d4ba: 8b 09                        	mov	ecx, dword ptr [ecx]
  57d4bc: 3b d1                        	cmp	edx, ecx
  57d4be: 0f 85 8c 07 00 00            	jne	0x57dc50 <.text+0x3c50>
  57d4c4: 3b 70 08                     	cmp	esi, dword ptr [eax + 0x8]
  57d4c7: 0f 94 c0                     	sete	al
  57d4ca: 84 c0                        	test	al, al
  57d4cc: 0f 94 c0                     	sete	al
  57d4cf: 84 c0                        	test	al, al
  57d4d1: 0f 84 7e 07 00 00            	je	0x57dc55 <.text+0x3c55>
  57d4d7: 8b c2                        	mov	eax, edx
  57d4d9: 85 c0                        	test	eax, eax
  57d4db: 0f 84 6f 07 00 00            	je	0x57dc50 <.text+0x3c50>
  57d4e1: 85 f6                        	test	esi, esi
  57d4e3: 0f 84 67 07 00 00            	je	0x57dc50 <.text+0x3c50>
  57d4e9: 39 70 04                     	cmp	dword ptr [eax + 0x4], esi
  57d4ec: 0f 87 5e 07 00 00            	ja	0x57dc50 <.text+0x3c50>
  57d4f2: 3b 70 08                     	cmp	esi, dword ptr [eax + 0x8]
  57d4f5: 0f 83 55 07 00 00            	jae	0x57dc50 <.text+0x3c50>
  57d4fb: 8d 8d b0 fc ff ff            	lea	ecx, [ebp - 0x350]
  57d501: 51                           	push	ecx
  57d502: 8d 56 08                     	lea	edx, [esi + 0x8]
  57d505: 52                           	push	edx
  57d506: 8b ce                        	mov	ecx, esi
  57d508: e8 d3 38 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57d50d: 8b 85 c8 fc ff ff            	mov	eax, dword ptr [ebp - 0x338]
  57d513: 39 85 b0 fc ff ff            	cmp	dword ptr [ebp - 0x350], eax
  57d519: 0f 85 0c 07 00 00            	jne	0x57dc2b <.text+0x3c2b>
  57d51f: 8b 03                        	mov	eax, dword ptr [ebx]
  57d521: 85 c0                        	test	eax, eax
  57d523: 0f 84 27 07 00 00            	je	0x57dc50 <.text+0x3c50>
  57d529: 39 70 04                     	cmp	dword ptr [eax + 0x4], esi
  57d52c: 0f 87 1e 07 00 00            	ja	0x57dc50 <.text+0x3c50>
  57d532: 3b 70 08                     	cmp	esi, dword ptr [eax + 0x8]
  57d535: 0f 83 15 07 00 00            	jae	0x57dc50 <.text+0x3c50>
  57d53b: 8b 8f 34 02 00 00            	mov	ecx, dword ptr [edi + 0x234]
  57d541: 6a 00                        	push	0x0
  57d543: 68 fc 98 9d 01               	push	0x19d98fc
  57d548: 68 74 91 9d 01               	push	0x19d9174
  57d54d: 6a 00                        	push	0x0
  57d54f: 83 c6 0c                     	add	esi, 0xc
  57d552: 51                           	push	ecx
  57d553: 89 b5 d0 fc ff ff            	mov	dword ptr [ebp - 0x330], esi
  57d559: e8 81 a1 e5 00               	call	0x13d76df <.text+0xe5d6df>
  57d55e: 8b d8                        	mov	ebx, eax
  57d560: 83 c4 14                     	add	esp, 0x14
  57d563: 89 9d f0 fc ff ff            	mov	dword ptr [ebp - 0x310], ebx
  57d569: 85 db                        	test	ebx, ebx
  57d56b: 0f 84 ba 06 00 00            	je	0x57dc2b <.text+0x3c2b>
  57d571: 8d 95 28 fc ff ff            	lea	edx, [ebp - 0x3d8]
  57d577: 33 ff                        	xor	edi, edi
  57d579: 52                           	push	edx
  57d57a: 8b ce                        	mov	ecx, esi
  57d57c: 89 bd e4 fc ff ff            	mov	dword ptr [ebp - 0x31c], edi
  57d582: 89 bd e8 fc ff ff            	mov	dword ptr [ebp - 0x318], edi
  57d588: e8 c3 28 fe ff               	call	0x55fe50
  57d58d: 8b 08                        	mov	ecx, dword ptr [eax]
  57d58f: 85 c9                        	test	ecx, ecx
  57d591: 74 0e                        	je	0x57d5a1 <.text+0x35a1>
  57d593: 8b 09                        	mov	ecx, dword ptr [ecx]
  57d595: 85 c9                        	test	ecx, ecx
  57d597: 74 08                        	je	0x57d5a1 <.text+0x35a1>
  57d599: 8b 39                        	mov	edi, dword ptr [ecx]
  57d59b: 89 bd e4 fc ff ff            	mov	dword ptr [ebp - 0x31c], edi
  57d5a1: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  57d5a4: 89 85 ec fc ff ff            	mov	dword ptr [ebp - 0x314], eax
  57d5aa: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
  57d5b0: 8d 8d 58 fc ff ff            	lea	ecx, [ebp - 0x3a8]
  57d5b6: 51                           	push	ecx
  57d5b7: 8b ce                        	mov	ecx, esi
  57d5b9: e8 82 6d 24 00               	call	0x7c4340 <.text+0x24a340>
  57d5be: 85 ff                        	test	edi, edi
  57d5c0: 0f 84 8a 06 00 00            	je	0x57dc50 <.text+0x3c50>
  57d5c6: 8b 17                        	mov	edx, dword ptr [edi]
  57d5c8: 85 d2                        	test	edx, edx
  57d5ca: 0f 84 80 06 00 00            	je	0x57dc50 <.text+0x3c50>
  57d5d0: 8b 08                        	mov	ecx, dword ptr [eax]
  57d5d2: 85 c9                        	test	ecx, ecx
  57d5d4: 74 02                        	je	0x57d5d8 <.text+0x35d8>
  57d5d6: 8b 09                        	mov	ecx, dword ptr [ecx]
  57d5d8: 3b d1                        	cmp	edx, ecx
  57d5da: 0f 85 70 06 00 00            	jne	0x57dc50 <.text+0x3c50>
  57d5e0: 8b 95 ec fc ff ff            	mov	edx, dword ptr [ebp - 0x314]
  57d5e6: 3b 50 08                     	cmp	edx, dword ptr [eax + 0x8]
  57d5e9: 0f 94 c0                     	sete	al
  57d5ec: 84 c0                        	test	al, al
  57d5ee: 0f 94 c0                     	sete	al
  57d5f1: 84 c0                        	test	al, al
  57d5f3: 0f 84 2c 06 00 00            	je	0x57dc25 <.text+0x3c25>
  57d5f9: 8b 03                        	mov	eax, dword ptr [ebx]
  57d5fb: 8b 90 d4 04 00 00            	mov	edx, dword ptr [eax + 0x4d4]
  57d601: 8b cb                        	mov	ecx, ebx
  57d603: ff d2                        	call	edx
  57d605: 8b 70 38                     	mov	esi, dword ptr [eax + 0x38]
  57d608: 2b 70 34                     	sub	esi, dword ptr [eax + 0x34]
  57d60b: 8b 07                        	mov	eax, dword ptr [edi]
  57d60d: c1 fe 02                     	sar	esi, 0x2
  57d610: 85 c0                        	test	eax, eax
  57d612: 0f 84 38 06 00 00            	je	0x57dc50 <.text+0x3c50>
  57d618: 8b 8d ec fc ff ff            	mov	ecx, dword ptr [ebp - 0x314]
  57d61e: 85 c9                        	test	ecx, ecx
  57d620: 0f 84 2a 06 00 00            	je	0x57dc50 <.text+0x3c50>
  57d626: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57d629: 0f 84 21 06 00 00            	je	0x57dc50 <.text+0x3c50>
  57d62f: 8b d9                        	mov	ebx, ecx
  57d631: 83 c3 0c                     	add	ebx, 0xc
  57d634: 8d 85 b4 fc ff ff            	lea	eax, [ebp - 0x34c]
  57d63a: 50                           	push	eax
  57d63b: 8d 4b 08                     	lea	ecx, [ebx + 0x8]
  57d63e: 51                           	push	ecx
  57d63f: 8b cb                        	mov	ecx, ebx
  57d641: 89 9d f4 fc ff ff            	mov	dword ptr [ebp - 0x30c], ebx
  57d647: e8 94 37 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57d64c: 3b b5 b4 fc ff ff            	cmp	esi, dword ptr [ebp - 0x34c]
  57d652: 0f 86 a2 05 00 00            	jbe	0x57dbfa <.text+0x3bfa>
  57d658: 8b 07                        	mov	eax, dword ptr [edi]
  57d65a: 85 c0                        	test	eax, eax
  57d65c: 0f 84 ee 05 00 00            	je	0x57dc50 <.text+0x3c50>
  57d662: 8b b5 ec fc ff ff            	mov	esi, dword ptr [ebp - 0x314]
  57d668: 3b 70 08                     	cmp	esi, dword ptr [eax + 0x8]
  57d66b: 0f 84 df 05 00 00            	je	0x57dc50 <.text+0x3c50>
  57d671: 8d 95 b8 fc ff ff            	lea	edx, [ebp - 0x348]
  57d677: 52                           	push	edx
  57d678: 8d 43 08                     	lea	eax, [ebx + 0x8]
  57d67b: 50                           	push	eax
  57d67c: 8b cb                        	mov	ecx, ebx
  57d67e: e8 5d 37 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57d683: 8b 8d e0 fc ff ff            	mov	ecx, dword ptr [ebp - 0x320]
  57d689: 39 8d b8 fc ff ff            	cmp	dword ptr [ebp - 0x348], ecx
  57d68f: 0f 85 65 05 00 00            	jne	0x57dbfa <.text+0x3bfa>
  57d695: 8b 07                        	mov	eax, dword ptr [edi]
  57d697: 85 c0                        	test	eax, eax
  57d699: 0f 84 b1 05 00 00            	je	0x57dc50 <.text+0x3c50>
  57d69f: 3b 70 08                     	cmp	esi, dword ptr [eax + 0x8]
  57d6a2: 0f 84 a8 05 00 00            	je	0x57dc50 <.text+0x3c50>
  57d6a8: 8d 8d 80 fc ff ff            	lea	ecx, [ebp - 0x380]
  57d6ae: e8 bd 4d c2 00               	call	0x11a2470 <.text+0xc28470>
  57d6b3: 8b 95 f8 fc ff ff            	mov	edx, dword ptr [ebp - 0x308]
  57d6b9: 8d 85 88 fc ff ff            	lea	eax, [ebp - 0x378]
  57d6bf: 50                           	push	eax
  57d6c0: 8d 8d 00 fd ff ff            	lea	ecx, [ebp - 0x300]
  57d6c6: 51                           	push	ecx
  57d6c7: 8d 8d 80 fc ff ff            	lea	ecx, [ebp - 0x380]
  57d6cd: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57d6d4: 89 95 00 fd ff ff            	mov	dword ptr [ebp - 0x300], edx
  57d6da: e8 51 32 c2 00               	call	0x11a0930 <.text+0xc26930>
  57d6df: 8d 95 1c fc ff ff            	lea	edx, [ebp - 0x3e4]
  57d6e5: 8d 73 30                     	lea	esi, [ebx + 0x30]
  57d6e8: 52                           	push	edx
  57d6e9: 8b ce                        	mov	ecx, esi
  57d6eb: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
  57d6f2: e8 49 6c 24 00               	call	0x7c4340 <.text+0x24a340>
  57d6f7: 8b d8                        	mov	ebx, eax
  57d6f9: 8d 85 80 fc ff ff            	lea	eax, [ebp - 0x380]
  57d6ff: 50                           	push	eax
  57d700: 8d 8d 34 fc ff ff            	lea	ecx, [ebp - 0x3cc]
  57d706: 51                           	push	ecx
  57d707: 8b ce                        	mov	ecx, esi
  57d709: e8 d2 cc f1 ff               	call	0x49a3e0
  57d70e: 8b 08                        	mov	ecx, dword ptr [eax]
  57d710: 85 c9                        	test	ecx, ecx
  57d712: 0f 84 38 05 00 00            	je	0x57dc50 <.text+0x3c50>
  57d718: 8b 09                        	mov	ecx, dword ptr [ecx]
  57d71a: 85 c9                        	test	ecx, ecx
  57d71c: 0f 84 2e 05 00 00            	je	0x57dc50 <.text+0x3c50>
  57d722: 8b 13                        	mov	edx, dword ptr [ebx]
  57d724: 85 d2                        	test	edx, edx
  57d726: 74 02                        	je	0x57d72a <.text+0x372a>
  57d728: 8b 12                        	mov	edx, dword ptr [edx]
  57d72a: 3b ca                        	cmp	ecx, edx
  57d72c: 0f 85 1e 05 00 00            	jne	0x57dc50 <.text+0x3c50>
  57d732: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  57d735: 3b 53 08                     	cmp	edx, dword ptr [ebx + 0x8]
  57d738: 8d 8d 80 fc ff ff            	lea	ecx, [ebp - 0x380]
  57d73e: 0f 94 c3                     	sete	bl
  57d741: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57d748: e8 73 35 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57d74d: 84 db                        	test	bl, bl
  57d74f: 0f 85 a5 04 00 00            	jne	0x57dbfa <.text+0x3bfa>
  57d755: 68 18 05 00 00               	push	0x518
  57d75a: e8 21 2c c3 00               	call	0x11b0380 <.text+0xc36380>
  57d75f: 8b f8                        	mov	edi, eax
  57d761: 83 c4 04                     	add	esp, 0x4
  57d764: 89 bd 64 fc ff ff            	mov	dword ptr [ebp - 0x39c], edi
  57d76a: c7 45 fc 02 00 00 00         	mov	dword ptr [ebp - 0x4], 0x2
  57d771: 85 ff                        	test	edi, edi
  57d773: 0f 84 ab 00 00 00            	je	0x57d824 <.text+0x3824>
  57d779: 8d 8d 8c fc ff ff            	lea	ecx, [ebp - 0x374]
  57d77f: e8 ec 4c c2 00               	call	0x11a2470 <.text+0xc28470>
  57d784: 8b 85 f8 fc ff ff            	mov	eax, dword ptr [ebp - 0x308]
  57d78a: 8d 8d 94 fc ff ff            	lea	ecx, [ebp - 0x36c]
  57d790: 51                           	push	ecx
  57d791: 8d 95 00 fd ff ff            	lea	edx, [ebp - 0x300]
  57d797: 52                           	push	edx
  57d798: 8d 8d 8c fc ff ff            	lea	ecx, [ebp - 0x374]
  57d79e: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57d7a2: 89 85 00 fd ff ff            	mov	dword ptr [ebp - 0x300], eax
  57d7a8: e8 83 31 c2 00               	call	0x11a0930 <.text+0xc26930>
  57d7ad: 8b 8d f0 fc ff ff            	mov	ecx, dword ptr [ebp - 0x310]
  57d7b3: 83 8d fc fc ff ff 01         	or	dword ptr [ebp - 0x304], 0x1
  57d7ba: 8d 45 d0                     	lea	eax, [ebp - 0x30]
  57d7bd: 50                           	push	eax
  57d7be: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  57d7c2: e8 09 50 ff ff               	call	0x5727d0
  57d7c7: 8b d8                        	mov	ebx, eax
  57d7c9: 83 8d fc fc ff ff 02         	or	dword ptr [ebp - 0x304], 0x2
  57d7d0: 8d 8d 8c fc ff ff            	lea	ecx, [ebp - 0x374]
  57d7d6: 51                           	push	ecx
  57d7d7: 8b ce                        	mov	ecx, esi
  57d7d9: c7 45 fc 05 00 00 00         	mov	dword ptr [ebp - 0x4], 0x5
  57d7e0: e8 7b ec f1 ff               	call	0x49c460
  57d7e5: b9 08 00 00 00               	mov	ecx, 0x8
  57d7ea: 39 48 18                     	cmp	dword ptr [eax + 0x18], ecx
  57d7ed: 72 05                        	jb	0x57d7f4 <.text+0x37f4>
  57d7ef: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57d7f2: eb 03                        	jmp	0x57d7f7 <.text+0x37f7>
  57d7f4: 83 c0 04                     	add	eax, 0x4
  57d7f7: 39 4b 18                     	cmp	dword ptr [ebx + 0x18], ecx
  57d7fa: 72 14                        	jb	0x57d810 <.text+0x3810>
  57d7fc: 8b 5b 04                     	mov	ebx, dword ptr [ebx + 0x4]
  57d7ff: 6a 00                        	push	0x0
  57d801: 6a 00                        	push	0x0
  57d803: 50                           	push	eax
  57d804: 53                           	push	ebx
  57d805: 8b cf                        	mov	ecx, edi
  57d807: e8 64 77 eb ff               	call	0x434f70
  57d80c: 8b f8                        	mov	edi, eax
  57d80e: eb 16                        	jmp	0x57d826 <.text+0x3826>
  57d810: 6a 00                        	push	0x0
  57d812: 6a 00                        	push	0x0
  57d814: 83 c3 04                     	add	ebx, 0x4
  57d817: 50                           	push	eax
  57d818: 53                           	push	ebx
  57d819: 8b cf                        	mov	ecx, edi
  57d81b: e8 50 77 eb ff               	call	0x434f70
  57d820: 8b f8                        	mov	edi, eax
  57d822: eb 02                        	jmp	0x57d826 <.text+0x3826>
  57d824: 33 ff                        	xor	edi, edi
  57d826: 8b 9d fc fc ff ff            	mov	ebx, dword ptr [ebp - 0x304]
  57d82c: f6 c3 02                     	test	bl, 0x2
  57d82f: 74 11                        	je	0x57d842 <.text+0x3842>
  57d831: 83 e3 fd                     	and	ebx, -0x3
  57d834: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57d837: 89 9d fc fc ff ff            	mov	dword ptr [ebp - 0x304], ebx
  57d83d: e8 ae ad ed ff               	call	0x4585f0
  57d842: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57d849: f6 c3 01                     	test	bl, 0x1
  57d84c: 74 14                        	je	0x57d862 <.text+0x3862>
  57d84e: 83 e3 fe                     	and	ebx, -0x2
  57d851: 8d 8d 8c fc ff ff            	lea	ecx, [ebp - 0x374]
  57d857: 89 9d fc fc ff ff            	mov	dword ptr [ebp - 0x304], ebx
  57d85d: e8 5e 34 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57d862: 85 ff                        	test	edi, edi
  57d864: 74 61                        	je	0x57d8c7 <.text+0x38c7>
  57d866: 8b 95 e4 fc ff ff            	mov	edx, dword ptr [ebp - 0x31c]
  57d86c: 8b 02                        	mov	eax, dword ptr [edx]
  57d86e: 85 c0                        	test	eax, eax
  57d870: 0f 84 da 03 00 00            	je	0x57dc50 <.text+0x3c50>
  57d876: 8b 8d ec fc ff ff            	mov	ecx, dword ptr [ebp - 0x314]
  57d87c: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
  57d87f: 0f 84 cb 03 00 00            	je	0x57dc50 <.text+0x3c50>
  57d885: 8b 8d f4 fc ff ff            	mov	ecx, dword ptr [ebp - 0x30c]
  57d88b: 8d 95 c0 fc ff ff            	lea	edx, [ebp - 0x340]
  57d891: 52                           	push	edx
  57d892: 8d 41 08                     	lea	eax, [ecx + 0x8]
  57d895: 50                           	push	eax
  57d896: e8 45 35 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57d89b: 8b 8d f0 fc ff ff            	mov	ecx, dword ptr [ebp - 0x310]
  57d8a1: 8b 11                        	mov	edx, dword ptr [ecx]
  57d8a3: 8b 82 d4 04 00 00            	mov	eax, dword ptr [edx + 0x4d4]
  57d8a9: 8b b5 c0 fc ff ff            	mov	esi, dword ptr [ebp - 0x340]
  57d8af: ff d0                        	call	eax
  57d8b1: 8b 48 34                     	mov	ecx, dword ptr [eax + 0x34]
  57d8b4: 8b 50 38                     	mov	edx, dword ptr [eax + 0x38]
  57d8b7: 2b d1                        	sub	edx, ecx
  57d8b9: c1 fa 02                     	sar	edx, 0x2
  57d8bc: 3b f2                        	cmp	esi, edx
  57d8be: 0f 83 8c 03 00 00            	jae	0x57dc50 <.text+0x3c50>
  57d8c4: 89 3c b1                     	mov	dword ptr [ecx + 4*esi], edi
  57d8c7: 8d 8d a4 fc ff ff            	lea	ecx, [ebp - 0x35c]
  57d8cd: e8 9e 4b c2 00               	call	0x11a2470 <.text+0xc28470>
  57d8d2: 8b 85 f8 fc ff ff            	mov	eax, dword ptr [ebp - 0x308]
  57d8d8: 8d 8d ac fc ff ff            	lea	ecx, [ebp - 0x354]
  57d8de: 51                           	push	ecx
  57d8df: 8d 95 00 fd ff ff            	lea	edx, [ebp - 0x300]
  57d8e5: bf 08 00 00 00               	mov	edi, 0x8
  57d8ea: 52                           	push	edx
  57d8eb: 8d 8d a4 fc ff ff            	lea	ecx, [ebp - 0x35c]
  57d8f1: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  57d8f4: 89 85 00 fd ff ff            	mov	dword ptr [ebp - 0x300], eax
  57d8fa: e8 31 30 c2 00               	call	0x11a0930 <.text+0xc26930>
  57d8ff: 8b b5 f4 fc ff ff            	mov	esi, dword ptr [ebp - 0x30c]
  57d905: 8d 85 a4 fc ff ff            	lea	eax, [ebp - 0x35c]
  57d90b: 83 c6 44                     	add	esi, 0x44
  57d90e: 50                           	push	eax
  57d90f: 8b ce                        	mov	ecx, esi
  57d911: c7 45 fc 09 00 00 00         	mov	dword ptr [ebp - 0x4], 0x9
  57d918: e8 43 eb f1 ff               	call	0x49c460
  57d91d: 39 78 18                     	cmp	dword ptr [eax + 0x18], edi
  57d920: 72 05                        	jb	0x57d927 <.text+0x3927>
  57d922: 8b 58 04                     	mov	ebx, dword ptr [eax + 0x4]
  57d925: eb 03                        	jmp	0x57d92a <.text+0x392a>
  57d927: 8d 58 04                     	lea	ebx, [eax + 0x4]
  57d92a: 68 78 21 56 01               	push	0x1562178
  57d92f: e8 bc 25 c2 00               	call	0x119fef0 <.text+0xc25ef0>
  57d934: 83 c4 04                     	add	esp, 0x4
  57d937: 8b cb                        	mov	ecx, ebx
  57d939: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  57d940: 66 8b 11                     	mov	dx, word ptr [ecx]
  57d943: 66 3b 10                     	cmp	dx, word ptr [eax]
  57d946: 75 1e                        	jne	0x57d966 <.text+0x3966>
  57d948: 66 85 d2                     	test	dx, dx
  57d94b: 74 15                        	je	0x57d962 <.text+0x3962>
  57d94d: 66 8b 51 02                  	mov	dx, word ptr [ecx + 0x2]
  57d951: 66 3b 50 02                  	cmp	dx, word ptr [eax + 0x2]
  57d955: 75 0f                        	jne	0x57d966 <.text+0x3966>
  57d957: 83 c1 04                     	add	ecx, 0x4
  57d95a: 83 c0 04                     	add	eax, 0x4
  57d95d: 66 85 d2                     	test	dx, dx
  57d960: 75 de                        	jne	0x57d940 <.text+0x3940>
  57d962: 33 c0                        	xor	eax, eax
  57d964: eb 05                        	jmp	0x57d96b <.text+0x396b>
  57d966: 1b c0                        	sbb	eax, eax
  57d968: 83 d8 ff                     	sbb	eax, -0x1
  57d96b: 85 c0                        	test	eax, eax
  57d96d: 8d 8d a4 fc ff ff            	lea	ecx, [ebp - 0x35c]
  57d973: 0f 95 c3                     	setne	bl
  57d976: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57d97d: e8 3e 33 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57d982: 84 db                        	test	bl, bl
  57d984: 0f 84 70 02 00 00            	je	0x57dbfa <.text+0x3bfa>
  57d98a: 8d 8d 74 fc ff ff            	lea	ecx, [ebp - 0x38c]
  57d990: e8 db 4a c2 00               	call	0x11a2470 <.text+0xc28470>
  57d995: 8b 9d f8 fc ff ff            	mov	ebx, dword ptr [ebp - 0x308]
  57d99b: 8d 8d 7c fc ff ff            	lea	ecx, [ebp - 0x384]
  57d9a1: 51                           	push	ecx
  57d9a2: 8d 95 00 fd ff ff            	lea	edx, [ebp - 0x300]
  57d9a8: 52                           	push	edx
  57d9a9: 8d 8d 74 fc ff ff            	lea	ecx, [ebp - 0x38c]
  57d9af: c7 45 fc 0a 00 00 00         	mov	dword ptr [ebp - 0x4], 0xa
  57d9b6: 89 9d 00 fd ff ff            	mov	dword ptr [ebp - 0x300], ebx
  57d9bc: e8 6f 2f c2 00               	call	0x11a0930 <.text+0xc26930>
  57d9c1: 8d 85 74 fc ff ff            	lea	eax, [ebp - 0x38c]
  57d9c7: 50                           	push	eax
  57d9c8: 8b ce                        	mov	ecx, esi
  57d9ca: c7 45 fc 0b 00 00 00         	mov	dword ptr [ebp - 0x4], 0xb
  57d9d1: e8 8a ea f1 ff               	call	0x49c460
  57d9d6: 8d 8d 74 fc ff ff            	lea	ecx, [ebp - 0x38c]
  57d9dc: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57d9e3: e8 d8 32 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57d9e8: 8b bd f0 fc ff ff            	mov	edi, dword ptr [ebp - 0x310]
  57d9ee: 8b 17                        	mov	edx, dword ptr [edi]
  57d9f0: 8b 85 e0 fc ff ff            	mov	eax, dword ptr [ebp - 0x320]
  57d9f6: 8b 92 bc 05 00 00            	mov	edx, dword ptr [edx + 0x5bc]
  57d9fc: 50                           	push	eax
  57d9fd: 8b cf                        	mov	ecx, edi
  57d9ff: ff d2                        	call	edx
  57da01: 8d 8d 98 fc ff ff            	lea	ecx, [ebp - 0x368]
  57da07: 89 85 f4 fc ff ff            	mov	dword ptr [ebp - 0x30c], eax
  57da0d: e8 5e 4a c2 00               	call	0x11a2470 <.text+0xc28470>
  57da12: 8d 85 a0 fc ff ff            	lea	eax, [ebp - 0x360]
  57da18: 50                           	push	eax
  57da19: 8d 8d 00 fd ff ff            	lea	ecx, [ebp - 0x300]
  57da1f: 51                           	push	ecx
  57da20: 8d 8d 98 fc ff ff            	lea	ecx, [ebp - 0x368]
  57da26: c7 45 fc 0c 00 00 00         	mov	dword ptr [ebp - 0x4], 0xc
  57da2d: 89 9d 00 fd ff ff            	mov	dword ptr [ebp - 0x300], ebx
  57da33: e8 f8 2e c2 00               	call	0x11a0930 <.text+0xc26930>
  57da38: 8d 55 d0                     	lea	edx, [ebp - 0x30]
  57da3b: 52                           	push	edx
  57da3c: 8b cf                        	mov	ecx, edi
  57da3e: c7 45 fc 0d 00 00 00         	mov	dword ptr [ebp - 0x4], 0xd
  57da45: e8 86 4d ff ff               	call	0x5727d0
  57da4a: 8b d8                        	mov	ebx, eax
  57da4c: 8d 85 98 fc ff ff            	lea	eax, [ebp - 0x368]
  57da52: 50                           	push	eax
  57da53: 8b ce                        	mov	ecx, esi
  57da55: c6 45 fc 0e                  	mov	byte ptr [ebp - 0x4], 0xe
  57da59: e8 02 ea f1 ff               	call	0x49c460
  57da5e: 83 78 18 08                  	cmp	dword ptr [eax + 0x18], 0x8
  57da62: 72 05                        	jb	0x57da69 <.text+0x3a69>
  57da64: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57da67: eb 03                        	jmp	0x57da6c <.text+0x3a6c>
  57da69: 83 c0 04                     	add	eax, 0x4
  57da6c: 83 7b 18 08                  	cmp	dword ptr [ebx + 0x18], 0x8
  57da70: 72 05                        	jb	0x57da77 <.text+0x3a77>
  57da72: 8b 5b 04                     	mov	ebx, dword ptr [ebx + 0x4]
  57da75: eb 03                        	jmp	0x57da7a <.text+0x3a7a>
  57da77: 83 c3 04                     	add	ebx, 0x4
  57da7a: 50                           	push	eax
  57da7b: 53                           	push	ebx
  57da7c: 68 f8 61 57 01               	push	0x15761f8
  57da81: e8 6a 24 c2 00               	call	0x119fef0 <.text+0xc25ef0>
  57da86: 8b 0d c8 f6 a6 01            	mov	ecx, dword ptr [0x1a6f6c8]
  57da8c: 83 c4 04                     	add	esp, 0x4
  57da8f: 50                           	push	eax
  57da90: 51                           	push	ecx
  57da91: e8 6a d9 c4 00               	call	0x11cb400 <.text+0xc51400>
  57da96: 83 c4 10                     	add	esp, 0x10
  57da99: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57da9c: 8b d8                        	mov	ebx, eax
  57da9e: e8 4d ab ed ff               	call	0x4585f0
  57daa3: 8d 8d 98 fc ff ff            	lea	ecx, [ebp - 0x368]
  57daa9: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57dab0: e8 0b 32 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57dab5: 8d 8d 04 fd ff ff            	lea	ecx, [ebp - 0x2fc]
  57dabb: e8 50 ae d3 00               	call	0x12b8910 <.text+0xd3e910>
  57dac0: c7 45 fc 0f 00 00 00         	mov	dword ptr [ebp - 0x4], 0xf
  57dac7: 85 db                        	test	ebx, ebx
  57dac9: 74 11                        	je	0x57dadc <.text+0x3adc>
  57dacb: 53                           	push	ebx
  57dacc: 8d 8d 04 fd ff ff            	lea	ecx, [ebp - 0x2fc]
  57dad2: e8 e9 71 ff ff               	call	0x574cc0
  57dad7: e9 a3 00 00 00               	jmp	0x57db7f <.text+0x3b7f>
  57dadc: 8b 95 f8 fc ff ff            	mov	edx, dword ptr [ebp - 0x308]
  57dae2: 52                           	push	edx
  57dae3: 8d 8d 68 fc ff ff            	lea	ecx, [ebp - 0x398]
  57dae9: e8 d2 c2 e8 ff               	call	0x409dc0
  57daee: 8d 45 d0                     	lea	eax, [ebp - 0x30]
  57daf1: 50                           	push	eax
  57daf2: 8b cf                        	mov	ecx, edi
  57daf4: c6 45 fc 10                  	mov	byte ptr [ebp - 0x4], 0x10
  57daf8: e8 d3 4c ff ff               	call	0x5727d0
  57dafd: 8b d8                        	mov	ebx, eax
  57daff: 8d 8d 68 fc ff ff            	lea	ecx, [ebp - 0x398]
  57db05: 51                           	push	ecx
  57db06: 8b ce                        	mov	ecx, esi
  57db08: c6 45 fc 11                  	mov	byte ptr [ebp - 0x4], 0x11
  57db0c: e8 4f e9 f1 ff               	call	0x49c460
  57db11: 83 78 18 08                  	cmp	dword ptr [eax + 0x18], 0x8
  57db15: 72 05                        	jb	0x57db1c <.text+0x3b1c>
  57db17: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
  57db1a: eb 03                        	jmp	0x57db1f <.text+0x3b1f>
  57db1c: 83 c0 04                     	add	eax, 0x4
  57db1f: 83 7b 18 08                  	cmp	dword ptr [ebx + 0x18], 0x8
  57db23: 72 05                        	jb	0x57db2a <.text+0x3b2a>
  57db25: 8b 4b 04                     	mov	ecx, dword ptr [ebx + 0x4]
  57db28: eb 03                        	jmp	0x57db2d <.text+0x3b2d>
  57db2a: 8d 4b 04                     	lea	ecx, [ebx + 0x4]
  57db2d: 50                           	push	eax
  57db2e: 51                           	push	ecx
  57db2f: 68 10 ae 58 01               	push	0x158ae10
  57db34: e8 b7 23 c2 00               	call	0x119fef0 <.text+0xc25ef0>
  57db39: 83 c4 04                     	add	esp, 0x4
  57db3c: 50                           	push	eax
  57db3d: 68 57 05 00 00               	push	0x557
  57db42: 68 90 ad 58 01               	push	0x158ad90
  57db47: e8 a4 23 c2 00               	call	0x119fef0 <.text+0xc25ef0>
  57db4c: 83 c4 04                     	add	esp, 0x4
  57db4f: 50                           	push	eax
  57db50: 68 30 ac 58 01               	push	0x158ac30
  57db55: e8 96 23 c2 00               	call	0x119fef0 <.text+0xc25ef0>
  57db5a: 83 c4 04                     	add	esp, 0x4
  57db5d: 50                           	push	eax
  57db5e: 6a 00                        	push	0x0
  57db60: e8 7b 51 c2 00               	call	0x11a2ce0 <.text+0xc28ce0>
  57db65: 83 c4 1c                     	add	esp, 0x1c
  57db68: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
  57db6b: e8 80 aa ed ff               	call	0x4585f0
  57db70: 8d 8d 68 fc ff ff            	lea	ecx, [ebp - 0x398]
  57db76: c6 45 fc 0f                  	mov	byte ptr [ebp - 0x4], 0xf
  57db7a: e8 41 31 c2 00               	call	0x11a0cc0 <.text+0xc26cc0>
  57db7f: 33 db                        	xor	ebx, ebx
  57db81: 8d b5 f0 fe ff ff            	lea	esi, [ebp - 0x110]
  57db87: eb 07                        	jmp	0x57db90 <.text+0x3b90>
  57db89: 8d a4 24 00 00 00 00         	lea	esp, [esp]
  57db90: 83 bc 9d c0 fe ff ff 12      	cmp	dword ptr [ebp + 4*ebx - 0x140], 0x12
  57db98: 74 33                        	je	0x57dbcd <.text+0x3bcd>
  57db9a: 8d 95 bc fc ff ff            	lea	edx, [ebp - 0x344]
  57dba0: 52                           	push	edx
  57dba1: 8d 7e 08                     	lea	edi, [esi + 0x8]
  57dba4: 57                           	push	edi
  57dba5: 8b ce                        	mov	ecx, esi
  57dba7: e8 34 32 c2 00               	call	0x11a0de0 <.text+0xc26de0>
  57dbac: 8b 8d f8 fc ff ff            	mov	ecx, dword ptr [ebp - 0x308]
  57dbb2: 03 8d bc fc ff ff            	add	ecx, dword ptr [ebp - 0x344]
  57dbb8: 57                           	push	edi
  57dbb9: 8d 95 c4 fc ff ff            	lea	edx, [ebp - 0x33c]
  57dbbf: 89 8d c4 fc ff ff            	mov	dword ptr [ebp - 0x33c], ecx
  57dbc5: 52                           	push	edx
  57dbc6: 8b ce                        	mov	ecx, esi
  57dbc8: e8 63 2d c2 00               	call	0x11a0930 <.text+0xc26930>
  57dbcd: 43                           	inc	ebx
  57dbce: 83 c6 0c                     	add	esi, 0xc
  57dbd1: 83 fb 03                     	cmp	ebx, 0x3
  57dbd4: 7c ba                        	jl	0x57db90 <.text+0x3b90>
  57dbd6: 8b 8d f4 fc ff ff            	mov	ecx, dword ptr [ebp - 0x30c]
  57dbdc: 8d 85 04 fd ff ff            	lea	eax, [ebp - 0x2fc]
  57dbe2: 50                           	push	eax
  57dbe3: e8 d8 70 ff ff               	call	0x574cc0
  57dbe8: 8d 8d 04 fd ff ff            	lea	ecx, [ebp - 0x2fc]
  57dbee: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  57dbf5: e8 76 6b eb ff               	call	0x434770
  57dbfa: 6a 00                        	push	0x0
  57dbfc: 8d 8d 4c fc ff ff            	lea	ecx, [ebp - 0x3b4]
  57dc02: 51                           	push	ecx
  57dc03: 8d 8d e4 fc ff ff            	lea	ecx, [ebp - 0x31c]
  57dc09: e8 d2 85 bb 00               	call	0x11361e0 <.text+0xbbc1e0>
  57dc0e: 8b bd e4 fc ff ff            	mov	edi, dword ptr [ebp - 0x31c]
  57dc14: 8b b5 d0 fc ff ff            	mov	esi, dword ptr [ebp - 0x330]
  57dc1a: 8b 9d f0 fc ff ff            	mov	ebx, dword ptr [ebp - 0x310]
  57dc20: e9 8b f9 ff ff               	jmp	0x57d5b0 <.text+0x35b0>
  57dc25: 8b bd cc fc ff ff            	mov	edi, dword ptr [ebp - 0x334]
  57dc2b: 6a 00                        	push	0x0
  57dc2d: 8d 95 40 fc ff ff            	lea	edx, [ebp - 0x3c0]
  57dc33: 52                           	push	edx
  57dc34: 8d 8d d4 fc ff ff            	lea	ecx, [ebp - 0x32c]
  57dc3a: e8 81 f6 be 00               	call	0x116d2c0 <.text+0xbf32c0>
  57dc3f: 8b b5 dc fc ff ff            	mov	esi, dword ptr [ebp - 0x324]
  57dc45: 8b 9d d4 fc ff ff            	mov	ebx, dword ptr [ebp - 0x32c]
  57dc4b: e9 40 f8 ff ff               	jmp	0x57d490 <.text+0x3490>
  57dc50: e8 52 91 e5 00               	call	0x13d6da7 <.text+0xe5cda7>
  57dc55: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  57dc58: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  57dc5f: 59                           	pop	ecx
  57dc60: 5f                           	pop	edi
  57dc61: 5e                           	pop	esi
  57dc62: 5b                           	pop	ebx
  57dc63: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57dc66: 33 cd                        	xor	ecx, ebp
  57dc68: e8 6b 95 e5 00               	call	0x13d71d8 <.text+0xe5d1d8>
  57dc6d: 8b e5                        	mov	esp, ebp
  57dc6f: 5d                           	pop	ebp
  57dc70: c2 08 00                     	ret	0x8
  57dc73: cc                           	int3
  57dc74: cc                           	int3
  57dc75: cc                           	int3
  57dc76: cc                           	int3
  57dc77: cc                           	int3
  57dc78: cc                           	int3
  57dc79: cc                           	int3
  57dc7a: cc                           	int3
  57dc7b: cc                           	int3
  57dc7c: cc                           	int3
  57dc7d: cc                           	int3
  57dc7e: cc                           	int3
  57dc7f: cc                           	int3
  57dc80: 55                           	push	ebp
  57dc81: 8b ec                        	mov	ebp, esp
  57dc83: 6a ff                        	push	-0x1
  57dc85: 68 00 d8 41 01               	push	0x141d800
  57dc8a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  57dc90: 50                           	push	eax
  57dc91: 83 ec 08                     	sub	esp, 0x8
  57dc94: 53                           	push	ebx
  57dc95: 56                           	push	esi
  57dc96: 57                           	push	edi
  57dc97: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57dc9c: 33 c5                        	xor	eax, ebp
  57dc9e: 50                           	push	eax
  57dc9f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57dca2: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57dca8: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  57dcab: 8b f1                        	mov	esi, ecx
  57dcad: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57dcb0: 3d ff ff ff 07               	cmp	eax, 0x7ffffff
  57dcb5: 76 0a                        	jbe	0x57dcc1 <.text+0x3cc1>
  57dcb7: 68 6c 20 56 01               	push	0x156206c
  57dcbc: e8 09 3b e4 00               	call	0x13c17ca <.text+0xe477ca>
  57dcc1: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
  57dcc4: 2b 4e 04                     	sub	ecx, dword ptr [esi + 0x4]
  57dcc7: c1 f9 05                     	sar	ecx, 0x5
  57dcca: 3b c8                        	cmp	ecx, eax
  57dccc: 73 75                        	jae	0x57dd43 <.text+0x3d43>
  57dcce: 8d 7e 10                     	lea	edi, [esi + 0x10]
  57dcd1: 50                           	push	eax
  57dcd2: 8b cf                        	mov	ecx, edi
  57dcd4: e8 47 a1 d7 00               	call	0x12f7e20 <.text+0xd7de20>
  57dcd9: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
  57dcdc: 8b 4e 04                     	mov	ecx, dword ptr [esi + 0x4]
  57dcdf: 52                           	push	edx
  57dce0: 6a 00                        	push	0x0
  57dce2: 8b d8                        	mov	ebx, eax
  57dce4: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  57dce7: 57                           	push	edi
  57dce8: 53                           	push	ebx
  57dce9: 50                           	push	eax
  57dcea: 51                           	push	ecx
  57dceb: 89 5d ec                     	mov	dword ptr [ebp - 0x14], ebx
  57dcee: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  57dcf5: e8 d6 f5 ff ff               	call	0x57d2d0 <.text+0x32d0>
  57dcfa: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  57dcfd: 8b 46 04                     	mov	eax, dword ptr [esi + 0x4]
