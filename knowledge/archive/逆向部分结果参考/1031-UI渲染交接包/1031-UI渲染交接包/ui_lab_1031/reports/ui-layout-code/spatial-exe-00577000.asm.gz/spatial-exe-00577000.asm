
<stdin>:	file format elf32-i386

Disassembly of section .text:

00577000 <.text>:
  577000: 0a 00                        	or	al, byte ptr [eax]
  577002: 00 e8                        	add	al, ch
  577004: 08 f4                        	or	ah, dh
  577006: 18 00                        	sbb	byte ptr [eax], al
  577008: 8b 88 e0 00 00 00            	mov	ecx, dword ptr [eax + 0xe0]
  57700e: 83 79 1c 00                  	cmp	dword ptr [ecx + 0x1c], 0x0
  577012: 0f 85 3a 0a 00 00            	jne	0x577a52 <.text+0xa52>
  577018: 89 be 6c 03 00 00            	mov	dword ptr [esi + 0x36c], edi
  57701e: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  577024: e8 97 f0 ff ff               	call	0x5760c0
  577029: 80 be 96 03 00 00 00         	cmp	byte ptr [esi + 0x396], 0x0
  577030: 0f 84 1c 0a 00 00            	je	0x577a52 <.text+0xa52>
  577036: e8 d5 f3 18 00               	call	0x706410 <.text+0x18f410>
  57703b: 8b 88 e0 00 00 00            	mov	ecx, dword ptr [eax + 0xe0]
  577041: 8d 49 20                     	lea	ecx, [ecx + 0x20]
  577044: e8 f7 35 c4 00               	call	0x11ba640 <.text+0xc43640>
  577049: 89 86 70 03 00 00            	mov	dword ptr [esi + 0x370], eax
  57704f: 05 20 4e 00 00               	add	eax, 0x4e20
  577054: 6a 00                        	push	0x0
  577056: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  57705c: 89 86 74 03 00 00            	mov	dword ptr [esi + 0x374], eax
  577062: e8 99 fa f2 ff               	call	0x4a6b00
  577067: e9 e6 09 00 00               	jmp	0x577a52 <.text+0xa52>
  57706c: 83 f8 03                     	cmp	eax, 0x3
  57706f: 75 3a                        	jne	0x5770ab <.text+0xab>
  577071: 80 be 99 03 00 00 00         	cmp	byte ptr [esi + 0x399], 0x0
  577078: 75 47                        	jne	0x5770c1 <.text+0xc1>
  57707a: 80 be 94 03 00 00 00         	cmp	byte ptr [esi + 0x394], 0x0
  577081: 0f 84 cb 09 00 00            	je	0x577a52 <.text+0xa52>
  577087: e8 84 f3 18 00               	call	0x706410 <.text+0x18f410>
  57708c: 8b 90 e0 00 00 00            	mov	edx, dword ptr [eax + 0xe0]
  577092: 83 7a 1c 00                  	cmp	dword ptr [edx + 0x1c], 0x0
  577096: 0f 85 b6 09 00 00            	jne	0x577a52 <.text+0xa52>
  57709c: c7 86 6c 03 00 00 04 00 00 00	mov	dword ptr [esi + 0x36c], 0x4
  5770a6: e9 73 ff ff ff               	jmp	0x57701e <.text+0x1e>
  5770ab: 83 f8 02                     	cmp	eax, 0x2
  5770ae: 75 11                        	jne	0x5770c1 <.text+0xc1>
  5770b0: 8b 86 fc 01 00 00            	mov	eax, dword ptr [esi + 0x1fc]
  5770b6: 85 c0                        	test	eax, eax
  5770b8: 74 07                        	je	0x5770c1 <.text+0xc1>
  5770ba: 8b 40 40                     	mov	eax, dword ptr [eax + 0x40]
  5770bd: c6 40 55 00                  	mov	byte ptr [eax + 0x55], 0x0
  5770c1: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  5770c7: c7 86 6c 03 00 00 00 00 00 00	mov	dword ptr [esi + 0x36c], 0x0
  5770d1: e8 ea ef ff ff               	call	0x5760c0
  5770d6: 83 c8 ff                     	or	eax, -0x1
  5770d9: 89 86 70 03 00 00            	mov	dword ptr [esi + 0x370], eax
  5770df: 89 86 74 03 00 00            	mov	dword ptr [esi + 0x374], eax
  5770e5: e9 68 09 00 00               	jmp	0x577a52 <.text+0xa52>
  5770ea: 68 2c 01 00 00               	push	0x12c
  5770ef: ff 15 88 a5 55 01            	call	dword ptr [0x155a588]
  5770f5: 50                           	push	eax
  5770f6: 6a 64                        	push	0x64
  5770f8: 6a 00                        	push	0x0
  5770fa: e8 61 28 c4 00               	call	0x11b9960 <.text+0xc42960>
  5770ff: 83 c4 10                     	add	esp, 0x10
  577102: 83 f8 32                     	cmp	eax, 0x32
  577105: 8b 86 6c 03 00 00            	mov	eax, dword ptr [esi + 0x36c]
  57710b: bb 01 00 00 00               	mov	ebx, 0x1
  577110: 0f 9c 85 ef fb ff ff         	setl	byte ptr [ebp - 0x411]
  577117: 3b c3                        	cmp	eax, ebx
  577119: 0f 85 47 02 00 00            	jne	0x577366 <.text+0x366>
  57711f: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577125: 6a 00                        	push	0x0
  577127: e8 a4 da c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57712c: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577132: 50                           	push	eax
  577133: 6a 78                        	push	0x78
  577135: 6a 00                        	push	0x0
  577137: e8 94 da c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57713c: 8b c8                        	mov	ecx, eax
  57713e: e8 3d cc c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  577143: d1 e8                        	shr	eax
  577145: b9 90 01 00 00               	mov	ecx, 0x190
  57714a: 2b c8                        	sub	ecx, eax
  57714c: 51                           	push	ecx
  57714d: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577153: e8 f8 c7 c3 00               	call	0x11b3950 <.text+0xc3c950>
  577158: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  57715e: e8 cd 23 c5 00               	call	0x11c9530 <.text+0xc52530>
  577163: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  577169: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  577170: e8 9b 23 c5 00               	call	0x11c9510 <.text+0xc52510>
  577175: 8b 15 6c 65 b5 01            	mov	edx, dword ptr [0x1b5656c]
  57717b: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577181: 6a 00                        	push	0x0
  577183: 89 95 d0 fb ff ff            	mov	dword ptr [ebp - 0x430], edx
  577189: e8 42 da c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57718e: 8b c8                        	mov	ecx, eax
  577190: e8 eb cb c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  577195: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57719b: 83 e8 0a                     	sub	eax, 0xa
  57719e: 66 89 85 ca fb ff ff         	mov	word ptr [ebp - 0x436], ax
  5771a5: b8 04 00 00 00               	mov	eax, 0x4
  5771aa: 66 89 85 cc fb ff ff         	mov	word ptr [ebp - 0x434], ax
  5771b1: c6 85 ce fb ff ff 00         	mov	byte ptr [ebp - 0x432], 0x0
  5771b8: 66 c7 85 c8 fb ff ff 01 01   	mov	word ptr [ebp - 0x438], 0x101
  5771c1: 8b 11                        	mov	edx, dword ptr [ecx]
  5771c3: 8b 52 4c                     	mov	edx, dword ptr [edx + 0x4c]
  5771c6: 8d 85 c8 fb ff ff            	lea	eax, [ebp - 0x438]
  5771cc: 50                           	push	eax
  5771cd: ff d2                        	call	edx
  5771cf: 68 ba 15 01 00               	push	0x115ba
  5771d4: e8 87 40 cb 00               	call	0x122b260 <.text+0xcb4260>
  5771d9: 50                           	push	eax
  5771da: 8d 85 f0 fd ff ff            	lea	eax, [ebp - 0x210]
  5771e0: 68 00 02 00 00               	push	0x200
  5771e5: 50                           	push	eax
  5771e6: e8 15 2e e9 ff               	call	0x40a000
  5771eb: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5771f1: 8b 39                        	mov	edi, dword ptr [ecx]
  5771f3: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5771f9: 83 c4 10                     	add	esp, 0x10
  5771fc: 8d 95 f0 fd ff ff            	lea	edx, [ebp - 0x210]
  577202: 52                           	push	edx
  577203: 68 e6 c8 9b ff               	push	0xff9bc8e6
  577208: 68 96 00 00 00               	push	0x96
  57720d: 6a 00                        	push	0x0
  57720f: e8 bc d9 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577214: 8b c8                        	mov	ecx, eax
  577216: e8 65 cb c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  57721b: 8b 57 5c                     	mov	edx, dword ptr [edi + 0x5c]
  57721e: d1 e8                        	shr	eax
  577220: b9 95 01 00 00               	mov	ecx, 0x195
  577225: 2b c8                        	sub	ecx, eax
  577227: 51                           	push	ecx
  577228: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57722e: ff d2                        	call	edx
  577230: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577236: 8b 01                        	mov	eax, dword ptr [ecx]
  577238: 8b 50 50                     	mov	edx, dword ptr [eax + 0x50]
  57723b: ff d2                        	call	edx
  57723d: 68 e8 03 00 00               	push	0x3e8
  577242: ff 15 88 a5 55 01            	call	dword ptr [0x155a588]
  577248: 50                           	push	eax
  577249: 68 ff 00 00 00               	push	0xff
  57724e: 6a 00                        	push	0x0
  577250: e8 0b 27 c4 00               	call	0x11b9960 <.text+0xc42960>
  577255: 8b 8e fc 01 00 00            	mov	ecx, dword ptr [esi + 0x1fc]
  57725b: 83 c4 10                     	add	esp, 0x10
  57725e: 85 c9                        	test	ecx, ecx
  577260: 74 12                        	je	0x577274 <.text+0x274>
  577262: 8b 49 44                     	mov	ecx, dword ptr [ecx + 0x44]
  577265: 88 59 15                     	mov	byte ptr [ecx + 0x15], bl
  577268: 8b 8e fc 01 00 00            	mov	ecx, dword ptr [esi + 0x1fc]
  57726e: 8b 49 44                     	mov	ecx, dword ptr [ecx + 0x44]
  577271: 89 41 18                     	mov	dword ptr [ecx + 0x18], eax
  577274: b8 1f 85 eb 51               	mov	eax, 0x51eb851f
  577279: f7 ad e8 fb ff ff            	imul	dword ptr [ebp - 0x418]
  57727f: c1 fa 04                     	sar	edx, 0x4
  577282: 8b c2                        	mov	eax, edx
  577284: c1 e8 1f                     	shr	eax, 0x1f
  577287: 03 c2                        	add	eax, edx
  577289: b9 0a 00 00 00               	mov	ecx, 0xa
  57728e: 99                           	cdq
  57728f: f7 f9                        	idiv	ecx
  577291: 80 bd ef fb ff ff 00         	cmp	byte ptr [ebp - 0x411], 0x0
  577298: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  57729e: 74 69                        	je	0x577309 <.text+0x309>
  5772a0: 6a 18                        	push	0x18
  5772a2: 8b fa                        	mov	edi, edx
  5772a4: e8 27 d9 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5772a9: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5772af: 50                           	push	eax
  5772b0: 8d 57 78                     	lea	edx, [edi + 0x78]
  5772b3: 52                           	push	edx
  5772b4: 6a 32                        	push	0x32
  5772b6: e8 95 c6 c3 00               	call	0x11b3950 <.text+0xc3c950>
  5772bb: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5772c1: 6a 16                        	push	0x16
  5772c3: e8 08 d9 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5772c8: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5772ce: 50                           	push	eax
  5772cf: b8 45 01 00 00               	mov	eax, 0x145
  5772d4: 2b c7                        	sub	eax, edi
  5772d6: 50                           	push	eax
  5772d7: 6a 32                        	push	0x32
  5772d9: e8 72 c6 c3 00               	call	0x11b3950 <.text+0xc3c950>
  5772de: 8b b6 28 02 00 00            	mov	esi, dword ptr [esi + 0x228]
  5772e4: 85 f6                        	test	esi, esi
  5772e6: 74 73                        	je	0x57735b <.text+0x35b>
  5772e8: 8b 16                        	mov	edx, dword ptr [esi]
  5772ea: 8b 82 98 01 00 00            	mov	eax, dword ptr [edx + 0x198]
  5772f0: 6a 02                        	push	0x2
  5772f2: 6a 00                        	push	0x0
  5772f4: 68 9b ff 00 ff               	push	0xff00ff9b
  5772f9: 53                           	push	ebx
  5772fa: 8b ce                        	mov	ecx, esi
  5772fc: ff d0                        	call	eax
  5772fe: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  577304: e9 3d 07 00 00               	jmp	0x577a46 <.text+0xa46>
  577309: 6a 17                        	push	0x17
  57730b: 8d 7a 78                     	lea	edi, [edx + 0x78]
  57730e: e8 bd d8 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577313: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577319: 50                           	push	eax
  57731a: 57                           	push	edi
  57731b: 6a 32                        	push	0x32
  57731d: e8 2e c6 c3 00               	call	0x11b3950 <.text+0xc3c950>
  577322: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577328: 6a 15                        	push	0x15
  57732a: e8 a1 d8 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57732f: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577335: 50                           	push	eax
  577336: 57                           	push	edi
  577337: 6a 32                        	push	0x32
  577339: e8 12 c6 c3 00               	call	0x11b3950 <.text+0xc3c950>
  57733e: 8b b6 28 02 00 00            	mov	esi, dword ptr [esi + 0x228]
  577344: 85 f6                        	test	esi, esi
  577346: 74 13                        	je	0x57735b <.text+0x35b>
  577348: 8b 16                        	mov	edx, dword ptr [esi]
  57734a: 8b 82 98 01 00 00            	mov	eax, dword ptr [edx + 0x198]
  577350: 6a 02                        	push	0x2
  577352: 53                           	push	ebx
  577353: 6a 00                        	push	0x0
  577355: 6a 00                        	push	0x0
  577357: 8b ce                        	mov	ecx, esi
  577359: ff d0                        	call	eax
  57735b: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  577361: e9 e0 06 00 00               	jmp	0x577a46 <.text+0xa46>
  577366: 83 f8 03                     	cmp	eax, 0x3
  577369: 0f 85 80 02 00 00            	jne	0x5775ef <.text+0x5ef>
  57736f: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577375: 6a 00                        	push	0x0
  577377: e8 54 d8 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57737c: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577382: 50                           	push	eax
  577383: 6a 78                        	push	0x78
  577385: 6a 00                        	push	0x0
  577387: e8 44 d8 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57738c: 8b c8                        	mov	ecx, eax
  57738e: e8 ed c9 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  577393: d1 e8                        	shr	eax
  577395: b9 90 01 00 00               	mov	ecx, 0x190
  57739a: 2b c8                        	sub	ecx, eax
  57739c: 51                           	push	ecx
  57739d: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5773a3: e8 a8 c5 c3 00               	call	0x11b3950 <.text+0xc3c950>
  5773a8: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5773ae: 6a 1f                        	push	0x1f
  5773b0: e8 1b d8 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5773b5: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5773bb: 50                           	push	eax
  5773bc: 68 8c 00 00 00               	push	0x8c
  5773c1: 6a 05                        	push	0x5
  5773c3: e8 08 d8 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5773c8: 8b c8                        	mov	ecx, eax
  5773ca: e8 b1 c9 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  5773cf: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5773d5: d1 e8                        	shr	eax
  5773d7: ba 90 01 00 00               	mov	edx, 0x190
  5773dc: 2b d0                        	sub	edx, eax
  5773de: 52                           	push	edx
  5773df: e8 6c c5 c3 00               	call	0x11b3950 <.text+0xc3c950>
  5773e4: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  5773ea: e8 41 21 c5 00               	call	0x11c9530 <.text+0xc52530>
  5773ef: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  5773f5: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  5773f8: e8 13 21 c5 00               	call	0x11c9510 <.text+0xc52510>
  5773fd: a1 6c 65 b5 01               	mov	eax, dword ptr [0x1b5656c]
  577402: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577408: 6a 00                        	push	0x0
  57740a: 89 85 d0 fb ff ff            	mov	dword ptr [ebp - 0x430], eax
  577410: e8 bb d7 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577415: 8b c8                        	mov	ecx, eax
  577417: e8 64 c9 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  57741c: b9 04 00 00 00               	mov	ecx, 0x4
  577421: 83 e8 0a                     	sub	eax, 0xa
  577424: 66 89 8d cc fb ff ff         	mov	word ptr [ebp - 0x434], cx
  57742b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577431: 66 89 85 ca fb ff ff         	mov	word ptr [ebp - 0x436], ax
  577438: 88 9d ce fb ff ff            	mov	byte ptr [ebp - 0x432], bl
  57743e: 66 c7 85 c8 fb ff ff 01 01   	mov	word ptr [ebp - 0x438], 0x101
  577447: 8b 11                        	mov	edx, dword ptr [ecx]
  577449: 8b 52 4c                     	mov	edx, dword ptr [edx + 0x4c]
  57744c: 8d 85 c8 fb ff ff            	lea	eax, [ebp - 0x438]
  577452: 50                           	push	eax
  577453: ff d2                        	call	edx
  577455: 68 bc 15 01 00               	push	0x115bc
  57745a: e8 01 3e cb 00               	call	0x122b260 <.text+0xcb4260>
  57745f: 50                           	push	eax
  577460: 8d 85 f0 fd ff ff            	lea	eax, [ebp - 0x210]
  577466: 68 00 02 00 00               	push	0x200
  57746b: 50                           	push	eax
  57746c: e8 8f 2b e9 ff               	call	0x40a000
  577471: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577477: 8b 39                        	mov	edi, dword ptr [ecx]
  577479: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  57747f: 83 c4 10                     	add	esp, 0x10
  577482: 8d 95 f0 fd ff ff            	lea	edx, [ebp - 0x210]
  577488: 52                           	push	edx
  577489: 68 e6 c8 9b ff               	push	0xff9bc8e6
  57748e: 68 b9 00 00 00               	push	0xb9
  577493: 6a 00                        	push	0x0
  577495: e8 36 d7 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57749a: 8b c8                        	mov	ecx, eax
  57749c: e8 df c8 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  5774a1: d1 e8                        	shr	eax
  5774a3: b9 95 01 00 00               	mov	ecx, 0x195
  5774a8: 2b c8                        	sub	ecx, eax
  5774aa: 51                           	push	ecx
  5774ab: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5774b1: 8b 57 5c                     	mov	edx, dword ptr [edi + 0x5c]
  5774b4: ff d2                        	call	edx
  5774b6: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5774bc: 8b 01                        	mov	eax, dword ptr [ecx]
  5774be: 8b 50 50                     	mov	edx, dword ptr [eax + 0x50]
  5774c1: ff d2                        	call	edx
  5774c3: 33 ff                        	xor	edi, edi
  5774c5: 39 be 90 03 00 00            	cmp	dword ptr [esi + 0x390], edi
  5774cb: 0f 86 a3 00 00 00            	jbe	0x577574 <.text+0x574>
  5774d1: 57                           	push	edi
  5774d2: 8d 85 9c fb ff ff            	lea	eax, [ebp - 0x464]
  5774d8: 50                           	push	eax
  5774d9: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  5774df: e8 5c d7 f2 ff               	call	0x4a4c40
  5774e4: 8b c8                        	mov	ecx, eax
  5774e6: e8 95 bf f2 ff               	call	0x4a3480
  5774eb: 84 c0                        	test	al, al
  5774ed: 0f 85 81 00 00 00            	jne	0x577574 <.text+0x574>
  5774f3: 89 bd e4 fb ff ff            	mov	dword ptr [ebp - 0x41c], edi
  5774f9: 89 bd e8 fb ff ff            	mov	dword ptr [ebp - 0x418], edi
  5774ff: 90                           	nop
  577500: 80 bd ef fb ff ff 00         	cmp	byte ptr [ebp - 0x411], 0x0
  577507: 74 59                        	je	0x577562 <.text+0x562>
  577509: 8b 0d 50 f7 a6 01            	mov	ecx, dword ptr [0x1a6f750]
  57750f: 8b 49 3c                     	mov	ecx, dword ptr [ecx + 0x3c]
  577512: 8d 95 e8 fb ff ff            	lea	edx, [ebp - 0x418]
  577518: 52                           	push	edx
  577519: 8d 85 e4 fb ff ff            	lea	eax, [ebp - 0x41c]
  57751f: 50                           	push	eax
  577520: 57                           	push	edi
  577521: e8 3a 50 f4 ff               	call	0x4bc560
  577526: 84 c0                        	test	al, al
  577528: 74 38                        	je	0x577562 <.text+0x562>
  57752a: 6a 00                        	push	0x0
  57752c: 6a 02                        	push	0x2
  57752e: e8 2d bf c3 00               	call	0x11b3460 <.text+0xc3c460>
  577533: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577539: 83 c4 08                     	add	esp, 0x8
  57753c: 6a 12                        	push	0x12
  57753e: e8 8d d6 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577543: 8b 8d e8 fb ff ff            	mov	ecx, dword ptr [ebp - 0x418]
  577549: 8b 95 e4 fb ff ff            	mov	edx, dword ptr [ebp - 0x41c]
  57754f: 50                           	push	eax
  577550: 51                           	push	ecx
  577551: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577557: 52                           	push	edx
  577558: e8 f3 c3 c3 00               	call	0x11b3950 <.text+0xc3c950>
  57755d: e8 0e c0 c3 00               	call	0x11b3570 <.text+0xc3c570>
  577562: 03 fb                        	add	edi, ebx
  577564: 83 ff 06                     	cmp	edi, 0x6
  577567: 7c 97                        	jl	0x577500 <.text+0x500>
  577569: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  57756f: e9 d2 04 00 00               	jmp	0x577a46 <.text+0xa46>
  577574: bb 04 00 00 00               	mov	ebx, 0x4
  577579: 39 9e 6c 03 00 00            	cmp	dword ptr [esi + 0x36c], ebx
  57757f: 74 63                        	je	0x5775e4 <.text+0x5e4>
  577581: 80 be 94 03 00 00 00         	cmp	byte ptr [esi + 0x394], 0x0
  577588: 74 5a                        	je	0x5775e4 <.text+0x5e4>
  57758a: e8 81 ee 18 00               	call	0x706410 <.text+0x18f410>
  57758f: 8b 80 e0 00 00 00            	mov	eax, dword ptr [eax + 0xe0]
  577595: 39 78 1c                     	cmp	dword ptr [eax + 0x1c], edi
  577598: 75 4a                        	jne	0x5775e4 <.text+0x5e4>
  57759a: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  5775a0: 89 9e 6c 03 00 00            	mov	dword ptr [esi + 0x36c], ebx
  5775a6: e8 15 eb ff ff               	call	0x5760c0
  5775ab: 80 be 96 03 00 00 00         	cmp	byte ptr [esi + 0x396], 0x0
  5775b2: 74 30                        	je	0x5775e4 <.text+0x5e4>
  5775b4: e8 57 ee 18 00               	call	0x706410 <.text+0x18f410>
  5775b9: 8b 88 e0 00 00 00            	mov	ecx, dword ptr [eax + 0xe0]
  5775bf: 8d 49 20                     	lea	ecx, [ecx + 0x20]
  5775c2: e8 79 30 c4 00               	call	0x11ba640 <.text+0xc43640>
  5775c7: 89 86 70 03 00 00            	mov	dword ptr [esi + 0x370], eax
  5775cd: 05 20 4e 00 00               	add	eax, 0x4e20
  5775d2: 57                           	push	edi
  5775d3: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  5775d9: 89 86 74 03 00 00            	mov	dword ptr [esi + 0x374], eax
  5775df: e8 1c f5 f2 ff               	call	0x4a6b00
  5775e4: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  5775ea: e9 57 04 00 00               	jmp	0x577a46 <.text+0xa46>
  5775ef: 83 f8 04                     	cmp	eax, 0x4
  5775f2: 0f 85 34 02 00 00            	jne	0x57782c <.text+0x82c>
  5775f8: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5775fe: 6a 00                        	push	0x0
  577600: e8 cb d5 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577605: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  57760b: 50                           	push	eax
  57760c: 6a 78                        	push	0x78
  57760e: 6a 00                        	push	0x0
  577610: e8 bb d5 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577615: 8b c8                        	mov	ecx, eax
  577617: e8 64 c7 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  57761c: d1 e8                        	shr	eax
  57761e: b9 90 01 00 00               	mov	ecx, 0x190
  577623: 2b c8                        	sub	ecx, eax
  577625: 51                           	push	ecx
  577626: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57762c: e8 1f c3 c3 00               	call	0x11b3950 <.text+0xc3c950>
  577631: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577637: 6a 1e                        	push	0x1e
  577639: e8 92 d5 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57763e: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577644: 50                           	push	eax
  577645: 68 8c 00 00 00               	push	0x8c
  57764a: 6a 05                        	push	0x5
  57764c: e8 7f d5 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577651: 8b c8                        	mov	ecx, eax
  577653: e8 28 c7 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  577658: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57765e: d1 e8                        	shr	eax
  577660: ba 90 01 00 00               	mov	edx, 0x190
  577665: 2b d0                        	sub	edx, eax
  577667: 52                           	push	edx
  577668: e8 e3 c2 c3 00               	call	0x11b3950 <.text+0xc3c950>
  57766d: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  577673: e8 b8 1e c5 00               	call	0x11c9530 <.text+0xc52530>
  577678: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  57767e: c7 45 fc 02 00 00 00         	mov	dword ptr [ebp - 0x4], 0x2
  577685: e8 86 1e c5 00               	call	0x11c9510 <.text+0xc52510>
  57768a: a1 6c 65 b5 01               	mov	eax, dword ptr [0x1b5656c]
  57768f: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577695: 6a 00                        	push	0x0
  577697: 89 85 d0 fb ff ff            	mov	dword ptr [ebp - 0x430], eax
  57769d: e8 2e d5 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5776a2: 8b c8                        	mov	ecx, eax
  5776a4: e8 d7 c6 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  5776a9: b9 04 00 00 00               	mov	ecx, 0x4
  5776ae: 83 e8 0a                     	sub	eax, 0xa
  5776b1: 66 89 8d cc fb ff ff         	mov	word ptr [ebp - 0x434], cx
  5776b8: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5776be: 66 89 85 ca fb ff ff         	mov	word ptr [ebp - 0x436], ax
  5776c5: 88 9d ce fb ff ff            	mov	byte ptr [ebp - 0x432], bl
  5776cb: 66 c7 85 c8 fb ff ff 01 01   	mov	word ptr [ebp - 0x438], 0x101
  5776d4: 8b 11                        	mov	edx, dword ptr [ecx]
  5776d6: 8b 52 4c                     	mov	edx, dword ptr [edx + 0x4c]
  5776d9: 8d 85 c8 fb ff ff            	lea	eax, [ebp - 0x438]
  5776df: 50                           	push	eax
  5776e0: ff d2                        	call	edx
  5776e2: 68 bb 15 01 00               	push	0x115bb
  5776e7: e8 74 3b cb 00               	call	0x122b260 <.text+0xcb4260>
  5776ec: 50                           	push	eax
  5776ed: 8d 85 f0 fd ff ff            	lea	eax, [ebp - 0x210]
  5776f3: 68 00 02 00 00               	push	0x200
  5776f8: 50                           	push	eax
  5776f9: e8 02 29 e9 ff               	call	0x40a000
  5776fe: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577704: 8b 39                        	mov	edi, dword ptr [ecx]
  577706: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  57770c: 83 c4 10                     	add	esp, 0x10
  57770f: 8d 95 f0 fd ff ff            	lea	edx, [ebp - 0x210]
  577715: 52                           	push	edx
  577716: 68 e6 c8 9b ff               	push	0xff9bc8e6
  57771b: 68 b9 00 00 00               	push	0xb9
  577720: 6a 00                        	push	0x0
  577722: e8 a9 d4 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577727: 8b c8                        	mov	ecx, eax
  577729: e8 52 c6 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  57772e: d1 e8                        	shr	eax
  577730: b9 95 01 00 00               	mov	ecx, 0x195
  577735: 2b c8                        	sub	ecx, eax
  577737: 51                           	push	ecx
  577738: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57773e: 8b 57 5c                     	mov	edx, dword ptr [edi + 0x5c]
  577741: ff d2                        	call	edx
  577743: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577749: 8b 01                        	mov	eax, dword ptr [ecx]
  57774b: 8b 50 50                     	mov	edx, dword ptr [eax + 0x50]
  57774e: ff d2                        	call	edx
  577750: 6a 00                        	push	0x0
  577752: 8d 85 9c fb ff ff            	lea	eax, [ebp - 0x464]
  577758: 50                           	push	eax
  577759: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  57775f: e8 dc d4 f2 ff               	call	0x4a4c40
  577764: 8b c8                        	mov	ecx, eax
  577766: e8 15 bd f2 ff               	call	0x4a3480
  57776b: 84 c0                        	test	al, al
  57776d: 0f 94 c0                     	sete	al
  577770: 84 c0                        	test	al, al
  577772: 0f 84 82 00 00 00            	je	0x5777fa <.text+0x7fa>
  577778: 33 ff                        	xor	edi, edi
  57777a: 89 bd e8 fb ff ff            	mov	dword ptr [ebp - 0x418], edi
  577780: 89 bd e4 fb ff ff            	mov	dword ptr [ebp - 0x41c], edi
  577786: 80 bd ef fb ff ff 00         	cmp	byte ptr [ebp - 0x411], 0x0
  57778d: 74 59                        	je	0x5777e8 <.text+0x7e8>
  57778f: 8b 0d 50 f7 a6 01            	mov	ecx, dword ptr [0x1a6f750]
  577795: 8b 49 3c                     	mov	ecx, dword ptr [ecx + 0x3c]
  577798: 8d 95 e4 fb ff ff            	lea	edx, [ebp - 0x41c]
  57779e: 52                           	push	edx
  57779f: 8d 85 e8 fb ff ff            	lea	eax, [ebp - 0x418]
  5777a5: 50                           	push	eax
  5777a6: 57                           	push	edi
  5777a7: e8 74 4d f4 ff               	call	0x4bc520
  5777ac: 84 c0                        	test	al, al
  5777ae: 74 38                        	je	0x5777e8 <.text+0x7e8>
  5777b0: 6a 00                        	push	0x0
  5777b2: 6a 02                        	push	0x2
  5777b4: e8 a7 bc c3 00               	call	0x11b3460 <.text+0xc3c460>
  5777b9: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5777bf: 83 c4 08                     	add	esp, 0x8
  5777c2: 6a 12                        	push	0x12
  5777c4: e8 07 d4 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5777c9: 8b 8d e4 fb ff ff            	mov	ecx, dword ptr [ebp - 0x41c]
  5777cf: 8b 95 e8 fb ff ff            	mov	edx, dword ptr [ebp - 0x418]
  5777d5: 50                           	push	eax
  5777d6: 51                           	push	ecx
  5777d7: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5777dd: 52                           	push	edx
  5777de: e8 6d c1 c3 00               	call	0x11b3950 <.text+0xc3c950>
  5777e3: e8 88 bd c3 00               	call	0x11b3570 <.text+0xc3c570>
  5777e8: 03 fb                        	add	edi, ebx
  5777ea: 83 ff 06                     	cmp	edi, 0x6
  5777ed: 7c 97                        	jl	0x577786 <.text+0x786>
  5777ef: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  5777f5: e9 4c 02 00 00               	jmp	0x577a46 <.text+0xa46>
  5777fa: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  577800: c7 86 6c 03 00 00 00 00 00 00	mov	dword ptr [esi + 0x36c], 0x0
  57780a: e8 b1 e8 ff ff               	call	0x5760c0
  57780f: 83 c8 ff                     	or	eax, -0x1
  577812: 89 86 70 03 00 00            	mov	dword ptr [esi + 0x370], eax
  577818: 89 86 74 03 00 00            	mov	dword ptr [esi + 0x374], eax
  57781e: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  577821: 8d 8d c8 fb ff ff            	lea	ecx, [ebp - 0x438]
  577827: e9 21 02 00 00               	jmp	0x577a4d <.text+0xa4d>
  57782c: 83 f8 02                     	cmp	eax, 0x2
  57782f: 0f 85 1d 02 00 00            	jne	0x577a52 <.text+0xa52>
  577835: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  57783b: 6a 04                        	push	0x4
  57783d: e8 8e d3 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577842: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577848: 50                           	push	eax
  577849: 68 8b 01 00 00               	push	0x18b
  57784e: 6a 7d                        	push	0x7d
  577850: e8 fb c0 c3 00               	call	0x11b3950 <.text+0xc3c950>
  577855: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  57785b: 6a 08                        	push	0x8
  57785d: e8 6e d3 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577862: 50                           	push	eax
  577863: b8 1f 85 eb 51               	mov	eax, 0x51eb851f
  577868: f7 ef                        	imul	edi
  57786a: c1 fa 04                     	sar	edx, 0x4
  57786d: 8b c2                        	mov	eax, edx
  57786f: c1 e8 1f                     	shr	eax, 0x1f
  577872: 03 c2                        	add	eax, edx
  577874: 99                           	cdq
  577875: b9 0a 00 00 00               	mov	ecx, 0xa
  57787a: f7 f9                        	idiv	ecx
  57787c: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577882: 81 c2 c7 01 00 00            	add	edx, 0x1c7
  577888: 52                           	push	edx
  577889: 6a 7d                        	push	0x7d
  57788b: e8 c0 c0 c3 00               	call	0x11b3950 <.text+0xc3c950>
  577890: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577896: 6a 00                        	push	0x0
  577898: e8 33 d3 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  57789d: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5778a3: 50                           	push	eax
  5778a4: 6a 3c                        	push	0x3c
  5778a6: 6a 00                        	push	0x0
  5778a8: e8 23 d3 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5778ad: 8b c8                        	mov	ecx, eax
  5778af: e8 cc c4 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  5778b4: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5778ba: d1 e8                        	shr	eax
  5778bc: ba 90 01 00 00               	mov	edx, 0x190
  5778c1: 2b d0                        	sub	edx, eax
  5778c3: 52                           	push	edx
  5778c4: e8 87 c0 c3 00               	call	0x11b3950 <.text+0xc3c950>
  5778c9: 8d 8d ac fb ff ff            	lea	ecx, [ebp - 0x454]
  5778cf: e8 5c 1c c5 00               	call	0x11c9530 <.text+0xc52530>
  5778d4: 8d 8d ac fb ff ff            	lea	ecx, [ebp - 0x454]
  5778da: c7 45 fc 03 00 00 00         	mov	dword ptr [ebp - 0x4], 0x3
  5778e1: e8 2a 1c c5 00               	call	0x11c9510 <.text+0xc52510>
  5778e6: a1 6c 65 b5 01               	mov	eax, dword ptr [0x1b5656c]
  5778eb: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  5778f1: 6a 00                        	push	0x0
  5778f3: 89 85 b4 fb ff ff            	mov	dword ptr [ebp - 0x44c], eax
  5778f9: e8 d2 d2 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  5778fe: 8b c8                        	mov	ecx, eax
  577900: e8 7b c4 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  577905: b9 04 00 00 00               	mov	ecx, 0x4
  57790a: 83 e8 0a                     	sub	eax, 0xa
  57790d: 66 89 8d b0 fb ff ff         	mov	word ptr [ebp - 0x450], cx
  577914: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57791a: 66 89 85 ae fb ff ff         	mov	word ptr [ebp - 0x452], ax
  577921: 88 9d b2 fb ff ff            	mov	byte ptr [ebp - 0x44e], bl
  577927: 66 c7 85 ac fb ff ff 01 01   	mov	word ptr [ebp - 0x454], 0x101
  577930: 8b 11                        	mov	edx, dword ptr [ecx]
  577932: 8b 52 4c                     	mov	edx, dword ptr [edx + 0x4c]
  577935: 8d 85 ac fb ff ff            	lea	eax, [ebp - 0x454]
  57793b: 50                           	push	eax
  57793c: ff d2                        	call	edx
  57793e: 68 bd 15 01 00               	push	0x115bd
  577943: e8 18 39 cb 00               	call	0x122b260 <.text+0xcb4260>
  577948: 50                           	push	eax
  577949: 8d 85 f0 fb ff ff            	lea	eax, [ebp - 0x410]
  57794f: 68 00 02 00 00               	push	0x200
  577954: 50                           	push	eax
  577955: e8 a6 26 e9 ff               	call	0x40a000
  57795a: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  577960: 8b 39                        	mov	edi, dword ptr [ecx]
  577962: 83 c4 10                     	add	esp, 0x10
  577965: 8d 95 f0 fb ff ff            	lea	edx, [ebp - 0x410]
  57796b: 52                           	push	edx
  57796c: 68 e6 c8 9b ff               	push	0xff9bc8e6
  577971: 6a 64                        	push	0x64
  577973: 8b 8e 9c 03 00 00            	mov	ecx, dword ptr [esi + 0x39c]
  577979: 6a 00                        	push	0x0
  57797b: e8 50 d2 c3 00               	call	0x11b4bd0 <.text+0xc3dbd0>
  577980: 8b c8                        	mov	ecx, eax
  577982: e8 f9 c3 c3 00               	call	0x11b3d80 <.text+0xc3cd80>
  577987: 8b 57 5c                     	mov	edx, dword ptr [edi + 0x5c]
  57798a: d1 e8                        	shr	eax
  57798c: b9 95 01 00 00               	mov	ecx, 0x195
  577991: 2b c8                        	sub	ecx, eax
  577993: 51                           	push	ecx
  577994: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  57799a: ff d2                        	call	edx
  57799c: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
  5779a2: 8b 01                        	mov	eax, dword ptr [ecx]
  5779a4: 8b 50 50                     	mov	edx, dword ptr [eax + 0x50]
  5779a7: ff d2                        	call	edx
  5779a9: 68 e8 03 00 00               	push	0x3e8
  5779ae: ff 15 88 a5 55 01            	call	dword ptr [0x155a588]
  5779b4: 50                           	push	eax
  5779b5: 68 ff 00 00 00               	push	0xff
  5779ba: 6a 00                        	push	0x0
  5779bc: e8 9f 1f c4 00               	call	0x11b9960 <.text+0xc42960>
  5779c1: 8b 8e fc 01 00 00            	mov	ecx, dword ptr [esi + 0x1fc]
  5779c7: 83 c4 10                     	add	esp, 0x10
  5779ca: 85 c9                        	test	ecx, ecx
  5779cc: 74 12                        	je	0x5779e0 <.text+0x9e0>
  5779ce: 8b 49 40                     	mov	ecx, dword ptr [ecx + 0x40]
  5779d1: 88 59 55                     	mov	byte ptr [ecx + 0x55], bl
  5779d4: 8b 8e fc 01 00 00            	mov	ecx, dword ptr [esi + 0x1fc]
  5779da: 8b 49 40                     	mov	ecx, dword ptr [ecx + 0x40]
  5779dd: 89 41 58                     	mov	dword ptr [ecx + 0x58], eax
  5779e0: 6a 00                        	push	0x0
  5779e2: 8d 95 9c fb ff ff            	lea	edx, [ebp - 0x464]
  5779e8: 52                           	push	edx
  5779e9: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  5779ef: e8 4c d2 f2 ff               	call	0x4a4c40
  5779f4: 8b c8                        	mov	ecx, eax
  5779f6: e8 85 ba f2 ff               	call	0x4a3480
  5779fb: 3a c3                        	cmp	al, bl
  5779fd: 0f 94 c0                     	sete	al
  577a00: 84 c0                        	test	al, al
  577a02: 74 3c                        	je	0x577a40 <.text+0xa40>
  577a04: 8b 86 fc 01 00 00            	mov	eax, dword ptr [esi + 0x1fc]
  577a0a: 8b 40 40                     	mov	eax, dword ptr [eax + 0x40]
  577a0d: c6 40 55 00                  	mov	byte ptr [eax + 0x55], 0x0
  577a11: 8d 8e 78 03 00 00            	lea	ecx, [esi + 0x378]
  577a17: c7 86 6c 03 00 00 00 00 00 00	mov	dword ptr [esi + 0x36c], 0x0
  577a21: e8 9a e6 ff ff               	call	0x5760c0
  577a26: 83 c8 ff                     	or	eax, -0x1
  577a29: 89 86 70 03 00 00            	mov	dword ptr [esi + 0x370], eax
  577a2f: 89 86 74 03 00 00            	mov	dword ptr [esi + 0x374], eax
  577a35: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  577a38: 8d 8d ac fb ff ff            	lea	ecx, [ebp - 0x454]
  577a3e: eb 0d                        	jmp	0x577a4d <.text+0xa4d>
  577a40: 8d 8d ac fb ff ff            	lea	ecx, [ebp - 0x454]
  577a46: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  577a4d: e8 de 29 be 00               	call	0x115a430 <.text+0xbe3430>
  577a52: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  577a55: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  577a5c: 59                           	pop	ecx
  577a5d: 5f                           	pop	edi
  577a5e: 5e                           	pop	esi
  577a5f: 5b                           	pop	ebx
  577a60: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  577a63: 33 cd                        	xor	ecx, ebp
  577a65: e8 6e f7 e5 00               	call	0x13d71d8 <.text+0xe601d8>
  577a6a: 8b e5                        	mov	esp, ebp
  577a6c: 5d                           	pop	ebp
  577a6d: c3                           	ret
  577a6e: cc                           	int3
  577a6f: cc                           	int3
  577a70: 55                           	push	ebp
  577a71: 8b ec                        	mov	ebp, esp
  577a73: 6a ff                        	push	-0x1
  577a75: 68 e9 ce 41 01               	push	0x141cee9
  577a7a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  577a80: 50                           	push	eax
  577a81: 83 ec 08                     	sub	esp, 0x8
  577a84: 56                           	push	esi
  577a85: 57                           	push	edi
  577a86: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  577a8b: 33 c5                        	xor	eax, ebp
  577a8d: 50                           	push	eax
  577a8e: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  577a91: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  577a97: 8b f1                        	mov	esi, ecx
  577a99: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  577a9c: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  577aa3: 8d 7e 38                     	lea	edi, [esi + 0x38]
  577aa6: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  577aa9: 8b cf                        	mov	ecx, edi
  577aab: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  577aaf: e8 6c 4c f2 ff               	call	0x49c720
  577ab4: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  577ab7: 50                           	push	eax
  577ab8: e8 6a e0 e5 00               	call	0x13d5b27 <.text+0xe5eb27>
  577abd: 8b 07                        	mov	eax, dword ptr [edi]
  577abf: 50                           	push	eax
  577ac0: e8 62 e0 e5 00               	call	0x13d5b27 <.text+0xe5eb27>
  577ac5: c7 07 00 00 00 00            	mov	dword ptr [edi], 0x0
  577acb: 8d 7e 24                     	lea	edi, [esi + 0x24]
  577ace: 83 c4 08                     	add	esp, 0x8
  577ad1: 89 7d ec                     	mov	dword ptr [ebp - 0x14], edi
  577ad4: 8b cf                        	mov	ecx, edi
  577ad6: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
  577ada: e8 41 4c f2 ff               	call	0x49c720
  577adf: 8b 47 08                     	mov	eax, dword ptr [edi + 0x8]
  577ae2: 50                           	push	eax
  577ae3: e8 3f e0 e5 00               	call	0x13d5b27 <.text+0xe5eb27>
  577ae8: 8b 07                        	mov	eax, dword ptr [edi]
  577aea: 50                           	push	eax
  577aeb: e8 37 e0 e5 00               	call	0x13d5b27 <.text+0xe5eb27>
  577af0: 83 c4 08                     	add	esp, 0x8
  577af3: 8d 4e 18                     	lea	ecx, [esi + 0x18]
  577af6: c7 07 00 00 00 00            	mov	dword ptr [edi], 0x0
  577afc: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  577b00: e8 bb 91 c2 00               	call	0x11a0cc0 <.text+0xc29cc0>
  577b05: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  577b08: c6 45 fc 00                  	mov	byte ptr [ebp - 0x4], 0x0
  577b0c: e8 af 91 c2 00               	call	0x11a0cc0 <.text+0xc29cc0>
  577b11: 8b ce                        	mov	ecx, esi
  577b13: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  577b1a: e8 a1 91 c2 00               	call	0x11a0cc0 <.text+0xc29cc0>
  577b1f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  577b22: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  577b29: 59                           	pop	ecx
  577b2a: 5f                           	pop	edi
  577b2b: 5e                           	pop	esi
  577b2c: 8b e5                        	mov	esp, ebp
  577b2e: 5d                           	pop	ebp
  577b2f: c3                           	ret
  577b30: 55                           	push	ebp
  577b31: 8b ec                        	mov	ebp, esp
  577b33: 6a ff                        	push	-0x1
  577b35: 68 51 cf 41 01               	push	0x141cf51
  577b3a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  577b40: 50                           	push	eax
  577b41: 83 ec 0c                     	sub	esp, 0xc
  577b44: 53                           	push	ebx
  577b45: 56                           	push	esi
  577b46: 57                           	push	edi
  577b47: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  577b4c: 33 c5                        	xor	eax, ebp
  577b4e: 50                           	push	eax
  577b4f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  577b52: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  577b58: 8b f1                        	mov	esi, ecx
  577b5a: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  577b5d: e8 0e a9 c2 00               	call	0x11a2470 <.text+0xc2b470>
  577b62: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  577b65: 8d 45 08                     	lea	eax, [ebp + 0x8]
  577b68: 50                           	push	eax
  577b69: 8d 4f 08                     	lea	ecx, [edi + 0x8]
  577b6c: 51                           	push	ecx
  577b6d: 8b cf                        	mov	ecx, edi
  577b6f: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  577b76: e8 65 92 c2 00               	call	0x11a0de0 <.text+0xc29de0>
  577b7b: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
  577b7e: 8d 46 08                     	lea	eax, [esi + 0x8]
  577b81: 50                           	push	eax
  577b82: 8d 4d f0                     	lea	ecx, [ebp - 0x10]
  577b85: 51                           	push	ecx
  577b86: 8b ce                        	mov	ecx, esi
  577b88: 89 55 f0                     	mov	dword ptr [ebp - 0x10], edx
  577b8b: e8 a0 8d c2 00               	call	0x11a0930 <.text+0xc29930>
  577b90: 8d 5e 0c                     	lea	ebx, [esi + 0xc]
  577b93: 8b cb                        	mov	ecx, ebx
  577b95: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
  577b9c: 89 5d e8                     	mov	dword ptr [ebp - 0x18], ebx
  577b9f: e8 cc a8 c2 00               	call	0x11a2470 <.text+0xc2b470>
  577ba4: 8d 55 08                     	lea	edx, [ebp + 0x8]
  577ba7: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  577baa: 52                           	push	edx
  577bab: 8d 41 08                     	lea	eax, [ecx + 0x8]
  577bae: 50                           	push	eax
  577baf: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  577bb3: e8 28 92 c2 00               	call	0x11a0de0 <.text+0xc29de0>
  577bb8: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  577bbb: 8d 53 08                     	lea	edx, [ebx + 0x8]
  577bbe: 52                           	push	edx
  577bbf: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  577bc2: 89 4d f0                     	mov	dword ptr [ebp - 0x10], ecx
  577bc5: 50                           	push	eax
  577bc6: 8b cb                        	mov	ecx, ebx
  577bc8: e8 63 8d c2 00               	call	0x11a0930 <.text+0xc29930>
  577bcd: 8d 5e 18                     	lea	ebx, [esi + 0x18]
  577bd0: 8b cb                        	mov	ecx, ebx
  577bd2: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  577bd6: 89 5d e8                     	mov	dword ptr [ebp - 0x18], ebx
  577bd9: e8 92 a8 c2 00               	call	0x11a2470 <.text+0xc2b470>
  577bde: 8d 4d 08                     	lea	ecx, [ebp + 0x8]
  577be1: 51                           	push	ecx
  577be2: 8d 4f 18                     	lea	ecx, [edi + 0x18]
  577be5: 8d 51 08                     	lea	edx, [ecx + 0x8]
  577be8: 52                           	push	edx
  577be9: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  577bed: e8 ee 91 c2 00               	call	0x11a0de0 <.text+0xc29de0>
  577bf2: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  577bf5: 8d 4b 08                     	lea	ecx, [ebx + 0x8]
  577bf8: 51                           	push	ecx
  577bf9: 8d 55 f0                     	lea	edx, [ebp - 0x10]
  577bfc: 52                           	push	edx
  577bfd: 8b cb                        	mov	ecx, ebx
  577bff: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  577c02: e8 29 8d c2 00               	call	0x11a0930 <.text+0xc29930>
  577c07: 8d 47 24                     	lea	eax, [edi + 0x24]
  577c0a: 8d 4e 24                     	lea	ecx, [esi + 0x24]
  577c0d: 50                           	push	eax
  577c0e: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
  577c12: e8 c9 e9 ff ff               	call	0x5765e0
  577c17: 83 c7 38                     	add	edi, 0x38
  577c1a: 57                           	push	edi
  577c1b: 8d 4e 38                     	lea	ecx, [esi + 0x38]
  577c1e: c6 45 fc 06                  	mov	byte ptr [ebp - 0x4], 0x6
  577c22: e8 b9 e9 ff ff               	call	0x5765e0
  577c27: 8b c6                        	mov	eax, esi
  577c29: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  577c2c: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  577c33: 59                           	pop	ecx
  577c34: 5f                           	pop	edi
  577c35: 5e                           	pop	esi
  577c36: 5b                           	pop	ebx
  577c37: 8b e5                        	mov	esp, ebp
  577c39: 5d                           	pop	ebp
  577c3a: c2 04 00                     	ret	0x4
  577c3d: cc                           	int3
  577c3e: cc                           	int3
  577c3f: cc                           	int3
  577c40: 55                           	push	ebp
  577c41: 8b ec                        	mov	ebp, esp
  577c43: 83 ec 20                     	sub	esp, 0x20
  577c46: 53                           	push	ebx
  577c47: 33 db                        	xor	ebx, ebx
  577c49: 56                           	push	esi
  577c4a: 8b f1                        	mov	esi, ecx
  577c4c: 57                           	push	edi
  577c4d: 8b 7d 18                     	mov	edi, dword ptr [ebp + 0x18]
  577c50: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  577c53: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
  577c56: 89 5d f4                     	mov	dword ptr [ebp - 0xc], ebx
  577c59: 89 5d f8                     	mov	dword ptr [ebp - 0x8], ebx
  577c5c: 39 5e 0c                     	cmp	dword ptr [esi + 0xc], ebx
  577c5f: 75 1b                        	jne	0x577c7c <.text+0xc7c>
  577c61: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  577c64: 57                           	push	edi
  577c65: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  577c68: 50                           	push	eax
  577c69: 6a 01                        	push	0x1
  577c6b: 57                           	push	edi
  577c6c: e8 7f ea ff ff               	call	0x5766f0
  577c71: 8b c7                        	mov	eax, edi
  577c73: 5f                           	pop	edi
  577c74: 5e                           	pop	esi
  577c75: 5b                           	pop	ebx
  577c76: 8b e5                        	mov	esp, ebp
  577c78: 5d                           	pop	ebp
  577c79: c2 14 00                     	ret	0x14
  577c7c: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  577c7f: 51                           	push	ecx
  577c80: 8b ce                        	mov	ecx, esi
  577c82: e8 c9 81 fe ff               	call	0x55fe50
  577c87: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  577c8a: 3b cb                        	cmp	ecx, ebx
  577c8c: 0f 84 c3 01 00 00            	je	0x577e55 <.text+0xe55>
  577c92: 8b 11                        	mov	edx, dword ptr [ecx]
  577c94: 3b d3                        	cmp	edx, ebx
  577c96: 0f 84 b9 01 00 00            	je	0x577e55 <.text+0xe55>
  577c9c: 8b 08                        	mov	ecx, dword ptr [eax]
  577c9e: 3b cb                        	cmp	ecx, ebx
  577ca0: 75 04                        	jne	0x577ca6 <.text+0xca6>
  577ca2: 33 c9                        	xor	ecx, ecx
  577ca4: eb 02                        	jmp	0x577ca8 <.text+0xca8>
  577ca6: 8b 09                        	mov	ecx, dword ptr [ecx]
  577ca8: 3b d1                        	cmp	edx, ecx
  577caa: 0f 85 a5 01 00 00            	jne	0x577e55 <.text+0xe55>
  577cb0: 8b 5d 14                     	mov	ebx, dword ptr [ebp + 0x14]
  577cb3: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
  577cb6: 75 26                        	jne	0x577cde <.text+0xcde>
  577cb8: 8b 57 0c                     	mov	edx, dword ptr [edi + 0xc]
  577cbb: 3b 53 0c                     	cmp	edx, dword ptr [ebx + 0xc]
  577cbe: 0f 8d 52 01 00 00            	jge	0x577e16 <.text+0xe16>
  577cc4: 57                           	push	edi
  577cc5: 53                           	push	ebx
  577cc6: 6a 01                        	push	0x1
  577cc8: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  577ccb: 8b ce                        	mov	ecx, esi
  577ccd: 57                           	push	edi
  577cce: e8 1d ea ff ff               	call	0x5766f0
  577cd3: 8b c7                        	mov	eax, edi
  577cd5: 5f                           	pop	edi
  577cd6: 5e                           	pop	esi
  577cd7: 5b                           	pop	ebx
  577cd8: 8b e5                        	mov	esp, ebp
  577cda: 5d                           	pop	ebp
  577cdb: c2 14 00                     	ret	0x14
  577cde: 8d 45 e4                     	lea	eax, [ebp - 0x1c]
  577ce1: 50                           	push	eax
  577ce2: 8b ce                        	mov	ecx, esi
  577ce4: e8 57 c6 24 00               	call	0x7c4340 <.text+0x24d340>
  577ce9: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  577cec: 8b 09                        	mov	ecx, dword ptr [ecx]
  577cee: 85 c9                        	test	ecx, ecx
  577cf0: 0f 84 5f 01 00 00            	je	0x577e55 <.text+0xe55>
  577cf6: 8b 10                        	mov	edx, dword ptr [eax]
  577cf8: 85 d2                        	test	edx, edx
  577cfa: 74 02                        	je	0x577cfe <.text+0xcfe>
  577cfc: 8b 12                        	mov	edx, dword ptr [edx]
  577cfe: 3b ca                        	cmp	ecx, edx
  577d00: 0f 85 4f 01 00 00            	jne	0x577e55 <.text+0xe55>
  577d06: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
  577d09: 75 18                        	jne	0x577d23 <.text+0xd23>
  577d0b: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  577d0e: 8b 42 08                     	mov	eax, dword ptr [edx + 0x8]
  577d11: 8b 48 0c                     	mov	ecx, dword ptr [eax + 0xc]
  577d14: 3b 4f 0c                     	cmp	ecx, dword ptr [edi + 0xc]
  577d17: 0f 8d f9 00 00 00            	jge	0x577e16 <.text+0xe16>
  577d1d: 57                           	push	edi
  577d1e: 50                           	push	eax
  577d1f: 6a 00                        	push	0x0
  577d21: eb a5                        	jmp	0x577cc8 <.text+0xcc8>
  577d23: 8b 4f 0c                     	mov	ecx, dword ptr [edi + 0xc]
  577d26: 39 4b 0c                     	cmp	dword ptr [ebx + 0xc], ecx
  577d29: 7e 6a                        	jle	0x577d95 <.text+0xd95>
  577d2b: 8b 55 0c                     	mov	edx, dword ptr [ebp + 0xc]
  577d2e: 8b 02                        	mov	eax, dword ptr [edx]
  577d30: 85 c0                        	test	eax, eax
  577d32: 74 05                        	je	0x577d39 <.text+0xd39>
  577d34: 8b 00                        	mov	eax, dword ptr [eax]
  577d36: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  577d39: 8d 4d f0                     	lea	ecx, [ebp - 0x10]
  577d3c: 89 5d f8                     	mov	dword ptr [ebp - 0x8], ebx
  577d3f: e8 1c 92 ff ff               	call	0x570f60
  577d44: 8b 4f 0c                     	mov	ecx, dword ptr [edi + 0xc]
  577d47: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  577d4a: 39 4a 0c                     	cmp	dword ptr [edx + 0xc], ecx
  577d4d: 7d 40                        	jge	0x577d8f <.text+0xd8f>
  577d4f: 8b 45 f8                     	mov	eax, dword ptr [ebp - 0x8]
  577d52: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
  577d55: 80 b9 c1 00 00 00 00         	cmp	byte ptr [ecx + 0xc1], 0x0
  577d5c: 57                           	push	edi
  577d5d: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  577d60: 8b ce                        	mov	ecx, esi
  577d62: 74 14                        	je	0x577d78 <.text+0xd78>
  577d64: 50                           	push	eax
  577d65: 6a 00                        	push	0x0
  577d67: 57                           	push	edi
  577d68: e8 83 e9 ff ff               	call	0x5766f0
  577d6d: 8b c7                        	mov	eax, edi
  577d6f: 5f                           	pop	edi
  577d70: 5e                           	pop	esi
  577d71: 5b                           	pop	ebx
  577d72: 8b e5                        	mov	esp, ebp
  577d74: 5d                           	pop	ebp
  577d75: c2 14 00                     	ret	0x14
  577d78: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  577d7b: 52                           	push	edx
  577d7c: 6a 01                        	push	0x1
  577d7e: 57                           	push	edi
  577d7f: e8 6c e9 ff ff               	call	0x5766f0
  577d84: 8b c7                        	mov	eax, edi
  577d86: 5f                           	pop	edi
  577d87: 5e                           	pop	esi
  577d88: 5b                           	pop	ebx
  577d89: 8b e5                        	mov	esp, ebp
  577d8b: 5d                           	pop	ebp
  577d8c: c2 14 00                     	ret	0x14
  577d8f: 8b 5d 14                     	mov	ebx, dword ptr [ebp + 0x14]
  577d92: 39 4b 0c                     	cmp	dword ptr [ebx + 0xc], ecx
  577d95: 7d 7f                        	jge	0x577e16 <.text+0xe16>
  577d97: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
  577d9a: 39 45 f0                     	cmp	dword ptr [ebp - 0x10], eax
  577d9d: 74 0b                        	je	0x577daa <.text+0xdaa>
  577d9f: 8b 00                        	mov	eax, dword ptr [eax]
  577da1: 85 c0                        	test	eax, eax
  577da3: 74 05                        	je	0x577daa <.text+0xdaa>
  577da5: 8b 00                        	mov	eax, dword ptr [eax]
  577da7: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  577daa: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  577dad: 51                           	push	ecx
  577dae: 8b ce                        	mov	ecx, esi
  577db0: 89 5d f8                     	mov	dword ptr [ebp - 0x8], ebx
  577db3: e8 88 c5 24 00               	call	0x7c4340 <.text+0x24d340>
  577db8: 50                           	push	eax
  577db9: 8d 4d f0                     	lea	ecx, [ebp - 0x10]
  577dbc: e8 9f 90 ff ff               	call	0x570e60
  577dc1: 8b c8                        	mov	ecx, eax
  577dc3: e8 58 21 03 00               	call	0x5a9f20 <.text+0x32f20>
  577dc8: 8b 4d f8                     	mov	ecx, dword ptr [ebp - 0x8]
  577dcb: 84 c0                        	test	al, al
  577dcd: 75 08                        	jne	0x577dd7 <.text+0xdd7>
  577dcf: 8b 57 0c                     	mov	edx, dword ptr [edi + 0xc]
  577dd2: 3b 51 0c                     	cmp	edx, dword ptr [ecx + 0xc]
  577dd5: 7d 3f                        	jge	0x577e16 <.text+0xe16>
  577dd7: 8b 45 14                     	mov	eax, dword ptr [ebp + 0x14]
  577dda: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  577ddd: 80 ba c1 00 00 00 00         	cmp	byte ptr [edx + 0xc1], 0x0
  577de4: 57                           	push	edi
  577de5: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  577de8: 74 16                        	je	0x577e00 <.text+0xe00>
  577dea: 50                           	push	eax
  577deb: 6a 00                        	push	0x0
  577ded: 8b ce                        	mov	ecx, esi
  577def: 57                           	push	edi
  577df0: e8 fb e8 ff ff               	call	0x5766f0
  577df5: 8b c7                        	mov	eax, edi
  577df7: 5f                           	pop	edi
  577df8: 5e                           	pop	esi
  577df9: 5b                           	pop	ebx
  577dfa: 8b e5                        	mov	esp, ebp
  577dfc: 5d                           	pop	ebp
  577dfd: c2 14 00                     	ret	0x14
  577e00: 51                           	push	ecx
  577e01: 6a 01                        	push	0x1
  577e03: 8b ce                        	mov	ecx, esi
  577e05: 57                           	push	edi
  577e06: e8 e5 e8 ff ff               	call	0x5766f0
  577e0b: 8b c7                        	mov	eax, edi
  577e0d: 5f                           	pop	edi
  577e0e: 5e                           	pop	esi
  577e0f: 5b                           	pop	ebx
  577e10: 8b e5                        	mov	esp, ebp
  577e12: 5d                           	pop	ebp
  577e13: c2 14 00                     	ret	0x14
  577e16: 6a 00                        	push	0x0
  577e18: 57                           	push	edi
  577e19: 8d 45 e0                     	lea	eax, [ebp - 0x20]
  577e1c: 50                           	push	eax
  577e1d: 8b ce                        	mov	ecx, esi
  577e1f: e8 5c ee ff ff               	call	0x576c80
  577e24: 8b d0                        	mov	edx, eax
  577e26: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  577e29: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  577e2f: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  577e36: 8b 0a                        	mov	ecx, dword ptr [edx]
  577e38: 85 c9                        	test	ecx, ecx
  577e3a: 74 0a                        	je	0x577e46 <.text+0xe46>
  577e3c: 8b 09                        	mov	ecx, dword ptr [ecx]
  577e3e: 85 c9                        	test	ecx, ecx
  577e40: 74 04                        	je	0x577e46 <.text+0xe46>
  577e42: 8b 09                        	mov	ecx, dword ptr [ecx]
  577e44: 89 08                        	mov	dword ptr [eax], ecx
  577e46: 8b 52 08                     	mov	edx, dword ptr [edx + 0x8]
  577e49: 5f                           	pop	edi
  577e4a: 5e                           	pop	esi
  577e4b: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  577e4e: 5b                           	pop	ebx
  577e4f: 8b e5                        	mov	esp, ebp
  577e51: 5d                           	pop	ebp
  577e52: c2 14 00                     	ret	0x14
  577e55: e8 4d ef e5 00               	call	0x13d6da7 <.text+0xe5fda7>
  577e5a: cc                           	int3
  577e5b: cc                           	int3
  577e5c: cc                           	int3
  577e5d: cc                           	int3
  577e5e: cc                           	int3
  577e5f: cc                           	int3
  577e60: 55                           	push	ebp
  577e61: 8b ec                        	mov	ebp, esp
  577e63: 83 ec 28                     	sub	esp, 0x28
  577e66: 56                           	push	esi
  577e67: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  577e6a: 50                           	push	eax
  577e6b: 8b f1                        	mov	esi, ecx
  577e6d: e8 ce c4 24 00               	call	0x7c4340 <.text+0x24d340>
  577e72: 83 ec 0c                     	sub	esp, 0xc
  577e75: 8b cc                        	mov	ecx, esp
  577e77: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  577e7d: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  577e84: 8b 10                        	mov	edx, dword ptr [eax]
  577e86: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  577e89: 85 d2                        	test	edx, edx
  577e8b: 74 0a                        	je	0x577e97 <.text+0xe97>
  577e8d: 8b 12                        	mov	edx, dword ptr [edx]
  577e8f: 85 d2                        	test	edx, edx
  577e91: 74 04                        	je	0x577e97 <.text+0xe97>
  577e93: 8b 12                        	mov	edx, dword ptr [edx]
  577e95: 89 11                        	mov	dword ptr [ecx], edx
  577e97: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  577e9a: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  577e9d: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  577ea0: 51                           	push	ecx
  577ea1: 8b ce                        	mov	ecx, esi
  577ea3: e8 a8 7f fe ff               	call	0x55fe50
  577ea8: 83 ec 0c                     	sub	esp, 0xc
  577eab: 8b cc                        	mov	ecx, esp
  577ead: c7 01 00 00 00 00            	mov	dword ptr [ecx], 0x0
  577eb3: c7 41 04 00 00 00 00         	mov	dword ptr [ecx + 0x4], 0x0
  577eba: 8b 10                        	mov	edx, dword ptr [eax]
  577ebc: 89 65 fc                     	mov	dword ptr [ebp - 0x4], esp
  577ebf: 85 d2                        	test	edx, edx
  577ec1: 74 0a                        	je	0x577ecd <.text+0xecd>
  577ec3: 8b 12                        	mov	edx, dword ptr [edx]
  577ec5: 85 d2                        	test	edx, edx
  577ec7: 74 04                        	je	0x577ecd <.text+0xecd>
  577ec9: 8b 12                        	mov	edx, dword ptr [edx]
  577ecb: 89 11                        	mov	dword ptr [ecx], edx
  577ecd: 8b 40 08                     	mov	eax, dword ptr [eax + 0x8]
  577ed0: 89 41 08                     	mov	dword ptr [ecx + 0x8], eax
  577ed3: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  577ed6: 51                           	push	ecx
  577ed7: 8b ce                        	mov	ecx, esi
  577ed9: e8 02 ef ff ff               	call	0x576de0
  577ede: 5e                           	pop	esi
  577edf: 8b e5                        	mov	esp, ebp
  577ee1: 5d                           	pop	ebp
  577ee2: c3                           	ret
  577ee3: cc                           	int3
  577ee4: cc                           	int3
  577ee5: cc                           	int3
  577ee6: cc                           	int3
  577ee7: cc                           	int3
  577ee8: cc                           	int3
  577ee9: cc                           	int3
  577eea: cc                           	int3
  577eeb: cc                           	int3
  577eec: cc                           	int3
  577eed: cc                           	int3
  577eee: cc                           	int3
  577eef: cc                           	int3
  577ef0: 55                           	push	ebp
  577ef1: 8b ec                        	mov	ebp, esp
  577ef3: 6a ff                        	push	-0x1
  577ef5: 68 80 cf 41 01               	push	0x141cf80
  577efa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  577f00: 50                           	push	eax
  577f01: 83 ec 28                     	sub	esp, 0x28
  577f04: 53                           	push	ebx
  577f05: 56                           	push	esi
  577f06: 57                           	push	edi
  577f07: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  577f0c: 33 c5                        	xor	eax, ebp
  577f0e: 50                           	push	eax
  577f0f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  577f12: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  577f18: 89 65 f0                     	mov	dword ptr [ebp - 0x10], esp
  577f1b: 8b f1                        	mov	esi, ecx
  577f1d: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  577f20: 33 ff                        	xor	edi, edi
  577f22: 6a 08                        	push	0x8
  577f24: 89 3e                        	mov	dword ptr [esi], edi
  577f26: e8 ef eb e5 00               	call	0x13d6b1a <.text+0xe5fb1a>
  577f2b: 83 c4 04                     	add	esp, 0x4
  577f2e: 3b c7                        	cmp	eax, edi
  577f30: 0f 84 a2 00 00 00            	je	0x577fd8 <.text+0xfd8>
  577f36: 89 06                        	mov	dword ptr [esi], eax
  577f38: 33 c9                        	xor	ecx, ecx
  577f3a: 33 d2                        	xor	edx, edx
  577f3c: 89 08                        	mov	dword ptr [eax], ecx
  577f3e: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
  577f41: 8b 06                        	mov	eax, dword ptr [esi]
  577f43: 89 30                        	mov	dword ptr [eax], esi
  577f45: 6a 3c                        	push	0x3c
  577f47: 89 7d fc                     	mov	dword ptr [ebp - 0x4], edi
  577f4a: 89 7e 0c                     	mov	dword ptr [esi + 0xc], edi
  577f4d: e8 c8 eb e5 00               	call	0x13d6b1a <.text+0xe5fb1a>
  577f52: 83 c4 04                     	add	esp, 0x4
  577f55: 3b c7                        	cmp	eax, edi
  577f57: 74 5b                        	je	0x577fb4 <.text+0xfb4>
  577f59: 89 46 08                     	mov	dword ptr [esi + 0x8], eax
  577f5c: 89 00                        	mov	dword ptr [eax], eax
  577f5e: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  577f61: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
  577f64: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  577f67: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
  577f6a: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
  577f6d: b8 01 00 00 00               	mov	eax, 0x1
  577f72: 88 41 38                     	mov	byte ptr [ecx + 0x38], al
  577f75: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
  577f78: 88 42 39                     	mov	byte ptr [edx + 0x39], al
  577f7b: 89 45 fc                     	mov	dword ptr [ebp - 0x4], eax
  577f7e: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  577f81: 50                           	push	eax
  577f82: 8b ce                        	mov	ecx, esi
  577f84: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  577f88: e8 93 ea ff ff               	call	0x576a20
  577f8d: 8b c6                        	mov	eax, esi
  577f8f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  577f92: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  577f99: 59                           	pop	ecx
  577f9a: 5f                           	pop	edi
  577f9b: 5e                           	pop	esi
  577f9c: 5b                           	pop	ebx
  577f9d: 8b e5                        	mov	esp, ebp
  577f9f: 5d                           	pop	ebp
  577fa0: c2 04 00                     	ret	0x4
  577fa3: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  577fa6: e8 b5 fe ff ff               	call	0x577e60 <.text+0xe60>
  577fab: 33 ff                        	xor	edi, edi
  577fad: 57                           	push	edi
  577fae: 57                           	push	edi
  577faf: e8 e6 eb e5 00               	call	0x13d6b9a <.text+0xe5fb9a>
  577fb4: 8d 4d e8                     	lea	ecx, [ebp - 0x18]
  577fb7: 51                           	push	ecx
  577fb8: 8d 4d d8                     	lea	ecx, [ebp - 0x28]
  577fbb: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
  577fbe: e8 07 e5 e5 00               	call	0x13d64ca <.text+0xe5f4ca>
  577fc3: 68 90 0f 91 01               	push	0x1910f90
  577fc8: 8d 55 d8                     	lea	edx, [ebp - 0x28]
  577fcb: 52                           	push	edx
  577fcc: c7 45 d8 84 20 56 01         	mov	dword ptr [ebp - 0x28], 0x1562084
  577fd3: e8 c2 eb e5 00               	call	0x13d6b9a <.text+0xe5fb9a>
  577fd8: 8d 45 e4                     	lea	eax, [ebp - 0x1c]
  577fdb: 50                           	push	eax
  577fdc: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  577fdf: 89 7d e4                     	mov	dword ptr [ebp - 0x1c], edi
  577fe2: e8 e3 e4 e5 00               	call	0x13d64ca <.text+0xe5f4ca>
  577fe7: 68 90 0f 91 01               	push	0x1910f90
  577fec: 8d 4d cc                     	lea	ecx, [ebp - 0x34]
  577fef: 51                           	push	ecx
  577ff0: c7 45 cc 84 20 56 01         	mov	dword ptr [ebp - 0x34], 0x1562084
  577ff7: e8 9e eb e5 00               	call	0x13d6b9a <.text+0xe5fb9a>
  577ffc: cc                           	int3
  577ffd: cc                           	int3
  577ffe: cc                           	int3
  577fff: cc                           	int3
  578000: 55                           	push	ebp
  578001: 8b ec                        	mov	ebp, esp
  578003: 6a ff                        	push	-0x1
  578005: 68 ec cf 41 01               	push	0x141cfec
  57800a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  578010: 50                           	push	eax
  578011: 83 ec 0c                     	sub	esp, 0xc
  578014: 53                           	push	ebx
  578015: 56                           	push	esi
  578016: 57                           	push	edi
  578017: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57801c: 33 c5                        	xor	eax, ebp
  57801e: 50                           	push	eax
  57801f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  578022: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  578028: 8b f1                        	mov	esi, ecx
  57802a: 89 75 ec                     	mov	dword ptr [ebp - 0x14], esi
  57802d: e8 3e a4 c2 00               	call	0x11a2470 <.text+0xc2b470>
  578032: 8d 46 08                     	lea	eax, [esi + 0x8]
  578035: 50                           	push	eax
  578036: 8d 4d f0                     	lea	ecx, [ebp - 0x10]
  578039: 33 db                        	xor	ebx, ebx
  57803b: 51                           	push	ecx
  57803c: 8b ce                        	mov	ecx, esi
  57803e: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  578041: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
  578044: e8 e7 88 c2 00               	call	0x11a0930 <.text+0xc29930>
  578049: 8d 7e 0c                     	lea	edi, [esi + 0xc]
  57804c: 8b cf                        	mov	ecx, edi
  57804e: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
  578055: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
  578058: e8 13 a4 c2 00               	call	0x11a2470 <.text+0xc2b470>
  57805d: 8d 57 08                     	lea	edx, [edi + 0x8]
  578060: 52                           	push	edx
  578061: 8d 45 f0                     	lea	eax, [ebp - 0x10]
  578064: 50                           	push	eax
  578065: 8b cf                        	mov	ecx, edi
  578067: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  57806b: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
  57806e: e8 bd 88 c2 00               	call	0x11a0930 <.text+0xc29930>
  578073: 8d 7e 18                     	lea	edi, [esi + 0x18]
  578076: 8b cf                        	mov	ecx, edi
  578078: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57807c: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
  57807f: e8 ec a3 c2 00               	call	0x11a2470 <.text+0xc2b470>
  578084: 8d 4f 08                     	lea	ecx, [edi + 0x8]
  578087: 51                           	push	ecx
  578088: 8d 55 f0                     	lea	edx, [ebp - 0x10]
  57808b: 52                           	push	edx
  57808c: 8b cf                        	mov	ecx, edi
  57808e: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
  578092: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
  578095: e8 96 88 c2 00               	call	0x11a0930 <.text+0xc29930>
  57809a: 8d 4e 24                     	lea	ecx, [esi + 0x24]
  57809d: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
  5780a1: e8 6a 47 f2 ff               	call	0x49c810
  5780a6: 8d 4e 38                     	lea	ecx, [esi + 0x38]
  5780a9: c6 45 fc 06                  	mov	byte ptr [ebp - 0x4], 0x6
  5780ad: e8 5e 47 f2 ff               	call	0x49c810
  5780b2: 8b ce                        	mov	ecx, esi
  5780b4: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
  5780b8: e8 83 e4 ff ff               	call	0x576540
  5780bd: 8b c6                        	mov	eax, esi
  5780bf: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  5780c2: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  5780c9: 59                           	pop	ecx
  5780ca: 5f                           	pop	edi
  5780cb: 5e                           	pop	esi
  5780cc: 5b                           	pop	ebx
  5780cd: 8b e5                        	mov	esp, ebp
  5780cf: 5d                           	pop	ebp
  5780d0: c3                           	ret
  5780d1: cc                           	int3
  5780d2: cc                           	int3
  5780d3: cc                           	int3
  5780d4: cc                           	int3
  5780d5: cc                           	int3
  5780d6: cc                           	int3
  5780d7: cc                           	int3
  5780d8: cc                           	int3
  5780d9: cc                           	int3
  5780da: cc                           	int3
  5780db: cc                           	int3
  5780dc: cc                           	int3
  5780dd: cc                           	int3
  5780de: cc                           	int3
  5780df: cc                           	int3
  5780e0: 55                           	push	ebp
  5780e1: 8b ec                        	mov	ebp, esp
  5780e3: 51                           	push	ecx
  5780e4: 53                           	push	ebx
  5780e5: 56                           	push	esi
  5780e6: 57                           	push	edi
  5780e7: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  5780ea: 8b f1                        	mov	esi, ecx
  5780ec: 8d 45 08                     	lea	eax, [ebp + 0x8]
  5780ef: 50                           	push	eax
  5780f0: 8d 4f 08                     	lea	ecx, [edi + 0x8]
  5780f3: 51                           	push	ecx
  5780f4: 8b cf                        	mov	ecx, edi
  5780f6: e8 e5 8c c2 00               	call	0x11a0de0 <.text+0xc29de0>
  5780fb: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
  5780fe: 8d 46 08                     	lea	eax, [esi + 0x8]
  578101: 50                           	push	eax
  578102: 8d 4d fc                     	lea	ecx, [ebp - 0x4]
  578105: 51                           	push	ecx
  578106: 8b ce                        	mov	ecx, esi
  578108: 89 55 fc                     	mov	dword ptr [ebp - 0x4], edx
  57810b: e8 20 88 c2 00               	call	0x11a0930 <.text+0xc29930>
  578110: 8d 4f 0c                     	lea	ecx, [edi + 0xc]
  578113: 8d 55 08                     	lea	edx, [ebp + 0x8]
  578116: 52                           	push	edx
  578117: 8d 41 08                     	lea	eax, [ecx + 0x8]
  57811a: 50                           	push	eax
  57811b: e8 c0 8c c2 00               	call	0x11a0de0 <.text+0xc29de0>
  578120: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  578123: 8d 56 14                     	lea	edx, [esi + 0x14]
  578126: 52                           	push	edx
  578127: 8d 45 fc                     	lea	eax, [ebp - 0x4]
  57812a: 89 4d fc                     	mov	dword ptr [ebp - 0x4], ecx
  57812d: 50                           	push	eax
  57812e: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  578131: e8 fa 87 c2 00               	call	0x11a0930 <.text+0xc29930>
  578136: 8d 4f 18                     	lea	ecx, [edi + 0x18]
  578139: 8d 55 08                     	lea	edx, [ebp + 0x8]
  57813c: 52                           	push	edx
  57813d: 8d 41 08                     	lea	eax, [ecx + 0x8]
  578140: 50                           	push	eax
  578141: e8 9a 8c c2 00               	call	0x11a0de0 <.text+0xc29de0>
  578146: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  578149: 8d 56 20                     	lea	edx, [esi + 0x20]
  57814c: 52                           	push	edx
  57814d: 8d 45 fc                     	lea	eax, [ebp - 0x4]
  578150: 89 4d fc                     	mov	dword ptr [ebp - 0x4], ecx
  578153: 50                           	push	eax
  578154: 8d 4e 18                     	lea	ecx, [esi + 0x18]
  578157: e8 d4 87 c2 00               	call	0x11a0930 <.text+0xc29930>
  57815c: 8d 4f 24                     	lea	ecx, [edi + 0x24]
  57815f: 51                           	push	ecx
  578160: 8d 4e 24                     	lea	ecx, [esi + 0x24]
  578163: e8 18 45 f2 ff               	call	0x49c680
  578168: 83 c7 38                     	add	edi, 0x38
  57816b: 57                           	push	edi
  57816c: 8d 4e 38                     	lea	ecx, [esi + 0x38]
  57816f: e8 0c 45 f2 ff               	call	0x49c680
  578174: 5f                           	pop	edi
  578175: 8b c6                        	mov	eax, esi
  578177: 5e                           	pop	esi
  578178: 5b                           	pop	ebx
  578179: 8b e5                        	mov	esp, ebp
  57817b: 5d                           	pop	ebp
  57817c: c2 04 00                     	ret	0x4
  57817f: cc                           	int3
  578180: 55                           	push	ebp
  578181: 8b ec                        	mov	ebp, esp
  578183: 6a ff                        	push	-0x1
  578185: 68 18 d0 41 01               	push	0x141d018
  57818a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  578190: 50                           	push	eax
  578191: 51                           	push	ecx
  578192: 56                           	push	esi
  578193: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  578198: 33 c5                        	xor	eax, ebp
  57819a: 50                           	push	eax
  57819b: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57819e: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  5781a4: 8b f1                        	mov	esi, ecx
  5781a6: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  5781a9: 8d 4e 0c                     	lea	ecx, [esi + 0xc]
  5781ac: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  5781b3: e8 b8 f8 ff ff               	call	0x577a70 <.text+0xa70>
  5781b8: 8b ce                        	mov	ecx, esi
  5781ba: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
  5781c1: e8 fa 8a c2 00               	call	0x11a0cc0 <.text+0xc29cc0>
  5781c6: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  5781c9: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  5781d0: 59                           	pop	ecx
  5781d1: 5e                           	pop	esi
  5781d2: 8b e5                        	mov	esp, ebp
  5781d4: 5d                           	pop	ebp
  5781d5: c3                           	ret
  5781d6: cc                           	int3
  5781d7: cc                           	int3
  5781d8: cc                           	int3
  5781d9: cc                           	int3
  5781da: cc                           	int3
  5781db: cc                           	int3
  5781dc: cc                           	int3
  5781dd: cc                           	int3
  5781de: cc                           	int3
  5781df: cc                           	int3
  5781e0: 55                           	push	ebp
  5781e1: 8b ec                        	mov	ebp, esp
  5781e3: 8b 45 18                     	mov	eax, dword ptr [ebp + 0x18]
  5781e6: 56                           	push	esi
  5781e7: 57                           	push	edi
  5781e8: 50                           	push	eax
  5781e9: 8b f1                        	mov	esi, ecx
  5781eb: e8 20 e7 ff ff               	call	0x576910
  5781f0: 50                           	push	eax
  5781f1: 83 ec 0c                     	sub	esp, 0xc
  5781f4: 8b c4                        	mov	eax, esp
  5781f6: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  5781fc: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  578203: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  578206: 89 65 18                     	mov	dword ptr [ebp + 0x18], esp
  578209: 85 c9                        	test	ecx, ecx
  57820b: 74 0a                        	je	0x578217 <.text+0x1217>
  57820d: 8b 09                        	mov	ecx, dword ptr [ecx]
  57820f: 85 c9                        	test	ecx, ecx
  578211: 74 04                        	je	0x578217 <.text+0x1217>
  578213: 8b 09                        	mov	ecx, dword ptr [ecx]
  578215: 89 08                        	mov	dword ptr [eax], ecx
  578217: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  57821a: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  57821d: 57                           	push	edi
  57821e: 8b ce                        	mov	ecx, esi
  578220: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  578223: e8 18 fa ff ff               	call	0x577c40 <.text+0xc40>
  578228: 8b c7                        	mov	eax, edi
  57822a: 5f                           	pop	edi
  57822b: 5e                           	pop	esi
  57822c: 5d                           	pop	ebp
  57822d: c2 14 00                     	ret	0x14
  578230: 55                           	push	ebp
  578231: 8b ec                        	mov	ebp, esp
  578233: 6a ff                        	push	-0x1
  578235: 68 56 d0 41 01               	push	0x141d056
  57823a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  578240: 50                           	push	eax
  578241: 81 ec 84 01 00 00            	sub	esp, 0x184
  578247: 53                           	push	ebx
  578248: 56                           	push	esi
  578249: 57                           	push	edi
  57824a: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57824f: 33 c5                        	xor	eax, ebp
  578251: 50                           	push	eax
  578252: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  578255: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  57825b: 8b f1                        	mov	esi, ecx
  57825d: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  578260: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  578263: 57                           	push	edi
  578264: 8d 45 e4                     	lea	eax, [ebp - 0x1c]
  578267: 50                           	push	eax
  578268: c7 45 e0 00 00 00 00         	mov	dword ptr [ebp - 0x20], 0x0
  57826f: e8 7c 29 c0 00               	call	0x117abf0 <.text+0xc03bf0>
  578274: 8d 4d d4                     	lea	ecx, [ebp - 0x2c]
  578277: 51                           	push	ecx
  578278: 8b ce                        	mov	ecx, esi
  57827a: e8 c1 c0 24 00               	call	0x7c4340 <.text+0x24d340>
  57827f: 8b 75 e4                     	mov	esi, dword ptr [ebp - 0x1c]
  578282: 85 f6                        	test	esi, esi
  578284: 0f 84 cb 00 00 00            	je	0x578355 <.text+0x1355>
  57828a: 8b 16                        	mov	edx, dword ptr [esi]
  57828c: 85 d2                        	test	edx, edx
  57828e: 0f 84 c1 00 00 00            	je	0x578355 <.text+0x1355>
  578294: 8b 08                        	mov	ecx, dword ptr [eax]
  578296: 85 c9                        	test	ecx, ecx
  578298: 74 02                        	je	0x57829c <.text+0x129c>
  57829a: 8b 09                        	mov	ecx, dword ptr [ecx]
  57829c: 3b d1                        	cmp	edx, ecx
  57829e: 0f 85 b1 00 00 00            	jne	0x578355 <.text+0x1355>
  5782a4: 8b 5d ec                     	mov	ebx, dword ptr [ebp - 0x14]
  5782a7: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
  5782aa: 0f 94 c0                     	sete	al
  5782ad: 84 c0                        	test	al, al
  5782af: 75 0b                        	jne	0x5782bc <.text+0x12bc>
  5782b1: 8b 17                        	mov	edx, dword ptr [edi]
  5782b3: 3b 53 0c                     	cmp	edx, dword ptr [ebx + 0xc]
  5782b6: 0f 8d 86 00 00 00            	jge	0x578342 <.text+0x1342>
  5782bc: 8b 3f                        	mov	edi, dword ptr [edi]
  5782be: 8d 8d 70 fe ff ff            	lea	ecx, [ebp - 0x190]
  5782c4: e8 e7 be ff ff               	call	0x5741b0
  5782c9: 50                           	push	eax
  5782ca: 8d 8d 24 ff ff ff            	lea	ecx, [ebp - 0xdc]
  5782d0: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  5782d7: 89 bd 20 ff ff ff            	mov	dword ptr [ebp - 0xe0], edi
  5782dd: e8 4e b8 ff ff               	call	0x573b30
  5782e2: 8d 85 20 ff ff ff            	lea	eax, [ebp - 0xe0]
  5782e8: 50                           	push	eax
  5782e9: 83 ec 0c                     	sub	esp, 0xc
  5782ec: 8b c4                        	mov	eax, esp
  5782ee: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  5782f4: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  5782fb: 8b 0e                        	mov	ecx, dword ptr [esi]
  5782fd: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  578301: 89 65 08                     	mov	dword ptr [ebp + 0x8], esp
  578304: 85 c9                        	test	ecx, ecx
  578306: 74 04                        	je	0x57830c <.text+0x130c>
  578308: 8b 09                        	mov	ecx, dword ptr [ecx]
  57830a: 89 08                        	mov	dword ptr [eax], ecx
  57830c: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
  57830f: 8d 55 d4                     	lea	edx, [ebp - 0x2c]
  578312: 52                           	push	edx
  578313: 89 58 08                     	mov	dword ptr [eax + 0x8], ebx
  578316: e8 c5 fe ff ff               	call	0x5781e0 <.text+0x11e0>
  57831b: 8b 08                        	mov	ecx, dword ptr [eax]
  57831d: 3b f1                        	cmp	esi, ecx
  57831f: 74 08                        	je	0x578329 <.text+0x1329>
  578321: 8b 09                        	mov	ecx, dword ptr [ecx]
  578323: 85 c9                        	test	ecx, ecx
  578325: 74 02                        	je	0x578329 <.text+0x1329>
  578327: 8b 31                        	mov	esi, dword ptr [ecx]
  578329: 8b 58 08                     	mov	ebx, dword ptr [eax + 0x8]
  57832c: 8d 8d 24 ff ff ff            	lea	ecx, [ebp - 0xdc]
  578332: e8 79 b4 ff ff               	call	0x5737b0
  578337: 8d 8d 70 fe ff ff            	lea	ecx, [ebp - 0x190]
  57833d: e8 6e b4 ff ff               	call	0x5737b0
  578342: 85 f6                        	test	esi, esi
  578344: 74 0f                        	je	0x578355 <.text+0x1355>
  578346: 8b 36                        	mov	esi, dword ptr [esi]
  578348: 85 f6                        	test	esi, esi
  57834a: 74 09                        	je	0x578355 <.text+0x1355>
  57834c: 85 db                        	test	ebx, ebx
  57834e: 74 05                        	je	0x578355 <.text+0x1355>
  578350: 3b 5e 08                     	cmp	ebx, dword ptr [esi + 0x8]
  578353: 75 05                        	jne	0x57835a <.text+0x135a>
  578355: e8 4d ea e5 00               	call	0x13d6da7 <.text+0xe5fda7>
  57835a: 8d 43 10                     	lea	eax, [ebx + 0x10]
  57835d: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  578360: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  578367: 59                           	pop	ecx
  578368: 5f                           	pop	edi
  578369: 5e                           	pop	esi
  57836a: 5b                           	pop	ebx
  57836b: 8b e5                        	mov	esp, ebp
  57836d: 5d                           	pop	ebp
  57836e: c2 04 00                     	ret	0x4
  578371: cc                           	int3
  578372: cc                           	int3
  578373: cc                           	int3
  578374: cc                           	int3
  578375: cc                           	int3
  578376: cc                           	int3
  578377: cc                           	int3
  578378: cc                           	int3
  578379: cc                           	int3
  57837a: cc                           	int3
  57837b: cc                           	int3
  57837c: cc                           	int3
  57837d: cc                           	int3
  57837e: cc                           	int3
  57837f: cc                           	int3
  578380: 55                           	push	ebp
  578381: 8b ec                        	mov	ebp, esp
  578383: 6a ff                        	push	-0x1
  578385: 68 96 d0 41 01               	push	0x141d096
  57838a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  578390: 50                           	push	eax
  578391: 81 ec 80 01 00 00            	sub	esp, 0x180
  578397: 53                           	push	ebx
  578398: 56                           	push	esi
  578399: 57                           	push	edi
  57839a: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57839f: 33 c5                        	xor	eax, ebp
  5783a1: 50                           	push	eax
  5783a2: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  5783a5: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  5783ab: 8b d9                        	mov	ebx, ecx
  5783ad: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  5783b0: 50                           	push	eax
  5783b1: 8d 4d e4                     	lea	ecx, [ebp - 0x1c]
  5783b4: 51                           	push	ecx
  5783b5: 8b cb                        	mov	ecx, ebx
  5783b7: c7 45 f0 00 00 00 00         	mov	dword ptr [ebp - 0x10], 0x0
  5783be: e8 2d 28 c0 00               	call	0x117abf0 <.text+0xc03bf0>
  5783c3: 8d 55 d8                     	lea	edx, [ebp - 0x28]
  5783c6: 52                           	push	edx
  5783c7: 8b cb                        	mov	ecx, ebx
  5783c9: e8 72 bf 24 00               	call	0x7c4340 <.text+0x24d340>
  5783ce: 8b 75 e4                     	mov	esi, dword ptr [ebp - 0x1c]
  5783d1: 85 f6                        	test	esi, esi
  5783d3: 0f 84 d0 00 00 00            	je	0x5784a9 <.text+0x14a9>
  5783d9: 8b 16                        	mov	edx, dword ptr [esi]
  5783db: 85 d2                        	test	edx, edx
  5783dd: 0f 84 c6 00 00 00            	je	0x5784a9 <.text+0x14a9>
  5783e3: 8b 08                        	mov	ecx, dword ptr [eax]
  5783e5: 85 c9                        	test	ecx, ecx
  5783e7: 74 02                        	je	0x5783eb <.text+0x13eb>
  5783e9: 8b 09                        	mov	ecx, dword ptr [ecx]
  5783eb: 3b d1                        	cmp	edx, ecx
  5783ed: 0f 85 b6 00 00 00            	jne	0x5784a9 <.text+0x14a9>
  5783f3: 8b 7d ec                     	mov	edi, dword ptr [ebp - 0x14]
  5783f6: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
  5783f9: 0f 94 c0                     	sete	al
  5783fc: 84 c0                        	test	al, al
  5783fe: 75 0e                        	jne	0x57840e <.text+0x140e>
  578400: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  578403: 8b 08                        	mov	ecx, dword ptr [eax]
  578405: 3b 4f 0c                     	cmp	ecx, dword ptr [edi + 0xc]
  578408: 0f 8d 88 00 00 00            	jge	0x578496 <.text+0x1496>
  57840e: 8d 8d 74 fe ff ff            	lea	ecx, [ebp - 0x18c]
  578414: e8 97 bd ff ff               	call	0x5741b0
  578419: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
  57841c: 8b 0a                        	mov	ecx, dword ptr [edx]
  57841e: 89 8d 24 ff ff ff            	mov	dword ptr [ebp - 0xdc], ecx
  578424: 50                           	push	eax
  578425: 8d 8d 28 ff ff ff            	lea	ecx, [ebp - 0xd8]
  57842b: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  578432: e8 f9 b6 ff ff               	call	0x573b30
  578437: 8d 95 24 ff ff ff            	lea	edx, [ebp - 0xdc]
  57843d: 52                           	push	edx
  57843e: 83 ec 0c                     	sub	esp, 0xc
  578441: 8b c4                        	mov	eax, esp
  578443: c7 00 00 00 00 00            	mov	dword ptr [eax], 0x0
  578449: c7 40 04 00 00 00 00         	mov	dword ptr [eax + 0x4], 0x0
  578450: 8b 0e                        	mov	ecx, dword ptr [esi]
  578452: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  578456: 89 65 08                     	mov	dword ptr [ebp + 0x8], esp
  578459: 85 c9                        	test	ecx, ecx
  57845b: 74 04                        	je	0x578461 <.text+0x1461>
  57845d: 8b 09                        	mov	ecx, dword ptr [ecx]
  57845f: 89 08                        	mov	dword ptr [eax], ecx
  578461: 8d 55 d8                     	lea	edx, [ebp - 0x28]
  578464: 52                           	push	edx
  578465: 8b cb                        	mov	ecx, ebx
  578467: 89 78 08                     	mov	dword ptr [eax + 0x8], edi
  57846a: e8 71 fd ff ff               	call	0x5781e0 <.text+0x11e0>
  57846f: 8b 08                        	mov	ecx, dword ptr [eax]
  578471: 3b f1                        	cmp	esi, ecx
  578473: 74 08                        	je	0x57847d <.text+0x147d>
  578475: 8b 09                        	mov	ecx, dword ptr [ecx]
  578477: 85 c9                        	test	ecx, ecx
  578479: 74 02                        	je	0x57847d <.text+0x147d>
  57847b: 8b 31                        	mov	esi, dword ptr [ecx]
  57847d: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
  578480: 8d 8d 28 ff ff ff            	lea	ecx, [ebp - 0xd8]
  578486: e8 25 b3 ff ff               	call	0x5737b0
  57848b: 8d 8d 74 fe ff ff            	lea	ecx, [ebp - 0x18c]
  578491: e8 1a b3 ff ff               	call	0x5737b0
  578496: 85 f6                        	test	esi, esi
  578498: 74 0f                        	je	0x5784a9 <.text+0x14a9>
  57849a: 8b 36                        	mov	esi, dword ptr [esi]
  57849c: 85 f6                        	test	esi, esi
  57849e: 74 09                        	je	0x5784a9 <.text+0x14a9>
  5784a0: 85 ff                        	test	edi, edi
  5784a2: 74 05                        	je	0x5784a9 <.text+0x14a9>
  5784a4: 3b 7e 08                     	cmp	edi, dword ptr [esi + 0x8]
  5784a7: 75 05                        	jne	0x5784ae <.text+0x14ae>
  5784a9: e8 f9 e8 e5 00               	call	0x13d6da7 <.text+0xe5fda7>
  5784ae: 8d 47 10                     	lea	eax, [edi + 0x10]
  5784b1: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  5784b4: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  5784bb: 59                           	pop	ecx
  5784bc: 5f                           	pop	edi
  5784bd: 5e                           	pop	esi
  5784be: 5b                           	pop	ebx
  5784bf: 8b e5                        	mov	esp, ebp
  5784c1: 5d                           	pop	ebp
  5784c2: c2 04 00                     	ret	0x4
  5784c5: cc                           	int3
  5784c6: cc                           	int3
  5784c7: cc                           	int3
  5784c8: cc                           	int3
  5784c9: cc                           	int3
  5784ca: cc                           	int3
  5784cb: cc                           	int3
  5784cc: cc                           	int3
  5784cd: cc                           	int3
  5784ce: cc                           	int3
  5784cf: cc                           	int3
  5784d0: 55                           	push	ebp
  5784d1: 8b ec                        	mov	ebp, esp
  5784d3: 83 ec 20                     	sub	esp, 0x20
  5784d6: 53                           	push	ebx
  5784d7: 56                           	push	esi
  5784d8: 57                           	push	edi
  5784d9: 83 ec 0c                     	sub	esp, 0xc
  5784dc: 33 ff                        	xor	edi, edi
  5784de: 8b c4                        	mov	eax, esp
  5784e0: 8b f1                        	mov	esi, ecx
  5784e2: 89 38                        	mov	dword ptr [eax], edi
  5784e4: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  5784e7: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
  5784ea: 89 75 fc                     	mov	dword ptr [ebp - 0x4], esi
  5784ed: 89 65 f8                     	mov	dword ptr [ebp - 0x8], esp
  5784f0: 3b cf                        	cmp	ecx, edi
  5784f2: 74 0a                        	je	0x5784fe <.text+0x14fe>
  5784f4: 8b 09                        	mov	ecx, dword ptr [ecx]
  5784f6: 3b cf                        	cmp	ecx, edi
  5784f8: 74 04                        	je	0x5784fe <.text+0x14fe>
  5784fa: 8b 09                        	mov	ecx, dword ptr [ecx]
  5784fc: 89 08                        	mov	dword ptr [eax], ecx
  5784fe: 8b 55 14                     	mov	edx, dword ptr [ebp + 0x14]
  578501: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  578504: 8d 45 ec                     	lea	eax, [ebp - 0x14]
  578507: 50                           	push	eax
  578508: 8b ce                        	mov	ecx, esi
  57850a: e8 b1 1c 1f 00               	call	0x76a1c0 <.text+0x1f31c0>
  57850f: 83 ec 0c                     	sub	esp, 0xc
  578512: 8b c4                        	mov	eax, esp
  578514: 89 38                        	mov	dword ptr [eax], edi
  578516: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  578519: 8b 4d 18                     	mov	ecx, dword ptr [ebp + 0x18]
  57851c: 89 65 f8                     	mov	dword ptr [ebp - 0x8], esp
  57851f: 3b cf                        	cmp	ecx, edi
  578521: 74 0a                        	je	0x57852d <.text+0x152d>
  578523: 8b 09                        	mov	ecx, dword ptr [ecx]
  578525: 3b cf                        	cmp	ecx, edi
  578527: 74 04                        	je	0x57852d <.text+0x152d>
  578529: 8b 09                        	mov	ecx, dword ptr [ecx]
  57852b: 89 08                        	mov	dword ptr [eax], ecx
  57852d: 8b 55 20                     	mov	edx, dword ptr [ebp + 0x20]
  578530: 89 50 08                     	mov	dword ptr [eax + 0x8], edx
  578533: 8d 45 e0                     	lea	eax, [ebp - 0x20]
  578536: 50                           	push	eax
  578537: 8b ce                        	mov	ecx, esi
  578539: e8 82 1c 1f 00               	call	0x76a1c0 <.text+0x1f31c0>
  57853e: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  578541: 3b c7                        	cmp	eax, edi
  578543: 74 06                        	je	0x57854b <.text+0x154b>
  578545: 8b 00                        	mov	eax, dword ptr [eax]
  578547: 3b c7                        	cmp	eax, edi
  578549: 75 05                        	jne	0x578550 <.text+0x1550>
  57854b: e8 57 e8 e5 00               	call	0x13d6da7 <.text+0xe5fda7>
  578550: 8b 4d e0                     	mov	ecx, dword ptr [ebp - 0x20]
  578553: 3b cf                        	cmp	ecx, edi
  578555: 75 04                        	jne	0x57855b <.text+0x155b>
  578557: 33 c9                        	xor	ecx, ecx
  578559: eb 02                        	jmp	0x57855d <.text+0x155d>
  57855b: 8b 09                        	mov	ecx, dword ptr [ecx]
  57855d: 3b c1                        	cmp	eax, ecx
  57855f: 74 05                        	je	0x578566 <.text+0x1566>
  578561: e8 41 e8 e5 00               	call	0x13d6da7 <.text+0xe5fda7>
  578566: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  578569: 8b 55 e8                     	mov	edx, dword ptr [ebp - 0x18]
  57856c: 3b ca                        	cmp	ecx, edx
  57856e: 74 38                        	je	0x5785a8 <.text+0x15a8>
  578570: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  578573: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  578576: 57                           	push	edi
  578577: 51                           	push	ecx
  578578: 50                           	push	eax
  578579: 52                           	push	edx
  57857a: e8 b1 d8 ff ff               	call	0x575e30
  57857f: 8b 5e 08                     	mov	ebx, dword ptr [esi + 0x8]
  578582: 8b f8                        	mov	edi, eax
  578584: 83 c4 10                     	add	esp, 0x10
  578587: 8b f7                        	mov	esi, edi
  578589: 3b fb                        	cmp	edi, ebx
  57858b: 74 11                        	je	0x57859e <.text+0x159e>
  57858d: 8d 49 00                     	lea	ecx, [ecx]
  578590: 8b ce                        	mov	ecx, esi
  578592: e8 19 bf ff ff               	call	0x5744b0
  578597: 83 c6 48                     	add	esi, 0x48
  57859a: 3b f3                        	cmp	esi, ebx
  57859c: 75 f2                        	jne	0x578590 <.text+0x1590>
  57859e: 8b 4d fc                     	mov	ecx, dword ptr [ebp - 0x4]
  5785a1: 89 79 08                     	mov	dword ptr [ecx + 0x8], edi
  5785a4: 33 ff                        	xor	edi, edi
  5785a6: 8b f1                        	mov	esi, ecx
  5785a8: 83 ec 0c                     	sub	esp, 0xc
  5785ab: 8b c4                        	mov	eax, esp
  5785ad: 89 38                        	mov	dword ptr [eax], edi
  5785af: 89 78 04                     	mov	dword ptr [eax + 0x4], edi
  5785b2: 8b 4d ec                     	mov	ecx, dword ptr [ebp - 0x14]
  5785b5: 89 65 f8                     	mov	dword ptr [ebp - 0x8], esp
  5785b8: 3b cf                        	cmp	ecx, edi
  5785ba: 74 0a                        	je	0x5785c6 <.text+0x15c6>
  5785bc: 8b 09                        	mov	ecx, dword ptr [ecx]
  5785be: 3b cf                        	cmp	ecx, edi
  5785c0: 74 04                        	je	0x5785c6 <.text+0x15c6>
  5785c2: 8b 11                        	mov	edx, dword ptr [ecx]
  5785c4: 89 10                        	mov	dword ptr [eax], edx
  5785c6: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  5785c9: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
  5785cc: 89 48 08                     	mov	dword ptr [eax + 0x8], ecx
  5785cf: 57                           	push	edi
  5785d0: 8b ce                        	mov	ecx, esi
  5785d2: e8 e9 1b 1f 00               	call	0x76a1c0 <.text+0x1f31c0>
  5785d7: 8b c7                        	mov	eax, edi
  5785d9: 5f                           	pop	edi
  5785da: 5e                           	pop	esi
  5785db: 5b                           	pop	ebx
  5785dc: 8b e5                        	mov	esp, ebp
  5785de: 5d                           	pop	ebp
  5785df: c2 1c 00                     	ret	0x1c
  5785e2: cc                           	int3
  5785e3: cc                           	int3
  5785e4: cc                           	int3
  5785e5: cc                           	int3
  5785e6: cc                           	int3
  5785e7: cc                           	int3
  5785e8: cc                           	int3
  5785e9: cc                           	int3
  5785ea: cc                           	int3
  5785eb: cc                           	int3
  5785ec: cc                           	int3
  5785ed: cc                           	int3
  5785ee: cc                           	int3
  5785ef: cc                           	int3
  5785f0: 55                           	push	ebp
  5785f1: 8b ec                        	mov	ebp, esp
  5785f3: 6a ff                        	push	-0x1
  5785f5: 68 a8 e9 44 01               	push	0x144e9a8
  5785fa: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  578600: 50                           	push	eax
  578601: 51                           	push	ecx
  578602: 56                           	push	esi
  578603: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  578608: 33 c5                        	xor	eax, ebp
  57860a: 50                           	push	eax
  57860b: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  57860e: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  578614: 8b f1                        	mov	esi, ecx
  578616: 89 75 f0                     	mov	dword ptr [ebp - 0x10], esi
  578619: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  578620: e8 3b f8 ff ff               	call	0x577e60 <.text+0xe60>
  578625: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
  578628: 50                           	push	eax
  578629: e8 f9 d4 e5 00               	call	0x13d5b27 <.text+0xe5eb27>
  57862e: 8b 0e                        	mov	ecx, dword ptr [esi]
  578630: 51                           	push	ecx
  578631: e8 f1 d4 e5 00               	call	0x13d5b27 <.text+0xe5eb27>
  578636: 83 c4 08                     	add	esp, 0x8
  578639: c7 06 00 00 00 00            	mov	dword ptr [esi], 0x0
  57863f: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
  578642: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
  578649: 59                           	pop	ecx
  57864a: 5e                           	pop	esi
  57864b: 8b e5                        	mov	esp, ebp
  57864d: 5d                           	pop	ebp
  57864e: c3                           	ret
  57864f: cc                           	int3
  578650: 55                           	push	ebp
  578651: 8b ec                        	mov	ebp, esp
  578653: 6a ff                        	push	-0x1
  578655: 68 00 d1 41 01               	push	0x141d100
  57865a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
  578660: 50                           	push	eax
  578661: 83 ec 58                     	sub	esp, 0x58
  578664: 53                           	push	ebx
  578665: 56                           	push	esi
  578666: 57                           	push	edi
  578667: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
  57866c: 33 c5                        	xor	eax, ebp
  57866e: 50                           	push	eax
  57866f: 8d 45 f4                     	lea	eax, [ebp - 0xc]
  578672: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
  578678: 8b f9                        	mov	edi, ecx
  57867a: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
  57867d: 6a 00                        	push	0x0
  57867f: 68 e8 91 9d 01               	push	0x19d91e8
  578684: 68 74 91 9d 01               	push	0x19d9174
  578689: 6a 00                        	push	0x0
  57868b: 50                           	push	eax
  57868c: e8 4e f0 e5 00               	call	0x13d76df <.text+0xe606df>
  578691: 8b f0                        	mov	esi, eax
  578693: 83 c4 14                     	add	esp, 0x14
  578696: 85 f6                        	test	esi, esi
  578698: 0f 84 d9 02 00 00            	je	0x578977 <.text+0x1977>
  57869e: 8b 16                        	mov	edx, dword ptr [esi]
  5786a0: 8b 82 a4 00 00 00            	mov	eax, dword ptr [edx + 0xa4]
  5786a6: 8b ce                        	mov	ecx, esi
  5786a8: ff d0                        	call	eax
  5786aa: 8b 16                        	mov	edx, dword ptr [esi]
  5786ac: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
  5786af: 8b 82 a8 00 00 00            	mov	eax, dword ptr [edx + 0xa8]
  5786b5: 8b ce                        	mov	ecx, esi
  5786b7: ff d0                        	call	eax
  5786b9: 8b 16                        	mov	edx, dword ptr [esi]
  5786bb: 89 45 d4                     	mov	dword ptr [ebp - 0x2c], eax
  5786be: 8b 82 ac 00 00 00            	mov	eax, dword ptr [edx + 0xac]
  5786c4: 8b ce                        	mov	ecx, esi
  5786c6: ff d0                        	call	eax
  5786c8: 8b 16                        	mov	edx, dword ptr [esi]
  5786ca: 89 45 d8                     	mov	dword ptr [ebp - 0x28], eax
  5786cd: 8b 82 f8 00 00 00            	mov	eax, dword ptr [edx + 0xf8]
  5786d3: 8b ce                        	mov	ecx, esi
  5786d5: ff d0                        	call	eax
  5786d7: 8b 16                        	mov	edx, dword ptr [esi]
  5786d9: 89 45 dc                     	mov	dword ptr [ebp - 0x24], eax
  5786dc: 8b 82 2c 02 00 00            	mov	eax, dword ptr [edx + 0x22c]
  5786e2: 8b ce                        	mov	ecx, esi
  5786e4: ff d0                        	call	eax
  5786e6: 8d 4d c0                     	lea	ecx, [ebp - 0x40]
  5786e9: 89 45 cc                     	mov	dword ptr [ebp - 0x34], eax
  5786ec: e8 7f 9d c2 00               	call	0x11a2470 <.text+0xc2b470>
  5786f1: 8d 4d c8                     	lea	ecx, [ebp - 0x38]
  5786f4: 51                           	push	ecx
  5786f5: 8d 55 e4                     	lea	edx, [ebp - 0x1c]
  5786f8: bb 01 00 00 00               	mov	ebx, 0x1
  5786fd: 52                           	push	edx
  5786fe: 8d 4d c0                     	lea	ecx, [ebp - 0x40]
  578701: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
  578708: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
  57870b: e8 20 82 c2 00               	call	0x11a0930 <.text+0xc29930>
  578710: 8d 87 04 03 00 00            	lea	eax, [edi + 0x304]
  578716: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
  578719: 8b 18                        	mov	ebx, dword ptr [eax]
  57871b: 8d 4d b4                     	lea	ecx, [ebp - 0x4c]
  57871e: 89 45 ec                     	mov	dword ptr [ebp - 0x14], eax
  578721: e8 4a 9d c2 00               	call	0x11a2470 <.text+0xc2b470>
  578726: 8d 45 bc                     	lea	eax, [ebp - 0x44]
  578729: 50                           	push	eax
  57872a: 8d 4d 08                     	lea	ecx, [ebp + 0x8]
  57872d: 51                           	push	ecx
  57872e: 8d 4d b4                     	lea	ecx, [ebp - 0x4c]
  578731: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
  578735: 89 5d 08                     	mov	dword ptr [ebp + 0x8], ebx
  578738: e8 f3 81 c2 00               	call	0x11a0930 <.text+0xc29930>
  57873d: 8d 9f 14 02 00 00            	lea	ebx, [edi + 0x214]
  578743: 8d 55 a8                     	lea	edx, [ebp - 0x58]
  578746: 52                           	push	edx
  578747: 8b cb                        	mov	ecx, ebx
  578749: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
  57874d: 89 5d e8                     	mov	dword ptr [ebp - 0x18], ebx
  578750: e8 eb bb 24 00               	call	0x7c4340 <.text+0x24d340>
  578755: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
  578758: 8d 45 b4                     	lea	eax, [ebp - 0x4c]
  57875b: 50                           	push	eax
  57875c: 8d 4d 9c                     	lea	ecx, [ebp - 0x64]
  57875f: 51                           	push	ecx
  578760: 8b cb                        	mov	ecx, ebx
  578762: e8 c9 98 ff ff               	call	0x572030
  578767: 8b 08                        	mov	ecx, dword ptr [eax]
  578769: 85 c9                        	test	ecx, ecx
  57876b: 0f 84 1a 02 00 00            	je	0x57898b <.text+0x198b>
  578771: 8b 09                        	mov	ecx, dword ptr [ecx]
  578773: 85 c9                        	test	ecx, ecx
  578775: 0f 84 10 02 00 00            	je	0x57898b <.text+0x198b>
  57877b: 8b 5d f0                     	mov	ebx, dword ptr [ebp - 0x10]
  57877e: 8b 13                        	mov	edx, dword ptr [ebx]
  578780: 85 d2                        	test	edx, edx
  578782: 74 02                        	je	0x578786 <.text+0x1786>
  578784: 8b 12                        	mov	edx, dword ptr [edx]
  578786: 3b ca                        	cmp	ecx, edx
  578788: 0f 85 fd 01 00 00            	jne	0x57898b <.text+0x198b>
  57878e: 8b 50 08                     	mov	edx, dword ptr [eax + 0x8]
  578791: 3b 53 08                     	cmp	edx, dword ptr [ebx + 0x8]
  578794: 8d 4d b4                     	lea	ecx, [ebp - 0x4c]
  578797: 0f 94 c3                     	sete	bl
  57879a: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
  57879e: e8 1d 85 c2 00               	call	0x11a0cc0 <.text+0xc29cc0>
  5787a3: 84 db                        	test	bl, bl
  5787a5: 0f 85 bd 01 00 00            	jne	0x578968 <.text+0x1968>
  5787ab: 8b 45 ec                     	mov	eax, dword ptr [ebp - 0x14]
  5787ae: 50                           	push	eax
  5787af: 8d 8f d0 02 00 00            	lea	ecx, [edi + 0x2d0]
  5787b5: e8 c6 fb ff ff               	call	0x578380 <.text+0x1380>
  5787ba: 8b f8                        	mov	edi, eax
  5787bc: 8b 4f 54                     	mov	ecx, dword ptr [edi + 0x54]
  5787bf: 2b 4f 50                     	sub	ecx, dword ptr [edi + 0x50]
  5787c2: b8 ab aa aa 2a               	mov	eax, 0x2aaaaaab
  5787c7: f7 e9                        	imul	ecx
  5787c9: d1 fa                        	sar	edx
  5787cb: 8b ca                        	mov	ecx, edx
  5787cd: c1 e9 1f                     	shr	ecx, 0x1f
  5787d0: 33 db                        	xor	ebx, ebx
  5787d2: 03 ca                        	add	ecx, edx
  5787d4: 0f 84 f0 00 00 00            	je	0x5788ca <.text+0x18ca>
  5787da: 89 5d f0                     	mov	dword ptr [ebp - 0x10], ebx
  5787dd: 8d 49 00                     	lea	ecx, [ecx]
  5787e0: 8b 55 ec                     	mov	edx, dword ptr [ebp - 0x14]
  5787e3: 8b 02                        	mov	eax, dword ptr [edx]
  5787e5: 8d 4d b4                     	lea	ecx, [ebp - 0x4c]
  5787e8: 89 45 08                     	mov	dword ptr [ebp + 0x8], eax
  5787eb: e8 80 9c c2 00               	call	0x11a2470 <.text+0xc2b470>
  5787f0: 8b 4d 08                     	mov	ecx, dword ptr [ebp + 0x8]
  5787f3: 8d 55 bc                     	lea	edx, [ebp - 0x44]
  5787f6: 52                           	push	edx
  5787f7: 8d 45 08                     	lea	eax, [ebp + 0x8]
  5787fa: 89 4d 08                     	mov	dword ptr [ebp + 0x8], ecx
  5787fd: 50                           	push	eax
  5787fe: 8d 4d                        	<unknown>
