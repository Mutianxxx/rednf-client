
<stdin>:	file format elf32-i386

Disassembly of section .text:

010032b0 <.text>:
 10032b0: 55                           	push	ebp
 10032b1: 8b ec                        	mov	ebp, esp
 10032b3: 6a ff                        	push	-0x1
 10032b5: 68 f3 2c 4b 01               	push	0x14b2cf3
 10032ba: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 10032c0: 50                           	push	eax
 10032c1: 81 ec a0 00 00 00            	sub	esp, 0xa0
 10032c7: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 10032cc: 33 c5                        	xor	eax, ebp
 10032ce: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
 10032d1: 53                           	push	ebx
 10032d2: 56                           	push	esi
 10032d3: 57                           	push	edi
 10032d4: 50                           	push	eax
 10032d5: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 10032d8: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 10032de: 8b c1                        	mov	eax, ecx
 10032e0: be 08 00 00 00               	mov	esi, 0x8
 10032e5: 89 85 64 ff ff ff            	mov	dword ptr [ebp - 0x9c], eax
 10032eb: 39 b0 f4 03 00 00            	cmp	dword ptr [eax + 0x3f4], esi
 10032f1: 72 08                        	jb	0x10032fb <.text+0x4b>
 10032f3: 8b 80 e0 03 00 00            	mov	eax, dword ptr [eax + 0x3e0]
 10032f9: eb 05                        	jmp	0x1003300 <.text+0x50>
 10032fb: 05 e0 03 00 00               	add	eax, 0x3e0
 1003300: 50                           	push	eax
 1003301: 68 78 21 56 01               	push	0x1562178
 1003306: e8 e5 cb 19 00               	call	0x119fef0 <.text+0x19cc40>
 100330b: 83 c4 04                     	add	esp, 0x4
 100330e: 50                           	push	eax
 100330f: e8 0c 03 22 00               	call	0x1223620 <.text+0x220370>
 1003314: 83 c4 08                     	add	esp, 0x8
 1003317: 84 c0                        	test	al, al
 1003319: 75 1c                        	jne	0x1003337 <.text+0x87>
 100331b: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 100331e: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1003325: 59                           	pop	ecx
 1003326: 5f                           	pop	edi
 1003327: 5e                           	pop	esi
 1003328: 5b                           	pop	ebx
 1003329: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
 100332c: 33 cd                        	xor	ecx, ebp
 100332e: e8 a5 3e 3d 00               	call	0x13d71d8 <.text+0x3d3f28>
 1003333: 8b e5                        	mov	esp, ebp
 1003335: 5d                           	pop	ebp
 1003336: c3                           	ret
 1003337: 33 db                        	xor	ebx, ebx
 1003339: 56                           	push	esi
 100333a: 89 5d b0                     	mov	dword ptr [ebp - 0x50], ebx
 100333d: e8 d8 37 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 1003342: 83 c4 04                     	add	esp, 0x4
 1003345: 3b c3                        	cmp	eax, ebx
 1003347: 0f 84 ef 03 00 00            	je	0x100373c <.text+0x48c>
 100334d: 89 45 b0                     	mov	dword ptr [ebp - 0x50], eax
 1003350: 33 c9                        	xor	ecx, ecx
 1003352: 89 08                        	mov	dword ptr [eax], ecx
 1003354: 33 d2                        	xor	edx, edx
 1003356: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1003359: 8b 4d b0                     	mov	ecx, dword ptr [ebp - 0x50]
 100335c: 8d 45 b0                     	lea	eax, [ebp - 0x50]
 100335f: 89 01                        	mov	dword ptr [ecx], eax
 1003361: bf 07 00 00 00               	mov	edi, 0x7
 1003366: 89 7d c8                     	mov	dword ptr [ebp - 0x38], edi
 1003369: 89 5d c4                     	mov	dword ptr [ebp - 0x3c], ebx
 100336c: 66 89 55 b4                  	mov	word ptr [ebp - 0x4c], dx
 1003370: 56                           	push	esi
 1003371: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
 1003374: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 1003377: e8 9e 37 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 100337c: 83 c4 04                     	add	esp, 0x4
 100337f: 3b c3                        	cmp	eax, ebx
 1003381: 0f 84 82 03 00 00            	je	0x1003709 <.text+0x459>
 1003387: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
 100338a: 33 c9                        	xor	ecx, ecx
 100338c: 89 08                        	mov	dword ptr [eax], ecx
 100338e: 33 d2                        	xor	edx, edx
 1003390: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1003393: 8b 4d d0                     	mov	ecx, dword ptr [ebp - 0x30]
 1003396: 8d 45 d0                     	lea	eax, [ebp - 0x30]
 1003399: 89 01                        	mov	dword ptr [ecx], eax
 100339b: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 100339e: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 10033a1: 66 89 55 d4                  	mov	word ptr [ebp - 0x2c], dx
 10033a5: 8d 45 b0                     	lea	eax, [ebp - 0x50]
 10033a8: 6a 01                        	push	0x1
 10033aa: 50                           	push	eax
 10033ab: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
 10033af: e8 5c 1e 22 00               	call	0x1225210 <.text+0x221f60>
 10033b4: 83 c4 08                     	add	esp, 0x8
 10033b7: 84 c0                        	test	al, al
 10033b9: 0f 84 bb 02 00 00            	je	0x100367a <.text+0x3ca>
 10033bf: 90                           	nop
 10033c0: 68 ec b0 82 01               	push	0x182b0ec
 10033c5: e8 26 cb 19 00               	call	0x119fef0 <.text+0x19cc40>
 10033ca: 8b c8                        	mov	ecx, eax
 10033cc: 83 c4 04                     	add	esp, 0x4
 10033cf: 8d 71 02                     	lea	esi, [ecx + 0x2]
 10033d2: 66 8b 11                     	mov	dx, word ptr [ecx]
 10033d5: 83 c1 02                     	add	ecx, 0x2
 10033d8: 66 3b d3                     	cmp	dx, bx
 10033db: 75 f5                        	jne	0x10033d2 <.text+0x122>
 10033dd: 2b ce                        	sub	ecx, esi
 10033df: d1 f9                        	sar	ecx
 10033e1: 51                           	push	ecx
 10033e2: 8b 4d c4                     	mov	ecx, dword ptr [ebp - 0x3c]
 10033e5: 50                           	push	eax
 10033e6: 51                           	push	ecx
 10033e7: 53                           	push	ebx
 10033e8: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 10033eb: e8 40 e8 3f ff               	call	0x401c30
 10033f0: 85 c0                        	test	eax, eax
 10033f2: 0f 85 67 02 00 00            	jne	0x100365f <.text+0x3af>
 10033f8: 6a 08                        	push	0x8
 10033fa: 89 5d 90                     	mov	dword ptr [ebp - 0x70], ebx
 10033fd: e8 18 37 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 1003402: 83 c4 04                     	add	esp, 0x4
 1003405: 3b c3                        	cmp	eax, ebx
 1003407: 0f 84 c9 02 00 00            	je	0x10036d6 <.text+0x426>
 100340d: 89 45 90                     	mov	dword ptr [ebp - 0x70], eax
 1003410: 33 c9                        	xor	ecx, ecx
 1003412: 89 08                        	mov	dword ptr [eax], ecx
 1003414: 33 d2                        	xor	edx, edx
 1003416: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1003419: 8b 45 90                     	mov	eax, dword ptr [ebp - 0x70]
 100341c: 8d 55 90                     	lea	edx, [ebp - 0x70]
 100341f: 89 10                        	mov	dword ptr [eax], edx
 1003421: 89 7d a8                     	mov	dword ptr [ebp - 0x58], edi
 1003424: 89 5d a4                     	mov	dword ptr [ebp - 0x5c], ebx
 1003427: 66 89 4d 94                  	mov	word ptr [ebp - 0x6c], cx
 100342b: 83 c8 ff                     	or	eax, -0x1
 100342e: 68 78 21 56 01               	push	0x1562178
 1003433: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
 1003437: 89 9d 78 ff ff ff            	mov	dword ptr [ebp - 0x88], ebx
 100343d: 89 9d 7c ff ff ff            	mov	dword ptr [ebp - 0x84], ebx
 1003443: 89 5d 80                     	mov	dword ptr [ebp - 0x80], ebx
 1003446: 89 5d 84                     	mov	dword ptr [ebp - 0x7c], ebx
 1003449: 89 45 88                     	mov	dword ptr [ebp - 0x78], eax
 100344c: 89 45 8c                     	mov	dword ptr [ebp - 0x74], eax
 100344f: e8 9c ca 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003454: 8b c8                        	mov	ecx, eax
 1003456: 83 c4 04                     	add	esp, 0x4
 1003459: 8d 71 02                     	lea	esi, [ecx + 0x2]
 100345c: 8d 64 24 00                  	lea	esp, [esp]
 1003460: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003463: 83 c1 02                     	add	ecx, 0x2
 1003466: 66 3b d3                     	cmp	dx, bx
 1003469: 75 f5                        	jne	0x1003460 <.text+0x1b0>
 100346b: 2b ce                        	sub	ecx, esi
 100346d: d1 f9                        	sar	ecx
 100346f: 51                           	push	ecx
 1003470: 50                           	push	eax
 1003471: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1003474: e8 b7 cb 40 ff               	call	0x410030
 1003479: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 100347c: 52                           	push	edx
 100347d: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
 1003481: e8 ca 1c 22 00               	call	0x1225150 <.text+0x221ea0>
 1003486: 83 c4 04                     	add	esp, 0x4
 1003489: 3a c3                        	cmp	al, bl
 100348b: 0f 84 88 01 00 00            	je	0x1003619 <.text+0x369>
 1003491: 68 cc b0 82 01               	push	0x182b0cc
 1003496: e8 55 ca 19 00               	call	0x119fef0 <.text+0x19cc40>
 100349b: 8b c8                        	mov	ecx, eax
 100349d: 83 c4 04                     	add	esp, 0x4
 10034a0: 8d 71 02                     	lea	esi, [ecx + 0x2]
 10034a3: 66 8b 11                     	mov	dx, word ptr [ecx]
 10034a6: 83 c1 02                     	add	ecx, 0x2
 10034a9: 66 3b d3                     	cmp	dx, bx
 10034ac: 75 f5                        	jne	0x10034a3 <.text+0x1f3>
 10034ae: 8b 7d e4                     	mov	edi, dword ptr [ebp - 0x1c]
 10034b1: 2b ce                        	sub	ecx, esi
 10034b3: d1 f9                        	sar	ecx
 10034b5: 8b f7                        	mov	esi, edi
 10034b7: 3b f9                        	cmp	edi, ecx
 10034b9: 72 02                        	jb	0x10034bd <.text+0x20d>
 10034bb: 8b f1                        	mov	esi, ecx
 10034bd: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 10034c1: 8b 55 d4                     	mov	edx, dword ptr [ebp - 0x2c]
 10034c4: 73 03                        	jae	0x10034c9 <.text+0x219>
 10034c6: 8d 55 d4                     	lea	edx, [ebp - 0x2c]
 10034c9: 3b f3                        	cmp	esi, ebx
 10034cb: 76 24                        	jbe	0x10034f1 <.text+0x241>
 10034cd: 8d 49 00                     	lea	ecx, [ecx]
 10034d0: 66 8b 1a                     	mov	bx, word ptr [edx]
 10034d3: 66 3b 18                     	cmp	bx, word ptr [eax]
 10034d6: 75 0d                        	jne	0x10034e5 <.text+0x235>
 10034d8: 83 c2 02                     	add	edx, 0x2
 10034db: 83 c0 02                     	add	eax, 0x2
 10034de: 4e                           	dec	esi
 10034df: 75 ef                        	jne	0x10034d0 <.text+0x220>
 10034e1: 33 db                        	xor	ebx, ebx
 10034e3: eb 0c                        	jmp	0x10034f1 <.text+0x241>
 10034e5: 1b c0                        	sbb	eax, eax
 10034e7: 83 e0 fe                     	and	eax, -0x2
 10034ea: 40                           	inc	eax
 10034eb: 33 db                        	xor	ebx, ebx
 10034ed: 3b c3                        	cmp	eax, ebx
 10034ef: 75 12                        	jne	0x1003503 <.text+0x253>
 10034f1: 3b f9                        	cmp	edi, ecx
 10034f3: 73 05                        	jae	0x10034fa <.text+0x24a>
 10034f5: 83 c8 ff                     	or	eax, -0x1
 10034f8: eb 07                        	jmp	0x1003501 <.text+0x251>
 10034fa: 33 c0                        	xor	eax, eax
 10034fc: 3b f9                        	cmp	edi, ecx
 10034fe: 0f 95 c0                     	setne	al
 1003501: 3b c3                        	cmp	eax, ebx
 1003503: 0f 94 c0                     	sete	al
 1003506: 3a c3                        	cmp	al, bl
 1003508: 74 11                        	je	0x100351b <.text+0x26b>
 100350a: 53                           	push	ebx
 100350b: e8 50 01 22 00               	call	0x1223660 <.text+0x2203b0>
 1003510: 89 85 78 ff ff ff            	mov	dword ptr [ebp - 0x88], eax
 1003516: e9 e2 00 00 00               	jmp	0x10035fd <.text+0x34d>
 100351b: 68 30 1c 57 01               	push	0x1571c30
 1003520: e8 cb c9 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003525: 8b c8                        	mov	ecx, eax
 1003527: 83 c4 04                     	add	esp, 0x4
 100352a: 8d 71 02                     	lea	esi, [ecx + 0x2]
 100352d: 8d 49 00                     	lea	ecx, [ecx]
 1003530: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003533: 83 c1 02                     	add	ecx, 0x2
 1003536: 66 3b d3                     	cmp	dx, bx
 1003539: 75 f5                        	jne	0x1003530 <.text+0x280>
 100353b: 2b ce                        	sub	ecx, esi
 100353d: d1 f9                        	sar	ecx
 100353f: 51                           	push	ecx
 1003540: 50                           	push	eax
 1003541: 8b 45 e4                     	mov	eax, dword ptr [ebp - 0x1c]
 1003544: 50                           	push	eax
 1003545: 53                           	push	ebx
 1003546: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003549: e8 e2 e6 3f ff               	call	0x401c30
 100354e: 85 c0                        	test	eax, eax
 1003550: 75 0e                        	jne	0x1003560 <.text+0x2b0>
 1003552: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1003555: 51                           	push	ecx
 1003556: e8 f5 1b 22 00               	call	0x1225150 <.text+0x221ea0>
 100355b: e9 9d 00 00 00               	jmp	0x10035fd <.text+0x34d>
 1003560: 68 a4 b0 82 01               	push	0x182b0a4
 1003565: e8 86 c9 19 00               	call	0x119fef0 <.text+0x19cc40>
 100356a: 8b c8                        	mov	ecx, eax
 100356c: 83 c4 04                     	add	esp, 0x4
 100356f: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003572: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003575: 83 c1 02                     	add	ecx, 0x2
 1003578: 66 3b d3                     	cmp	dx, bx
 100357b: 75 f5                        	jne	0x1003572 <.text+0x2c2>
 100357d: 8b 55 e4                     	mov	edx, dword ptr [ebp - 0x1c]
 1003580: 2b ce                        	sub	ecx, esi
 1003582: d1 f9                        	sar	ecx
 1003584: 51                           	push	ecx
 1003585: 50                           	push	eax
 1003586: 52                           	push	edx
 1003587: 53                           	push	ebx
 1003588: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 100358b: e8 a0 e6 3f ff               	call	0x401c30
 1003590: 85 c0                        	test	eax, eax
 1003592: 75 2c                        	jne	0x10035c0 <.text+0x310>
 1003594: 53                           	push	ebx
 1003595: e8 c6 00 22 00               	call	0x1223660 <.text+0x2203b0>
 100359a: 53                           	push	ebx
 100359b: 89 85 7c ff ff ff            	mov	dword ptr [ebp - 0x84], eax
 10035a1: e8 ba 00 22 00               	call	0x1223660 <.text+0x2203b0>
 10035a6: 53                           	push	ebx
 10035a7: 89 45 80                     	mov	dword ptr [ebp - 0x80], eax
 10035aa: e8 b1 00 22 00               	call	0x1223660 <.text+0x2203b0>
 10035af: 53                           	push	ebx
 10035b0: 89 45 84                     	mov	dword ptr [ebp - 0x7c], eax
 10035b3: e8 a8 00 22 00               	call	0x1223660 <.text+0x2203b0>
 10035b8: 83 c4 10                     	add	esp, 0x10
 10035bb: 89 45 88                     	mov	dword ptr [ebp - 0x78], eax
 10035be: eb 40                        	jmp	0x1003600 <.text+0x350>
 10035c0: 68 78 b0 82 01               	push	0x182b078
 10035c5: e8 26 c9 19 00               	call	0x119fef0 <.text+0x19cc40>
 10035ca: 8b c8                        	mov	ecx, eax
 10035cc: 83 c4 04                     	add	esp, 0x4
 10035cf: 8d 71 02                     	lea	esi, [ecx + 0x2]
 10035d2: 66 8b 11                     	mov	dx, word ptr [ecx]
 10035d5: 83 c1 02                     	add	ecx, 0x2
 10035d8: 66 3b d3                     	cmp	dx, bx
 10035db: 75 f5                        	jne	0x10035d2 <.text+0x322>
 10035dd: 2b ce                        	sub	ecx, esi
 10035df: d1 f9                        	sar	ecx
 10035e1: 51                           	push	ecx
 10035e2: 50                           	push	eax
 10035e3: 8b 45 e4                     	mov	eax, dword ptr [ebp - 0x1c]
 10035e6: 50                           	push	eax
 10035e7: 53                           	push	ebx
 10035e8: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 10035eb: e8 40 e6 3f ff               	call	0x401c30
 10035f0: 85 c0                        	test	eax, eax
 10035f2: 75 0c                        	jne	0x1003600 <.text+0x350>
 10035f4: 53                           	push	ebx
 10035f5: e8 66 00 22 00               	call	0x1223660 <.text+0x2203b0>
 10035fa: 89 45 8c                     	mov	dword ptr [ebp - 0x74], eax
 10035fd: 83 c4 04                     	add	esp, 0x4
 1003600: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003603: 51                           	push	ecx
 1003604: e8 47 1b 22 00               	call	0x1225150 <.text+0x221ea0>
 1003609: 83 c4 04                     	add	esp, 0x4
 100360c: 3a c3                        	cmp	al, bl
 100360e: 0f 85 7d fe ff ff            	jne	0x1003491 <.text+0x1e1>
 1003614: bf 07 00 00 00               	mov	edi, 0x7
 1003619: 8b 8d 64 ff ff ff            	mov	ecx, dword ptr [ebp - 0x9c]
 100361f: 8d 95 78 ff ff ff            	lea	edx, [ebp - 0x88]
 1003625: 52                           	push	edx
 1003626: 81 c1 c4 03 00 00            	add	ecx, 0x3c4
 100362c: e8 bf fb ff ff               	call	0x10031f0
 1003631: 83 7d a8 08                  	cmp	dword ptr [ebp - 0x58], 0x8
 1003635: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
 1003639: 72 0c                        	jb	0x1003647 <.text+0x397>
 100363b: 8b 45 94                     	mov	eax, dword ptr [ebp - 0x6c]
 100363e: 50                           	push	eax
 100363f: e8 e3 24 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003644: 83 c4 04                     	add	esp, 0x4
 1003647: 8b 55 90                     	mov	edx, dword ptr [ebp - 0x70]
 100364a: 33 c9                        	xor	ecx, ecx
 100364c: 52                           	push	edx
 100364d: 89 7d a8                     	mov	dword ptr [ebp - 0x58], edi
 1003650: 89 5d a4                     	mov	dword ptr [ebp - 0x5c], ebx
 1003653: 66 89 4d 94                  	mov	word ptr [ebp - 0x6c], cx
 1003657: e8 cb 24 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 100365c: 83 c4 04                     	add	esp, 0x4
 100365f: 8d 45 b0                     	lea	eax, [ebp - 0x50]
 1003662: 6a 01                        	push	0x1
 1003664: 50                           	push	eax
 1003665: e8 a6 1b 22 00               	call	0x1225210 <.text+0x221f60>
 100366a: 83 c4 08                     	add	esp, 0x8
 100366d: 84 c0                        	test	al, al
 100366f: 0f 85 4b fd ff ff            	jne	0x10033c0 <.text+0x110>
 1003675: be 08 00 00 00               	mov	esi, 0x8
 100367a: 39 75 e8                     	cmp	dword ptr [ebp - 0x18], esi
 100367d: 72 0c                        	jb	0x100368b <.text+0x3db>
 100367f: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
 1003682: 51                           	push	ecx
 1003683: e8 9f 24 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003688: 83 c4 04                     	add	esp, 0x4
 100368b: 8b 45 d0                     	mov	eax, dword ptr [ebp - 0x30]
 100368e: 33 d2                        	xor	edx, edx
 1003690: 50                           	push	eax
 1003691: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 1003694: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1003697: 66 89 55 d4                  	mov	word ptr [ebp - 0x2c], dx
 100369b: e8 87 24 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 10036a0: 83 c4 04                     	add	esp, 0x4
 10036a3: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 10036a6: 39 75 c8                     	cmp	dword ptr [ebp - 0x38], esi
 10036a9: 72 0c                        	jb	0x10036b7 <.text+0x407>
 10036ab: 8b 4d b4                     	mov	ecx, dword ptr [ebp - 0x4c]
 10036ae: 51                           	push	ecx
 10036af: e8 73 24 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 10036b4: 83 c4 04                     	add	esp, 0x4
 10036b7: 8b 45 b0                     	mov	eax, dword ptr [ebp - 0x50]
 10036ba: 33 d2                        	xor	edx, edx
 10036bc: 50                           	push	eax
 10036bd: 89 7d c8                     	mov	dword ptr [ebp - 0x38], edi
 10036c0: 89 5d c4                     	mov	dword ptr [ebp - 0x3c], ebx
 10036c3: 66 89 55 b4                  	mov	word ptr [ebp - 0x4c], dx
 10036c7: e8 5b 24 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 10036cc: 83 c4 04                     	add	esp, 0x4
 10036cf: b0 01                        	mov	al, 0x1
 10036d1: e9 45 fc ff ff               	jmp	0x100331b <.text+0x6b>
 10036d6: 8d 8d 74 ff ff ff            	lea	ecx, [ebp - 0x8c]
 10036dc: 51                           	push	ecx
 10036dd: 8d 8d 68 ff ff ff            	lea	ecx, [ebp - 0x98]
 10036e3: 89 9d 74 ff ff ff            	mov	dword ptr [ebp - 0x8c], ebx
 10036e9: e8 dc 2d 3d 00               	call	0x13d64ca <.text+0x3d321a>
 10036ee: 68 90 0f 91 01               	push	0x1910f90
 10036f3: 8d 95 68 ff ff ff            	lea	edx, [ebp - 0x98]
 10036f9: 52                           	push	edx
 10036fa: c7 85 68 ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0x98], 0x1562084
 1003704: e8 91 34 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 1003709: 8d 85 60 ff ff ff            	lea	eax, [ebp - 0xa0]
 100370f: 50                           	push	eax
 1003710: 8d 8d 54 ff ff ff            	lea	ecx, [ebp - 0xac]
 1003716: 89 9d 60 ff ff ff            	mov	dword ptr [ebp - 0xa0], ebx
 100371c: e8 a9 2d 3d 00               	call	0x13d64ca <.text+0x3d321a>
 1003721: 68 90 0f 91 01               	push	0x1910f90
 1003726: 8d 8d 54 ff ff ff            	lea	ecx, [ebp - 0xac]
 100372c: 51                           	push	ecx
 100372d: c7 85 54 ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0xac], 0x1562084
 1003737: e8 5e 34 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 100373c: 8d 95 74 ff ff ff            	lea	edx, [ebp - 0x8c]
 1003742: 52                           	push	edx
 1003743: 8d 8d 68 ff ff ff            	lea	ecx, [ebp - 0x98]
 1003749: 89 9d 74 ff ff ff            	mov	dword ptr [ebp - 0x8c], ebx
 100374f: e8 76 2d 3d 00               	call	0x13d64ca <.text+0x3d321a>
 1003754: 68 90 0f 91 01               	push	0x1910f90
 1003759: 8d 85 68 ff ff ff            	lea	eax, [ebp - 0x98]
 100375f: 50                           	push	eax
 1003760: c7 85 68 ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0x98], 0x1562084
 100376a: e8 2b 34 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 100376f: cc                           	int3
 1003770: 55                           	push	ebp
 1003771: 8b ec                        	mov	ebp, esp
 1003773: 6a ff                        	push	-0x1
 1003775: 68 59 2d 4b 01               	push	0x14b2d59
 100377a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1003780: 50                           	push	eax
 1003781: 81 ec d8 00 00 00            	sub	esp, 0xd8
 1003787: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 100378c: 33 c5                        	xor	eax, ebp
 100378e: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
 1003791: 53                           	push	ebx
 1003792: 56                           	push	esi
 1003793: 57                           	push	edi
 1003794: 50                           	push	eax
 1003795: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1003798: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 100379e: 8b 7d 08                     	mov	edi, dword ptr [ebp + 0x8]
 10037a1: 33 db                        	xor	ebx, ebx
 10037a3: 6a 08                        	push	0x8
 10037a5: 8b f1                        	mov	esi, ecx
 10037a7: 89 9d 58 ff ff ff            	mov	dword ptr [ebp - 0xa8], ebx
 10037ad: e8 68 33 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 10037b2: 83 c4 04                     	add	esp, 0x4
 10037b5: 3b c3                        	cmp	eax, ebx
 10037b7: 0f 84 a2 05 00 00            	je	0x1003d5f <.text+0xaaf>
 10037bd: 89 85 58 ff ff ff            	mov	dword ptr [ebp - 0xa8], eax
 10037c3: 33 c9                        	xor	ecx, ecx
 10037c5: 89 08                        	mov	dword ptr [eax], ecx
 10037c7: 33 d2                        	xor	edx, edx
 10037c9: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10037cc: 8b 8d 58 ff ff ff            	mov	ecx, dword ptr [ebp - 0xa8]
 10037d2: 8d 85 58 ff ff ff            	lea	eax, [ebp - 0xa8]
 10037d8: 89 01                        	mov	dword ptr [ecx], eax
 10037da: c7 85 70 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0x90], 0x7
 10037e4: 89 9d 6c ff ff ff            	mov	dword ptr [ebp - 0x94], ebx
 10037ea: 66 89 95 5c ff ff ff         	mov	word ptr [ebp - 0xa4], dx
 10037f1: 8d 8d 40 ff ff ff            	lea	ecx, [ebp - 0xc0]
 10037f7: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
 10037fa: e8 81 f6 ff ff               	call	0x1002e80
 10037ff: 8d 85 40 ff ff ff            	lea	eax, [ebp - 0xc0]
 1003805: 8d 8e c4 03 00 00            	lea	ecx, [esi + 0x3c4]
 100380b: 50                           	push	eax
 100380c: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
 1003813: 89 8d 1c ff ff ff            	mov	dword ptr [ebp - 0xe4], ecx
 1003819: e8 d2 f9 ff ff               	call	0x10031f0
 100381e: 8b c7                        	mov	eax, edi
 1003820: 8d 50 02                     	lea	edx, [eax + 0x2]
 1003823: 66 8b 08                     	mov	cx, word ptr [eax]
 1003826: 83 c0 02                     	add	eax, 0x2
 1003829: 66 3b cb                     	cmp	cx, bx
 100382c: 75 f5                        	jne	0x1003823 <.text+0x573>
 100382e: 2b c2                        	sub	eax, edx
 1003830: d1 f8                        	sar	eax
 1003832: 50                           	push	eax
 1003833: 57                           	push	edi
 1003834: 8d 8e dc 03 00 00            	lea	ecx, [esi + 0x3dc]
 100383a: e8 f1 c7 40 ff               	call	0x410030
 100383f: 80 7d 0c 00                  	cmp	byte ptr [ebp + 0xc], 0x0
 1003843: 74 60                        	je	0x10038a5 <.text+0x5f5>
 1003845: 83 bd 70 ff ff ff 08         	cmp	dword ptr [ebp - 0x90], 0x8
 100384c: 72 0f                        	jb	0x100385d <.text+0x5ad>
 100384e: 8b 8d 5c ff ff ff            	mov	ecx, dword ptr [ebp - 0xa4]
 1003854: 51                           	push	ecx
 1003855: e8 cd 22 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 100385a: 83 c4 04                     	add	esp, 0x4
 100385d: 8b 85 58 ff ff ff            	mov	eax, dword ptr [ebp - 0xa8]
 1003863: 33 d2                        	xor	edx, edx
 1003865: 50                           	push	eax
 1003866: c7 85 70 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0x90], 0x7
 1003870: 89 9d 6c ff ff ff            	mov	dword ptr [ebp - 0x94], ebx
 1003876: 66 89 95 5c ff ff ff         	mov	word ptr [ebp - 0xa4], dx
 100387d: e8 a5 22 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003882: 83 c4 04                     	add	esp, 0x4
 1003885: b0 01                        	mov	al, 0x1
 1003887: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 100388a: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1003891: 59                           	pop	ecx
 1003892: 5f                           	pop	edi
 1003893: 5e                           	pop	esi
 1003894: 5b                           	pop	ebx
 1003895: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
 1003898: 33 cd                        	xor	ecx, ebp
 100389a: e8 39 39 3d 00               	call	0x13d71d8 <.text+0x3d3f28>
 100389f: 8b e5                        	mov	esp, ebp
 10038a1: 5d                           	pop	ebp
 10038a2: c2 08 00                     	ret	0x8
 10038a5: 83 be f4 03 00 00 08         	cmp	dword ptr [esi + 0x3f4], 0x8
 10038ac: 72 08                        	jb	0x10038b6 <.text+0x606>
 10038ae: 8b b6 e0 03 00 00            	mov	esi, dword ptr [esi + 0x3e0]
 10038b4: eb 06                        	jmp	0x10038bc <.text+0x60c>
 10038b6: 81 c6 e0 03 00 00            	add	esi, 0x3e0
 10038bc: 56                           	push	esi
 10038bd: 68 78 21 56 01               	push	0x1562178
 10038c2: e8 29 c6 19 00               	call	0x119fef0 <.text+0x19cc40>
 10038c7: 83 c4 04                     	add	esp, 0x4
 10038ca: 50                           	push	eax
 10038cb: e8 50 fd 21 00               	call	0x1223620 <.text+0x220370>
 10038d0: 83 c4 08                     	add	esp, 0x8
 10038d3: 84 c0                        	test	al, al
 10038d5: 75 07                        	jne	0x10038de <.text+0x62e>
 10038d7: 32 db                        	xor	bl, bl
 10038d9: e9 9d 03 00 00               	jmp	0x1003c7b <.text+0x9cb>
 10038de: 6a 08                        	push	0x8
 10038e0: 89 5d b0                     	mov	dword ptr [ebp - 0x50], ebx
 10038e3: e8 32 32 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 10038e8: 83 c4 04                     	add	esp, 0x4
 10038eb: 3b c3                        	cmp	eax, ebx
 10038ed: 0f 84 39 04 00 00            	je	0x1003d2c <.text+0xa7c>
 10038f3: 89 45 b0                     	mov	dword ptr [ebp - 0x50], eax
 10038f6: 33 c9                        	xor	ecx, ecx
 10038f8: 89 08                        	mov	dword ptr [eax], ecx
 10038fa: 33 d2                        	xor	edx, edx
 10038fc: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10038ff: 8b 55 b0                     	mov	edx, dword ptr [ebp - 0x50]
 1003902: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 1003905: 89 0a                        	mov	dword ptr [edx], ecx
 1003907: bf 07 00 00 00               	mov	edi, 0x7
 100390c: 33 c0                        	xor	eax, eax
 100390e: 89 7d c8                     	mov	dword ptr [ebp - 0x38], edi
 1003911: 89 5d c4                     	mov	dword ptr [ebp - 0x3c], ebx
 1003914: 66 89 45 b4                  	mov	word ptr [ebp - 0x4c], ax
 1003918: 6a 08                        	push	0x8
 100391a: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
 100391e: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 1003921: e8 f4 31 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 1003926: 83 c4 04                     	add	esp, 0x4
 1003929: 3b c3                        	cmp	eax, ebx
 100392b: 0f 84 c8 03 00 00            	je	0x1003cf9 <.text+0xa49>
 1003931: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
 1003934: 33 c9                        	xor	ecx, ecx
 1003936: 89 08                        	mov	dword ptr [eax], ecx
 1003938: 33 d2                        	xor	edx, edx
 100393a: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 100393d: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 1003940: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003943: 89 0a                        	mov	dword ptr [edx], ecx
 1003945: 33 c0                        	xor	eax, eax
 1003947: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 100394a: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 100394d: 66 89 45 d4                  	mov	word ptr [ebp - 0x2c], ax
 1003951: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 1003954: 6a 01                        	push	0x1
 1003956: 51                           	push	ecx
 1003957: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
 100395b: e8 b0 18 22 00               	call	0x1225210 <.text+0x221f60>
 1003960: 83 c4 08                     	add	esp, 0x8
 1003963: 84 c0                        	test	al, al
 1003965: 0f 84 b4 02 00 00            	je	0x1003c1f <.text+0x96f>
 100396b: eb 03                        	jmp	0x1003970 <.text+0x6c0>
 100396d: 8d 49 00                     	lea	ecx, [ecx]
 1003970: 68 ec b0 82 01               	push	0x182b0ec
 1003975: e8 76 c5 19 00               	call	0x119fef0 <.text+0x19cc40>
 100397a: 8b c8                        	mov	ecx, eax
 100397c: 83 c4 04                     	add	esp, 0x4
 100397f: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003982: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003985: 83 c1 02                     	add	ecx, 0x2
 1003988: 66 3b d3                     	cmp	dx, bx
 100398b: 75 f5                        	jne	0x1003982 <.text+0x6d2>
 100398d: 8b 55 c4                     	mov	edx, dword ptr [ebp - 0x3c]
 1003990: 2b ce                        	sub	ecx, esi
 1003992: d1 f9                        	sar	ecx
 1003994: 51                           	push	ecx
 1003995: 50                           	push	eax
 1003996: 52                           	push	edx
 1003997: 53                           	push	ebx
 1003998: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 100399b: e8 90 e2 3f ff               	call	0x401c30
 10039a0: 85 c0                        	test	eax, eax
 10039a2: 0f 85 61 02 00 00            	jne	0x1003c09 <.text+0x959>
 10039a8: 6a 08                        	push	0x8
 10039aa: 89 5d 90                     	mov	dword ptr [ebp - 0x70], ebx
 10039ad: e8 68 31 3d 00               	call	0x13d6b1a <.text+0x3d386a>
 10039b2: 83 c4 04                     	add	esp, 0x4
 10039b5: 3b c3                        	cmp	eax, ebx
 10039b7: 0f 84 09 03 00 00            	je	0x1003cc6 <.text+0xa16>
 10039bd: 89 45 90                     	mov	dword ptr [ebp - 0x70], eax
 10039c0: 33 c9                        	xor	ecx, ecx
 10039c2: 89 08                        	mov	dword ptr [eax], ecx
 10039c4: 33 d2                        	xor	edx, edx
 10039c6: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10039c9: 8b 4d 90                     	mov	ecx, dword ptr [ebp - 0x70]
 10039cc: 8d 45 90                     	lea	eax, [ebp - 0x70]
 10039cf: 89 01                        	mov	dword ptr [ecx], eax
 10039d1: 89 7d a8                     	mov	dword ptr [ebp - 0x58], edi
 10039d4: 89 5d a4                     	mov	dword ptr [ebp - 0x5c], ebx
 10039d7: 66 89 55 94                  	mov	word ptr [ebp - 0x6c], dx
 10039db: 83 c8 ff                     	or	eax, -0x1
 10039de: 68 78 21 56 01               	push	0x1562178
 10039e3: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
 10039e7: 89 9d 78 ff ff ff            	mov	dword ptr [ebp - 0x88], ebx
 10039ed: 89 9d 7c ff ff ff            	mov	dword ptr [ebp - 0x84], ebx
 10039f3: 89 5d 80                     	mov	dword ptr [ebp - 0x80], ebx
 10039f6: 89 5d 84                     	mov	dword ptr [ebp - 0x7c], ebx
 10039f9: 89 45 88                     	mov	dword ptr [ebp - 0x78], eax
 10039fc: 89 45 8c                     	mov	dword ptr [ebp - 0x74], eax
 10039ff: e8 ec c4 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003a04: 8b c8                        	mov	ecx, eax
 1003a06: 83 c4 04                     	add	esp, 0x4
 1003a09: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003a0c: 8d 64 24 00                  	lea	esp, [esp]
 1003a10: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003a13: 83 c1 02                     	add	ecx, 0x2
 1003a16: 66 3b d3                     	cmp	dx, bx
 1003a19: 75 f5                        	jne	0x1003a10 <.text+0x760>
 1003a1b: 2b ce                        	sub	ecx, esi
 1003a1d: d1 f9                        	sar	ecx
 1003a1f: 51                           	push	ecx
 1003a20: 50                           	push	eax
 1003a21: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1003a24: e8 07 c6 40 ff               	call	0x410030
 1003a29: 8d 45 d0                     	lea	eax, [ebp - 0x30]
 1003a2c: 50                           	push	eax
 1003a2d: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
 1003a31: e8 1a 17 22 00               	call	0x1225150 <.text+0x221ea0>
 1003a36: 83 c4 04                     	add	esp, 0x4
 1003a39: 84 c0                        	test	al, al
 1003a3b: 0f 84 88 01 00 00            	je	0x1003bc9 <.text+0x919>
 1003a41: 68 cc b0 82 01               	push	0x182b0cc
 1003a46: e8 a5 c4 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003a4b: 8b c8                        	mov	ecx, eax
 1003a4d: 83 c4 04                     	add	esp, 0x4
 1003a50: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003a53: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003a56: 83 c1 02                     	add	ecx, 0x2
 1003a59: 66 3b d3                     	cmp	dx, bx
 1003a5c: 75 f5                        	jne	0x1003a53 <.text+0x7a3>
 1003a5e: 8b 7d e4                     	mov	edi, dword ptr [ebp - 0x1c]
 1003a61: 2b ce                        	sub	ecx, esi
 1003a63: d1 f9                        	sar	ecx
 1003a65: 8b f7                        	mov	esi, edi
 1003a67: 3b f9                        	cmp	edi, ecx
 1003a69: 72 02                        	jb	0x1003a6d <.text+0x7bd>
 1003a6b: 8b f1                        	mov	esi, ecx
 1003a6d: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1003a71: 8b 55 d4                     	mov	edx, dword ptr [ebp - 0x2c]
 1003a74: 73 03                        	jae	0x1003a79 <.text+0x7c9>
 1003a76: 8d 55 d4                     	lea	edx, [ebp - 0x2c]
 1003a79: 3b f3                        	cmp	esi, ebx
 1003a7b: 76 24                        	jbe	0x1003aa1 <.text+0x7f1>
 1003a7d: 8d 49 00                     	lea	ecx, [ecx]
 1003a80: 66 8b 1a                     	mov	bx, word ptr [edx]
 1003a83: 66 3b 18                     	cmp	bx, word ptr [eax]
 1003a86: 75 0d                        	jne	0x1003a95 <.text+0x7e5>
 1003a88: 83 c2 02                     	add	edx, 0x2
 1003a8b: 83 c0 02                     	add	eax, 0x2
 1003a8e: 4e                           	dec	esi
 1003a8f: 75 ef                        	jne	0x1003a80 <.text+0x7d0>
 1003a91: 33 db                        	xor	ebx, ebx
 1003a93: eb 0c                        	jmp	0x1003aa1 <.text+0x7f1>
 1003a95: 1b c0                        	sbb	eax, eax
 1003a97: 83 e0 fe                     	and	eax, -0x2
 1003a9a: 40                           	inc	eax
 1003a9b: 33 db                        	xor	ebx, ebx
 1003a9d: 3b c3                        	cmp	eax, ebx
 1003a9f: 75 12                        	jne	0x1003ab3 <.text+0x803>
 1003aa1: 3b f9                        	cmp	edi, ecx
 1003aa3: 73 05                        	jae	0x1003aaa <.text+0x7fa>
 1003aa5: 83 c8 ff                     	or	eax, -0x1
 1003aa8: eb 07                        	jmp	0x1003ab1 <.text+0x801>
 1003aaa: 33 c0                        	xor	eax, eax
 1003aac: 3b f9                        	cmp	edi, ecx
 1003aae: 0f 95 c0                     	setne	al
 1003ab1: 3b c3                        	cmp	eax, ebx
 1003ab3: 0f 94 c0                     	sete	al
 1003ab6: 84 c0                        	test	al, al
 1003ab8: 74 11                        	je	0x1003acb <.text+0x81b>
 1003aba: 53                           	push	ebx
 1003abb: e8 a0 fb 21 00               	call	0x1223660 <.text+0x2203b0>
 1003ac0: 89 85 78 ff ff ff            	mov	dword ptr [ebp - 0x88], eax
 1003ac6: e9 e2 00 00 00               	jmp	0x1003bad <.text+0x8fd>
 1003acb: 68 30 1c 57 01               	push	0x1571c30
 1003ad0: e8 1b c4 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003ad5: 8b c8                        	mov	ecx, eax
 1003ad7: 83 c4 04                     	add	esp, 0x4
 1003ada: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003add: 8d 49 00                     	lea	ecx, [ecx]
 1003ae0: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003ae3: 83 c1 02                     	add	ecx, 0x2
 1003ae6: 66 3b d3                     	cmp	dx, bx
 1003ae9: 75 f5                        	jne	0x1003ae0 <.text+0x830>
 1003aeb: 2b ce                        	sub	ecx, esi
 1003aed: d1 f9                        	sar	ecx
 1003aef: 51                           	push	ecx
 1003af0: 50                           	push	eax
 1003af1: 8b 45 e4                     	mov	eax, dword ptr [ebp - 0x1c]
 1003af4: 50                           	push	eax
 1003af5: 53                           	push	ebx
 1003af6: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003af9: e8 32 e1 3f ff               	call	0x401c30
 1003afe: 85 c0                        	test	eax, eax
 1003b00: 75 0e                        	jne	0x1003b10 <.text+0x860>
 1003b02: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1003b05: 51                           	push	ecx
 1003b06: e8 45 16 22 00               	call	0x1225150 <.text+0x221ea0>
 1003b0b: e9 9d 00 00 00               	jmp	0x1003bad <.text+0x8fd>
 1003b10: 68 a4 b0 82 01               	push	0x182b0a4
 1003b15: e8 d6 c3 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003b1a: 8b c8                        	mov	ecx, eax
 1003b1c: 83 c4 04                     	add	esp, 0x4
 1003b1f: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003b22: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003b25: 83 c1 02                     	add	ecx, 0x2
 1003b28: 66 3b d3                     	cmp	dx, bx
 1003b2b: 75 f5                        	jne	0x1003b22 <.text+0x872>
 1003b2d: 8b 55 e4                     	mov	edx, dword ptr [ebp - 0x1c]
 1003b30: 2b ce                        	sub	ecx, esi
 1003b32: d1 f9                        	sar	ecx
 1003b34: 51                           	push	ecx
 1003b35: 50                           	push	eax
 1003b36: 52                           	push	edx
 1003b37: 53                           	push	ebx
 1003b38: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003b3b: e8 f0 e0 3f ff               	call	0x401c30
 1003b40: 85 c0                        	test	eax, eax
 1003b42: 75 2c                        	jne	0x1003b70 <.text+0x8c0>
 1003b44: 53                           	push	ebx
 1003b45: e8 16 fb 21 00               	call	0x1223660 <.text+0x2203b0>
 1003b4a: 53                           	push	ebx
 1003b4b: 89 85 7c ff ff ff            	mov	dword ptr [ebp - 0x84], eax
 1003b51: e8 0a fb 21 00               	call	0x1223660 <.text+0x2203b0>
 1003b56: 53                           	push	ebx
 1003b57: 89 45 80                     	mov	dword ptr [ebp - 0x80], eax
 1003b5a: e8 01 fb 21 00               	call	0x1223660 <.text+0x2203b0>
 1003b5f: 53                           	push	ebx
 1003b60: 89 45 84                     	mov	dword ptr [ebp - 0x7c], eax
 1003b63: e8 f8 fa 21 00               	call	0x1223660 <.text+0x2203b0>
 1003b68: 83 c4 10                     	add	esp, 0x10
 1003b6b: 89 45 88                     	mov	dword ptr [ebp - 0x78], eax
 1003b6e: eb 40                        	jmp	0x1003bb0 <.text+0x900>
 1003b70: 68 78 b0 82 01               	push	0x182b078
 1003b75: e8 76 c3 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003b7a: 8b c8                        	mov	ecx, eax
 1003b7c: 83 c4 04                     	add	esp, 0x4
 1003b7f: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1003b82: 66 8b 11                     	mov	dx, word ptr [ecx]
 1003b85: 83 c1 02                     	add	ecx, 0x2
 1003b88: 66 3b d3                     	cmp	dx, bx
 1003b8b: 75 f5                        	jne	0x1003b82 <.text+0x8d2>
 1003b8d: 2b ce                        	sub	ecx, esi
 1003b8f: d1 f9                        	sar	ecx
 1003b91: 51                           	push	ecx
 1003b92: 50                           	push	eax
 1003b93: 8b 45 e4                     	mov	eax, dword ptr [ebp - 0x1c]
 1003b96: 50                           	push	eax
 1003b97: 53                           	push	ebx
 1003b98: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003b9b: e8 90 e0 3f ff               	call	0x401c30
 1003ba0: 85 c0                        	test	eax, eax
 1003ba2: 75 0c                        	jne	0x1003bb0 <.text+0x900>
 1003ba4: 53                           	push	ebx
 1003ba5: e8 b6 fa 21 00               	call	0x1223660 <.text+0x2203b0>
 1003baa: 89 45 8c                     	mov	dword ptr [ebp - 0x74], eax
 1003bad: 83 c4 04                     	add	esp, 0x4
 1003bb0: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1003bb3: 51                           	push	ecx
 1003bb4: e8 97 15 22 00               	call	0x1225150 <.text+0x221ea0>
 1003bb9: 83 c4 04                     	add	esp, 0x4
 1003bbc: 84 c0                        	test	al, al
 1003bbe: 0f 85 7d fe ff ff            	jne	0x1003a41 <.text+0x791>
 1003bc4: bf 07 00 00 00               	mov	edi, 0x7
 1003bc9: 8b 8d 1c ff ff ff            	mov	ecx, dword ptr [ebp - 0xe4]
 1003bcf: 8d 95 78 ff ff ff            	lea	edx, [ebp - 0x88]
 1003bd5: 52                           	push	edx
 1003bd6: e8 15 f6 ff ff               	call	0x10031f0
 1003bdb: 83 7d a8 08                  	cmp	dword ptr [ebp - 0x58], 0x8
 1003bdf: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
 1003be3: 72 0c                        	jb	0x1003bf1 <.text+0x941>
 1003be5: 8b 45 94                     	mov	eax, dword ptr [ebp - 0x6c]
 1003be8: 50                           	push	eax
 1003be9: e8 39 1f 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003bee: 83 c4 04                     	add	esp, 0x4
 1003bf1: 8b 55 90                     	mov	edx, dword ptr [ebp - 0x70]
 1003bf4: 33 c9                        	xor	ecx, ecx
 1003bf6: 52                           	push	edx
 1003bf7: 89 7d a8                     	mov	dword ptr [ebp - 0x58], edi
 1003bfa: 89 5d a4                     	mov	dword ptr [ebp - 0x5c], ebx
 1003bfd: 66 89 4d 94                  	mov	word ptr [ebp - 0x6c], cx
 1003c01: e8 21 1f 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003c06: 83 c4 04                     	add	esp, 0x4
 1003c09: 8d 45 b0                     	lea	eax, [ebp - 0x50]
 1003c0c: 6a 01                        	push	0x1
 1003c0e: 50                           	push	eax
 1003c0f: e8 fc 15 22 00               	call	0x1225210 <.text+0x221f60>
 1003c14: 83 c4 08                     	add	esp, 0x8
 1003c17: 84 c0                        	test	al, al
 1003c19: 0f 85 51 fd ff ff            	jne	0x1003970 <.text+0x6c0>
 1003c1f: be 08 00 00 00               	mov	esi, 0x8
 1003c24: 39 75 e8                     	cmp	dword ptr [ebp - 0x18], esi
 1003c27: 72 0c                        	jb	0x1003c35 <.text+0x985>
 1003c29: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
 1003c2c: 51                           	push	ecx
 1003c2d: e8 f5 1e 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003c32: 83 c4 04                     	add	esp, 0x4
 1003c35: 8b 45 d0                     	mov	eax, dword ptr [ebp - 0x30]
 1003c38: 33 d2                        	xor	edx, edx
 1003c3a: 50                           	push	eax
 1003c3b: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 1003c3e: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1003c41: 66 89 55 d4                  	mov	word ptr [ebp - 0x2c], dx
 1003c45: e8 dd 1e 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003c4a: 83 c4 04                     	add	esp, 0x4
 1003c4d: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 1003c50: 39 75 c8                     	cmp	dword ptr [ebp - 0x38], esi
 1003c53: 72 0c                        	jb	0x1003c61 <.text+0x9b1>
 1003c55: 8b 4d b4                     	mov	ecx, dword ptr [ebp - 0x4c]
 1003c58: 51                           	push	ecx
 1003c59: e8 c9 1e 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003c5e: 83 c4 04                     	add	esp, 0x4
 1003c61: 8b 45 b0                     	mov	eax, dword ptr [ebp - 0x50]
 1003c64: 33 d2                        	xor	edx, edx
 1003c66: 50                           	push	eax
 1003c67: 89 7d c8                     	mov	dword ptr [ebp - 0x38], edi
 1003c6a: 89 5d c4                     	mov	dword ptr [ebp - 0x3c], ebx
 1003c6d: 66 89 55 b4                  	mov	word ptr [ebp - 0x4c], dx
 1003c71: e8 b1 1e 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003c76: 83 c4 04                     	add	esp, 0x4
 1003c79: b3 01                        	mov	bl, 0x1
 1003c7b: 83 bd 70 ff ff ff 08         	cmp	dword ptr [ebp - 0x90], 0x8
 1003c82: 72 0f                        	jb	0x1003c93 <.text+0x9e3>
 1003c84: 8b 8d 5c ff ff ff            	mov	ecx, dword ptr [ebp - 0xa4]
 1003c8a: 51                           	push	ecx
 1003c8b: e8 97 1e 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003c90: 83 c4 04                     	add	esp, 0x4
 1003c93: 8b 85 58 ff ff ff            	mov	eax, dword ptr [ebp - 0xa8]
 1003c99: 33 d2                        	xor	edx, edx
 1003c9b: 50                           	push	eax
 1003c9c: c7 85 70 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0x90], 0x7
 1003ca6: c7 85 6c ff ff ff 00 00 00 00	mov	dword ptr [ebp - 0x94], 0x0
 1003cb0: 66 89 95 5c ff ff ff         	mov	word ptr [ebp - 0xa4], dx
 1003cb7: e8 6b 1e 3d 00               	call	0x13d5b27 <.text+0x3d2877>
 1003cbc: 83 c4 04                     	add	esp, 0x4
 1003cbf: 8a c3                        	mov	al, bl
 1003cc1: e9 c1 fb ff ff               	jmp	0x1003887 <.text+0x5d7>
 1003cc6: 8d 8d 38 ff ff ff            	lea	ecx, [ebp - 0xc8]
 1003ccc: 51                           	push	ecx
 1003ccd: 8d 8d 20 ff ff ff            	lea	ecx, [ebp - 0xe0]
 1003cd3: 89 9d 38 ff ff ff            	mov	dword ptr [ebp - 0xc8], ebx
 1003cd9: e8 ec 27 3d 00               	call	0x13d64ca <.text+0x3d321a>
 1003cde: 68 90 0f 91 01               	push	0x1910f90
 1003ce3: 8d 95 20 ff ff ff            	lea	edx, [ebp - 0xe0]
 1003ce9: 52                           	push	edx
 1003cea: c7 85 20 ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0xe0], 0x1562084
 1003cf4: e8 a1 2e 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 1003cf9: 8d 85 3c ff ff ff            	lea	eax, [ebp - 0xc4]
 1003cff: 50                           	push	eax
 1003d00: 8d 8d 2c ff ff ff            	lea	ecx, [ebp - 0xd4]
 1003d06: 89 9d 3c ff ff ff            	mov	dword ptr [ebp - 0xc4], ebx
 1003d0c: e8 b9 27 3d 00               	call	0x13d64ca <.text+0x3d321a>
 1003d11: 68 90 0f 91 01               	push	0x1910f90
 1003d16: 8d 8d 2c ff ff ff            	lea	ecx, [ebp - 0xd4]
 1003d1c: 51                           	push	ecx
 1003d1d: c7 85 2c ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0xd4], 0x1562084
 1003d27: e8 6e 2e 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 1003d2c: 8d 95 38 ff ff ff            	lea	edx, [ebp - 0xc8]
 1003d32: 52                           	push	edx
 1003d33: 8d 8d 20 ff ff ff            	lea	ecx, [ebp - 0xe0]
 1003d39: 89 9d 38 ff ff ff            	mov	dword ptr [ebp - 0xc8], ebx
 1003d3f: e8 86 27 3d 00               	call	0x13d64ca <.text+0x3d321a>
 1003d44: 68 90 0f 91 01               	push	0x1910f90
 1003d49: 8d 85 20 ff ff ff            	lea	eax, [ebp - 0xe0]
 1003d4f: 50                           	push	eax
 1003d50: c7 85 20 ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0xe0], 0x1562084
 1003d5a: e8 3b 2e 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 1003d5f: 8d 8d 3c ff ff ff            	lea	ecx, [ebp - 0xc4]
 1003d65: 51                           	push	ecx
 1003d66: 8d 8d 2c ff ff ff            	lea	ecx, [ebp - 0xd4]
 1003d6c: 89 9d 3c ff ff ff            	mov	dword ptr [ebp - 0xc4], ebx
 1003d72: e8 53 27 3d 00               	call	0x13d64ca <.text+0x3d321a>
 1003d77: 68 90 0f 91 01               	push	0x1910f90
 1003d7c: 8d 95 2c ff ff ff            	lea	edx, [ebp - 0xd4]
 1003d82: 52                           	push	edx
 1003d83: c7 85 2c ff ff ff 84 20 56 01	mov	dword ptr [ebp - 0xd4], 0x1562084
 1003d8d: e8 08 2e 3d 00               	call	0x13d6b9a <.text+0x3d38ea>
 1003d92: cc                           	int3
 1003d93: cc                           	int3
 1003d94: cc                           	int3
 1003d95: cc                           	int3
 1003d96: cc                           	int3
 1003d97: cc                           	int3
 1003d98: cc                           	int3
 1003d99: cc                           	int3
 1003d9a: cc                           	int3
 1003d9b: cc                           	int3
 1003d9c: cc                           	int3
 1003d9d: cc                           	int3
 1003d9e: cc                           	int3
 1003d9f: cc                           	int3
 1003da0: 33 c0                        	xor	eax, eax
 1003da2: 89 41 04                     	mov	dword ptr [ecx + 0x4], eax
 1003da5: 89 41 14                     	mov	dword ptr [ecx + 0x14], eax
 1003da8: 89 41 34                     	mov	dword ptr [ecx + 0x34], eax
 1003dab: 89 41 38                     	mov	dword ptr [ecx + 0x38], eax
 1003dae: c3                           	ret
 1003daf: cc                           	int3
 1003db0: 55                           	push	ebp
 1003db1: 8b ec                        	mov	ebp, esp
 1003db3: 6a ff                        	push	-0x1
 1003db5: 68 16 ec 41 01               	push	0x141ec16
 1003dba: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1003dc0: 50                           	push	eax
 1003dc1: 51                           	push	ecx
 1003dc2: 56                           	push	esi
 1003dc3: 57                           	push	edi
 1003dc4: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 1003dc9: 33 c5                        	xor	eax, ebp
 1003dcb: 50                           	push	eax
 1003dcc: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1003dcf: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 1003dd5: 8b f1                        	mov	esi, ecx
 1003dd7: c7 46 08 cb 00 00 00         	mov	dword ptr [esi + 0x8], 0xcb
 1003dde: c7 46 0c d1 00 00 00         	mov	dword ptr [esi + 0xc], 0xd1
 1003de5: a1 e4 64 b5 01               	mov	eax, dword ptr [0x1b564e4]
 1003dea: 8b 38                        	mov	edi, dword ptr [eax]
 1003dec: 68 e8 b1 82 01               	push	0x182b1e8
 1003df1: e8 fa c0 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003df6: 8b 0d e4 64 b5 01            	mov	ecx, dword ptr [0x1b564e4]
 1003dfc: 8b 57 10                     	mov	edx, dword ptr [edi + 0x10]
 1003dff: 83 c4 04                     	add	esp, 0x4
 1003e02: 50                           	push	eax
 1003e03: ff d2                        	call	edx
 1003e05: 68 fc 01 00 00               	push	0x1fc
 1003e0a: 89 46 14                     	mov	dword ptr [esi + 0x14], eax
 1003e0d: e8 6e c5 1a 00               	call	0x11b0380 <.text+0x1ad0d0>
 1003e12: 8b f8                        	mov	edi, eax
 1003e14: 83 c4 04                     	add	esp, 0x4
 1003e17: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
 1003e1a: c7 45 fc 00 00 00 00         	mov	dword ptr [ebp - 0x4], 0x0
 1003e21: 85 ff                        	test	edi, edi
 1003e23: 74 1b                        	je	0x1003e40 <.text+0xb90>
 1003e25: 6a 00                        	push	0x0
 1003e27: 6a 01                        	push	0x1
 1003e29: 68 78 b1 82 01               	push	0x182b178
 1003e2e: e8 bd c0 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003e33: 83 c4 04                     	add	esp, 0x4
 1003e36: 50                           	push	eax
 1003e37: 8b cf                        	mov	ecx, edi
 1003e39: e8 a2 66 09 00               	call	0x109a4e0 <.text+0x97230>
 1003e3e: eb 02                        	jmp	0x1003e42 <.text+0xb92>
 1003e40: 33 c0                        	xor	eax, eax
 1003e42: 68 fc 01 00 00               	push	0x1fc
 1003e47: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1003e4e: 89 46 34                     	mov	dword ptr [esi + 0x34], eax
 1003e51: e8 2a c5 1a 00               	call	0x11b0380 <.text+0x1ad0d0>
 1003e56: 8b f8                        	mov	edi, eax
 1003e58: 83 c4 04                     	add	esp, 0x4
 1003e5b: 89 7d f0                     	mov	dword ptr [ebp - 0x10], edi
 1003e5e: c7 45 fc 01 00 00 00         	mov	dword ptr [ebp - 0x4], 0x1
 1003e65: 85 ff                        	test	edi, edi
 1003e67: 74 1b                        	je	0x1003e84 <.text+0xbd4>
 1003e69: 6a 00                        	push	0x0
 1003e6b: 6a 01                        	push	0x1
 1003e6d: 68 20 b1 82 01               	push	0x182b120
 1003e72: e8 79 c0 19 00               	call	0x119fef0 <.text+0x19cc40>
 1003e77: 83 c4 04                     	add	esp, 0x4
 1003e7a: 50                           	push	eax
 1003e7b: 8b cf                        	mov	ecx, edi
 1003e7d: e8 5e 66 09 00               	call	0x109a4e0 <.text+0x97230>
 1003e82: eb 02                        	jmp	0x1003e86 <.text+0xbd6>
 1003e84: 33 c0                        	xor	eax, eax
 1003e86: 8d 4e 18                     	lea	ecx, [esi + 0x18]
 1003e89: c7 45 fc ff ff ff ff         	mov	dword ptr [ebp - 0x4], 0xffffffff
 1003e90: 89 46 38                     	mov	dword ptr [esi + 0x38], eax
 1003e93: c7 46 10 00 00 00 00         	mov	dword ptr [esi + 0x10], 0x0
 1003e9a: e8 71 56 1c 00               	call	0x11c9510 <.text+0x1c6260>
 1003e9f: a1 6c 65 b5 01               	mov	eax, dword ptr [0x1b5656c]
 1003ea4: b9 e4 00 00 00               	mov	ecx, 0xe4
 1003ea9: 89 46 20                     	mov	dword ptr [esi + 0x20], eax
 1003eac: 66 89 4e 1a                  	mov	word ptr [esi + 0x1a], cx
 1003eb0: c6 46 1e 01                  	mov	byte ptr [esi + 0x1e], 0x1
 1003eb4: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1003eb7: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1003ebe: 59                           	pop	ecx
 1003ebf: 5f                           	pop	edi
 1003ec0: 5e                           	pop	esi
 1003ec1: 8b e5                        	mov	esp, ebp
 1003ec3: 5d                           	pop	ebp
 1003ec4: c3                           	ret
 1003ec5: cc                           	int3
 1003ec6: cc                           	int3
 1003ec7: cc                           	int3
 1003ec8: cc                           	int3
 1003ec9: cc                           	int3
 1003eca: cc                           	int3
 1003ecb: cc                           	int3
 1003ecc: cc                           	int3
 1003ecd: cc                           	int3
 1003ece: cc                           	int3
 1003ecf: cc                           	int3
 1003ed0: 55                           	push	ebp
 1003ed1: 8b ec                        	mov	ebp, esp
 1003ed3: 53                           	push	ebx
 1003ed4: 56                           	push	esi
 1003ed5: 8b f1                        	mov	esi, ecx
 1003ed7: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003edd: 8b 01                        	mov	eax, dword ptr [ecx]
 1003edf: 8b 40 4c                     	mov	eax, dword ptr [eax + 0x4c]
 1003ee2: 57                           	push	edi
 1003ee3: 8d 56 18                     	lea	edx, [esi + 0x18]
 1003ee6: 52                           	push	edx
 1003ee7: ff d0                        	call	eax
 1003ee9: 0f b6 7d 08                  	movzx	edi, byte ptr [ebp + 0x8]
 1003eed: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003ef3: 8b 19                        	mov	ebx, dword ptr [ecx]
 1003ef5: c1 e7 18                     	shl	edi, 0x18
 1003ef8: 68 2c a5 00 00               	push	0xa52c
 1003efd: 81 cf e6 c8 9b 00            	or	edi, 0x9bc8e6
 1003f03: e8 58 73 22 00               	call	0x122b260 <.text+0x227fb0>
 1003f08: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
 1003f0b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f11: 83 c4 04                     	add	esp, 0x4
 1003f14: 50                           	push	eax
 1003f15: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 1003f18: 57                           	push	edi
 1003f19: 83 c2 54                     	add	edx, 0x54
 1003f1c: 52                           	push	edx
 1003f1d: 8b 53 5c                     	mov	edx, dword ptr [ebx + 0x5c]
 1003f20: 83 c0 50                     	add	eax, 0x50
 1003f23: 50                           	push	eax
 1003f24: ff d2                        	call	edx
 1003f26: a1 2c 58 b5 01               	mov	eax, dword ptr [0x1b5582c]
 1003f2b: 8b 18                        	mov	ebx, dword ptr [eax]
 1003f2d: 68 2d a5 00 00               	push	0xa52d
 1003f32: e8 29 73 22 00               	call	0x122b260 <.text+0x227fb0>
 1003f37: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 1003f3a: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 1003f3d: 83 c4 04                     	add	esp, 0x4
 1003f40: 50                           	push	eax
 1003f41: 8b 43 5c                     	mov	eax, dword ptr [ebx + 0x5c]
 1003f44: 57                           	push	edi
 1003f45: 83 c1 66                     	add	ecx, 0x66
 1003f48: 51                           	push	ecx
 1003f49: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f4f: 83 c2 50                     	add	edx, 0x50
 1003f52: 52                           	push	edx
 1003f53: ff d0                        	call	eax
 1003f55: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f5b: 8b 19                        	mov	ebx, dword ptr [ecx]
 1003f5d: 68 2e a5 00 00               	push	0xa52e
 1003f62: e8 f9 72 22 00               	call	0x122b260 <.text+0x227fb0>
 1003f67: 8b 56 0c                     	mov	edx, dword ptr [esi + 0xc]
 1003f6a: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f70: 83 c4 04                     	add	esp, 0x4
 1003f73: 50                           	push	eax
 1003f74: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 1003f77: 57                           	push	edi
 1003f78: 83 c2 78                     	add	edx, 0x78
 1003f7b: 52                           	push	edx
 1003f7c: 8b 53 5c                     	mov	edx, dword ptr [ebx + 0x5c]
 1003f7f: 83 c0 50                     	add	eax, 0x50
 1003f82: 50                           	push	eax
 1003f83: ff d2                        	call	edx
 1003f85: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1003f8b: 8b 01                        	mov	eax, dword ptr [ecx]
 1003f8d: 8b 50 50                     	mov	edx, dword ptr [eax + 0x50]
 1003f90: ff d2                        	call	edx
 1003f92: 5f                           	pop	edi
 1003f93: 5e                           	pop	esi
 1003f94: 5b                           	pop	ebx
 1003f95: 5d                           	pop	ebp
 1003f96: c2 04 00                     	ret	0x4
 1003f99: cc                           	int3
 1003f9a: cc                           	int3
 1003f9b: cc                           	int3
 1003f9c: cc                           	int3
 1003f9d: cc                           	int3
 1003f9e: cc                           	int3
 1003f9f: cc                           	int3
 1003fa0: 53                           	push	ebx
 1003fa1: 56                           	push	esi
 1003fa2: 8b f1                        	mov	esi, ecx
 1003fa4: 57                           	push	edi
 1003fa5: 8b 7e 34                     	mov	edi, dword ptr [esi + 0x34]
 1003fa8: 33 db                        	xor	ebx, ebx
 1003faa: 89 5e 04                     	mov	dword ptr [esi + 0x4], ebx
 1003fad: 3b fb                        	cmp	edi, ebx
 1003faf: 74 10                        	je	0x1003fc1 <.text+0xd11>
 1003fb1: 8b cf                        	mov	ecx, edi
 1003fb3: e8 78 4d 09 00               	call	0x1098d30 <.text+0x95a80>
 1003fb8: 57                           	push	edi
 1003fb9: e8 02 c4 1a 00               	call	0x11b03c0 <.text+0x1ad110>
 1003fbe: 83 c4 04                     	add	esp, 0x4
 1003fc1: 8b 7e 38                     	mov	edi, dword ptr [esi + 0x38]
 1003fc4: 89 5e 34                     	mov	dword ptr [esi + 0x34], ebx
 1003fc7: 3b fb                        	cmp	edi, ebx
 1003fc9: 74 10                        	je	0x1003fdb <.text+0xd2b>
 1003fcb: 8b cf                        	mov	ecx, edi
 1003fcd: e8 5e 4d 09 00               	call	0x1098d30 <.text+0x95a80>
 1003fd2: 57                           	push	edi
 1003fd3: e8 e8 c3 1a 00               	call	0x11b03c0 <.text+0x1ad110>
 1003fd8: 83 c4 04                     	add	esp, 0x4
 1003fdb: 5f                           	pop	edi
 1003fdc: 89 5e 38                     	mov	dword ptr [esi + 0x38], ebx
 1003fdf: 5e                           	pop	esi
 1003fe0: 5b                           	pop	ebx
 1003fe1: c3                           	ret
 1003fe2: cc                           	int3
 1003fe3: cc                           	int3
 1003fe4: cc                           	int3
 1003fe5: cc                           	int3
 1003fe6: cc                           	int3
 1003fe7: cc                           	int3
 1003fe8: cc                           	int3
 1003fe9: cc                           	int3
 1003fea: cc                           	int3
 1003feb: cc                           	int3
 1003fec: cc                           	int3
 1003fed: cc                           	int3
 1003fee: cc                           	int3
 1003fef: cc                           	int3
 1003ff0: 55                           	push	ebp
 1003ff1: 8b ec                        	mov	ebp, esp
 1003ff3: 56                           	push	esi
 1003ff4: 8b f1                        	mov	esi, ecx
 1003ff6: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 1003ff9: f6 81 ec 01 00 00 08         	test	byte ptr [ecx + 0x1ec], 0x8
 1004000: 75 26                        	jne	0x1004028 <.text+0xd78>
 1004002: e8 b9 84 09 00               	call	0x109c4c0 <.text+0x99210>
 1004007: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
 100400a: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
 100400d: 8b 15 2c 58 b5 01            	mov	edx, dword ptr [0x1b5582c]
 1004013: 6a 01                        	push	0x1
 1004015: 6a 00                        	push	0x0
 1004017: 83 c0 14                     	add	eax, 0x14
 100401a: 50                           	push	eax
 100401b: 83 c1 4b                     	add	ecx, 0x4b
 100401e: 51                           	push	ecx
 100401f: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 1004022: 52                           	push	edx
 1004023: e8 58 25 09 00               	call	0x1096580 <.text+0x932d0>
 1004028: 8b 46 34                     	mov	eax, dword ptr [esi + 0x34]
 100402b: f6 80 ec 01 00 00 08         	test	byte ptr [eax + 0x1ec], 0x8
 1004032: 74 66                        	je	0x100409a <.text+0xdea>
 1004034: 0f b6 45 08                  	movzx	eax, byte ptr [ebp + 0x8]
 1004038: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 1004040: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 1004043: 83 ec 08                     	sub	esp, 0x8
 1004046: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 100404c: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004051: 0f 57 c0                     	xorps	xmm0, xmm0
 1004054: c1 e0 18                     	shl	eax, 0x18
 1004057: 0d ff ff ff 00               	or	eax, 0xffffff
 100405c: 50                           	push	eax
 100405d: 83 ec 0c                     	sub	esp, 0xc
 1004060: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004066: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100406e: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004074: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004079: 6a 07                        	push	0x7
 100407b: e8 50 0b 1b 00               	call	0x11b4bd0 <.text+0x1b1920>
 1004080: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 1004083: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 1004086: 50                           	push	eax
 1004087: 83 c1 13                     	add	ecx, 0x13
 100408a: 51                           	push	ecx
 100408b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1004091: 83 c2 48                     	add	edx, 0x48
 1004094: 52                           	push	edx
 1004095: e8 46 01 1b 00               	call	0x11b41e0 <.text+0x1b0f30>
 100409a: 5e                           	pop	esi
 100409b: 5d                           	pop	ebp
 100409c: c2 04 00                     	ret	0x4
 100409f: cc                           	int3
 10040a0: 55                           	push	ebp
 10040a1: 8b ec                        	mov	ebp, esp
 10040a3: 56                           	push	esi
 10040a4: 8b f1                        	mov	esi, ecx
 10040a6: 8b 4e 38                     	mov	ecx, dword ptr [esi + 0x38]
 10040a9: f6 81 ec 01 00 00 08         	test	byte ptr [ecx + 0x1ec], 0x8
 10040b0: 75 26                        	jne	0x10040d8 <.text+0xe28>
 10040b2: e8 09 84 09 00               	call	0x109c4c0 <.text+0x99210>
 10040b7: 8b 46 0c                     	mov	eax, dword ptr [esi + 0xc]
 10040ba: 8b 4e 08                     	mov	ecx, dword ptr [esi + 0x8]
 10040bd: 8b 15 2c 58 b5 01            	mov	edx, dword ptr [0x1b5582c]
 10040c3: 6a 01                        	push	0x1
 10040c5: 6a 00                        	push	0x0
 10040c7: 83 c0 23                     	add	eax, 0x23
 10040ca: 50                           	push	eax
 10040cb: 83 c1 7d                     	add	ecx, 0x7d
 10040ce: 51                           	push	ecx
 10040cf: 8b 4e 38                     	mov	ecx, dword ptr [esi + 0x38]
 10040d2: 52                           	push	edx
 10040d3: e8 a8 24 09 00               	call	0x1096580 <.text+0x932d0>
 10040d8: 8b 46 38                     	mov	eax, dword ptr [esi + 0x38]
 10040db: f6 80 ec 01 00 00 08         	test	byte ptr [eax + 0x1ec], 0x8
 10040e2: 74 66                        	je	0x100414a <.text+0xe9a>
 10040e4: 0f b6 45 08                  	movzx	eax, byte ptr [ebp + 0x8]
 10040e8: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 10040f0: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 10040f3: 83 ec 08                     	sub	esp, 0x8
 10040f6: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 10040fc: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004101: 0f 57 c0                     	xorps	xmm0, xmm0
 1004104: c1 e0 18                     	shl	eax, 0x18
 1004107: 0d ff ff ff 00               	or	eax, 0xffffff
 100410c: 50                           	push	eax
 100410d: 83 ec 0c                     	sub	esp, 0xc
 1004110: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004116: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100411e: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004124: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004129: 6a 01                        	push	0x1
 100412b: e8 a0 0a 1b 00               	call	0x11b4bd0 <.text+0x1b1920>
 1004130: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 1004133: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 1004136: 50                           	push	eax
 1004137: 83 c1 23                     	add	ecx, 0x23
 100413a: 51                           	push	ecx
 100413b: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 1004141: 83 c2 7d                     	add	edx, 0x7d
 1004144: 52                           	push	edx
 1004145: e8 96 00 1b 00               	call	0x11b41e0 <.text+0x1b0f30>
 100414a: 5e                           	pop	esi
 100414b: 5d                           	pop	ebp
 100414c: c2 04 00                     	ret	0x4
 100414f: cc                           	int3
 1004150: 55                           	push	ebp
 1004151: 8b ec                        	mov	ebp, esp
 1004153: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 100415b: 53                           	push	ebx
 100415c: 8b 5d 08                     	mov	ebx, dword ptr [ebp + 0x8]
 100415f: 56                           	push	esi
 1004160: 83 ec 08                     	sub	esp, 0x8
 1004163: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004169: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100416e: 0f 57 c0                     	xorps	xmm0, xmm0
 1004171: 0f b6 c3                     	movzx	eax, bl
 1004174: c1 e0 18                     	shl	eax, 0x18
 1004177: 0d ff ff ff 00               	or	eax, 0xffffff
 100417c: 50                           	push	eax
 100417d: 83 ec 0c                     	sub	esp, 0xc
 1004180: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 1004186: f3 0f 10 05 fc 20 56 01      	movss	xmm0, dword ptr [0x15620fc]
 100418e: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 1004194: 8b f1                        	mov	esi, ecx
 1004196: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 1004199: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 100419e: 6a 00                        	push	0x0
 10041a0: e8 2b 0a 1b 00               	call	0x11b4bd0 <.text+0x1b1920>
 10041a5: 8b 4e 0c                     	mov	ecx, dword ptr [esi + 0xc]
 10041a8: 8b 56 08                     	mov	edx, dword ptr [esi + 0x8]
 10041ab: 50                           	push	eax
 10041ac: 51                           	push	ecx
 10041ad: 8b 0d 2c 58 b5 01            	mov	ecx, dword ptr [0x1b5582c]
 10041b3: 52                           	push	edx
 10041b4: e8 27 00 1b 00               	call	0x11b41e0 <.text+0x1b0f30>
 10041b9: 53                           	push	ebx
 10041ba: 8b ce                        	mov	ecx, esi
 10041bc: e8 2f fe ff ff               	call	0x1003ff0 <.text+0xd40>
 10041c1: 53                           	push	ebx
 10041c2: 8b ce                        	mov	ecx, esi
 10041c4: e8 d7 fe ff ff               	call	0x10040a0 <.text+0xdf0>
 10041c9: 53                           	push	ebx
 10041ca: 8b ce                        	mov	ecx, esi
 10041cc: e8 ff fc ff ff               	call	0x1003ed0 <.text+0xc20>
 10041d1: 5e                           	pop	esi
 10041d2: 5b                           	pop	ebx
 10041d3: 5d                           	pop	ebp
 10041d4: c2 04 00                     	ret	0x4
 10041d7: cc                           	int3
 10041d8: cc                           	int3
 10041d9: cc                           	int3
 10041da: cc                           	int3
 10041db: cc                           	int3
 10041dc: cc                           	int3
 10041dd: cc                           	int3
 10041de: cc                           	int3
 10041df: cc                           	int3
 10041e0: 56                           	push	esi
 10041e1: 8b f1                        	mov	esi, ecx
 10041e3: 8b 46 04                     	mov	eax, dword ptr [esi + 0x4]
 10041e6: 48                           	dec	eax
 10041e7: 83 f8 07                     	cmp	eax, 0x7
 10041ea: 0f 87 8b 03 00 00            	ja	0x100457b <.text+0x12cb>
 10041f0: 53                           	push	ebx
 10041f1: 57                           	push	edi
 10041f2: ff 24 85 80 45 00 01         	jmp	dword ptr [4*eax + 0x1004580]
 10041f9: ff 46 10                     	inc	dword ptr [esi + 0x10]
 10041fc: 83 7e 10 3c                  	cmp	dword ptr [esi + 0x10], 0x3c
 1004200: 0f 8e 73 03 00 00            	jle	0x1004579 <.text+0x12c9>
 1004206: c7 46 04 02 00 00 00         	mov	dword ptr [esi + 0x4], 0x2
 100420d: ff 15 88 a5 55 01            	call	dword ptr [0x155a588]
 1004213: 89 46 10                     	mov	dword ptr [esi + 0x10], eax
 1004216: 8b 46 34                     	mov	eax, dword ptr [esi + 0x34]
 1004219: b3 08                        	mov	bl, 0x8
 100421b: bf f7 ff ff ff               	mov	edi, 0xfffffff7
 1004220: 84 98 ec 01 00 00            	test	byte ptr [eax + 0x1ec], bl
 1004226: 74 10                        	je	0x1004238 <.text+0xf88>
 1004228: 21 b8 ec 01 00 00            	and	dword ptr [eax + 0x1ec], edi
 100422e: 8b 4e 34                     	mov	ecx, dword ptr [esi + 0x34]
 1004231: 6a 01                        	push	0x1
 1004233: e8 f8 70 09 00               	call	0x109b330 <.text+0x98080>
 1004238: 8b 46 38                     	mov	eax, dword ptr [esi + 0x38]
 100423b: 84 98 ec 01 00 00            	test	byte ptr [eax + 0x1ec], bl
 1004241: 0f 84 32 03 00 00            	je	0x1004579 <.text+0x12c9>
 1004247: 21 b8 ec 01 00 00            	and	dword ptr [eax + 0x1ec], edi
 100424d: 8b 4e 38                     	mov	ecx, dword ptr [esi + 0x38]
 1004250: 6a 01                        	push	0x1
 1004252: e8 d9 70 09 00               	call	0x109b330 <.text+0x98080>
 1004257: 5f                           	pop	edi
 1004258: 5b                           	pop	ebx
 1004259: 5e                           	pop	esi
 100425a: c3                           	ret
 100425b: 8b 3d 88 a5 55 01            	mov	edi, dword ptr [0x155a588]
 1004261: ff d7                        	call	edi
 1004263: 8b c8                        	mov	ecx, eax
 1004265: 2b 4e 10                     	sub	ecx, dword ptr [esi + 0x10]
 1004268: f3 0f 10 05 50 22 56 01      	movss	xmm0, dword ptr [0x1562250]
 1004270: 69 c9 ff 00 00 00            	imul	ecx, ecx, 0xff
 1004276: b8 d3 4d 62 10               	mov	eax, 0x10624dd3
 100427b: f7 e1                        	mul	ecx
 100427d: 8b 4e 14                     	mov	ecx, dword ptr [esi + 0x14]
 1004280: 8b da                        	mov	ebx, edx
 1004282: c1 eb 07                     	shr	ebx, 0x7
 1004285: 83 ec 08                     	sub	esp, 0x8
 1004288: f3 0f 11 44 24 04            	movss	dword ptr [esp + 0x4], xmm0
 100428e: f3 0f 11 04 24               	movss	dword ptr [esp], xmm0
 1004293: 0f 57 c0                     	xorps	xmm0, xmm0
 1004296: 0f b6 d3                     	movzx	edx, bl
 1004299: c1 e2 18                     	shl	edx, 0x18
 100429c: 81 ca ff ff ff 00            	or	edx, 0xffffff
 10042a2: 52                           	push	edx
 10042a3: 83 ec 0c                     	sub	esp, 0xc
 10042a6: f3 0f 11 44 24 08            	movss	dword ptr [esp + 0x8], xmm0
 10042ac: f3 0f 10 05                  	<unknown>
