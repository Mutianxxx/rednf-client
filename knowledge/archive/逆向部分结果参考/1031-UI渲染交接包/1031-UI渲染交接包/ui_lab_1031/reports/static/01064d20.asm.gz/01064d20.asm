
<stdin>:	file format elf32-i386

Disassembly of section .text:

01064d20 <.text>:
 1064d20: 55                           	push	ebp
 1064d21: 8b ec                        	mov	ebp, esp
 1064d23: 6a ff                        	push	-0x1
 1064d25: 68 dc 6b 4b 01               	push	0x14b6bdc
 1064d2a: 64 a1 00 00 00 00            	mov	eax, dword ptr fs:[0x0]
 1064d30: 50                           	push	eax
 1064d31: 81 ec 64 05 00 00            	sub	esp, 0x564
 1064d37: a1 90 63 a4 01               	mov	eax, dword ptr [0x1a46390]
 1064d3c: 33 c5                        	xor	eax, ebp
 1064d3e: 89 45 f0                     	mov	dword ptr [ebp - 0x10], eax
 1064d41: 53                           	push	ebx
 1064d42: 56                           	push	esi
 1064d43: 57                           	push	edi
 1064d44: 50                           	push	eax
 1064d45: 8d 45 f4                     	lea	eax, [ebp - 0xc]
 1064d48: 64 a3 00 00 00 00            	mov	dword ptr fs:[0x0], eax
 1064d4e: 8b f1                        	mov	esi, ecx
 1064d50: 33 db                        	xor	ebx, ebx
 1064d52: 89 b5 48 fe ff ff            	mov	dword ptr [ebp - 0x1b8], esi
 1064d58: 89 9d 00 fe ff ff            	mov	dword ptr [ebp - 0x200], ebx
 1064d5e: 8b 4e 28                     	mov	ecx, dword ptr [esi + 0x28]
 1064d61: 8d 46 28                     	lea	eax, [esi + 0x28]
 1064d64: 89 5d fc                     	mov	dword ptr [ebp - 0x4], ebx
 1064d67: 89 85 2c fe ff ff            	mov	dword ptr [ebp - 0x1d4], eax
 1064d6d: 89 85 f0 fd ff ff            	mov	dword ptr [ebp - 0x210], eax
 1064d73: 89 8d ec fd ff ff            	mov	dword ptr [ebp - 0x214], ecx
 1064d79: 8b 55 2c                     	mov	edx, dword ptr [ebp + 0x2c]
 1064d7c: 6a 08                        	push	0x8
 1064d7e: c6 45 fc 01                  	mov	byte ptr [ebp - 0x4], 0x1
 1064d82: 89 10                        	mov	dword ptr [eax], edx
 1064d84: 89 5d b0                     	mov	dword ptr [ebp - 0x50], ebx
 1064d87: e8 8e 1d 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064d8c: 83 c4 04                     	add	esp, 0x4
 1064d8f: 3b c3                        	cmp	eax, ebx
 1064d91: 0f 84 a3 30 00 00            	je	0x1067e3a <.text+0x311a>
 1064d97: 89 45 b0                     	mov	dword ptr [ebp - 0x50], eax
 1064d9a: 33 c9                        	xor	ecx, ecx
 1064d9c: 89 08                        	mov	dword ptr [eax], ecx
 1064d9e: 33 d2                        	xor	edx, edx
 1064da0: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064da3: 8b 4d b0                     	mov	ecx, dword ptr [ebp - 0x50]
 1064da6: 8d 45 b0                     	lea	eax, [ebp - 0x50]
 1064da9: 89 01                        	mov	dword ptr [ecx], eax
 1064dab: bf 07 00 00 00               	mov	edi, 0x7
 1064db0: 89 7d c8                     	mov	dword ptr [ebp - 0x38], edi
 1064db3: 89 5d c4                     	mov	dword ptr [ebp - 0x3c], ebx
 1064db6: 66 89 55 b4                  	mov	word ptr [ebp - 0x4c], dx
 1064dba: 6a 08                        	push	0x8
 1064dbc: c6 45 fc 02                  	mov	byte ptr [ebp - 0x4], 0x2
 1064dc0: 89 5d 90                     	mov	dword ptr [ebp - 0x70], ebx
 1064dc3: e8 52 1d 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064dc8: 83 c4 04                     	add	esp, 0x4
 1064dcb: 3b c3                        	cmp	eax, ebx
 1064dcd: 0f 84 34 30 00 00            	je	0x1067e07 <.text+0x30e7>
 1064dd3: 89 45 90                     	mov	dword ptr [ebp - 0x70], eax
 1064dd6: 33 c9                        	xor	ecx, ecx
 1064dd8: 89 08                        	mov	dword ptr [eax], ecx
 1064dda: 33 d2                        	xor	edx, edx
 1064ddc: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064ddf: 8b 4d 90                     	mov	ecx, dword ptr [ebp - 0x70]
 1064de2: 8d 45 90                     	lea	eax, [ebp - 0x70]
 1064de5: 89 01                        	mov	dword ptr [ecx], eax
 1064de7: 89 7d a8                     	mov	dword ptr [ebp - 0x58], edi
 1064dea: 89 5d a4                     	mov	dword ptr [ebp - 0x5c], ebx
 1064ded: 66 89 55 94                  	mov	word ptr [ebp - 0x6c], dx
 1064df1: 6a 08                        	push	0x8
 1064df3: c6 45 fc 03                  	mov	byte ptr [ebp - 0x4], 0x3
 1064df7: 89 9d 70 ff ff ff            	mov	dword ptr [ebp - 0x90], ebx
 1064dfd: e8 18 1d 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064e02: 83 c4 04                     	add	esp, 0x4
 1064e05: 3b c3                        	cmp	eax, ebx
 1064e07: 0f 84 c7 2f 00 00            	je	0x1067dd4 <.text+0x30b4>
 1064e0d: 89 85 70 ff ff ff            	mov	dword ptr [ebp - 0x90], eax
 1064e13: 33 c9                        	xor	ecx, ecx
 1064e15: 89 08                        	mov	dword ptr [eax], ecx
 1064e17: 33 d2                        	xor	edx, edx
 1064e19: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064e1c: 8b 8d 70 ff ff ff            	mov	ecx, dword ptr [ebp - 0x90]
 1064e22: 8d 85 70 ff ff ff            	lea	eax, [ebp - 0x90]
 1064e28: 89 01                        	mov	dword ptr [ecx], eax
 1064e2a: 89 7d 88                     	mov	dword ptr [ebp - 0x78], edi
 1064e2d: 89 5d 84                     	mov	dword ptr [ebp - 0x7c], ebx
 1064e30: 66 89 95 74 ff ff ff         	mov	word ptr [ebp - 0x8c], dx
 1064e37: 6a 08                        	push	0x8
 1064e39: c6 45 fc 04                  	mov	byte ptr [ebp - 0x4], 0x4
 1064e3d: 89 9d 14 fe ff ff            	mov	dword ptr [ebp - 0x1ec], ebx
 1064e43: e8 d2 1c 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064e48: 83 c4 04                     	add	esp, 0x4
 1064e4b: 3b c3                        	cmp	eax, ebx
 1064e4d: 0f 84 4e 2f 00 00            	je	0x1067da1 <.text+0x3081>
 1064e53: 89 85 14 fe ff ff            	mov	dword ptr [ebp - 0x1ec], eax
 1064e59: 33 c9                        	xor	ecx, ecx
 1064e5b: 89 08                        	mov	dword ptr [eax], ecx
 1064e5d: 33 d2                        	xor	edx, edx
 1064e5f: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064e62: 8b 8d 14 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1ec]
 1064e68: 8d 85 14 fe ff ff            	lea	eax, [ebp - 0x1ec]
 1064e6e: 89 01                        	mov	dword ptr [ecx], eax
 1064e70: 89 9d 18 fe ff ff            	mov	dword ptr [ebp - 0x1e8], ebx
 1064e76: 89 9d 1c fe ff ff            	mov	dword ptr [ebp - 0x1e4], ebx
 1064e7c: 89 9d 20 fe ff ff            	mov	dword ptr [ebp - 0x1e0], ebx
 1064e82: 6a 08                        	push	0x8
 1064e84: c6 45 fc 05                  	mov	byte ptr [ebp - 0x4], 0x5
 1064e88: 89 9d c4 fd ff ff            	mov	dword ptr [ebp - 0x23c], ebx
 1064e8e: e8 87 1c 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064e93: 83 c4 04                     	add	esp, 0x4
 1064e96: 3b c3                        	cmp	eax, ebx
 1064e98: 0f 84 d0 2e 00 00            	je	0x1067d6e <.text+0x304e>
 1064e9e: 89 85 c4 fd ff ff            	mov	dword ptr [ebp - 0x23c], eax
 1064ea4: 33 d2                        	xor	edx, edx
 1064ea6: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064ea9: 33 c9                        	xor	ecx, ecx
 1064eab: 89 08                        	mov	dword ptr [eax], ecx
 1064ead: 8b 85 c4 fd ff ff            	mov	eax, dword ptr [ebp - 0x23c]
 1064eb3: 8d 95 c4 fd ff ff            	lea	edx, [ebp - 0x23c]
 1064eb9: 89 10                        	mov	dword ptr [eax], edx
 1064ebb: 89 9d c8 fd ff ff            	mov	dword ptr [ebp - 0x238], ebx
 1064ec1: 89 9d cc fd ff ff            	mov	dword ptr [ebp - 0x234], ebx
 1064ec7: 89 9d d0 fd ff ff            	mov	dword ptr [ebp - 0x230], ebx
 1064ecd: 8d 55 08                     	lea	edx, [ebp + 0x8]
 1064ed0: 8d 8e 98 00 00 00            	lea	ecx, [esi + 0x98]
 1064ed6: 52                           	push	edx
 1064ed7: c6 45 fc 06                  	mov	byte ptr [ebp - 0x4], 0x6
 1064edb: e8 60 b8 3f ff               	call	0x460740
 1064ee0: 38 5d 28                     	cmp	byte ptr [ebp + 0x28], bl
 1064ee3: 75 0f                        	jne	0x1064ef4 <.text+0x1d4>
 1064ee5: 8b 8e 8c 00 00 00            	mov	ecx, dword ptr [esi + 0x8c]
 1064eeb: 3b cb                        	cmp	ecx, ebx
 1064eed: 74 05                        	je	0x1064ef4 <.text+0x1d4>
 1064eef: e8 7c de ff ff               	call	0x1062d70
 1064ef4: 8d 45 b0                     	lea	eax, [ebp - 0x50]
 1064ef7: 6a 01                        	push	0x1
 1064ef9: 50                           	push	eax
 1064efa: e8 11 03 1c 00               	call	0x1225210 <.text+0x1c04f0>
 1064eff: 83 c4 08                     	add	esp, 0x8
 1064f02: 84 c0                        	test	al, al
 1064f04: 0f 84 31 20 00 00            	je	0x1066f3b <.text+0x221b>
 1064f0a: eb 09                        	jmp	0x1064f15 <.text+0x1f5>
 1064f0c: 8d 64 24 00                  	lea	esp, [esp]
 1064f10: bf 07 00 00 00               	mov	edi, 0x7
 1064f15: 6a 08                        	push	0x8
 1064f17: 89 9d 50 ff ff ff            	mov	dword ptr [ebp - 0xb0], ebx
 1064f1d: e8 f8 1b 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064f22: 83 c4 04                     	add	esp, 0x4
 1064f25: 3b c3                        	cmp	eax, ebx
 1064f27: 0f 84 0e 2e 00 00            	je	0x1067d3b <.text+0x301b>
 1064f2d: 89 85 50 ff ff ff            	mov	dword ptr [ebp - 0xb0], eax
 1064f33: 33 c9                        	xor	ecx, ecx
 1064f35: 89 08                        	mov	dword ptr [eax], ecx
 1064f37: 33 d2                        	xor	edx, edx
 1064f39: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064f3c: 8b 95 50 ff ff ff            	mov	edx, dword ptr [ebp - 0xb0]
 1064f42: 8d 8d 50 ff ff ff            	lea	ecx, [ebp - 0xb0]
 1064f48: 89 0a                        	mov	dword ptr [edx], ecx
 1064f4a: 33 c0                        	xor	eax, eax
 1064f4c: 89 bd 68 ff ff ff            	mov	dword ptr [ebp - 0x98], edi
 1064f52: 89 9d 64 ff ff ff            	mov	dword ptr [ebp - 0x9c], ebx
 1064f58: 66 89 85 54 ff ff ff         	mov	word ptr [ebp - 0xac], ax
 1064f5f: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 1064f63: f6 05 e4 82 af 01 01         	test	byte ptr [0x1af82e4], 0x1
 1064f6a: 0f 85 94 00 00 00            	jne	0x1065004 <.text+0x2e4>
 1064f70: 83 0d e4 82 af 01 01         	or	dword ptr [0x1af82e4], 0x1
 1064f77: 6a 08                        	push	0x8
 1064f79: c6 45 fc 08                  	mov	byte ptr [ebp - 0x4], 0x8
 1064f7d: 89 1d d0 82 af 01            	mov	dword ptr [0x1af82d0], ebx
 1064f83: e8 92 1b 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064f88: 83 c4 04                     	add	esp, 0x4
 1064f8b: 3b c3                        	cmp	eax, ebx
 1064f8d: 0f 84 58 29 00 00            	je	0x10678eb <.text+0x2bcb>
 1064f93: a3 d0 82 af 01               	mov	dword ptr [0x1af82d0], eax
 1064f98: 33 c9                        	xor	ecx, ecx
 1064f9a: 33 d2                        	xor	edx, edx
 1064f9c: 89 08                        	mov	dword ptr [eax], ecx
 1064f9e: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1064fa1: 8b 0d d0 82 af 01            	mov	ecx, dword ptr [0x1af82d0]
 1064fa7: c7 01 d0 82 af 01            	mov	dword ptr [ecx], 0x1af82d0
 1064fad: 6a 18                        	push	0x18
 1064faf: c6 45 fc 09                  	mov	byte ptr [ebp - 0x4], 0x9
 1064fb3: 89 1d dc 82 af 01            	mov	dword ptr [0x1af82dc], ebx
 1064fb9: e8 5c 1b 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1064fbe: 83 c4 04                     	add	esp, 0x4
 1064fc1: 3b c3                        	cmp	eax, ebx
 1064fc3: 0f 84 ef 28 00 00            	je	0x10678b8 <.text+0x2b98>
 1064fc9: a3 d8 82 af 01               	mov	dword ptr [0x1af82d8], eax
 1064fce: 89 00                        	mov	dword ptr [eax], eax
 1064fd0: a1 d8 82 af 01               	mov	eax, dword ptr [0x1af82d8]
 1064fd5: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
 1064fd8: a1 d8 82 af 01               	mov	eax, dword ptr [0x1af82d8]
 1064fdd: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
 1064fe0: 8b 15 d8 82 af 01            	mov	edx, dword ptr [0x1af82d8]
 1064fe6: c6 42 14 01                  	mov	byte ptr [edx + 0x14], 0x1
 1064fea: a1 d8 82 af 01               	mov	eax, dword ptr [0x1af82d8]
 1064fef: 68 e0 01 55 01               	push	0x15501e0
 1064ff4: c6 40 15 01                  	mov	byte ptr [eax + 0x15], 0x1
 1064ff8: e8 0d 23 37 00               	call	0x13d730a <.text+0x3725ea>
 1064ffd: 83 c4 04                     	add	esp, 0x4
 1065000: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 1065004: f6 05 e4 82 af 01 02         	test	byte ptr [0x1af82e4], 0x2
 106500b: 75 26                        	jne	0x1065033 <.text+0x313>
 106500d: 83 0d e4 82 af 01 02         	or	dword ptr [0x1af82e4], 0x2
 1065014: b9 cc 82 af 01               	mov	ecx, 0x1af82cc
 1065019: c6 45 fc 0a                  	mov	byte ptr [ebp - 0x4], 0xa
 106501d: e8 2e 01 14 00               	call	0x11a5150 <.text+0x140430>
 1065022: 68 f0 00 55 01               	push	0x15500f0
 1065027: e8 de 22 37 00               	call	0x13d730a <.text+0x3725ea>
 106502c: 83 c4 04                     	add	esp, 0x4
 106502f: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 1065033: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 106503a: 0f 84 bb 01 00 00            	je	0x10651fb <.text+0x4db>
 1065040: 83 7d c8 08                  	cmp	dword ptr [ebp - 0x38], 0x8
 1065044: 72 0b                        	jb	0x1065051 <.text+0x331>
 1065046: 8b 4d b4                     	mov	ecx, dword ptr [ebp - 0x4c]
 1065049: 89 8d 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], ecx
 106504f: eb 09                        	jmp	0x106505a <.text+0x33a>
 1065051: 8d 55 b4                     	lea	edx, [ebp - 0x4c]
 1065054: 89 95 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], edx
 106505a: 8d 85 40 fe ff ff            	lea	eax, [ebp - 0x1c0]
 1065060: 50                           	push	eax
 1065061: 8d 8d b8 fb ff ff            	lea	ecx, [ebp - 0x448]
 1065067: 51                           	push	ecx
 1065068: b9 d0 82 af 01               	mov	ecx, 0x1af82d0
 106506d: e8 9e 36 3f ff               	call	0x458710
 1065072: 8b 08                        	mov	ecx, dword ptr [eax]
 1065074: 33 f6                        	xor	esi, esi
 1065076: 3b cb                        	cmp	ecx, ebx
 1065078: 74 08                        	je	0x1065082 <.text+0x362>
 106507a: 8b 09                        	mov	ecx, dword ptr [ecx]
 106507c: 3b cb                        	cmp	ecx, ebx
 106507e: 74 02                        	je	0x1065082 <.text+0x362>
 1065080: 8b 31                        	mov	esi, dword ptr [ecx]
 1065082: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
 1065085: 8d 95 70 fb ff ff            	lea	edx, [ebp - 0x490]
 106508b: 52                           	push	edx
 106508c: b9 d0 82 af 01               	mov	ecx, 0x1af82d0
 1065091: e8 aa f2 75 ff               	call	0x7c4340
 1065096: 3b f3                        	cmp	esi, ebx
 1065098: 0f 84 6b 1f 00 00            	je	0x1067009 <.text+0x22e9>
 106509e: 8b 36                        	mov	esi, dword ptr [esi]
 10650a0: 3b f3                        	cmp	esi, ebx
 10650a2: 0f 84 61 1f 00 00            	je	0x1067009 <.text+0x22e9>
 10650a8: 8b 08                        	mov	ecx, dword ptr [eax]
 10650aa: 3b cb                        	cmp	ecx, ebx
 10650ac: 75 04                        	jne	0x10650b2 <.text+0x392>
 10650ae: 33 c9                        	xor	ecx, ecx
 10650b0: eb 02                        	jmp	0x10650b4 <.text+0x394>
 10650b2: 8b 09                        	mov	ecx, dword ptr [ecx]
 10650b4: 3b f1                        	cmp	esi, ecx
 10650b6: 0f 85 4d 1f 00 00            	jne	0x1067009 <.text+0x22e9>
 10650bc: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
 10650bf: 0f 94 c0                     	sete	al
 10650c2: 84 c0                        	test	al, al
 10650c4: 0f 94 c0                     	sete	al
 10650c7: 84 c0                        	test	al, al
 10650c9: 0f 84 8d 18 00 00            	je	0x106695c <.text+0x1c3c>
 10650cf: 8b 47 10                     	mov	eax, dword ptr [edi + 0x10]
 10650d2: 3d ea 01 00 00               	cmp	eax, 0x1ea
 10650d7: 0f 8f 28 1b 00 00            	jg	0x1066c05 <.text+0x1ee5>
 10650dd: 74 51                        	je	0x1065130 <.text+0x410>
 10650df: 3b c3                        	cmp	eax, ebx
 10650e1: 74 0b                        	je	0x10650ee <.text+0x3ce>
 10650e3: 3d bf 00 00 00               	cmp	eax, 0xbf
 10650e8: 0f 85 6e 18 00 00            	jne	0x106695c <.text+0x1c3c>
 10650ee: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 10650f5: 0f 85 26 01 00 00            	jne	0x1065221 <.text+0x501>
 10650fb: 68 80 e2 82 01               	push	0x182e280
 1065100: e8 eb ad 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065105: 83 c4 04                     	add	esp, 0x4
 1065108: 89 85 00 fd ff ff            	mov	dword ptr [ebp - 0x300], eax
 106510e: 8d 85 00 fd ff ff            	lea	eax, [ebp - 0x300]
 1065114: 50                           	push	eax
 1065115: 8d 8d 00 fb ff ff            	lea	ecx, [ebp - 0x500]
 106511b: 51                           	push	ecx
 106511c: b9 d0 82 af 01               	mov	ecx, 0x1af82d0
 1065121: c7 85 04 fd ff ff bf 00 00 00	mov	dword ptr [ebp - 0x2fc], 0xbf
 106512b: e8 a0 3a 3f ff               	call	0x458bd0
 1065130: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 1065137: 0f 85 2e 1a 00 00            	jne	0x1066b6b <.text+0x1e4b>
 106513d: 68 64 e2 82 01               	push	0x182e264
 1065142: e8 a9 ad 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065147: 83 c4 04                     	add	esp, 0x4
 106514a: 8d 95 e0 fc ff ff            	lea	edx, [ebp - 0x320]
 1065150: 89 85 e0 fc ff ff            	mov	dword ptr [ebp - 0x320], eax
 1065156: 52                           	push	edx
 1065157: 8d 85 10 fb ff ff            	lea	eax, [ebp - 0x4f0]
 106515d: 50                           	push	eax
 106515e: b9 d0 82 af 01               	mov	ecx, 0x1af82d0
 1065163: c7 85 e4 fc ff ff ea 01 00 00	mov	dword ptr [ebp - 0x31c], 0x1ea
 106516d: e8 5e 3a 3f ff               	call	0x458bd0
 1065172: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 1065179: 0f 85 56 1d 00 00            	jne	0x1066ed5 <.text+0x21b5>
 106517f: 68 9c 29 81 01               	push	0x181299c
 1065184: e8 67 ad 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065189: 83 c4 04                     	add	esp, 0x4
 106518c: 8d 8d 10 fd ff ff            	lea	ecx, [ebp - 0x2f0]
 1065192: 51                           	push	ecx
 1065193: 8d 95 f0 fa ff ff            	lea	edx, [ebp - 0x510]
 1065199: 52                           	push	edx
 106519a: b9 d0 82 af 01               	mov	ecx, 0x1af82d0
 106519f: 89 85 10 fd ff ff            	mov	dword ptr [ebp - 0x2f0], eax
 10651a5: c7 85 14 fd ff ff fa 01 00 00	mov	dword ptr [ebp - 0x2ec], 0x1fa
 10651af: e8 1c 3a 3f ff               	call	0x458bd0
 10651b4: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 10651bb: 0f 85 5d 1a 00 00            	jne	0x1066c1e <.text+0x1efe>
 10651c1: 68 44 e2 82 01               	push	0x182e244
 10651c6: e8 25 ad 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10651cb: 83 c4 04                     	add	esp, 0x4
 10651ce: 89 85 f0 fc ff ff            	mov	dword ptr [ebp - 0x310], eax
 10651d4: 8d 85 f0 fc ff ff            	lea	eax, [ebp - 0x310]
 10651da: 50                           	push	eax
 10651db: 8d 8d d0 fa ff ff            	lea	ecx, [ebp - 0x530]
 10651e1: 51                           	push	ecx
 10651e2: b9 d0 82 af 01               	mov	ecx, 0x1af82d0
 10651e7: c7 85 f4 fc ff ff 01 02 00 00	mov	dword ptr [ebp - 0x30c], 0x201
 10651f1: e8 da 39 3f ff               	call	0x458bd0
 10651f6: e9 63 17 00 00               	jmp	0x106695e <.text+0x1c3e>
 10651fb: b9 cc 82 af 01               	mov	ecx, 0x1af82cc
 1065200: e8 bb f9 13 00               	call	0x11a4bc0 <.text+0x13fea0>
 1065205: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 106520c: 0f 84 e9 fe ff ff            	je	0x10650fb <.text+0x3db>
 1065212: b9 cc 82 af 01               	mov	ecx, 0x1af82cc
 1065217: e8 d4 f9 13 00               	call	0x11a4bf0 <.text+0x13fed0>
 106521c: e9 42 fd ff ff               	jmp	0x1064f63 <.text+0x243>
 1065221: 8d 55 90                     	lea	edx, [ebp - 0x70]
 1065224: 52                           	push	edx
 1065225: e8 26 ff 1b 00               	call	0x1225150 <.text+0x1c0430>
 106522a: 8b 45 94                     	mov	eax, dword ptr [ebp - 0x6c]
 106522d: 83 c4 04                     	add	esp, 0x4
 1065230: 83 7d a8 08                  	cmp	dword ptr [ebp - 0x58], 0x8
 1065234: 73 03                        	jae	0x1065239 <.text+0x519>
 1065236: 8d 45 94                     	lea	eax, [ebp - 0x6c]
 1065239: 50                           	push	eax
 106523a: e8 31 f9 00 00               	call	0x1074b70 <.text+0xfe50>
 106523f: 8b d8                        	mov	ebx, eax
 1065241: 83 c4 04                     	add	esp, 0x4
 1065244: 89 9d 30 fe ff ff            	mov	dword ptr [ebp - 0x1d0], ebx
 106524a: 85 db                        	test	ebx, ebx
 106524c: 0f 84 0a 17 00 00            	je	0x106695c <.text+0x1c3c>
 1065252: 8d 85 50 ff ff ff            	lea	eax, [ebp - 0xb0]
 1065258: 50                           	push	eax
 1065259: e8 f2 fe 1b 00               	call	0x1225150 <.text+0x1c0430>
 106525e: 83 c4 04                     	add	esp, 0x4
 1065261: 8d 8d 40 fe ff ff            	lea	ecx, [ebp - 0x1c0]
 1065267: 51                           	push	ecx
 1065268: 83 ec 20                     	sub	esp, 0x20
 106526b: 8b f4                        	mov	esi, esp
 106526d: 33 ff                        	xor	edi, edi
 106526f: 89 a5 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], esp
 1065275: 6a 08                        	push	0x8
 1065277: 89 bd 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], edi
 106527d: 89 b5 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], esi
 1065283: 89 3e                        	mov	dword ptr [esi], edi
 1065285: e8 90 18 37 00               	call	0x13d6b1a <.text+0x371dfa>
 106528a: 83 c4 04                     	add	esp, 0x4
 106528d: 3b c7                        	cmp	eax, edi
 106528f: 0f 84 2a 29 00 00            	je	0x1067bbf <.text+0x2e9f>
 1065295: 89 06                        	mov	dword ptr [esi], eax
 1065297: 33 d2                        	xor	edx, edx
 1065299: 33 c9                        	xor	ecx, ecx
 106529b: 89 08                        	mov	dword ptr [eax], ecx
 106529d: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10652a0: 8b 16                        	mov	edx, dword ptr [esi]
 10652a2: 89 32                        	mov	dword ptr [edx], esi
 10652a4: 6a ff                        	push	-0x1
 10652a6: 57                           	push	edi
 10652a7: 8d 8d 50 ff ff ff            	lea	ecx, [ebp - 0xb0]
 10652ad: 33 c0                        	xor	eax, eax
 10652af: 51                           	push	ecx
 10652b0: c7 46 18 07 00 00 00         	mov	dword ptr [esi + 0x18], 0x7
 10652b7: 89 7e 14                     	mov	dword ptr [esi + 0x14], edi
 10652ba: 8b ce                        	mov	ecx, esi
 10652bc: c6 45 fc 0b                  	mov	byte ptr [ebp - 0x4], 0xb
 10652c0: 66 89 46 04                  	mov	word ptr [esi + 0x4], ax
 10652c4: e8 67 00 3a ff               	call	0x405330
 10652c9: 8b b5 48 fe ff ff            	mov	esi, dword ptr [ebp - 0x1b8]
 10652cf: 8b ce                        	mov	ecx, esi
 10652d1: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 10652d5: e8 06 de ff ff               	call	0x10630e0
 10652da: 84 c0                        	test	al, al
 10652dc: 0f 84 81 00 00 00            	je	0x1065363 <.text+0x643>
 10652e2: 8b 85 40 fe ff ff            	mov	eax, dword ptr [ebp - 0x1c0]
 10652e8: 89 43 44                     	mov	dword ptr [ebx + 0x44], eax
 10652eb: 83 f8 ff                     	cmp	eax, -0x1
 10652ee: 74 15                        	je	0x1065305 <.text+0x5e5>
 10652f0: 8b 55 2c                     	mov	edx, dword ptr [ebp + 0x2c]
 10652f3: 01 53 44                     	add	dword ptr [ebx + 0x44], edx
 10652f6: 3b 86 90 00 00 00            	cmp	eax, dword ptr [esi + 0x90]
 10652fc: 7c 07                        	jl	0x1065305 <.text+0x5e5>
 10652fe: 40                           	inc	eax
 10652ff: 89 86 90 00 00 00            	mov	dword ptr [esi + 0x90], eax
 1065305: 8b 43 44                     	mov	eax, dword ptr [ebx + 0x44]
 1065308: 50                           	push	eax
 1065309: 68 08 52 56 01               	push	0x1565208
 106530e: e8 dd ab 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065313: 83 c4 04                     	add	esp, 0x4
 1065316: 50                           	push	eax
 1065317: 8d 8d 0c fe ff ff            	lea	ecx, [ebp - 0x1f4]
 106531d: 51                           	push	ecx
 106531e: e8 6d fb 13 00               	call	0x11a4e90 <.text+0x140170>
 1065323: 83 c4 0c                     	add	esp, 0xc
 1065326: 8b c8                        	mov	ecx, eax
 1065328: c6 45 fc 0c                  	mov	byte ptr [ebp - 0x4], 0xc
 106532c: e8 5f f4 13 00               	call	0x11a4790 <.text+0x13fa70>
 1065331: 8b c8                        	mov	ecx, eax
 1065333: 8d 71 02                     	lea	esi, [ecx + 0x2]
 1065336: 66 8b 11                     	mov	dx, word ptr [ecx]
 1065339: 83 c1 02                     	add	ecx, 0x2
 106533c: 66 3b d7                     	cmp	dx, di
 106533f: 75 f5                        	jne	0x1065336 <.text+0x616>
 1065341: 2b ce                        	sub	ecx, esi
 1065343: d1 f9                        	sar	ecx
 1065345: 51                           	push	ecx
 1065346: 50                           	push	eax
 1065347: 8d 8d 50 ff ff ff            	lea	ecx, [ebp - 0xb0]
 106534d: e8 de ac 3a ff               	call	0x410030
 1065352: 8d 8d 0c fe ff ff            	lea	ecx, [ebp - 0x1f4]
 1065358: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 106535c: e8 bf f5 13 00               	call	0x11a4920 <.text+0x13fc00>
 1065361: eb 0f                        	jmp	0x1065372 <.text+0x652>
 1065363: 8b 96 90 00 00 00            	mov	edx, dword ptr [esi + 0x90]
 1065369: 89 53 44                     	mov	dword ptr [ebx + 0x44], edx
 106536c: ff 86 90 00 00 00            	inc	dword ptr [esi + 0x90]
 1065372: 8b 43 44                     	mov	eax, dword ptr [ebx + 0x44]
 1065375: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 106537b: 6a 00                        	push	0x0
 106537d: 50                           	push	eax
 106537e: e8 1d df ff ff               	call	0x10632a0
 1065383: 6a 00                        	push	0x0
 1065385: e8 d6 e2 1b 00               	call	0x1223660 <.text+0x1be940>
 106538a: 6a 00                        	push	0x0
 106538c: 89 43 48                     	mov	dword ptr [ebx + 0x48], eax
 106538f: e8 cc e2 1b 00               	call	0x1223660 <.text+0x1be940>
 1065394: 6a 00                        	push	0x0
 1065396: 89 43 4c                     	mov	dword ptr [ebx + 0x4c], eax
 1065399: e8 c2 e2 1b 00               	call	0x1223660 <.text+0x1be940>
 106539e: 8b f8                        	mov	edi, eax
 10653a0: 83 c4 0c                     	add	esp, 0xc
 10653a3: 33 f6                        	xor	esi, esi
 10653a5: 85 ff                        	test	edi, edi
 10653a7: 7e 2e                        	jle	0x10653d7 <.text+0x6b7>
 10653a9: 8d a4 24 00 00 00 00         	lea	esp, [esp]
 10653b0: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
 10653b6: 51                           	push	ecx
 10653b7: e8 94 fd 1b 00               	call	0x1225150 <.text+0x1c0430>
 10653bc: 83 c4 04                     	add	esp, 0x4
 10653bf: 84 c0                        	test	al, al
 10653c1: 74 14                        	je	0x10653d7 <.text+0x6b7>
 10653c3: 8d 95 70 ff ff ff            	lea	edx, [ebp - 0x90]
 10653c9: 52                           	push	edx
 10653ca: 8d 4b 50                     	lea	ecx, [ebx + 0x50]
 10653cd: e8 6e b3 3f ff               	call	0x460740
 10653d2: 46                           	inc	esi
 10653d3: 3b f7                        	cmp	esi, edi
 10653d5: 7c d9                        	jl	0x10653b0 <.text+0x690>
 10653d7: 6a 00                        	push	0x0
 10653d9: e8 82 e2 1b 00               	call	0x1223660 <.text+0x1be940>
 10653de: 8b d8                        	mov	ebx, eax
 10653e0: 83 c4 04                     	add	esp, 0x4
 10653e3: 89 9d 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], ebx
 10653e9: c7 85 40 fe ff ff 00 00 00 00	mov	dword ptr [ebp - 0x1c0], 0x0
 10653f3: 85 db                        	test	ebx, ebx
 10653f5: 0f 8e 0e 01 00 00            	jle	0x1065509 <.text+0x7e9>
 10653fb: 8d 85 3c fe ff ff            	lea	eax, [ebp - 0x1c4]
 1065401: 50                           	push	eax
 1065402: c7 85 3c fe ff ff 00 00 00 00	mov	dword ptr [ebp - 0x1c4], 0x0
 106540c: e8 cf e2 1b 00               	call	0x12236e0 <.text+0x1be9c0>
 1065411: 83 c4 04                     	add	esp, 0x4
 1065414: 84 c0                        	test	al, al
 1065416: 0f 84 ed 00 00 00            	je	0x1065509 <.text+0x7e9>
 106541c: 8b b5 30 fe ff ff            	mov	esi, dword ptr [ebp - 0x1d0]
 1065422: 8b 46 6c                     	mov	eax, dword ptr [esi + 0x6c]
 1065425: 8d 8d 3c fe ff ff            	lea	ecx, [ebp - 0x1c4]
 106542b: 3b c8                        	cmp	ecx, eax
 106542d: 73 6b                        	jae	0x106549a <.text+0x77a>
 106542f: 8b 56 68                     	mov	edx, dword ptr [esi + 0x68]
 1065432: 3b d1                        	cmp	edx, ecx
 1065434: 77 64                        	ja	0x106549a <.text+0x77a>
 1065436: 8b f9                        	mov	edi, ecx
 1065438: 8b 4e 70                     	mov	ecx, dword ptr [esi + 0x70]
 106543b: 2b fa                        	sub	edi, edx
 106543d: c1 ff 02                     	sar	edi, 0x2
 1065440: 3b c1                        	cmp	eax, ecx
 1065442: 75 43                        	jne	0x1065487 <.text+0x767>
 1065444: 2b c2                        	sub	eax, edx
 1065446: c1 f8 02                     	sar	eax, 0x2
 1065449: 3d fe ff ff 3f               	cmp	eax, 0x3ffffffe
 106544e: 0f 87 ca 24 00 00            	ja	0x106791e <.text+0x2bfe>
 1065454: 2b ca                        	sub	ecx, edx
 1065456: 40                           	inc	eax
 1065457: c1 f9 02                     	sar	ecx, 0x2
 106545a: 3b c1                        	cmp	eax, ecx
 106545c: 76 29                        	jbe	0x1065487 <.text+0x767>
 106545e: 8b d1                        	mov	edx, ecx
 1065460: d1 ea                        	shr	edx
 1065462: bb ff ff ff 3f               	mov	ebx, 0x3fffffff
 1065467: 2b da                        	sub	ebx, edx
 1065469: 3b d9                        	cmp	ebx, ecx
 106546b: 73 04                        	jae	0x1065471 <.text+0x751>
 106546d: 33 c9                        	xor	ecx, ecx
 106546f: eb 02                        	jmp	0x1065473 <.text+0x753>
 1065471: 03 ca                        	add	ecx, edx
 1065473: 3b c8                        	cmp	ecx, eax
 1065475: 0f 42 c8                     	cmovb	ecx, eax
 1065478: 51                           	push	ecx
 1065479: 8d 4e 64                     	lea	ecx, [esi + 0x64]
 106547c: e8 4f 10 4b ff               	call	0x5164d0
 1065481: 8b 9d 44 fe ff ff            	mov	ebx, dword ptr [ebp - 0x1bc]
 1065487: 8b 46 6c                     	mov	eax, dword ptr [esi + 0x6c]
 106548a: 8b 56 68                     	mov	edx, dword ptr [esi + 0x68]
 106548d: 8d 3c ba                     	lea	edi, [edx + 4*edi]
 1065490: 85 c0                        	test	eax, eax
 1065492: 74 5c                        	je	0x10654f0 <.text+0x7d0>
 1065494: 8b 0f                        	mov	ecx, dword ptr [edi]
 1065496: 89 08                        	mov	dword ptr [eax], ecx
 1065498: eb 56                        	jmp	0x10654f0 <.text+0x7d0>
 106549a: 8b 4e 70                     	mov	ecx, dword ptr [esi + 0x70]
 106549d: 3b c1                        	cmp	eax, ecx
 106549f: 75 40                        	jne	0x10654e1 <.text+0x7c1>
 10654a1: 8b 56 68                     	mov	edx, dword ptr [esi + 0x68]
 10654a4: 2b c2                        	sub	eax, edx
 10654a6: c1 f8 02                     	sar	eax, 0x2
 10654a9: 3d fe ff ff 3f               	cmp	eax, 0x3ffffffe
 10654ae: 0f 87 6a 24 00 00            	ja	0x106791e <.text+0x2bfe>
 10654b4: 2b ca                        	sub	ecx, edx
 10654b6: 40                           	inc	eax
 10654b7: c1 f9 02                     	sar	ecx, 0x2
 10654ba: 3b c1                        	cmp	eax, ecx
 10654bc: 76 23                        	jbe	0x10654e1 <.text+0x7c1>
 10654be: 8b d1                        	mov	edx, ecx
 10654c0: d1 ea                        	shr	edx
 10654c2: bf ff ff ff 3f               	mov	edi, 0x3fffffff
 10654c7: 2b fa                        	sub	edi, edx
 10654c9: 3b f9                        	cmp	edi, ecx
 10654cb: 73 04                        	jae	0x10654d1 <.text+0x7b1>
 10654cd: 33 c9                        	xor	ecx, ecx
 10654cf: eb 02                        	jmp	0x10654d3 <.text+0x7b3>
 10654d1: 03 ca                        	add	ecx, edx
 10654d3: 3b c8                        	cmp	ecx, eax
 10654d5: 0f 42 c8                     	cmovb	ecx, eax
 10654d8: 51                           	push	ecx
 10654d9: 8d 4e 64                     	lea	ecx, [esi + 0x64]
 10654dc: e8 ef 0f 4b ff               	call	0x5164d0
 10654e1: 8b 46 6c                     	mov	eax, dword ptr [esi + 0x6c]
 10654e4: 85 c0                        	test	eax, eax
 10654e6: 74 08                        	je	0x10654f0 <.text+0x7d0>
 10654e8: 8b 95 3c fe ff ff            	mov	edx, dword ptr [ebp - 0x1c4]
 10654ee: 89 10                        	mov	dword ptr [eax], edx
 10654f0: 8b 85 40 fe ff ff            	mov	eax, dword ptr [ebp - 0x1c0]
 10654f6: 83 46 6c 04                  	add	dword ptr [esi + 0x6c], 0x4
 10654fa: 40                           	inc	eax
 10654fb: 89 85 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], eax
 1065501: 3b c3                        	cmp	eax, ebx
 1065503: 0f 8c f2 fe ff ff            	jl	0x10653fb <.text+0x6db>
 1065509: 33 f6                        	xor	esi, esi
 106550b: 6a 08                        	push	0x8
 106550d: 89 b5 ec fe ff ff            	mov	dword ptr [ebp - 0x114], esi
 1065513: e8 02 16 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1065518: 83 c4 04                     	add	esp, 0x4
 106551b: 3b c6                        	cmp	eax, esi
 106551d: 0f 84 69 26 00 00            	je	0x1067b8c <.text+0x2e6c>
 1065523: 89 85 ec fe ff ff            	mov	dword ptr [ebp - 0x114], eax
 1065529: 33 c9                        	xor	ecx, ecx
 106552b: 89 08                        	mov	dword ptr [eax], ecx
 106552d: 33 d2                        	xor	edx, edx
 106552f: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1065532: 8b 8d ec fe ff ff            	mov	ecx, dword ptr [ebp - 0x114]
 1065538: 8d 85 ec fe ff ff            	lea	eax, [ebp - 0x114]
 106553e: 89 01                        	mov	dword ptr [ecx], eax
 1065540: c7 85 04 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0xfc], 0x7
 106554a: 89 b5 00 ff ff ff            	mov	dword ptr [ebp - 0x100], esi
 1065550: 66 89 95 f0 fe ff ff         	mov	word ptr [ebp - 0x110], dx
 1065557: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 106555d: 83 c8 ff                     	or	eax, -0x1
 1065560: 89 85 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], eax
 1065566: 89 85 f8 fd ff ff            	mov	dword ptr [ebp - 0x208], eax
 106556c: 89 85 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], eax
 1065572: 8b 47 24                     	mov	eax, dword ptr [edi + 0x24]
 1065575: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1065579: 89 b5 e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], esi
 106557f: 89 b5 e0 fd ff ff            	mov	dword ptr [ebp - 0x220], esi
 1065585: 89 b5 e8 fd ff ff            	mov	dword ptr [ebp - 0x218], esi
 106558b: 89 85 3c fe ff ff            	mov	dword ptr [ebp - 0x1c4], eax
 1065591: c6 85 36 fe ff ff 01         	mov	byte ptr [ebp - 0x1ca], 0x1
 1065598: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 106559b: 6a 01                        	push	0x1
 106559d: 51                           	push	ecx
 106559e: e8 6d fc 1b 00               	call	0x1225210 <.text+0x1c04f0>
 10655a3: 83 c4 08                     	add	esp, 0x8
 10655a6: 84 c0                        	test	al, al
 10655a8: 0f 84 5d 11 00 00            	je	0x106670b <.text+0x19eb>
 10655ae: 33 f6                        	xor	esi, esi
 10655b0: 8d 7e 08                     	lea	edi, [esi + 0x8]
 10655b3: f6 05 e4 82 af 01 04         	test	byte ptr [0x1af82e4], 0x4
 10655ba: 0f 85 93 00 00 00            	jne	0x1065653 <.text+0x933>
 10655c0: 83 0d e4 82 af 01 04         	or	dword ptr [0x1af82e4], 0x4
 10655c7: 57                           	push	edi
 10655c8: c6 45 fc 0e                  	mov	byte ptr [ebp - 0x4], 0xe
 10655cc: 89 35 b4 82 af 01            	mov	dword ptr [0x1af82b4], esi
 10655d2: e8 43 15 37 00               	call	0x13d6b1a <.text+0x371dfa>
 10655d7: 83 c4 04                     	add	esp, 0x4
 10655da: 3b c6                        	cmp	eax, esi
 10655dc: 0f 84 79 23 00 00            	je	0x106795b <.text+0x2c3b>
 10655e2: a3 b4 82 af 01               	mov	dword ptr [0x1af82b4], eax
 10655e7: 33 d2                        	xor	edx, edx
 10655e9: 33 c9                        	xor	ecx, ecx
 10655eb: 89 08                        	mov	dword ptr [eax], ecx
 10655ed: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10655f0: 8b 15 b4 82 af 01            	mov	edx, dword ptr [0x1af82b4]
 10655f6: c7 02 b4 82 af 01            	mov	dword ptr [edx], 0x1af82b4
 10655fc: 6a 18                        	push	0x18
 10655fe: c6 45 fc 0f                  	mov	byte ptr [ebp - 0x4], 0xf
 1065602: 89 35 c0 82 af 01            	mov	dword ptr [0x1af82c0], esi
 1065608: e8 0d 15 37 00               	call	0x13d6b1a <.text+0x371dfa>
 106560d: 83 c4 04                     	add	esp, 0x4
 1065610: 3b c6                        	cmp	eax, esi
 1065612: 0f 84 10 23 00 00            	je	0x1067928 <.text+0x2c08>
 1065618: a3 bc 82 af 01               	mov	dword ptr [0x1af82bc], eax
 106561d: 89 00                        	mov	dword ptr [eax], eax
 106561f: a1 bc 82 af 01               	mov	eax, dword ptr [0x1af82bc]
 1065624: 89 40 04                     	mov	dword ptr [eax + 0x4], eax
 1065627: a1 bc 82 af 01               	mov	eax, dword ptr [0x1af82bc]
 106562c: 89 40 08                     	mov	dword ptr [eax + 0x8], eax
 106562f: a1 bc 82 af 01               	mov	eax, dword ptr [0x1af82bc]
 1065634: c6 40 14 01                  	mov	byte ptr [eax + 0x14], 0x1
 1065638: 8b 0d bc 82 af 01            	mov	ecx, dword ptr [0x1af82bc]
 106563e: 68 70 01 55 01               	push	0x1550170
 1065643: c6 41 15 01                  	mov	byte ptr [ecx + 0x15], 0x1
 1065647: e8 be 1c 37 00               	call	0x13d730a <.text+0x3725ea>
 106564c: 83 c4 04                     	add	esp, 0x4
 106564f: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1065653: f6 05 e4 82 af 01 08         	test	byte ptr [0x1af82e4], 0x8
 106565a: 75 25                        	jne	0x1065681 <.text+0x961>
 106565c: 09 3d e4 82 af 01            	or	dword ptr [0x1af82e4], edi
 1065662: b9 b0 82 af 01               	mov	ecx, 0x1af82b0
 1065667: c6 45 fc 10                  	mov	byte ptr [ebp - 0x4], 0x10
 106566b: e8 e0 fa 13 00               	call	0x11a5150 <.text+0x140430>
 1065670: 68 e0 00 55 01               	push	0x15500e0
 1065675: e8 90 1c 37 00               	call	0x13d730a <.text+0x3725ea>
 106567a: 83 c4 04                     	add	esp, 0x4
 106567d: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1065681: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 1065688: 0f 84 16 03 00 00            	je	0x10659a4 <.text+0xc84>
 106568e: 39 7d c8                     	cmp	dword ptr [ebp - 0x38], edi
 1065691: 72 0b                        	jb	0x106569e <.text+0x97e>
 1065693: 8b 55 b4                     	mov	edx, dword ptr [ebp - 0x4c]
 1065696: 89 95 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], edx
 106569c: eb 09                        	jmp	0x10656a7 <.text+0x987>
 106569e: 8d 45 b4                     	lea	eax, [ebp - 0x4c]
 10656a1: 89 85 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], eax
 10656a7: 8d 8d 38 fe ff ff            	lea	ecx, [ebp - 0x1c8]
 10656ad: 51                           	push	ecx
 10656ae: 8d 95 7c fb ff ff            	lea	edx, [ebp - 0x484]
 10656b4: 52                           	push	edx
 10656b5: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 10656ba: e8 51 30 3f ff               	call	0x458710
 10656bf: 8b 08                        	mov	ecx, dword ptr [eax]
 10656c1: 3b ce                        	cmp	ecx, esi
 10656c3: 74 08                        	je	0x10656cd <.text+0x9ad>
 10656c5: 8b 09                        	mov	ecx, dword ptr [ecx]
 10656c7: 3b ce                        	cmp	ecx, esi
 10656c9: 74 02                        	je	0x10656cd <.text+0x9ad>
 10656cb: 8b 31                        	mov	esi, dword ptr [ecx]
 10656cd: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
 10656d0: 8d 85 94 fb ff ff            	lea	eax, [ebp - 0x46c]
 10656d6: 50                           	push	eax
 10656d7: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 10656dc: e8 5f ec 75 ff               	call	0x7c4340
 10656e1: 33 db                        	xor	ebx, ebx
 10656e3: 3b f3                        	cmp	esi, ebx
 10656e5: 0f 84 1e 19 00 00            	je	0x1067009 <.text+0x22e9>
 10656eb: 8b 36                        	mov	esi, dword ptr [esi]
 10656ed: 3b f3                        	cmp	esi, ebx
 10656ef: 0f 84 14 19 00 00            	je	0x1067009 <.text+0x22e9>
 10656f5: 8b 08                        	mov	ecx, dword ptr [eax]
 10656f7: 3b cb                        	cmp	ecx, ebx
 10656f9: 75 04                        	jne	0x10656ff <.text+0x9df>
 10656fb: 33 c9                        	xor	ecx, ecx
 10656fd: eb 02                        	jmp	0x1065701 <.text+0x9e1>
 10656ff: 8b 09                        	mov	ecx, dword ptr [ecx]
 1065701: 3b f1                        	cmp	esi, ecx
 1065703: 0f 85 00 19 00 00            	jne	0x1067009 <.text+0x22e9>
 1065709: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
 106570c: 0f 94 c0                     	sete	al
 106570f: 84 c0                        	test	al, al
 1065711: 0f 94 c0                     	sete	al
 1065714: 84 c0                        	test	al, al
 1065716: 0f 84 bd 0f 00 00            	je	0x10666d9 <.text+0x19b9>
 106571c: 8b 47 10                     	mov	eax, dword ptr [edi + 0x10]
 106571f: 3d 44 01 00 00               	cmp	eax, 0x144
 1065724: 0f 8f ad 0b 00 00            	jg	0x10662d7 <.text+0x15b7>
 106572a: 0f 84 25 01 00 00            	je	0x1065855 <.text+0xb35>
 1065730: 3d 16 01 00 00               	cmp	eax, 0x116
 1065735: 0f 8f 23 05 00 00            	jg	0x1065c5e <.text+0xf3e>
 106573b: 74 50                        	je	0x106578d <.text+0xa6d>
 106573d: 85 c0                        	test	eax, eax
 106573f: 74 0b                        	je	0x106574c <.text+0xa2c>
 1065741: 3d 13 01 00 00               	cmp	eax, 0x113
 1065746: 0f 85 8d 0f 00 00            	jne	0x10666d9 <.text+0x19b9>
 106574c: 38 1d ac 82 af 01            	cmp	byte ptr [0x1af82ac], bl
 1065752: 0f 85 72 02 00 00            	jne	0x10659ca <.text+0xcaa>
 1065758: 68 1c e2 82 01               	push	0x182e21c
 106575d: e8 8e a7 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065762: 83 c4 04                     	add	esp, 0x4
 1065765: 8d 8d 28 fd ff ff            	lea	ecx, [ebp - 0x2d8]
 106576b: 51                           	push	ecx
 106576c: 8d 95 90 fa ff ff            	lea	edx, [ebp - 0x570]
 1065772: 52                           	push	edx
 1065773: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 1065778: 89 85 28 fd ff ff            	mov	dword ptr [ebp - 0x2d8], eax
 106577e: c7 85 2c fd ff ff 13 01 00 00	mov	dword ptr [ebp - 0x2d4], 0x113
 1065788: e8 43 34 3f ff               	call	0x458bd0
 106578d: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 1065794: 0f 85 3b 02 00 00            	jne	0x10659d5 <.text+0xcb5>
 106579a: 68 00 e2 82 01               	push	0x182e200
 106579f: e8 4c a7 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10657a4: 83 c4 04                     	add	esp, 0x4
 10657a7: 89 85 18 fd ff ff            	mov	dword ptr [ebp - 0x2e8], eax
 10657ad: 8d 85 18 fd ff ff            	lea	eax, [ebp - 0x2e8]
 10657b3: 50                           	push	eax
 10657b4: 8d 8d 40 fb ff ff            	lea	ecx, [ebp - 0x4c0]
 10657ba: 51                           	push	ecx
 10657bb: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 10657c0: c7 85 1c fd ff ff 16 01 00 00	mov	dword ptr [ebp - 0x2e4], 0x116
 10657ca: e8 01 34 3f ff               	call	0x458bd0
 10657cf: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 10657d6: 0f 85 bd 06 00 00            	jne	0x1065e99 <.text+0x1179>
 10657dc: 68 dc e1 82 01               	push	0x182e1dc
 10657e1: e8 0a a7 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10657e6: 83 c4 04                     	add	esp, 0x4
 10657e9: 8d 8d 08 fd ff ff            	lea	ecx, [ebp - 0x2f8]
 10657ef: 51                           	push	ecx
 10657f0: 8d 95 e0 fa ff ff            	lea	edx, [ebp - 0x520]
 10657f6: 52                           	push	edx
 10657f7: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 10657fc: 89 85 08 fd ff ff            	mov	dword ptr [ebp - 0x2f8], eax
 1065802: c7 85 0c fd ff ff 1f 01 00 00	mov	dword ptr [ebp - 0x2f4], 0x11f
 106580c: e8 bf 33 3f ff               	call	0x458bd0
 1065811: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 1065818: 0f 85 59 04 00 00            	jne	0x1065c77 <.text+0xf57>
 106581e: 68 b8 e1 82 01               	push	0x182e1b8
 1065823: e8 c8 a6 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065828: 83 c4 04                     	add	esp, 0x4
 106582b: 89 85 f8 fc ff ff            	mov	dword ptr [ebp - 0x308], eax
 1065831: 8d 85 f8 fc ff ff            	lea	eax, [ebp - 0x308]
 1065837: 50                           	push	eax
 1065838: 8d 8d 20 fb ff ff            	lea	ecx, [ebp - 0x4e0]
 106583e: 51                           	push	ecx
 106583f: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 1065844: c7 85 fc fc ff ff 31 01 00 00	mov	dword ptr [ebp - 0x304], 0x131
 106584e: e8 7d 33 3f ff               	call	0x458bd0
 1065853: 33 db                        	xor	ebx, ebx
 1065855: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 106585c: 0f 85 57 08 00 00            	jne	0x10660b9 <.text+0x1399>
 1065862: 68 90 e1 82 01               	push	0x182e190
 1065867: e8 84 a6 13 00               	call	0x119fef0 <.text+0x13b1d0>
 106586c: 83 c4 04                     	add	esp, 0x4
 106586f: 8d 95 e8 fc ff ff            	lea	edx, [ebp - 0x318]
 1065875: 89 85 e8 fc ff ff            	mov	dword ptr [ebp - 0x318], eax
 106587b: 52                           	push	edx
 106587c: 8d 85 a0 fa ff ff            	lea	eax, [ebp - 0x560]
 1065882: 50                           	push	eax
 1065883: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 1065888: c7 85 ec fc ff ff 44 01 00 00	mov	dword ptr [ebp - 0x314], 0x144
 1065892: e8 39 33 3f ff               	call	0x458bd0
 1065897: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 106589e: 0f 85 4f 0a 00 00            	jne	0x10662f3 <.text+0x15d3>
 10658a4: 68 68 e1 82 01               	push	0x182e168
 10658a9: e8 42 a6 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10658ae: 83 c4 04                     	add	esp, 0x4
 10658b1: 8d 95 d8 fc ff ff            	lea	edx, [ebp - 0x328]
 10658b7: 89 85 d8 fc ff ff            	mov	dword ptr [ebp - 0x328], eax
 10658bd: 52                           	push	edx
 10658be: 8d 85 60 fb ff ff            	lea	eax, [ebp - 0x4a0]
 10658c4: 50                           	push	eax
 10658c5: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 10658ca: c7 85 dc fc ff ff 5d 01 00 00	mov	dword ptr [ebp - 0x324], 0x15d
 10658d4: e8 f7 32 3f ff               	call	0x458bd0
 10658d9: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 10658e0: 0f 85 aa 0b 00 00            	jne	0x1066490 <.text+0x1770>
 10658e6: 68 44 e1 82 01               	push	0x182e144
 10658eb: e8 00 a6 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10658f0: 83 c4 04                     	add	esp, 0x4
 10658f3: 8d 95 30 fd ff ff            	lea	edx, [ebp - 0x2d0]
 10658f9: 89 85 30 fd ff ff            	mov	dword ptr [ebp - 0x2d0], eax
 10658ff: 52                           	push	edx
 1065900: 8d 85 c0 fa ff ff            	lea	eax, [ebp - 0x540]
 1065906: 50                           	push	eax
 1065907: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 106590c: c7 85 34 fd ff ff 6b 01 00 00	mov	dword ptr [ebp - 0x2cc], 0x16b
 1065916: e8 b5 32 3f ff               	call	0x458bd0
 106591b: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 1065922: 0f 85 36 0c 00 00            	jne	0x106655e <.text+0x183e>
 1065928: 68 20 e1 82 01               	push	0x182e120
 106592d: e8 be a5 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065932: 83 c4 04                     	add	esp, 0x4
 1065935: 89 85 40 fd ff ff            	mov	dword ptr [ebp - 0x2c0], eax
 106593b: 8d 85 40 fd ff ff            	lea	eax, [ebp - 0x2c0]
 1065941: 50                           	push	eax
 1065942: 8d 8d 50 fb ff ff            	lea	ecx, [ebp - 0x4b0]
 1065948: 51                           	push	ecx
 1065949: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 106594e: c7 85 44 fd ff ff 74 01 00 00	mov	dword ptr [ebp - 0x2bc], 0x174
 1065958: e8 73 32 3f ff               	call	0x458bd0
 106595d: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 1065964: 0f 85 60 0d 00 00            	jne	0x10666ca <.text+0x19aa>
 106596a: 68 f8 e0 82 01               	push	0x182e0f8
 106596f: e8 7c a5 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1065974: 83 c4 04                     	add	esp, 0x4
 1065977: 89 85 20 fd ff ff            	mov	dword ptr [ebp - 0x2e0], eax
 106597d: 8d 85 20 fd ff ff            	lea	eax, [ebp - 0x2e0]
 1065983: 50                           	push	eax
 1065984: 8d 8d 30 fb ff ff            	lea	ecx, [ebp - 0x4d0]
 106598a: 51                           	push	ecx
 106598b: b9 b4 82 af 01               	mov	ecx, 0x1af82b4
 1065990: c7 85 24 fd ff ff 8c 01 00 00	mov	dword ptr [ebp - 0x2dc], 0x18c
 106599a: e8 31 32 3f ff               	call	0x458bd0
 106599f: e9 35 0d 00 00               	jmp	0x10666d9 <.text+0x19b9>
 10659a4: b9 b0 82 af 01               	mov	ecx, 0x1af82b0
 10659a9: e8 12 f2 13 00               	call	0x11a4bc0 <.text+0x13fea0>
 10659ae: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 10659b5: 0f 84 9d fd ff ff            	je	0x1065758 <.text+0xa38>
 10659bb: b9 b0 82 af 01               	mov	ecx, 0x1af82b0
 10659c0: e8 2b f2 13 00               	call	0x11a4bf0 <.text+0x13fed0>
 10659c5: e9 e9 fb ff ff               	jmp	0x10655b3 <.text+0x893>
 10659ca: 88 9d 36 fe ff ff            	mov	byte ptr [ebp - 0x1ca], bl
 10659d0: e9 04 0d 00 00               	jmp	0x10666d9 <.text+0x19b9>
 10659d5: 33 f6                        	xor	esi, esi
 10659d7: 6a 08                        	push	0x8
 10659d9: 89 b5 ac fe ff ff            	mov	dword ptr [ebp - 0x154], esi
 10659df: e8 36 11 37 00               	call	0x13d6b1a <.text+0x371dfa>
 10659e4: 83 c4 04                     	add	esp, 0x4
 10659e7: 3b c6                        	cmp	eax, esi
 10659e9: 0f 84 05 20 00 00            	je	0x10679f4 <.text+0x2cd4>
 10659ef: 89 85 ac fe ff ff            	mov	dword ptr [ebp - 0x154], eax
 10659f5: 33 c9                        	xor	ecx, ecx
 10659f7: 89 08                        	mov	dword ptr [eax], ecx
 10659f9: 33 d2                        	xor	edx, edx
 10659fb: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10659fe: 8b 85 ac fe ff ff            	mov	eax, dword ptr [ebp - 0x154]
 1065a04: 8d 95 ac fe ff ff            	lea	edx, [ebp - 0x154]
 1065a0a: 89 10                        	mov	dword ptr [eax], edx
 1065a0c: c7 85 c4 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x13c], 0x7
 1065a16: 89 b5 c0 fe ff ff            	mov	dword ptr [ebp - 0x140], esi
 1065a1c: 66 89 8d b0 fe ff ff         	mov	word ptr [ebp - 0x150], cx
 1065a23: 52                           	push	edx
 1065a24: c6 45 fc 11                  	mov	byte ptr [ebp - 0x4], 0x11
 1065a28: e8 23 f7 1b 00               	call	0x1225150 <.text+0x1c0430>
 1065a2d: 83 c4 04                     	add	esp, 0x4
 1065a30: 84 c0                        	test	al, al
 1065a32: 0f 84 d8 01 00 00            	je	0x1065c10 <.text+0xef0>
 1065a38: 39 b5 c0 fe ff ff            	cmp	dword ptr [ebp - 0x140], esi
 1065a3e: 0f 84 cc 01 00 00            	je	0x1065c10 <.text+0xef0>
 1065a44: 83 bd c4 fe ff ff 08         	cmp	dword ptr [ebp - 0x13c], 0x8
 1065a4b: 0f 82 a6 00 00 00            	jb	0x1065af7 <.text+0xdd7>
 1065a51: 8b bd b0 fe ff ff            	mov	edi, dword ptr [ebp - 0x150]
 1065a57: 85 ff                        	test	edi, edi
 1065a59: 0f 84 a3 00 00 00            	je	0x1065b02 <.text+0xde2>
 1065a5f: 8d 85 84 fd ff ff            	lea	eax, [ebp - 0x27c]
 1065a65: 50                           	push	eax
 1065a66: 83 ec 20                     	sub	esp, 0x20
 1065a69: 8b f4                        	mov	esi, esp
 1065a6b: 89 a5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esp
 1065a71: 33 db                        	xor	ebx, ebx
 1065a73: 6a 08                        	push	0x8
 1065a75: 89 b5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esi
 1065a7b: 89 1e                        	mov	dword ptr [esi], ebx
 1065a7d: e8 98 10 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1065a82: 83 c4 04                     	add	esp, 0x4
 1065a85: 3b c3                        	cmp	eax, ebx
 1065a87: 0f 84 01 1f 00 00            	je	0x106798e <.text+0x2c6e>
 1065a8d: 33 c9                        	xor	ecx, ecx
 1065a8f: 89 06                        	mov	dword ptr [esi], eax
 1065a91: 33 d2                        	xor	edx, edx
 1065a93: 89 08                        	mov	dword ptr [eax], ecx
 1065a95: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1065a98: 8b 0e                        	mov	ecx, dword ptr [esi]
 1065a9a: 89 31                        	mov	dword ptr [ecx], esi
 1065a9c: c7 46 18 07 00 00 00         	mov	dword ptr [esi + 0x18], 0x7
 1065aa3: 89 5e 14                     	mov	dword ptr [esi + 0x14], ebx
 1065aa6: 8b c7                        	mov	eax, edi
 1065aa8: 66 89 56 04                  	mov	word ptr [esi + 0x4], dx
 1065aac: c6 45 fc 12                  	mov	byte ptr [ebp - 0x4], 0x12
 1065ab0: 8d 50 02                     	lea	edx, [eax + 0x2]
 1065ab3: 66 8b 08                     	mov	cx, word ptr [eax]
 1065ab6: 83 c0 02                     	add	eax, 0x2
 1065ab9: 66 3b cb                     	cmp	cx, bx
 1065abc: 75 f5                        	jne	0x1065ab3 <.text+0xd93>
 1065abe: 2b c2                        	sub	eax, edx
 1065ac0: d1 f8                        	sar	eax
 1065ac2: 50                           	push	eax
 1065ac3: 57                           	push	edi
 1065ac4: 8b ce                        	mov	ecx, esi
 1065ac6: e8 65 a5 3a ff               	call	0x410030
 1065acb: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1065ad1: c6 45 fc 11                  	mov	byte ptr [ebp - 0x4], 0x11
 1065ad5: e8 06 d6 ff ff               	call	0x10630e0
 1065ada: 84 c0                        	test	al, al
 1065adc: 74 24                        	je	0x1065b02 <.text+0xde2>
 1065ade: 8b 85 84 fd ff ff            	mov	eax, dword ptr [ebp - 0x27c]
 1065ae4: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1065aea: 6a 01                        	push	0x1
 1065aec: 50                           	push	eax
 1065aed: e8 ae d7 ff ff               	call	0x10632a0
 1065af2: e9 0f 01 00 00               	jmp	0x1065c06 <.text+0xee6>
 1065af7: 8d bd b0 fe ff ff            	lea	edi, [ebp - 0x150]
 1065afd: e9 5d ff ff ff               	jmp	0x1065a5f <.text+0xd3f>
 1065b02: 33 db                        	xor	ebx, ebx
 1065b04: 6a 08                        	push	0x8
 1065b06: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 1065b09: e8 0c 10 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1065b0e: 83 c4 04                     	add	esp, 0x4
 1065b11: 3b c3                        	cmp	eax, ebx
 1065b13: 0f 84 a8 1e 00 00            	je	0x10679c1 <.text+0x2ca1>
 1065b19: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
 1065b1c: 33 c9                        	xor	ecx, ecx
 1065b1e: 33 d2                        	xor	edx, edx
 1065b20: 89 08                        	mov	dword ptr [eax], ecx
 1065b22: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1065b25: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 1065b28: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1065b2b: 89 0a                        	mov	dword ptr [edx], ecx
 1065b2d: 33 c0                        	xor	eax, eax
 1065b2f: 66 89 45 d4                  	mov	word ptr [ebp - 0x2c], ax
 1065b33: 8b c7                        	mov	eax, edi
 1065b35: c6 45 fc 13                  	mov	byte ptr [ebp - 0x4], 0x13
 1065b39: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1065b40: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1065b43: 8d 50 02                     	lea	edx, [eax + 0x2]
 1065b46: 66 8b 08                     	mov	cx, word ptr [eax]
 1065b49: 83 c0 02                     	add	eax, 0x2
 1065b4c: 66 3b cb                     	cmp	cx, bx
 1065b4f: 75 f5                        	jne	0x1065b46 <.text+0xe26>
 1065b51: 2b c2                        	sub	eax, edx
 1065b53: d1 f8                        	sar	eax
 1065b55: 50                           	push	eax
 1065b56: 57                           	push	edi
 1065b57: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1065b5a: e8 d1 a4 3a ff               	call	0x410030
 1065b5f: 8b b5 48 fe ff ff            	mov	esi, dword ptr [ebp - 0x1b8]
 1065b65: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1065b68: 51                           	push	ecx
 1065b69: 8d 95 3c fc ff ff            	lea	edx, [ebp - 0x3c4]
 1065b6f: 52                           	push	edx
 1065b70: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
 1065b73: c6 45 fc 14                  	mov	byte ptr [ebp - 0x4], 0x14
 1065b77: e8 d4 dd ff ff               	call	0x1063950
 1065b7c: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1065b80: c6 45 fc 11                  	mov	byte ptr [ebp - 0x4], 0x11
 1065b84: 72 0c                        	jb	0x1065b92 <.text+0xe72>
 1065b86: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 1065b89: 50                           	push	eax
 1065b8a: e8 98 ff 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065b8f: 83 c4 04                     	add	esp, 0x4
 1065b92: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 1065b95: 33 c9                        	xor	ecx, ecx
 1065b97: 52                           	push	edx
 1065b98: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1065b9f: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1065ba2: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 1065ba6: e8 7c ff 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065bab: 83 c4 04                     	add	esp, 0x4
 1065bae: 8d 85 ac fb ff ff            	lea	eax, [ebp - 0x454]
 1065bb4: 50                           	push	eax
 1065bb5: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
 1065bb8: e8 d3 9b 74 ff               	call	0x7af790
 1065bbd: 8b 8d 3c fc ff ff            	mov	ecx, dword ptr [ebp - 0x3c4]
 1065bc3: 3b cb                        	cmp	ecx, ebx
 1065bc5: 0f 84 3e 14 00 00            	je	0x1067009 <.text+0x22e9>
 1065bcb: 8b 11                        	mov	edx, dword ptr [ecx]
 1065bcd: 3b d3                        	cmp	edx, ebx
 1065bcf: 0f 84 34 14 00 00            	je	0x1067009 <.text+0x22e9>
 1065bd5: 8b 08                        	mov	ecx, dword ptr [eax]
 1065bd7: 3b cb                        	cmp	ecx, ebx
 1065bd9: 75 04                        	jne	0x1065bdf <.text+0xebf>
 1065bdb: 33 c9                        	xor	ecx, ecx
 1065bdd: eb 02                        	jmp	0x1065be1 <.text+0xec1>
 1065bdf: 8b 09                        	mov	ecx, dword ptr [ecx]
 1065be1: 3b d1                        	cmp	edx, ecx
 1065be3: 0f 85 20 14 00 00            	jne	0x1067009 <.text+0x22e9>
 1065be9: 8b 8d 44 fc ff ff            	mov	ecx, dword ptr [ebp - 0x3bc]
 1065bef: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
 1065bf2: 0f 94 c0                     	sete	al
 1065bf5: 84 c0                        	test	al, al
 1065bf7: 0f 94 c0                     	sete	al
 1065bfa: 84 c0                        	test	al, al
 1065bfc: 74 12                        	je	0x1065c10 <.text+0xef0>
 1065bfe: 8b 49 28                     	mov	ecx, dword ptr [ecx + 0x28]
 1065c01: e8 6a f6 16 00               	call	0x11d5270 <.text+0x170550>
 1065c06: 85 c0                        	test	eax, eax
 1065c08: 74 06                        	je	0x1065c10 <.text+0xef0>
 1065c0a: 89 85 3c fe ff ff            	mov	dword ptr [ebp - 0x1c4], eax
 1065c10: 83 bd c4 fe ff ff 08         	cmp	dword ptr [ebp - 0x13c], 0x8
 1065c17: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1065c1b: 72 0f                        	jb	0x1065c2c <.text+0xf0c>
 1065c1d: 8b 8d b0 fe ff ff            	mov	ecx, dword ptr [ebp - 0x150]
 1065c23: 51                           	push	ecx
 1065c24: e8 fe fe 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065c29: 83 c4 04                     	add	esp, 0x4
 1065c2c: 8b 85 ac fe ff ff            	mov	eax, dword ptr [ebp - 0x154]
 1065c32: 33 f6                        	xor	esi, esi
 1065c34: 33 d2                        	xor	edx, edx
 1065c36: 50                           	push	eax
 1065c37: c7 85 c4 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x13c], 0x7
 1065c41: 89 b5 c0 fe ff ff            	mov	dword ptr [ebp - 0x140], esi
 1065c47: 66 89 95 b0 fe ff ff         	mov	word ptr [ebp - 0x150], dx
 1065c4e: e8 d4 fe 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065c53: 89 b5 ac fe ff ff            	mov	dword ptr [ebp - 0x154], esi
 1065c59: e9 78 0a 00 00               	jmp	0x10666d6 <.text+0x19b6>
 1065c5e: 2d 1f 01 00 00               	sub	eax, 0x11f
 1065c63: 0f 84 66 fb ff ff            	je	0x10657cf <.text+0xaaf>
 1065c69: 83 e8 12                     	sub	eax, 0x12
 1065c6c: 0f 84 9f fb ff ff            	je	0x1065811 <.text+0xaf1>
 1065c72: e9 62 0a 00 00               	jmp	0x10666d9 <.text+0x19b9>
 1065c77: 33 db                        	xor	ebx, ebx
 1065c79: 6a 08                        	push	0x8
 1065c7b: 89 9d 6c fe ff ff            	mov	dword ptr [ebp - 0x194], ebx
 1065c81: e8 94 0e 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1065c86: 83 c4 04                     	add	esp, 0x4
 1065c89: 3b c3                        	cmp	eax, ebx
 1065c8b: 0f 84 96 1d 00 00            	je	0x1067a27 <.text+0x2d07>
 1065c91: 89 85 6c fe ff ff            	mov	dword ptr [ebp - 0x194], eax
 1065c97: 33 c9                        	xor	ecx, ecx
 1065c99: 89 08                        	mov	dword ptr [eax], ecx
 1065c9b: 33 d2                        	xor	edx, edx
 1065c9d: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1065ca0: 8b 85 6c fe ff ff            	mov	eax, dword ptr [ebp - 0x194]
 1065ca6: 8d 95 6c fe ff ff            	lea	edx, [ebp - 0x194]
 1065cac: 89 10                        	mov	dword ptr [eax], edx
 1065cae: c7 85 84 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x17c], 0x7
 1065cb8: 89 9d 80 fe ff ff            	mov	dword ptr [ebp - 0x180], ebx
 1065cbe: 66 89 8d 70 fe ff ff         	mov	word ptr [ebp - 0x190], cx
 1065cc5: 52                           	push	edx
 1065cc6: c6 45 fc 17                  	mov	byte ptr [ebp - 0x4], 0x17
 1065cca: e8 81 f4 1b 00               	call	0x1225150 <.text+0x1c0430>
 1065ccf: 83 c4 04                     	add	esp, 0x4
 1065cd2: 84 c0                        	test	al, al
 1065cd4: 0f 84 a0 00 00 00            	je	0x1065d7a <.text+0x105a>
 1065cda: 39 9d 80 fe ff ff            	cmp	dword ptr [ebp - 0x180], ebx
 1065ce0: 0f 84 94 00 00 00            	je	0x1065d7a <.text+0x105a>
 1065ce6: 83 bd 84 fe ff ff 08         	cmp	dword ptr [ebp - 0x17c], 0x8
 1065ced: 0f 82 d3 00 00 00            	jb	0x1065dc6 <.text+0x10a6>
 1065cf3: 8b b5 70 fe ff ff            	mov	esi, dword ptr [ebp - 0x190]
 1065cf9: 3b f3                        	cmp	esi, ebx
 1065cfb: 0f 84 d0 00 00 00            	je	0x1065dd1 <.text+0x10b1>
 1065d01: 8d 85 7c fd ff ff            	lea	eax, [ebp - 0x284]
 1065d07: 50                           	push	eax
 1065d08: 83 ec 20                     	sub	esp, 0x20
 1065d0b: 8b cc                        	mov	ecx, esp
 1065d0d: 89 a5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esp
 1065d13: 56                           	push	esi
 1065d14: e8 07 c2 3a ff               	call	0x411f20
 1065d19: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 1065d1f: 8b cf                        	mov	ecx, edi
 1065d21: e8 ba d3 ff ff               	call	0x10630e0
 1065d26: 84 c0                        	test	al, al
 1065d28: 0f 84 a9 00 00 00            	je	0x1065dd7 <.text+0x10b7>
 1065d2e: 8b 8d 7c fd ff ff            	mov	ecx, dword ptr [ebp - 0x284]
 1065d34: 6a 01                        	push	0x1
 1065d36: 51                           	push	ecx
 1065d37: 8b cf                        	mov	ecx, edi
 1065d39: e8 62 d5 ff ff               	call	0x10632a0
 1065d3e: 8b f8                        	mov	edi, eax
 1065d40: 89 bd e0 fd ff ff            	mov	dword ptr [ebp - 0x220], edi
 1065d46: 3b fb                        	cmp	edi, ebx
 1065d48: 74 30                        	je	0x1065d7a <.text+0x105a>
 1065d4a: 53                           	push	ebx
 1065d4b: e8 10 d9 1b 00               	call	0x1223660 <.text+0x1be940>
 1065d50: 8b f0                        	mov	esi, eax
 1065d52: 83 c4 04                     	add	esp, 0x4
 1065d55: 3b f3                        	cmp	esi, ebx
 1065d57: 7c 0b                        	jl	0x1065d64 <.text+0x1044>
 1065d59: 8b cf                        	mov	ecx, edi
 1065d5b: e8 f0 72 17 00               	call	0x11dd050 <.text+0x178330>
 1065d60: 3b f0                        	cmp	esi, eax
 1065d62: 7c 02                        	jl	0x1065d66 <.text+0x1046>
 1065d64: 33 f6                        	xor	esi, esi
 1065d66: 56                           	push	esi
 1065d67: 8b cf                        	mov	ecx, edi
 1065d69: e8 32 53 02 00               	call	0x108b0a0 <.text+0x26380>
 1065d6e: 89 85 3c fe ff ff            	mov	dword ptr [ebp - 0x1c4], eax
 1065d74: 89 b5 f8 fd ff ff            	mov	dword ptr [ebp - 0x208], esi
 1065d7a: 83 bd 84 fe ff ff 08         	cmp	dword ptr [ebp - 0x17c], 0x8
 1065d81: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1065d85: 72 0f                        	jb	0x1065d96 <.text+0x1076>
 1065d87: 8b 95 70 fe ff ff            	mov	edx, dword ptr [ebp - 0x190]
 1065d8d: 52                           	push	edx
 1065d8e: e8 94 fd 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065d93: 83 c4 04                     	add	esp, 0x4
 1065d96: 8b 8d 6c fe ff ff            	mov	ecx, dword ptr [ebp - 0x194]
 1065d9c: 33 c0                        	xor	eax, eax
 1065d9e: 51                           	push	ecx
 1065d9f: c7 85 84 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x17c], 0x7
 1065da9: 89 9d 80 fe ff ff            	mov	dword ptr [ebp - 0x180], ebx
 1065daf: 66 89 85 70 fe ff ff         	mov	word ptr [ebp - 0x190], ax
 1065db6: e8 6c fd 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065dbb: 89 9d 6c fe ff ff            	mov	dword ptr [ebp - 0x194], ebx
 1065dc1: e9 10 09 00 00               	jmp	0x10666d6 <.text+0x19b6>
 1065dc6: 8d b5 70 fe ff ff            	lea	esi, [ebp - 0x190]
 1065dcc: e9 30 ff ff ff               	jmp	0x1065d01 <.text+0xfe1>
 1065dd1: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 1065dd7: 56                           	push	esi
 1065dd8: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1065ddb: e8 40 c1 3a ff               	call	0x411f20
 1065de0: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 1065de3: 52                           	push	edx
 1065de4: 8d 85 c0 fc ff ff            	lea	eax, [ebp - 0x340]
 1065dea: 50                           	push	eax
 1065deb: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 1065dee: c6 45 fc 18                  	mov	byte ptr [ebp - 0x4], 0x18
 1065df2: e8 59 db ff ff               	call	0x1063950
 1065df7: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1065dfb: c6 45 fc 17                  	mov	byte ptr [ebp - 0x4], 0x17
 1065dff: 72 0c                        	jb	0x1065e0d <.text+0x10ed>
 1065e01: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
 1065e04: 51                           	push	ecx
 1065e05: e8 1d fd 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065e0a: 83 c4 04                     	add	esp, 0x4
 1065e0d: 8b 45 d0                     	mov	eax, dword ptr [ebp - 0x30]
 1065e10: 33 d2                        	xor	edx, edx
 1065e12: 50                           	push	eax
 1065e13: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1065e1a: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1065e1d: 66 89 55 d4                  	mov	word ptr [ebp - 0x2c], dx
 1065e21: e8 01 fd 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065e26: 83 c4 04                     	add	esp, 0x4
 1065e29: 8d 8d a0 fb ff ff            	lea	ecx, [ebp - 0x460]
 1065e2f: 51                           	push	ecx
 1065e30: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 1065e33: e8 58 99 74 ff               	call	0x7af790
 1065e38: 8b 8d c0 fc ff ff            	mov	ecx, dword ptr [ebp - 0x340]
 1065e3e: 3b cb                        	cmp	ecx, ebx
 1065e40: 0f 84 c3 11 00 00            	je	0x1067009 <.text+0x22e9>
 1065e46: 8b 11                        	mov	edx, dword ptr [ecx]
 1065e48: 3b d3                        	cmp	edx, ebx
 1065e4a: 0f 84 b9 11 00 00            	je	0x1067009 <.text+0x22e9>
 1065e50: 8b 08                        	mov	ecx, dword ptr [eax]
 1065e52: 3b cb                        	cmp	ecx, ebx
 1065e54: 75 04                        	jne	0x1065e5a <.text+0x113a>
 1065e56: 33 c9                        	xor	ecx, ecx
 1065e58: eb 02                        	jmp	0x1065e5c <.text+0x113c>
 1065e5a: 8b 09                        	mov	ecx, dword ptr [ecx]
 1065e5c: 3b d1                        	cmp	edx, ecx
 1065e5e: 0f 85 a5 11 00 00            	jne	0x1067009 <.text+0x22e9>
 1065e64: 8b 8d c8 fc ff ff            	mov	ecx, dword ptr [ebp - 0x338]
 1065e6a: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
 1065e6d: 0f 94 c0                     	sete	al
 1065e70: 84 c0                        	test	al, al
 1065e72: 0f 94 c0                     	sete	al
 1065e75: 84 c0                        	test	al, al
 1065e77: 74 15                        	je	0x1065e8e <.text+0x116e>
 1065e79: 8b 49 28                     	mov	ecx, dword ptr [ecx + 0x28]
 1065e7c: e8 ef f3 16 00               	call	0x11d5270 <.text+0x170550>
 1065e81: 8b f8                        	mov	edi, eax
 1065e83: 89 85 e0 fd ff ff            	mov	dword ptr [ebp - 0x220], eax
 1065e89: e9 b8 fe ff ff               	jmp	0x1065d46 <.text+0x1026>
 1065e8e: 89 9d e0 fd ff ff            	mov	dword ptr [ebp - 0x220], ebx
 1065e94: e9 e1 fe ff ff               	jmp	0x1065d7a <.text+0x105a>
 1065e99: 33 f6                        	xor	esi, esi
 1065e9b: 6a 08                        	push	0x8
 1065e9d: 89 b5 8c fe ff ff            	mov	dword ptr [ebp - 0x174], esi
 1065ea3: e8 72 0c 37 00               	call	0x13d6b1a <.text+0x371dfa>
 1065ea8: 83 c4 04                     	add	esp, 0x4
 1065eab: 3b c6                        	cmp	eax, esi
 1065ead: 0f 84 a7 1b 00 00            	je	0x1067a5a <.text+0x2d3a>
 1065eb3: 89 85 8c fe ff ff            	mov	dword ptr [ebp - 0x174], eax
 1065eb9: 33 c9                        	xor	ecx, ecx
 1065ebb: 89 08                        	mov	dword ptr [eax], ecx
 1065ebd: 33 d2                        	xor	edx, edx
 1065ebf: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1065ec2: 8b 85 8c fe ff ff            	mov	eax, dword ptr [ebp - 0x174]
 1065ec8: 8d 95 8c fe ff ff            	lea	edx, [ebp - 0x174]
 1065ece: 89 10                        	mov	dword ptr [eax], edx
 1065ed0: c7 85 a4 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x15c], 0x7
 1065eda: 89 b5 a0 fe ff ff            	mov	dword ptr [ebp - 0x160], esi
 1065ee0: 66 89 8d 90 fe ff ff         	mov	word ptr [ebp - 0x170], cx
 1065ee7: 52                           	push	edx
 1065ee8: c6 45 fc 15                  	mov	byte ptr [ebp - 0x4], 0x15
 1065eec: e8 5f f2 1b 00               	call	0x1225150 <.text+0x1c0430>
 1065ef1: 83 c4 04                     	add	esp, 0x4
 1065ef4: 84 c0                        	test	al, al
 1065ef6: 0f 84 9b 00 00 00            	je	0x1065f97 <.text+0x1277>
 1065efc: 39 b5 a0 fe ff ff            	cmp	dword ptr [ebp - 0x160], esi
 1065f02: 0f 84 8f 00 00 00            	je	0x1065f97 <.text+0x1277>
 1065f08: bf 08 00 00 00               	mov	edi, 0x8
 1065f0d: 39 bd a4 fe ff ff            	cmp	dword ptr [ebp - 0x15c], edi
 1065f13: 0f 82 cc 00 00 00            	jb	0x1065fe5 <.text+0x12c5>
 1065f19: 8b b5 90 fe ff ff            	mov	esi, dword ptr [ebp - 0x170]
 1065f1f: 85 f6                        	test	esi, esi
 1065f21: 0f 84 c9 00 00 00            	je	0x1065ff0 <.text+0x12d0>
 1065f27: 8d 85 74 fd ff ff            	lea	eax, [ebp - 0x28c]
 1065f2d: 50                           	push	eax
 1065f2e: 83 ec 20                     	sub	esp, 0x20
 1065f31: 8b cc                        	mov	ecx, esp
 1065f33: 89 a5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esp
 1065f39: 56                           	push	esi
 1065f3a: e8 e1 bf 3a ff               	call	0x411f20
 1065f3f: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1065f45: e8 96 d1 ff ff               	call	0x10630e0
 1065f4a: 84 c0                        	test	al, al
 1065f4c: 0f 84 9e 00 00 00            	je	0x1065ff0 <.text+0x12d0>
 1065f52: 8b 8d 74 fd ff ff            	mov	ecx, dword ptr [ebp - 0x28c]
 1065f58: 6a 01                        	push	0x1
 1065f5a: 51                           	push	ecx
 1065f5b: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1065f61: e8 3a d3 ff ff               	call	0x10632a0
 1065f66: 8b f8                        	mov	edi, eax
 1065f68: 89 bd e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], edi
 1065f6e: 85 ff                        	test	edi, edi
 1065f70: 74 25                        	je	0x1065f97 <.text+0x1277>
 1065f72: 6a 00                        	push	0x0
 1065f74: e8 e7 d6 1b 00               	call	0x1223660 <.text+0x1be940>
 1065f79: 83 c4 04                     	add	esp, 0x4
 1065f7c: 8b cf                        	mov	ecx, edi
 1065f7e: 8b f0                        	mov	esi, eax
 1065f80: e8 9b a8 15 00               	call	0x11c0820 <.text+0x15bb00>
 1065f85: 3b f0                        	cmp	esi, eax
 1065f87: 72 02                        	jb	0x1065f8b <.text+0x126b>
 1065f89: 33 f6                        	xor	esi, esi
 1065f8b: 89 bd 3c fe ff ff            	mov	dword ptr [ebp - 0x1c4], edi
 1065f91: 89 b5 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], esi
 1065f97: 83 bd a4 fe ff ff 08         	cmp	dword ptr [ebp - 0x15c], 0x8
 1065f9e: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1065fa2: 72 0f                        	jb	0x1065fb3 <.text+0x1293>
 1065fa4: 8b 95 90 fe ff ff            	mov	edx, dword ptr [ebp - 0x170]
 1065faa: 52                           	push	edx
 1065fab: e8 77 fb 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065fb0: 83 c4 04                     	add	esp, 0x4
 1065fb3: 8b 8d 8c fe ff ff            	mov	ecx, dword ptr [ebp - 0x174]
 1065fb9: 33 f6                        	xor	esi, esi
 1065fbb: 33 c0                        	xor	eax, eax
 1065fbd: 51                           	push	ecx
 1065fbe: c7 85 a4 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x15c], 0x7
 1065fc8: 89 b5 a0 fe ff ff            	mov	dword ptr [ebp - 0x160], esi
 1065fce: 66 89 85 90 fe ff ff         	mov	word ptr [ebp - 0x170], ax
 1065fd5: e8 4d fb 36 00               	call	0x13d5b27 <.text+0x370e07>
 1065fda: 89 b5 8c fe ff ff            	mov	dword ptr [ebp - 0x174], esi
 1065fe0: e9 f1 06 00 00               	jmp	0x10666d6 <.text+0x19b6>
 1065fe5: 8d b5 90 fe ff ff            	lea	esi, [ebp - 0x170]
 1065feb: e9 37 ff ff ff               	jmp	0x1065f27 <.text+0x1207>
 1065ff0: 56                           	push	esi
 1065ff1: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1065ff4: e8 27 bf 3a ff               	call	0x411f20
 1065ff9: 8b b5 48 fe ff ff            	mov	esi, dword ptr [ebp - 0x1b8]
 1065fff: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 1066002: 52                           	push	edx
 1066003: 8d 85 9c fc ff ff            	lea	eax, [ebp - 0x364]
 1066009: 50                           	push	eax
 106600a: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
 106600d: c6 45 fc 16                  	mov	byte ptr [ebp - 0x4], 0x16
 1066011: e8 3a d9 ff ff               	call	0x1063950
 1066016: c6 45 fc 15                  	mov	byte ptr [ebp - 0x4], 0x15
 106601a: 39 7d e8                     	cmp	dword ptr [ebp - 0x18], edi
 106601d: 72 0c                        	jb	0x106602b <.text+0x130b>
 106601f: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
 1066022: 51                           	push	ecx
 1066023: e8 ff fa 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066028: 83 c4 04                     	add	esp, 0x4
 106602b: 8b 45 d0                     	mov	eax, dword ptr [ebp - 0x30]
 106602e: 33 d2                        	xor	edx, edx
 1066030: 33 ff                        	xor	edi, edi
 1066032: 50                           	push	eax
 1066033: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 106603a: 89 7d e4                     	mov	dword ptr [ebp - 0x1c], edi
 106603d: 66 89 55 d4                  	mov	word ptr [ebp - 0x2c], dx
 1066041: e8 e1 fa 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066046: 83 c4 04                     	add	esp, 0x4
 1066049: 8d 8d 88 fb ff ff            	lea	ecx, [ebp - 0x478]
 106604f: 51                           	push	ecx
 1066050: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
 1066053: e8 38 97 74 ff               	call	0x7af790
 1066058: 8b 8d 9c fc ff ff            	mov	ecx, dword ptr [ebp - 0x364]
 106605e: 3b cf                        	cmp	ecx, edi
 1066060: 0f 84 a3 0f 00 00            	je	0x1067009 <.text+0x22e9>
 1066066: 8b 11                        	mov	edx, dword ptr [ecx]
 1066068: 3b d7                        	cmp	edx, edi
 106606a: 0f 84 99 0f 00 00            	je	0x1067009 <.text+0x22e9>
 1066070: 8b 08                        	mov	ecx, dword ptr [eax]
 1066072: 3b cf                        	cmp	ecx, edi
 1066074: 75 04                        	jne	0x106607a <.text+0x135a>
 1066076: 33 c9                        	xor	ecx, ecx
 1066078: eb 02                        	jmp	0x106607c <.text+0x135c>
 106607a: 8b 09                        	mov	ecx, dword ptr [ecx]
 106607c: 3b d1                        	cmp	edx, ecx
 106607e: 0f 85 85 0f 00 00            	jne	0x1067009 <.text+0x22e9>
 1066084: 8b 8d a4 fc ff ff            	mov	ecx, dword ptr [ebp - 0x35c]
 106608a: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
 106608d: 0f 94 c0                     	sete	al
 1066090: 84 c0                        	test	al, al
 1066092: 0f 94 c0                     	sete	al
 1066095: 84 c0                        	test	al, al
 1066097: 74 15                        	je	0x10660ae <.text+0x138e>
 1066099: 8b 49 28                     	mov	ecx, dword ptr [ecx + 0x28]
 106609c: e8 cf f1 16 00               	call	0x11d5270 <.text+0x170550>
 10660a1: 8b f8                        	mov	edi, eax
 10660a3: 89 85 e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], eax
 10660a9: e9 c0 fe ff ff               	jmp	0x1065f6e <.text+0x124e>
 10660ae: 89 bd e4 fd ff ff            	mov	dword ptr [ebp - 0x21c], edi
 10660b4: e9 de fe ff ff               	jmp	0x1065f97 <.text+0x1277>
 10660b9: 6a 08                        	push	0x8
 10660bb: 89 9d cc fe ff ff            	mov	dword ptr [ebp - 0x134], ebx
 10660c1: e8 54 0a 37 00               	call	0x13d6b1a <.text+0x371dfa>
 10660c6: 83 c4 04                     	add	esp, 0x4
 10660c9: 3b c3                        	cmp	eax, ebx
 10660cb: 0f 84 bc 19 00 00            	je	0x1067a8d <.text+0x2d6d>
 10660d1: 89 85 cc fe ff ff            	mov	dword ptr [ebp - 0x134], eax
 10660d7: 33 c9                        	xor	ecx, ecx
 10660d9: 89 08                        	mov	dword ptr [eax], ecx
 10660db: 33 d2                        	xor	edx, edx
 10660dd: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10660e0: 8b 95 cc fe ff ff            	mov	edx, dword ptr [ebp - 0x134]
 10660e6: 8d 8d cc fe ff ff            	lea	ecx, [ebp - 0x134]
 10660ec: 89 0a                        	mov	dword ptr [edx], ecx
 10660ee: 33 c0                        	xor	eax, eax
 10660f0: c7 85 e4 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x11c], 0x7
 10660fa: 89 9d e0 fe ff ff            	mov	dword ptr [ebp - 0x120], ebx
 1066100: 66 89 85 d0 fe ff ff         	mov	word ptr [ebp - 0x130], ax
 1066107: 51                           	push	ecx
 1066108: c6 45 fc 19                  	mov	byte ptr [ebp - 0x4], 0x19
 106610c: e8 3f f0 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066111: 83 c4 04                     	add	esp, 0x4
 1066114: 84 c0                        	test	al, al
 1066116: 0f 84 9c 00 00 00            	je	0x10661b8 <.text+0x1498>
 106611c: 39 9d e0 fe ff ff            	cmp	dword ptr [ebp - 0x120], ebx
 1066122: 0f 84 90 00 00 00            	je	0x10661b8 <.text+0x1498>
 1066128: 83 bd e4 fe ff ff 08         	cmp	dword ptr [ebp - 0x11c], 0x8
 106612f: 0f 82 cf 00 00 00            	jb	0x1066204 <.text+0x14e4>
 1066135: 8b b5 d0 fe ff ff            	mov	esi, dword ptr [ebp - 0x130]
 106613b: 3b f3                        	cmp	esi, ebx
 106613d: 0f 84 cc 00 00 00            	je	0x106620f <.text+0x14ef>
 1066143: 8d 95 6c fd ff ff            	lea	edx, [ebp - 0x294]
 1066149: 52                           	push	edx
 106614a: 83 ec 20                     	sub	esp, 0x20
 106614d: 8b cc                        	mov	ecx, esp
 106614f: 89 a5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esp
 1066155: 56                           	push	esi
 1066156: e8 c5 bd 3a ff               	call	0x411f20
 106615b: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 1066161: 8b cf                        	mov	ecx, edi
 1066163: e8 78 cf ff ff               	call	0x10630e0
 1066168: 84 c0                        	test	al, al
 106616a: 0f 84 a5 00 00 00            	je	0x1066215 <.text+0x14f5>
 1066170: 8b 85 6c fd ff ff            	mov	eax, dword ptr [ebp - 0x294]
 1066176: 6a 01                        	push	0x1
 1066178: 50                           	push	eax
 1066179: 8b cf                        	mov	ecx, edi
 106617b: e8 20 d1 ff ff               	call	0x10632a0
 1066180: 8b f8                        	mov	edi, eax
 1066182: 89 bd e8 fd ff ff            	mov	dword ptr [ebp - 0x218], edi
 1066188: 3b fb                        	cmp	edi, ebx
 106618a: 74 2c                        	je	0x10661b8 <.text+0x1498>
 106618c: 53                           	push	ebx
 106618d: e8 ce d4 1b 00               	call	0x1223660 <.text+0x1be940>
 1066192: 83 c4 04                     	add	esp, 0x4
 1066195: 8b f0                        	mov	esi, eax
 1066197: 56                           	push	esi
 1066198: 8b cf                        	mov	ecx, edi
 106619a: e8 21 ef 16 00               	call	0x11d50c0 <.text+0x1703a0>
 106619f: 85 c0                        	test	eax, eax
 10661a1: 0f 44 f3                     	cmove	esi, ebx
 10661a4: 56                           	push	esi
 10661a5: 8b cf                        	mov	ecx, edi
 10661a7: e8 14 ef 16 00               	call	0x11d50c0 <.text+0x1703a0>
 10661ac: 89 85 3c fe ff ff            	mov	dword ptr [ebp - 0x1c4], eax
 10661b2: 89 b5 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], esi
 10661b8: 83 bd e4 fe ff ff 08         	cmp	dword ptr [ebp - 0x11c], 0x8
 10661bf: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 10661c3: 72 0f                        	jb	0x10661d4 <.text+0x14b4>
 10661c5: 8b 8d d0 fe ff ff            	mov	ecx, dword ptr [ebp - 0x130]
 10661cb: 51                           	push	ecx
 10661cc: e8 56 f9 36 00               	call	0x13d5b27 <.text+0x370e07>
 10661d1: 83 c4 04                     	add	esp, 0x4
 10661d4: 8b 85 cc fe ff ff            	mov	eax, dword ptr [ebp - 0x134]
 10661da: 33 d2                        	xor	edx, edx
 10661dc: 50                           	push	eax
 10661dd: c7 85 e4 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x11c], 0x7
 10661e7: 89 9d e0 fe ff ff            	mov	dword ptr [ebp - 0x120], ebx
 10661ed: 66 89 95 d0 fe ff ff         	mov	word ptr [ebp - 0x130], dx
 10661f4: e8 2e f9 36 00               	call	0x13d5b27 <.text+0x370e07>
 10661f9: 89 9d cc fe ff ff            	mov	dword ptr [ebp - 0x134], ebx
 10661ff: e9 d2 04 00 00               	jmp	0x10666d6 <.text+0x19b6>
 1066204: 8d b5 d0 fe ff ff            	lea	esi, [ebp - 0x130]
 106620a: e9 34 ff ff ff               	jmp	0x1066143 <.text+0x1423>
 106620f: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 1066215: 56                           	push	esi
 1066216: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066219: e8 02 bd 3a ff               	call	0x411f20
 106621e: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066221: 51                           	push	ecx
 1066222: 8d 95 cc fc ff ff            	lea	edx, [ebp - 0x334]
 1066228: 52                           	push	edx
 1066229: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 106622c: c6 45 fc 1a                  	mov	byte ptr [ebp - 0x4], 0x1a
 1066230: e8 1b d7 ff ff               	call	0x1063950
 1066235: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1066239: c6 45 fc 19                  	mov	byte ptr [ebp - 0x4], 0x19
 106623d: 72 0c                        	jb	0x106624b <.text+0x152b>
 106623f: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 1066242: 50                           	push	eax
 1066243: e8 df f8 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066248: 83 c4 04                     	add	esp, 0x4
 106624b: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 106624e: 33 c9                        	xor	ecx, ecx
 1066250: 52                           	push	edx
 1066251: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1066258: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 106625b: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 106625f: e8 c3 f8 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066264: 83 c4 04                     	add	esp, 0x4
 1066267: 8d 85 c4 fb ff ff            	lea	eax, [ebp - 0x43c]
 106626d: 50                           	push	eax
 106626e: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 1066271: e8 1a 95 74 ff               	call	0x7af790
 1066276: 8b 8d cc fc ff ff            	mov	ecx, dword ptr [ebp - 0x334]
 106627c: 3b cb                        	cmp	ecx, ebx
 106627e: 0f 84 85 0d 00 00            	je	0x1067009 <.text+0x22e9>
 1066284: 8b 11                        	mov	edx, dword ptr [ecx]
 1066286: 3b d3                        	cmp	edx, ebx
 1066288: 0f 84 7b 0d 00 00            	je	0x1067009 <.text+0x22e9>
 106628e: 8b 08                        	mov	ecx, dword ptr [eax]
 1066290: 3b cb                        	cmp	ecx, ebx
 1066292: 75 04                        	jne	0x1066298 <.text+0x1578>
 1066294: 33 c9                        	xor	ecx, ecx
 1066296: eb 02                        	jmp	0x106629a <.text+0x157a>
 1066298: 8b 09                        	mov	ecx, dword ptr [ecx]
 106629a: 3b d1                        	cmp	edx, ecx
 106629c: 0f 85 67 0d 00 00            	jne	0x1067009 <.text+0x22e9>
 10662a2: 8b 8d d4 fc ff ff            	mov	ecx, dword ptr [ebp - 0x32c]
 10662a8: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
 10662ab: 0f 94 c0                     	sete	al
 10662ae: 84 c0                        	test	al, al
 10662b0: 0f 94 c0                     	sete	al
 10662b3: 84 c0                        	test	al, al
 10662b5: 74 15                        	je	0x10662cc <.text+0x15ac>
 10662b7: 8b 49 28                     	mov	ecx, dword ptr [ecx + 0x28]
 10662ba: e8 b1 ef 16 00               	call	0x11d5270 <.text+0x170550>
 10662bf: 8b f8                        	mov	edi, eax
 10662c1: 89 85 e8 fd ff ff            	mov	dword ptr [ebp - 0x218], eax
 10662c7: e9 bc fe ff ff               	jmp	0x1066188 <.text+0x1468>
 10662cc: 89 9d e8 fd ff ff            	mov	dword ptr [ebp - 0x218], ebx
 10662d2: e9 e1 fe ff ff               	jmp	0x10661b8 <.text+0x1498>
 10662d7: 05 a3 fe ff ff               	add	eax, 0xfffffea3
 10662dc: 83 f8 2f                     	cmp	eax, 0x2f
 10662df: 0f 87 f4 03 00 00            	ja	0x10666d9 <.text+0x19b9>
 10662e5: 0f b6 88 84 7e 06 01         	movzx	ecx, byte ptr [eax + 0x1067e84]
 10662ec: ff 24 8d 70 7e 06 01         	jmp	dword ptr [4*ecx + 0x1067e70]
 10662f3: 6a 08                        	push	0x8
 10662f5: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 10662f8: e8 1d 08 37 00               	call	0x13d6b1a <.text+0x371dfa>
 10662fd: 83 c4 04                     	add	esp, 0x4
 1066300: 3b c3                        	cmp	eax, ebx
 1066302: 0f 84 eb 17 00 00            	je	0x1067af3 <.text+0x2dd3>
 1066308: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
 106630b: 33 c9                        	xor	ecx, ecx
 106630d: 89 08                        	mov	dword ptr [eax], ecx
 106630f: 33 d2                        	xor	edx, edx
 1066311: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1066314: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 1066317: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 106631a: 89 0a                        	mov	dword ptr [edx], ecx
 106631c: be 07 00 00 00               	mov	esi, 0x7
 1066321: 33 c0                        	xor	eax, eax
 1066323: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
 1066326: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1066329: 66 89 45 d4                  	mov	word ptr [ebp - 0x2c], ax
 106632d: 51                           	push	ecx
 106632e: c6 45 fc 1b                  	mov	byte ptr [ebp - 0x4], 0x1b
 1066332: e8 19 ee 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066337: 83 c4 04                     	add	esp, 0x4
 106633a: 84 c0                        	test	al, al
 106633c: 0f 84 1e 01 00 00            	je	0x1066460 <.text+0x1740>
 1066342: 6a 08                        	push	0x8
 1066344: 89 9d 30 ff ff ff            	mov	dword ptr [ebp - 0xd0], ebx
 106634a: e8 cb 07 37 00               	call	0x13d6b1a <.text+0x371dfa>
 106634f: 83 c4 04                     	add	esp, 0x4
 1066352: 3b c3                        	cmp	eax, ebx
 1066354: 0f 84 66 17 00 00            	je	0x1067ac0 <.text+0x2da0>
 106635a: 89 85 30 ff ff ff            	mov	dword ptr [ebp - 0xd0], eax
 1066360: 33 c9                        	xor	ecx, ecx
 1066362: 89 08                        	mov	dword ptr [eax], ecx
 1066364: 33 d2                        	xor	edx, edx
 1066366: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1066369: 8b 85 30 ff ff ff            	mov	eax, dword ptr [ebp - 0xd0]
 106636f: 8d 95 30 ff ff ff            	lea	edx, [ebp - 0xd0]
 1066375: 89 10                        	mov	dword ptr [eax], edx
 1066377: 89 b5 48 ff ff ff            	mov	dword ptr [ebp - 0xb8], esi
 106637d: 89 9d 44 ff ff ff            	mov	dword ptr [ebp - 0xbc], ebx
 1066383: 66 89 8d 34 ff ff ff         	mov	word ptr [ebp - 0xcc], cx
 106638a: 52                           	push	edx
 106638b: c6 45 fc 1c                  	mov	byte ptr [ebp - 0x4], 0x1c
 106638f: e8 bc ed 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066394: 83 c4 04                     	add	esp, 0x4
 1066397: 84 c0                        	test	al, al
 1066399: 0f 84 85 00 00 00            	je	0x1066424 <.text+0x1704>
 106639f: 8b bd 30 fe ff ff            	mov	edi, dword ptr [ebp - 0x1d0]
 10663a5: 68 cc e0 82 01               	push	0x182e0cc
 10663aa: e8 41 9b 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10663af: 8b c8                        	mov	ecx, eax
 10663b1: 83 c4 04                     	add	esp, 0x4
 10663b4: 8d 71 02                     	lea	esi, [ecx + 0x2]
 10663b7: 66 8b 11                     	mov	dx, word ptr [ecx]
 10663ba: 83 c1 02                     	add	ecx, 0x2
 10663bd: 66 3b d3                     	cmp	dx, bx
 10663c0: 75 f5                        	jne	0x10663b7 <.text+0x1697>
 10663c2: 2b ce                        	sub	ecx, esi
 10663c4: d1 f9                        	sar	ecx
 10663c6: 51                           	push	ecx
 10663c7: 50                           	push	eax
 10663c8: 8b 85 44 ff ff ff            	mov	eax, dword ptr [ebp - 0xbc]
 10663ce: 50                           	push	eax
 10663cf: 53                           	push	ebx
 10663d0: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 10663d6: e8 55 b8 39 ff               	call	0x401c30
 10663db: 85 c0                        	test	eax, eax
 10663dd: 74 40                        	je	0x106641f <.text+0x16ff>
 10663df: 8b 8d 34 ff ff ff            	mov	ecx, dword ptr [ebp - 0xcc]
 10663e5: b8 08 00 00 00               	mov	eax, 0x8
 10663ea: 39 85 48 ff ff ff            	cmp	dword ptr [ebp - 0xb8], eax
 10663f0: 73 06                        	jae	0x10663f8 <.text+0x16d8>
 10663f2: 8d 8d 34 ff ff ff            	lea	ecx, [ebp - 0xcc]
 10663f8: 39 45 e8                     	cmp	dword ptr [ebp - 0x18], eax
 10663fb: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 10663fe: 73 03                        	jae	0x1066403 <.text+0x16e3>
 1066400: 8d 45 d4                     	lea	eax, [ebp - 0x2c]
 1066403: 51                           	push	ecx
 1066404: 50                           	push	eax
 1066405: 8b cf                        	mov	ecx, edi
 1066407: e8 e4 dd 00 00               	call	0x10741f0 <.text+0xf4d0>
 106640c: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 1066412: 51                           	push	ecx
 1066413: e8 38 ed 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066418: 83 c4 04                     	add	esp, 0x4
 106641b: 84 c0                        	test	al, al
 106641d: 75 86                        	jne	0x10663a5 <.text+0x1685>
 106641f: be 07 00 00 00               	mov	esi, 0x7
 1066424: 83 bd 48 ff ff ff 08         	cmp	dword ptr [ebp - 0xb8], 0x8
 106642b: 72 0f                        	jb	0x106643c <.text+0x171c>
 106642d: 8b 95 34 ff ff ff            	mov	edx, dword ptr [ebp - 0xcc]
 1066433: 52                           	push	edx
 1066434: e8 ee f6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066439: 83 c4 04                     	add	esp, 0x4
 106643c: 8b 8d 30 ff ff ff            	mov	ecx, dword ptr [ebp - 0xd0]
 1066442: 33 c0                        	xor	eax, eax
 1066444: 51                           	push	ecx
 1066445: 89 b5 48 ff ff ff            	mov	dword ptr [ebp - 0xb8], esi
 106644b: 89 9d 44 ff ff ff            	mov	dword ptr [ebp - 0xbc], ebx
 1066451: 66 89 85 34 ff ff ff         	mov	word ptr [ebp - 0xcc], ax
 1066458: e8 ca f6 36 00               	call	0x13d5b27 <.text+0x370e07>
 106645d: 83 c4 04                     	add	esp, 0x4
 1066460: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1066464: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1066468: 72 0c                        	jb	0x1066476 <.text+0x1756>
 106646a: 8b 55 d4                     	mov	edx, dword ptr [ebp - 0x2c]
 106646d: 52                           	push	edx
 106646e: e8 b4 f6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066473: 83 c4 04                     	add	esp, 0x4
 1066476: 8b 4d d0                     	mov	ecx, dword ptr [ebp - 0x30]
 1066479: 33 c0                        	xor	eax, eax
 106647b: 51                           	push	ecx
 106647c: 89 75 e8                     	mov	dword ptr [ebp - 0x18], esi
 106647f: 89 5d e4                     	mov	dword ptr [ebp - 0x1c], ebx
 1066482: 66 89 45 d4                  	mov	word ptr [ebp - 0x2c], ax
 1066486: e8 9c f6 36 00               	call	0x13d5b27 <.text+0x370e07>
 106648b: e9 46 02 00 00               	jmp	0x10666d6 <.text+0x19b6>
 1066490: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 1066493: bb 08 00 00 00               	mov	ebx, 0x8
 1066498: 53                           	push	ebx
 1066499: e8 7c 06 37 00               	call	0x13d6b1a <.text+0x371dfa>
 106649e: 33 f6                        	xor	esi, esi
 10664a0: 83 c4 04                     	add	esp, 0x4
 10664a3: 3b c6                        	cmp	eax, esi
 10664a5: 0f 84 7b 16 00 00            	je	0x1067b26 <.text+0x2e06>
 10664ab: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
 10664ae: 33 c9                        	xor	ecx, ecx
 10664b0: 89 08                        	mov	dword ptr [eax], ecx
 10664b2: 33 d2                        	xor	edx, edx
 10664b4: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 10664b7: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 10664ba: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 10664bd: 89 0a                        	mov	dword ptr [edx], ecx
 10664bf: bf 07 00 00 00               	mov	edi, 0x7
 10664c4: 33 c0                        	xor	eax, eax
 10664c6: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 10664c9: 89 75 e4                     	mov	dword ptr [ebp - 0x1c], esi
 10664cc: 66 89 45 d4                  	mov	word ptr [ebp - 0x2c], ax
 10664d0: 51                           	push	ecx
 10664d1: c6 45 fc 1d                  	mov	byte ptr [ebp - 0x4], 0x1d
 10664d5: e8 76 ec 1b 00               	call	0x1225150 <.text+0x1c0430>
 10664da: 83 c4 04                     	add	esp, 0x4
 10664dd: 84 c0                        	test	al, al
 10664df: 74 4e                        	je	0x106652f <.text+0x180f>
 10664e1: 8d 95 b4 fd ff ff            	lea	edx, [ebp - 0x24c]
 10664e7: 52                           	push	edx
 10664e8: e8 f3 d1 1b 00               	call	0x12236e0 <.text+0x1be9c0>
 10664ed: 83 c4 04                     	add	esp, 0x4
 10664f0: 84 c0                        	test	al, al
 10664f2: 74 3b                        	je	0x106652f <.text+0x180f>
 10664f4: 8b b5 30 fe ff ff            	mov	esi, dword ptr [ebp - 0x1d0]
 10664fa: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
 1066500: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 1066503: 39 5d e8                     	cmp	dword ptr [ebp - 0x18], ebx
 1066506: 73 03                        	jae	0x106650b <.text+0x17eb>
 1066508: 8d 45 d4                     	lea	eax, [ebp - 0x2c]
 106650b: 8b 8d b4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x24c]
 1066511: 51                           	push	ecx
 1066512: 50                           	push	eax
 1066513: 8b ce                        	mov	ecx, esi
 1066515: e8 76 d6 00 00               	call	0x1073b90 <.text+0xee70>
 106651a: 8d 95 b4 fd ff ff            	lea	edx, [ebp - 0x24c]
 1066520: 52                           	push	edx
 1066521: e8 ba d1 1b 00               	call	0x12236e0 <.text+0x1be9c0>
 1066526: 83 c4 04                     	add	esp, 0x4
 1066529: 84 c0                        	test	al, al
 106652b: 75 d3                        	jne	0x1066500 <.text+0x17e0>
 106652d: 33 f6                        	xor	esi, esi
 106652f: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1066533: 39 5d e8                     	cmp	dword ptr [ebp - 0x18], ebx
 1066536: 72 0c                        	jb	0x1066544 <.text+0x1824>
 1066538: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 106653b: 50                           	push	eax
 106653c: e8 e6 f5 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066541: 83 c4 04                     	add	esp, 0x4
 1066544: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 1066547: 33 c9                        	xor	ecx, ecx
 1066549: 52                           	push	edx
 106654a: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 106654d: 89 75 e4                     	mov	dword ptr [ebp - 0x1c], esi
 1066550: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 1066554: e8 ce f5 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066559: e9 78 01 00 00               	jmp	0x10666d6 <.text+0x19b6>
 106655e: 89 5d d0                     	mov	dword ptr [ebp - 0x30], ebx
 1066561: bb 08 00 00 00               	mov	ebx, 0x8
 1066566: 53                           	push	ebx
 1066567: e8 ae 05 37 00               	call	0x13d6b1a <.text+0x371dfa>
 106656c: 33 f6                        	xor	esi, esi
 106656e: 83 c4 04                     	add	esp, 0x4
 1066571: 3b c6                        	cmp	eax, esi
 1066573: 0f 84 e0 15 00 00            	je	0x1067b59 <.text+0x2e39>
 1066579: 89 45 d0                     	mov	dword ptr [ebp - 0x30], eax
 106657c: 33 c9                        	xor	ecx, ecx
 106657e: 89 08                        	mov	dword ptr [eax], ecx
 1066580: 33 d2                        	xor	edx, edx
 1066582: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1066585: 8b 45 d0                     	mov	eax, dword ptr [ebp - 0x30]
 1066588: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 106658b: 89 10                        	mov	dword ptr [eax], edx
 106658d: bf 07 00 00 00               	mov	edi, 0x7
 1066592: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 1066595: 89 75 e4                     	mov	dword ptr [ebp - 0x1c], esi
 1066598: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 106659c: 52                           	push	edx
 106659d: c6 45 fc 1e                  	mov	byte ptr [ebp - 0x4], 0x1e
 10665a1: e8 aa eb 1b 00               	call	0x1225150 <.text+0x1c0430>
 10665a6: 83 c4 04                     	add	esp, 0x4
 10665a9: 84 c0                        	test	al, al
 10665ab: 0f 84 ed 00 00 00            	je	0x106669e <.text+0x197e>
 10665b1: 8d 8d 28 ff ff ff            	lea	ecx, [ebp - 0xd8]
 10665b7: e8 54 cc ff ff               	call	0x1063210
 10665bc: 8b b5 30 fe ff ff            	mov	esi, dword ptr [ebp - 0x1d0]
 10665c2: c6 45 fc 1f                  	mov	byte ptr [ebp - 0x4], 0x1f
 10665c6: eb 08                        	jmp	0x10665d0 <.text+0x18b0>
 10665c8: 8d a4 24 00 00 00 00         	lea	esp, [esp]
 10665cf: 90                           	nop
 10665d0: 0f 57 c0                     	xorps	xmm0, xmm0
 10665d3: 33 c0                        	xor	eax, eax
 10665d5: 89 85 28 ff ff ff            	mov	dword ptr [ebp - 0xd8], eax
 10665db: 89 85 44 ff ff ff            	mov	dword ptr [ebp - 0xbc], eax
 10665e1: 8b 85 34 ff ff ff            	mov	eax, dword ptr [ebp - 0xcc]
 10665e7: f3 0f 11 85 2c ff ff ff      	movss	dword ptr [ebp - 0xd4], xmm0
 10665ef: 39 9d 48 ff ff ff            	cmp	dword ptr [ebp - 0xb8], ebx
 10665f5: 73 06                        	jae	0x10665fd <.text+0x18dd>
 10665f7: 8d 85 34 ff ff ff            	lea	eax, [ebp - 0xcc]
 10665fd: 33 c9                        	xor	ecx, ecx
 10665ff: 66 89 08                     	mov	word ptr [eax], cx
 1066602: 8d 95 30 ff ff ff            	lea	edx, [ebp - 0xd0]
 1066608: 52                           	push	edx
 1066609: 8d 85 2c ff ff ff            	lea	eax, [ebp - 0xd4]
 106660f: 50                           	push	eax
 1066610: 8d 8d 28 ff ff ff            	lea	ecx, [ebp - 0xd8]
 1066616: 51                           	push	ecx
 1066617: e8 44 fd 1b 00               	call	0x1226360 <.text+0x1c1640>
 106661c: 83 c4 0c                     	add	esp, 0xc
 106661f: 83 e8 02                     	sub	eax, 0x2
 1066622: 74 0a                        	je	0x106662e <.text+0x190e>
 1066624: 83 e8 02                     	sub	eax, 0x2
 1066627: 74 05                        	je	0x106662e <.text+0x190e>
 1066629: 83 e8 03                     	sub	eax, 0x3
 106662c: 75 2f                        	jne	0x106665d <.text+0x193d>
 106662e: 83 ec 28                     	sub	esp, 0x28
 1066631: 8d 95 28 ff ff ff            	lea	edx, [ebp - 0xd8]
 1066637: 8b cc                        	mov	ecx, esp
 1066639: 89 a5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esp
 106663f: 52                           	push	edx
 1066640: e8 6b d0 22 00               	call	0x12936b0 <.text+0x22e990>
 1066645: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 1066648: 39 5d e8                     	cmp	dword ptr [ebp - 0x18], ebx
 106664b: 73 03                        	jae	0x1066650 <.text+0x1930>
 106664d: 8d 45 d4                     	lea	eax, [ebp - 0x2c]
 1066650: 50                           	push	eax
 1066651: 8b ce                        	mov	ecx, esi
 1066653: e8 08 e3 00 00               	call	0x1074960 <.text+0xfc40>
 1066658: e9 73 ff ff ff               	jmp	0x10665d0 <.text+0x18b0>
 106665d: 39 9d 48 ff ff ff            	cmp	dword ptr [ebp - 0xb8], ebx
 1066663: 72 0f                        	jb	0x1066674 <.text+0x1954>
 1066665: 8b 85 34 ff ff ff            	mov	eax, dword ptr [ebp - 0xcc]
 106666b: 50                           	push	eax
 106666c: e8 b6 f4 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066671: 83 c4 04                     	add	esp, 0x4
 1066674: 8b 95 30 ff ff ff            	mov	edx, dword ptr [ebp - 0xd0]
 106667a: 33 c9                        	xor	ecx, ecx
 106667c: 52                           	push	edx
 106667d: 89 bd 48 ff ff ff            	mov	dword ptr [ebp - 0xb8], edi
 1066683: c7 85 44 ff ff ff 00 00 00 00	mov	dword ptr [ebp - 0xbc], 0x0
 106668d: 66 89 8d 34 ff ff ff         	mov	word ptr [ebp - 0xcc], cx
 1066694: e8 8e f4 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066699: 83 c4 04                     	add	esp, 0x4
 106669c: 33 f6                        	xor	esi, esi
 106669e: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 10666a2: 39 5d e8                     	cmp	dword ptr [ebp - 0x18], ebx
 10666a5: 72 0c                        	jb	0x10666b3 <.text+0x1993>
 10666a7: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 10666aa: 50                           	push	eax
 10666ab: e8 77 f4 36 00               	call	0x13d5b27 <.text+0x370e07>
 10666b0: 83 c4 04                     	add	esp, 0x4
 10666b3: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 10666b6: 33 c9                        	xor	ecx, ecx
 10666b8: 52                           	push	edx
 10666b9: 89 7d e8                     	mov	dword ptr [ebp - 0x18], edi
 10666bc: 89 75 e4                     	mov	dword ptr [ebp - 0x1c], esi
 10666bf: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 10666c3: e8 5f f4 36 00               	call	0x13d5b27 <.text+0x370e07>
 10666c8: eb 0c                        	jmp	0x10666d6 <.text+0x19b6>
 10666ca: 8d 95 ec fe ff ff            	lea	edx, [ebp - 0x114]
 10666d0: 52                           	push	edx
 10666d1: e8 7a ea 1b 00               	call	0x1225150 <.text+0x1c0430>
 10666d6: 83 c4 04                     	add	esp, 0x4
 10666d9: 80 3d ac 82 af 01 00         	cmp	byte ptr [0x1af82ac], 0x0
 10666e0: 75 16                        	jne	0x10666f8 <.text+0x19d8>
 10666e2: b9 b0 82 af 01               	mov	ecx, 0x1af82b0
 10666e7: e8 04 e5 13 00               	call	0x11a4bf0 <.text+0x13fed0>
 10666ec: c6 05 ac 82 af 01 01         	mov	byte ptr [0x1af82ac], 0x1
 10666f3: e9 b6 ee ff ff               	jmp	0x10655ae <.text+0x88e>
 10666f8: 80 bd 36 fe ff ff 00         	cmp	byte ptr [ebp - 0x1ca], 0x0
 10666ff: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 1066705: 0f 85 8d ee ff ff            	jne	0x1065598 <.text+0x878>
 106670b: 68 ac e0 82 01               	push	0x182e0ac
 1066710: e8 db 97 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1066715: 8b c8                        	mov	ecx, eax
 1066717: 83 c4 04                     	add	esp, 0x4
 106671a: 8d 71 02                     	lea	esi, [ecx + 0x2]
 106671d: 8d 49 00                     	lea	ecx, [ecx]
 1066720: 66 8b 11                     	mov	dx, word ptr [ecx]
 1066723: 83 c1 02                     	add	ecx, 0x2
 1066726: 66 85 d2                     	test	dx, dx
 1066729: 75 f5                        	jne	0x1066720 <.text+0x1a00>
 106672b: 2b ce                        	sub	ecx, esi
 106672d: d1 f9                        	sar	ecx
 106672f: 51                           	push	ecx
 1066730: 50                           	push	eax
 1066731: 8b 45 a4                     	mov	eax, dword ptr [ebp - 0x5c]
 1066734: 50                           	push	eax
 1066735: 6a 00                        	push	0x0
 1066737: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 106673a: e8 f1 b4 39 ff               	call	0x401c30
 106673f: 8b 9d 30 fe ff ff            	mov	ebx, dword ptr [ebp - 0x1d0]
 1066745: 85 c0                        	test	eax, eax
 1066747: 0f 85 ab 01 00 00            	jne	0x10668f8 <.text+0x1bd8>
 106674d: 8b 4b 58                     	mov	ecx, dword ptr [ebx + 0x58]
 1066750: 2b 4b 54                     	sub	ecx, dword ptr [ebx + 0x54]
 1066753: c1 f9 05                     	sar	ecx, 0x5
 1066756: 85 c9                        	test	ecx, ecx
 1066758: 0f 84 9a 01 00 00            	je	0x10668f8 <.text+0x1bd8>
 106675e: 8b 85 40 fe ff ff            	mov	eax, dword ptr [ebp - 0x1c0]
 1066764: c7 85 38 fe ff ff ff ff ff ff	mov	dword ptr [ebp - 0x1c8], 0xffffffff
 106676e: 83 f8 ff                     	cmp	eax, -0x1
 1066771: 74 12                        	je	0x1066785 <.text+0x1a65>
 1066773: 8b 8d 3c fe ff ff            	mov	ecx, dword ptr [ebp - 0x1c4]
 1066779: 50                           	push	eax
 106677a: e8 b1 a0 15 00               	call	0x11c0830 <.text+0x15bb10>
 106677f: 89 85 3c fe ff ff            	mov	dword ptr [ebp - 0x1c4], eax
 1066785: 8b 43 54                     	mov	eax, dword ptr [ebx + 0x54]
 1066788: 8b 4b 58                     	mov	ecx, dword ptr [ebx + 0x58]
 106678b: 2b c8                        	sub	ecx, eax
 106678d: c1 f9 05                     	sar	ecx, 0x5
 1066790: 8d 95 38 fe ff ff            	lea	edx, [ebp - 0x1c8]
 1066796: 52                           	push	edx
 1066797: 85 c9                        	test	ecx, ecx
 1066799: 0f 84 6a 08 00 00            	je	0x1067009 <.text+0x22e9>
 106679f: be 08 00 00 00               	mov	esi, 0x8
 10667a4: 39 70 18                     	cmp	dword ptr [eax + 0x18], esi
 10667a7: 72 05                        	jb	0x10667ae <.text+0x1a8e>
 10667a9: 8b 40 04                     	mov	eax, dword ptr [eax + 0x4]
 10667ac: eb 03                        	jmp	0x10667b1 <.text+0x1a91>
 10667ae: 83 c0 04                     	add	eax, 0x4
 10667b1: 83 ec 20                     	sub	esp, 0x20
 10667b4: 8b cc                        	mov	ecx, esp
 10667b6: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 10667bc: 50                           	push	eax
 10667bd: e8 5e b7 3a ff               	call	0x411f20
 10667c2: 8b cf                        	mov	ecx, edi
 10667c4: e8 17 c9 ff ff               	call	0x10630e0
 10667c9: 84 c0                        	test	al, al
 10667cb: 74 17                        	je	0x10667e4 <.text+0x1ac4>
 10667cd: 83 bd 38 fe ff ff ff         	cmp	dword ptr [ebp - 0x1c8], -0x1
 10667d4: 75 0e                        	jne	0x10667e4 <.text+0x1ac4>
 10667d6: 8b 95 3c fe ff ff            	mov	edx, dword ptr [ebp - 0x1c4]
 10667dc: 89 53 78                     	mov	dword ptr [ebx + 0x78], edx
 10667df: e9 14 01 00 00               	jmp	0x10668f8 <.text+0x1bd8>
 10667e4: 8b 43 54                     	mov	eax, dword ptr [ebx + 0x54]
 10667e7: 8b 4b 58                     	mov	ecx, dword ptr [ebx + 0x58]
 10667ea: 2b c8                        	sub	ecx, eax
 10667ec: c1 f9 05                     	sar	ecx, 0x5
 10667ef: 85 c9                        	test	ecx, ecx
 10667f1: 0f 84 12 08 00 00            	je	0x1067009 <.text+0x22e9>
 10667f7: 39 70 18                     	cmp	dword ptr [eax + 0x18], esi
 10667fa: 72 05                        	jb	0x1066801 <.text+0x1ae1>
 10667fc: 8b 70 04                     	mov	esi, dword ptr [eax + 0x4]
 10667ff: eb 03                        	jmp	0x1066804 <.text+0x1ae4>
 1066801: 8d 70 04                     	lea	esi, [eax + 0x4]
 1066804: 85 f6                        	test	esi, esi
 1066806: 74 38                        	je	0x1066840 <.text+0x1b20>
 1066808: 8d 95 d8 fd ff ff            	lea	edx, [ebp - 0x228]
 106680e: 52                           	push	edx
 106680f: 83 ec 20                     	sub	esp, 0x20
 1066812: 8b cc                        	mov	ecx, esp
 1066814: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 106681a: 56                           	push	esi
 106681b: e8 00 b7 3a ff               	call	0x411f20
 1066820: 8b cf                        	mov	ecx, edi
 1066822: e8 b9 c8 ff ff               	call	0x10630e0
 1066827: 84 c0                        	test	al, al
 1066829: 74 15                        	je	0x1066840 <.text+0x1b20>
 106682b: 8b 85 d8 fd ff ff            	mov	eax, dword ptr [ebp - 0x228]
 1066831: 6a 01                        	push	0x1
 1066833: 50                           	push	eax
 1066834: 8b cf                        	mov	ecx, edi
 1066836: e8 65 ca ff ff               	call	0x10632a0
 106683b: e9 b5 00 00 00               	jmp	0x10668f5 <.text+0x1bd5>
 1066840: 56                           	push	esi
 1066841: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066844: e8 d7 b6 3a ff               	call	0x411f20
 1066849: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 106684c: 51                           	push	ecx
 106684d: 8d 95 9c fd ff ff            	lea	edx, [ebp - 0x264]
 1066853: 52                           	push	edx
 1066854: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 1066857: c6 45 fc 20                  	mov	byte ptr [ebp - 0x4], 0x20
 106685b: e8 f0 d0 ff ff               	call	0x1063950
 1066860: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1066864: c6 45 fc 0d                  	mov	byte ptr [ebp - 0x4], 0xd
 1066868: 72 0c                        	jb	0x1066876 <.text+0x1b56>
 106686a: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 106686d: 50                           	push	eax
 106686e: e8 b4 f2 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066873: 83 c4 04                     	add	esp, 0x4
 1066876: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 1066879: 33 c9                        	xor	ecx, ecx
 106687b: 52                           	push	edx
 106687c: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1066883: c7 45 e4 00 00 00 00         	mov	dword ptr [ebp - 0x1c], 0x0
 106688a: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 106688e: e8 94 f2 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066893: 83 c4 04                     	add	esp, 0x4
 1066896: 8d 85 dc fb ff ff            	lea	eax, [ebp - 0x424]
 106689c: 50                           	push	eax
 106689d: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 10668a0: c7 45 d0 00 00 00 00         	mov	dword ptr [ebp - 0x30], 0x0
 10668a7: e8 e4 8e 74 ff               	call	0x7af790
 10668ac: 8b 8d 9c fd ff ff            	mov	ecx, dword ptr [ebp - 0x264]
 10668b2: 85 c9                        	test	ecx, ecx
 10668b4: 0f 84 4f 07 00 00            	je	0x1067009 <.text+0x22e9>
 10668ba: 8b 11                        	mov	edx, dword ptr [ecx]
 10668bc: 85 d2                        	test	edx, edx
 10668be: 0f 84 45 07 00 00            	je	0x1067009 <.text+0x22e9>
 10668c4: 8b 08                        	mov	ecx, dword ptr [eax]
 10668c6: 85 c9                        	test	ecx, ecx
 10668c8: 74 02                        	je	0x10668cc <.text+0x1bac>
 10668ca: 8b 09                        	mov	ecx, dword ptr [ecx]
 10668cc: 3b d1                        	cmp	edx, ecx
 10668ce: 0f 85 35 07 00 00            	jne	0x1067009 <.text+0x22e9>
 10668d4: 8b 8d a4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x25c]
 10668da: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
 10668dd: 0f 94 c0                     	sete	al
 10668e0: 84 c0                        	test	al, al
 10668e2: 0f 94 c0                     	sete	al
 10668e5: 84 c0                        	test	al, al
 10668e7: 74 0a                        	je	0x10668f3 <.text+0x1bd3>
 10668e9: 8b 49 28                     	mov	ecx, dword ptr [ecx + 0x28]
 10668ec: e8 7f e9 16 00               	call	0x11d5270 <.text+0x170550>
 10668f1: eb 02                        	jmp	0x10668f5 <.text+0x1bd5>
 10668f3: 33 c0                        	xor	eax, eax
 10668f5: 89 43 78                     	mov	dword ptr [ebx + 0x78], eax
 10668f8: 8b 8d 3c fe ff ff            	mov	ecx, dword ptr [ebp - 0x1c4]
 10668fe: 51                           	push	ecx
 10668ff: 8b cb                        	mov	ecx, ebx
 1066901: e8 fa 7c 00 00               	call	0x106e600 <.text+0x98e0>
 1066906: 8b cb                        	mov	ecx, ebx
 1066908: 84 c0                        	test	al, al
 106690a: 75 75                        	jne	0x1066981 <.text+0x1c61>
 106690c: 8b 13                        	mov	edx, dword ptr [ebx]
 106690e: 8b 02                        	mov	eax, dword ptr [edx]
 1066910: 6a 01                        	push	0x1
 1066912: ff d0                        	call	eax
 1066914: 83 bd 04 ff ff ff 08         	cmp	dword ptr [ebp - 0xfc], 0x8
 106691b: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 106691f: 72 0f                        	jb	0x1066930 <.text+0x1c10>
 1066921: 8b 8d f0 fe ff ff            	mov	ecx, dword ptr [ebp - 0x110]
 1066927: 51                           	push	ecx
 1066928: e8 fa f1 36 00               	call	0x13d5b27 <.text+0x370e07>
 106692d: 83 c4 04                     	add	esp, 0x4
 1066930: 8b 85 ec fe ff ff            	mov	eax, dword ptr [ebp - 0x114]
 1066936: 33 d2                        	xor	edx, edx
 1066938: c7 85 04 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0xfc], 0x7
 1066942: c7 85 00 ff ff ff 00 00 00 00	mov	dword ptr [ebp - 0x100], 0x0
 106694c: 66 89 95 f0 fe ff ff         	mov	word ptr [ebp - 0x110], dx
 1066953: 50                           	push	eax
 1066954: e8 ce f1 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066959: 83 c4 04                     	add	esp, 0x4
 106695c: 33 db                        	xor	ebx, ebx
 106695e: 80 3d c8 82 af 01 00         	cmp	byte ptr [0x1af82c8], 0x0
 1066965: 0f 85 79 05 00 00            	jne	0x1066ee4 <.text+0x21c4>
 106696b: b9 cc 82 af 01               	mov	ecx, 0x1af82cc
 1066970: e8 7b e2 13 00               	call	0x11a4bf0 <.text+0x13fed0>
 1066975: c6 05 c8 82 af 01 01         	mov	byte ptr [0x1af82c8], 0x1
 106697c: e9 e2 e5 ff ff               	jmp	0x1064f63 <.text+0x243>
 1066981: e8 ea e8 16 00               	call	0x11d5270 <.text+0x170550>
 1066986: 85 c0                        	test	eax, eax
 1066988: 74 29                        	je	0x10669b3 <.text+0x1c93>
 106698a: 8b cb                        	mov	ecx, ebx
 106698c: e8 df e8 16 00               	call	0x11d5270 <.text+0x170550>
 1066991: 83 bd 68 ff ff ff 08         	cmp	dword ptr [ebp - 0x98], 0x8
 1066998: 8b 8d 54 ff ff ff            	mov	ecx, dword ptr [ebp - 0xac]
 106699e: 73 06                        	jae	0x10669a6 <.text+0x1c86>
 10669a0: 8d 8d 54 ff ff ff            	lea	ecx, [ebp - 0xac]
 10669a6: 8b 10                        	mov	edx, dword ptr [eax]
 10669a8: 51                           	push	ecx
 10669a9: 8b c8                        	mov	ecx, eax
 10669ab: 8b 82 8c 00 00 00            	mov	eax, dword ptr [edx + 0x8c]
 10669b1: ff d0                        	call	eax
 10669b3: 83 7b 44 ff                  	cmp	dword ptr [ebx + 0x44], -0x1
 10669b7: 75 11                        	jne	0x10669ca <.text+0x1caa>
 10669b9: 8d 8d 30 fe ff ff            	lea	ecx, [ebp - 0x1d0]
 10669bf: 51                           	push	ecx
 10669c0: 8d 4f 64                     	lea	ecx, [edi + 0x64]
 10669c3: e8 a8 cd 42 ff               	call	0x493770
 10669c8: eb 11                        	jmp	0x10669db <.text+0x1cbb>
 10669ca: 8d 95 50 ff ff ff            	lea	edx, [ebp - 0xb0]
 10669d0: 52                           	push	edx
 10669d1: 8d 4f 2c                     	lea	ecx, [edi + 0x2c]
 10669d4: e8 b7 e1 ff ff               	call	0x1064b90
 10669d9: 89 18                        	mov	dword ptr [eax], ebx
 10669db: 8b 8d 30 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1d0]
 10669e1: e8 8a e8 16 00               	call	0x11d5270 <.text+0x170550>
 10669e6: 8b f8                        	mov	edi, eax
 10669e8: 85 ff                        	test	edi, edi
 10669ea: 0f 84 03 01 00 00            	je	0x1066af3 <.text+0x1dd3>
 10669f0: 68 58 e0 82 01               	push	0x182e058
 10669f5: e8 f6 94 13 00               	call	0x119fef0 <.text+0x13b1d0>
 10669fa: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1066a00: 8b d0                        	mov	edx, eax
 1066a02: 83 c4 04                     	add	esp, 0x4
 1066a05: 83 c1 04                     	add	ecx, 0x4
 1066a08: 8d 5a 02                     	lea	ebx, [edx + 0x2]
 1066a0b: eb 03                        	jmp	0x1066a10 <.text+0x1cf0>
 1066a0d: 8d 49 00                     	lea	ecx, [ecx]
 1066a10: 66 8b 32                     	mov	si, word ptr [edx]
 1066a13: 83 c2 02                     	add	edx, 0x2
 1066a16: 66 85 f6                     	test	si, si
 1066a19: 75 f5                        	jne	0x1066a10 <.text+0x1cf0>
 1066a1b: 2b d3                        	sub	edx, ebx
 1066a1d: d1 fa                        	sar	edx
 1066a1f: 52                           	push	edx
 1066a20: 50                           	push	eax
 1066a21: 8b 41 14                     	mov	eax, dword ptr [ecx + 0x14]
 1066a24: 50                           	push	eax
 1066a25: 6a 00                        	push	0x0
 1066a27: e8 04 b2 39 ff               	call	0x401c30
 1066a2c: 85 c0                        	test	eax, eax
 1066a2e: 74 16                        	je	0x1066a46 <.text+0x1d26>
 1066a30: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1066a36: 8b 49 24                     	mov	ecx, dword ptr [ecx + 0x24]
 1066a39: e8 02 6e 3c ff               	call	0x42d840
 1066a3e: 50                           	push	eax
 1066a3f: 8b cf                        	mov	ecx, edi
 1066a41: e8 1a 7a 15 00               	call	0x11be460 <.text+0x159740>
 1066a46: 8b 95 48 fe ff ff            	mov	edx, dword ptr [ebp - 0x1b8]
 1066a4c: 8b 8a 8c 00 00 00            	mov	ecx, dword ptr [edx + 0x8c]
 1066a52: 85 c9                        	test	ecx, ecx
 1066a54: 74 15                        	je	0x1066a6b <.text+0x1d4b>
 1066a56: 8b 85 30 fe ff ff            	mov	eax, dword ptr [ebp - 0x1d0]
 1066a5c: 8b 40 44                     	mov	eax, dword ptr [eax + 0x44]
 1066a5f: 83 f8 ff                     	cmp	eax, -0x1
 1066a62: 74 07                        	je	0x1066a6b <.text+0x1d4b>
 1066a64: 57                           	push	edi
 1066a65: 50                           	push	eax
 1066a66: e8 f5 c3 ff ff               	call	0x1062e60
 1066a6b: 8b b5 e4 fd ff ff            	mov	esi, dword ptr [ebp - 0x21c]
 1066a71: 85 f6                        	test	esi, esi
 1066a73: 74 1e                        	je	0x1066a93 <.text+0x1d73>
 1066a75: 8b 8d 40 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1c0]
 1066a7b: 57                           	push	edi
 1066a7c: 51                           	push	ecx
 1066a7d: 8b ce                        	mov	ecx, esi
 1066a7f: e8 ac ba 15 00               	call	0x11c2530 <.text+0x15d810>
 1066a84: 8b ce                        	mov	ecx, esi
 1066a86: e8 85 9d 15 00               	call	0x11c0810 <.text+0x15baf0>
 1066a8b: 50                           	push	eax
 1066a8c: 8b ce                        	mov	ecx, esi
 1066a8e: e8 2d af 15 00               	call	0x11c19c0 <.text+0x15cca0>
 1066a93: 8b 8d e0 fd ff ff            	mov	ecx, dword ptr [ebp - 0x220]
 1066a99: 85 c9                        	test	ecx, ecx
 1066a9b: 74 0d                        	je	0x1066aaa <.text+0x1d8a>
 1066a9d: 8b 95 f8 fd ff ff            	mov	edx, dword ptr [ebp - 0x208]
 1066aa3: 57                           	push	edi
 1066aa4: 52                           	push	edx
 1066aa5: e8 26 46 02 00               	call	0x108b0d0 <.text+0x263b0>
 1066aaa: 8b 8d e8 fd ff ff            	mov	ecx, dword ptr [ebp - 0x218]
 1066ab0: 85 c9                        	test	ecx, ecx
 1066ab2: 74 18                        	je	0x1066acc <.text+0x1dac>
 1066ab4: e8 97 65 17 00               	call	0x11dd050 <.text+0x178330>
 1066ab9: 3b 85 44 fe ff ff            	cmp	eax, dword ptr [ebp - 0x1bc]
 1066abf: 74 0b                        	je	0x1066acc <.text+0x1dac>
 1066ac1: 8b 07                        	mov	eax, dword ptr [edi]
 1066ac3: 8b 50 10                     	mov	edx, dword ptr [eax + 0x10]
 1066ac6: 6a 00                        	push	0x0
 1066ac8: 8b cf                        	mov	ecx, edi
 1066aca: ff d2                        	call	edx
 1066acc: 83 bd 00 ff ff ff 00         	cmp	dword ptr [ebp - 0x100], 0x0
 1066ad3: 74 1e                        	je	0x1066af3 <.text+0x1dd3>
 1066ad5: 83 ec 20                     	sub	esp, 0x20
 1066ad8: 8d 85 ec fe ff ff            	lea	eax, [ebp - 0x114]
 1066ade: 8b cc                        	mov	ecx, esp
 1066ae0: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 1066ae6: 50                           	push	eax
 1066ae7: e8 d4 9d 3a ff               	call	0x4108c0
 1066aec: 8b cf                        	mov	ecx, edi
 1066aee: e8 ad 8e 15 00               	call	0x11bf9a0 <.text+0x15ac80>
 1066af3: 6a 00                        	push	0x0
 1066af5: 68 5c e6 a3 01               	push	0x1a3e65c
 1066afa: 68 88 96 9d 01               	push	0x19d9688
 1066aff: 6a 00                        	push	0x0
 1066b01: 57                           	push	edi
 1066b02: e8 d8 0b 37 00               	call	0x13d76df <.text+0x3729bf>
 1066b07: 83 c4 14                     	add	esp, 0x14
 1066b0a: 89 85 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], eax
 1066b10: 85 c0                        	test	eax, eax
 1066b12: 74 12                        	je	0x1066b26 <.text+0x1e06>
 1066b14: 8d 8d 44 fe ff ff            	lea	ecx, [ebp - 0x1bc]
 1066b1a: 51                           	push	ecx
 1066b1b: 8d 8d 14 fe ff ff            	lea	ecx, [ebp - 0x1ec]
 1066b21: e8 4a cc 42 ff               	call	0x493770
 1066b26: 83 bd 04 ff ff ff 08         	cmp	dword ptr [ebp - 0xfc], 0x8
 1066b2d: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 1066b31: 72 0f                        	jb	0x1066b42 <.text+0x1e22>
 1066b33: 8b 95 f0 fe ff ff            	mov	edx, dword ptr [ebp - 0x110]
 1066b39: 52                           	push	edx
 1066b3a: e8 e8 ef 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066b3f: 83 c4 04                     	add	esp, 0x4
 1066b42: 8b 8d ec fe ff ff            	mov	ecx, dword ptr [ebp - 0x114]
 1066b48: 33 c0                        	xor	eax, eax
 1066b4a: c7 85 04 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0xfc], 0x7
 1066b54: c7 85 00 ff ff ff 00 00 00 00	mov	dword ptr [ebp - 0x100], 0x0
 1066b5e: 66 89 85 f0 fe ff ff         	mov	word ptr [ebp - 0x110], ax
 1066b65: 51                           	push	ecx
 1066b66: e9 e9 fd ff ff               	jmp	0x1066954 <.text+0x1c34>
 1066b6b: 8d 8d 0c ff ff ff            	lea	ecx, [ebp - 0xf4]
 1066b71: 51                           	push	ecx
 1066b72: e8 69 c4 ff ff               	call	0x1062fe0
 1066b77: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066b7a: c6 45 fc 21                  	mov	byte ptr [ebp - 0x4], 0x21
 1066b7e: e8 0d b7 04 00               	call	0x10b2290 <.text+0x4d570>
 1066b83: 8d 95 0c ff ff ff            	lea	edx, [ebp - 0xf4]
 1066b89: 52                           	push	edx
 1066b8a: c6 45 fc 22                  	mov	byte ptr [ebp - 0x4], 0x22
 1066b8e: c6 85 37 fe ff ff 01         	mov	byte ptr [ebp - 0x1c9], 0x1
 1066b95: e8 b6 e5 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066b9a: 8d 45 d0                     	lea	eax, [ebp - 0x30]
 1066b9d: 50                           	push	eax
 1066b9e: e8 ad e5 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066ba3: 83 c4 08                     	add	esp, 0x8
 1066ba6: 88 85 37 fe ff ff            	mov	byte ptr [ebp - 0x1c9], al
 1066bac: 84 c0                        	test	al, al
 1066bae: 74 27                        	je	0x1066bd7 <.text+0x1eb7>
 1066bb0: 6a ff                        	push	-0x1
 1066bb2: 53                           	push	ebx
 1066bb3: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066bb6: 51                           	push	ecx
 1066bb7: 8d 8d 2c ff ff ff            	lea	ecx, [ebp - 0xd4]
 1066bbd: e8 6e e7 39 ff               	call	0x405330
 1066bc2: 8d 95 37 fe ff ff            	lea	edx, [ebp - 0x1c9]
 1066bc8: 52                           	push	edx
 1066bc9: e8 92 ca 1b 00               	call	0x1223660 <.text+0x1be940>
 1066bce: 83 c4 04                     	add	esp, 0x4
 1066bd1: 89 85 4c ff ff ff            	mov	dword ptr [ebp - 0xb4], eax
 1066bd7: 8d 85 0c ff ff ff            	lea	eax, [ebp - 0xf4]
 1066bdd: 50                           	push	eax
 1066bde: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 1066be4: e8 d7 da ff ff               	call	0x10646c0
 1066be9: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066bec: e8 ff 19 3f ff               	call	0x4585f0
 1066bf1: 8d 8d 0c ff ff ff            	lea	ecx, [ebp - 0xf4]
 1066bf7: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 1066bfb: e8 70 cb 69 ff               	call	0x703770
 1066c00: e9 59 fd ff ff               	jmp	0x106695e <.text+0x1c3e>
 1066c05: 2d fa 01 00 00               	sub	eax, 0x1fa
 1066c0a: 0f 84 62 e5 ff ff            	je	0x1065172 <.text+0x452>
 1066c10: 83 e8 07                     	sub	eax, 0x7
 1066c13: 0f 84 9b e5 ff ff            	je	0x10651b4 <.text+0x494>
 1066c19: e9 40 fd ff ff               	jmp	0x106695e <.text+0x1c3e>
 1066c1e: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066c21: e8 6a b6 04 00               	call	0x10b2290 <.text+0x4d570>
 1066c26: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 1066c2c: c6 45 fc 23                  	mov	byte ptr [ebp - 0x4], 0x23
 1066c30: e8 5b b6 04 00               	call	0x10b2290 <.text+0x4d570>
 1066c35: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 1066c38: 52                           	push	edx
 1066c39: c6 45 fc 24                  	mov	byte ptr [ebp - 0x4], 0x24
 1066c3d: e8 0e e5 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066c42: 83 c4 04                     	add	esp, 0x4
 1066c45: 84 c0                        	test	al, al
 1066c47: 0f 84 8c 10 00 00            	je	0x1067cd9 <.text+0x2fb9>
 1066c4d: 8d 85 30 ff ff ff            	lea	eax, [ebp - 0xd0]
 1066c53: 50                           	push	eax
 1066c54: e8 f7 e4 1b 00               	call	0x1225150 <.text+0x1c0430>
 1066c59: 83 c4 04                     	add	esp, 0x4
 1066c5c: 84 c0                        	test	al, al
 1066c5e: 0f 84 75 10 00 00            	je	0x1067cd9 <.text+0x2fb9>
 1066c64: 89 9d 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], ebx
 1066c6a: 8d 9b 00 00 00 00            	lea	ebx, [ebx]
 1066c70: f6 05 e4 82 af 01 10         	test	byte ptr [0x1af82e4], 0x10
 1066c77: 75 26                        	jne	0x1066c9f <.text+0x1f7f>
 1066c79: 83 0d e4 82 af 01 10         	or	dword ptr [0x1af82e4], 0x10
 1066c80: b9 98 82 af 01               	mov	ecx, 0x1af8298
 1066c85: c6 45 fc 25                  	mov	byte ptr [ebp - 0x4], 0x25
 1066c89: e8 62 7c 8c ff               	call	0x92e8f0
 1066c8e: 68 00 01 55 01               	push	0x1550100
 1066c93: e8 72 06 37 00               	call	0x13d730a <.text+0x3725ea>
 1066c98: 83 c4 04                     	add	esp, 0x4
 1066c9b: c6 45 fc 24                  	mov	byte ptr [ebp - 0x4], 0x24
 1066c9f: f6 05 e4 82 af 01 20         	test	byte ptr [0x1af82e4], 0x20
 1066ca6: 75 26                        	jne	0x1066cce <.text+0x1fae>
 1066ca8: 83 0d e4 82 af 01 20         	or	dword ptr [0x1af82e4], 0x20
 1066caf: b9 94 82 af 01               	mov	ecx, 0x1af8294
 1066cb4: c6 45 fc 26                  	mov	byte ptr [ebp - 0x4], 0x26
 1066cb8: e8 93 e4 13 00               	call	0x11a5150 <.text+0x140430>
 1066cbd: 68 d0 00 55 01               	push	0x15500d0
 1066cc2: e8 43 06 37 00               	call	0x13d730a <.text+0x3725ea>
 1066cc7: 83 c4 04                     	add	esp, 0x4
 1066cca: c6 45 fc 24                  	mov	byte ptr [ebp - 0x4], 0x24
 1066cce: 80 3d 90 82 af 01 00         	cmp	byte ptr [0x1af8290], 0x0
 1066cd5: 0f 84 e5 00 00 00            	je	0x1066dc0 <.text+0x20a0>
 1066cdb: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1066cdf: 72 0b                        	jb	0x1066cec <.text+0x1fcc>
 1066ce1: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
 1066ce4: 89 8d 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], ecx
 1066cea: eb 09                        	jmp	0x1066cf5 <.text+0x1fd5>
 1066cec: 8d 55 d4                     	lea	edx, [ebp - 0x2c]
 1066cef: 89 95 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], edx
 1066cf5: 8d 85 44 fe ff ff            	lea	eax, [ebp - 0x1bc]
 1066cfb: 50                           	push	eax
 1066cfc: 8d 8d d0 fb ff ff            	lea	ecx, [ebp - 0x430]
 1066d02: 51                           	push	ecx
 1066d03: b9 98 82 af 01               	mov	ecx, 0x1af8298
 1066d08: e8 03 1a 3f ff               	call	0x458710
 1066d0d: 8b 08                        	mov	ecx, dword ptr [eax]
 1066d0f: 33 f6                        	xor	esi, esi
 1066d11: 3b cb                        	cmp	ecx, ebx
 1066d13: 74 08                        	je	0x1066d1d <.text+0x1ffd>
 1066d15: 8b 09                        	mov	ecx, dword ptr [ecx]
 1066d17: 3b cb                        	cmp	ecx, ebx
 1066d19: 74 02                        	je	0x1066d1d <.text+0x1ffd>
 1066d1b: 8b 31                        	mov	esi, dword ptr [ecx]
 1066d1d: 8b 78 08                     	mov	edi, dword ptr [eax + 0x8]
 1066d20: 8d 95 48 fd ff ff            	lea	edx, [ebp - 0x2b8]
 1066d26: 52                           	push	edx
 1066d27: b9 98 82 af 01               	mov	ecx, 0x1af8298
 1066d2c: e8 0f d6 75 ff               	call	0x7c4340
 1066d31: 3b f3                        	cmp	esi, ebx
 1066d33: 0f 84 d0 02 00 00            	je	0x1067009 <.text+0x22e9>
 1066d39: 8b 36                        	mov	esi, dword ptr [esi]
 1066d3b: 3b f3                        	cmp	esi, ebx
 1066d3d: 0f 84 c6 02 00 00            	je	0x1067009 <.text+0x22e9>
 1066d43: 8b 08                        	mov	ecx, dword ptr [eax]
 1066d45: 3b cb                        	cmp	ecx, ebx
 1066d47: 75 04                        	jne	0x1066d4d <.text+0x202d>
 1066d49: 33 c9                        	xor	ecx, ecx
 1066d4b: eb 02                        	jmp	0x1066d4f <.text+0x202f>
 1066d4d: 8b 09                        	mov	ecx, dword ptr [ecx]
 1066d4f: 3b f1                        	cmp	esi, ecx
 1066d51: 0f 85 b2 02 00 00            	jne	0x1067009 <.text+0x22e9>
 1066d57: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
 1066d5a: 0f 94 c0                     	sete	al
 1066d5d: 84 c0                        	test	al, al
 1066d5f: 0f 94 c0                     	sete	al
 1066d62: 84 c0                        	test	al, al
 1066d64: 0f 84 04 01 00 00            	je	0x1066e6e <.text+0x214e>
 1066d6a: 8b 7f 10                     	mov	edi, dword ptr [edi + 0x10]
 1066d6d: 3b fb                        	cmp	edi, ebx
 1066d6f: 74 0c                        	je	0x1066d7d <.text+0x205d>
 1066d71: 81 ff 09 02 00 00            	cmp	edi, 0x209
 1066d77: 0f 85 f1 00 00 00            	jne	0x1066e6e <.text+0x214e>
 1066d7d: 80 3d 90 82 af 01 00         	cmp	byte ptr [0x1af8290], 0x0
 1066d84: 75 5c                        	jne	0x1066de2 <.text+0x20c2>
 1066d86: 68 bc 2e 7f 01               	push	0x17f2ebc
 1066d8b: e8 60 91 13 00               	call	0x119fef0 <.text+0x13b1d0>
 1066d90: 83 c4 04                     	add	esp, 0x4
 1066d93: 89 85 38 fd ff ff            	mov	dword ptr [ebp - 0x2c8], eax
 1066d99: 8d 85 38 fd ff ff            	lea	eax, [ebp - 0x2c8]
 1066d9f: 50                           	push	eax
 1066da0: 8d 8d b0 fa ff ff            	lea	ecx, [ebp - 0x550]
 1066da6: 51                           	push	ecx
 1066da7: b9 98 82 af 01               	mov	ecx, 0x1af8298
 1066dac: c7 85 3c fd ff ff 09 02 00 00	mov	dword ptr [ebp - 0x2c4], 0x209
 1066db6: e8 15 1e 3f ff               	call	0x458bd0
 1066dbb: e9 ae 00 00 00               	jmp	0x1066e6e <.text+0x214e>
 1066dc0: b9 94 82 af 01               	mov	ecx, 0x1af8294
 1066dc5: e8 f6 dd 13 00               	call	0x11a4bc0 <.text+0x13fea0>
 1066dca: 80 3d 90 82 af 01 00         	cmp	byte ptr [0x1af8290], 0x0
 1066dd1: 74 b3                        	je	0x1066d86 <.text+0x2066>
 1066dd3: b9 94 82 af 01               	mov	ecx, 0x1af8294
 1066dd8: e8 13 de 13 00               	call	0x11a4bf0 <.text+0x13fed0>
 1066ddd: e9 8e fe ff ff               	jmp	0x1066c70 <.text+0x1f50>
 1066de2: 8d 95 dc fd ff ff            	lea	edx, [ebp - 0x224]
 1066de8: 52                           	push	edx
 1066de9: e8 f2 c8 1b 00               	call	0x12236e0 <.text+0x1be9c0>
 1066dee: 83 c4 04                     	add	esp, 0x4
 1066df1: 84 c0                        	test	al, al
 1066df3: 0f 84 7e 0e 00 00            	je	0x1067c77 <.text+0x2f57>
 1066df9: 39 9d dc fd ff ff            	cmp	dword ptr [ebp - 0x224], ebx
 1066dff: 0f 8e 72 0e 00 00            	jle	0x1067c77 <.text+0x2f57>
 1066e05: 6a 3c                        	push	0x3c
 1066e07: e8 0e fd 36 00               	call	0x13d6b1a <.text+0x371dfa>
 1066e0c: 83 c4 04                     	add	esp, 0x4
 1066e0f: 89 85 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], eax
 1066e15: c6 45 fc 27                  	mov	byte ptr [ebp - 0x4], 0x27
 1066e19: 3b c3                        	cmp	eax, ebx
 1066e1b: 74 0b                        	je	0x1066e28 <.text+0x2108>
 1066e1d: 8b c8                        	mov	ecx, eax
 1066e1f: e8 5c 65 69 ff               	call	0x6fd380
 1066e24: 8b f8                        	mov	edi, eax
 1066e26: eb 02                        	jmp	0x1066e2a <.text+0x210a>
 1066e28: 33 ff                        	xor	edi, edi
 1066e2a: 33 f6                        	xor	esi, esi
 1066e2c: c6 45 fc 24                  	mov	byte ptr [ebp - 0x4], 0x24
 1066e30: 89 bd 40 fe ff ff            	mov	dword ptr [ebp - 0x1c0], edi
 1066e36: 39 9d dc fd ff ff            	cmp	dword ptr [ebp - 0x224], ebx
 1066e3c: 7e 30                        	jle	0x1066e6e <.text+0x214e>
 1066e3e: 8b ff                        	mov	edi, edi
 1066e40: 8d 85 f4 fd ff ff            	lea	eax, [ebp - 0x20c]
 1066e46: 50                           	push	eax
 1066e47: e8 94 c8 1b 00               	call	0x12236e0 <.text+0x1be9c0>
 1066e4c: 83 c4 04                     	add	esp, 0x4
 1066e4f: 84 c0                        	test	al, al
 1066e51: 0f 84 82 0e 00 00            	je	0x1067cd9 <.text+0x2fb9>
 1066e57: 8b 8d f4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x20c]
 1066e5d: 51                           	push	ecx
 1066e5e: 8b cf                        	mov	ecx, edi
 1066e60: e8 bb 64 69 ff               	call	0x6fd320
 1066e65: 46                           	inc	esi
 1066e66: 3b b5 dc fd ff ff            	cmp	esi, dword ptr [ebp - 0x224]
 1066e6c: 7c d2                        	jl	0x1066e40 <.text+0x2120>
 1066e6e: 80 3d 90 82 af 01 00         	cmp	byte ptr [0x1af8290], 0x0
 1066e75: 75 16                        	jne	0x1066e8d <.text+0x216d>
 1066e77: b9 94 82 af 01               	mov	ecx, 0x1af8294
 1066e7c: e8 6f dd 13 00               	call	0x11a4bf0 <.text+0x13fed0>
 1066e81: c6 05 90 82 af 01 01         	mov	byte ptr [0x1af8290], 0x1
 1066e88: e9 e3 fd ff ff               	jmp	0x1066c70 <.text+0x1f50>
 1066e8d: 39 9d 40 fe ff ff            	cmp	dword ptr [ebp - 0x1c0], ebx
 1066e93: 0f 84 59 0d 00 00            	je	0x1067bf2 <.text+0x2ed2>
 1066e99: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1066e9f: 8d 95 30 ff ff ff            	lea	edx, [ebp - 0xd0]
 1066ea5: 52                           	push	edx
 1066ea6: 81 c1 ac 00 00 00            	add	ecx, 0xac
 1066eac: e8 3f d1 2e 00               	call	0x1353ff0 <.text+0x2ef2d0>
 1066eb1: 8b 8d 40 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1c0]
 1066eb7: 89 08                        	mov	dword ptr [eax], ecx
 1066eb9: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 1066ebf: e8 2c 17 3f ff               	call	0x4585f0
 1066ec4: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1066ec7: c6 45 fc 07                  	mov	byte ptr [ebp - 0x4], 0x7
 1066ecb: e8 20 17 3f ff               	call	0x4585f0
 1066ed0: e9 89 fa ff ff               	jmp	0x106695e <.text+0x1c3e>
 1066ed5: 80 7d 28 00                  	cmp	byte ptr [ebp + 0x28], 0x0
 1066ed9: 0f 85 26 0d 00 00            	jne	0x1067c05 <.text+0x2ee5>
 1066edf: e9 7a fa ff ff               	jmp	0x106695e <.text+0x1c3e>
 1066ee4: 83 bd 68 ff ff ff 08         	cmp	dword ptr [ebp - 0x98], 0x8
 1066eeb: c6 45 fc 06                  	mov	byte ptr [ebp - 0x4], 0x6
 1066eef: 72 0f                        	jb	0x1066f00 <.text+0x21e0>
 1066ef1: 8b 95 54 ff ff ff            	mov	edx, dword ptr [ebp - 0xac]
 1066ef7: 52                           	push	edx
 1066ef8: e8 2a ec 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066efd: 83 c4 04                     	add	esp, 0x4
 1066f00: 8b 8d 50 ff ff ff            	mov	ecx, dword ptr [ebp - 0xb0]
 1066f06: 33 c0                        	xor	eax, eax
 1066f08: 51                           	push	ecx
 1066f09: c7 85 68 ff ff ff 07 00 00 00	mov	dword ptr [ebp - 0x98], 0x7
 1066f13: 89 9d 64 ff ff ff            	mov	dword ptr [ebp - 0x9c], ebx
 1066f19: 66 89 85 54 ff ff ff         	mov	word ptr [ebp - 0xac], ax
 1066f20: e8 02 ec 36 00               	call	0x13d5b27 <.text+0x370e07>
 1066f25: 8d 55 b0                     	lea	edx, [ebp - 0x50]
 1066f28: 6a 01                        	push	0x1
 1066f2a: 52                           	push	edx
 1066f2b: e8 e0 e2 1b 00               	call	0x1225210 <.text+0x1c04f0>
 1066f30: 83 c4 0c                     	add	esp, 0xc
 1066f33: 84 c0                        	test	al, al
 1066f35: 0f 85 d5 df ff ff            	jne	0x1064f10 <.text+0x1f0>
 1066f3b: 8b 85 18 fe ff ff            	mov	eax, dword ptr [ebp - 0x1e8]
 1066f41: 3b 85 1c fe ff ff            	cmp	eax, dword ptr [ebp - 0x1e4]
 1066f47: 0f 84 c1 00 00 00            	je	0x106700e <.text+0x22ee>
 1066f4d: 8d 8d 48 fd ff ff            	lea	ecx, [ebp - 0x2b8]
 1066f53: 51                           	push	ecx
 1066f54: 8d 8d 14 fe ff ff            	lea	ecx, [ebp - 0x1ec]
 1066f5a: e8 e1 d3 75 ff               	call	0x7c4340
 1066f5f: 8b 08                        	mov	ecx, dword ptr [eax]
 1066f61: c7 85 08 fe ff ff 00 00 00 00	mov	dword ptr [ebp - 0x1f8], 0x0
 1066f6b: 85 c9                        	test	ecx, ecx
 1066f6d: 74 0e                        	je	0x1066f7d <.text+0x225d>
 1066f6f: 8b 09                        	mov	ecx, dword ptr [ecx]
 1066f71: 85 c9                        	test	ecx, ecx
 1066f73: 74 08                        	je	0x1066f7d <.text+0x225d>
 1066f75: 8b 11                        	mov	edx, dword ptr [ecx]
 1066f77: 89 95 08 fe ff ff            	mov	dword ptr [ebp - 0x1f8], edx
 1066f7d: 8b 58 08                     	mov	ebx, dword ptr [eax + 0x8]
 1066f80: 8d 85 48 fd ff ff            	lea	eax, [ebp - 0x2b8]
 1066f86: 50                           	push	eax
 1066f87: 8d 8d 14 fe ff ff            	lea	ecx, [ebp - 0x1ec]
 1066f8d: e8 de f1 10 00               	call	0x1176170 <.text+0x111450>
 1066f92: 8b 08                        	mov	ecx, dword ptr [eax]
 1066f94: 33 ff                        	xor	edi, edi
 1066f96: 85 c9                        	test	ecx, ecx
 1066f98: 74 08                        	je	0x1066fa2 <.text+0x2282>
 1066f9a: 8b 09                        	mov	ecx, dword ptr [ecx]
 1066f9c: 85 c9                        	test	ecx, ecx
 1066f9e: 74 02                        	je	0x1066fa2 <.text+0x2282>
 1066fa0: 8b 39                        	mov	edi, dword ptr [ecx]
 1066fa2: 8b 70 08                     	mov	esi, dword ptr [eax + 0x8]
 1066fa5: 8b 95 08 fe ff ff            	mov	edx, dword ptr [ebp - 0x1f8]
 1066fab: eb 03                        	jmp	0x1066fb0 <.text+0x2290>
 1066fad: 8d 49 00                     	lea	ecx, [ecx]
 1066fb0: 85 ff                        	test	edi, edi
 1066fb2: 74 55                        	je	0x1067009 <.text+0x22e9>
 1066fb4: 8b 0f                        	mov	ecx, dword ptr [edi]
 1066fb6: 85 c9                        	test	ecx, ecx
 1066fb8: 74 4f                        	je	0x1067009 <.text+0x22e9>
 1066fba: 85 d2                        	test	edx, edx
 1066fbc: 75 04                        	jne	0x1066fc2 <.text+0x22a2>
 1066fbe: 33 c0                        	xor	eax, eax
 1066fc0: eb 02                        	jmp	0x1066fc4 <.text+0x22a4>
 1066fc2: 8b 02                        	mov	eax, dword ptr [edx]
 1066fc4: 3b c8                        	cmp	ecx, eax
 1066fc6: 75 41                        	jne	0x1067009 <.text+0x22e9>
 1066fc8: 3b f3                        	cmp	esi, ebx
 1066fca: 0f 94 c0                     	sete	al
 1066fcd: 84 c0                        	test	al, al
 1066fcf: 0f 94 c0                     	sete	al
 1066fd2: 84 c0                        	test	al, al
 1066fd4: 74 38                        	je	0x106700e <.text+0x22ee>
 1066fd6: 85 c9                        	test	ecx, ecx
 1066fd8: 74 2f                        	je	0x1067009 <.text+0x22e9>
 1066fda: 85 f6                        	test	esi, esi
 1066fdc: 74 2b                        	je	0x1067009 <.text+0x22e9>
 1066fde: 39 71 04                     	cmp	dword ptr [ecx + 0x4], esi
 1066fe1: 77 26                        	ja	0x1067009 <.text+0x22e9>
 1066fe3: 3b 71 08                     	cmp	esi, dword ptr [ecx + 0x8]
 1066fe6: 73 21                        	jae	0x1067009 <.text+0x22e9>
 1066fe8: 8b 0e                        	mov	ecx, dword ptr [esi]
 1066fea: 85 c9                        	test	ecx, ecx
 1066fec: 74 0b                        	je	0x1066ff9 <.text+0x22d9>
 1066fee: e8 bd c2 f9 ff               	call	0x10032b0
 1066ff3: 8b 95 08 fe ff ff            	mov	edx, dword ptr [ebp - 0x1f8]
 1066ff9: 8b 07                        	mov	eax, dword ptr [edi]
 1066ffb: 85 c0                        	test	eax, eax
 1066ffd: 74 0a                        	je	0x1067009 <.text+0x22e9>
 1066fff: 3b 70 08                     	cmp	esi, dword ptr [eax + 0x8]
 1067002: 73 05                        	jae	0x1067009 <.text+0x22e9>
 1067004: 83 c6 04                     	add	esi, 0x4
 1067007: eb a7                        	jmp	0x1066fb0 <.text+0x2290>
 1067009: e8 99 fd 36 00               	call	0x13d6da7 <.text+0x372087>
 106700e: 8b 8d c8 fd ff ff            	mov	ecx, dword ptr [ebp - 0x238]
 1067014: 3b 8d cc fd ff ff            	cmp	ecx, dword ptr [ebp - 0x234]
 106701a: 0f 84 af 04 00 00            	je	0x10674cf <.text+0x27af>
 1067020: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 1067026: 8b 57 24                     	mov	edx, dword ptr [edi + 0x24]
 1067029: 8d 85 08 fe ff ff            	lea	eax, [ebp - 0x1f8]
 106702f: 50                           	push	eax
 1067030: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 1067036: 89 95 f8 fd ff ff            	mov	dword ptr [ebp - 0x208], edx
 106703c: e8 2f f1 10 00               	call	0x1176170 <.text+0x111450>
 1067041: 8b 9d 10 fe ff ff            	mov	ebx, dword ptr [ebp - 0x1f0]
 1067047: 8b b5 08 fe ff ff            	mov	esi, dword ptr [ebp - 0x1f8]
 106704d: 8d 8d 48 fd ff ff            	lea	ecx, [ebp - 0x2b8]
 1067053: 51                           	push	ecx
 1067054: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 106705a: e8 e1 d2 75 ff               	call	0x7c4340
 106705f: 85 f6                        	test	esi, esi
 1067061: 74 a6                        	je	0x1067009 <.text+0x22e9>
 1067063: 8b 16                        	mov	edx, dword ptr [esi]
 1067065: 85 d2                        	test	edx, edx
 1067067: 74 a0                        	je	0x1067009 <.text+0x22e9>
 1067069: 8b 08                        	mov	ecx, dword ptr [eax]
 106706b: 85 c9                        	test	ecx, ecx
 106706d: 74 02                        	je	0x1067071 <.text+0x2351>
 106706f: 8b 09                        	mov	ecx, dword ptr [ecx]
 1067071: 3b d1                        	cmp	edx, ecx
 1067073: 75 94                        	jne	0x1067009 <.text+0x22e9>
 1067075: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 1067078: 0f 94 c0                     	sete	al
 106707b: 84 c0                        	test	al, al
 106707d: 0f 94 c0                     	sete	al
 1067080: 84 c0                        	test	al, al
 1067082: 0f 84 3e 04 00 00            	je	0x10674c6 <.text+0x27a6>
 1067088: 8d 95 d0 fb ff ff            	lea	edx, [ebp - 0x430]
 106708e: 81 c7 98 00 00 00            	add	edi, 0x98
 1067094: 52                           	push	edx
 1067095: 8b cf                        	mov	ecx, edi
 1067097: e8 a4 d2 75 ff               	call	0x7c4340
 106709c: 8b f0                        	mov	esi, eax
 106709e: 8b 85 08 fe ff ff            	mov	eax, dword ptr [ebp - 0x1f8]
 10670a4: 8b 00                        	mov	eax, dword ptr [eax]
 10670a6: 85 c0                        	test	eax, eax
 10670a8: 0f 84 5b ff ff ff            	je	0x1067009 <.text+0x22e9>
 10670ae: 85 db                        	test	ebx, ebx
 10670b0: 0f 84 53 ff ff ff            	je	0x1067009 <.text+0x22e9>
 10670b6: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 10670b9: 0f 87 4a ff ff ff            	ja	0x1067009 <.text+0x22e9>
 10670bf: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 10670c2: 0f 83 41 ff ff ff            	jae	0x1067009 <.text+0x22e9>
 10670c8: 53                           	push	ebx
 10670c9: 83 ec 0c                     	sub	esp, 0xc
 10670cc: 8b cc                        	mov	ecx, esp
 10670ce: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 10670d4: 51                           	push	ecx
 10670d5: 8b cf                        	mov	ecx, edi
 10670d7: e8 64 d2 75 ff               	call	0x7c4340
 10670dc: 83 ec 0c                     	sub	esp, 0xc
 10670df: 8b d4                        	mov	edx, esp
 10670e1: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 10670e7: 52                           	push	edx
 10670e8: 8b cf                        	mov	ecx, edi
 10670ea: e8 81 f0 10 00               	call	0x1176170 <.text+0x111450>
 10670ef: 8d 85 dc fb ff ff            	lea	eax, [ebp - 0x424]
 10670f5: 50                           	push	eax
 10670f6: e8 c5 c0 ff ff               	call	0x10631c0
 10670fb: 8b 08                        	mov	ecx, dword ptr [eax]
 10670fd: 83 c4 20                     	add	esp, 0x20
 1067100: 85 c9                        	test	ecx, ecx
 1067102: 0f 84 01 ff ff ff            	je	0x1067009 <.text+0x22e9>
 1067108: 8b 09                        	mov	ecx, dword ptr [ecx]
 106710a: 33 ff                        	xor	edi, edi
 106710c: 3b cf                        	cmp	ecx, edi
 106710e: 0f 84 f5 fe ff ff            	je	0x1067009 <.text+0x22e9>
 1067114: 8b 16                        	mov	edx, dword ptr [esi]
 1067116: 3b d7                        	cmp	edx, edi
 1067118: 75 04                        	jne	0x106711e <.text+0x23fe>
 106711a: 33 d2                        	xor	edx, edx
 106711c: eb 02                        	jmp	0x1067120 <.text+0x2400>
 106711e: 8b 12                        	mov	edx, dword ptr [edx]
 1067120: 3b ca                        	cmp	ecx, edx
 1067122: 0f 85 e1 fe ff ff            	jne	0x1067009 <.text+0x22e9>
 1067128: 8b 48 08                     	mov	ecx, dword ptr [eax + 0x8]
 106712b: 3b 4e 08                     	cmp	ecx, dword ptr [esi + 0x8]
 106712e: 0f 94 c0                     	sete	al
 1067131: 84 c0                        	test	al, al
 1067133: 0f 94 c0                     	sete	al
 1067136: 84 c0                        	test	al, al
 1067138: 0f 85 65 02 00 00            	jne	0x10673a3 <.text+0x2683>
 106713e: 8b 85 08 fe ff ff            	mov	eax, dword ptr [ebp - 0x1f8]
 1067144: 8b 00                        	mov	eax, dword ptr [eax]
 1067146: 8d 95 44 fe ff ff            	lea	edx, [ebp - 0x1bc]
 106714c: 89 bd 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], edi
 1067152: 52                           	push	edx
 1067153: 3b c7                        	cmp	eax, edi
 1067155: 0f 84 ae fe ff ff            	je	0x1067009 <.text+0x22e9>
 106715b: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 106715e: 0f 87 a5 fe ff ff            	ja	0x1067009 <.text+0x22e9>
 1067164: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 1067167: 0f 83 9c fe ff ff            	jae	0x1067009 <.text+0x22e9>
 106716d: be 08 00 00 00               	mov	esi, 0x8
 1067172: 39 73 38                     	cmp	dword ptr [ebx + 0x38], esi
 1067175: 72 05                        	jb	0x106717c <.text+0x245c>
 1067177: 8b 43 24                     	mov	eax, dword ptr [ebx + 0x24]
 106717a: eb 03                        	jmp	0x106717f <.text+0x245f>
 106717c: 8d 43 24                     	lea	eax, [ebx + 0x24]
 106717f: 83 ec 20                     	sub	esp, 0x20
 1067182: 8b cc                        	mov	ecx, esp
 1067184: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 106718a: 50                           	push	eax
 106718b: e8 90 ad 3a ff               	call	0x411f20
 1067190: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1067196: e8 45 bf ff ff               	call	0x10630e0
 106719b: 8b 8d 08 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1f8]
 10671a1: 8b 01                        	mov	eax, dword ptr [ecx]
 10671a3: 85 c0                        	test	eax, eax
 10671a5: 0f 84 5e fe ff ff            	je	0x1067009 <.text+0x22e9>
 10671ab: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 10671ae: 0f 87 55 fe ff ff            	ja	0x1067009 <.text+0x22e9>
 10671b4: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 10671b7: 0f 83 4c fe ff ff            	jae	0x1067009 <.text+0x22e9>
 10671bd: 39 73 38                     	cmp	dword ptr [ebx + 0x38], esi
 10671c0: 72 05                        	jb	0x10671c7 <.text+0x24a7>
 10671c2: 8b 73 24                     	mov	esi, dword ptr [ebx + 0x24]
 10671c5: eb 03                        	jmp	0x10671ca <.text+0x24aa>
 10671c7: 8d 73 24                     	lea	esi, [ebx + 0x24]
 10671ca: 85 f6                        	test	esi, esi
 10671cc: 74 42                        	je	0x1067210 <.text+0x24f0>
 10671ce: 8d 95 f4 fd ff ff            	lea	edx, [ebp - 0x20c]
 10671d4: 52                           	push	edx
 10671d5: 83 ec 20                     	sub	esp, 0x20
 10671d8: 8b cc                        	mov	ecx, esp
 10671da: 89 a5 28 fe ff ff            	mov	dword ptr [ebp - 0x1d8], esp
 10671e0: 56                           	push	esi
 10671e1: e8 3a ad 3a ff               	call	0x411f20
 10671e6: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 10671ec: e8 ef be ff ff               	call	0x10630e0
 10671f1: 84 c0                        	test	al, al
 10671f3: 74 1b                        	je	0x1067210 <.text+0x24f0>
 10671f5: 8b 85 f4 fd ff ff            	mov	eax, dword ptr [ebp - 0x20c]
 10671fb: 8b b5 48 fe ff ff            	mov	esi, dword ptr [ebp - 0x1b8]
 1067201: 6a 01                        	push	0x1
 1067203: 50                           	push	eax
 1067204: 8b ce                        	mov	ecx, esi
 1067206: e8 95 c0 ff ff               	call	0x10632a0
 106720b: e9 b1 00 00 00               	jmp	0x10672c1 <.text+0x25a1>
 1067210: 56                           	push	esi
 1067211: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1067214: e8 07 ad 3a ff               	call	0x411f20
 1067219: 8b b5 48 fe ff ff            	mov	esi, dword ptr [ebp - 0x1b8]
 106721f: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1067222: 51                           	push	ecx
 1067223: 8d 95 9c fd ff ff            	lea	edx, [ebp - 0x264]
 1067229: 52                           	push	edx
 106722a: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
 106722d: c6 45 fc 28                  	mov	byte ptr [ebp - 0x4], 0x28
 1067231: e8 1a c7 ff ff               	call	0x1063950
 1067236: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 106723a: c6 45 fc 06                  	mov	byte ptr [ebp - 0x4], 0x6
 106723e: 72 0c                        	jb	0x106724c <.text+0x252c>
 1067240: 8b 45 d4                     	mov	eax, dword ptr [ebp - 0x2c]
 1067243: 50                           	push	eax
 1067244: e8 de e8 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067249: 83 c4 04                     	add	esp, 0x4
 106724c: 8b 55 d0                     	mov	edx, dword ptr [ebp - 0x30]
 106724f: 33 c9                        	xor	ecx, ecx
 1067251: 52                           	push	edx
 1067252: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1067259: c7 45 e4 00 00 00 00         	mov	dword ptr [ebp - 0x1c], 0x0
 1067260: 66 89 4d d4                  	mov	word ptr [ebp - 0x2c], cx
 1067264: e8 be e8 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067269: 83 c4 04                     	add	esp, 0x4
 106726c: 8d 85 c4 fb ff ff            	lea	eax, [ebp - 0x43c]
 1067272: 50                           	push	eax
 1067273: 8d 4e 2c                     	lea	ecx, [esi + 0x2c]
 1067276: c7 45 d0 00 00 00 00         	mov	dword ptr [ebp - 0x30], 0x0
 106727d: e8 0e 85 74 ff               	call	0x7af790
 1067282: 8b 8d 9c fd ff ff            	mov	ecx, dword ptr [ebp - 0x264]
 1067288: 85 c9                        	test	ecx, ecx
 106728a: 0f 84 79 fd ff ff            	je	0x1067009 <.text+0x22e9>
 1067290: 8b 11                        	mov	edx, dword ptr [ecx]
 1067292: 85 d2                        	test	edx, edx
 1067294: 0f 84 6f fd ff ff            	je	0x1067009 <.text+0x22e9>
 106729a: 8b 08                        	mov	ecx, dword ptr [eax]
 106729c: 85 c9                        	test	ecx, ecx
 106729e: 74 02                        	je	0x10672a2 <.text+0x2582>
 10672a0: 8b 09                        	mov	ecx, dword ptr [ecx]
 10672a2: 3b d1                        	cmp	edx, ecx
 10672a4: 0f 85 5f fd ff ff            	jne	0x1067009 <.text+0x22e9>
 10672aa: 8b 8d a4 fd ff ff            	mov	ecx, dword ptr [ebp - 0x25c]
 10672b0: 3b 48 08                     	cmp	ecx, dword ptr [eax + 0x8]
 10672b3: 74 0a                        	je	0x10672bf <.text+0x259f>
 10672b5: 8b 49 28                     	mov	ecx, dword ptr [ecx + 0x28]
 10672b8: e8 b3 df 16 00               	call	0x11d5270 <.text+0x170550>
 10672bd: eb 02                        	jmp	0x10672c1 <.text+0x25a1>
 10672bf: 33 c0                        	xor	eax, eax
 10672c1: 89 46 24                     	mov	dword ptr [esi + 0x24], eax
 10672c4: 85 c0                        	test	eax, eax
 10672c6: 75 09                        	jne	0x10672d1 <.text+0x25b1>
 10672c8: 8b 8d f8 fd ff ff            	mov	ecx, dword ptr [ebp - 0x208]
 10672ce: 89 4e 24                     	mov	dword ptr [esi + 0x24], ecx
 10672d1: 8b 8d 08 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1f8]
 10672d7: 8b 01                        	mov	eax, dword ptr [ecx]
 10672d9: 85 c0                        	test	eax, eax
 10672db: 0f 84 28 fd ff ff            	je	0x1067009 <.text+0x22e9>
 10672e1: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 10672e4: 0f 87 1f fd ff ff            	ja	0x1067009 <.text+0x22e9>
 10672ea: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 10672ed: 0f 83 16 fd ff ff            	jae	0x1067009 <.text+0x22e9>
 10672f3: 83 7b 40 ff                  	cmp	dword ptr [ebx + 0x40], -0x1
 10672f7: 75 23                        	jne	0x106731c <.text+0x25fc>
 10672f9: 85 c0                        	test	eax, eax
 10672fb: 0f 84 08 fd ff ff            	je	0x1067009 <.text+0x22e9>
 1067301: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 1067304: 0f 87 ff fc ff ff            	ja	0x1067009 <.text+0x22e9>
 106730a: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 106730d: 0f 83 f6 fc ff ff            	jae	0x1067009 <.text+0x22e9>
 1067313: 8b 95 44 fe ff ff            	mov	edx, dword ptr [ebp - 0x1bc]
 1067319: 89 53 40                     	mov	dword ptr [ebx + 0x40], edx
 106731c: 8b 01                        	mov	eax, dword ptr [ecx]
 106731e: 85 c0                        	test	eax, eax
 1067320: 0f 84 e3 fc ff ff            	je	0x1067009 <.text+0x22e9>
 1067326: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 1067329: 0f 87 da fc ff ff            	ja	0x1067009 <.text+0x22e9>
 106732f: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 1067332: 0f 83 d1 fc ff ff            	jae	0x1067009 <.text+0x22e9>
 1067338: 85 c0                        	test	eax, eax
 106733a: 0f 84 c9 fc ff ff            	je	0x1067009 <.text+0x22e9>
 1067340: 39 58 04                     	cmp	dword ptr [eax + 0x4], ebx
 1067343: 0f 87 c0 fc ff ff            	ja	0x1067009 <.text+0x22e9>
 1067349: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 106734c: 0f 83 b7 fc ff ff            	jae	0x1067009 <.text+0x22e9>
 1067352: 83 7b 18 08                  	cmp	dword ptr [ebx + 0x18], 0x8
 1067356: 72 05                        	jb	0x106735d <.text+0x263d>
 1067358: 8b 43 04                     	mov	eax, dword ptr [ebx + 0x4]
 106735b: eb 03                        	jmp	0x1067360 <.text+0x2640>
 106735d: 8d 43 04                     	lea	eax, [ebx + 0x4]
 1067360: 8b 4b 40                     	mov	ecx, dword ptr [ebx + 0x40]
 1067363: 03 4d 2c                     	add	ecx, dword ptr [ebp + 0x2c]
 1067366: 51                           	push	ecx
 1067367: 6a 01                        	push	0x1
 1067369: 50                           	push	eax
 106736a: 8b ce                        	mov	ecx, esi
 106736c: e8 4f 0b 00 00               	call	0x1067ec0 <.text+0x31a0>
 1067371: 8d 8e 98 00 00 00            	lea	ecx, [esi + 0x98]
 1067377: e8 b4 c9 ff ff               	call	0x1063d30
 106737c: 8b 95 08 fe ff ff            	mov	edx, dword ptr [ebp - 0x1f8]
 1067382: 8b 02                        	mov	eax, dword ptr [edx]
 1067384: 85 c0                        	test	eax, eax
 1067386: 0f 84 7d fc ff ff            	je	0x1067009 <.text+0x22e9>
 106738c: 3b 58 08                     	cmp	ebx, dword ptr [eax + 0x8]
 106738f: 0f 83 74 fc ff ff            	jae	0x1067009 <.text+0x22e9>
 1067395: 8b bd 48 fe ff ff            	mov	edi, dword ptr [ebp - 0x1b8]
 106739b: 83 c3 44                     	add	ebx, 0x44
 106739e: e9 a4 fc ff ff               	jmp	0x1067047 <.text+0x2327>
 10673a3: 33 c0                        	xor	eax, eax
 10673a5: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 10673ab: c7 00 36 02 00 00            	mov	dword ptr [eax], 0x236
 10673b1: e8 2a d2 ff ff               	call	0x10645e0
 10673b6: 8b 85 18 fe ff ff            	mov	eax, dword ptr [ebp - 0x1e8]
 10673bc: 3b c7                        	cmp	eax, edi
 10673be: 74 09                        	je	0x10673c9 <.text+0x26a9>
 10673c0: 50                           	push	eax
 10673c1: e8 61 e7 36 00               	call	0x13d5b27 <.text+0x370e07>
 10673c6: 83 c4 04                     	add	esp, 0x4
 10673c9: 8b 85 14 fe ff ff            	mov	eax, dword ptr [ebp - 0x1ec]
 10673cf: 50                           	push	eax
 10673d0: 89 bd 18 fe ff ff            	mov	dword ptr [ebp - 0x1e8], edi
 10673d6: 89 bd 1c fe ff ff            	mov	dword ptr [ebp - 0x1e4], edi
 10673dc: 89 bd 20 fe ff ff            	mov	dword ptr [ebp - 0x1e0], edi
 10673e2: e8 40 e7 36 00               	call	0x13d5b27 <.text+0x370e07>
 10673e7: bb 08 00 00 00               	mov	ebx, 0x8
 10673ec: 83 c4 04                     	add	esp, 0x4
 10673ef: 89 bd 14 fe ff ff            	mov	dword ptr [ebp - 0x1ec], edi
 10673f5: 39 5d 88                     	cmp	dword ptr [ebp - 0x78], ebx
 10673f8: 72 0f                        	jb	0x1067409 <.text+0x26e9>
 10673fa: 8b 8d 74 ff ff ff            	mov	ecx, dword ptr [ebp - 0x8c]
 1067400: 51                           	push	ecx
 1067401: e8 21 e7 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067406: 83 c4 04                     	add	esp, 0x4
 1067409: 8b 85 70 ff ff ff            	mov	eax, dword ptr [ebp - 0x90]
 106740f: 33 d2                        	xor	edx, edx
 1067411: be 07 00 00 00               	mov	esi, 0x7
 1067416: 50                           	push	eax
 1067417: 89 75 88                     	mov	dword ptr [ebp - 0x78], esi
 106741a: 89 7d 84                     	mov	dword ptr [ebp - 0x7c], edi
 106741d: 66 89 95 74 ff ff ff         	mov	word ptr [ebp - 0x8c], dx
 1067424: e8 fe e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067429: 83 c4 04                     	add	esp, 0x4
 106742c: 89 bd 70 ff ff ff            	mov	dword ptr [ebp - 0x90], edi
 1067432: 39 5d a8                     	cmp	dword ptr [ebp - 0x58], ebx
 1067435: 72 0c                        	jb	0x1067443 <.text+0x2723>
 1067437: 8b 4d 94                     	mov	ecx, dword ptr [ebp - 0x6c]
 106743a: 51                           	push	ecx
 106743b: e8 e7 e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067440: 83 c4 04                     	add	esp, 0x4
 1067443: 8b 45 90                     	mov	eax, dword ptr [ebp - 0x70]
 1067446: 33 d2                        	xor	edx, edx
 1067448: 50                           	push	eax
 1067449: 89 75 a8                     	mov	dword ptr [ebp - 0x58], esi
 106744c: 89 7d a4                     	mov	dword ptr [ebp - 0x5c], edi
 106744f: 66 89 55 94                  	mov	word ptr [ebp - 0x6c], dx
 1067453: e8 cf e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067458: 83 c4 04                     	add	esp, 0x4
 106745b: 89 7d 90                     	mov	dword ptr [ebp - 0x70], edi
 106745e: 39 5d c8                     	cmp	dword ptr [ebp - 0x38], ebx
 1067461: 72 0c                        	jb	0x106746f <.text+0x274f>
 1067463: 8b 4d b4                     	mov	ecx, dword ptr [ebp - 0x4c]
 1067466: 51                           	push	ecx
 1067467: e8 bb e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 106746c: 83 c4 04                     	add	esp, 0x4
 106746f: 8b 45 b0                     	mov	eax, dword ptr [ebp - 0x50]
 1067472: 33 d2                        	xor	edx, edx
 1067474: 50                           	push	eax
 1067475: 89 75 c8                     	mov	dword ptr [ebp - 0x38], esi
 1067478: 89 7d c4                     	mov	dword ptr [ebp - 0x3c], edi
 106747b: 66 89 55 b4                  	mov	word ptr [ebp - 0x4c], dx
 106747f: e8 a3 e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067484: 8b 8d ec fd ff ff            	mov	ecx, dword ptr [ebp - 0x214]
 106748a: 8b 95 2c fe ff ff            	mov	edx, dword ptr [ebp - 0x1d4]
 1067490: 89 7d b0                     	mov	dword ptr [ebp - 0x50], edi
 1067493: 83 c4 04                     	add	esp, 0x4
 1067496: 89 0a                        	mov	dword ptr [edx], ecx
 1067498: 39 5d 20                     	cmp	dword ptr [ebp + 0x20], ebx
 106749b: 72 0c                        	jb	0x10674a9 <.text+0x2789>
 106749d: 8b 45 0c                     	mov	eax, dword ptr [ebp + 0xc]
 10674a0: 50                           	push	eax
 10674a1: e8 81 e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 10674a6: 83 c4 04                     	add	esp, 0x4
 10674a9: 8b 55 08                     	mov	edx, dword ptr [ebp + 0x8]
 10674ac: 33 c9                        	xor	ecx, ecx
 10674ae: 52                           	push	edx
 10674af: 89 75 20                     	mov	dword ptr [ebp + 0x20], esi
 10674b2: 89 7d 1c                     	mov	dword ptr [ebp + 0x1c], edi
 10674b5: 66 89 4d 0c                  	mov	word ptr [ebp + 0xc], cx
 10674b9: e8 69 e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 10674be: 83 c4 04                     	add	esp, 0x4
 10674c1: e9 91 07 00 00               	jmp	0x1067c57 <.text+0x2f37>
 10674c6: 8b 85 f8 fd ff ff            	mov	eax, dword ptr [ebp - 0x208]
 10674cc: 89 47 24                     	mov	dword ptr [edi + 0x24], eax
 10674cf: 80 7d 28 00                  	cmp	byte ptr [ebp + 0x28], 0x0
 10674d3: 0f 84 1f 01 00 00            	je	0x10675f8 <.text+0x28d8>
 10674d9: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 10674df: e8 fc d0 ff ff               	call	0x10645e0
 10674e4: 8b 85 18 fe ff ff            	mov	eax, dword ptr [ebp - 0x1e8]
 10674ea: 33 f6                        	xor	esi, esi
 10674ec: 3b c6                        	cmp	eax, esi
 10674ee: 74 09                        	je	0x10674f9 <.text+0x27d9>
 10674f0: 50                           	push	eax
 10674f1: e8 31 e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 10674f6: 83 c4 04                     	add	esp, 0x4
 10674f9: 8b 8d 14 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1ec]
 10674ff: 51                           	push	ecx
 1067500: 89 b5 18 fe ff ff            	mov	dword ptr [ebp - 0x1e8], esi
 1067506: 89 b5 1c fe ff ff            	mov	dword ptr [ebp - 0x1e4], esi
 106750c: 89 b5 20 fe ff ff            	mov	dword ptr [ebp - 0x1e0], esi
 1067512: e8 10 e6 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067517: bb 08 00 00 00               	mov	ebx, 0x8
 106751c: 83 c4 04                     	add	esp, 0x4
 106751f: 89 b5 14 fe ff ff            	mov	dword ptr [ebp - 0x1ec], esi
 1067525: 39 5d 88                     	cmp	dword ptr [ebp - 0x78], ebx
 1067528: 72 0f                        	jb	0x1067539 <.text+0x2819>
 106752a: 8b 95 74 ff ff ff            	mov	edx, dword ptr [ebp - 0x8c]
 1067530: 52                           	push	edx
 1067531: e8 f1 e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067536: 83 c4 04                     	add	esp, 0x4
 1067539: 8b 8d 70 ff ff ff            	mov	ecx, dword ptr [ebp - 0x90]
 106753f: 33 c0                        	xor	eax, eax
 1067541: bf 07 00 00 00               	mov	edi, 0x7
 1067546: 51                           	push	ecx
 1067547: 89 7d 88                     	mov	dword ptr [ebp - 0x78], edi
 106754a: 89 75 84                     	mov	dword ptr [ebp - 0x7c], esi
 106754d: 66 89 85 74 ff ff ff         	mov	word ptr [ebp - 0x8c], ax
 1067554: e8 ce e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067559: 83 c4 04                     	add	esp, 0x4
 106755c: 89 b5 70 ff ff ff            	mov	dword ptr [ebp - 0x90], esi
 1067562: 39 5d a8                     	cmp	dword ptr [ebp - 0x58], ebx
 1067565: 72 0c                        	jb	0x1067573 <.text+0x2853>
 1067567: 8b 55 94                     	mov	edx, dword ptr [ebp - 0x6c]
 106756a: 52                           	push	edx
 106756b: e8 b7 e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067570: 83 c4 04                     	add	esp, 0x4
 1067573: 8b 4d 90                     	mov	ecx, dword ptr [ebp - 0x70]
 1067576: 33 c0                        	xor	eax, eax
 1067578: 51                           	push	ecx
 1067579: 89 7d a8                     	mov	dword ptr [ebp - 0x58], edi
 106757c: 89 75 a4                     	mov	dword ptr [ebp - 0x5c], esi
 106757f: 66 89 45 94                  	mov	word ptr [ebp - 0x6c], ax
 1067583: e8 9f e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067588: 83 c4 04                     	add	esp, 0x4
 106758b: 89 75 90                     	mov	dword ptr [ebp - 0x70], esi
 106758e: 39 5d c8                     	cmp	dword ptr [ebp - 0x38], ebx
 1067591: 72 0c                        	jb	0x106759f <.text+0x287f>
 1067593: 8b 55 b4                     	mov	edx, dword ptr [ebp - 0x4c]
 1067596: 52                           	push	edx
 1067597: e8 8b e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 106759c: 83 c4 04                     	add	esp, 0x4
 106759f: 8b 4d b0                     	mov	ecx, dword ptr [ebp - 0x50]
 10675a2: 33 c0                        	xor	eax, eax
 10675a4: 51                           	push	ecx
 10675a5: 89 7d c8                     	mov	dword ptr [ebp - 0x38], edi
 10675a8: 89 75 c4                     	mov	dword ptr [ebp - 0x3c], esi
 10675ab: 66 89 45 b4                  	mov	word ptr [ebp - 0x4c], ax
 10675af: e8 73 e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 10675b4: 8b 95 ec fd ff ff            	mov	edx, dword ptr [ebp - 0x214]
 10675ba: 8b 85 2c fe ff ff            	mov	eax, dword ptr [ebp - 0x1d4]
 10675c0: 89 75 b0                     	mov	dword ptr [ebp - 0x50], esi
 10675c3: 83 c4 04                     	add	esp, 0x4
 10675c6: 89 10                        	mov	dword ptr [eax], edx
 10675c8: 39 5d 20                     	cmp	dword ptr [ebp + 0x20], ebx
 10675cb: 72 0c                        	jb	0x10675d9 <.text+0x28b9>
 10675cd: 8b 4d 0c                     	mov	ecx, dword ptr [ebp + 0xc]
 10675d0: 51                           	push	ecx
 10675d1: e8 51 e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 10675d6: 83 c4 04                     	add	esp, 0x4
 10675d9: 8b 45 08                     	mov	eax, dword ptr [ebp + 0x8]
 10675dc: 33 d2                        	xor	edx, edx
 10675de: 50                           	push	eax
 10675df: 89 7d 20                     	mov	dword ptr [ebp + 0x20], edi
 10675e2: 89 75 1c                     	mov	dword ptr [ebp + 0x1c], esi
 10675e5: 66 89 55 0c                  	mov	word ptr [ebp + 0xc], dx
 10675e9: e8 39 e5 36 00               	call	0x13d5b27 <.text+0x370e07>
 10675ee: 83 c4 04                     	add	esp, 0x4
 10675f1: b0 01                        	mov	al, 0x1
 10675f3: e9 61 06 00 00               	jmp	0x1067c59 <.text+0x2f39>
 10675f8: 33 f6                        	xor	esi, esi
 10675fa: 6a 08                        	push	0x8
 10675fc: 89 b5 4c fe ff ff            	mov	dword ptr [ebp - 0x1b4], esi
 1067602: e8 13 f5 36 00               	call	0x13d6b1a <.text+0x371dfa>
 1067607: 83 c4 04                     	add	esp, 0x4
 106760a: 3b c6                        	cmp	eax, esi
 106760c: 0f 84 73 02 00 00            	je	0x1067885 <.text+0x2b65>
 1067612: 89 85 4c fe ff ff            	mov	dword ptr [ebp - 0x1b4], eax
 1067618: 33 c9                        	xor	ecx, ecx
 106761a: 89 08                        	mov	dword ptr [eax], ecx
 106761c: 33 d2                        	xor	edx, edx
 106761e: 89 50 04                     	mov	dword ptr [eax + 0x4], edx
 1067621: 8b 95 4c fe ff ff            	mov	edx, dword ptr [ebp - 0x1b4]
 1067627: 8d 8d 4c fe ff ff            	lea	ecx, [ebp - 0x1b4]
 106762d: 89 0a                        	mov	dword ptr [edx], ecx
 106762f: 33 c0                        	xor	eax, eax
 1067631: c7 85 64 fe ff ff 07 00 00 00	mov	dword ptr [ebp - 0x19c], 0x7
 106763b: 89 b5 60 fe ff ff            	mov	dword ptr [ebp - 0x1a0], esi
 1067641: 66 89 85 50 fe ff ff         	mov	word ptr [ebp - 0x1b0], ax
 1067648: 8b b5 48 fe ff ff            	mov	esi, dword ptr [ebp - 0x1b8]
 106764e: 83 7e 1c 08                  	cmp	dword ptr [esi + 0x1c], 0x8
 1067652: c6 45 fc 29                  	mov	byte ptr [ebp - 0x4], 0x29
 1067656: 72 05                        	jb	0x106765d <.text+0x293d>
 1067658: 8b 46 08                     	mov	eax, dword ptr [esi + 0x8]
 106765b: eb 03                        	jmp	0x1067660 <.text+0x2940>
 106765d: 8d 46 08                     	lea	eax, [esi + 0x8]
 1067660: 50                           	push	eax
 1067661: 68 28 e1 56 01               	push	0x156e128
 1067666: e8 85 88 13 00               	call	0x119fef0 <.text+0x13b1d0>
 106766b: 83 c4 04                     	add	esp, 0x4
 106766e: 50                           	push	eax
 106766f: 8d 8d 4c fe ff ff            	lea	ecx, [ebp - 0x1b4]
 1067675: 51                           	push	ecx
 1067676: e8 a5 d6 1b 00               	call	0x1224d20 <.text+0x1c0000>
 106767b: 83 c6 2c                     	add	esi, 0x2c
 106767e: 83 c4 0c                     	add	esp, 0xc
 1067681: 8d 95 08 fe ff ff            	lea	edx, [ebp - 0x1f8]
 1067687: 52                           	push	edx
 1067688: 8b ce                        	mov	ecx, esi
 106768a: 89 b5 f4 fd ff ff            	mov	dword ptr [ebp - 0x20c], esi
 1067690: e8 3b 98 16 00               	call	0x11d0ed0 <.text+0x16c1b0>
 1067695: 8b bd 10 fe ff ff            	mov	edi, dword ptr [ebp - 0x1f0]
 106769b: 8b 9d 08 fe ff ff            	mov	ebx, dword ptr [ebp - 0x1f8]
 10676a1: 8d 85 48 fd ff ff            	lea	eax, [ebp - 0x2b8]
 10676a7: 50                           	push	eax
 10676a8: 8b ce                        	mov	ecx, esi
 10676aa: e8 e1 80 74 ff               	call	0x7af790
 10676af: 85 db                        	test	ebx, ebx
 10676b1: 0f 84 52 f9 ff ff            	je	0x1067009 <.text+0x22e9>
 10676b7: 8b 13                        	mov	edx, dword ptr [ebx]
 10676b9: 33 f6                        	xor	esi, esi
 10676bb: 3b d6                        	cmp	edx, esi
 10676bd: 0f 84 46 f9 ff ff            	je	0x1067009 <.text+0x22e9>
 10676c3: 8b 08                        	mov	ecx, dword ptr [eax]
 10676c5: 3b ce                        	cmp	ecx, esi
 10676c7: 75 04                        	jne	0x10676cd <.text+0x29ad>
 10676c9: 33 c9                        	xor	ecx, ecx
 10676cb: eb 02                        	jmp	0x10676cf <.text+0x29af>
 10676cd: 8b 09                        	mov	ecx, dword ptr [ecx]
 10676cf: 3b d1                        	cmp	edx, ecx
 10676d1: 0f 85 32 f9 ff ff            	jne	0x1067009 <.text+0x22e9>
 10676d7: 3b 78 08                     	cmp	edi, dword ptr [eax + 0x8]
 10676da: 0f 94 c0                     	sete	al
 10676dd: 84 c0                        	test	al, al
 10676df: 0f 94 c0                     	sete	al
 10676e2: 84 c0                        	test	al, al
 10676e4: 0f 84 13 01 00 00            	je	0x10677fd <.text+0x2add>
 10676ea: 8b c2                        	mov	eax, edx
 10676ec: 3b c6                        	cmp	eax, esi
 10676ee: 0f 84 15 f9 ff ff            	je	0x1067009 <.text+0x22e9>
 10676f4: 3b fe                        	cmp	edi, esi
 10676f6: 0f 84 0d f9 ff ff            	je	0x1067009 <.text+0x22e9>
 10676fc: 3b 78 04                     	cmp	edi, dword ptr [eax + 0x4]
 10676ff: 0f 84 04 f9 ff ff            	je	0x1067009 <.text+0x22e9>
 1067705: 8b 4f 28                     	mov	ecx, dword ptr [edi + 0x28]
 1067708: e8 63 db 16 00               	call	0x11d5270 <.text+0x170550>
 106770d: 8b f0                        	mov	esi, eax
 106770f: 85 f6                        	test	esi, esi
 1067711: 74 1c                        	je	0x106772f <.text+0x2a0f>
 1067713: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1067716: 51                           	push	ecx
 1067717: 8b ce                        	mov	ecx, esi
 1067719: e8 12 7d 15 00               	call	0x11bf430 <.text+0x15a710>
 106771e: 83 8d 00 fe ff ff 01         	or	dword ptr [ebp - 0x200], 0x1
 1067725: 83 78 14 00                  	cmp	dword ptr [eax + 0x14], 0x0
 1067729: 74 04                        	je	0x106772f <.text+0x2a0f>
 106772b: b3 01                        	mov	bl, 0x1
 106772d: eb 02                        	jmp	0x1067731 <.text+0x2a11>
 106772f: 32 db                        	xor	bl, bl
 1067731: f6 85 00 fe ff ff 01         	test	byte ptr [ebp - 0x200], 0x1
 1067738: 74 39                        	je	0x1067773 <.text+0x2a53>
 106773a: 83 a5 00 fe ff ff fe         	and	dword ptr [ebp - 0x200], -0x2
 1067741: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 1067745: 72 0c                        	jb	0x1067753 <.text+0x2a33>
 1067747: 8b 55 d4                     	mov	edx, dword ptr [ebp - 0x2c]
 106774a: 52                           	push	edx
 106774b: e8 d7 e3 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067750: 83 c4 04                     	add	esp, 0x4
 1067753: 8b 4d d0                     	mov	ecx, dword ptr [ebp - 0x30]
 1067756: 33 c0                        	xor	eax, eax
 1067758: 51                           	push	ecx
 1067759: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 1067760: c7 45 e4 00 00 00 00         	mov	dword ptr [ebp - 0x1c], 0x0
 1067767: 66 89 45 d4                  	mov	word ptr [ebp - 0x2c], ax
 106776b: e8 b7 e3 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067770: 83 c4 04                     	add	esp, 0x4
 1067773: 84 db                        	test	bl, bl
 1067775: 74 60                        	je	0x10677d7 <.text+0x2ab7>
 1067777: 8d 55 d0                     	lea	edx, [ebp - 0x30]
 106777a: 52                           	push	edx
 106777b: 8b ce                        	mov	ecx, esi
 106777d: e8 ae 7c 15 00               	call	0x11bf430 <.text+0x15a710>
 1067782: 8b 8d 48 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1b8]
 1067788: 8b 51 24                     	mov	edx, dword ptr [ecx + 0x24]
 106778b: 56                           	push	esi
 106778c: 52                           	push	edx
 106778d: 50                           	push	eax
 106778e: 8d 85 4c fe ff ff            	lea	eax, [ebp - 0x1b4]
 1067794: 50                           	push	eax
 1067795: c6 45 fc 2a                  	mov	byte ptr [ebp - 0x4], 0x2a
 1067799: e8 42 39 01 00               	call	0x107b0e0 <.text+0x163c0>
 106779e: 83 c4 10                     	add	esp, 0x10
 10677a1: 83 7d e8 08                  	cmp	dword ptr [ebp - 0x18], 0x8
 10677a5: c6 45 fc 29                  	mov	byte ptr [ebp - 0x4], 0x29
 10677a9: 72 0c                        	jb	0x10677b7 <.text+0x2a97>
 10677ab: 8b 4d d4                     	mov	ecx, dword ptr [ebp - 0x2c]
 10677ae: 51                           	push	ecx
 10677af: e8 73 e3 36 00               	call	0x13d5b27 <.text+0x370e07>
 10677b4: 83 c4 04                     	add	esp, 0x4
 10677b7: 8b 45 d0                     	mov	eax, dword ptr [ebp - 0x30]
 10677ba: 33 d2                        	xor	edx, edx
 10677bc: 50                           	push	eax
 10677bd: c7 45 e8 07 00 00 00         	mov	dword ptr [ebp - 0x18], 0x7
 10677c4: c7 45 e4 00 00 00 00         	mov	dword ptr [ebp - 0x1c], 0x0
 10677cb: 66 89 55 d4                  	mov	word ptr [ebp - 0x2c], dx
 10677cf: e8 53 e3 36 00               	call	0x13d5b27 <.text+0x370e07>
 10677d4: 83 c4 04                     	add	esp, 0x4
 10677d7: 8b 8d 08 fe ff ff            	mov	ecx, dword ptr [ebp - 0x1f8]
 10677dd: 8b 01                        	mov	eax, dword ptr [ecx]
 10677df: 85 c0                        	test	eax, eax
 10677e1: 0f 84 22 f8 ff ff            	je	0x1067009 <.text+0x22e9>
 10677e7: 3b 78 04                     	cmp	edi, dword ptr [eax + 0x4]
 10677ea: 0f 84 19 f8 ff ff            	je	0x1067009 <.text+0x22e9>
 10677f0: 8b 3f                        	mov	edi, dword ptr [edi]
 10677f2: 8b b5 f4 fd ff ff            	mov	esi, dword ptr [ebp - 0x20c]
 10677f8: e9 9e fe ff ff               	jmp	0x106769b <.text+0x297b>
 10677fd: 8d 8d 4c fe ff ff            	lea	ecx, [ebp - 0x1b4]
 1067803: e8 e8 0d 3f ff               	call	0x4585f0
 1067808: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 106780e: e8 cd cd ff ff               	call	0x10645e0
 1067813: 8b 85 18 fe ff ff            	mov	eax, dword ptr [ebp - 0x1e8]
 1067819: 3b c6                        	cmp	eax, esi
 106781b: 74 09                        	je	0x1067826 <.text+0x2b06>
 106781d: 50                           	push	eax
 106781e: e8 04 e3 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067823: 83 c4 04                     	add	esp, 0x4
 1067826: 8b 95 14 fe ff ff            	mov	edx, dword ptr [ebp - 0x1ec]
 106782c: 52                           	push	edx
 106782d: 89 b5 18 fe ff ff            	mov	dword ptr [ebp - 0x1e8], esi
 1067833: 89 b5 1c fe ff ff            	mov	dword ptr [ebp - 0x1e4], esi
 1067839: 89 b5 20 fe ff ff            	mov	dword ptr [ebp - 0x1e0], esi
 106783f: e8 e3 e2 36 00               	call	0x13d5b27 <.text+0x370e07>
 1067844: 83 c4 04                     	add	esp, 0x4
 1067847: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
 106784d: 89 b5 14 fe ff ff            	mov	dword ptr [ebp - 0x1ec], esi
 1067853: e8 98 0d 3f ff               	call	0x4585f0
 1067858: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 106785b: e8 90 0d 3f ff               	call	0x4585f0
 1067860: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 1067863: e8 88 0d 3f ff               	call	0x4585f0
 1067868: 8b 85 ec fd ff ff            	mov	eax, dword ptr [ebp - 0x214]
 106786e: 8b 8d 2c fe ff ff            	mov	ecx, dword ptr [ebp - 0x1d4]
 1067874: 89 01                        	mov	dword ptr [ecx], eax
 1067876: 8d 4d 08                     	lea	ecx, [ebp + 0x8]
 1067879: e8 72 0d 3f ff               	call	0x4585f0
 106787e: b0 01                        	mov	al, 0x1
 1067880: e9 d4 03 00 00               	jmp	0x1067c59 <.text+0x2f39>
 1067885: 8d 95 d8 fd ff ff            	lea	edx, [ebp - 0x228]
 106788b: 52                           	push	edx
 106788c: 8d 8d 9c fd ff ff            	lea	ecx, [ebp - 0x264]
 1067892: 89 b5 d8 fd ff ff            	mov	dword ptr [ebp - 0x228], esi
 1067898: e8 2d ec 36 00               	call	0x13d64ca <.text+0x3717aa>
 106789d: 68 90 0f 91 01               	push	0x1910f90
 10678a2: 8d 85 9c fd ff ff            	lea	eax, [ebp - 0x264]
 10678a8: 50                           	push	eax
 10678a9: c7 85 9c fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x264], 0x1562084
 10678b3: e8 e2 f2 36 00               	call	0x13d6b9a <.text+0x371e7a>
 10678b8: 8d 8d 44 fe ff ff            	lea	ecx, [ebp - 0x1bc]
 10678be: 51                           	push	ecx
 10678bf: 8d 8d 90 fc ff ff            	lea	ecx, [ebp - 0x370]
 10678c5: 89 9d 44 fe ff ff            	mov	dword ptr [ebp - 0x1bc], ebx
 10678cb: e8 fa eb 36 00               	call	0x13d64ca <.text+0x3717aa>
 10678d0: 68 90 0f 91 01               	push	0x1910f90
 10678d5: 8d 95 90 fc ff ff            	lea	edx, [ebp - 0x370]
 10678db: 52                           	push	edx
 10678dc: c7 85 90 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x370], 0x1562084
 10678e6: e8 af f2 36 00               	call	0x13d6b9a <.text+0x371e7a>
 10678eb: 8d 85 54 fd ff ff            	lea	eax, [ebp - 0x2ac]
 10678f1: 50                           	push	eax
 10678f2: 8d 8d 0c fc ff ff            	lea	ecx, [ebp - 0x3f4]
 10678f8: 89 9d 54 fd ff ff            	mov	dword ptr [ebp - 0x2ac], ebx
 10678fe: e8 c7 eb 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067903: 68 90 0f 91 01               	push	0x1910f90
 1067908: 8d 8d 0c fc ff ff            	lea	ecx, [ebp - 0x3f4]
 106790e: 51                           	push	ecx
 106790f: c7 85 0c fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3f4], 0x1562084
 1067919: e8 7c f2 36 00               	call	0x13d6b9a <.text+0x371e7a>
 106791e: 68 6c 20 56 01               	push	0x156206c
 1067923: e8 a2 9e 35 00               	call	0x13c17ca <.text+0x35caaa>
 1067928: 8d 95 38 fe ff ff            	lea	edx, [ebp - 0x1c8]
 106792e: 52                           	push	edx
 106792f: 8d 8d 24 fc ff ff            	lea	ecx, [ebp - 0x3dc]
 1067935: 89 b5 38 fe ff ff            	mov	dword ptr [ebp - 0x1c8], esi
 106793b: e8 8a eb 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067940: 68 90 0f 91 01               	push	0x1910f90
 1067945: 8d 85 24 fc ff ff            	lea	eax, [ebp - 0x3dc]
 106794b: 50                           	push	eax
 106794c: c7 85 24 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3dc], 0x1562084
 1067956: e8 3f f2 36 00               	call	0x13d6b9a <.text+0x371e7a>
 106795b: 8d 8d 80 fd ff ff            	lea	ecx, [ebp - 0x280]
 1067961: 51                           	push	ecx
 1067962: 8d 8d 84 fc ff ff            	lea	ecx, [ebp - 0x37c]
 1067968: 89 b5 80 fd ff ff            	mov	dword ptr [ebp - 0x280], esi
 106796e: e8 57 eb 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067973: 68 90 0f 91 01               	push	0x1910f90
 1067978: 8d 95 84 fc ff ff            	lea	edx, [ebp - 0x37c]
 106797e: 52                           	push	edx
 106797f: c7 85 84 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x37c], 0x1562084
 1067989: e8 0c f2 36 00               	call	0x13d6b9a <.text+0x371e7a>
 106798e: 8d 85 90 fd ff ff            	lea	eax, [ebp - 0x270]
 1067994: 50                           	push	eax
 1067995: 8d 8d 6c fc ff ff            	lea	ecx, [ebp - 0x394]
 106799b: 89 9d 90 fd ff ff            	mov	dword ptr [ebp - 0x270], ebx
 10679a1: e8 24 eb 36 00               	call	0x13d64ca <.text+0x3717aa>
 10679a6: 68 90 0f 91 01               	push	0x1910f90
 10679ab: 8d 8d 6c fc ff ff            	lea	ecx, [ebp - 0x394]
 10679b1: 51                           	push	ecx
 10679b2: c7 85 6c fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x394], 0x1562084
 10679bc: e8 d9 f1 36 00               	call	0x13d6b9a <.text+0x371e7a>
 10679c1: 8d 95 60 fd ff ff            	lea	edx, [ebp - 0x2a0]
 10679c7: 52                           	push	edx
 10679c8: 8d 8d 60 fc ff ff            	lea	ecx, [ebp - 0x3a0]
 10679ce: 89 9d 60 fd ff ff            	mov	dword ptr [ebp - 0x2a0], ebx
 10679d4: e8 f1 ea 36 00               	call	0x13d64ca <.text+0x3717aa>
 10679d9: 68 90 0f 91 01               	push	0x1910f90
 10679de: 8d 85 60 fc ff ff            	lea	eax, [ebp - 0x3a0]
 10679e4: 50                           	push	eax
 10679e5: c7 85 60 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3a0], 0x1562084
 10679ef: e8 a6 f1 36 00               	call	0x13d6b9a <.text+0x371e7a>
 10679f4: 8d 8d 64 fd ff ff            	lea	ecx, [ebp - 0x29c]
 10679fa: 51                           	push	ecx
 10679fb: 8d 8d 48 fc ff ff            	lea	ecx, [ebp - 0x3b8]
 1067a01: 89 b5 64 fd ff ff            	mov	dword ptr [ebp - 0x29c], esi
 1067a07: e8 be ea 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067a0c: 68 90 0f 91 01               	push	0x1910f90
 1067a11: 8d 95 48 fc ff ff            	lea	edx, [ebp - 0x3b8]
 1067a17: 52                           	push	edx
 1067a18: c7 85 48 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3b8], 0x1562084
 1067a22: e8 73 f1 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067a27: 8d 85 98 fd ff ff            	lea	eax, [ebp - 0x268]
 1067a2d: 50                           	push	eax
 1067a2e: 8d 8d 30 fc ff ff            	lea	ecx, [ebp - 0x3d0]
 1067a34: 89 9d 98 fd ff ff            	mov	dword ptr [ebp - 0x268], ebx
 1067a3a: e8 8b ea 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067a3f: 68 90 0f 91 01               	push	0x1910f90
 1067a44: 8d 8d 30 fc ff ff            	lea	ecx, [ebp - 0x3d0]
 1067a4a: 51                           	push	ecx
 1067a4b: c7 85 30 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3d0], 0x1562084
 1067a55: e8 40 f1 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067a5a: 8d 95 78 fd ff ff            	lea	edx, [ebp - 0x288]
 1067a60: 52                           	push	edx
 1067a61: 8d 8d 18 fc ff ff            	lea	ecx, [ebp - 0x3e8]
 1067a67: 89 b5 78 fd ff ff            	mov	dword ptr [ebp - 0x288], esi
 1067a6d: e8 58 ea 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067a72: 68 90 0f 91 01               	push	0x1910f90
 1067a77: 8d 85 18 fc ff ff            	lea	eax, [ebp - 0x3e8]
 1067a7d: 50                           	push	eax
 1067a7e: c7 85 18 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3e8], 0x1562084
 1067a88: e8 0d f1 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067a8d: 8d 8d 88 fd ff ff            	lea	ecx, [ebp - 0x278]
 1067a93: 51                           	push	ecx
 1067a94: 8d 8d 00 fc ff ff            	lea	ecx, [ebp - 0x400]
 1067a9a: 89 9d 88 fd ff ff            	mov	dword ptr [ebp - 0x278], ebx
 1067aa0: e8 25 ea 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067aa5: 68 90 0f 91 01               	push	0x1910f90
 1067aaa: 8d 95 00 fc ff ff            	lea	edx, [ebp - 0x400]
 1067ab0: 52                           	push	edx
 1067ab1: c7 85 00 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x400], 0x1562084
 1067abb: e8 da f0 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067ac0: 8d 85 70 fd ff ff            	lea	eax, [ebp - 0x290]
 1067ac6: 50                           	push	eax
 1067ac7: 8d 8d e8 fb ff ff            	lea	ecx, [ebp - 0x418]
 1067acd: 89 9d 70 fd ff ff            	mov	dword ptr [ebp - 0x290], ebx
 1067ad3: e8 f2 e9 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067ad8: 68 90 0f 91 01               	push	0x1910f90
 1067add: 8d 8d e8 fb ff ff            	lea	ecx, [ebp - 0x418]
 1067ae3: 51                           	push	ecx
 1067ae4: c7 85 e8 fb ff ff 84 20 56 01	mov	dword ptr [ebp - 0x418], 0x1562084
 1067aee: e8 a7 f0 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067af3: 8d 95 94 fd ff ff            	lea	edx, [ebp - 0x26c]
 1067af9: 52                           	push	edx
 1067afa: 8d 8d 54 fc ff ff            	lea	ecx, [ebp - 0x3ac]
 1067b00: 89 9d 94 fd ff ff            	mov	dword ptr [ebp - 0x26c], ebx
 1067b06: e8 bf e9 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067b0b: 68 90 0f 91 01               	push	0x1910f90
 1067b10: 8d 85 54 fc ff ff            	lea	eax, [ebp - 0x3ac]
 1067b16: 50                           	push	eax
 1067b17: c7 85 54 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x3ac], 0x1562084
 1067b21: e8 74 f0 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067b26: 8d 8d 8c fd ff ff            	lea	ecx, [ebp - 0x274]
 1067b2c: 51                           	push	ecx
 1067b2d: 8d 8d 78 fc ff ff            	lea	ecx, [ebp - 0x388]
 1067b33: 89 b5 8c fd ff ff            	mov	dword ptr [ebp - 0x274], esi
 1067b39: e8 8c e9 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067b3e: 68 90 0f 91 01               	push	0x1910f90
 1067b43: 8d 95 78 fc ff ff            	lea	edx, [ebp - 0x388]
 1067b49: 52                           	push	edx
 1067b4a: c7 85 78 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x388], 0x1562084
 1067b54: e8 41 f0 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067b59: 8d 85 5c fd ff ff            	lea	eax, [ebp - 0x2a4]
 1067b5f: 50                           	push	eax
 1067b60: 8d 8d b4 fc ff ff            	lea	ecx, [ebp - 0x34c]
 1067b66: 89 b5 5c fd ff ff            	mov	dword ptr [ebp - 0x2a4], esi
 1067b6c: e8 59 e9 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067b71: 68 90 0f 91 01               	push	0x1910f90
 1067b76: 8d 8d b4 fc ff ff            	lea	ecx, [ebp - 0x34c]
 1067b7c: 51                           	push	ecx
 1067b7d: c7 85 b4 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x34c], 0x1562084
 1067b87: e8 0e f0 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067b8c: 8d 95 68 fd ff ff            	lea	edx, [ebp - 0x298]
 1067b92: 52                           	push	edx
 1067b93: 8d 8d a8 fc ff ff            	lea	ecx, [ebp - 0x358]
 1067b99: 89 b5 68 fd ff ff            	mov	dword ptr [ebp - 0x298], esi
 1067b9f: e8 26 e9 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067ba4: 68 90 0f 91 01               	push	0x1910f90
 1067ba9: 8d 85 a8 fc ff ff            	lea	eax, [ebp - 0x358]
 1067baf: 50                           	push	eax
 1067bb0: c7 85 a8 fc ff ff 84 20 56 01	mov	dword ptr [ebp - 0x358], 0x1562084
 1067bba: e8 db ef 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067bbf: 8d 8d 58 fd ff ff            	lea	ecx, [ebp - 0x2a8]
 1067bc5: 51                           	push	ecx
 1067bc6: 8d 8d f4 fb ff ff            	lea	ecx, [ebp - 0x40c]
 1067bcc: 89 bd 58 fd ff ff            	mov	dword ptr [ebp - 0x2a8], edi
 1067bd2: e8 f3 e8 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067bd7: 68 90 0f 91 01               	push	0x1910f90
 1067bdc: 8d 95 f4 fb ff ff            	lea	edx, [ebp - 0x40c]
 1067be2: 52                           	push	edx
 1067be3: c7 85 f4 fb ff ff 84 20 56 01	mov	dword ptr [ebp - 0x40c], 0x1562084
 1067bed: e8 a8 ef 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067bf2: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 1067bf8: e8 f3 09 3f ff               	call	0x4585f0
 1067bfd: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1067c00: e8 eb 09 3f ff               	call	0x4585f0
 1067c05: 8d 8d 50 ff ff ff            	lea	ecx, [ebp - 0xb0]
 1067c0b: e8 e0 09 3f ff               	call	0x4585f0
 1067c10: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 1067c16: e8 c5 c9 ff ff               	call	0x10645e0
 1067c1b: 8d 8d 14 fe ff ff            	lea	ecx, [ebp - 0x1ec]
 1067c21: e8 ea 56 70 ff               	call	0x76d310
 1067c26: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
 1067c2c: e8 bf 09 3f ff               	call	0x4585f0
 1067c31: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1067c34: e8 b7 09 3f ff               	call	0x4585f0
 1067c39: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 1067c3c: e8 af 09 3f ff               	call	0x4585f0
 1067c41: 8b 95 ec fd ff ff            	mov	edx, dword ptr [ebp - 0x214]
 1067c47: 8b 85 2c fe ff ff            	mov	eax, dword ptr [ebp - 0x1d4]
 1067c4d: 89 10                        	mov	dword ptr [eax], edx
 1067c4f: 8d 4d 08                     	lea	ecx, [ebp + 0x8]
 1067c52: e8 99 09 3f ff               	call	0x4585f0
 1067c57: 32 c0                        	xor	al, al
 1067c59: 8b 4d f4                     	mov	ecx, dword ptr [ebp - 0xc]
 1067c5c: 64 89 0d 00 00 00 00         	mov	dword ptr fs:[0x0], ecx
 1067c63: 59                           	pop	ecx
 1067c64: 5f                           	pop	edi
 1067c65: 5e                           	pop	esi
 1067c66: 5b                           	pop	ebx
 1067c67: 8b 4d f0                     	mov	ecx, dword ptr [ebp - 0x10]
 1067c6a: 33 cd                        	xor	ecx, ebp
 1067c6c: e8 67 f5 36 00               	call	0x13d71d8 <.text+0x3724b8>
 1067c71: 8b e5                        	mov	esp, ebp
 1067c73: 5d                           	pop	ebp
 1067c74: c2 28 00                     	ret	0x28
 1067c77: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 1067c7d: e8 6e 09 3f ff               	call	0x4585f0
 1067c82: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1067c85: e8 66 09 3f ff               	call	0x4585f0
 1067c8a: 8d 8d 50 ff ff ff            	lea	ecx, [ebp - 0xb0]
 1067c90: e8 5b 09 3f ff               	call	0x4585f0
 1067c95: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 1067c9b: e8 40 c9 ff ff               	call	0x10645e0
 1067ca0: 8d 8d 14 fe ff ff            	lea	ecx, [ebp - 0x1ec]
 1067ca6: e8 65 56 70 ff               	call	0x76d310
 1067cab: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
 1067cb1: e8 3a 09 3f ff               	call	0x4585f0
 1067cb6: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1067cb9: e8 32 09 3f ff               	call	0x4585f0
 1067cbe: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 1067cc1: e8 2a 09 3f ff               	call	0x4585f0
 1067cc6: 8b 8d ec fd ff ff            	mov	ecx, dword ptr [ebp - 0x214]
 1067ccc: 8b 95 2c fe ff ff            	mov	edx, dword ptr [ebp - 0x1d4]
 1067cd2: 89 0a                        	mov	dword ptr [edx], ecx
 1067cd4: e9 76 ff ff ff               	jmp	0x1067c4f <.text+0x2f2f>
 1067cd9: 8d 8d 30 ff ff ff            	lea	ecx, [ebp - 0xd0]
 1067cdf: e8 0c 09 3f ff               	call	0x4585f0
 1067ce4: 8d 4d d0                     	lea	ecx, [ebp - 0x30]
 1067ce7: e8 04 09 3f ff               	call	0x4585f0
 1067cec: 8d 8d 50 ff ff ff            	lea	ecx, [ebp - 0xb0]
 1067cf2: e8 f9 08 3f ff               	call	0x4585f0
 1067cf7: 8d 8d c4 fd ff ff            	lea	ecx, [ebp - 0x23c]
 1067cfd: e8 de c8 ff ff               	call	0x10645e0
 1067d02: 8d 8d 14 fe ff ff            	lea	ecx, [ebp - 0x1ec]
 1067d08: e8 03 56 70 ff               	call	0x76d310
 1067d0d: 8d 8d 70 ff ff ff            	lea	ecx, [ebp - 0x90]
 1067d13: e8 d8 08 3f ff               	call	0x4585f0
 1067d18: 8d 4d 90                     	lea	ecx, [ebp - 0x70]
 1067d1b: e8 d0 08 3f ff               	call	0x4585f0
 1067d20: 8d 4d b0                     	lea	ecx, [ebp - 0x50]
 1067d23: e8 c8 08 3f ff               	call	0x4585f0
 1067d28: 8b 85 ec fd ff ff            	mov	eax, dword ptr [ebp - 0x214]
 1067d2e: 8b 8d 2c fe ff ff            	mov	ecx, dword ptr [ebp - 0x1d4]
 1067d34: 89 01                        	mov	dword ptr [ecx], eax
 1067d36: e9 14 ff ff ff               	jmp	0x1067c4f <.text+0x2f2f>
 1067d3b: 8d 8d 04 fe ff ff            	lea	ecx, [ebp - 0x1fc]
 1067d41: 51                           	push	ecx
 1067d42: 8d 8d a8 fd ff ff            	lea	ecx, [ebp - 0x258]
 1067d48: 89 9d 04 fe ff ff            	mov	dword ptr [ebp - 0x1fc], ebx
 1067d4e: e8 77 e7 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067d53: 68 90 0f 91 01               	push	0x1910f90
 1067d58: 8d 95 a8 fd ff ff            	lea	edx, [ebp - 0x258]
 1067d5e: 52                           	push	edx
 1067d5f: c7 85 a8 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x258], 0x1562084
 1067d69: e8 2c ee 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067d6e: 8d 85 fc fd ff ff            	lea	eax, [ebp - 0x204]
 1067d74: 50                           	push	eax
 1067d75: 8d 8d b8 fd ff ff            	lea	ecx, [ebp - 0x248]
 1067d7b: 89 9d fc fd ff ff            	mov	dword ptr [ebp - 0x204], ebx
 1067d81: e8 44 e7 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067d86: 68 90 0f 91 01               	push	0x1910f90
 1067d8b: 8d 8d b8 fd ff ff            	lea	ecx, [ebp - 0x248]
 1067d91: 51                           	push	ecx
 1067d92: c7 85 b8 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x248], 0x1562084
 1067d9c: e8 f9 ed 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067da1: 8d 95 04 fe ff ff            	lea	edx, [ebp - 0x1fc]
 1067da7: 52                           	push	edx
 1067da8: 8d 8d a8 fd ff ff            	lea	ecx, [ebp - 0x258]
 1067dae: 89 9d 04 fe ff ff            	mov	dword ptr [ebp - 0x1fc], ebx
 1067db4: e8 11 e7 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067db9: 68 90 0f 91 01               	push	0x1910f90
 1067dbe: 8d 85 a8 fd ff ff            	lea	eax, [ebp - 0x258]
 1067dc4: 50                           	push	eax
 1067dc5: c7 85 a8 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x258], 0x1562084
 1067dcf: e8 c6 ed 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067dd4: 8d 8d fc fd ff ff            	lea	ecx, [ebp - 0x204]
 1067dda: 51                           	push	ecx
 1067ddb: 8d 8d b8 fd ff ff            	lea	ecx, [ebp - 0x248]
 1067de1: 89 9d fc fd ff ff            	mov	dword ptr [ebp - 0x204], ebx
 1067de7: e8 de e6 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067dec: 68 90 0f 91 01               	push	0x1910f90
 1067df1: 8d 95 b8 fd ff ff            	lea	edx, [ebp - 0x248]
 1067df7: 52                           	push	edx
 1067df8: c7 85 b8 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x248], 0x1562084
 1067e02: e8 93 ed 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067e07: 8d 85 04 fe ff ff            	lea	eax, [ebp - 0x1fc]
 1067e0d: 50                           	push	eax
 1067e0e: 8d 8d a8 fd ff ff            	lea	ecx, [ebp - 0x258]
 1067e14: 89 9d 04 fe ff ff            	mov	dword ptr [ebp - 0x1fc], ebx
 1067e1a: e8 ab e6 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067e1f: 68 90 0f 91 01               	push	0x1910f90
 1067e24: 8d 8d a8 fd ff ff            	lea	ecx, [ebp - 0x258]
 1067e2a: 51                           	push	ecx
 1067e2b: c7 85 a8 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x258], 0x1562084
 1067e35: e8 60 ed 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067e3a: 8d 95 fc fd ff ff            	lea	edx, [ebp - 0x204]
 1067e40: 52                           	push	edx
 1067e41: 8d 8d b8 fd ff ff            	lea	ecx, [ebp - 0x248]
 1067e47: 89 9d fc fd ff ff            	mov	dword ptr [ebp - 0x204], ebx
 1067e4d: e8 78 e6 36 00               	call	0x13d64ca <.text+0x3717aa>
 1067e52: 68 90 0f 91 01               	push	0x1910f90
 1067e57: 8d 85 b8 fd ff ff            	lea	eax, [ebp - 0x248]
 1067e5d: 50                           	push	eax
 1067e5e: c7 85 b8 fd ff ff 84 20 56 01	mov	dword ptr [ebp - 0x248], 0x1562084
 1067e68: e8 2d ed 36 00               	call	0x13d6b9a <.text+0x371e7a>
 1067e6d: 8d 49 00                     	lea	ecx, [ecx]
 1067e70: 97                           	xchg	eax, edi
 1067e71: 58                           	pop	eax
 1067e72: 06                           	push	es
 1067e73: 01 d9                        	add	ecx, ebx
 1067e75: 58                           	pop	eax
 1067e76: 06                           	push	es
 1067e77: 01 1b                        	add	dword ptr [ebx], ebx
 1067e79: 59                           	pop	ecx
 1067e7a: 06                           	push	es
 1067e7b: 01 5d 59                     	add	dword ptr [ebp + 0x59], ebx
 1067e7e: 06                           	push	es
 1067e7f: 01 d9                        	add	ecx, ebx
 1067e81: 66 06                        	push	es
 1067e83: 01 00                        	add	dword ptr [eax], eax
 1067e85: 04 04                        	add	al, 0x4
 1067e87: 04 04                        	add	al, 0x4
 1067e89: 04 04                        	add	al, 0x4
 1067e8b: 04 04                        	add	al, 0x4
 1067e8d: 04 04                        	add	al, 0x4
 1067e8f: 04 04                        	add	al, 0x4
 1067e91: 04 01                        	add	al, 0x1
 1067e93: 04 04                        	add	al, 0x4
 1067e95: 04 04                        	add	al, 0x4
 1067e97: 04 04                        	add	al, 0x4
 1067e99: 04 04                        	add	al, 0x4
 1067e9b: 02 04 04                     	add	al, byte ptr [esp + eax]
 1067e9e: 04 04                        	add	al, 0x4
 1067ea0: 04 04                        	add	al, 0x4
 1067ea2: 04 04                        	add	al, 0x4
 1067ea4: 04 04                        	add	al, 0x4
 1067ea6: 04 04                        	add	al, 0x4
 1067ea8: 04 04                        	add	al, 0x4
 1067eaa: 04 04                        	add	al, 0x4
 1067eac: 04 04                        	add	al, 0x4
 1067eae: 04 04                        	add	al, 0x4
 1067eb0: 04 04                        	add	al, 0x4
 1067eb2: 04 03                        	add	al, 0x3
 1067eb4: cc                           	int3
 1067eb5: cc                           	int3
 1067eb6: cc                           	int3
 1067eb7: cc                           	int3
 1067eb8: cc                           	int3
 1067eb9: cc                           	int3
 1067eba: cc                           	int3
 1067ebb: cc                           	int3
 1067ebc: cc                           	int3
 1067ebd: cc                           	int3
 1067ebe: cc                           	int3
 1067ebf: cc                           	int3
