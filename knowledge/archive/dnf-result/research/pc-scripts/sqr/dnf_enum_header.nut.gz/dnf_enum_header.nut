// 带颇家胶郴 enum蔼阑 squirrel script俊辑档 荤侩窍扁 困秦 函券秦初篮 蔼甸涝聪促. 
// 鉴荐 胶农赋飘肺 累诀窍搁辑 眠啊秦具且 蔼甸捞 乐促搁.. 阿 流诀_header.nut颇老俊 火涝秦林技夸.. 捞镑俊 眠啊陛瘤

LANDTYPE_GRASS <- 0 
LANDTYPE_WETGRASS <- 1 
LANDTYPE_SWAMP <- 2 
LANDTYPE_POISONSWAMP <- 3 
LANDTYPE_BROWNDIRT <- 4 
LANDTYPE_BLUEDIRT <- 5 
LANDTYPE_BONEYARD <- 6 
LANDTYPE_WATER <- 7 
LANDTYPE_MAGMA <- 8 
LANDTYPE_SNOW <- 9 
LANDTYPE_RED_SWAMP <- 10 
LANDTYPE_PURPLE_POISONSWAMP <- 11 
LANDPARTICLE_DOWNLARGE <- 0 
LANDPARTICLE_DOWNSMALL <- 1 
LANDPARTICLE_MOVE <- 2 
LANDSOUND_JUMPSTART <- 0 
LANDSOUND_JUMPLAND <- 1 
LANDSOUND_MOVE <- 2 
LANDSOUND_DASH <- 3 
LANDSOUND_BACKSTEP <- 4 
LANDSOUND_FASTTHROUGH <- 5 

CATEGORY_TRIBE_HUMAN <- 0 
CATEGORY_TRIBE_BEAST <- 1 
CATEGORY_TRIBE_PLANT <- 2 
CATEGORY_TRIBE_INSECT <- 3 
CATEGORY_TRIBE_MACHINE <- 4 
CATEGORY_TRIBE_ORGANIC <- 5 
CATEGORY_TRIBE_HYBRID <- 6 
CATEGORY_TRIBE_UNDEAD <- 7 
CATEGORY_TRIBE_DEVIL <- 8 
CATEGORY_TRIBE_SPIRIT <- 9 
CATEGORY_TRIBE_DRAGON <- 10 
CATEGORY_AI_MELEE_ATTACK <- 11 
CATEGORY_AI_RANGE_ATTACK <- 12 
CATEGORY_AI_NEGATIVE <- 13 
CATEGORY_AI_CAREFUL <- 14 
CATEGORY_AI_FULLSUPERARMOR <- 15 
CATEGORY_AI_RASH <- 16 
CATEGORY_AI_MANACE <- 17 
CATEGORY_ARMOR_HUMAN <- 18 
CATEGORY_ARMOR_FORT <- 19 
CATEGORY_ARMOR_DIVINE <- 20 
CATEGORY_ETC_GOBLIN <- 21 
CATEGORY_ETC_TAU <- 22 
CATEGORY_ETC_LUGARU <- 23 
CATEGORY_ETC_FIXTURE <- 24 
CATEGORY_ETC_STAY <- 25 
CATEGORY_PASSIVEOBJECT_TYPE_MELEE <- 26 
CATEGORY_PASSIVEOBJECT_TYPE_MISSILE <- 27 
CATEGORY_PASSIVEOBJECT_TYPE_ENERGY <- 28 
CATEGORY_PASSIVEOBJECT_TYPE_PHYSICAL <- 29 
CATEGORY_PASSIVEOBJECT_TYPE_MAGICAL <- 30 
CATEGORY_PASSIVEOBJECT_TYPE_BULLET <- 31 
CATEGORY_PASSIVEOBJECT_TYPE_CANON <- 32 
CATEGORY_PASSIVEOBJECT_TYPE_EXPLOSION <- 33 
CATEGORY_PASSIVEOBJECT_TYPE_INFLAME <- 34 
CATEGORY_PASSIVEOBJECT_TYPE_NONINFLAME <- 35 
CATEGORY_PASSIVEOBJECT_TYPE_LIGHT <- 36 
CATEGORY_PASSIVEOBJECT_TYPE_DARK <- 37 
CATEGORY_PASSIVEOBJECT_TYPE_WATER <- 38 
CATEGORY_PASSIVEOBJECT_TYPE_FIRE <- 39 
CATEGORY_PASSIVEOBJECT_TYPE_FORT <- 40 
CATEGORY_ETC_UNBEATABLE <- 41 
CATEGORY_TRIBE_ANGEL <- 42 
CATEGORY_MAX <- 43 

DOWN_PARAM_TYPE_VALUE <- 0 
DOWN_PARAM_TYPE_FORCE <- 1 
DOWN_PARAM_TYPE_BOUNCE_VALUE <- 2 
DOWN_PARAM_TYPE_BOUNCE_FORCE <- 3 
DOWN_PARAM_TYPE_BOUNCE <- 4 

ENUM_DIRECTION_LEFT <- 0 
ENUM_DIRECTION_RIGHT <- 1 
ENUM_DIRECTION_UP <- 2 
ENUM_DIRECTION_DOWN <- 3 
ENUM_DIRECTION_NEUTRAL <- 4 
ENUM_DIRECTION_MAX <- 5 

GRAPHICEFFECT_NONE <- 0 
GRAPHICEFFECT_DODGE <- 1 
GRAPHICEFFECT_LINEARDODGE <- 2 
GRAPHICEFFECT_DARK <- 3 
GRAPHICEFFECT_XOR <- 4 
GRAPHICEFFECT_MONOCHROME <- 5 
GRAPHICEFFECT_SPACE_DISTORT <- 6 
GRAPHICEFFECT_MAX <- 7 

ENUM_DRAWLAYER_CONTACT <- 0 		  //  立版 饭捞绢
ENUM_DRAWLAYER_NORMAL <- 1 		  //  老馆 饭捞绢
ENUM_DRAWLAYER_BOTTOM <- 2 		  //  官蹿 饭捞绢
ENUM_DRAWLAYER_CLOSEBACK <- 3 		  //  辟版 饭捞绢
ENUM_DRAWLAYER_MIDDLEBACK <- 4 		  //  吝版 饭捞绢
ENUM_DRAWLAYER_DISTANTBACK <- 5 		  //  盔版 饭捞绢
ENUM_DRAWLAYER_COVER <- 6 		  //  拳搁阑 丹绰 饭捞绢 ex : Blind
ENUM_DRAWLAYER_MAX <- 7 

STATE_STAND <- 0 		  //  辑乐扁, 捞悼
STATE_SIT <- 1 		  //  旧扁 (老绢唱扁 傈)
STATE_SIT_FOREVER <- 2 		  //  旧酒乐扁
STATE_DAMAGE <- 3 		  //  嘎扁
STATE_DOWN <- 4 		  //  促款 
STATE_DIE <- 5 		  //  磷扁
STATE_JUMP <- 6 		  //  痢橇
STATE_JUMP_ATTACK <- 7 		  //  痢橇
STATE_ATTACK <- 8 		  //  傍拜
STATE_HOLD <- 9 		  //  悼累 阂瓷 惑怕
STATE_SUMMONSTART <- 10 		  //  家券 矫累
STATE_SUMMONEND <- 11 		  //  家券 肯丰
STATE_UNSUMMON <- 12 		  //  开家券登辑 荤扼咙
STATE_THROW <- 13 		  //  捧么
STATE_DASH <- 14 		  //  措浆 
STATE_DASH_ATTACK <- 15 		  //  措浆 绢琶
STATE_GET_ITEM <- 16 		  //  酒捞袍 凛扁
STATE_BUFF <- 17 		  //  滚橇
STATE_QUICK_STANDING <- 18 		  //  狞胶拍爹
STATE_CROUCH <- 19 		  //  农扼快摹
STATE_CROUCH_ATTACK <- 20 		  //  农扼快摹 绢柄摹扁
STATE_LOW_KICK <- 21 		  //  肺疟, 夯 农矾寂, 荤肺疟
STATE_TRY_GRAB <- 22 		  //  棱扁 矫档
STATE_SUPLEX <- 23 		  //  荐敲泛胶
STATE_JUMP_SUPLEX <- 24 		  //  胶颇捞绢
STATE_JUMP_SUPLEX_LARIAT <- 25 		  //  胶颇捞绢 雀傈 眠啊鸥
STATE_MOUNT_TRY <- 26 		  //  付款飘 矫档
STATE_MOUNT <- 27 		  //  付款飘
STATE_STOMP <- 28 		  //  光扁
STATE_CLOSE_PUNCH <- 29 		  //  盔牢摹 戚摹
STATE_LIFT_UPPER <- 30 		  //  公令 绢欺
STATE_GRAB_EXPLOSION <- 31 		  //  老惯拳距己
STATE_VIRTUAL_ATTACK <- 32 		  //  老馆 傍拜 -> 秦赣疟 殿阑 困茄 啊惑 STATE
STATE_SHOULDER_TACKLE <- 33 		  //  捡歹 怕努
STATE_WHIRL_WIND_KICK <- 34 		  //  急浅阿
STATE_BLOCK_BUSTER <- 35 		  //  喉废 滚胶磐
STATE_TRY_LEG_SUPLEX <- 36 		  //  俊绢酱鸥捞呈 矫档
STATE_LEG_SUPLEX <- 37 		  //  俊绢酱鸥捞呈 角青
STATE_LIGHTNING_DANCE <- 38 		  //  扼捞飘醋 错胶
STATE_THROW_WEB <- 39 		  //  玫扼瘤噶
STATE_HIDDEN_STING <- 40 		  //  官疵 厘傈(洒电胶泼)
STATE_VENOM_MINE <- 41 		  //  海仇付牢
STATE_JUNK_SPIN <- 42 		  //  沥农胶巧
STATE_SHOULDER_CHARGE <- 43 		  //  枚魂绊
STATE_SINGLE_KICK <- 44 		  //  秦赣疟
STATE_NEN_FLOWER <- 45 		  //  迟拳
STATE_THROW_ENEMY <- 46 		  //  肺敲傅
STATE_DASH_PUNCH <- 47 		  //  沥鼻 骂福扁
STATE_PUNCH_AFTER_RETURN <- 48 		  //  鸥拜饶 第肺倒府扁
STATE_RANDOM_KICK <- 49 		  //  归凯阿 抄鸥
STATE_RISING_UPPER <- 50 		  //  铰锋鼻
STATE_DASH_AFTER_DASH <- 51 		  //  龋脚楷拜
STATE_EARTH_BREAK <- 52 		  //  陛碍尖
STATE_HOLD_UP <- 53 		  //  圈靛诀
STATE_WILD_CANNON_SPIKE <- 54 		  //  客老靛 某稠 胶颇捞农
STATE_SUPLEX_CYCLONE <- 55 		  //  荐敲泛胶 荤捞努沸
STATE_LIGHTNING_DRAGON <- 56 		  //  堡面畴档
STATE_STRONGEST_LOW_KICK <- 57 		  //  荤惑 弥碍狼 肺疟
STATE_GROUND_KICK <- 58 		  //  弊扼款靛疟
STATE_FAST_DASH <- 59 		  //  鉴焊
STATE_DESTROY_EARTH_SKY_DROP <- 60 		  //  胶飘府飘 颇捞磐 阿己扁 - 玫贺瘤鲍
STATE_TYPHOON <- 61 		  //  弊贰敲矾 阿己扁
STATE_FLAME_LEGS <- 62 		  //  胶飘扼捞目 阿己扁 - 拳堪狼阿
STATE_THROW_SAND <- 63 		  //  秋磐胶盜磐
STATE_ENCHANT_POISON <- 64 		  //  刀厘傈
STATE_SPIRAL_NEN_SHOOT <- 65 		  //  唱急狼 迟 : 免
STATE_NEN_SPEAR_EX <- 66 		  //  迟 胶乔绢(漂己) proc俊辑 敲贰弊1俊 个 坷滚饭捞,拳搁 敲贰浆    敲贰弊2 俊 踩洒绰 绢奇叼瘤 家券 
STATE_HURRICANE_SPEAR <- 67 		  //  倾府纳牢 胶乔绢 (漂己)
STATE_CRASH_ROPE <- 68 		  //  堡气趋荤 (漂己)
STATE_CHARGE_SPEAR_EX <- 69 		  //  瞒瘤 胶乔绢(漂己)
STATE_SPIRAL_COLUMN_EX <- 70 		  //  唱急券(漂己)
STATE_GLUEY_FRUIT_EX <- 71 		  //  馋利馋利 凯概(漂己)
STATE_CHAIN_KICK_EX <- 72 		  //  楷券硼 (漂己)
STATE_108_STAIRS_EX <- 73 		  //  108拌窜 (漂己)
STATE_INHERIT_START <- 74 
STATE_MAX <- 75 

SKILL_SHOULDER_CHARGE <- 1 		  //  001.枚魂绊
SKILL_CROUCH <- 2 		  //  002.农扼快摹
SKILL_GRAB_EXPLOSION <- 3 		  //  003.老惯拳距己
SKILL_CRASH_LOW_KICK <- 4 		  //  004.夯 农矾寂
SKILL_LIFT_UPPER <- 5 		  //  005.公令 绢欺
SKILL_DAMAGE_LOW_KICK <- 6 		  //  006.肺疟
SKILL_PHYSICAL_DEFENSE_UP <- 7 		  //  007.枚陛碍
SKILL_CREATE_ILLUSION <- 8 		  //  008.盒脚
SKILL_SUPLEX <- 9 		  //  009.荐敲泛胶
SKILL_BACK_SUPLEX <- 10 		  //  010.归宏饭捞目
SKILL_THUNDER_SUPLEX <- 11 		  //  011.荐敲泛胶 姐歹
SKILL_ENERGY_BALL <- 12 		  //  012.迟藕
SKILL_THROW_SAND <- 13 		  //  013.秋磐 胶奶磐
SKILL_MOUNT <- 14 		  //  014.付款飘
SKILL_ROAR_STUN <- 15 		  //  015.荤磊饶
SKILL_ENERGY_FIELD <- 16 		  //  016.扁傍厘
SKILL_STOMP <- 17 		  //  017.傍吝 光扁
SKILL_JUMP_SUPLEX <- 18 		  //  018.胶颇捞绢
SKILL_CLOSE_PUNCH <- 19 		  //  019.盔牢摹 戚摹
SKILL_SUPER_ARMOR <- 20 		  //  020.酱欺酒赣
SKILL_CANCEL_ENERGY_BALL <- 21 		  //  021.牡浇 迟藕
SKILL_SUPLEX_SUB_POWER_UP <- 22 		  //  022.碍纺茄 抛捞农 促款
SKILL_CANCEL_LIFT_UPPER <- 23 		  //  023.牡浇 公令 绢欺
SKILL_CANCEL_LOW_KICK <- 24 		  //  024.牡浇 肺疟
SKILL_CANCEL_THROW_SAND <- 25 		  //  025.牡浇 秋磐 胶奶磐
SKILL_CANCEL_CLOSE_PUNCH <- 26 		  //  026.牡浇 盔牢摹 戚摹
SKILL_CANCEL_SUPLEX <- 27 		  //  027.牡浇 荐敲泛胶
SKILL_CANCEL_JUMP_SUPLEX <- 28 		  //  028.牡浇 胶颇捞绢
SKILL_LIGHT_FRIENDSHIP <- 29 		  //  029.蝴狼 模拳
SKILL_LIGHT_ENCHANT_WEAPON <- 30 		  //  030.墨捞
SKILL_ATTACK_SPEED_UP <- 31 		  //  031.劝己拳 见搬
SKILL_POISON_TOLERANCE_UP <- 32 		  //  032.刀俊 劳槛窃
SKILL_STUN_ON_USE_SKILL <- 33 		  //  033.林拳涝付
SKILL_EQUIP_BOXING_GLOVE <- 34 		  //  034.鼻捧臂矾宏 荤侩 啊瓷
SKILL_BLIND_TOLERANCE_UP <- 35 		  //  035.迟栏肺 蠢长促
SKILL_LIGHT_TOLERANCE_UP <- 36 		  //  036.怕剧狼 目瓢
SKILL_SLOW_DOWN_POWER_UP <- 37 		  //  037.碍鼻
SKILL_ENCHANT_POISON <- 38 		  //  038.刀 厘傈(刀官福扁)
SKILL_AIM_VITAL_POINT <- 39 		  //  039.鞭家 瘤沥
SKILL_SPIRAL_NEN <- 40 		  //  040.唱急狼 迟
SKILL_FLAME_LEGS <- 41 		  //  041.胶飘扼捞目 阿己扁 - 拳堪狼阿
SKILL_NEN_GUARD <- 42 		  //  042.迟啊靛
SKILL_DOUBLE_THROW <- 43 		  //  043.捞吝 捧么
SKILL_PROVOCATION <- 44 		  //  044.档惯
SKILL_CLAW_MASTERY <- 45 		  //  045.努肺 付胶磐府
SKILL_SINGLE_KICK <- 46 		  //  046.秦赣 疟
SKILL_CANCEL_SINGLE_KICK <- 47 		  //  047.牡浇 秦赣 疟
SKILL_CANCEL_GRAB_EXPLOSION <- 48 		  //  048.牡浇 老惯拳距己
SKILL_THROW_ENEMY <- 49 		  //  049.肺敲傅
SKILL_DEFINITE_GRAB <- 50 		  //  050.馆靛矫 棱绰促!
SKILL_SLIDE_GRAB <- 51 		  //  051.浇扼捞爹 弊乏
SKILL_THROW_WEB <- 52 		  //  052.玫扼瘤噶
SKILL_CANCEL_THROW_ENEMY <- 53 		  //  053.牡浇 肺敲傅
SKILL_SHOULDER_TACKLE <- 54 		  //  054.捡歹 怕努
SKILL_GRAB_CANNON <- 55 		  //  055.弊乏 某稠
SKILL_ARMOR_MASTERY_LIGHT_SK <- 56 		  //  056.逞摹绰 塞狼 版癌 付胶磐府
SKILL_ARMOR_MASTERY_LIGHT_GP <- 57 		  //  057.碍牢茄 辟己狼 版癌 付胶磐府
SKILL_WHIRL_WIND_KICK <- 58 		  //  058.龙浅阿
SKILL_CANCEL_WHIRL_WIND_KICK <- 59 		  //  059.牡浇 龙浅阿
SKILL_BLOCK_BUSTER <- 60 		  //  060.喉废 滚胶磐
SKILL_CANCEL_THROW <- 61 		  //  061.牡浇 捧么
SKILL_LEG_SUPLEX <- 62 		  //  062.俊绢酱鸥捞呈
SKILL_TYPHOON <- 63 		  //  063.弊贰敲矾 阿己扁
SKILL_DUMMY <- 64 		  //  064.荤侩窍瘤 臼澜.
SKILL_EFFICIENT_BURN <- 65 		  //  065.胶飘扼捞磐 阿己 菩矫宏 - 瓤啦利牢 楷家
SKILL_GRAB_MASTERY <- 66 		  //  066.棱扁 付胶磐府
SKILL_NEN_FLOWER <- 67 		  //  067.迟拳
SKILL_LIGHTNING_DANCE <- 68 		  //  068.扼捞飘醋 错胶
SKILL_ILLUSION_BOMB <- 69 		  //  069.券康气尖
SKILL_POWER_UP_ON_DASH <- 70 		  //  070.胶牌乔靛
SKILL_STRONGEST_LOW_KICK <- 71 		  //  071.荤惑弥碍狼 肺疟
SKILL_NEN_SHIELD <- 72 		  //  072.瑞朝府绰 玫堪拳
SKILL_ARMOR_MASTERY_HEAVY_SP <- 73 		  //  073.吝癌 付胶磐府
SKILL_CRAZY_MOUNT <- 74 		  //  074.瘤饿 付款飘
SKILL_HIDDEN_STING <- 75 		  //  075.洒电胶泼
SKILL_VENOM_MINE <- 76 		  //  076.海仇付牢
SKILL_JUNK_SPIN <- 77 		  //  077.沥农胶巧
SKILL_ENERGY_BALL_CHARGE <- 78 		  //  078.迟藕 葛酒筋扁
SKILL_NEN_MONSTER_WHITE_TIGER <- 79 		  //  079.迟荐 : 归龋
SKILL_DASH_PUNCH <- 80 		  //  080.沥鼻骂福扁
SKILL_PUNCH_AFTER_RETURN <- 81 		  //  081.鸥拜饶 第肺倒府扁
SKILL_RANDOM_KICK <- 82 		  //  082.归凯阿 抄鸥
SKILL_RISING_UPPER <- 83 		  //  083.铰锋鼻
SKILL_DASH_AFTER_DASH <- 84 		  //  084.龋脚楷拜
SKILL_DASH_AFTER_DASH_EXTENSION <- 85 		  //  085.龋器
SKILL_EARTH_BREAK <- 86 		  //  086.陛碍尖
SKILL_HOLD_UP <- 87 		  //  087.圈靛诀
SKILL_WILD_CANNON_SPIKE <- 88 		  //  088.客老靛 某稠 胶颇捞农
SKILL_SUPLEX_CYCLONE <- 89 		  //  089.荐敲泛胶 荤捞努沸
SKILL_LIGHTNING_DRAGON <- 90 		  //  090.堡面畴档
SKILL_MUSCLE_SHIFT <- 91 		  //  091.赣浇 矫橇飘	
SKILL_CANCEL_EARTH_BREAK <- 92 		  //  092.牡浇 陛碍尖
SKILL_CANCEL_DASH_PUNCH <- 93 		  //  093.牡浇 贺鼻
SKILL_CANCEL_SHOULDER_CHARGE <- 94 		  //  094.牡浇 枚魂绊
SKILL_CANCEL_PUNCH_AFTER_RETURN <- 95 		  //  095.牡浇 鸥拜饶 第肺倒府扁
SKILL_CANCEL_SUPLEX_CYCLONE <- 96 		  //  096.牡浇 荐敲泛胶 荤捞努沸
SKILL_ARMOR_MASTERY_CLOTH_NM <- 97 		  //  097.玫 付胶磐府:迟付胶磐
SKILL_CANCEL_NEN_GUARD <- 98 		  //  098.牡浇 迟啊靛
SKILL_CANCEL_ROAR_STUN <- 99 		  //  099.牡浇 荤磊饶
SKILL_CANCEL_ENERGY_FIELD <- 100 		  //  100.牡浇 扁傍厘
SKILL_CANCEL_ENCHANT_POISON <- 101 		  //  101.荤侩窍瘤 臼澜.
SKILL_CANCEL_VENOM_MINE <- 102 		  //  102.牡浇 海仇付牢
SKILL_CANCEL_RANDOM_KICK <- 103 		  //  103.牡浇 厚飘靛扼捞宏
SKILL_BLOCK_BUSTER_EX <- 104 		  //  104.喉废 滚胶磐[碍拳]
SKILL_DESTROY_EARTH_SKY_DROP <- 105 		  //  105.胶飘府飘 颇捞磐 阿己扁 - 玫贺瘤鲍
SKILL_GROUND_KICK <- 106 		  //  106.弊扼款靛疟
SKILL_CANCEL_GROUND_KICK <- 107 		  //  107.牡浇 弊扼款靛疟
SKILL_FAST_DASH <- 108 		  //  108.鉴焊
SKILL_SMART_THROW <- 109 		  //  埃瘤捧么 家胶 累诀 - 沥柳荐
SKILL_AUTO_LOAD <- 110 		  //  110.磊悼厘傈
SKILL_SPIRAL_NEN_SHOOT <- 111 		  //  111.唱急狼 迟 : 免
SKILL_SPIRAL_NEN_SPIN <- 112 		  //  112.唱急狼 迟 : 林
SKILL_CANCEL_SPIRAL_NEN_SHOOT <- 113 		  //  113.牡浇 唱急狼 迟 : 免
SKILL_NEN_POLE <- 114 		  //  114.迟狼 必狼
SKILL_TYPHOON_COUNTER_STRIKE <- 115 		  //  115.开嚼 : 弊贰敲矾 阿己扁 菩矫宏
SKILL_1000HANDS_1000EYES <- 116 		  //  116.玫荐玫救 : 胶颇 阿己扁 菩矫宏
SKILL_NEN_SPEAR_EX <- 117 		  //  117.迟 胶乔绢(漂己)
SKILL_CHARGE_SPEAR_EX <- 118 		  //  118.瞒瘤 胶乔绢(漂己)
SKILL_GLUEY_FRUIT_EX <- 119 		  //  119.馋利馋利凯概 (漂己)
SKILL_SPIRAL_COLUMN_EX <- 120 		  //  120.唱急券(漂己) 沥柳荐
SKILL_108_STAIRS_EX <- 121 		  //  121.108拌窜 (漂己)
SKILL_HURRICANE_SPEAR <- 122 		  //  122.倾府纳牢 胶乔绢 (漂己)
SKILL_CRASH_ROPE <- 123 		  //  123.堡气趋荤 (漂己)
SKILL_CHAIN_KICK_EX <- 124 		  //  124.楷券硼 (漂己)

CUSTOM_ANI_CROUCH <- 0 		  //  农扼快摹 悼累
CUSTOM_ANI_CRASH_LOW_KICK <- 1 		  //  夯 农矾寂
CUSTOM_ANI_LIFT_UPPER <- 2 		  //  公令 绢欺
CUSTOM_ANI_DAMAGE_LOW_KICK <- 3 		  //  肺疟
CUSTOM_ANI_TRY_SUPLEX <- 4 		  //  荐敲泛胶 矫档
CUSTOM_ANI_SUPLEX <- 5 		  //  荐敲泛胶
CUSTOM_ANI_BACK_SUPLEX <- 6 		  //  归宏饭捞目
CUSTOM_ANI_MOUNT_TRY <- 7 		  //  付款飘 矫档
CUSTOM_ANI_MOUNT <- 8 		  //  付款飘 - 利阑 疮洒绊 锭府扁 傈鳖瘤 葛记
CUSTOM_ANI_MOUNT_PUNCH <- 9 		  //  付款飘 - 戚摹
CUSTOM_ANI_NOT_USE <- 10 		  //  荤侩窍瘤 臼澜.
CUSTOM_ANI_STOMP <- 11 		  //  傍吝 光扁
CUSTOM_ANI_TRY_JUMP_SUPLEX <- 12 		  //  胶颇捞绢 矫档
CUSTOM_ANI_JUMP_SUPLEX <- 13 		  //  胶颇捞绢
CUSTOM_ANI_JUMP_SUPLEX_LARIAT <- 14 		  //  胶颇捞绢 雀傈 眠啊鸥
CUSTOM_ANI_CLOSE_PUNCH <- 15 		  //  盔牢摹 戚摹
CUSTOM_ANI_GRAB_EXPLOSION <- 16 		  //  老惯拳距己
CUSTOM_ANI_SHOULDER_TACKLE <- 17 		  //  捡歹 怕努
CUSTOM_ANI_WHIRL_WIND_KICK <- 18 		  //  急浅阿
CUSTOM_ANI_BLOCK_BUSTER_READY <- 19 		  //  喉废 滚胶磐 - 霖厚 (碍拳捧么 矫傈吝 老锭父 惯悼凳)
CUSTOM_ANI_BLOCK_BUSTER_JUMP <- 20 		  //  喉废 滚胶磐 - 痢橇 (碍拳捧么 矫傈吝 老锭父 惯悼凳)
CUSTOM_ANI_BLOCK_BUSTER_SHOOT <- 21 		  //  喉废 滚胶磐 - 痢橇 (碍拳捧么 矫傈吝 老锭父 惯悼凳)
CUSTOM_ANI_BLOCK_BUSTER_NORMAL <- 22 		  //  喉废 滚胶磐 - 老馆 寒倒 带瘤扁
CUSTOM_ANI_TRY_LEG_SUPLEX <- 23 		  //  俊绢酱鸥捞呈 矫档
CUSTOM_ANI_LEG_SUPLEX_THROW <- 24 		  //  俊绢酱鸥捞呈 : 带瘤扁
CUSTOM_ANI_LEG_SUPLEX_KICK <- 25 		  //  郴妨嘛扁 疟 葛记
CUSTOM_ANI_TYPHOON_GRAB <- 26 		  //  弊贰敲矾 阿己扁 : 棱扁
CUSTOM_ANI_TYPHOON_ATTACK1 <- 27 		  //  弊贰敲矾 阿己扁 : 1鸥
CUSTOM_ANI_TYPHOON_ATTACK2 <- 28 		  //  弊贰敲矾 阿己扁 : 2鸥
CUSTOM_ANI_TYPHOON_ATTACK3 <- 29 		  //  弊贰敲矾 阿己扁 : 3鸥
CUSTOM_ANI_TYPHOON_KICKUP <- 30 		  //  弊贰敲矾 阿己扁 : 瞒棵府扁
CUSTOM_ANI_TYPHOON_JUMP <- 31 		  //  弊贰敲矾 阿己扁 : 痢橇
CUSTOM_ANI_TYPHOON_LAST <- 32 		  //  弊贰敲矾 阿己扁 : 阜鸥
CUSTOM_ANI_TYPHOON_STAY <- 33 		  //  弊贰敲矾 阿己扁 : 阜鸥 饶 措扁
CUSTOM_ANI_CRAZY_MOUNT_START <- 34 		  //  瘤饿 付款飘
CUSTOM_ANI_CRAZY_MOUNT_PUNCH <- 35 		  //  瘤饿 付款飘 老馆 鸥拜
CUSTOM_ANI_CRAZY_MOUNT_NOT_USE <- 36 		  //  荤侩窍瘤 臼澜.
CUSTOM_ANI_CRAZY_MOUNT_END <- 37 		  //  瘤饿 付款飘 阜鸥
CUSTOM_ANI_THROW_WEB <- 38 		  //  玫扼瘤噶
CUSTOM_ANI_HIDDEN_STING <- 39 		  //  洒电胶泼
CUSTOM_ANI_VENOM_MINE <- 40 		  //  海仇付牢
CUSTOM_ANI_FLAME_LEGS_CAST <- 41 		  //  胶飘扼捞目 阿己扁 - 拳堪狼阿(矫傈)
CUSTOM_ANI_JUNK_SPIN_LOOP <- 42 		  //  沥农胶巧
CUSTOM_ANI_JUNK_SPIN_FINISH <- 43 
CUSTOM_ANI_MOUNT_END <- 44 		  //  付款飘 付瘤阜 戚摹
CUSTOM_ANI_SHOULDER_CHARGE <- 45 		  //  枚魂绊
CUSTOM_ANI_SINGLE_KICK <- 46 		  //  秦赣疟
CUSTOM_ANI_NEN_FLOWER <- 47 		  //  迟拳
CUSTOM_ANI_TRY_THROW_ENEMY <- 48 		  //  肺敲傅 矫档
CUSTOM_ANI_THROW_ENEMY_HOLD <- 49 		  //  肺敲傅 棱绊乐扁
CUSTOM_ANI_THROW_ENEMY_THROW <- 50 		  //  肺敲傅 带瘤扁
CUSTOM_ANI_WHITE_TIGER_COMBO1 <- 51 		  //  迟荐:归龋 1鸥
CUSTOM_ANI_WHITE_TIGER_COMBO2 <- 52 		  //  迟荐:归龋 2鸥
CUSTOM_ANI_WHITE_TIGER_COMBO3 <- 53 		  //  迟荐:归龋 3鸥
CUSTOM_ANI_WHITE_TIGER_COMBO4 <- 54 		  //  迟荐:归龋 4鸥
CUSTOM_ANI_WHITE_TIGER_COMBO5 <- 55 		  //  迟荐:归龋 5鸥
CUSTOM_ANI_WHITE_TIGER_DASH_ATTACK <- 56 		  //  迟荐:归龋 措浆傍拜
CUSTOM_ANI_WHITE_TIGER_JUMP_ATTACK <- 57 		  //  迟荐:归龋 痢橇傍拜
CUSTOM_ANI_DASH_PUNCH <- 58 		  //  沥鼻 骂福扁
CUSTOM_ANI_PUNCH_AFTER_RETURN <- 59 		  //  鸥拜饶 第肺倒府扁
CUSTOM_ANI_RANDOM_KICK1 <- 60 		  //  厚飘 靛扼捞宏 1鸥
CUSTOM_ANI_RANDOM_KICK2 <- 61 		  //  厚飘 靛扼捞宏 2鸥
CUSTOM_ANI_RANDOM_KICK3 <- 62 		  //  厚飘 靛扼捞宏 3鸥
CUSTOM_ANI_RANDOM_KICK_FINISH <- 63 		  //  厚飘 靛扼捞宏 阜鸥
CUSTOM_ANI_RISING_UPPER_DASH <- 64 		  //  铰锋鼻 : 措浆
CUSTOM_ANI_RISING_UPPER <- 65 		  //  铰锋鼻 : 绢欺
CUSTOM_ANI_DASH_AFTER_DASH_COMBO1 <- 66 		  //  龋脚楷拜 : 1鸥
CUSTOM_ANI_DASH_AFTER_DASH_COMBO2 <- 67 		  //  龋脚楷拜 : 2鸥
CUSTOM_ANI_DASH_AFTER_DASH_COMBO3 <- 68 		  //  龋脚楷拜 : 3鸥 - 巢拜啊绰 龋脚楷拜 3鸥 绝澜 
CUSTOM_ANI_DASH_AFTER_DASH_COMBO4 <- 69 		  //  龋脚楷拜 : 4鸥 - 巢拜啊绰 龋脚楷拜 4鸥 绝澜 
CUSTOM_ANI_EARTH_BREAK <- 70 		  //  陛碍尖
CUSTOM_ANI_HOLD_UP_TRY <- 71 		  //  圈靛诀 : 矫档
CUSTOM_ANI_HOLD_UP_HOLD <- 72 		  //  圈靛诀 : 棱扁
CUSTOM_ANI_HOLD_UP_HIT <- 73 		  //  圈靛诀 : 锭府扁
CUSTOM_ANI_WILD_CANNON_SPIKE_CHARGE <- 74 		  //  客老靛 某稠 胶颇捞农 : 面傈
CUSTOM_ANI_WILD_CANNON_SPIKE_FALL <- 75 		  //  客老靛 牡稠 胶颇捞农 : 冻绢瘤扁
CUSTOM_ANI_THROW_SAND <- 76 		  //  秋磐胶奶磐
CUSTOM_ANI_THROW_SAND_DOUBLE <- 77 		  //  秋磐胶奶磐 (捞吝捧么)
CUSTOM_ANI_TRY_SUPLEX_CYCLONE <- 78 		  //  荐敲泛胶 荤捞努沸 : 矫档
CUSTOM_ANI_TURN_SUPLEX_CYCLONE <- 79 		  //  荐敲泛胶 荤捞努沸 : 棱绊倒扁
CUSTOM_ANI_WILD_CANNON_SPIKE_EXP <- 80 		  //  客老靛 某稠 胶颇捞农 : 阜鸥
CUSTOM_ANI_FINISH_SUPLEX_CYCLONE <- 81 		  //  荤侩窍瘤 臼澜.
CUSTOM_ANI_LIGHTNING_DRAGON <- 82 		  //  堡面畴档 矫傈
CUSTOM_ANI_DESTROY_EARTH_SKY_DROP_START <- 83 		  //  胶飘府飘 颇捞磐 阿己扁 - 玫贺瘤鲍 矫累
CUSTOM_ANI_DESTROY_EARTH_SKY_DROP_ON_SKY <- 84 		  //  胶飘府飘 颇捞磐 阿己扁 - 玫贺瘤鲍 : 傍吝葛记
CUSTOM_ANI_DESTROY_EARTH_SKY_DROP_FINISH <- 85 		  //  碍拳 俊绢酱鸥捞呈 1瞒 嘛扁
CUSTOM_ANI_TRY_LEG_SUPLEX_EX_SECOND <- 86 		  //  碍拳 俊绢酱鸥捞呈 2瞒 矫档窍矾 痢橇
CUSTOM_ANI_LEG_SUPLEX_EX_2 <- 87 		  //  碍拳 俊绢酱鸥捞呈 2瞒 嘛扁
CUSTOM_ANI_RISING_UPPER_EX_START <- 88 		  //  碍拳 扼捞隆 呈努 矫累
CUSTOM_ANI_RISING_UPPER_EX <- 89 		  //  碍拳 扼捞隆 呈努
CUSTOM_ANI_RISING_UPPER_EX_FINISH <- 90 		  //  碍拳 扼捞隆 呈努 阜鸥
CUSTOM_ANI_BLOCK_BUSTER_EX_TRY <- 91 		  //  碍拳 喉废 滚胶磐 矫累
CUSTOM_ANI_BLOCK_BUSTER_EX_JUMP <- 92 		  //  碍拳 喉废 滚胶磐 痢橇
CUSTOM_ANI_BLOCK_BUSTER_EX_FINISH <- 93 		  //  碍拳 喉废 滚胶磐 阜鸥
CUSTOM_ANI_SUPLEX_CYCLONE_JUMP_EX <- 94 		  //  碍拳 荐敲泛胶 荤捞努沸 : 痢橇
CUSTOM_ANI_SUPLEX_CYCLONE_SPIN_EX <- 95 		  //  碍拳 荐敲泛胶 荤捞努沸 : 胶巧
CUSTOM_ANI_DASH_PUNCH_EX <- 96 		  //  碍拳 贺鼻
CUSTOM_ANI_STOMP_FINISH <- 97 		  //  傍吝光扁 阜鸥
CUSTOM_ANI_GROUND_KICK_JUMP <- 98 		  //  弊扼款靛疟 - 痢橇
CUSTOM_ANI_GROUND_KICK_ATTACK <- 99 		  //  弊扼款靛疟 - 傍拜
CUSTOM_ANI_GROUND_KICK_FINISH <- 100 		  //  弊扼款靛疟 - 乔聪浆
CUSTOM_ANI_FAST_DASH <- 101 		  //  鉴焊
CUSTOM_ANI_CRASH_LOW_KICK_SECOND <- 102 		  //  夯 农矾寂 滴锅掳 鸥拜
CUSTOM_ANI_THROW_ENEMY_SIDEKICK <- 103 		  //  巢拜 肺敲傅 荤捞靛疟
CUSTOM_ANI_THROW_ENEMY_DOWNKICK <- 104 		  //  巢拜 肺敲傅 郴妨嘛扁疟
CUSTOM_ANI_THROW_GRAB_CANNON_ENEMY_SIDEKICK <- 105 		  //  巢拜 肺敲傅 弊乏某惩 荤捞靛疟
CUSTOM_ANI_SUPLEX_FINAL_ATTACK <- 106 		  //  巢拜 荐敲泛胶 弊乏某惩 公腑嘛扁
CUSTOM_ANI_SUPLEX_THROW_FINAL_ATTACK <- 107 		  //  巢拜 荐敲泛胶 敲扼捞 公腑嘛扁
CUSTOM_ANI_DOUBLE_THROW_WEB <- 108 		  //  巢拜 弊拱捧么 (捞吝捧么)
CUSTOM_ANI_LEG_SUPLEX_FIRST_KICK <- 109 		  //  巢拜 俊绢酱鸥捞呈 檬扁 嘛扁 傍拜悼累
CUSTOM_ANI_JUMP_SUPLEX_HOLD_IMPRESSKICK <- 110 		  //  巢拜 胶颇捞绢 - 棱扁阂啊利 - 郴妨嘛扁 疟 葛记 
CUSTOM_ANI_LIGHTNING_DANCE_KICK <- 111 		  //  巢拜 扼捞飘醋 错胶 疟
CUSTOM_ANI_LIGHTNING_DANCE_LAST_LOW_KICK <- 112 		  //  巢拜 扼捞飘醋 错胶 阜鸥 肺快疟
CUSTOM_ANI_GRAB_EXPLOSION_KICK <- 113 		  //  巢拜 老惯拳距己	- 棱绊 瞒绰 悼累
CUSTOM_ANI_NEN_FLOWER_READY <- 114 		  //  迟付胶磐-阿己 龋尔捞 鸥绰 悼累
CUSTOM_ANI_NEN_FLOWER_ATTACK <- 115 		  //  迟付胶磐-阿己 龋尔捞 傍拜
CUSTOM_ANI_NEN_FLOWER_FINAL <- 116 		  //  迟付胶磐-阿己 龋尔捞 付瘤阜 傍拜
CUSTOM_ANI_ENCHANT_POISON <- 117 		  //  刀厘傈 惯荤
CUSTOM_ANI_SPIRALNEN_SHOOT_PREPARE <- 118 		  //  唱急狼 迟:免 礁 霖厚悼累
CUSTOM_ANI_SPIRALNEN_SHOOT <- 119 		  //  唱急狼 迟:免 礁
CUSTOM_ANI_BLOCK_BUSTER_DOUBLE <- 120 		  //  喉废 滚胶磐 - 捞吝捧么
CUSTOM_ANI_ENCHANT_POISON_DOUBLE <- 121 		  //  刀厘傈 - 捞吝捧么
CUSTOM_ANI_HIDDEN_STING_DOUBLE <- 122 		  //  官疵厘傈 - 捞吝捧么
CUSTOM_ANI_DEFINITE_GRAB <- 123 		  //  馆靛矫 棱绰促 - 漂荐弊乏 悼累
CUSTOM_ANI_NEN_SPEAR <- 124 		  //  迟 胶乔绢 踩扁(漂己)
CUSTOM_ANI_NEN_SPEAR_SUCCESS <- 125 		  //  迟 胶乔绢 踩扁 己傍矫(漂己)
CUSTOM_ANI_HURRICANE_SPEAR <- 126 		  //  巢拜捧啊 漂己胶懦 - 倾府纳牢 胶乔绢
CUSTOM_ANI_CHARGE_SPEAR_RECHARGE <- 127 		  //  瞒瘤胶乔绢(漂己) 面傈
CUSTOM_ANI_CHARGE_SPEAR_RUSH <- 128 		  //  瞒瘤胶乔绢(漂己) 倒拜
CUSTOM_ANI_CHARGE_SPEAR_END <- 129 		  //  瞒瘤胶乔绢(漂己) 倒拜 场
CUSTOM_ANI_SPIRAL_COLUMN_EX <- 130 		  //  唱急券(漂己)
CUSTOM_ANI_CRASH_ROPE <- 131 		  //  堡气趋荤 (漂己)
CUSTOM_ANI_GLUEY_FRUIT <- 132 		  //  馋利馋利 凯概(漂己)
CUSTOM_ANI_CHAIN_KICK <- 133 		  //  楷券硼(漂己)
CUSTOM_ANI_108_STAIRS_TRY_EX <- 134 		  //  108拌窜(漂己)
CUSTOM_ANI_108_STAIRS_KICK_EX <- 135 		  //  108拌窜(漂己)
CUSTOM_ANI_108_STAIRS_PUNCH_EX <- 136 		  //  108拌窜(漂己)
CUSTOM_ANI_108_STAIRS_BLOW_EX <- 137 		  //  108拌窜(漂己)
CUSTOM_ANI_108_STAIRS_THROW_EX <- 138 		  //  108拌窜(漂己)
CUSTOM_ANI_108_STAIRS_FINAL_EX <- 139 		  //  108拌窜(漂己)

CUSTOM_ATTACKINFO_CRASH_LOW_KICK <- 0 		  //  夯 农矾寂
CUSTOM_ATTACKINFO_LIFT_UPPER <- 1 		  //  公令 绢欺
CUSTOM_ATTACKINFO_DAMAGE_LOW_KICK <- 2 		  //  肺疟
CUSTOM_ATTACKINFO_TRY_GRAB <- 3 		  //  棱扁 矫档
CUSTOM_ATTACKINFO_SUPLEX <- 4 		  //  荐敲泛胶狼 埃立 单固瘤
CUSTOM_ATTACKINFO_MOUNT <- 5 		  //  付款飘 戚摹
CUSTOM_ATTACKINFO_STOMP <- 6 		  //  傍吝 光扁
CUSTOM_ATTACKINFO_JUMP_SUPLEX <- 7 		  //  胶颇捞绢 (弥檬 疟)
CUSTOM_ATTACKINFO_JUMP_SUPLEX_HEADING <- 8 		  //  胶颇捞绢 付瘤阜 雀傈疟
CUSTOM_ATTACKINFO_JUMP_SUPLEX_LARIAT <- 9 		  //  弊乏某惩 胶颇捞绢 付瘤阜 雀傈疟 (棱扁阂啊利)
CUSTOM_ATTACKINFO_CLOSE_PUNCH <- 10 		  //  盔牢摹 戚摹
CUSTOM_ATTACKINFO_SHOULDER_CHARGE <- 11 		  //  枚魂绊
CUSTOM_ATTACKINFO_SINGLE_KICK <- 12 		  //  秦赣 疟
CUSTOM_ATTACKINFO_GRAB_EXPLOSION <- 13 		  //  老惯拳距己 鸥拜
CUSTOM_ATTACKINFO_SHOULDER_TACKLE <- 14 		  //  捡歹 怕努
CUSTOM_ATTACKINFO_GRAB_CANNON <- 15 		  //  弊乏 某稠
CUSTOM_ATTACKINFO_WHIRL_WIND_KICK <- 16 		  //  急浅阿
CUSTOM_ATTACKINFO_JUNK_SPIN <- 17 		  //  官疵胶巧 (沥农胶巧)
CUSTOM_ATTACKINFO_LEG_SUPLEX_KICK <- 18 		  //  俊绢酱鸥捞呈 : 瞒扁
CUSTOM_ATTACKINFO_LIGHTNING_DANCE <- 19 		  //  扼捞飘醋 错胶
CUSTOM_ATTACKINFO_STRONGEST_LOW_KICK <- 20 		  //  荤惑弥碍狼 肺疟
CUSTOM_ATTACKINFO_CRAZY_MOUNT <- 21 		  //  瘤饿 付款飘
CUSTOM_ATTACKINFO_THROW_WEB <- 22 		  //  玫扼瘤噶
CUSTOM_ATTACKINFO_HIDDEN_STING <- 23 		  //  洒电胶泼
CUSTOM_ATTACKINFO_DASH_PUNCH <- 24 		  //  沥鼻 骂福扁
CUSTOM_ATTACKINFO_PUNCH_AFTER_RETURN <- 25 		  //  鸥拜饶 第肺倒府扁
CUSTOM_ATTACKINFO_RANDOM_KICK_1 <- 26 		  //  厚飘 靛扼捞宏 1鸥
CUSTOM_ATTACKINFO_RANDOM_KICK_2 <- 27 		  //  厚飘 靛扼捞宏 2鸥
CUSTOM_ATTACKINFO_RANDOM_KICK_3 <- 28 		  //  厚飘 靛扼捞宏 3鸥
CUSTOM_ATTACKINFO_RANDOM_KICK_FINISH <- 29 		  //  厚飘 靛扼捞宏 阜鸥
CUSTOM_ATTACKINFO_DUMMY_4 <- 30 		  //  荤侩登瘤 臼绊乐澜.
CUSTOM_ATTACKINFO_RISING_UPPER <- 31 		  //  铰锋鼻 : 绢欺
CUSTOM_ATTACKINFO_DASH_AFTER_DASH_COMBO1 <- 32 		  // 	龋脚楷拜 : 1鸥
CUSTOM_ATTACKINFO_DASH_AFTER_DASH_COMBO2 <- 33 		  // 	龋脚楷拜 : 2鸥
CUSTOM_ATTACKINFO_VENOM_MINE <- 34 		  // 	海仇付牢 傍拜仿
CUSTOM_ATTACKINFO_DUMMY_2 <- 35 		  // 	荤侩登瘤 臼绊乐澜
CUSTOM_ATTACKINFO_HOLD_UP_TRY <- 36 		  //  圈靛诀 : 矫档
CUSTOM_ATTACKINFO_HOLD_UP_HIT <- 37 		  //  圈靛诀 : 锭府扁
CUSTOM_ATTACKINFO_WILD_CANNON_SPIKE_FALL <- 38 		  //  客老靛 某稠 胶颇捞农 : 傍吝俊辑 冻绢龙锭
CUSTOM_ATTACKINFO_WILD_CANNON_SPIKE_HIT <- 39 		  //  客老靛 某稠 胶颇捞农 : 官蹿俊辑 利俊霸 单固瘤临锭
CUSTOM_ATTACKINFO_WHITE_TIGER_COMBO1 <- 40 		  //  迟荐:归龋 1鸥
CUSTOM_ATTACKINFO_WHITE_TIGER_COMBO2 <- 41 		  //  迟荐:归龋 2鸥
CUSTOM_ATTACKINFO_WHITE_TIGER_COMBO3 <- 42 		  //  迟荐:归龋 3鸥
CUSTOM_ATTACKINFO_WHITE_TIGER_COMBO4 <- 43 		  //  迟荐:归龋 4鸥
CUSTOM_ATTACKINFO_WHITE_TIGER_COMBO5 <- 44 		  //  迟荐:归龋 5鸥
CUSTOM_ATTACKINFO_WHITE_TIGER_DASH_ATTACK <- 45 		  //  迟荐:归龋 措浆傍拜
CUSTOM_ATTACKINFO_WHITE_TIGER_JUMP_ATTACK <- 46 		  //  迟荐:归龋 痢橇傍拜
CUSTOM_ATTACKINFO_SUPLEX_CYCLONE_CRASH <- 47 		  //  荐敲泛胶 荤捞努沸 : 棱绊嘛扁
CUSTOM_ATTACKINFO_SUPLEX_CYCLONE_FINISH <- 48 		  //  荐敲泛胶 荤捞努沸 : 付瘤阜 鸥拜
CUSTOM_ATTACKINFO_LEG_SUPLEX_EX_SPIN <- 49 		  //  碍拳 俊绢酱鸥捞呈 胶巧
CUSTOM_ATTACKINFO_DASH_PUNCH_EX <- 50 		  //  碍拳 贺鼻
CUSTOM_ATTACKINFO_BLOCK_BUSTER_FINISH_EX <- 51 		  //  碍拳 喉废 滚胶磐 阜鸥
CUSTOM_ATTACKINFO_RISING_UPPER_START_EX <- 52 		  //  碍拳 铰锋鼻 : 矫累
CUSTOM_ATTACKINFO_RISING_UPPER_EX <- 53 		  //  碍拳 铰锋鼻 : 绢欺
CUSTOM_ATTACKINFO_RISING_UPPER_FINISH_EX <- 54 		  //  碍拳 铰锋鼻 : 乔聪矫
CUSTOM_ATTACKINFO_SUPLEX_CYCLONE_EX <- 55 		  //  碍拳 荐敲泛胶 荤捞努沸
CUSTOM_ATTACKINFO_SUPLEX_CYCLONE_SPIN_EX <- 56 		  //  碍拳 荐敲泛胶 荤捞努沸 : 雀傈
CUSTOM_ATTACKINFO_STOMP_FINISH <- 57 		  //  傍吝光扁 阜鸥
CUSTOM_ATTACKINFO_GROUND_KICK <- 58 		  //  弊扼款靛疟
CUSTOM_ATTACKINFO_LIGHTNING_DRAGON <- 59 		  //  堡面畴档
CUSTOM_ATTACKINFO_CRASH_LOW_KICK_SECOND <- 60 		  //  夯 农矾寂 滴锅掳 鸥拜
CUSTOM_ATTACKINFO_THROW_ENEMY_UPKICK <- 61 		  //  巢拜 肺敲傅 UP疟
CUSTOM_ATTACKINFO_THROW_ENEMY_SIDEKICK <- 62 		  //  巢拜 肺敲傅 SIDE疟
CUSTOM_ATTACKINFO_THROW_ENEMY_DOWNKICK <- 63 		  //  巢拜 肺敲傅 DOWN疟
CUSTOM_ATTACKINFO_TRY_GRAB_THROW_ENEMY <- 64 		  //  肺钱傅 
CUSTOM_ATTACKINFO_THROW_WEB_DOUBLE <- 65 		  //  弊拱捧么 (捞吝捧么老锭)
CUSTOM_ATTACKINFO_LIGHTNING_LOW_KICK <- 66 		  //  弊拱捧么 (捞吝捧么老锭)
CUSTOM_ATTACKINFO_SUPLEX_GRABCANNON <- 67 		  //  荐敲泛胶 弊乏某惩 
CUSTOM_ATTACKINFO_NEN_FLOWER <- 68 		  //  迟付胶磐-阿己
CUSTOM_ATTACKINFO_TYPHOON <- 69 		  //  弊贰敲矾 阿己扁
CUSTOM_ATTACKINFO_TYPHOON_LAST <- 70 		  //  弊贰敲矾 阿己扁
CUSTOM_ATTACKINFO_SPIRAL_NEN_SHOOT <- 71 		  //  唱急狼 迟:免
CUSTOM_ATTACKINFO_NEN_SPEAR <- 72 		  //  迟胶乔绢(漂己)
CUSTOM_ATTACKINFO_CHARGE_SPEAR <- 73 		  //  瞒瘤胶乔绢(漂己)
CUSTOM_ATTACKINFO_HURRICANE_SPEAR <- 74 		  // 	倾府纳牢 胶乔绢 (漂己)
CUSTOM_ATTACKINFO_CRASH_ROPE <- 75 		  //  堡气趋荤 (漂己)
CUSTOM_ATTACKINFO_CHAIN_KICK1 <- 76 		  //  楷券硼 1鸥(漂己)
CUSTOM_ATTACKINFO_CHAIN_KICK2 <- 77 		  //  楷券硼 2鸥(漂己)
CUSTOM_ATTACKINFO_CHAIN_KICK3 <- 78 		  //  楷券硼 3鸥(漂己)
CUSTOM_ATTACKINFO_108_STAIRS_KICK_EX <- 79 		  //  108拌窜(漂己)
CUSTOM_ATTACKINFO_108_STAIRS_PUNCH_EX <- 80 		  //  108拌窜(漂己)
CUSTOM_ATTACKINFO_108_STAIRS_BLOW_1_EX <- 81 		  //  108拌窜(漂己)
CUSTOM_ATTACKINFO_108_STAIRS_BLOW_2_EX <- 82 		  //  108拌窜(漂己)
CUSTOM_ATTACKINFO_108_STAIRS_BLOW_3_EX <- 83 		  //  108拌窜(漂己)

WEAPON_SUBTYPE_KNUCKLE <- 0 		  //  呈努
WEAPON_SUBTYPE_GAUNTLET <- 1 		  //  扒撇房
WEAPON_SUBTYPE_CLAW <- 2 		  //  努肺
WEAPON_SUBTYPE_BOXING_GLOVE <- 3 		  //  鼻捧臂矾宏
WEAPON_SUBTYPE_DUMMY <- 4 		  //  UNKNOWN
WEAPON_SUBTYPE_TONFA <- 5 		  //  烹颇
WEAPON_SUBTYPE_MAX <- 6 

SOUND_ID_STATIC <- 0 		  //  甘俊 乐绰 悼救 拌加 敲饭捞
SOUND_ID_MOVE <- 1 		  //  叭绰 家府
SOUND_ID_ACTIVESTATUS_POISON <- 2 		  //  器捞琉 吧啡阑 锭
SOUND_ID_ACTIVESTATUS_BURN <- 3 		  //  锅 吧啡阑 锭
SOUND_ID_ACTIVESTATUS_LIGHTNING <- 4 		  //  扼捞飘醋 吧啡阑 锭
SOUND_ID_AURA_SHIELD <- 5 		  //  Appendage : 坷扼 角靛
SOUND_ID_MAGICAL_TEMPO_UP <- 6 		  //  Appendage : 碱鸥烙
SOUND_ID_DOT_AREA <- 7 		  //  Appendage : 柳悼颇
SOUND_ID_DOT_AREA_DAMAGE <- 8 		  //  Appendage : 柳悼颇 乔拜
SOUND_ID_DIVINE_LIGHT <- 9 		  //  Appendage : 脚己茄 蝴
SOUND_ID_SHADOW_BOXER <- 10 		  //  Appendage : 绩档快 冠辑
SOUND_ID_GUARD <- 11 		  //  啊靛 惑怕老锭
SOUND_ID_CHAKRA_OF_PASSION <- 12 		  //  Appendage : 凯沥狼 铆农扼
SOUND_ID_CHAKRA_OF_CALMNESS <- 13 		  //  Appendage : 趁沥狼 铆农扼
SOUND_ID_WAVE_MARK <- 14 		  //  Appendage : 颇悼牢
SOUND_ID_KEIGA <- 15 		  //  Appendage : 儡康狼 纳捞啊
SOUND_ID_END <- 16 

STATE_PRIORITY_AUTO <- 0 		  //  矫埃捞唱 炼扒俊 狼秦 磊悼栏肺 登绰 巴甸 (傍拜 辆丰, 惯荤 -> 厘傈 殿殿)
STATE_PRIORITY_USER <- 1 		  //  蜡历狼 目盖靛俊 狼秦 唱啊绰 巴甸 (胶懦, 傍拜 殿)
STATE_PRIORITY_HALF_FORCE <- 2 		  //  盔秦辑 唱啊绰 巴篮 酒聪瘤父, 肯傈 碍力焊促绰 撤篮 巴甸. (捞搁 第笼扁 殿)
STATE_PRIORITY_FORCE <- 3 		  //  碍力肺 窍霸 登绰 巴甸. (促款, 单固瘤, 荤噶, 圈靛 殿)
STATE_PRIORITY_IGNORE_FORCE <- 4 		  //  碍力 函版阑 公矫窍绰 巴甸. (荐敲泛胶肺 惑措 棱扁 殿)

STATE_VIRTUAL_ATTACK <- 19 		  //  老馆 傍拜 -> 傍拜胶懦 殿阑 困茄 啊惑 STATE
STATE_ANTIAIR_UPPER <- 20 		  //  绢欺
STATE_DUCKING <- 21 		  //  歹欧
STATE_SWAY <- 22 		  //  胶傀捞
STATE_GIANT_SWING <- 23 		  //  措雀傈拜
STATE_REPEATED_SMASH <- 24 		  //  抄拜
STATE_SMASHER <- 25 		  //  胶概寂
STATE_QUAKE_AREA <- 26 		  //  倡豪眠
STATE_WILL_DRIVER <- 27 		  //  廓 靛扼捞滚
STATE_DUCKING_SKILL <- 28 		  //  歹欧惑怕狼 胶懦喊 犬厘
STATE_LUCKY_STRAIGHT <- 29 		  //  钒虐 胶飘饭捞飘
STATE_SECOND_UPPER <- 30 		  //  技牧靛绢欺
STATE_HOLY_COUNTER <- 31 		  //  圈府 墨款磐
STATE_GORGEOUS_COMBINATION <- 32 		  //  绊历胶 哪厚匙捞记
STATE_CHOPPING_HAMMER <- 33 		  //  檬俏 秦赣
STATE_HURRICANE_OF_JUDGEMENT <- 34 		  //  缴魄狼 雀坷府
STATE_HOME_RUN <- 35 		  //  权繁
STATE_BLADE_OF_PURE_WHITE <- 36 		  //  鉴归狼 漠朝
STATE_HURRICANE_ROLL <- 37 		  //  倾府纳牢 费
STATE_THROW_WEAPON <- 38 		  //  芭急浅
STATE_DEFLECT_WALL <- 39 		  //  叼敲泛飘 岿
STATE_SPEAR_OF_VICTORY <- 40 		  //  铰府狼 芒
STATE_HAMMER_OF_CONTRITION <- 41 		  //  曼雀狼 噶摹
STATE_HEAVENLY_COMBINATION <- 42 		  //  庆红府 哪厚匙捞记
STATE_DIVINE_CRUSH <- 43 		  //  叼官牢 农矾矫
STATE_SIDEWIND <- 44 		  //  荤捞靛客牢靛
STATE_MACHINE_GUN_JAB <- 45 		  //  赣脚扒 漓
STATE_THROW_TALISMAN <- 46 		  //  己阂
STATE_APOCALYPSE <- 47 		  //  酒器漠赋胶
STATE_GALE_SMASH <- 48 		  //  龙浅鸥
STATE_ATOMIC_SMASH <- 49 		  //  公街拜
STATE_BIG_BANG_PUNCH <- 50 		  //  候桂 戚摹
STATE_BLUE_DRAGON <- 51 		  //  芒锋拜
STATE_HEAL_WIND <- 52 		  //  鳃 扩靛
STATE_CUTTING_DARKNESS <- 53 		  //  绢狄啊福扁
STATE_MACHINE_GUN_JAB_EX <- 54 		  //  碍拳 赣脚扒 漓
STATE_HEAVENLY_COMBINATION_EX <- 55 		  //  庆红府 哪厚匙捞记[碍拳]
STATE_REPEATED_SMASH_EX <- 56 		  //  碍拳 抄拜
STATE_DEFLECT_WALL_EX <- 57 		  //  叼敲泛飘 岿[碍拳]

SKILL_ANTIAIR_UPPER <- 1 		  //  傍曼鸥
SKILL_DUCKING <- 2 		  //  歹欧 措矫
SKILL_SWAY <- 3 		  //  胶傀捞
SKILL_HURRICANE_ROLL <- 4 		  //  倾府纳牢 费
SKILL_GIANT_SWING <- 5 		  //  措雀傈拜
SKILL_CANCEL_ANTIAIR_UPPER <- 6 		  //  牡浇 傍曼鸥
SKILL_STRIKING <- 7 		  //  胶飘扼捞欧
SKILL_SMASHER <- 8 		  //  胶概寂
SKILL_CANCEL_SMASHER <- 9 		  //  牡浇 胶概寂
SKILL_CHANGE_HP_TO_MP <- 10 		  // 	绊烹狼 锐凯
SKILL_QUAKE_AREA <- 11 		  //  倡豪眠
SKILL_CANCEL_QUAKE_AREA <- 12 		  //  牡浇 倡豪眠
SKILL_WILL_DRIVER <- 13 		  //  廓 靛扼捞滚
SKILL_TECHNICAL_MASTERY <- 14 		  //  抛农聪拿 付胶磐府
SKILL_BATTLE_AURA_MASTERY <- 15 		  //  硅撇 坷扼 付胶磐府
SKILL_CORKSCREW_MASTERY <- 16 		  //  内农胶农幅 付胶磐府
SKILL_COMBINATION_MASTERY <- 17 		  //  哪厚匙捞记 付胶磐府
SKILL_HARD_PUNCH_MASTERY <- 18 		  //  窍靛 戚摹 付胶磐府
SKILL_HP_MAX_UP_PERSONAL <- 19 		  //  玫惑狼 羔肺叼
SKILL_EMBLEM_OF_SAFEGUARD <- 20 		  //  焊龋狼 隆钎
SKILL_FOUNTAIN_OF_LIFE <- 21 		  //  积疙狼 盔玫
SKILL_DIVINE_LIGHT <- 22 		  //  脚己茄 蝴
SKILL_REVENGE_OF_LIGHT <- 23 		  //  蝴狼 汗荐
SKILL_HP_MAX_UP_PARTY <- 24 		  //  玫惑狼 窍葛聪
SKILL_SACRIFICE_OF_SOUL <- 25 		  //  康去狼 锐积
SKILL_HEAL_WIND <- 26 		  //  鳃 扩靛
SKILL_DEFLECT_WALL <- 27 		  //  叼敲泛飘 岿
SKILL_FLASH_GLOBE <- 28 		  //  敲贰矫 臂肺宏
SKILL_EXTENDED_PUNCH <- 29 		  //  鼻扁规免
SKILL_HOLY_COUNTER <- 30 		  //  圈府 墨款磐
SKILL_GORGEOUS_COMBINATION <- 31 		  //  绊历胶 哪厚匙捞记
SKILL_CANCEL_GORGEOUS_COMBINATION <- 32 		  //  牡浇 绊历胶 哪厚匙捞记
SKILL_CHOPPING_HAMMER <- 33 		  //  檬俏 秦赣
SKILL_ARMOR_MASTERY_PLATE_CS <- 34 		  //  农风技捞歹 魄陛 付胶磐府
SKILL_SHADOW_BOXER <- 35 		  //  绩档快 冠辑
SKILL_DOUBLE_SHADOW_BOXER <- 36 		  //  歹喉 绩档快 冠辑
SKILL_HURRICANE_OF_JUDGEMENT <- 37 		  //  缴魄狼 雀坷府
SKILL_ENTERING_NIRVANA <- 38 		  //  己阂
SKILL_OPPRESSION_TALISMAN <- 39 		  //  力拘何 (捞棋飘)
SKILL_THUNDERBOLT_TALISMAN <- 40 		  //  倡汾何 (捞棋飘)
SKILL_HOME_RUN <- 41 		  //  历 窍疵狼 喊
SKILL_QUICK_PARRY <- 42 		  //  狞 菩府
SKILL_BLADE_OF_PURE_WHITE <- 43 		  //  鉴归狼 漠朝
SKILL_CANCEL_BLADE_OF_PURE_WHITE <- 44 		  //  牡浇 鉴归狼 漠朝
SKILL_GLORIOUS_BLESS <- 45 		  //  康堡狼 绵汗
SKILL_CANCEL_HURRICANE_ROLL <- 46 		  //  牡浇 倾府纳牢 费
SKILL_CHAKRA_OF_PASSION <- 47 		  //  凯沥狼 铆农扼
SKILL_CHAKRA_OF_CALMNESS <- 48 		  //  趁沥狼 铆农扼
SKILL_REPEATED_SMASH <- 49 		  //  抄拜
SKILL_THROW_WEAPON <- 50 		  //  芭急浅
SKILL_SLOW_HEAL <- 51 		  //  浇肺快 鳃
SKILL_CURE <- 52 		  //  钮绢
SKILL_BLESS <- 53 		  //  瘤驱狼 绵汗
SKILL_GRACE_OF_GOD <- 54 		  //  脚狼 篮醚
SKILL_FAST_HEAL <- 55 		  //  菩胶飘 鳃
SKILL_DUCKING_STRAIGHT <- 56 		  //  歹欧 胶飘饭捞飘
SKILL_DUCKING_BODYBLOW <- 57 		  //  歹欧 焊叼喉肺
SKILL_DUCKING_UPPER <- 58 		  //  歹欧 绢欺
SKILL_CANCEL_DUCKING <- 59 		  //  牡浇 歹欧
SKILL_CANCEL_SWAY <- 60 		  //  牡浇 胶傀捞
SKILL_LUCKY_STRAIGHT <- 61 		  //  钒虐 胶飘饭捞飘
SKILL_CANCEL_LUCKY_STRAIGHT <- 62 		  //  牡浇 钒虐 胶飘饭捞飘
SKILL_SECOND_UPPER <- 63 		  //  技牧靛 绢欺
SKILL_GRASP_HAND_OF_ANGER <- 64 		  //  盒畴狼 框难羚
SKILL_CANCEL_GRASP_HAND_OF_ANGER <- 65 		  //  牡浇 盒畴狼 框难羚
SKILL_CHARGE_WEAPON <- 66 		  //  泪锋
SKILL_FORCE_OF_EXORCISM <- 67 		  //  硼付狼 扁款
SKILL_ARMOR_MASTERY_CLOTH_EC <- 68 
SKILL_HYUN_MOO <- 69 		  //  瘤狼 侥脚 - 泅公
SKILL_BAEK_HO <- 70 		  //  傍狼 侥脚 - 归龋
SKILL_CANCEL_REPEATED_SMASH <- 71 		  //  牡浇 抄拜
SKILL_CANCEL_HOME_RUN <- 72 		  //  牡浇 权繁
SKILL_SPEAR_OF_VICTORY <- 73 		  //  铰府狼 芒
SKILL_HAMMER_OF_CONTRITION <- 74 		  //  曼雀狼 噶摹
SKILL_HEAVENLY_COMBINATION <- 75 		  //  庆红府 哪厚匙捞记
SKILL_DIVINE_CRUSH <- 76 		  //  叼官牢 农矾矫
SKILL_SIDEWIND <- 77 		  //  荤捞靛客牢靛
SKILL_MACHINE_GUN_JAB <- 78 		  //  赣脚扒 漓
SKILL_CANCEL_SIDEWIND <- 79 		  //  牡浇 荤捞靛客牢靛
SKILL_CANCEL_MACHINE_GUN_JAB <- 80 		  //  牡浇 赣脚扒 漓
SKILL_JUDGEMENT <- 81 		  //  沥狼狼 缴魄
SKILL_BIG_WEAPON_MASTERY <- 82 		  //  芭捍付胶磐府 积己
SKILL_BATTLE_AXE_MASTERY <- 83 		  //  硅撇咀胶 付胶磐府
SKILL_APOCALYPSE <- 84 		  //  酒器漠赋胶
SKILL_GALE_SMASH <- 85 		  //  龙浅鸥
SKILL_AURA_OF_FAITH <- 86 		  //  脚充狼 坷扼
SKILL_DRYOUT <- 87 		  //  靛扼捞酒眶
SKILL_ATOMIC_SMASH <- 88 		  //  公街拜
SKILL_RADIATE_FIGHTING_AURA <- 89 		  //  捧扁 惯魂
SKILL_BIG_BANG_PUNCH <- 90 		  //  候桂 戚摹
SKILL_ARMOR_MASTERY_LIGHT_IF <- 91 		  //  版癌 付胶磐府:牢颇捞磐
SKILL_ARMOR_MASTERY_PLATE_EC <- 92 		  //  魄陛 付胶磐府:硼付荤
SKILL_BLUE_DRAGON <- 93 		  //  芒锋拜
SKILL_CANCEL_ENTERING_NIRVANA <- 94 		  //  牡浇 己阂
SKILL_CANCEL_GALE_SMASH <- 95 		  //  牡浇 龙浅鸥
SKILL_ARMOR_MASTERY_HEAVY_EC <- 96 		  //  吝癌 付胶磐府:硼付荤
SKILL_GRACE_OF_COURAGE <- 97 		  //  侩扁狼 篮醚
SKILL_GRACE_OF_PROTECTION <- 98 		  //  荐龋狼 篮醚
SKILL_RISING_AREA <- 99 		  //  铰玫柳
SKILL_CUTTING_DARKNESS <- 100 		  //  绢狄啊福扁
SKILL_SHIKIGAMI <- 101 		  //  侥脚狼 焙
SKILL_CANCEL_RISING_AREA <- 102 		  //  牡浇 铰玫柳
SKILL_MACHINE_GUN_JAB_EX <- 103 		  //  碍拳 赣脚扒 漓
SKILL_HEAVENLY_COMBINATION_EX <- 104 		  //  庆红府 哪厚匙固记[碍拳]
SKILL_REPEATED_SMASH_EX <- 105 		  //  碍拳 抄拜
SKILL_VERMILIONBIRD_TALISMAN <- 106 		  //  林累何
SKILL_CROSS_CRASH <- 107 		  //  农肺胶 农贰浆, 俺惯疙 : 哆芭款 绞磊啊, HotCross 殿
SKILL_FLASH_GLOBE_EX <- 108 		  //  敲贰矫 臂肺宏[碍拳]
SKILL_DEFLECT_WALL_EX <- 109 		  //  叼敲泛飘 岿[碍拳]
SKILL_HYUN_MOO_EX <- 110 		  //  泅公[碍拳]
SKILL_GROUND_CRASH <- 111 		  //  弊扼款靛 胶概矫, 俺惯疙 ox crash (茄快倒颇)
SKILL_CANCEL_GROUND_CRASH <- 112 		  //  牡浇 弊扼款靛 胶概矫
SKILL_SLOW_HEAL_EX <- 140 		  //  浇肺快 鳃 菩矫宏
SKILL_LUCKY_STRAIGHT_EX <- 141 		  //  钒虐 胶飘饭捞飘 菩矫宏
SKILL_QUAKE_AREA_EX <- 142 		  //  倡豪眠 菩矫宏
SKILL_GRASP_HAND_OF_ANGER_EX <- 143 		  //  盒畴狼 框难羚
SKILL_SPEAR_OF_VICTORY_EX <- 144 		  //  铰府狼 芒 菩矫宏
SKILL_REVENGE_OF_LIGHT_EX <- 145 		  //  蝴狼 汗荐 菩矫宏
SKILL_DUCKING_STRAIGHT_EX <- 146 		  //  歹欧 胶飘饭捞飘 菩矫宏
SKILL_WILL_DRIVER_EX <- 147 		  //  廓 靛扼捞滚 菩矫宏
SKILL_OPPRESSION_TALISMAN_EX <- 148 		  //  力拘何 菩矫宏
SKILL_THROW_WEAPON_EX <- 149 		  //  芭急浅 菩矫宏

CUSTOM_ANI_JUMP_PUNCH <- 0 		  //  痢橇 戚摹 (芭捍 绝阑锭 痢橇傍拜)
CUSTOM_ANI_ANTIAIR_UPPER <- 1 		  //  绢欺
CUSTOM_ANI_DUCKING <- 2 		  //  歹欧
CUSTOM_ANI_SWAY <- 3 		  //  胶傀捞
CUSTOM_ANI_GIANT_SWING_READY <- 4 		  //  措雀傈拜 : 霖厚
CUSTOM_ANI_GIANT_SWING <- 5 		  //  措雀傈拜 : 雀傈
CUSTOM_ANI_GIANT_SWING_FINAL <- 6 		  //  措雀傈拜 : 阜鸥
CUSTOM_ANI_SMASHER_TRY_GRAB <- 7 		  //  胶概寂 : 棱扁 扁档
CUSTOM_ANI_SMASHER_SUCCESS_GRAB <- 8 		  //  胶概寂 : 棱扁 己傍
CUSTOM_ANI_SMASHER_DASH <- 9 		  //  胶概寂 : 措矫 饶 带瘤扁
CUSTOM_ANI_DUCKING_BODYBLOW <- 10 		  //  焊叼喉肺
CUSTOM_ANI_QUAKE_AREA <- 11 		  //  倡豪眠
CUSTOM_ANI_WILL_DRIVER <- 12 		  //  廓 靛扼捞滚
CUSTOM_ANI_WILL_DRIVER_SECOND <- 13 		  //  廓 靛扼捞滚 : 捞固 踩腮 惑怕
CUSTOM_ANI_LUCKY_STRAIGHT <- 14 		  //  钒虐胶飘饭捞飘
CUSTOM_ANI_DUCKING_STRAIGHT <- 15 		  //  歹欧 胶飘饭捞飘
CUSTOM_ANI_SECOND_UPPER <- 16 		  //  技牧靛 绢欺
CUSTOM_ANI_DUCKING_UPPER <- 17 		  //  歹欧 绢欺
CUSTOM_ANI_HOLY_COUNTER_PRAY <- 18 		  //  圈府 墨款磐 : 扁档
CUSTOM_ANI_HOLY_COUNTER_BODYBLOW <- 19 		  //  圈府 墨款磐 : 官叼喉肺
CUSTOM_ANI_GORGEOUS_COMBINATION <- 20 		  //  绊历胶 哪厚匙捞记
CUSTOM_ANI_CHOPPING_HAMMER <- 21 		  //  檬俏 秦赣
CUSTOM_ANI_HURRICANE_OF_JUDGEMENT <- 22 		  //  缴魄狼 雀坷府
CUSTOM_ANI_HURRICANE_OF_JUDGEMENT2 <- 23 		  //  缴魄狼 雀坷府 2鸥
CUSTOM_ANI_HOME_RUN_GRAB <- 24 		  //  权繁 : 棱扁 矫档
CUSTOM_ANI_HOME_RUN_CHARGE <- 25 		  //  权繁 : 棱扁 & 瞒瘤
CUSTOM_ANI_HOME_RUN_SMASH <- 26 		  //  权繁 : 胶喇
CUSTOM_ANI_BLADE_OF_PURE_WHITE <- 27 		  //  鉴归狼 漠朝
CUSTOM_ANI_HURRICANE_ROLL_HOOK <- 28 		  //  倾府纳牢 费 : 扰
CUSTOM_ANI_HURRICANE_ROLL_UPPER <- 29 		  //  倾府纳牢 费 : 绢欺
CUSTOM_ANI_REPEATED_SMASH_START <- 30 		  //  抄拜 : 霉鸥
CUSTOM_ANI_REPEATED_SMASH <- 31 		  //  抄拜 : 抄鸥
CUSTOM_ANI_REPEATED_SMASH_FINAL <- 32 		  //  抄拜 : 阜鸥
CUSTOM_ANI_THROW_WEAPON_READY <- 33 		  //  芭急浅 : 霖厚
CUSTOM_ANI_THROW_WEAPON_SWING <- 34 		  //  芭急浅 : 雀傈 (钱瞒瘤矫 1雀傈 眠啊 葛记)
CUSTOM_ANI_THROW_WEAPON_THROW <- 35 		  //  芭急浅 : 捧么 (钱瞒瘤啊 酒聪搁 霖厚 -> 捧么)
CUSTOM_ANI_DEFLECT_WALL <- 36 		  //  叼敲泛飘 岿
CUSTOM_ANI_SPEAR_OF_VICTORY_READY <- 37 		  //  铰府狼 芒 : 霖厚&面傈
CUSTOM_ANI_SPEAR_OF_VICTORY_THROW <- 38 		  //  铰府狼 芒 : 捧么
CUSTOM_ANI_HAMMER_OF_CONTRITION <- 39 		  //  曼雀狼 噶摹
CUSTOM_ANI_HEAVENLY_COMBINATION <- 40 		  //  庆红府 哪厚匙捞记
CUSTOM_ANI_DIVINE_CRUSH <- 41 		  //  叼官牢 农矾矫
CUSTOM_ANI_INFIGHTER_ATTACK12 <- 42 		  //  牢颇捞磐 乞鸥 1,2鸥
CUSTOM_ANI_INFIGHTER_ATTACK3 <- 43 		  //  牢颇捞磐 乞鸥 3鸥
CUSTOM_ANI_INFIGHTER_ATTACK4 <- 44 		  //  牢颇捞磐 乞鸥 4鸥
CUSTOM_ANI_INFIGHTER_ATTACK5 <- 45 		  //  牢颇捞磐 乞鸥 5鸥
CUSTOM_ANI_EXORCIST_ATTACK1 <- 46 		  //  硼付荤 乞鸥 1鸥
CUSTOM_ANI_EXORCIST_ATTACK2 <- 47 		  //  硼付荤 乞鸥 2鸥
CUSTOM_ANI_EXORCIST_ATTACK3 <- 48 		  //  硼付荤 乞鸥 3鸥
CUSTOM_ANI_SIDEWIND <- 49 		  //  荤捞靛客牢靛 扁夯
CUSTOM_ANI_SIDEWIND_SECOND <- 50 		  //  荤捞靛客牢靛 眠啊鸥
CUSTOM_ANI_MACHINE_GUN_JAB <- 51 		  //  赣脚扒 漓 : 楷鸥
CUSTOM_ANI_MACHINE_GUN_JAB_FINISH <- 52 		  //  赣脚扒 漓 : 乔聪矫
CUSTOM_ANI_MACHINE_GUN_JAB_APPEND <- 53 		  //  赣脚扒 漓 : 眠啊鸥
CUSTOM_ANI_THROW_TALISMAN1 <- 54 		  //  己阂 : 带瘤扁1
CUSTOM_ANI_THROW_TALISMAN2 <- 55 		  //  己阂 : 带瘤扁2
CUSTOM_ANI_APOCALYPSE <- 56 		  //  酒器漠赋胶
CUSTOM_ANI_GALE_SMASH1 <- 57 		  //  龙浅鸥 : 绢柄摹扁
CUSTOM_ANI_GALE_SMASH2 <- 58 		  //  龙浅鸥 : 戎滴福扁
CUSTOM_ANI_ATOMIC_SMASH <- 59 		  //  公街拜
CUSTOM_ANI_BIG_BANG_PUNCH_READY <- 60 		  //  候桂 戚摹 : 霖厚
CUSTOM_ANI_BIG_BANG_PUNCH1 <- 61 		  //  候桂 戚摹 : 1鸥
CUSTOM_ANI_BIG_BANG_PUNCH2 <- 62 		  //  候桂 戚摹 : 2鸥
CUSTOM_ANI_BIG_BANG_PUNCH3 <- 63 		  //  候桂 戚摹 : 3鸥
CUSTOM_ANI_BIG_BANG_PUNCH4 <- 64 		  //  候桂 戚摹 : 4鸥
CUSTOM_ANI_HEAL_WIND_CAST <- 65 		  //  鳃 扩靛 : 某胶泼
CUSTOM_ANI_HEAL_WIND_BLAST <- 66 		  //  鳃 扩靛 : 惯悼
CUSTOM_ANI_BLUE_DRAGON1 <- 67 		  //  芒锋拜 : 积己
CUSTOM_ANI_BLUE_DRAGON2 <- 68 		  //  芒锋拜 : 捧么霖厚
CUSTOM_ANI_BLUE_DRAGON3 <- 69 		  //  芒锋拜 : 捧么
CUSTOM_ANI_CUTTING_DARKNESS_CHARGE <- 70 		  //  绢狄啊福扁 : 面傈
CUSTOM_ANI_CUTTING_DARKNESS_SMASH <- 71 		  //  绢狄啊福扁 : 戎滴福扁
CUSTOM_ANI_CUTTING_DARKNESS_FULL_SMASH <- 72 		  //  绢狄 啊福扁 : 面傈 戎滴福扁
CUSTOM_ANI_MACHINE_GUN_JAB_EX_LEFT <- 73 		  //  碍拳 赣脚扒 漓 楷鸥 谅
CUSTOM_ANI_MACHINE_GUN_JAB_EX_RIGHT <- 74 		  //  碍拳 赣脚扒 漓 楷鸥 快
CUSTOM_ANI_MACHINE_GUN_JAB_EX_FINISH <- 75 		  //  碍拳 赣脚扒 漓 乔聪浆
CUSTOM_ANI_HEAVENLY_COMBINATION_EX <- 76 		  //  庆红府 哪厚匙捞记[碍拳]
CUSTOM_ANI_REPEATED_SMASH_EX_FINISH <- 77 		  //  碍拳 抄拜 朝府扁
CUSTOM_ANI_GROUND_CRASH <- 78 		  //  弊扼款靛 胶概矫

CUSTOM_ATTACKINFO_JUMP_PUNCH <- 0 		  //  痢橇 戚摹 (傍捍 绝阑锭 痢橇傍拜)
CUSTOM_ATTACKINFO_DASH_ATTACK_SMASH <- 1 		  //  措矫 傍拜 2鸥掳
CUSTOM_ATTACKINFO_ANTIAIR_UPPER <- 2 		  //  傍曼鸥
CUSTOM_ATTACKINFO_GIANT_SWING <- 3 		  //  措雀傈拜 : 雀傈
CUSTOM_ATTACKINFO_GIANT_SWING_FINAL <- 4 		  //  措雀傈拜 : 阜鸥
CUSTOM_ATTACKINFO_SMASHER_TRY <- 5 		  //  胶概寂 棱扁 矫档
CUSTOM_ATTACKINFO_SMASHER_DASH <- 6 		  //  胶概寂 措矫
CUSTOM_ATTACKINFO_SMASHER_THROW <- 7 		  //  胶概寂 带瘤扁
CUSTOM_ATTACKINFO_QUAKE_AREA <- 8 		  //  倡豪眠
CUSTOM_ATTACKINFO_LUCKY_STRAIGHT <- 9 		  //  钒虐 胶飘饭捞飘
CUSTOM_ATTACKINFO_SECOND_UPPER <- 10 		  //  技牧靛 绢欺
CUSTOM_ATTACKINFO_DUCKING_STRAIGHT <- 11 		  //  歹欧 胶飘饭捞飘
CUSTOM_ATTACKINFO_DUCKING_BODYBLOW <- 12 		  //  歹欧 焊叼喉肺
CUSTOM_ATTACKINFO_DUCKING_UPPER <- 13 		  //  歹欧 绢欺
CUSTOM_ATTACKINFO_HOLY_COUNTER <- 14 		  //  圈府 墨款磐
CUSTOM_ATTACKINFO_GORGEOUS_COMBINATION1 <- 15 		  //  绊历胶 哪厚匙捞记 : 漓
CUSTOM_ATTACKINFO_GORGEOUS_COMBINATION2 <- 16 		  //  绊历胶 哪厚匙捞记 : 胶飘饭捞飘
CUSTOM_ATTACKINFO_GORGEOUS_COMBINATION3 <- 17 		  //  绊历胶 哪厚匙捞记 : 扰
CUSTOM_ATTACKINFO_CHOPPING_HAMMER <- 18 		  //  檬俏 秦赣
CUSTOM_ATTACKINFO_HURRICANE_OF_JUDGEMENT <- 19 		  //  缴魄狼 雀坷府
CUSTOM_ATTACKINFO_HOME_RUN_GRAB <- 20 		  //  权繁 : 棱扁 矫档
CUSTOM_ATTACKINFO_HOME_RUN_HIT <- 21 		  //  权繁 : 棱扁 己傍 饶 1鸥
CUSTOM_ATTACKINFO_HOME_RUN_SMASH <- 22 		  //  权繁 : 戎滴福扁
CUSTOM_ATTACKINFO_BLADE_OF_PURE_WHITE <- 23 		  //  鉴归狼 漠朝
CUSTOM_ATTACKINFO_HURRICANE_ROLL_HOOK <- 24 		  //  倾府纳牢 费 : 扰
CUSTOM_ATTACKINFO_HURRICANE_ROLL_UPPER <- 25 		  //  倾府纳牢 费 : 绢欺
CUSTOM_ATTACKINFO_REPEATED_SMASH <- 26 		  //  抄拜 : 抄鸥
CUSTOM_ATTACKINFO_REPEATED_SMASH_FINAL <- 27 		  //  抄拜 : 阜鸥
CUSTOM_ATTACKINFO_THROW_WEAPON <- 28 		  //  芭急浅 : 辟芭府 鸥拜
CUSTOM_ATTACKINFO_HAMMER_OF_CONTRITION <- 29 		  //  曼雀狼 噶摹
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION1 <- 30 		  //  庆红府 哪厚匙捞记 : 1鸥
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION2 <- 31 		  //  庆红府 哪厚匙捞记 : 2鸥
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION3 <- 32 		  //  庆红府 哪厚匙捞记 : 3鸥
CUSTOM_ATTACKINFO_DIVINE_CRUSH <- 33 		  //  叼官牢 农矾矫
CUSTOM_ATTACKINFO_INFIGHTER_ATTACK1 <- 34 		  //  牢颇捞磐 乞鸥 1鸥
CUSTOM_ATTACKINFO_INFIGHTER_ATTACK2 <- 35 		  //  牢颇捞磐 乞鸥 2鸥
CUSTOM_ATTACKINFO_INFIGHTER_ATTACK3 <- 36 		  //  牢颇捞磐 乞鸥 3鸥
CUSTOM_ATTACKINFO_INFIGHTER_ATTACK4 <- 37 		  //  牢颇捞磐 乞鸥 4鸥
CUSTOM_ATTACKINFO_INFIGHTER_ATTACK5 <- 38 		  //  牢颇捞磐 乞鸥 5鸥
CUSTOM_ATTACKINFO_EXORCIST_ATTACK1 <- 39 		  //  硼付荤 乞鸥 1鸥
CUSTOM_ATTACKINFO_EXORCIST_ATTACK2 <- 40 		  //  硼付荤 乞鸥 2鸥
CUSTOM_ATTACKINFO_EXORCIST_ATTACK3 <- 41 		  //  硼付荤 乞鸥 3鸥
CUSTOM_ATTACKINFO_SIDEWIND <- 42 		  //  荤捞靛客牢靛
CUSTOM_ATTACKINFO_SIDEWIND_SECOND <- 43 		  //  荤捞靛客牢靛 眠啊鸥
CUSTOM_ATTACKINFO_MACHINE_GUN_JAB <- 44 		  //  赣脚扒 漓 : 楷鸥
CUSTOM_ATTACKINFO_MACHINE_GUN_JAB_FINISH <- 45 		  //  赣脚扒 漓 : 乔聪矫
CUSTOM_ATTACKINFO_MACHINE_GUN_JAB_APPEND <- 46 		  //  赣脚扒 漓 : 眠啊鸥
CUSTOM_ATTACKINFO_THROW_TALISMAN1 <- 47 		  //  己阂 : 带瘤扁1
CUSTOM_ATTACKINFO_THROW_TALISMAN2 <- 48 		  //  己阂 : 带瘤扁2
CUSTOM_ATTACKINFO_GALE_SMASH1 <- 49 		  //  龙浅鸥 : 绢柄摹扁
CUSTOM_ATTACKINFO_GALE_SMASH2 <- 50 		  //  龙浅鸥 : 戎滴福扁
CUSTOM_ATTACKINFO_ATOMIC_SMASH_SWING <- 51 		  //  公街拜 : 戎滴福扁
CUSTOM_ATTACKINFO_ATOMIC_SMASH_SMASH <- 52 		  //  公街拜 : 郴妨摹扁
CUSTOM_ATTACKINFO_BIG_BANG_PUNCH_READY <- 53 		  //  候桂 戚摹 : 霖厚
CUSTOM_ATTACKINFO_BIG_BANG_PUNCH1 <- 54 		  //  候桂 戚摹 : 1鸥
CUSTOM_ATTACKINFO_BIG_BANG_PUNCH2 <- 55 		  //  候桂 戚摹 : 2鸥
CUSTOM_ATTACKINFO_BIG_BANG_PUNCH3 <- 56 		  //  候桂 戚摹 : 3鸥
CUSTOM_ATTACKINFO_BIG_BANG_PUNCH4 <- 57 		  //  候桂 戚摹 : 4鸥
CUSTOM_ATTACKINFO_BLUE_DRAGON <- 58 		  //  芒锋拜
CUSTOM_ATTACKINFO_CUTTING_DARKNESS <- 59 		  //  绢狄啊福扁
CUSTOM_ATTACKINFO_MACHINE_GUN_JAB_EX <- 60 		  //  碍拳 赣脚扒 漓 : 楷鸥
CUSTOM_ATTACKINFO_MACHINE_GUN_JAB_EX_FINISH <- 61 		  //  碍拳 赣脚扒 漓 : 乔聪矫
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION_EX2 <- 62 		  //  庆红府 哪厚匙捞记 : 2鸥
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION_EX3 <- 63 		  //  庆红府 哪厚匙捞记 : 3鸥
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION_EX4 <- 64 		  //  庆红府 哪厚匙捞记 : 4鸥
CUSTOM_ATTACKINFO_HEAVENLY_COMBINATION_EX5 <- 65 		  //  庆红府 哪厚匙捞记 : 5鸥
CUSTOM_ATTACKINFO_REPEATED_SMASH_EX_LIFT <- 66 		  //  碍拳 抄拜 剁快扁
CUSTOM_ATTACKINFO_REPEATED_SMASH_EX_FINAL <- 67 		  //  碍拳 抄拜 朝府扁
CUSTOM_ATTACKINFO_GROUND_CRASH1 <- 68 		  //  弊扼款靛 胶概矫 1鸥
CUSTOM_ATTACKINFO_GROUND_CRASH2 <- 69 		  //  弊扼款靛 胶概矫 2鸥


ATTACK_DIRECTION_UP <- 0 		  //  棵妨摹扁
ATTACK_DIRECTION_HORIZON <- 1 		  //  荐乞摹扁
ATTACK_DIRECTION_DOWN <- 2 		  //  郴妨摹扁
ATTACK_DIRECTION_MAX <- 3 

ATTACKTYPE_PHYSICAL <- 0 		  //  刀赋 拱府 傍拜
ATTACKTYPE_MAGICAL <- 1 		  //  刀赋 付过 傍拜  
ATTACKTYPE_ABSOLUTE <- 2 		  //  规绢 公矫 傍拜
ATTACKTYPE_MAX <- 3 

ATTACKTARGET_OWN <- 0 		  //  磊脚
ATTACKTARGET_FRIEND <- 1 		  //  酒焙
ATTACKTARGET_ENEMY <- 2 		  //  (磊脚苞 酒焙 捞寇狼) 利

DAMAGEACT_NONE <- 0 		  //  馆览 绝澜
DAMAGEACT_DAMAGE <- 1 		  //  单固瘤 葛记
DAMAGEACT_DOWN <- 2 		  //  促款
DAMAGEACT_DAMAGE_EXCEPT_HUMAN <- 3 		  //  扁夯 单固瘤, 绒刚酒赣绰 馆览绝澜

KNOCK_BACK_TYPE_NORMAL <- 0 		  //  老馆
KNOCK_BACK_TYPE_KNOCK_BACK <- 1 		  //  第肺 腹捞 剐覆 (乘归)
KNOCK_BACK_TYPE_SHORT_KNOCK_BACK_ <- 2 		  //  第肺 距埃 剐覆 (乘归)
KNOCK_BACK_TYPE_PIXEL_WITHOUT_DAMAGE_TIME <- 3 		  //  NORMAL_DAMAGE_BACK_TIME 矫埃悼救 瘤沥茄 侨伎父怒 第肺 剐覆, 捞悼吝 版流捞 钱府搁 捞悼档 肛勉
KNOCK_BACK_TYPE_NOT_BACK <- -1 		  //  第肺 救剐覆

HIT_DIRECTION_AUTO <- 0 		  //  磊悼 魄喊
HIT_DIRECTION_FRONT <- 1 		  //  菊栏肺
HIT_DIRECTION_BACK <- 2 		  //  第肺
HIT_DIRECTION_OUTER <- 3 		  //  官冰率栏肺
HIT_DIRECTION_INNER <- 4 		  //  救率栏肺

WEAPON_SUBTYPE_CROSS <- 0 		  //  绞磊啊
WEAPON_SUBTYPE_ROSARY <- 1 		  //  堪林
WEAPON_SUBTYPE_TOTEM <- 2 		  //  配袍
WEAPON_SUBTYPE_SCYTHE <- 3 		  //  炒
WEAPON_SUBTYPE_BATTLE_AXE <- 4 		  //  硅撇 咀胶
WEAPON_SUBTYPE_MAX <- 5 

GROW_TYPE_PRIEST <- 0 		  //  橇府胶飘
GROW_TYPE_CRUSADER <- 1 		  //  农风技捞歹
GROW_TYPE_INFIGHTER <- 2 		  //  牢颇捞磐
GROW_TYPE_EXORCIST <- 3 		  //  硼付荤
GROW_TYPE_AVENGER <- 4 		  //  绢亥历
GROW_TYPE_PRIEST_G <- 5 		  //  橇府胶飘G

EXTENDED_PUNCH_MOTION_DASH_ATTACK <- 0 		  //  措矫 傍拜
EXTENDED_PUNCH_MOTION_SECOND_UPPER <- 1 		  //  技牧靛 绢欺
EXTENDED_PUNCH_MOTION_MAX <- 2 

BASE_ATTACK_TYPE_DEFAULT <- 0 		  //  扁夯
BASE_ATTACK_TYPE_INFIGHTER <- 1 		  //  牢颇捞磐 林冈
BASE_ATTACK_TYPE_EXORCIST <- 2 		  //  硼付荤 芭捍

BATTLE_AURA_MOTION_ATTACK_12 <- 0 		  //  乞鸥1,2 (漓)
BATTLE_AURA_MOTION_ATTACK_3 <- 1 		  //  乞鸥3 (胶飘饭捞飘)
BATTLE_AURA_MOTION_ATTACK_4 <- 2 		  //  乞鸥4 (绢欺)
BATTLE_AURA_MOTION_ATTACK_5 <- 3 		  //  乞鸥5 (郴妨嘛扁)
BATTLE_AURA_MOTION_GORGEOUS_COMBINATION <- 4 		  //  绊历胶 哪厚匙捞记
BATTLE_AURA_MOTION_SIDEWIND <- 5 		  //  荤捞靛客牢靛
BATTLE_AURA_MOTION_SIDEWIND_SECOND <- 6 		  //  荤捞靛客牢靛 眠啊鸥
BATTLE_AURA_MOTION_MAX <- 7 



CHANGE_STATUS_TYPE_PHYSICAL_ATTACK <- 0 		  //  拱府 傍拜
CHANGE_STATUS_TYPE_MAGICAL_ATTACK <- 1 		  //  付过 傍拜
CHANGE_STATUS_TYPE_MAGICAL_DEFENSE <- 2 		  //  付过 规绢仿
CHANGE_STATUS_TYPE_PHYSICAL_DEFENSE <- 3 		  //  拱府 规绢
CHANGE_STATUS_TYPE_EQUIPMENT_PHYSICAL_ATTACK <- 4 		  //  厘厚 单固瘤
CHANGE_STATUS_TYPE_EQUIPMENT_PHYSICAL_DEFENSE <- 5 		  //  厘厚 拱府 规绢
CHANGE_STATUS_TYPE_PHYSICAL_ATTACK_BONUS <- 6 		  //  拱府 傍拜 焊呈胶
CHANGE_STATUS_TYPE_MAGICAL_ATTACK_BONUS <- 7 		  //  付过 傍拜 焊呈胶
CHANGE_STATUS_TYPE_JUMP_POWER <- 8 		  //  痢橇仿
CHANGE_STATUS_TYPE_JUMP_SPEED_RATE <- 9 		  //  痢橇 加档
CHANGE_STATUS_TYPE_ATTACK_SPEED <- 10 		  //  傍拜 加档
CHANGE_STATUS_TYPE_MOVE_SPEED <- 11 		  //  捞悼 加档
CHANGE_STATUS_TYPE_CAST_SPEED <- 12 		  //  某胶飘 加档
CHANGE_STATUS_TYPE_HP_MAX <- 13 		  //  HP MAX
CHANGE_STATUS_TYPE_HP_REGEN_RATE <- 14 		  //  HP 雀汗加档
CHANGE_STATUS_TYPE_PHYSICAL_CRITICAL_HIT_RATE <- 15 		  //  拱府 农府萍拿 洒飘 犬伏
CHANGE_STATUS_TYPE_MAGICAL_CRITICAL_HIT_RATE <- 16 		  //  付过 农府萍拿 洒飘 犬伏
CHANGE_STATUS_TYPE_PHYSICAL_BACK_ATTACK_CRITICAL <- 17 		  //  归绢琶 农府萍拿 洒飘 犬伏
CHANGE_STATUS_TYPE_MAGICAL_BACK_ATTACK_CRITICAL <- 18 		  //  归绢琶 农府萍拿 洒飘 犬伏
CHANGE_STATUS_TYPE_CRITICAL_TOLERANCE_RATE <- 19 		  //  农府萍拿 郴己
CHANGE_STATUS_TYPE_ELEMENT_TOLERANCE_FIRE <- 20 		  //  拳加己历亲
CHANGE_STATUS_TYPE_ELEMENT_TOLERANCE_WATER <- 21 		  //  荐加己历亲
CHANGE_STATUS_TYPE_ELEMENT_TOLERANCE_DARK <- 22 		  //  鞠加己历亲
CHANGE_STATUS_TYPE_ELEMENT_TOLERANCE_LIGHT <- 23 		  //  疙加己历亲
CHANGE_STATUS_TYPE_ELEMENT_TOLERANCE_ALL <- 24 		  //  葛电 加己历亲
CHANGE_STATUS_TYPE_ELEMENT_TOLERANCE_ZERO <- 25 		  //  加己历亲仿 0
CHANGE_STATUS_TYPE_ACTIVESTATUS_TOLERANCE_ALL <- 26 		  //  葛电 惑怕
CHANGE_STATUS_TYPE_ACTIVEPROPERTY_STUCK <- 27 		  //  胶盼(雀乔)
CHANGE_STATUS_TYPE_BACK_ATTACK_STUCK_TOLERANCE <- 28 		  //  归绢琶 胶盼 郴己 [郴啊 嘎阑锭] (% 窜困)
CHANGE_STATUS_TYPE_MP_REGEN_RATE <- 29 		  //  MP 雀汗 加档
CHANGE_STATUS_TYPE_EXTRA_SPEED_RATE <- 30 		  //  洒飘矫 版流
CHANGE_STATUS_TYPE_EQUIPMENT_MAGICAL_ATTACK <- 31 		  //  厘厚 付过 傍拜
CHANGE_STATUS_TYPE_EQUIPMENT_MAGICAL_DEFENSE <- 32 		  //  厘厚 付过 规绢
CHANGE_STATUS_TYPE_STUCK <- 33 		  //  胶盼 [郴啊 锭副锭](利吝)
CHANGE_STATUS_TYPE_HIT_RECOVERY <- 34 		  //  洒飘 府目滚府
CHANGE_STATUS_TYPE_MELEE_HIT_DELAY <- 35 		  //  辟芭府 鸥拜矫 三 掉饭捞
CAHNGE_STATUS_TYPE_EQUIPMENT_ALL_STAT <- 36 		  //  厘厚狼 葛电 瓷仿摹甫 棵妨临 锭.
CHANGE_STATUS_TYPE_CUSTOM <- 37 
CHANGE_STATUS_TYPE_EXP_DOUBLE <- 38 		  //  版氰摹 2硅
CHANGE_STATUS_TYPE_EVIL_UP <- 39 		  //  亲付仿 臭澜
CHANGE_STATUS_TYPE_EVIL_DOWN <- 40 		  //  92 亲付仿 撤澜 
CHANGE_STATUS_TYPE_RIGIDITY <- 41 		  //  版流档
CHANGE_STATUS_TYPE_ELEMENT_ATTACK_FIRE <- 42 		  //  拳加己 碍拳
CHANGE_STATUS_TYPE_ELEMENT_ATTACK_WATER <- 43 		  //  荐加己 碍拳
CHANGE_STATUS_TYPE_ELEMENT_ATTACK_DARK <- 44 		  //  鞠加己 碍拳
CHANGE_STATUS_TYPE_ELEMENT_ATTACK_LIGHT <- 45 		  //  疙加己 碍拳
CHANGE_STATUS_TYPE_ELEMENT_ATTACK_ALL <- 46 		  //  葛电 加己 碍拳
CHANGE_STATUS_TYPE_DISEASE <- 47 		  //  龙捍
CHANGE_STATUS_TYPE_MP_MAX <- 48 		  //  MP MAX
CHANGE_STATUS_TYPE_COOLTIME_DECLINE <- 49 		  //  胶懦 酿鸥烙
CHANGE_STATUS_TYPE_PHYSICAL_CRITICAL_DAMAGE_RATE <- 50 		  //  拱府 农府萍拿 单固瘤 刘啊 厚啦
CHANGE_STATUS_TYPE_MAGICAL_CRITICAL_DAMAGE_RATE <- 51 		  //  付过 农府萍拿 单固瘤 刘啊 厚啦
CHANGE_STATUS_TYPE_BLOODWAR_GROW_ABILITY <- 52 		  //  喉矾靛 带傈(趋捧狼啪) 己厘 
CHANGE_STATUS_TYPE_ADDITIONAL_PHYSICAL_GENUINE_ATTACK <- 53 		  //  刀赋 单固瘤 拱府 傍拜仿 函拳
CHANGE_STATUS_TYPE_ADDITIONAL_MAGICAL_GENUINE_ATTACK <- 54 		  //  刀赋 单固瘤 付过 傍拜仿 函拳
CHANGE_STATUS_TYPE_SUMMON_SKILL_POWER_BONUS_RATE <- 55 		  //  付过荤 家券荐狼 胶懦 傍拜仿 刘啊
CHANGE_STATUS_TYPE_ANTIEVIL <- 56 		  //  角力 亲付仿 荐摹 炼沥
CHANGE_STATUS_TYPE_PHYSICAL_ABSOLUTE_DAMAGE <- 57 		  //  拱府 例措 单固瘤 or 拱府 规绢公矫 单固瘤
CHANGE_STATUS_GHOST_TRAIN_NO_BREATH_TIME <- 58 		  //  蜡飞凯瞒 龙侥 矫埃 函版
CHANGE_STATUS_CHARACTER_LINK <- 59 		  //  某腐磐 傅农
CHANGE_STATUS_GOLD_INCREASE <- 60 
CHANGE_STATUS_TYPE_MAX <- 61 


OBJECTTYPE_OBJECT <- 0 		  //  弥惑困 坷宏璃飘
OBJECTTYPE_COLLISION <- 1 		  //  面倒 坷宏璃飘 (OBJECTTYPE_OBJECT 窍困)
OBJECTTYPE_ACTIVE <- 17 		  //  瓷悼 坷宏璃飘 (OBJECTTYPE_COLLISION 窍困)
OBJECTTYPE_CHARACTER <- 273 		  //  某腐磐 坷宏璃飘 (OBJECTTYPE_ACTIVE 窍困)
OBJECTTYPE_MONSTER <- 529 		  //  阁胶磐 坷宏璃飘 (OBJECTTYPE_ACTIVE 窍困)
OBJECTTYPE_RIDABLEOBJECT <- 4625 		  //  呕巴 包访 坷宏璃飘 (OBJECTTYPE_MONSTER 窍困)
OBJECTTYPE_PASSIVE <- 33 		  //  荐悼 坷宏璃飘 (OBJECTTYPE_COLLISION 窍困)
OBJECTTYPE_ITEM <- 289 		  //  酒捞袍 坷宏璃飘 (OBJECTTYPE_PASSIVE 窍困)
OBJECTTYPE_TRAP <- 545 		  //  飘乏 坷宏璃飘 (OBJECTTYPE_PASSIVE 窍困)
OBJECTTYPE_BREAKABLE <- 1057 		  //  颇鲍 啊瓷茄 坷宏璃飘(焊拱惑磊 扳窃) (OBJECTTYPE_PASSIVE 窍困)
OBJECTTYPE_PET <- 65 		  //  脚荐 (OBJCTTYPE_COLLISION 窍困)
OBJECTTYPE_CREATURE <- 129 		  //  农府媚 (OBJCTTYPE_COLLISION 窍困)
OBJECTTYPE_DRAWONLY <- 2 		  //  弊府扁 傈侩 坷宏璃飘 (OBJECTTYPE_OBJECT 窍困)
OBJECTTYPE_VIRTUALCHARACTER <- 18 		  //  措扁角俊辑 静绰 啊惑 某腐磐 (OBJECTTYPE_DRAWONLY 窍困)
OBJECTTYPE_NPC <- 34 		  //  措扁角狼 NPC (OBJECTTYPE_DRAWONLY 窍困)
OBJECTTYPE_DONKEY <- 66 		  //  措扁角狼 俺牢惑痢 (OBJECTTYPE_DRAWONLY 窍困)
OBJECTTYPE_VIRTUALCREATURE <- 130 		  //  措扁角俊辑 静绰 啊惑 农府媚(OBJECTTYPE_DRAWONLY 窍困)
OBJECTTYPE_DISJOINTSHOP <- 258 		  //  措扁角狼 秦眉啊 秦眉 惑痢(OBJECTTYPE_DRAWONLY 窍困)
OBJECTTYPE_VIRTUALMONSTER <- 514 		  //  措扁角俊辑 静绰 啊惑 阁胶磐 (OBJECTTYPE_DRAWONLEY 窍困)
OBJECTTYPE_NONE_DELETE <- 1026 		  //  坷宏璃飘 昏力 矫 昏力登瘤 臼绰 坷宏璃飘 (OBJECTTYPE_DRAWONLEY 窍困) 
OBJECTTYPE_DEFINE_END <- 61440 


CONVERT_TABLE_TYPE_DAMAGE <- 0 		  //  单固瘤
CONVERT_TABLE_TYPE_DEFENSE <- 1 		  //  规绢仿
CONVERT_TABLE_TYPE_HP <- 2 		  //  HP MAX
CONVERT_TABLE_TYPE_PHYSICAL_ATTACK <- 3 		  //  塞
CONVERT_TABLE_TYPE_PHYSICAL_DEFENSE <- 4 		  //  眉仿
CONVERT_TABLE_TYPE_MAGICAL_ATTACK <- 5 		  //  瘤瓷
CONVERT_TABLE_TYPE_MAGICAL_DEFENSE <- 6 		  //  沥脚仿
CONVERT_TABLE_TYPE_PHYSICAL_ABSOLUTE_DAMAGE <- 7 		  //  拱府 例措 单固瘤
CONVERT_TABLE_TYPE_PHYSICAL_DAMAGE_REDUCE <- 8 		  //  拱府 单固瘤 焊沥
CONVERT_TABLE_TYPE_MAGICAL_ABSOLUTE_DAMAGE <- 9 		  //  付过 例措 单固瘤
CONVERT_TABLE_TYPE_MAGICAL_DAMAGE_REDUCE <- 10 		  //  付过 单固瘤 焊沥
CONVERT_TABLE_TYPE_ACTIVESTATUS_DAMAGE_REDUCE <- 11 		  //  惑怕捞惑 单固瘤 焊沥.
CONVERT_TABLE_TYPE_MP <- 12 		  //  MP MAX
CONVERT_TABLE_TYPE_SKILL_POWER <- 13 		  //  胶懦 刀赋单固瘤
CONVERT_TABLE_TYPE_MAX <- 14 

ENUM_EQUIPMENTTYPE_AVATAR_HEADGEAR <- 0 		  //  葛磊 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_HAIR <- 1 		  //  赣府 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_FACE <- 2 		  //  倔奔 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_JACKET <- 3 		  //  惑狼 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_PANTS <- 4 		  //  窍狼 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_SHOES <- 5 		  //  脚惯 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_BREAST <- 6 		  //  格啊娇 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_WAIST <- 7 		  //  倾府 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_SKIN <- 8 		  //  个祸彬 酒官鸥
ENUM_EQUIPMENTTYPE_AVATAR_AURORA <- 9 		  //  坷肺扼 酒官鸥
ENUM_EQUIPMENTTYPE_WEAPON <- 10 		  //  公扁
ENUM_EQUIPMENTTYPE_TITLE <- 11 		  //  莫龋
ENUM_EQUIPMENTTYPE_JACKET <- 12 		  //  惑狼
ENUM_EQUIPMENTTYPE_SHOULDER <- 13 		  //  绢柄
ENUM_EQUIPMENTTYPE_PANTS <- 14 		  //  窍狼
ENUM_EQUIPMENTTYPE_SHOES <- 15 		  //  脚惯
ENUM_EQUIPMENTTYPE_WAIST <- 16 		  //  倾府
ENUM_EQUIPMENTTYPE_AMULET <- 17 		  //  格吧捞
ENUM_EQUIPMENTTYPE_WRIST <- 18 		  //  迫骂
ENUM_EQUIPMENTTYPE_RING <- 19 		  //  馆瘤
ENUM_EQUIPMENTTYPE_SUPPORT <- 20 		  //  焊炼
ENUM_EQUIPMENTTYPE_MAGIC_STONE <- 21 		  //  付过籍
ENUM_EQUIPMENTTYPE_MAX <- 22 
ENUM_EQUIPMENTTYPE_AVATAR_START <- 0 		  //  酒官鸥 矫累
ENUM_EQUIPMENTTYPE_AVATAR_END <- 8 		  //  酒官鸥 场
ENUM_EQUIPMENTTYPE_AVATAR_SELL_END <- 8 		  //  技扼讥 魄概 酒官鸥 场
ENUM_EQUIPMENTTYPE_AVATAR_MAX <- 9 		  //  酒官鸥 俺荐
ENUM_EQUIPMENTTYPE_ITEM_START <- 10 		  //  (酒官鸥啊 酒囱) 酒捞袍 矫累
ENUM_EQUIPMENTTYPE_VISIBLE_END <- 11 		  //  寇屈 函拳 厘厚 场
ENUM_EQUIPMENTTYPE_CREATURE <- 22 		  //  农府媚
ENUM_EQUIPMENTTYPE_ARTIFACT_RED <- 23 		  //  酒萍蒲飘 霉锅掳 浇吩
ENUM_EQUIPMENTTYPE_ARTIFACT_BLUE <- 24 		  //  酒萍蒲飘 滴锅掳 浇吩
ENUM_EQUIPMENTTYPE_ARTIFACT_GREEN <- 25 		  //  酒萍蒲飘 技锅掳 浇吩
ENUM_EQUIPMENTTYPE_ARTIFACT_END <- 26 
ENUM_EQUIPMENTTYPE_CREATURE_END <- 25 
ENUM_EQUIPMENTTYPE_CREATURE_MAX <- 24 
ENUM_EQUIPMENTTYPE_ARTIFACT <- 0 		  //  酒萍蒲飘 措钎牢郸胶
ENUM_EQUIPMENTTYPE_TOTAL_MAX <- 24 
ENUM_EQUIPMENTTYPE_VISIBLE_MAX <- 13 		  //  寇屈 函拳 厘厚 俺荐
ENUM_EQUIPMENTTYPE_ARMOR_START <- 12 
ENUM_EQUIPMENTTYPE_ARMOR_END <- 21 
ENUM_EQUIPMENTTYPE_ARMOR_NUM <- 10 
ENUM_EQUIPMENTTYPE_EXPAND_EQUIPSLOT_REVISE <- 10 		  //  老馆厘馒 浇吩苞 傍搬厘馒 浇吩埃狼 焊沥摹

SKILL_BACK_STEP <- 169 		  //  归胶跑
SKILL_CANCEL_BACK_STEP <- 170 		  //  牡浇 归胶跑
SKILL_CANCEL_THROW_ITEM <- 171 		  //  牡浇 酒捞袍 捧么
SKILL_ARMOR_MASTERY_LIGHT <- 172 		  //  版癌 付胶磐府
SKILL_ARMOR_MASTERY_HEAVY <- 173 		  //  吝癌 付胶磐府
SKILL_BASIC_ATTACK_UP <- 174 		  // 乞鸥 碍拳
SKILL_JUMP_POWER_UP <- 175 		  //  档距
SKILL_MAGICAL_ATTACK_UP <- 176 		  //  绊措狼 扁撅
SKILL_THROW_MASTERY <- 177 		  //  捧么 付胶磐府
SKILL_PHYSICAL_BACK_ATTACK_CRITICAL <- 178 		  //  拱府 归 绢琶
SKILL_DISJOINT_ITEM <- 179 		  //  酒捞袍 秦眉
SKILL_SUPER_ARMOR_ON_CAST <- 180 		  //  阂奔狼 狼瘤
SKILL_COMPOUND_CRAFT <- 181 		  //  炼钦:技傍
SKILL_COMPOUND_WEAVING <- 182 		  //  炼钦:规流
SKILL_COMPOUND_MACHINE <- 183 		  //  炼钦:扁拌
SKILL_COMPOUND_CHEMISTRY <- 184 		  //  炼钦:拳切
SKILL_ARMOR_MASTERY_LEATHER <- 185 		  //  啊磷 癌渴 付胶磐府
SKILL_PHYSICAL_CRITICAL_HIT_UP <- 186 		  //  拱府 农府萍拿 洒飘
SKILL_ARMOR_MASTERY_CLOTH <- 187 		  //  玫 规绢备 付胶磐府
SKILL_MAGICAL_CRITICAL_HIT_UP <- 188 		  //  付过 农府萍拿 洒飘
SKILL_MAGICAL_BACK_ATTACK_CRITICAL <- 189 		  //  付过 归 绢琶
SKILL_QUICK_STANDING <- 190 		  //  狞 胶拍爹
SKILL_BASIC_HP_MAX_UP <- 195 		  //  傍乞茄 搬捧厘 傈侩 胶懦 - 积疙仿 槛访
SKILL_ARMOR_MASTERY_PLATE <- 196 		  //  魄陛 付胶磐府
SKILL_GUILD_STATUS_UP <- 200 		  //  辨靛 胶懦
SKILL_FEATURE_STAT_PHYSICAL_ATTACK_UP <- 210 		  //  塞 漂己
SKILL_FEATURE_STAT_PHYSICAL_DEFENCE_UP <- 211 		  //  眉仿 漂己
SKILL_FEATURE_STAT_MAGICAL_ATTACK_UP <- 212 		  //  瘤瓷 漂己
SKILL_FEATURE_STAT_MAGICAL_DEFENCE_UP <- 213 		  //  沥脚 漂己
SKILL_FEATURE_STAT_STUCK_UP <- 214 		  //  利吝伏 漂己
SKILL_FEATURE_STAT_ACTIVEPROPERTY_STUCK_UP <- 215 		  //  雀乔啦 漂己
SKILL_FEATURE_STAT_HP_REGEN_RATE_UP <- 216 		  //  HP 府哩 漂己
SKILL_FEATURE_STAT_MP_REGEN_RATE_UP <- 217 		  //  MP 府哩 漂己
SKILL_FEATURE_STAT_ELEMENT_ATTACK_ALL_UP <- 218 		  // 	葛电 加己 碍拳
SKILL_FEATURE_STAT_ELEMENT_TOLERANCE_ALL_UP <- 219 		  //  葛电 加己 历亲
SKILL_MAX <- 220 
SKILL_FEATURE_STAT_START <- 210 
SKILL_FEATURE_STAT_MAX <- 10 		  // 胶湃 漂己 俺荐


ACTIVESTATUS_SLOW <- 0 		  //  浇肺快
ACTIVESTATUS_FREEZE <- 1 		  //  橇府令
ACTIVESTATUS_POISON <- 2 		  //  器捞琉
ACTIVESTATUS_STUN <- 3 		  //  胶畔
ACTIVESTATUS_CURSE <- 4 		  //  目胶
ACTIVESTATUS_BLIND <- 5 		  //  喉扼牢靛
ACTIVESTATUS_LIGHTNING <- 6 		  //  扼捞飘醋
ACTIVESTATUS_STONE <- 7 		  //  胶沛
ACTIVESTATUS_SLEEP <- 8 		  //  浇赋
ACTIVESTATUS_BURN <- 9 		  //  拳惑
ACTIVESTATUS_WEAPON_BREAK <- 10 		  //  公扁 颇鲍
ACTIVESTATUS_BLEEDING <- 11 		  //  喉府爹
ACTIVESTATUS_HASTE <- 12 		  //  庆捞胶飘
ACTIVESTATUS_BLESS <- 13 		  //  喉饭胶
ACTIVESTATUS_ELEMENT <- 14 		  //  郡饭刚飘
ACTIVESTATUS_CONFUSE <- 15 		  //  去鄂
ACTIVESTATUS_HOLD <- 16 		  //  圈靛
ACTIVESTATUS_ARMOR_BREAK <- 17 		  //  癌渴 颇鲍
ACTIVESTATUS_MAX <- 18 


GROW_TYPE_PRIEST <- 0		/// 橇府胶飘
GROW_TYPE_CRUSADER <- 1		/// 农风技捞歹
GROW_TYPE_INFIGHTER <- 2	/// 牢颇捞磐
GROW_TYPE_EXORCIST <- 3		/// 硼付荤
GROW_TYPE_AVENGER <- 4		/// 绢亥历


ENUM_CHARACTERJOB_SWORDMAN <- 0     /// 八荤
ENUM_CHARACTERJOB_FIGHTER <- 1      /// 拜捧啊
ENUM_CHARACTERJOB_GUNNER <- 2       /// 芭呈
ENUM_CHARACTERJOB_MAGE <- 3			/// 付过荤
ENUM_CHARACTERJOB_PRIEST <- 4		/// 橇府胶飘
ENUM_CHARACTERJOB_AT_GUNNER <- 5	/// 咯己 芭呈
ENUM_CHARACTERJOB_THIEF <- 6		/// 档迪
ENUM_CHARACTERJOB_AT_FIGHTER <- 7	/// 巢己 拜捧啊
ENUM_CHARACTERJOB_AT_MAGE <- 8		/// 巢己 付过荤
ENUM_CHARACTERJOB_DEMONIC_SWORDMAN <- 9	/// 付八荤
ENUM_CHARACTERJOB_CREATOR_MAGE <- 10	/// 农府俊捞磐
ENUM_CHARACTERJOB_MAX <- 11	/// 


ENUM_IS_REVERSE <- 0
ENUM_IS_START <- 1
ENUM_IS_PAUSE <- 2
ENUM_IS_END <- 3
ENUM_IS_INTERPOLATE_ATTACKBOX <- 4
ENUM_NEVER_APPLY_ANOTHER_PLAYERS_EFFECT_ALPHA_RATE <- 5
ENUM_IS_APPLY_ANOTHER_PLAYERS_EFFECT_ALPHA_RATE <- 6
ENUM_ANIMATION_BOOL_MAX <- 7


MODULE_TYPE_NONE <- -1
MODULE_TYPE_ENTRANCE <- 0
MODULE_TYPE_ROOM_LIST <- 1	// 付阑
MODULE_TYPE_SELECT_DUNGEON <- 2				// 带傈 急琶拳搁
MODULE_TYPE_MAIN_GAME <- 3					// 老馆带傈(捞拌 器窃)
MODULE_TYPE_PVP <- 4						// 搬厘
MODULE_TYPE_FAIR_PVP <- 5					// 傍搬
//MODULE_TYPE_LABYRINTH <- 7				// 荤扼咙
MODULE_TYPE_SELECT_CHANNEL <- 6             
MODULE_TYPE_WARROOM <- 7					// 傈里瘤开
//MODULE_TYPE_CHAOS <- 8					
MODULE_TYPE_LOGIN <- 8
MODULE_TYPE_ASSAULT <- 9					// 轿快磊
MODULE_TYPE_DEAD_TOWER <- 10					// 荤啪
MODULE_TYPE_BLOOD_SYSTEM <- 11				// 公茄狼 力窜
MODULE_TYPE_DESPAIR_TOWER <- 12			//例噶狼啪

// 臂肺国角 牧刨明
MODULE_TYPE_BOSS_TOWER <- 13			//缴楷狼 捧扁厘
MODULE_TYPE_ADVANCE_ALTAR <- 14			//柳拜狼 力窜

MODULE_TYPE_LOAD <- 15
MODULE_TYPE_TOURNAMENT <- 16
MODULE_TYPE_MAX <- 17
MODULE_TYPE_PVP_TYPE <- 18			// 搬捧厘, 轿快磊, 傈里瘤开阑 钦媚 瘤莫
MODULE_TYPE_DUNGEON_TYPE <- 19		// 带傈, 荤啪, 公力甫 钦媚 瘤莫
MODULE_TYPE_ALL <- 20			

//MODULE_TYPE_LOAD <- 13
//MODULE_TYPE_TOURNAMENT <- 14
//MODULE_TYPE_MAX <- 15
//MODULE_TYPE_PVP_TYPE <- 16			// 搬捧厘, 轿快磊, 傈里瘤开阑 钦媚 瘤莫
//MODULE_TYPE_DUNGEON_TYPE <- 17		// 带傈, 荤啪, 公力甫 钦媚 瘤莫
//MODULE_TYPE_ALL <- 18				// 葛电 葛碘阑 瘤莫


ATTACKTYPE_PHYSICAL <- 0		/// 刀赋 拱府 傍拜
ATTACKTYPE_MAGICAL  <- 1       /// 刀赋 付过 傍拜  
ATTACKTYPE_ABSOLUTE <- 2      /// 规绢 公矫 傍拜
ATTACKTYPE_LIGHT	<- 3
ATTACKTYPE_DARK		<- 4
ATTACKTYPE_WATER	<- 5
ATTACKTYPE_FIRE		<- 6
ATTACKTYPE_MAX		<- 7

BUFF_CAUSE_NORMAL <- 0// 老馆 绢奇叼瘤 鞍篮 鸥涝
BUFF_CAUSE_ACTIVE_STATUS <- 1// 惑怕捞惑
BUFF_CAUSE_SKILL <- 2		// 胶懦
BUFF_CAUSE_EXCEPTIONAL <- 3	// 抗寇贸府甫 困窃(付阑俊辑档 蜡瘤登绰 滚橇 酒捞能 鞍篮 巴)
BUFF_NONE <- 4				// 酒公繁巴档 窍瘤 臼澜
BUFF_CAUSE_MAX <- 5



PAUSETYPE_NONE		<- 0	/// 老矫沥瘤 救窃
PAUSETYPE_OBJECT	<- 1	/// 坷宏璃飘父 老矫沥瘤 (Appendage, 惑怕 函拳, 捞棋飘绰 拌加 倒酒皑, 吝仿 固利侩)
PAUSETYPE_WORLD		<- 2	/// 傈 技拌啊 老矫沥瘤 (Appendage, 惑怕 函拳, 捞棋飘档 沥瘤)

ENUM_ELEMENT_FIRE	<- 0	/// 拳
ENUM_ELEMENT_WATER	<- 1	/// 荐
ENUM_ELEMENT_DARK	<- 2	/// 鞠
ENUM_ELEMENT_LIGHT	<- 3	/// 疙
ENUM_ELEMENT_NONE	<- 4	/// 公
ENUM_ELEMENT_MAX	<- 4	/// == ENUM_ELEMENT_NONE


//  带瘤绰 措惑狼 鸥涝
THROW_TYPE_SKILL	<- 0	/// 胶懦
THROW_TYPE_ITEM		<- 1	/// 捧么 酒捞袍
SETUP_TYPE_ITEM		<- 2	/// 汲摹 酒捞袍

SPEED_TYPE_CONST						<- 0	/// 惑荐蔼. 函版秦档 setStaticSpeedInfo甫 犁龋免窍扁 傈鳖瘤绰 利侩 救凳
SPEED_TYPE_MOVE_SPEED					<- 1	/// 捞悼 加档
SPEED_TYPE_ATTACK_SPEED					<- 2	/// 傍拜 加档
SPEED_TYPE_EXCEPT_WEAPON_ATTACK_SPEED	<- 3	/// 公扁 狐柳 傍拜 加档
SPEED_TYPE_CAST_SPEED					<- 4	/// 某胶飘 加档

Z_ACCEL_TYPE_CONST				<- 0	/// 烙狼狼 惑荐
Z_ACCEL_TYPE_GRAVITY_WORLD		<- 1	/// 吝仿 : 技拌狼 碍力 吝仿
Z_ACCEL_TYPE_GRAVITY_OBJECT		<- 2	/// 吝仿 : 某腐磐喊 吝仿
Z_ACCEL_TYPE_ANTIGRAVITY_OBJECT	<- 3	/// 馆吝仿 : 吝仿俊 馆措登绰 塞. 肚绰 剧仿.

STATICINFO_DEPTH				<- 4	/// Static Info狼 弥措 历厘 表捞. (扁夯 -> 厘厚 利侩 -> 惑怕函拳 利侩 -> 酒捞袍, 胶懦 利侩)
X_NORMALMOVE_VELOCITY			<- 143	/// 啊肺 捞悼矫 啊肺肺 1檬悼救 捞悼 侨伎 荐
X_SLANTMOVE_VELOCITY			<- 119	/// 措阿急 捞悼矫 啊肺肺 1檬悼救 捞悼 侨伎 荐
Y_NORMALMOVE_VELOCITY			<- 114	/// 技肺 捞悼矫 技肺肺 1檬悼救 捞悼 侨伎 荐
Y_SLANTMOVE_VELOCITY			<- 95	/// 措阿急 捞悼矫 技肺肺 1檬悼救 捞悼 侨伎 荐
FORCE_TO_VELOCITY_CONST			<- 4000	/// 塞俊 狼茄 加档甫 拌魂窍绰 惑荐. 加档 = 惑荐 * 塞 / 公霸
SPEED_VALUE_DEFAULT				<- 1000	/// 捞悼 加档, 傍拜 加档殿狼 加档蔼 扁夯摹. 捞 蔼捞搁 100%烙.
LIGHT_OBJECT_MAX_WEIGHT			<- 60000	/// 瓤苞澜俊辑 啊涵款 公霸狼 惑茄急
MIDDLE_OBJECT_MAX_WEIGHT		<- 100000	/// 瓤苞澜俊辑 吝埃 公霸狼 惑茄急
DEFAULT_GRAVITY_ACCEL			<- -1500	/// 扁夯 吝仿 啊加档


OBJECT_MESSAGE_INVINCIBLE		<- 0
OBJECT_MESSAGE_GHOST			<- 1
OBJECT_MESSAGE_SUPERARMOR		<- 2
OBJECT_MESSAGE_UNBREAKABLE		<- 3
OBJECT_MESSAGE_END				<- 4

RECOVER_TYPE_HP					<- 0
RECOVER_TYPE_MP					<- 1
RECOVER_TYPE_HP_MP				<- 2
RECOVER_TYPE_MAX				<- 3

REASON_NONE						<- 0
REASON_DEATH					<- 1
REASON_MOVING_VILLAGE			<- 2
REASON_LOGIN					<- 3
REASON_ALL						<- 4

OPTION_HOTKEY_MOVE_UP 	<- 0
OPTION_HOTKEY_MOVE_DOWN <- 2
OPTION_HOTKEY_MOVE_LEFT <- 1
OPTION_HOTKEY_MOVE_RIGHT <- 3
ENUM_SUBKEY_TYPE_ALL <- 7


GROW_TYPE_AT_MAGE			<- 0	//  巢过荤
GROW_TYPE_ELEMENTAL_BOMBER	<- 1	//  郡饭膏呕 官赣
GROW_TYPE_GRACIAL_MASTER	<- 2	//  葫搬荤

PARTICLE_CREATER_LARGE_HIT			<- 0		/// 奴 鸥拜侩
PARTICLE_CREATER_SMALL_HIT			<- 1		/// 累篮 鸥拜侩
PARTICLE_CREATER_FIRE_HIT			<- 2		/// 拳 加己 鸥拜侩
PARTICLE_CREATER_FIRE_HIT_LIGHT		<- 3		/// 拳 加己 鸥拜侩
PARTICLE_CREATER_WATER_HIT			<- 4		/// 荐 加己 鸥拜侩
PARTICLE_CREATER_WATER_HIT_LIGHT	<- 5		/// 荐 加己 鸥拜侩
PARTICLE_CREATER_WATER_HIT_ICE		<- 6		/// 荐 加己 鸥拜侩

OPTION_HOTKEY__UNDEFINED <- -1 		  //  沥狼登瘤 臼澜
OPTION_HOTKEY_MOVE_UP <- 0 		  //  (Up arrow)
OPTION_HOTKEY_MOVE_LEFT <- 1 		  //  (Left arrow)
OPTION_HOTKEY_MOVE_DOWN <- 2 		  //  (Down arrow)
OPTION_HOTKEY_MOVE_RIGHT <- 3 		  //  (Right arrow)
OPTION_HOTKEY_ATTACK <- 4 		  //  (X)
OPTION_HOTKEY_JUMP <- 5 		  //  (C)
OPTION_HOTKEY_SKILL <- 6 		  //  (Z)
OPTION_HOTKEY_SKILL2 <- 7 		  //  buff侩 虐(space)
OPTION_HOTKEY_CREATURE_SKILL <- 8 		  //  (V)
OPTION_HOTKEY_STATUS_WINDOW <- 9 		  //  (M)
OPTION_HOTKEY_SKILL_WINDOW <- 10 		  //  (K)
OPTION_HOTKEY_ITEM_INVENTORY <- 11 		  //  (I)
OPTION_HOTKEY_OPTION_WINDOW <- 12 		  //  (O)
OPTION_HOTKEY_NORMAL_QUEST_WINDOW <- 13 		  //  (Q)
OPTION_HOTKEY_AVATAR_INVENTORY <- 14 		  //  (U)
OPTION_HOTKEY_CERASHOP <- 15 		  //  (T)
OPTION_HOTKEY_MINIMAP <- 16 		  // 带傈 固聪甘(N)
OPTION_HOTKEY_CREATURE_WINDOW <- 17 		  //  (Y)
OPTION_HOTKEY_TOOLTIP_ <- 18 		  // 惑技焊扁 傈券虐(R)
OPTION_HOTKEY_EPIC_QUEST_WINDOW <- 19 		  //  (W)
OPTION_HOTKEY_QUICK_SKILL1 <- 20 		  //  胶懦 浇吩(A, S, D, F, G, H)
OPTION_HOTKEY_QUICK_SKILL2 <- 21 
OPTION_HOTKEY_QUICK_SKILL3 <- 22 
OPTION_HOTKEY_QUICK_SKILL4 <- 23 
OPTION_HOTKEY_QUICK_SKILL5 <- 24 
OPTION_HOTKEY_QUICK_SKILL6 <- 25 
OPTION_HOTKEY_EXSKILL1 <- 26 		  //  犬厘胶懦 浇吩(F1 - F6)
OPTION_HOTKEY_EXSKILL2 <- 27 
OPTION_HOTKEY_EXSKILL3 <- 28 
OPTION_HOTKEY_EXSKILL4 <- 29 
OPTION_HOTKEY_EXSKILL5 <- 30 
OPTION_HOTKEY_EXSKILL6 <- 31 
OPTION_HOTKEY_ITEM_QUICKSLOT1 <- 32 		  //  酒捞袍 狞 浇吩(1 - 6)
OPTION_HOTKEY_ITEM_QUICKSLOT2 <- 33 
OPTION_HOTKEY_ITEM_QUICKSLOT3 <- 34 
OPTION_HOTKEY_ITEM_QUICKSLOT4 <- 35 
OPTION_HOTKEY_ITEM_QUICKSLOT5 <- 36 
OPTION_HOTKEY_ITEM_QUICKSLOT6 <- 37 
OPTION_HOTKEY_TOGGLE_ITEM_NAME_IN_DUNGEON <- 38 		  //  带傈俊辑 酒捞袍 捞抚焊扁(ctrl)
OPTION_HOTKEY_HIDE_MAIN_HUD <- 39 		  //  牢磐其捞胶 见扁扁(Tab)
OPTION_HOTKEY_TOGGLE_TITLE_ANIMATION <- 40 		  //  葱匙烙 沥焊 葛靛 函券(E)
OPTION_HOTKEY_TOGGLE_SKILL_INFORMATION <- 41 		  //  胶懦 砒屏 汲疙 葛靛 傈券(F7)
OPTION_HOTKEY_PAUSE_IN_TOWER <- 42 		  //  荤噶狼 啪 老矫沥瘤
OPTION_HOTKEY_CAPTURE_MOVING_PICTURE <- 43 		  //  悼康惑 母媚(Pause)
OPTION_HOTKEY_MENU_MY_INFO <- 44 		  //  郴焊包窃 皋春(7)
OPTION_HOTKEY_MENU_COMMUNITY <- 45 		  //  目孤聪萍 皋春(8)
OPTION_HOTKEY_MENU_CONTENTS <- 46 		  //  牧刨明 皋春(9)
OPTION_HOTKEY_MENU_SERVICE <- 47 		  //  辑厚胶 皋春(0)
OPTION_HOTKEY_MENU_SYSTEM__CLOSE_ALL_WINDOW <- 48 		  // 葛电芒摧扁(Esc)
OPTION_HOTKEY_PVP <- 49 		  //  搬捧厘(P)
OPTION_HOTKEY_RECOMMEND_USER <- 50 		  //  眠玫悼丰([)
OPTION_HOTKEY_PARTY_MATCHING <- 51 		  //  颇萍概莫(])
OPTION_HOTKEY_FRIEND <- 52 		  //  模备(L)
OPTION_HOTKEY_GUILD <- 53 		  //  辨靛(;)
OPTION_HOTKEY_MEMBER <- 54 		  //  糕滚(')
OPTION_HOTKEY_BLACKLIST <- 55 		  //  瞒窜
OPTION_HOTKEY_PVP_BUDDY <- 56 		  //  搬捧模备
OPTION_HOTKEY_WAR_AREA_LIST <- 57 		  //  傈里瘤开格废芒(,)
OPTION_HOTKEY_AUCTION_WINDOW <- 58 		  //  版概厘(B)
OPTION_HOTKEY_GOBLIN_PAD <- 59 		  //  绊喉赴菩靛
OPTION_HOTKEY_HOTKEY_SETTING_WINDOW <- 60 		  //  窜绵虐 汲沥芒
OPTION_HOTKEY_WAR_AREA_INFORMATION <- 61 		  //  傈里瘤开 沥焊芒(End)
OPTION_HOTKEY_HELLMODE_INFORMATION <- 62 		  //  歹 捞惑 荤侩登瘤 臼澜
OPTION_HOTKEY_FAVOR_CHECK_WINDOW <- 63 		  //  歹 捞惑 荤侩登瘤 臼澜
OPTION_HOTKEY_EXPERT_JOB <- 64 		  //  傈巩流诀 扁瓷
OPTION_HOTKEY_EMOTION_EXPRESSION <- 65 		  //  皑沥钎泅 扁瓷
OPTION_HOTKEY_EVENT <- 66 		  //  捞亥飘虐(shift)
OPTION_HOTKEY_PVP_MSSION <- 67 		  //  固记扩档快
OPTION_HOTKEY_PVP_RECORD <- 68 		  //  傈利焊扁芒
OPTION_HOTKEY_QUICK_CHAT_0 <- 69 
OPTION_HOTKEY_QUICK_CHAT_1 <- 70 
OPTION_HOTKEY_QUICK_CHAT_2 <- 71 
OPTION_HOTKEY_QUICK_CHAT_3 <- 72 
OPTION_HOTKEY_QUICK_CHAT_4 <- 73 
OPTION_HOTKEY_QUICK_CHAT_5 <- 74 
OPTION_HOTKEY_QUICK_CHAT_6 <- 75 
OPTION_HOTKEY_QUICK_CHAT_7 <- 76 
OPTION_HOTKEY_QUICK_CHAT_8 <- 77 
OPTION_HOTKEY_QUICK_CHAT_9 <- 78 
OPTION_HOTKEY_TOGGLE_ITEMINFO_COMPARE <- 79 		  //  酒捞袍 厚背芒 傈券虐 (Default: F8)
OPTION_HOTKEY_TITLEBOOK <- 80 		  //  莫龋合
OPTION_HOTKEY_THIS_DUNGEON <- 81 		  //  犁档傈
OPTION_HOTKEY_ANOTHER_DUNGEON <- 82 		  //  促弗 带傈 档傈
OPTION_HOTKEY_RETURN_TO_TOWN <- 83 		  //  付阑肺 倒酒啊扁
OPTION_HOTKEY_MERCENARY_SYSTEM <- 84 		  //  侩捍 矫胶袍
OPTION_HOTKEY_ITEM_DICTIONARY <- 85 
OPTION_HOTKEY_QUICK_PARTY_REGISTER <- 86 		  //  狐弗 颇萍 殿废 夸没


STATE_BURSTER				<- 100	// 傍烹胶懦 state 滚胶磐
// 傍烹 skill包访 何盒涝聪促.
// 198	`ATMage/Buster.skl`				// 滚胶磐
SKILL_BURSTER				<- 198	// 傍烹胶懦 滚胶磐
