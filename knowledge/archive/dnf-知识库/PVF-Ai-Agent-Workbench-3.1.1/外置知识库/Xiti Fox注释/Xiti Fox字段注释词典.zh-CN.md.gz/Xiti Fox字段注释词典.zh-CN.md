# Xiti Fox 字段注释词典

状态：`需验证`。本词典提取自外部批注数据库（作者 Xiti Fox，共 346 条；已去除作者、时间与工具类型编号信息）。社区批注只能作为读取与复核线索，不能直接作为写 PVF 的依据；写入前必须在目标 PVF 中重新读取同类样本、解析 registry、保存到显式输出并读回。

## 使用方式

1. 先在「文件类型索引」定位字段属于哪类文件（分组依据是批注里“官方示例”文件名的扩展名）。
2. 再打开对应分组：先看字段索引表（标签、标题、示例文件），需要细节时进入标签小节读说明与示例代码。
3. 同名字段出现在不同文件类型时按所在分组分别解释，不建立全局单义映射。
4. 示例文件名（如 `mapsample.map`）是工具自带的官方样例，不是目标 PVF 的实际路径；实际写入以目标 PVF 读回为准。
5. 无示例分组的条目多为短注释（只有标题或说明），阅读时按标签名定位。

## 文件类型索引

| 分组 | 条数 | 分组内标签示例 |
| --- | --- | --- |
| 怪物 | 48 | `EQUIPMENT_MAGICAL_ATTACK`、`EQUIPMENT_MAGICAL_DEFENSE`、`EQUIPMENT_PHYSICAL_ATTACK`、`EQUIPMENT_PHYSICAL_DEFENSE`、`attack delay`、`attack info` 等 48 个 |
| 攻击信息 | 33 | `active status`、`armor break`、`attack direction`、`attack enemy`、`attack friend`、`attack type` 等 33 个 |
| 技能 | 26 | `casting time`、`command`、`command key explain`、`consume MP`、`consume item`、`cool time` 等 26 个 |
| 装备 | 18 | `HP MAX`、`MP MAX`、`animation job`、`bleeding resistance`、`cast speed`、`equipment magical attack` 等 18 个 |
| 消耗品 | 11 | `active status recovery`、`attach type`、`buff`、`icon`、`minimum level`、`my status` 等 11 个 |
| 任务 | 8 | `exposed by npc`、`gold multiple`、`int data`、`job`、`reward int data`、`reward selection int data` 等 8 个 |
| 动画 | 7 | `ATTACK BOX`、`DELAY`、`FRAME MAX`、`FRAME000`、`IMAGE`、`IMAGE POS` 等 7 个 |
| 动作 | 6 | `BURN`、`INDEX`、`LEVEL`、`POS`、`SAY SPEECH`、`SUMMON MONSTER` |
| 地下城 | 5 | `basis level`、`champion`、`coin limit`、`experience increasing point`、`minimum required level` |
| 地图 | 2 | `dungeon start area`、`sound` |
| 杂项 | 2 | `avatar`、`difficulty` |
| 角色 | 1 | `weapon hit info` |
| 无示例 | 179 | `(ATTACK)`、`(BUFF)`、`(DOWN)`、`(LEFT)`、`(RIGHT)`、`(SKILL)` 等 177 个 |

## 分组明细

---

## 怪物（48 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `attack delay` | 攻击延迟 | monstersample.mob |
| `attack info` | 攻击信息 | monstersample.mob、newmonstersample.mob |
| `attack kind` | 怪物的攻击类型 | monstersample.mob、newmonstersample.mob |
| `attack motion` | 攻击动作 | actionlibrary/sample.mob、monstersample.mob |
| `category` | 怪物类型 | monstersample.mob、newmonstersample.mob |
| `common champion drop item` | 普通精英怪的[独立掉落] | actionlibrary/sample.mob、monstersample.mob、newmonstersample.mob |
| `common champion elemental property` | 普通精英怪的属性 | monstersample.mob、newmonstersample.mob |
| `damage motion 1` | 受击动作 | monstersample.mob |
| `damage motion 2` | 处于地面的受击动作 | monstersample.mob |
| `die effect` | 怪物被击杀时的特效 | monstersample.mob、newmonstersample.mob |
| `down motion` | 倒地动作 | monstersample.mob |
| `EQUIPMENT_MAGICAL_ATTACK` | 装备魔法攻击 | newmonstersample.mob |
| `EQUIPMENT_MAGICAL_DEFENSE` | 装备魔法防御 | newmonstersample.mob |
| `EQUIPMENT_PHYSICAL_ATTACK` | 装备物理攻击 | newmonstersample.mob |
| `EQUIPMENT_PHYSICAL_DEFENSE` | 装备物理防御 | newmonstersample.mob |
| `event super on scr` | 怪物在一定条件下触发霸体 | newmonstersample.mob |
| `face image` | 怪物在血条位置的头像 | monstersample.mob、newmonstersample.mob |
| `hit recovery` | 硬直（数值越高 | newmonstersample.mob |
| `hp regen rate` | 每分钟恢复生命值 | newmonstersample.mob |
| `item` | 该标签位于怪物面板时 | actionlibrary/sample.mob、monstersample.mob、newmonstersample.mob |
| `level` | 在任务里代表接取任务角色的等级区间 | monstersample.mob、newmonstersample.mob |
| `move motion` | 移动动作 | actionlibrary/sample.mob、monstersample.mob |
| `overturn motion` | 受到浮空效果的动作 | monstersample.mob |
| `sight` | 视力 | monstersample.mob、newmonstersample.mob |
| `sit motion` | 倒地起身动画 | actionlibrary/sample.mob、monstersample.mob |
| `speech on situation` | 台词信息 | monstersample.mob |
| `stuckbonus on damage` | 两个数值为1组 | monstersample.mob、newmonstersample.mob |
| `stun resistance` | 眩晕抗性 | newmonstersample.mob |
| `superarmor on attack` | 发起攻击时进入霸体 | monstersample.mob |
| `targeting attacker` | 怪物AI逻辑 | monstersample.mob、newmonstersample.mob |
| `targeting downed` | 怪物AI逻辑 | monstersample.mob |
| `targeting from direction` | 怪物AI逻辑 | monstersample.mob、newmonstersample.mob |
| `targeting high HP` | 怪物AI逻辑 | monstersample.mob |
| `targeting high level` | 怪物AI逻辑 | monstersample.mob |
| `targeting low HP` | 怪物AI逻辑 | monstersample.mob |
| `targeting low level` | 怪物AI逻辑 | monstersample.mob |
| `targeting low magical attack` | 怪物AI逻辑 | monstersample.mob |
| `targeting low magical defense` | 怪物AI逻辑 | monstersample.mob |
| `targeting low physical attack` | 怪物AI逻辑 | monstersample.mob |
| `targeting low physical defense` | 怪物AI逻辑 | monstersample.mob、newmonstersample.mob |
| `targeting nearest` | 怪物AI逻辑 | monstersample.mob |
| `targeting on attack` | 怪物AI逻辑 | monstersample.mob |
| `targeting on damage` | 怪物AI逻辑 | monstersample.mob |
| `targeting time term` | 怪物AI逻辑 | monstersample.mob |
| `unbreakable` | 霸体 | newmonstersample.mob |
| `undead` | 不死族 | newmonstersample.mob |
| `waiting motion` | 静止动作 | actionlibrary/sample.mob、monstersample.mob |
| `with blast` | 大概是狂龙之吼？ | newmonstersample.mob |

### `attack delay`

**标题**：攻击延迟

攻击延迟
300=0.3秒

**官方示例：monstersample.mob**

```pvf
[attack delay] 1000 // 攻击后再次攻击之前的平均延迟
```

### `attack info`

**标题**：攻击信息

[attack info]攻击信息
//使用攻击动作时会调用的ATK信息
//若要调整远程攻击需前往被动对象

//以下是可以在ATK中调整的内容
伤害比率、伤害类型、适用装备攻击力加成、敌和友伤判定、赋予属性、伤害判定、浮空值、平推值、击退值、命中音效、攻击方向、打击类型、异常状态

**官方示例：monstersample.mob**

```pvf
[attack info] // 基本攻击动作的攻击信息
`Attack1.atk`
`Attack2.atk`
[/attack info] // 必须用此标签闭合
```

**官方示例：newmonstersample.mob**

```pvf
[attack info] // 各动作文件的攻击信息。标签内指定的顺序与动作列表1:1匹配。
`AttackInfo/Attack1.atk`
`AttackInfo/Attack1.atk`
[/attack info]
```

### `attack kind`

**标题**：怪物的攻击类型

**官方示例：monstersample.mob**

```pvf
[attack kind] // 怪物的攻击种类
30 5 1 1 400 20 20 0 // 基本投掷
30 5 0 1 400 100 100 0 // 3方向投掷
[/attack kind]
```

**官方示例：newmonstersample.mob**

```pvf
[attack kind]
50.000000 0.000000 0.000000 1 70 0 0 0 10 0 10 0
40.000000 0.000000 0.000000 1 50 0 0 0 15 0 15 0
30.000000 0.000000 0.000000 1 55 0 0 0 10 0 10 0
0.000000 0.000000 0.000000 1 55 0 0 0 10 0 10 0 // 乱舞攻击 07.05.11添加，根据远程攻击概率触发，因此设为0。
[/attack kind]
```

### `attack motion`

**标题**：攻击动作

[attack motion]攻击动作
0为第1个，1为第2个，以此类推

同理的，控制攻击动作台词的[speech on situation]标签也跟这个一样

**官方示例：actionlibrary/sample.mob**

```pvf
[attack motion]
//`Animation_Goblin/Attack1.ani`
`Animation_Goblin/Stay.ani`
[/attack motion]
```

**官方示例：monstersample.mob**

```pvf
[attack motion] // 攻击动作动画文件名列表
`Attack1.ani`
`Attack2.ani`
[/attack motion] // 必须用此标签闭合
```

### `category`

**标题**：怪物类型

[category]怪物类型

//拓展添加
`[fort armor]` [建筑护甲]
`[divine armor]`[神圣护甲]
`[human armor]`[人形护甲]
`[fixture]` [固定位置]（比如罗特斯或斯卡萨）

//种族
 `[human]` [人形]                `[beast]` [野兽]
  `[plant]` [植物]                  `[insect]` [昆虫]
`[machine]` [机械]              `[hybrid]` [组合体]
 `[undead]` [不死族]           `[devil]` [恶魔]
   `[spirit]` [精灵]                `[dragon]` [龙族]
    `[tau]` [牛头族]              `[goblin]` [哥布林族]
 `[lugaru]` [猫妖族]
//攻击模式（2选1）
`[melee combat]` [近战攻击]
`[range combat]` [远程攻击]

//攻击逻辑（4选1）
`[close-passive]` [被动攻击]
`[close-carefully]` [游击]
`[close-tough]` [主动靠近攻击]
`[close-manace]` [施压]

逻辑讲解：
[被动攻击]：一般不会主动攻击，进入攻击范围会触发反击，
                    同时也跟游击差不多，会寻找合适的偷袭位置
[游击]：近战怪物会走位寻找合适的偷袭位置，最常见的就是
             走位偷背身，也会抓玩家的攻击后摇；
             远程怪物跟近战的差不多，在此基础上会在玩家靠近以后逃跑，
             也就是会风筝玩家的意思
[主动靠近攻击]：字面意思，会主动靠近玩家进行攻击
[施压]：实际体感跟[主动靠近攻击]差不多，为数不多的区别是身在远处也会发起攻击，无论近战远程，也无论是否进入攻击范围

**官方示例：monstersample.mob**

```pvf
[category] // 所属类别列表
`[undead]`
[/category]
```

**官方示例：newmonstersample.mob**

```pvf
[category] // 所属类别列表
[undead]
// 类别列表
// 种族 : [human][beast][plant][insect][machine][organic][hybrid][undead][devil][spirit][dragon]
// AI : [melee combat][range combat][close-passive][close-carefully][close-tough][close-manace] // * AI 接近方式 参考
// 护甲 : [human armor][fort armor][divine armor]
// 其他 : [goblin][tau][lugaru], [fixture], [stay] 添加 [stay] 是在原地不动
[/category]
```

### `common champion drop item`

**标题**：普通精英怪的[独立掉落]

普通精英怪的[独立掉落]
左边物品代码      右边权重（也就是概率占比的意思）

与独立掉落对应的是根据怪物等级来决定掉落材料的全局掉落[world drop]
全局掉落路径{ etc/worlddrop.etc }

**官方示例：actionlibrary/sample.mob**

```pvf
[common champion drop item]   // 普通冠军掉落的物品列表
3171 7000
[/common champion drop item]
```

**官方示例：monstersample.mob**

```pvf
[common champion drop item] // 一般冠军掉落的物品列表
1015 1
[/common champion drop item]
```

**官方示例：newmonstersample.mob**

```pvf
[common champion drop item] // 一般冠军掉落的物品列表。
1015 1
[/common champion drop item]
```

### `common champion elemental property`

**标题**：普通精英怪的属性

普通精英怪的属性
//若不选择，则随机分配属性

`[fire element]` = 火属性
`[water element]` = 冰属性
`[light element]` = 光属性
`[dark element]` = 暗属性
`[no element]` = 无属性

**官方示例：monstersample.mob**

```pvf
[common champion elemental property] // 一般冠军可拥有的元素属性种类
`[fire element]` // 若未指定任何属性，则必为随机属性冠军
`[water element]` // 若只指定一种，则必为该属性冠军
`[dark element]`
`[light element]`
`[no element]`
[/common champion elemental property]
```

**官方示例：newmonstersample.mob**

```pvf
[common champion elemental property] // 一般冠军可拥有的元素属性种类
[fire element] // 若未指定任何属性，则必为随机属性冠军
[water element] // 若只指定一种，则必为该属性冠军
[dark element]
[light element]
[no element]
[/common champion elemental property]
```

### `damage motion 1`

**标题**：受击动作

**官方示例：monstersample.mob**

```pvf
[damage motion 1] `BodyDamage1.ani` // 受伤动作1动画文件名
```

### `damage motion 2`

**标题**：处于地面的受击动作

**官方示例：monstersample.mob**

```pvf
[damage motion 2] `BodyDamage2.ani` // 受伤动作2动画文件名
```

### `die effect`

**标题**：怪物被击杀时的特效

[die effect]怪物被击杀时的特效

第1个：启用死亡特效（写0启用）
第2个：死亡时的碎块颜色编号
第3个：死亡时隐藏部分特效
// 0 : 全部显示（碎块 + 血液 + 烟雾 + 闪光特效）
// 1 : 隐藏碎块
// 2 : 隐藏血液
// 4 : 隐藏烟雾
// 8 : 隐藏闪光特效

**官方示例：monstersample.mob**

```pvf
// [die effect]
// param1 : 0 - 有死亡效果 (有[die effect]标签时务必设为0)
// param2 : 肉块的色号
// param3 : 死亡效果中不显示的部分的位值
// 0 : 全部显示。(肉块 + 血 + 烟雾 + 闪烁闪光)
// 1 : 仅排除肉块
// 2 : 仅排除血
// 4 : 仅排除烟雾
// 8 : 仅排除闪烁闪光
[die effect] 0 3 2
```

**官方示例：newmonstersample.mob**

```pvf
[die effect] 0 3 2 // 指定死亡时显示的特效
// param1 : 0 - 有死亡效果 (有[die effect]标签时必须设为0) -> 2007.8.22添加事项：大于0则无视审查等级无条件显示(冰碎片等)
// param2 : 肉块的色号
// param3 : 死亡效果中不显示的部分的位值
// 0 : 全部显示。(肉块 + 血 + 烟雾 + 闪烁闪光) 1 : 仅排除肉块 2 : 仅排除血 4 : 仅排除烟雾 8 : 仅排除闪烁闪光
```

### `down motion`

**标题**：倒地动作

**官方示例：monstersample.mob**

```pvf
[down motion] `BodyDown.ani` // 倒地动作动画文件名
```

### `EQUIPMENT_MAGICAL_ATTACK`

**标题**：装备魔法攻击

**官方示例：newmonstersample.mob**

```pvf
[EQUIPMENT_MAGICAL_ATTACK] // 魔法攻击：项目存在但不运作 - 我们系统中根本没有魔法攻击这个项目...
```

### `EQUIPMENT_MAGICAL_DEFENSE`

**标题**：装备魔法防御

**官方示例：newmonstersample.mob**

```pvf
[EQUIPMENT_MAGICAL_DEFENSE]
// 类别名，+ 或 *，+为加绝对值。*为按百分比相乘。若为 10 则在内部处理为 10 / 100 即 0.10
```

### `EQUIPMENT_PHYSICAL_ATTACK`

**标题**：装备物理攻击

**官方示例：newmonstersample.mob**

```pvf
[EQUIPMENT_PHYSICAL_ATTACK] `+` 10 // 物理攻击力
```

### `EQUIPMENT_PHYSICAL_DEFENSE`

**标题**：装备物理防御

**官方示例：newmonstersample.mob**

```pvf
[EQUIPMENT_PHYSICAL_DEFENSE] // 物理防御力
```

### `event super on scr`

**标题**：怪物在一定条件下触发霸体

[event super on scr]怪物在一定条件下触发霸体

上方4选1触发条件：
`[on time]` = 破坏后间隔一定时间刷新
`[on hp]` = 由剩余生命值触发
`[always]` = 到时间自动刷新，无论是否被破坏
`[counter]` = 破招时触发

下方2选1触发霸体类型：
`[unbreakable]` = 不可被破坏
`[breakable]` = 可以被破坏

拓展机制，不写也不影响：
`[with blast]` = 与霸体一起触发的狂龙之吼
————————————————————
//1000 = 1秒
————————————————————
	`[on time]`	5000	20000	1
//以上代表消失后间隔5秒刷新，护盾存在时间20秒，护盾存在期间受到投技不会导致霸体消失（写1不导致，写-1会导致）

	`[on hp]`	70	-1	-1
//以上代表减少70%最大生命值时触发（对会回血的目标则是剩余30%生命值触发），护盾永久存在（写-1就是永久），受到投技会导致霸体消失（写1不导致，写-1会导致）

	`[counter]`	1	10000	1
//以上代表受到破招时触发（写1触发，写-1不触发），护盾存在时间10秒，护盾存在期间受到投技不会导致霸体消失（写1不导致，写-1会导致）

	`[always]`	10000	5000
//以上代表每隔10秒刷新，护盾存在时间5秒
————————————————————
	`[breakable]`	和`[unbreakable]`通用写法介绍：
1、护盾耐久值，     根据最大生命值百分比决定，写多少就是多少百分比
2、护盾恢复效率，  写多少就是每秒恢复多少百分比（或许是）
3、近战防御力（固定值）
4、远程防御力（固定值）

**官方示例：newmonstersample.mob**

```pvf
// 由事件触发的超级护甲条件。
[event super on scr]
[on hp] 10 10000 1 // [on time], [on hp], [always], [conunter], 触发条件索引, 持续时间, 重新激活与否
[unbreakable] -1 -1 -1 -1 // 耐久度, 恢复力, 近程防御力, 远程防御力。
[with blast] // 与光龙的咆哮一起触发。
[/event super on scr]
```

### `face image`

**标题**：怪物在血条位置的头像

怪物在血条位置的头像

以下为npk文件调用链接，后面数字写多少就是调用多少号的头像
（比如写0调用0号头像）

**官方示例：monstersample.mob**

```pvf
[face image] `MonsterFace.img` 0 // 怪物脸部图像的文件和帧索引
```

**官方示例：newmonstersample.mob**

```pvf
[face image] `MonsterFace.img` 0 // 怪物脸部图像的文件和帧索引
```

### `hit recovery`

**标题**：硬直（数值越高

硬直（数值越高，受到攻击的硬直时间越短）

**官方示例：newmonstersample.mob**

```pvf
[hit recovery] 1000 1000 // 从2秒中减去该数值。动画帧延迟总和超过2秒时动画会被截断。
```

### `hp regen rate`

**标题**：每分钟恢复生命值

每分钟恢复生命值

该标签位于BOSS面板时，左边为战斗状态回复量，右边为脱战回复量（大概是）

0.3 = 每分钟回复30%

**官方示例：newmonstersample.mob**

```pvf
[hp regen rate] 0.0 0.0 // 锁定目标时的恢复比率，无目标时的恢复比率。
// 默认值 0.15f 0.6f。
```

### `item`

**标题**：该标签位于怪物面板时

该标签位于怪物面板时，代表该怪物的[独立掉落]，击杀该怪物以后有概率会从专门设置的掉落材料里随机掉落1个：
左边物品代码      右边权重（也就是概率占比的意思）

与独立掉落对应的是根据怪物等级来决定掉落材料的全局掉落[world drop]
全局掉落路径{ etc/worlddrop.etc }

娃娃机中：下面跟物品编号即可

商城里是道具→道具购买界面
商城编号→道具编号→购买条件（金币）→购买条件（胜点）→
购买条件（点券）→名称
商城的道具购买条件最好是3选1，否则会出现多个资源一起消耗的情况，比如设置50金币+50胜点购买某个道具，但金币够胜点不够，就会购买失败

**官方示例：actionlibrary/sample.mob**

```pvf
[item]
//3049 100
3015 100
//3029 100
1000 50
1047 200
1004 100
//3133 70
//7090 1
//7091 1
//7092 1
//7093 1
//7094 1
//7095 1
//7096 1
//7097 35
//7098 35
[/item]
```

**官方示例：monstersample.mob**

```pvf
// 杀死怪物时掉落的物品指定。没有特别指定的物品时可不写 //
[item]
1 6 // 依次为物品索引，概率
27 13
[/item] // 必须用此标签闭合
```

**官方示例：newmonstersample.mob**

```pvf
[item] // 杀死怪物时掉落的指定物品。没有特别指定的物品时可不写。
1 600 // 依次为物品索引，概率，万分比。
27 1300
[/item] // 必须用此标签闭合。
```

### `level`

**标题**：在任务里代表接取任务角色的等级区间

在任务里代表接取任务角色的等级区间，若超过最大等级，任务将不显示

在怪物里代表怪物等级

**官方示例：monstersample.mob**

```pvf
// 根据 最小 / 最大 等级的能力值 //
[level] 10 30 // 前面的为最小等级，后面的为最大等级
```

**官方示例：newmonstersample.mob**

```pvf
[level] 10 30 // 前面的为最小等级，后面的为最大等级
```

### `move motion`

**标题**：移动动作

**官方示例：actionlibrary/sample.mob**

```pvf
//[waiting action]  `Action_Goblin/stay.act`
[move motion]  `Animation_Goblin/Move.ani`
//[move action]	`Action_Goblin/move.act`
```

**官方示例：monstersample.mob**

```pvf
[move motion] `BodyMove.ani` // 移动动作动画文件名
```

### `overturn motion`

**标题**：受到浮空效果的动作

**官方示例：monstersample.mob**

```pvf
[overturn motion] `BodyOverturn.ani` // 被翻转动作动画文件名
```

### `sight`

**标题**：视力

视力
此数值越高，就越不容易因为距离过远而丢失目标

**官方示例：monstersample.mob**

```pvf
// AI 信息。使用默认值时可不写。 //
[sight] 200 // 目标有效距离 (像素值，0则为无限大)
```

**官方示例：newmonstersample.mob**

```pvf
//mkjung 120618 添加
[sight] 300
```

### `sit motion`

**标题**：倒地起身动画

**官方示例：actionlibrary/sample.mob**

```pvf
//[move action]	`Action_Goblin/move.act`
[sit motion]  `Animation_Goblin/Sit.ani`
```

**官方示例：monstersample.mob**

```pvf
[sit motion] `BodySit.ani` // 坐下动作动画文件名
```

### `speech on situation`

**标题**：台词信息

[speech on situation]台词信息
登场的APC或怪物在做出特定动作和攻击动作[attack motion]时，头上会浮现的对话气泡
—————————————————————————————
                              //当赋予台词对象为怪物时
发起攻击:
	`[on attack]`	`（台词）`	0
//0是第1个攻击动作，1是第2个，以此类推

受到攻击:
	`[on damage]`	`（台词）`	0

产生仇恨目标时:
	`[on revenge]`	`（台词）`	0

出现在自身附近时:
	`[on appear]`	`（台词）`	0
//这个实际上跟revenge用法差不多

特殊触发:
	`[on etc]`	`（台词）`	0
//比如艾力斯的吐口水，或者僵尸识别到附近有被施加出血异常的敌军

生命值耗尽:
	`[on die]`	`（台词）`	0

处于【怪物攻城战】期间时：
	`[on village]`	`（台词）`	0
—————————————————————————————
                              //当赋予台词对象为APC时
//需要注意的是APC台词是目标动作在上方，台词在下方
处于站立状态时：
	[on stand]
		`（台词）`	0

受到攻击:
	[on damage]
		`（台词）`	0

生命值耗尽：
	[on die]
		`（台词）`	0

出现在自身附近时：
	[on appear]
		`（台词）`	0

联动台词：
	[on disappear]
		`（第二句台词）`	0
—————————————————————————————
[on disappear]一般与[on appear]搭配使用，也可以修改最后一个数字以达到分组的效果，就像这样↓
	[on appear]
		`我小熊丢了......`	1
	[on disappear]
		`能帮我找找嘛？`	1
	[on appear]
		`呀哈!`	2
	[on disappear]
		`我的火焰厉害嘛？`	2
那么第2组的[on disappear]就不会接上第1组的[on appear]
—————————————————————————————
使用快捷栏技能[quick skill]：
	[on attack]
		`（台词）`	50	0

使用快捷栏道具[quick item]：
	[on attack]
		`（台词）`	100	0

**官方示例：monstersample.mob**

```pvf
// 0626 添加
[speech on situation]
`[on attack]` `接招吧！我的第0次攻击！！` 0 // 只有 `[on attack]` 时末尾的数字有意义。
`[on attack]` `接招吧！我的第1次攻击！！` 1
`[on damage]` `呃啊 好痛！！！` 0
`[on die]` `爸爸啊~` 0
`[on revenge]` `复仇会招致复仇！` 0
`[on etc]` `其他硬编码情况下指定此处后与程序员商议` 0 // `[on etc]` 的情况下顺序很重要，因此编写后请勿改变顺序
[/speech on situation]
```

### `stuckbonus on damage`

**标题**：两个数值为1组

两个数值为1组：
受到远程攻击的受击硬直比率，最小值/最大值
受到近战攻击的受击硬直比率，最小值/最大值

**官方示例：monstersample.mob**

```pvf
// 07?? 添加
[stuckbonus on damage]
0 0 // 远程攻击的僵直率 - 最低等级 ~ 最高等级
0 0 // 近战攻击的僵直率 - 最低等级 ~ 最高等级

[stuckbonus on damage]
5 20 // 受到远程攻击时的僵直奖励 %，最低等级 / 最高等级
0 5 // 受到近战攻击时的僵直奖励 %，最低等级 / 最高等级
```

**官方示例：newmonstersample.mob**

```pvf
[stuckbonus on damage]
5 20 // 受到远程攻击时的僵直奖励 %，最低等级 / 最高等级
0 5 // 受到近战攻击时的僵直奖励 %，最低等级 / 最高等级。
```

### `stun resistance`

**标题**：眩晕抗性

**官方示例：newmonstersample.mob**

```pvf
[stun resistance] // 眩晕
```

### `superarmor on attack`

**标题**：发起攻击时进入霸体

[superarmor on attack]发起攻击时进入霸体
	1	50

左边改1为进入霸体，改0则不进入

**官方示例：monstersample.mob**

```pvf
[superarmor on attack] 1 // 采取攻击姿势时变为超级护甲。
```

### `targeting attacker`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最后攻击自身的敌人
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting attacker] 0 // 1则为锁定最后攻击自己的敌人
```

**官方示例：newmonstersample.mob**

```pvf
[targeting attacker] 1 // 1则为锁定最后攻击自己的敌人。
```

### `targeting downed`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定倒地的敌人
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防

**官方示例：monstersample.mob**

```pvf
[targeting downed] 1 // 1则优先锁定倒地的敌人
```

### `targeting from direction`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定当前朝向的敌人
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting from direction] 1 // 1则为锁定当前面向方向的敌人
```

**官方示例：newmonstersample.mob**

```pvf
//120622 添加
[targeting from direction] 1 // 1则为锁定当前面向方向的敌人。
```

### `targeting high HP`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最高生命值
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting high HP] 1 // 1则为锁定高HP的敌人
```

### `targeting high level`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最高等级
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting high level] 0 // 1则为锁定高等级的敌人
```

### `targeting low HP`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最低生命值
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting low HP] 0 // 1则为锁定低HP的敌人
```

### `targeting low level`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最低等级
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting low level] 1 // 1则为锁定低等级的敌人
```

### `targeting low magical attack`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最低魔攻
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting low magical attack] 0 // 1则为锁定魔法攻击力低的敌人
```

### `targeting low magical defense`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最低魔防
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting low magical defense] 1 // 1则为锁定魔法防御力低的敌人
```

### `targeting low physical attack`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最低物攻
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting low physical attack] 1 // 1则为锁定物理攻击力低的敌人
```

### `targeting low physical defense`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最低物防
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting low physical defense] 0 // 1则为锁定物理防御力低的敌人
```

**官方示例：newmonstersample.mob**

```pvf
[targeting low physical defense] 1 // 1则为锁定物理防御力低的敌人。
```

### `targeting nearest`

**标题**：怪物AI逻辑

怪物AI逻辑：优先锁定最近的敌人
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting nearest] 1 // 1则为锁定近处的敌人
```

### `targeting on attack`

**标题**：怪物AI逻辑

怪物AI逻辑：攻击后重新判定目标
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting on attack] 1 // 1则为对目标攻击成功后重新设置目标
```

### `targeting on damage`

**标题**：怪物AI逻辑

怪物AI逻辑：受到攻击后重新判定目标
        1开启        0关闭

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting on damage] 0 // 1则为被目标击中一次后重新设置目标
```

### `targeting time term`

**标题**：怪物AI逻辑

怪物AI逻辑：锁定目标后，持续一定时长会重新寻找目标
1000 = 1秒（写0则永久锁定）

//其他AI逻辑：
[targeting time term]// 锁定目标后，持续一定时长会重新寻找目标
[targeting on attack]// 攻击后重新判定目标
[targeting on damage]// 受到攻击后重新判定目标
[targeting high level]// 优先锁定最高等级
[targeting low level]// 优先锁定最低等级
[targeting high HP]// 优先锁定最高生命值
[targeting low HP]// 优先锁定最低生命值
[targeting nearest]// 优先锁定最近的敌人
[targeting attacker]// 优先锁定最后攻击自身的敌人
[targeting from direction]// 优先锁定当前朝向的敌人
[targeting low physical attack]// 优先锁定最低物攻
[targeting low physical defense]// 优先锁定最低物防
[targeting low magical attack]// 优先锁定最低魔攻
[targeting low magical defense]// 优先锁定最低魔防
[targeting downed]// 优先锁定倒地的敌人

**官方示例：monstersample.mob**

```pvf
[targeting time term] 1000 // 锁定目标后经过此时间则重新设置目标 (0则不由时间重新设置)
```

### `unbreakable`

**标题**：霸体

霸体：不可被破坏

**官方示例：newmonstersample.mob**

```pvf
[unbreakable] -1 -1 -1 -1 // 耐久度, 恢复力, 近程防御力, 远程防御力。
```

### `undead`

**标题**：不死族

**官方示例：newmonstersample.mob**

```pvf
[undead]
// 类别列表
// 种族 : [human][beast][plant][insect][machine][organic][hybrid][undead][devil][spirit][dragon]
// AI : [melee combat][range combat][close-passive][close-carefully][close-tough][close-manace] // * AI 接近方式 参考
// 护甲 : [human armor][fort armor][divine armor]
// 其他 : [goblin][tau][lugaru], [fixture], [stay] 添加 [stay] 是在原地不动
```

### `waiting motion`

**标题**：静止动作

**官方示例：actionlibrary/sample.mob**

```pvf
[waiting motion]  `Animation_Goblin/Stay.ani`
//[waiting action]  `Action_Goblin/stay.act`
```

**官方示例：monstersample.mob**

```pvf
// 动画列表。没有的可以不写。或用 `` 输入则视为没有 //
[waiting motion] `BodyStay.ani` // 待机动作动画文件名
```

### `with blast`

**标题**：大概是狂龙之吼？

**官方示例：newmonstersample.mob**

```pvf
[with blast] // 与光龙的咆哮一起触发。
```

---

## 攻击信息（33 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `active status` | 此攻击附带的异常/增益状态 | attackinfosample.atk |
| `armor break` | 异常效果 | attackinfosample.atk |
| `attack direction` | 攻击方向 | attackinfosample.atk |
| `attack enemy` | 敌伤判定（禁用时不会造成伤害） | attackinfosample.atk |
| `attack friend` | 友伤判定（开启时可以对友方造成伤害） | attackinfosample.atk |
| `attack type` | 伤害类型（隔一行再编辑） | attackinfosample.atk |
| `bless` | 增益效果 | attackinfosample.atk |
| `blood` | 打击类型 | attackinfosample.atk |
| `curse` | 异常效果 | attackinfosample.atk |
| `cut` | 打击类型 | attackinfosample.atk |
| `damage bonus` | 伤害比率 | attackinfosample.atk、attackinfosamplebytool.atk |
| `damage reaction` | 伤害判定 | attackinfosample.atk |
| `elemental property` | 为该攻击或装备赋予属性 | attackinfosample.atk |
| `front` | 判定方向 | attackinfosample.atk |
| `haste` | 增益效果 | attackinfosample.atk |
| `hit direction` | 判定方向 | attackinfosample.atk |
| `hit down` | 攻击判定 | attackinfosamplebytool.atk |
| `hit info` | 打击类型 | attackinfosample.atk、attackinfosamplebytool.atk |
| `hit lift up` | 攻击判定 | attackinfosample.atk |
| `hit wav` | 命中音效 | attackinfosample.atk |
| `ignore defense` | ignore defense | attackinfosamplebytool.atk |
| `knuck back` | 击退 | attackinfosample.atk |
| `lift up` | 浮空值 | attackinfosample.atk |
| `lightning` | 异常效果 | attackinfosample.atk |
| `no blood` | 打击类型 | attackinfosamplebytool.atk |
| `no element` | no element | attackinfosample.atk |
| `physic` | 物理 | attackinfosample.atk |
| `push aside` | 平推值 | attackinfosample.atk |
| `slow` | 异常效果 | attackinfosample.atk |
| `stuck` | 命中率（正数减少 | attackinfosample.atk |
| `weakness` | 异常效果 | attackinfosample.atk、attackinfosamplebytool.atk |
| `weapon break` | 异常效果 | attackinfosample.atk |
| `weapon damage apply` | 开启改1 关闭改0 | attackinfosample.atk |

### `active status`

**标题**：此攻击附带的异常/增益状态

[active status]此攻击附带的异常/增益状态，异常/增益等级越高越容易施加成功
//记得在添加异常/增益词条的时候把注释和中文去掉
//1000 = 1秒
———————————————————————————
[blind]失明
	-1	-1	-1	-1	-1// 概率(%)，等级，持续时间，减少视野(%)，减少命中(%)
[freeze]冰冻
	-1	-1	-1// 概率(%)，等级，持续时间
[stone]石化
	-1	-1	-1	-1// 概率(%)，等级，持续时间，石化时附加固伤
[stun]眩晕
	-1	-1	-1// 概率(%)，等级，持续时间
[sleep]睡眠
	-1	-1	-1// 概率(%)，等级，持续时间
[hold]束缚
	-1	-1	-1// 概率，等级，持续时间
[slow]减速
	-1	-1	-1	-1	-1// 概率(%)，等级，持续时间，减少移速(%)，减少攻速(%)
[haste]加速
	-1	-1	-1	-1	-1// 概率(%)，等级，持续时间，增加移速(%)，增加攻速(%)
[confuse]混乱
	-1	-1	-1	-1// 概率(%)，等级，持续时间，第4个若施加对象为职业则不添加，若施加对象为怪物则补上1，代表施加成功后令怪物攻击友方
[poison]中毒
	-1	-1	-1	-1// 概率(%)，等级，持续时间，中毒总伤
[bleeding]出血
	-1	-1	-1	-1// 概率(%)，等级，持续时间，出血总伤
[burn]灼伤
	-1	-1	-1	-1// 概率(%)，等级，持续时间，灼伤总伤
[lightning]感电
	-1	-1	-1	-1// 概率(%)，等级，持续时间，感电总伤
[curse]诅咒
	-1	-1	-1	-1	-1	-1	-1// 概率(%)，等级，持续时间，减少力量，减少体力，减少智力，减少精神
[bless]祝福
	-1	-1	-1	-1	-1	-1	-1// 概率(%)，等级，持续时间，增加力量，增加体力，增加智力，增加精神
[weakness]虚弱
	-1	-1	-1	-1// 概率(%)，等级，持续时间，伤害减少比率（以剩余生命值计算，比如被施加虚弱的目标剩余200生命值，虚弱效果是0.3（30%），则打出的伤害减少60）
[weapon break]武器损坏
	-1	-1	-1	-1// 概率(%)，等级，持续时间，减少武器耐久
[armor break]防具损坏
	-1	-1	-1	-1// 概率(%)，等级，持续时间，减少防具耐久
[piercing]破甲
	-1	-1	-1	？// 概率(%)，等级，持续时间，最后一个暂不清楚是怎么减少防御的
[deelement]属性剥离
	-1	-1	-1// 概率(%)，等级，持续时间
[deadlystrike]致命一击
	-1	-1// 概率(%)，等级
———————————————————————————
{补充：破甲、属性剥离和致命一击的描述未经编写者测试，不一定准确}
———————————————————————————
你也可以在收尾部分添加[/active status]以为此攻击赋予多个异常效果，就像这样：

[active status]
[bleeding]
	35	11	15000	500
[/active status]

[active status]
[poison]
	25	11	15000	500
[/active status]
//以上代表有35%的概率和25%的概率，同时施加均为11级的，持续时长为15秒的出血和中毒异常效果，出血和中毒效果均为500总伤
———————————————————————————
// 灼伤词条位于彼诺修的烈焰护盾机制时，代表：
概率(%)，等级，持续时间，伤害，范围伤害，范围伤害选项(1表示范围伤害仅适用于敌军)、范围伤害间隔
//1000 = 1秒

// 彼诺修的烈焰护盾机制路径：
monster/soceress/action_keraha/proc_vinoshu.act

**官方示例：attackinfosample.atk**

```pvf
[active status] [curse] 37 100    // 最前面是攻击附带的异常状态种类。
                    // 从下面中选择一个
                    // 第二个是触发概率（写了 `[none] 则随意填写）
                    // 第三个是触发强度（写了 `[none] 则随意填写）

[active status] [blind] 100 20 3000 10 100        // 概率, 等级, 持续时间, 视野（%）, 硬直率增加（+）

[active status] [freeze] 100 20 3000            // 概率, 等级, 持续时间

[active status] [stun] 100 20 3000            // 概率, 等级, 持续时间

[active status] [slow] 100 20 10000 50 50        // 概率, 等级, 持续时间, 移速（%）, 攻速（%）

[active status] [haste] 100 20 3000 50 50        // 概率, 等级, 持续时间, 移速（%）, 攻速（%）

[active status] [stone] 100 20 3000 50        // 概率, 等级, 持续时间, 伤害值（+）

[active status] [sleep] 100 20 3000            // 概率, 等级, 持续时间

[active status] [confuse] 100 20 3000 1        // 概率, 等级, 持续时间, 为1时怪物陷入混乱，会攻击同伴。

[active status] [hold] 100 20 3000            // 概率, 等级, 持续时间

[active status] [weakness] 100 20 50            // 概率, 等级, 伤害减少比率（基于剩余 HP）

[active status] [armor break] 100 20 10000 15        // 概率, 等级, 持续时间, 耐久度消耗检查次数

[active status] [weapon break] 100 20 10000 15    // 概率, 等级, 持续时间, 耐久度消耗检查次数

[active status] [poison] 100 10 20000 1000         // 概率, 等级, 持续时间, 伤害

[active status] [lightning] 100 10 2000 100         // 概率, 等级, 持续时间, 伤害

[active status] [bleeding] 100 10 5000 10         // 概率, 等级, 持续时间, 伤害

[active status] [burn] 100 10 20000 1000 10 1 3000    // 概率, 等级, 持续时间, 伤害, 周围伤害, 周围伤害选项（为1时只对敌军造成周围伤害）, 周围伤害应用间隔（时间）

[active status] [bless] 100 10 5000 10 10 10 10    // 概率, 等级, 持续时间, 力量,体力,智力,精神

[active status] [curse] 100 10 5000 20 20 20 20    // 概率, 等级, 持续时间, 力量,体力,智力,精神

///// 攻击信息 (.atk) /////
[active status] [curse] 100 10 5000 20 20 20 20
- 使用方法与 equ 相同，但 `.atk` 文件中不包含 target 信息。
```

### `armor break`

**标题**：异常效果

异常效果：防具损坏

//减少防具的耐久度

**官方示例：attackinfosample.atk**

```pvf
[active status] [armor break] 100 20 10000 15        // 概率, 等级, 持续时间, 耐久度消耗检查次数
```

### `attack direction`

**标题**：攻击方向

[attack direction]攻击方向

[hit lift up] = 浮空
[hit horizon] = 平推
[hit down] = 击倒

**官方示例：attackinfosample.atk**

```pvf
[attack direction] [hit lift up]        // 攻击方向。在 [hit lift up] [hit horizon] [hit down] 中选择1个
```

### `attack enemy`

**标题**：敌伤判定（禁用时不会造成伤害）

[attack enemy]敌伤判定（禁用时不会造成伤害）
开启改1     禁用改0
————————————————————
若要为此攻击添加友伤判定，需添加词条：
[attack friend]
————————————————————
若要调整此攻击的伤害比率，需调整词条（没有的话要添加）：
[damage bonus]
————————————————————
若要为此攻击赋予异常状态，需添加词条：
[active status]

**官方示例：attackinfosample.atk**

```pvf
[attack enemy] 1            // 是否攻击敌人（除自己和友军外的所有目标）。默认值 1
```

### `attack friend`

**标题**：友伤判定（开启时可以对友方造成伤害）

[attack friend]友伤判定（开启时可以对友方造成伤害）
开启改1     禁用改0
————————————————————
若要为此攻击添加敌伤判定，需添加词条：
[attack enemy]
————————————————————
若要调整此攻击的伤害比率，需调整词条（没有的话要添加）：
[damage bonus]
————————————————————
若要为此攻击赋予异常状态，需添加词条：
[active status]

**官方示例：attackinfosample.atk**

```pvf
[attack friend] 0            // 是否攻击友军。默认值 0
```

### `attack type`

**标题**：伤害类型（隔一行再编辑）

[attack type] 伤害类型（隔一行再编辑）

[physic] = 物理伤害
[magic] = 魔法伤害
[ignore defense] = 无视防御的伤害

**官方示例：attackinfosample.atk**

```pvf
[attack type] [physic]        // 攻击类型。在 [physic] [magic] [ignore defense] 中选择1个
```

### `bless`

**标题**：增益效果

增益效果：祝福

**官方示例：attackinfosample.atk**

```pvf
[active status] [bless] 100 10 5000 10 10 10 10    // 概率, 等级, 持续时间, 力量,体力,智力,精神
```

### `blood`

**标题**：打击类型

打击类型：有出血视觉效果

**官方示例：attackinfosample.atk**

```pvf
[hit info] [cut] [blood] 50 1.0// 第一个是打击种类。在 [cut] [blow] [burn] [etc] [mana burn] 中选择1个，跟随武器子类型请用 ``
                //[mana burn] 时不减少 hp 而消耗 mp
                // 第二个是是否溅血。在 [blood] [no blood] 中选择1个
                // 第三个是命中时短暂停顿时间。跟随武器子类型请用 -1
                // 第四个是受击延迟时间倍数。跟随武器子类型请用 -1
```

### `curse`

**标题**：异常效果

异常效果：诅咒

**官方示例：attackinfosample.atk**

```pvf
[active status] [curse] 37 100    // 最前面是攻击附带的异常状态种类。
                    // 从下面中选择一个
                    // 第二个是触发概率（写了 `[none] 则随意填写）
                    // 第三个是触发强度（写了 `[none] 则随意填写）

[active status] [curse] 100 10 5000 20 20 20 20    // 概率, 等级, 持续时间, 力量,体力,智力,精神

///// 攻击信息 (.atk) /////
[active status] [curse] 100 10 5000 20 20 20 20
- 使用方法与 equ 相同，但 `.atk` 文件中不包含 target 信息。
```

### `cut`

**标题**：打击类型

打击类型：切割

**官方示例：attackinfosample.atk**

```pvf
[hit info] [cut] [blood] 50 1.0// 第一个是打击种类。在 [cut] [blow] [burn] [etc] [mana burn] 中选择1个，跟随武器子类型请用 ``
                //[mana burn] 时不减少 hp 而消耗 mp
                // 第二个是是否溅血。在 [blood] [no blood] 中选择1个
                // 第三个是命中时短暂停顿时间。跟随武器子类型请用 -1
                // 第四个是受击延迟时间倍数。跟随武器子类型请用 -1
```

### `damage bonus`

**标题**：伤害比率

伤害比率

0 = 100%

20 = 120%

-10 = 90%

**官方示例：attackinfosample.atk**

```pvf
[damage bonus] 10        // 伤害加成。%值

[damage bonus] -10    // 技能固有的攻击力
```

**官方示例：attackinfosamplebytool.atk**

```pvf
{exp}按照所写的百分比增加伤害(输入20则比当前伤害多造成20%的伤害){/exp}[damage bonus]
    //mkjung 120601 int-->float 修改
    {must1}{exp}要增加百分之多少的伤害？{/exp}{float(:)}

{exp}技能固有的攻击力{/exp}[damage bonus]
        //mkjung 120601 int-->float 修改
        {must1}{exp}{/exp}{float(:)}
```

### `damage reaction`

**标题**：伤害判定

[damage reaction]伤害判定
——————————————————
[none] = 无
[damage] = 有伤害判定
[down] = 有伤害的同时有击倒判定

**官方示例：attackinfosample.atk**

```pvf
[damage reaction] [damage]        // 受到攻击时的反应。在 [none] [damage] [down] [damage except human] 中选择1个
```

### `elemental property`

**标题**：为该攻击或装备赋予属性

为该攻击或装备赋予属性
[fire element] 火属性
[water element] 冰属性
[light element] 光属性
[dark element] 暗属性
[no element] 无属性

要为atk信息里添加异常状态的话，需赋予标签：
[active status]

**官方示例：attackinfosample.atk**

```pvf
[elemental property] [no element]            // 攻击的元素属性。在 [no element] [fire element] [water element] [dark element] [light element] 中选择1个。不写则默认 [no element]1
```

### `front`

**标题**：判定方向

判定方向：面前

**官方示例：attackinfosample.atk**

```pvf
//mkissue 120601 添加
[hit direction] [front]
```

### `haste`

**标题**：增益效果

增益效果：加速

**官方示例：attackinfosample.atk**

```pvf
[active status] [haste] 100 20 3000 50 50        // 概率, 等级, 持续时间, 移速（%）, 攻速（%）
```

### `hit direction`

**标题**：判定方向

判定方向

[back] = 身后
[front] = 面前

**官方示例：attackinfosample.atk**

```pvf
//mkissue 120601 添加
[hit direction] [front]
```

### `hit down`

**标题**：攻击判定

攻击判定：击倒

**官方示例：attackinfosamplebytool.atk**

```pvf
{must1}[hit down]
    //mkjung 120531 添加
```

### `hit info`

**标题**：打击类型

[hit info]打击类型

命中特效4选1：
[cut]=切割       //参考太刀普攻击中
[blow]=钝击    //参考钝器普攻击中
[burn]=灼烧    //命中后不会马上掉血而是缓慢下降
[etc]=其他       //暂不清楚

出血视觉效果2选1：
[blood]=有出血视觉效果
[no blood]=无出血视觉效果

选择完以后，在[blood]及[no blood]词条下
编辑命中卡肉时间（1000=1秒，或改成-1同步武器卡肉时间）和命中硬直比率，如下演示：
[hit info]

[cut]

[blood]
	150	1.5
//以上示例代表命中特效为切割，命中有出血视觉效果，卡肉时间0.15秒，命中硬直0.225秒
————————————{分割线}——————————————
[hit info]

[blow]

[no blood]
	-1	1.2
//以上示例代表命中特效为钝击，命中无出血视觉效果，卡肉时间跟随武器类型，命中硬直比率为1.2
————————————{分割线}——————————————
命中硬直比率：如果卡肉时间为0.2秒，命中硬直比率2.0，那么实际
                         造成的硬直效果为0.4秒
————————————{分割线}——————————————
加斜杠的用意：
一般用于需要赋予PVP属性时清晰划分开效果，比如如下展示
[pvp]
	[hit info]
	[blow]
	[no blood]
		-1	1.2
[/pvp]

[dungeon]
	[hit info]
	[blow]
	[no blood]
		100	1.5
[/dungeon]
//自行理解

**官方示例：attackinfosample.atk**

```pvf
[hit info] [cut] [blood] 50 1.0// 第一个是打击种类。在 [cut] [blow] [burn] [etc] [mana burn] 中选择1个，跟随武器子类型请用 ``
                //[mana burn] 时不减少 hp 而消耗 mp
                // 第二个是是否溅血。在 [blood] [no blood] 中选择1个
                // 第三个是命中时短暂停顿时间。跟随武器子类型请用 -1
                // 第四个是受击延迟时间倍数。跟随武器子类型请用 -1
```

**官方示例：attackinfosamplebytool.atk**

```pvf
//mkjung 120601 添加
    {exp}攻击信息{/exp}[hit info]
```

### `hit lift up`

**标题**：攻击判定

攻击判定：浮空

**官方示例：attackinfosample.atk**

```pvf
[attack direction] [hit lift up]        // 攻击方向。在 [hit lift up] [hit horizon] [hit down] 中选择1个
```

### `hit wav`

**标题**：命中音效

[hit wav]命中音效

调用npk文件里的音效

**官方示例：attackinfosample.atk**

```pvf
[hit wav] `HIT_SOUND`    // 命中时播放的音效标签
```

### `ignore defense`

**标题**：ignore defense

无视防御的伤害

**官方示例：attackinfosamplebytool.atk**

```pvf
{must1}{exp}无视防御攻击{/exp}[ignore defense]
    //mkjung 120531 添加
```

### `knuck back`

**标题**：击退

[knuck back]击退

添加此词条之后有击退效果
1 = 开启击退        -1 = 禁用击退

开启击退后，可以选择赋予更高的值来增加击退力度
比如1改成10，敌人会被一巴掌扇到地图边缘

**官方示例：attackinfosample.atk**

```pvf
[knuck back] 1            // 击退类型。0:普通 1:大幅击退 -1:不击退
// 以下值为 1 或 0
```

### `lift up`

**标题**：浮空值

浮空值
10 = 10%

**官方示例：attackinfosample.atk**

```pvf
[lift up] 30            // 向上击飞的力度
```

### `lightning`

**标题**：异常效果

异常效果：感电

**官方示例：attackinfosample.atk**

```pvf
[active status] [lightning] 100 10 2000 100         // 概率, 等级, 持续时间, 伤害
```

### `no blood`

**标题**：打击类型

打击类型：没有出血视觉效果

**官方示例：attackinfosamplebytool.atk**

```pvf
{must2}{exp}是否溅血（不出血）{/exp}[no blood]
    //mkjung 120601
    {must2}{exp}{/exp}{string}
```

### `no element`

**标题**：no element

无元素属性

**官方示例：attackinfosample.atk**

```pvf
[elemental property] [no element]            // 攻击的元素属性。在 [no element] [fire element] [water element] [dark element] [light element] 中选择1个。不写则默认 [no element]1
```

### `physic`

**标题**：物理

**官方示例：attackinfosample.atk**

```pvf
[attack type] [physic]        // 攻击类型。在 [physic] [magic] [ignore defense] 中选择1个
```

### `push aside`

**标题**：平推值

平推值
10 = 10%

若要让此攻击可以击退敌人，需赋予词条：
[knuck back]

**官方示例：attackinfosample.atk**

```pvf
[push aside] 200            // 向后方击退的力度
```

### `slow`

**标题**：异常效果

异常效果：减速

**官方示例：attackinfosample.atk**

```pvf
[active status] [slow] 100 20 10000 50 50        // 概率, 等级, 持续时间, 移速（%）, 攻速（%）
```

### `stuck`

**标题**：命中率（正数减少

命中率（正数减少，负数增加）
 -10 = 增加10%命中率

此标签在ATK信息里时，需填写-1000才能必定命中

**官方示例：attackinfosample.atk**

```pvf
[stuck] +2.2            // 硬直率变化值
```

### `weakness`

**标题**：异常效果

异常效果：虚弱

//以剩余生命值计算，比如被施加虚弱的目标剩余200生命值，虚弱效果是0.3（30%），则打出的伤害减少60

**官方示例：attackinfosample.atk**

```pvf
// 以下值为 1 或 0
[weakness]    3.0 5.5        // 有 3.0% 的概率造成 HP 5.5% 的伤害。

[active status] [weakness] 100 20 50            // 概率, 等级, 伤害减少比率（基于剩余 HP）
```

**官方示例：attackinfosamplebytool.atk**

```pvf
// 以下值为 1 或 0
{exp}X的概率造成HP百分比值的伤害{/exp}[weakness]
    {must1}{exp}概率{/exp}{float(:)}
    //mkjung 120531 修改 must1--> must2
    {must2}{exp}HP百分比值{/exp}{float(:)}
```

### `weapon break`

**标题**：异常效果

异常效果：武器损坏

//减少武器的耐久度

**官方示例：attackinfosample.atk**

```pvf
[active status] [weapon break] 100 20 10000 15    // 概率, 等级, 持续时间, 耐久度消耗检查次数
```

### `weapon damage apply`

**标题**：开启改1 关闭改0

开启改1     关闭改0

开启时适用装备攻击力加成
关闭时禁用装备攻击力加成

**官方示例：attackinfosample.atk**

```pvf
[weapon damage apply] 1        // 是否应用武器伤害。默认值 0。[ignore defense] 时应用物理伤害。
// 按攻击目标设定是否攻击。默认值可不写 //
```

---

## 技能（26 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `casting time` | 施法时间 | skillsample.skl |
| `command` | 技能指令 | skillsample.skl |
| `command key explain` | 手搓指令的释放介绍 | skillsample.skl |
| `consume item` | 第一个是释放技能要消耗的物品代码 | skillsample.skl |
| `consume MP` | MP 消耗 | skillsample.skl |
| `cool time` | 冷却时间 | skillsample.skl |
| `growtype maximum level` | 每个职业可通过sp点或tp点学得此技能的最高等级 | skillsample.skl |
| `level info` | 级别信息/动态数据 | skillsample.skl、skillscriptmoduleseparationsample.skl |
| `level property` | 游戏内的技能属性 | skillsample.skl、skillscriptmoduleseparationsample.skl |
| `maximum level` | 最高等级 | skillsample.skl |
| `name` | 在游戏中所显示的第1个名字 | skillsample.skl |
| `pre required skill` | 学得所需的前置技能 | skillsample.skl |
| `purchase cost` | 学得此技能所需的sp点 | skillsample.skl |
| `pvp` | 决斗场中的效果 | skillsample.skl |
| `required level` | 学习等级 | skillsample.skl |
| `required level range` | 等级间隔 | skillsample.skl |
| `second growtype maximum level` | 觉醒之后可学得的最高等级 | skillsample.skl |
| `shake screen` | 释放技能在部分时候的屏幕抖动效果 | skillsample.skl |
| `skill command advantage` | — | skillsample.skl |
| `skill fitness growtype` | 为职业赋予这个技能 | skillsample.skl |
| `skill fitness second growtype` | 这个标签可为此技能添加觉醒限制 | skillsample.skl |
| `skill under cooltime effect` | 施放过后会一同进入冷却时间的技能 | skillsample.skl |
| `special purchase cost` | 学得此技能所需的tp点 | skillsample.skl |
| `start cool time` | 开始冷却 | skillsample.skl |
| `static data` | 静态数据 | skillsample.skl |
| `weapon effect type` | 伤害类型 | skillsample.skl |

### `casting time`

**标题**：施法时间

施法时间
100=0.1秒

**官方示例：skillsample.skl**

```pvf
[casting time] 1000 500 // 咏唱时间。毫秒单位。等级1，最终等级。
```

### `command`

**标题**：技能指令

技能指令，比如“←→+Z”以默认的手搓指令释放鬼剑士的【十字斩】等等
↑=`(UP)`
↓=`(DOWN)`
←=`(LEFT)`
→=`(RIGHT)`
Z=`(SKILL)`
普攻=`(ATTACK)`
跳跃=`(JUMP)`
空格键=`(BUFF)`

{6=`(键位)`} 是需要按的键位
{8=`,`} 是衔接下一个按键的代码
{8=`&`} 是按住方向键之后按指令键的代码

比如：
	{6=`(RIGHT)`}
	{8=`,`}
	{6=`(BUFF)`}
为按一下前进+空格键以默认的手搓指令释放鬼剑士的【刀魂之卡赞】

再比如：
	{6=`(UP)`}
	{8=`&`}
	{6=`(SKILL)`}
为按住上+Z以默认的手搓指令释放鬼剑士的【鬼斩】，
//需要注意的是按住类手搓指令只能绑一个移动键
//以及，若本身就有指令的技能是无法通过PVF修改按住类指令的

**官方示例：skillsample.skl**

```pvf
[command] // 操作方法。
(SKILL) (ATTACK) & // 写入按下时需要按住的键，最后用&结束。没有则不写也可以。
(LEFT) 100, (DOWN)! (RIGHT) // 由键列表中键的组合和延迟时间构成一个输入。
`DOWN` // 输入之间用 !（150ms）、（300ms）~（1000ms）之一分隔。
// 检查类型可选择 `DOWN` `DOWN ONCE` `UP` `UP ONCE` 之一。
// 可输入的指令：(LEFT) (RIGHT) (UP) (DOWN) (SKILL) (ATTACK) (JUMP) (CREATURE) (BUFF)。
[/command]
```

### `command key explain`

**标题**：手搓指令的释放介绍

**官方示例：skillsample.skl**

```pvf
[command key explain] `指令: → ← ⓩ` // 指定指令说明的标签。
```

### `consume item`

**标题**：第一个是释放技能要消耗的物品代码

第一个是释放技能要消耗的物品代码
第二个是最低等级的消耗
第三个是最高等级的消耗

示例：
	3037	1	5
代表最低等级将消耗1个无色小晶块，并随等级逐渐增加消耗数量，最高等级将消耗5个无色小晶块

**官方示例：skillsample.skl**

```pvf
[consume item] // 使用技能所需的物品。
1001 1 1 // 物品索引，等级1时的消耗数，最高等级时的消耗数（通常登记无色小晶块）。
1002 2 5
[/consume item]
```

### `consume MP`

**标题**：MP 消耗

使用技能时消耗的魔法值
左边最低等级消耗     右边最高等级消耗

//示例：
	[consume MP]
		7723	1123

以上示例代表1级消耗7723魔法值，并随等级逐渐减少需消耗的魔法值，满级消耗1123魔法值

**官方示例：skillsample.skl**

```pvf
[consume MP] 10.0 300.0 // 每次消耗的MP。等级1和最高等级时的值。
```

### `cool time`

**标题**：冷却时间

换装和道具冷却时间

赋予词条对象为技能时，左边最低等级冷却，右边最高等级冷却

1000=1秒

**官方示例：skillsample.skl**

```pvf
[cool time] 1000 2000 // 使用后阻止主动技能和消耗品使用的时间。毫秒单位，仅对主动技能有效。
// 等级1，满级。
```

### `growtype maximum level`

**标题**：每个职业可通过sp点或tp点学得此技能的最高等级

每个职业可通过sp点或tp点学得此技能的最高等级，比如
[growtype maximum level]
	0	2	0	0	0
代表只有剑魂能把这个技能学到2级

1男鬼剑士 2剑魂            3鬼泣         4狂战士      5阿修罗
1女格斗     2女气功        3女散打     4女街霸      5女柔道家
1女魔法师 2元素师        3召唤师     4战斗法师  5魔道学者
1男圣职者 2男圣骑士     3蓝拳圣使 4男驱魔师   5复仇者
1神枪手     2漫游枪手     3枪炮师    4机械师       5弹药专家
1暗夜使者 2刺客            3死灵术士  4忍者         5影舞者
1男魔法师 2元素爆破师 3冰结师

//赋予技能等级之后，还需要将技能加入目标职业的技能树坐标
sp技能树路径：clientonly/skilltree/职业_sp.co
tp技能树路径：clientonly/skilltree/职业_tp.co

**官方示例：skillsample.skl**

```pvf
[growtype maximum level] 2 2 2 3 // 通过技能购买可获得的最高等级。
```

### `level info`

**标题**：级别信息/动态数据

级别信息/动态数据
可以随技能等级提升的数据，修改此数据可以影响到实战，而无法随等级提升的是静态数据[static data]

第1横排的内容是会生效的动态数据的数量，不计入该技能的第1级，所以可以算第0级
第1横排的内容为4时，代表从第2横排开始左往右能生效4个动态数据，所以第2横排才能算作此技能的第1级
—————————————————————————————
每个等级从左往右数就是[level property]会使用<int>、<float1>、<float2>
按照0、1、2、3的位置调用的数值
//示例：
[level property]
	1	99                               ←1级显示到99级
	`银弹装弹数 : <int>发`      ←技能属性(添加<>以调用下方3个数值
	                                                                                    为1组的数据)
	-1	0	1.0                        ←调用动态数据从左往右数的第0位
[/level property]
—————————————————————————————
技能从1级升到2级后就会调用第3横排的数据，5级升到6级后就会调用第7横排的数据，以此类推

**官方示例：skillsample.skl**

```pvf
[level info] // 硬编码中使用的各级别资料集合（技能等级不同值也不同的资料）。
2 // 各级别资料的数量。
// 资料1 资料2
1 20 // 第一行为等级1。依次写下资料1和2。
2 30 // 重复至满级。
4 40
6 50
8 60
[/level info]
```

**官方示例：skillscriptmoduleseparationsample.skl**

```pvf
[level info]
2
// 0.攻击力% 1.浮空力：修改时需修改 [level property]。
100 350
106 368
111 387
117 405
122 424
128 442
133 461
139 479
145 497
150 516
156 534
161 553
167 571
173 589
178 608
184 626
189 645
195 663
200 682
206 700
[/level info]
```

### `level property`

**标题**：游戏内的技能属性

游戏内的技能属性

修改此标签里的内容仅影响显示，需搭配能影响实战的
[level info]（动态数据）或者[static data]（静态数据）使用
—————————————————————————————
//示例1：
[level property]
	1	99                               ←1级显示到99级
	`银弹装弹数 : <int>发`      ←技能属性(添加<>以调用下方3个数值
	                                                                                    为1组的数据)
	-1	0	1.0                        ←调用动态数据从左往右数的第0位
[/level property]
—————————————————————————————
//示例2：
[level property]
	1	99                                          ←1级显示到99级
	`鬼印珠多段攻击间隔 : <float2>秒`    ←技能属性(添加<>以调用下方
                                                                                3个数值为1组的数据)
	1	1	0.001                               ←调用静态数据从左往右数的第1位
[/level property]
—————————————————————————————
示例第二排引号后边的内容可以自己编辑，也可以打上
<int>、<float1>、<float2>来调用1.0、0.1、0.01、0.001的内容，
有一个<>就会调用一组数据，
比如膝撞的`物理攻击力 : <int>%% + <int>`在游戏里只会显示一排，但在PVF里会调用两组动/静态数据

<int>：特殊效果的等级、数量、技能倍率、技能固伤、穿刺力、吸收伤害、减少延迟、范围、异常抗性、增加面板、技能大小

<float1>：特殊效果的概率、命中率、浮空力、发动速度、暴击率、持续时间、前摇、攻击间隔、增加速度、激活使用技能的时间、蓄力时间

<float2>：同<float1>
//提示：<float2>相比<float1>可以显示更详细的数值，<float1>在部分情况遇到小数点时会取整，显示大概的数值
—————————————————————————————
//示例第三排的3个数值为1组的内容分别为
第1个 : 为正数时调用静态数据（与第2个数字写一样的）
            为负数时调用动态数据
     -2 = 固伤伤害
     -3 = 中毒伤害
     -4 = 出血伤害
     -5 = 灼伤伤害
     -6 = 感电伤害

第2个 : 动/静态数据位置，0是从左往右数第1个，1是从左往右数第2个，以此类推

第3个 : 调用动/静态数据后在游戏内技能属性显示出来的数值：
     `1.0（或与1.0相近的）：范围、数量、技能倍率、技能固伤、速度、穿刺力、发动速度、特殊效果的等级、增加面板、技能大小`

     `0.1（或与0.1相近的）：浮空力、命中率、暴击率、特殊效果的概率`

     `0.001（或与0.001相近的）：持续时间`

//1.0=显示100%内容（比如倍率、数量等）
//0.1=显示10%内容（比如概率的200在游戏内是20%）
//0.001=显示0.1%内容（持续时间的1000在游戏内是1秒）

**官方示例：skillsample.skl**

```pvf
[level property] // 技能特性说明。
1 10 // 适用的等级区间。
`以<整数>%概率格挡<小数1>%的物理攻击。` // 说明。放置参数的部分选择<整数> <小数1> <小数2>之一填写。
// <小数1>显示小数点后1位，<小数2>显示小数点后2位。
0 1 1.0 // 第二个要放入的参数的整数资料索引。等级1~满级，相乘的值。下同重复。
2 3 1.0 // 第二个要放入的参数的整数资料索引。等级1~满级，相乘的值。下同重复，最多5行。
-1 0 1.0 // 第一个值为-1则从[level info]读取。第二个值是参考第几个资料。
// -1 百分比伤害。
// -2 独立。
// -3 中毒。
// -4 出血。
// -5 灼伤。
// -6 感电。
// -7 石化。
[/level property]

[level property] // 技能特性说明。
11 99 // 适用的等级区间。
`以<整数>%概率格挡<小数1>%的物理攻击，以<整数>%概率格挡<小数2>%的魔法攻击。`
0 1 1.0 // 第一个要放入的参数的整数资料索引。等级1~满级，相乘的值。
2 3 1.0 // 第二个要放入的参数的整数资料索引。等级1~满级，相乘的值。下同重复。
0 1 1.0
4 5 1.0
[/level property]
```

**官方示例：skillscriptmoduleseparationsample.skl**

```pvf
[level property]
1 99
<12::antiair_upper_level_property>
-1 1 0.285714285714 // 0.285714285714 : 100 / 1级时的浮空力。
-1 0 1.0
[/level property]
```

### `maximum level`

**标题**：最高等级

拥有此词条对象为技能时，限制绝对的最大可学得等级，也就是不止通过sp点（比如装备、卡片、称号等等）可以提升的最大等级

**官方示例：skillsample.skl**

```pvf
[maximum level] 10 // 通过所有手段可提升的最大等级（包含物品、Buff等）。
```

### `name`

**标题**：在游戏中所显示的第1个名字

**官方示例：skillsample.skl**

```pvf
[name] // 指定技能名称的标签，通常与<12:: > Skill.kor.str文件链接。
```

### `pre required skill`

**标题**：学得所需的前置技能

学得所需的前置技能

左边前置技能编号    右边等级需求

//若设定不止一个前置技能，则按照
`左、右、左、右`
的顺序来赋予前置技能

**官方示例：skillsample.skl**

```pvf
[pre required skill] // 学习技能前必须先学习的技能列表。
3 2 // 依次为技能索引，等级。
11 1
[/pre required skill] // 必须用此标签闭合。
```

### `purchase cost`

**标题**：学得此技能所需的sp点

学得此技能所需的sp点

在数字的右边跟一个灰箭头即可设置下一级所需sp点
你也可以只设置1个数字来统一技能每一级所需sp点

**官方示例：skillsample.skl**

```pvf
[purchase cost] // 各级别购买所需的SP。此数值的数量即成为最大等级的数量。
100 // 获得等级1所需的SP。
200 // 获得等级1后获得等级2所需的SP。
200 // 若中途截断，则之后均使用该值。
[/purchase cost] // 必须用此标签闭合。
```

### `pvp`

**标题**：决斗场中的效果

**官方示例：skillsample.skl**

```pvf
[pvp]
// 此标签内的数值仅在决斗场中适用。
[/pvp]
```

### `required level`

**标题**：学习等级

最低学得等级

**官方示例：skillsample.skl**

```pvf
[required level] 10 // 学习技能所需角色的最低等级。
```

### `required level range`

**标题**：等级间隔

技能升级间隔

2代表每2级可通过sp点或tp点升1级

**官方示例：skillsample.skl**

```pvf
[required level range] 3 // 需求等级的区间。
```

### `second growtype maximum level`

**标题**：觉醒之后可学得的最高等级

觉醒之后可学得的最高等级
搭配[skill fitness second growtype]使用

移除此标签和[skill fitness second growtype]标签即可解除觉醒限制

//示例：
[second growtype maximum level]
	0	0	2	0	0	0	0	0	0	0	0	0
//以上代表只有花花能把这个技能学到2级

与[growtype maximum level]不同，添加觉醒限制之后的技能要扩充最高学得等级需在等级右边追加一个0，要是看不懂的话按下面的序号从左往右数并按照职业位置赋予等级即可：
1男鬼剑士 3剑魂            5鬼泣         7狂战士      9阿修罗
1女格斗     3女气功        5女散打     7女街霸      9女柔道家
1女魔法师 3元素师        5召唤师     7战斗法师   9魔道学者
1男圣职者 3男圣骑士     5蓝拳圣使 7男驱魔师   9复仇者
1神枪手     3漫游枪手    5枪炮师      7机械师      9弹药专家
1男魔法师 3元素爆破师 5冰结师

**官方示例：skillsample.skl**

```pvf
// - 与原有的[growtype maximum level]用法相同（在此指定觉醒技能。1次、2次觉醒）。
[second growtype maximum level] 0 0 1 0 0 0 0 0 0 0
```

### `shake screen`

**标题**：释放技能在部分时候的屏幕抖动效果

释放技能在部分时候的屏幕抖动效果
比如狂战士释放技能【暴走】在读条结束之后会抖动屏幕
左边对应抖动强度      右边对应抖动时间，100=0.1秒

**官方示例：skillsample.skl**

```pvf
[shake screen] 2 200 // 在特定情况下震动屏幕。
// 2 == 屏幕震动强度。
// 200 == 屏幕震动时间。
// 注意：屏幕震动是硬编码，因此。
// 若输入了此值，必须告知程序员。
// 在何种情况下需要震动屏幕。
```

### `skill command advantage`

以手搓指令释放技能时所获得的收益

左边若为20将减少最大冷却时间2%	 右边若为50将减少魔法值消耗5%

同时会在职业的头上显示你搓了哪些指令

**官方示例：skillsample.skl**

```pvf
[skill command advantage] 10 20 // 冷却时间减少比率（0.1%单位），MP消耗量减少比率（0.1%单位） // 通过指令输入技能时可获得的增益。
```

### `skill fitness growtype`

**标题**：为职业赋予这个技能

为职业赋予这个技能，需搭配代码：[growtype maximum level]
                                    //不然的话就光是有技能而无法学得技能

比如【崩山击】
[skill fitness growtype]
	0	1	2	3	4
[/skill fitness growtype]
代表鬼剑士全部职业都可以学得

再比如，还是【崩山击】
[skill fitness growtype]
	0	2	4
[/skill fitness growtype]
代表只有鬼剑士、鬼泣、阿修罗可以学得

输入数字可为职业赋予此技能
- 0男鬼剑士 1剑魂            2鬼泣         3狂战士      4阿修罗
- 0女格斗     1女气功        2女散打     3女街霸      4女柔道家
- 0女魔法师 1女元素师     2召唤师     3战斗法师  4魔道学者
- 0男圣职者 1男圣骑士     2蓝拳圣使 3男驱魔师   4复仇者
- 0神枪手     1漫游枪手     2枪炮师     3机械师      4弹药专家
- 0暗夜使者 1刺客            2死灵术士  3忍者         4影舞者

//赋予技能之后，还需要将技能加入目标职业的技能树坐标
sp技能树路径：clientonly/skilltree/职业_sp.co
tp技能树路径：clientonly/skilltree/职业_tp.co

**官方示例：skillsample.skl**

```pvf
[skill fitness growtype] // 注册可正式学习技能的成长类型编号。
3
[/skill fitness growtype]
```

### `skill fitness second growtype`

**标题**：这个标签可为此技能添加觉醒限制

这个标签可为此技能添加觉醒限制

搭配[second growtype maximum level]使用

移除此标签和[second growtype maximum level]标签即可解除觉醒限制

**官方示例：skillsample.skl**

```pvf
// - 与原有的[skill fitness growtype]用法相同。
[skill fitness second growtype]
2
[/skill fitness second growtype]
```

### `skill under cooltime effect`

**标题**：施放过后会一同进入冷却时间的技能

施放过后会一同进入冷却时间的技能，
将其他技能编号写入即可设置

**官方示例：skillsample.skl**

```pvf
// 等级1，满级。
[skill under cooltime effect] // 此技能发动时，同时进入冷却时间的技能列表。
12
11
[/skill under cooltime effect]
```

### `special purchase cost`

**标题**：学得此技能所需的tp点

学得此技能所需的tp点

在数字的右边跟一个灰箭头即可设置下一级所需tp点
你也可以只设置1个数字来统一技能每一级所需tp点

**官方示例：skillsample.skl**

```pvf
[special purchase cost] // 若有此标签，则购买需要TP而非SP。
1 // 各级别购买所需的TP数值。
[/special purchase cost]
```

### `start cool time`

**标题**：开始冷却

对局开始时的冷却时间限制
20000代表对局开始时有20秒禁用时间

1000=1秒

**官方示例：skillsample.skl**

```pvf
[start cool time] 10000 // 若希望决斗场、死亡之塔、战争区域等一开始就处于冷却时间，在此输入大于0的数字。
```

### `static data`

**标题**：静态数据

静态数据
无法随等级提升的技能数据，修改此数据可以影响到实战，你也可以把动态数据[level info]全改成一个数据来达到伪静态数据的结果（笑）

//通用：
有些技能的静态数据比如鬼泣的[封印解除]是可以把别的技能编号补充进去以达到用被动增强主动的效果
以及[攻击类型转换]，将其他主动技能编号写入即可在游戏内切换转职后技能的伤害加成

//魔法师：
`召唤师`、`魔道学者`的召唤物静态数据里会出现的怪物编号
[比如魔道学者用变异苍蝇拍击杀怪物后，以大成功召唤出变异牛头巨兽，静态数据里第8位正好有61154编号，对应怪物编号61154的变异牛头巨兽]
这代表此技能将生效于召唤物，所以这也是为什么召唤物的面板和技能是分开写的

//机械师：
机械师的机器人比较特殊，生效信息并没有写在静态数据里，但是可以通过
monster/gunner/robot
的路径查看机器人面板信息

//示例：
[level property]
	1	99                                          ←1级到99级显示
`鬼印珠多段攻击间隔 : <float2>秒`    ←技能属性(添加<>以调用下方
                                                                                3个数值为1组的数据)
	1	1	0.001                               ←调用静态数据从左往右数的第1位
[/level property]
静态数据从左往右数就是[level property]会使用<int>、<float1>、<float2>
按照0、1、2、3的位置调用的数值

**官方示例：skillsample.skl**

```pvf
[static data] // 硬编码中使用的固定资料集合（技能等级提升也不改变的值）。
1
10
100
300
300
400
[/static data]
```

### `weapon effect type`

**标题**：伤害类型

伤害类型
物理伤害：`[physical]`
魔法伤害：`[magical]`

**官方示例：skillsample.skl**

```pvf
[weapon effect type] `[none]` // MP、冷却时间将跟随武器的哪种参数。可选择 `[none]` `[physical]` `[magical]` 之一。
```

---

## 装备（18 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `animation job` | - 职业动画 - 使用该动画的职业 | equipmentsample.equ |
| `bleeding resistance` | 出血抗性 | equipmentsample.equ |
| `cast speed` | - 施放速度 - 施放速度 (0 | equipmentsample.equ |
| `equipment magical attack` | - 魔法攻击力 - 魔法攻击力(地下城) 魔法攻击力(决斗场) | equipmentsample.equ |
| `equipment magical defense` | - 魔法防御力 - 魔法防御力(地下城) 魔法防御力(决斗场) | equipmentsample.equ |
| `equipment physical attack` | - 物理攻击力 - 物理攻击力(地下城) 物理攻击力(决斗场) | equipmentsample.equ |
| `equipment physical defense` | - 物理防御力 - 物理防御力(地下城) 物理防御力(决斗场) | equipmentsample.equ |
| `grade` | - 装备实际等级 - 时装品级 // 1 普通 - 装备的等级 (佩戴等级 +0 | avatarsample.equ、equipmentsample.equ |
| `HP MAX` | HP 最大值 | equipmentsample.equ |
| `if` | - 如果 - ####1 | equipmentsample.equ、equipmentsamplebytool.equ |
| `move wav` | - 掉落、移动、使用音效 - 移动/拾取时音效 - 移动/拾取音效 - 掉落在地上、移动道具时（包含装备）发出的声音 | avatarsample.equ、creaturesample.equ、equipmentsample.equ |
| `MP MAX` | MP 最大值 | equipmentsample.equ |
| `need material` | - 购买所需道具 - 所需材料道具索引 | equipmentsample.equ |
| `poison resistance` | 中毒抗性 | equipmentsample.equ |
| `rarity` | 稀有度 | equipmentsample.equ |
| `skill levelup` | - 技能等级提升 - 装备时提升的技能和等级限制 | equipmentsample.equ、equipmentsamplebytool.equ |
| `then` | - 然后 - 1 | equipmentsamplebytool.equ |
| `value` | - 出售价格 - 玩家卖给商店的金额 | equipmentsample.equ |

### `animation job`

**标题**：- 职业动画 / - 使用该动画的职业

### 职业动画

| 字段 | 职业 |
| --- | --- |
| [swordman] | 鬼剑士 |
| [demonic swordman] | 黑暗武士 |
| [fighter] | 格斗家(女) |
| [at fighter] | 格斗家(男) |
| [gunner] | 神枪手(男) |
| [at gunner] | 神枪手(女) |
| [mage] | 魔法师(女) |
| [at mage] | 魔法师(男) |
| [thief] | 暗夜使者 |
| [at swordman] | 女鬼剑 |

**官方示例：equipmentsample.equ**

```pvf
[animation job] `[gunner]`			// 使用该动画的职业。只有异性角色共享一个脚本时才需要写。

[animation job] `[fighter]`			// 动画的职业。equ 中只有一个职业动画的话可以没有。

[animation job] `[at fighter]`			// 动画的职业。equ 中只有一个职业动画的话可以没有。
```

### `bleeding resistance`

**标题**：出血抗性

出血异常抗性

**官方示例：equipmentsample.equ**

```pvf
[bleeding resistance] 32			// 出血抗性
```

### `cast speed`

**标题**：- 施放速度 / - 施放速度 (0

单位：0.1%

**官方示例：equipmentsample.equ**

```pvf
[cast speed] 30					// 施放速度 (0.1% 单位)
```

### `equipment magical attack`

**标题**：- 魔法攻击力 / - 魔法攻击力(地下城) 魔法攻击力(决斗场)

装备魔法攻击

**官方示例：equipmentsample.equ**

```pvf
[equipment magical attack] +100 +100		// 魔法攻击力(地下城) 魔法攻击力(决斗场)
```

### `equipment magical defense`

**标题**：- 魔法防御力 / - 魔法防御力(地下城) 魔法防御力(决斗场)

装备魔法防御力

**官方示例：equipmentsample.equ**

```pvf
[equipment magical defense] +38 +38		// 魔法防御力(地下城) 魔法防御力(决斗场)
```

### `equipment physical attack`

**标题**：- 物理攻击力 / - 物理攻击力(地下城) 物理攻击力(决斗场)

装备物理攻击

**官方示例：equipmentsample.equ**

```pvf
[equipment physical attack] +100 +100		// 物理攻击力(地下城) 物理攻击力(决斗场)
```

### `equipment physical defense`

**标题**：- 物理防御力 / - 物理防御力(地下城) 物理防御力(决斗场)

装备物理防御力

**官方示例：equipmentsample.equ**

```pvf
[equipment physical defense] +25 +25		// 物理防御力(地下城) 物理防御力(决斗场)
```

### `grade`

**标题**：- 装备实际等级 / - 时装品级 // 1 普通 / - 装备的等级 (佩戴等级 +0

- 影响增幅强化所加的具体数值，与增幅强化的数值成正比
- 在装备、道具中为**掉落等级**，史诗装备则为对应等级的深渊
>掉落区间为±5级，也就是说写10时，有概率从击杀的5—15级怪物身上掉落
1. [深渊派对文件](etc/hellparty.etc)
2. [深渊怪物爆率的文件路径](etc/itemdropinfo_monster_hell.etc)

**官方示例：avatarsample.equ**

```pvf
[grade] 2                // 时装品级 // 1 普通，2 高级，3 稀有
```

**官方示例：equipmentsample.equ**

```pvf
[grade] 3					// 装备的等级 (佩戴等级 +0:普通, +2:稀有 +3:传说 +4:神器 +5:史诗)
```

### `HP MAX`

**标题**：HP 最大值

最大生命值

**官方示例：equipmentsample.equ**

```pvf
// 变化能力值。变化量为 0 的可以不写。前面的 + 号可以省略 //
[HP MAX] +10					// HP 最大值
```

### `if`

**标题**：- 如果 / - ####1

如果

作为特效或效果的某种触发条件使用

**官方示例：equipmentsample.equ**

```pvf
// 攻击时 1% 几率使自己 30 秒内僵直度增加 10000。
[if]
[cooltime] 60000
[attack success] 1
[/if]
```

**官方示例：equipmentsamplebytool.equ**

```pvf
// 条件(if)##########################
[if]
	//####1.1.1 trigger ######
	//1.1.1.1 attack success #
	{exp}攻击成功时的值{/exp}[attack success]
		{must1}{exp}值为 2 时使用 attack condition 的 stuck{/exp}{int(1:2)}
	[!attack success]

	//1.1.1.2 check damage #
	{exp}受击时 HP 总扣除伤害 %{/exp}[check damage]
		{must1}{exp}% 或 +{/exp}{string}
		{must2}{exp}数值{/exp}{int(0:)}
	[!check damage]

	//1.1.1.3 event attack success #
	{prereq}[increase damage]|[increase critical damage]|[weakness]{/prereq}{exp}仅在与 increase damage, increase critical damage, weakness 标签组合时使用{/exp}[event attack success]
		{must1}{exp}攻击成功时的值{/exp}{int(0:)}
	[!event attack success]

	//1.1.1.4 after attack #
	{prereq}[combo]|[aerial]{/prereq}{exp}仅在与 combo, aerial 标签组合时使用{/exp}[after attack]
		{must1}{exp}攻击成功时的值{/exp}{int(0:)}
	[!after attack]

	//1.1.1.5 hit #
	[hit]
		{must1}{exp}受击时的值{/exp}{int(0:)}
	[!hit]

	//1.1.1.6 event hit #
	[event hit]
		{must1}{exp}受击时的值{/exp}{int(0:)}
	[!event hit]

	//1.1.1.7 my active status on #
	[my active status on]
		{must1}{exp}状态变化{/exp}{string}
	[!my active status on]

	//1.1.1.8 casting #
	[casting]
		{must1}{exp}施放技能使用时的情况检查{/exp}{int(0:)}
	[!casting]

	//1.1.1.9 use skill #
	[use skill]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能编号{/exp}{int(0:)}
	[!use skill]

	//1.1.1.10 event use skill #
	[event use skill]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能编号{/exp}{int(0:)}
	[!event use skill]

	//1.1.1.11 my death #(标签弃用)
	//2010-02-10 之后禁止使用

	//1.1.1.12 party death #
	{exp}指定队友死亡时{/exp}[party death]
		{must1}{exp}{/exp}{int(1:1)}
	[!party death]

	//1.1.1.13 use command #
	{exp}指定输入指令时{/exp}[use command]
		{must1}{exp}{/exp}{int(1:1)}
	[!use command]

	//1.1.1.14 revive #
	{exp}指定自己复活时{/exp}[revive]
		{must1}{exp}{/exp}{int(1:1)}
	[!revive]

	//1.1.1.15 time #
	[time]
		{must1}{exp}时间间隔{/exp}{int(0:)}
		{must2}{exp}循环与否{/exp}{int(0:1)}
		{must3}{exp}先冷却时间 {/exp}{int(0:)}
	[!time]

	//1.1.1.16 set my state #
	{exp}指定自己状态变更时{/exp}[set my state]
		{must1}{exp}{/exp}{int(1:1)}
	[!set my state]

	//1.1.1.17 change status #
	{exp}条件符合时应用选项{/exp}[change status]
		{must1}{exp}状态{/exp}{string}
		{must2}{exp}比较方法{/exp}{string}
		{must3}{exp}比较单位{/exp}{string}
		{must4}{exp}数值{/exp}{int(0:)}
	[!change status]

	//1.1.1.18 change status in range #
	{prereq}[apply status in range]{/prereq}{exp}数值1~数值2符合时应用选项{/exp}[change status in range]
		{must1}{exp}状态{/exp}{string}
		{must2}{exp}数值1{/exp}{int(0:)}
		{must3}{exp}数值2{/exp}{int(0:)}
	[!change status in range]

	//1.1.1.19 skill frame trigger #
	[skill frame trigger]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
		{must3}{exp}动画名称{/exp}{string}
		{must4}{exp}帧{/exp}{int(0:)}
	[!skill frame trigger]

	//####1.1.2 state ######
	//1.1.2.1 module #
	{exp}模块{/exp}[module]
		{string}
		{!string}
	[/module]

	//1.1.2.2 attacker #
	{exp}攻击成功时控制攻击类型{/exp}[attacker]
		{must1}{exp}类型{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
	[!attacker]

	//1.1.2.3 element #
	{prereq}[attack success]|[hit]{/prereq}{exp}攻击成功时控制攻击类型{/exp}[element]
		{must1}{exp}属性{/exp}{string}
	[!element]

	//1.1.2.4 character #
	{exp}只有自己是该职业时才检查条件{/exp}[character]
		{must1}{exp}职业{/exp}{string}
	[!character]

	//1.1.2.5 distance #
	{prereq}[attack success]|[hit]{/prereq}{exp}距离{/exp}[distance]
		{must1}{exp}{/exp}{int(0:)}
	[!distance]

	//1.1.2.6 my active status #
	{exp}检查自己的状态变化{/exp}[my active status]
		{must1}{exp}状态{/exp}{string}
	[!my active status]

	//1.1.2.7 my state #
	{exp}检查自己的状态{/exp}[my state]
		{must1}{exp}状态{/exp}{string}
	[!my state]

	//1.1.2.8 target state #
	{exp}检查敌人状态{/exp}[target state]
		{must1}{exp}状态{/exp}{string}
	[!target state]

	//1.1.2.9 target active status #
	{exp}检查自己攻击的敌人的状态变化{/exp}[target active status]
		{must1}{exp}状态变化{/exp}{string}
	[!target active status]

	//1.1.2.10 attack type #
	{prereq}[attack success]|[hit]{/prereq}{exp}{/exp}[attacker type]
		{must1}{exp}类型{/exp}{string}
	[!attacker type]

	//1.1.2.11 target type #
	{prereq}[attack success]{/prereq}{exp}检查自己攻击的敌人的类型{/exp}[target type]
		{must1}{exp}类型{/exp}{string}
	[!target type]

	//1.1.2.12 target grade #
	{prereq}[attack success]{/prereq}{exp}检查自己攻击的敌人的等级{/exp}[target grade]
		{must1}{exp}等级{/exp}{string}
	[!target grade]

	//1.1.2.13 attack condition #
	{prereq}[attack success]|[hit]{/prereq}[attack condition]
		{must1}{exp}攻击条件{/exp}{string}
	[!attack condition]

	//1.1.2.14 skill #
	{prereq}[attack success]|[hit]{/prereq}[skill]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
	[!skill]

	//1.1.2.15 stat change #
	[stat change]
		{must1}{exp}状态{/exp}{string}
		{must2}{exp}比较方法{/exp}{string}
		{must3}{exp}比较单位{/exp}{string}
		{must4}{exp}数值{/exp}{int(0:)}
	[!stat change]

	//1.1.2.16 target stat #
	[target stat]
		{must1}{exp}状态{/exp}{string}
		{must2}{exp}比较方法{/exp}{string}
		{must3}{exp}比较单位{/exp}{string}
		{must4}{exp}数值{/exp}{int(0:)}
	[!target stat]

	//1.1.2.17 cooltime #
	{exp}冷却时间内不检查条件{/exp}[cooltime]
		{must1}{exp}冷却时间单位: ms{/exp}{int(0:)}
	[!cooltime]

	//1.1.2.18 start cooltime #
	{exp}每次装备时应用该冷却时间{/exp}[start cooltime]
		{must1}{exp}冷却时间单位: ms{/exp}{int(0:)}
	[!start cooltime]

	//1.1.2.19 target death #
	{prereq}[attack success]{/prereq}{exp}指定自己攻击的敌人死亡时{/exp}[target death]
		{must1}{exp}{/exp}{int(1:1)}
	[!target death]

	//1.1.2.20 combo #
	{exp}指定连击达到数值时{/exp}[combo]
		{must1}{exp}数值{/exp}{int(0:)}
	[!combo]

	//1.1.2.21 aerial #
	{exp}指定空中连击达到数值时{/exp}[aerial]
		{must1}{exp}{/exp}{string}
	[!aerial]

	//1.1.2.22 overkill #
	{exp}指定自己攻击的敌人以 Overkill 方式死亡时{/exp}[overkill]
		{must1}{exp}{/exp}{string}
	[!overkill]

	//1.1.2.23 party count #
	{exp}队友数量{/exp}[party count]
		{must1}{exp}数量{/exp}{int(0:)}
	[!party count]

	//1.1.2.24 my appendage #
	{exp}检查自己身上有 n 号附加物时{/exp}[my appendage]
		{must1}{exp}附加物索引{/exp}{int(0:)}
	[!my appendage]

	//1.1.2.25 skill frame state #
	{exp}该动画开始~结束帧之间成功。{/exp}[skill frame state]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
		{must3}{exp}动画名称{/exp}{string}
		{must4}{exp}开始帧{/exp}{int(0:)}
		{must5}{exp}结束帧{/exp}{int(0:)}
	[!skill frame state]

	//1.1.2.26 skill cooltime  #
	{exp}用于限制技能初始化范围的状态{/exp}[skill cooltime]
		{must1}{exp}比较方法{/exp}{string}
		{must2}{exp}冷却时间{/exp}{int(0:)}
	[!skill cooltime]

[/if]
```

### `move wav`

**标题**：- 掉落、移动、使用音效 / - 移动/拾取时音效 / - 移动/拾取音效 / - 掉落在地上、移动道具时（包含装备）发出的声音

|字段|音效类型|
|---|---|
|`POTION_TOUCH`| 药水|
|**饰品**||
|`NECKLACE_TOUCH`|  项链|
|`BRACELET_TOUCH`| 手镯|
|`RING_TOUCH`|戒指|
|**防具**||
|`BONE_TOUCH`   |   轻甲|
|`SCRAP_TOUCH`  |  板甲|
|`CLOTH_TOUCH`  |  布甲|
|`CLOTH_TOUCH`  |  皮甲同布甲|
|**武器**||
|`MINERALSWD_TOUCH`  |   短剑|

**官方示例：avatarsample.equ**

```pvf
[move wav] `CLOTH_TOUCH`        // 移动/拾取时音效
```

**官方示例：creaturesample.equ**

```pvf
[move wav] `NECKLACE_TOUCH`        // 移动/拾取音效
```

**官方示例：equipmentsample.equ**

```pvf
[move wav] `MOVE_SOUND`				// 掉落在地上、移动道具时（包含装备）发出的声音
```

### `MP MAX`

**标题**：MP 最大值

最大魔法值

**官方示例：equipmentsample.equ**

```pvf
[MP MAX] +27					// MP 最大值
```

### `need material`

**标题**：- 购买所需道具 / - 所需材料道具索引

- 添加到 NPC 商店时购买所需道具
 - 每行第一个数是道具ID，第二个数是所需数量
***
 - [price]      金币购买
 - [value]     售出价格（左道具编号，右道具数量）
 - [cash]       点券购买

**官方示例：equipmentsample.equ**

```pvf
// 未单独指定时，以 [value] 的值替代；若 [value] 也未指定，则以 [price] 的值替代。
[need material] 3043  2				// 所需材料道具索引，材料道具数量 (例，黑莲 2个)
```

### `poison resistance`

**标题**：中毒抗性

中毒异常抗性

**官方示例：equipmentsample.equ**

```pvf
[poison resistance] 11				// 中毒抗性
```

### `rarity`

**标题**：稀有度

0.普通
1.高级
2.稀有
3.神器
4.史诗
5.勇者
6.传说
7.神话

**官方示例：equipmentsample.equ**

```pvf
[rarity] 0					// 稀有度. 0:普通 1:高级 2:稀有 3:神器 4:史诗 5:传说)
```

### `skill levelup`

**标题**：- 技能等级提升 / - 装备时提升的技能和等级限制

每一行由3列组成：
1. 使用职业
2. 职业技能ID
3. 提升等级数

**官方示例：equipmentsample.equ**

```pvf
[skill levelup]					// 装备时提升的技能和等级限制。
`[swordman]` 10 1				// 职业 技能索引 等级
`[fighter]` 1 33
[/skill levelup]
```

**官方示例：equipmentsamplebytool.equ**

```pvf
//1.2.26 skill levelup #
	[skill levelup]
		{exp}职业{/exp}{string}
			{must1}{exp}技能索引{/exp}{int(0:)}
			{must2}{exp}等级变化量 {/exp}{int(0:)}
		{!string}
	[/skill levelup]
```

### `then`

**标题**：- 然后 / - 1

然后

与[if]词条搭配使用

[if]词条作为前置词条，也就是触发条件

[then]作为触发效果

**官方示例：equipmentsamplebytool.equ**

```pvf
//2 效果(than)##########################
[then]
	//1.2.1 consume item #
	{exp}消耗该索引的道具{/exp}[consume item ]
		{must1}{exp}索引{/exp}{int(0:)}
		{must2}{exp}数量{/exp}{int(0:)}
	[!consume item ]

	//1.2.2 target #
	{exp}指定效果发生在哪个目标身上{/exp}[target]
		{must1}{exp}种类{/exp}{string}
		{must2}{exp}范围(单位: px){/exp}{int(0:)}
	[!target]

	//1.2.3 duration #
	{exp}指定效果持续多久{/exp}[duration]
		{must1}{exp}数值(单位 : ms){/exp}{int(0:)}
	[!duration]

	//1.2.4 equipment duration #
	{exp}指定效果持续多久{/exp}[equipment duration]
		{must1}{exp}数值(单位 : ms){/exp}{int(0:)}
	[!equipment duration]

	//1.2.5 delay #
	{exp}指定效果延迟多久发动{/exp}[delay]
		{must1}{exp}数值(单位 : ms){/exp}{int(0:)}
	[!delay]

	//1.2.6 probability #
	{exp}指定效果发动的概率{exp}[probability]
		{must1}{exp}默认 100{/exp}{int(0:)}
	[!probability]

	//1.2.7 active status #
	{exp}{/exp}[active status]
		{must1}{exp}状态变化{/exp}{string}
		{opt1}{exp}等级{/exp}{int(0:)}
		{opt2}{exp}强度{/exp}{int(0:)}
	[!active status]

	//1.2.8 disenchant #
	{exp}解除目标所有状态变化和增益{/exp}[disenchant]
		{must1}{exp}{/exp}{int(1:1)}
	[!disenchant]

	//1.2.9 buff #
	[buff]
		{must1}{exp}种类{/exp}{string}
		{must2}{exp}等级{/exp}{int(0:)}
	[!buff]

	//1.2.10 appendage #
	{exp}给目标施加该索引的增益{/exp}[appendage]
		{must1}{exp}索引{/exp}{int(0:)}
	[!appendage]

	//1.2.11 add absolute damage #
	[add absolute damage]
		{must1}{exp}类型{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
	[!add absolute damage]

	//1.2.12 increase damage #
	[increase damage]
		{must1}{exp}比率 {/exp}{string}
		{must2}{exp}数值{/exp}{int(0:)}
	[!increase damage]

	//1.2.13 increase critical damage #
	[increase critical damage]
		{must1}{exp}比率 {/exp}{string}
		{must2}{exp}数值{/exp}{int(0:)}
	[!increase critical damage]

	//1.2.14 weakness #
	[weakness]
		{must1}{exp}数值{/exp}{int(0:)}
	[!weakness]

	//1.2.15 add absolute defence #
	[add absolute defence]
		{must1}{exp}类型{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
	[!add absolute defence]

	//1.2.16 add absolute defence percent #
	{exp}受击时减少伤害数值%{/exp}[add absolute defence percent]
		{must1}{exp}类型{/exp}{string}
		{must2}{exp}数值{/exp}{int(0:)}
	[!add absolute defence percent]

	//1.2.17 aura active #
	[aura active]
		{must1}{exp}光环种类{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
		{must4}{exp}光环范围(X轴像素单位数值){/exp}{int(0:)}
	[!aura active]

	//1.2.18 stat #
	[stat]
		{must1}{exp}状态种类{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
	[!stat]

	//1.2.19 restore #
	[restore]
		{must1}{exp}状态种类{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
		{must4}{exp}恢复速度: 时间(单位:ms){/exp}{int(0:)}
	[!restore]

	//1.2.20 active status resistance #
	[active status resistance]
		{must1}{exp}状态变化 {/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
	[!active status resistance]

	//1.2.21 element resistance #
	[element resistance]
		{must1}{exp}属性{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
	[!element resistance]

	//1.2.22 damage rate(未实现) #
	[damage rate]
		{must1}{exp}种类{/exp}{string}
		{must2}{exp}数值 : 百分比变化值{/exp}{int(0:)}
	[!damage rate]

	//1.2.23 summon monster #
	[summon monster]
		{must1}{exp}索引{/exp}{string}
		{must2}{exp}等级{/exp}{string}
		{must3}{exp}最大数量{/exp}{int(0:)}
	[!summon monster]

	//1.2.24 passive object #
	[passive object]
		{must1}{exp}索引{/exp}{int(0:)}
		{must2}{exp}x轴坐标{/exp}{int(0:)}
		{must3}{exp}y轴坐标{/exp}{int(0:)}
		{must4}{exp}z轴坐标{/exp}{int(0:)}
		{must5}{exp}等级 {/exp}{int(0:)}
		{must6}{exp}文件名 {/exp}{string}
	[!passive object]

	//1.2.25 skill #
	[skill]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
		{must3}{exp}等级{/exp}{int(0:)}
	[!skill]

	//1.2.26 skill levelup #
	[skill levelup]
		{exp}职业{/exp}{string}
			{must1}{exp}技能索引{/exp}{int(0:)}
			{must2}{exp}等级变化量 {/exp}{int(0:)}
		{!string}
	[/skill levelup]

	//1.2.27 thorn #
	{prereq}按百分比将伤害返还给敌人{/prereq}{exp}按百分比将伤害返还给敌人{/exp}[thorn]
		{must1}{exp}数值{/exp}{int(0:)}
	[!thorn]

	//1.2.28 knockback #
	[knockback]
		{must1}{exp}数值{/exp}{int(0:)}
	[!knockback]

	//1.2.29 reduction #
	[reduction]
		{must1}{exp}种类{/exp}{string}
		{must2}{exp}要减少的耐久度数值{/exp}{int(0:)}
	[!reduction]

	//1.2.30 elemental weapon #
	{exp}赋予武器属性{/exp}[elemental weapon]
		{must1}{exp}属性{/exp}{string}
	[!elemental weapon]

	//1.2.31 stat by condition #
	{exp}• 使增益图标实时显示{/exp}[stat by condition]
		{must1}{exp}状态种类{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值{/exp}{int(0:)}
	[!stat by condition]

	//1.2.32 apply status in range #
	[apply status in range]
		{must1}{exp}状态种类{/exp}{string}
		{must2}{exp}数值单位{/exp}{string}
		{must3}{exp}数值1{/exp}{int(0:)}
		{must4}{exp}数值2{/exp}{int(0:)}
	[!apply status in range]

	//1.2.33 skill super armor  #
	{exp}使技能施放动作变为霸体状态{/exp}[skill super armor]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
	[!skill super armor]

	//1.2.34 skill unbreakable  #
	{exp}使技能施放动作变为无敌状态{/exp}[skill unbreakable]
		{must1}{exp}技能索引{/exp}{int(0:)}
	[!skill unbreakable]

	//1.2.35 skill duration  #
	[skill duration]
		{must1}{exp}职业{/exp}{string}
		{must2}{exp}技能索引{/exp}{int(0:)}
		{must3}{exp}应用参数{/exp}{string}
		{must4}{exp}参数索引{/exp}{int(0:)}
	[!skill duration]

	//1.2.36 speech on  #
	{exp}对话气泡{/exp}[speech on]
		{must1}{exp}数值1(ms){/exp}{int(0:)}
		{must2}{exp}数值2(ms){/exp}{int(0:)}
		{must3}{exp}输出内容 {/exp}{string}
	[!speech on]

	//1.2.37 skill cooltime reset  #
	{exp}技能冷却时间重置{/exp}[skill cooltime reset]
		{must1}{exp}{/exp}{int(1:2)}
	[!skill cooltime reset]
[/then]
```

### `value`

**标题**：- 出售价格 / - 玩家卖给商店的金额

[value] 售出价格，   实际出售价为标写的1/5
通过移除此标签可取消售出价格，即游戏内售出不会获得金币

//装备里为增加的数量

//以及：
[price]                 金币购买
[cash]                  点券购买
[need material]   道具购买（左道具编号，右道具数量）

**官方示例：equipmentsample.equ**

```pvf
[value] 50					// 玩家卖给商店的金额
```

---

## 消耗品（11 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `active status recovery` | - 解除异常效果 - 状态异常恢复 | 090302stackablesample.stk |
| `attach type` | - 交易 - 绑定类型 在     中选择一个 - 绑定类型 | stackablesample-booster.stk、090302stackablesample.stk、stackablesample.stk |
| `buff` | - 增益状态 - 使自己进入状态异常（基本以外的那些） | 090302stackablesample.stk |
| `icon` | - 游戏中展示的图标 - 图标图像文件和帧索引 | stackablesample-booster.stk、090302stackablesample.stk、stackablesample.stk |
| `minimum level` | - 等级限制 - 使用所需的最低等级 | stackablesample-booster.stk、090302stackablesample.stk、stackablesample.stk |
| `my status` | - 赋予自身异常状态 - 使自己进入状态异常 | 090302stackablesample.stk |
| `price` | 价格 | stackablesample-booster.stk、090302stackablesample.stk、stackablesample.stk |
| `stat change` | - 道具效果 - 使用消耗品时硬直度增加1000 | 090302stackablesample.stk、stackablesample.stk |
| `string data` | - 宝珠可镶嵌的部位 - 用于硬编码的字符串数据 - 怪物卡片图像包 - 配方类型 - 指定对象路径的粒子脚本 | stackablesample-booster.stk、stackablesample-monster_card.stk、stackablesample-recipe.stk、stackablesample.stk、stackablesample-throwitem.stk |
| `usable job` | - 在道具里为可以使用的职业 - 可使用角色列表的开始 | stackablesample-booster.stk、090302stackablesample.stk、stackablesample.stk |
| `weight` | - 重量 - 重量 (单位 | stackablesample-booster.stk、090302stackablesample.stk、stackablesample.stk |

### `active status recovery`

**标题**：- 解除异常效果 / - 状态异常恢复

解除异常效果

//示例：
[active status recovery]
	`poison`	70
	`party`
//以上代表最高可以解除70级的中毒异常效果，且对身边友军也会生效

感电：`lightning`
束缚：`hold`
减速：`slow`
灼伤：`burn`
中毒：`poison`
眩晕：`stun`
睡眠：`sleep`
石化：`stone`
失明：`blind`
疾病：`disease`
混乱：`confuse`
出血：`bleeding`
沉默：`silence`
冰冻：`freeze`
诅咒：`curse`
所有异常效果：`all`
所有异常效果：`any`

仅对自身生效：`myself`
对身边友军也会生效：`party`

**官方示例：090302stackablesample.stk**

```pvf
[active status recovery] `stun` 55 `myself`    //状态异常恢复。状态异常种类，最大等级，目标
```

### `attach type`

**标题**：- 交易 / - 绑定类型 在     中选择一个 / - 绑定类型

交易类型
`[free]` = 不限制
`[sealing]` = 封装
`[trade]` = 不可交易
`[account]` = 帐号绑定
`[trade delete]` = 无法交易、删除
`[sealing trade]` = 封装且不可交易

**官方示例：stackablesample-booster.stk**

```pvf
[attach type] `[free]`				// 绑定类型 在 `[free]` `[trade]` `[trade delete]` `[sealing]` 中选择一个
```

**官方示例：090302stackablesample.stk**

```pvf
[attach type] `[free]`                // 绑定类型
```

**官方示例：stackablesample.stk**

```pvf
[attach type] `[free]`				// 绑定类型 在 `[free]` `[trade]` `[trade delete]` `[sealing]` 中选择一个
```

### `buff`

**标题**：- 增益状态 / - 使自己进入状态异常（基本以外的那些）

**官方示例：090302stackablesample.stk**

```pvf
[buff] `superarmor` 5000 `myself`    //使自己进入状态异常（基本以外的那些）。状态异常种类，持续时间，目标
```

### `icon`

**标题**：- 游戏中展示的图标 / - 图标图像文件和帧索引

游戏中展示的图标

调用客户端的ImagePacks2文件夹的NPK文件里面图像，
需借助ExtractorSharp工具查看

**官方示例：stackablesample-booster.stk**

```pvf
[icon] `StackableIcon.img` 2		// 图标图像文件和帧索引
```

**官方示例：090302stackablesample.stk**

```pvf
[icon] `StackableIcon.img` 2        // 图标图像文件和帧索引
```

**官方示例：stackablesample.stk**

```pvf
[icon] `StackableIcon.img` 2		// 图标图像文件和帧索引
```

### `minimum level`

**标题**：- 等级限制 / - 使用所需的最低等级

等级限制
装备、物品最低可使用的等级

**官方示例：stackablesample-booster.stk**

```pvf
[minimum level] 0				// 使用所需的最低等级
```

**官方示例：090302stackablesample.stk**

```pvf
[minimum level] 0                // 使用所需的最低等级。
```

**官方示例：stackablesample.stk**

```pvf
[minimum level] 0				// 使用所需的最低等级
```

### `my status`

**标题**：- 赋予自身异常状态 / - 使自己进入状态异常

赋予自身异常状态

//示例：
[my status]
	`confuse`	10	7000	40	1

以上为暗黑城特产干酪的效果，1%的几率为自身赋予40级的混乱异常状态，持续7秒

**官方示例：090302stackablesample.stk**

```pvf
[my status] `poison` 10 7000 10 90    //使自己进入状态异常。状态异常种类，概率，持续时间，等级，根据状态异常种类的变量（最多4个）
```

### `price`

**标题**：价格

[price] 金币购买的价格

//除了金币购买还可以添加如下词条：
[value]                售出价格（实际出售价为标写的1/5）
[cash]                 点券购买
[need material]  道具购买（左道具编号，右道具数量）

**官方示例：stackablesample-booster.stk**

```pvf
// `[waste]` `[material]` `[recipe]` `[throw]` `[set]` `[legacy]` `[quest]` `[etc]` `[creature]` `[feed]`
// `[cera package]` `[package]` `[cera booster]` `[booster]`
					// 后面的数字是价格表索引。如果没有价格则输入0。
					// 即使单独输入价格，卖出/修理价格也会遵循这个索引
[price] 100				// 价格。如果从价格表读取则无需填写
```

**官方示例：090302stackablesample.stk**

```pvf
[price] 100                // 价格。如果从表里读取则无需填写。
```

**官方示例：stackablesample.stk**

```pvf
[price] 100				// 价格。如果从价格表读取则无需填写
```

### `stat change`

**标题**：- 道具效果 / - 使用消耗品时硬直度增加1000

道具效果：
一般和[stat change duration]联动使用
`———————————————————————————`
//示例①：
[stat change]
	`%` 10
	`physical critical hit`
[/stat change]
//以上为使用道具之后在已有物理暴击率的基础上增加10%的物理暴击率
`———————————————————————————`
//示例②：
[stat change]
	`%` 10
	`physical critical hit`
	`+`	7
	`physical attack bonus`
[/stat change]
//以上为使用道具之后增加10%的物理暴击率和7点物理攻击力
`———————————————————————————`
//上方：
`+` = 固定数值
`%` = 百分比数值

//提醒：
使用`+`时，若为暴击率、命中率、闪避率、三速，则按百分比增加，也就是说0暴击率吃了一个为`+`的暴击药，效果是10，则实际增加到10%暴击率

使用`%`时，暴击率、命中率、闪避率、三速只会按当前数值增幅，比如自带50%暴击率，用`%`增加50%暴击率只会在此基础上增加一半的暴击率，也就是实际使用道具达到75%暴击率
`———————————————————————————`
//下方：
`stuck` = 命中率（负数增加命中率，正数减少命中率）
`stuck resistance` = 闪避率
`attack speed` = 攻击速度
`cast speed` = 施法速度
`move speed` = 移动速度
`physical critical hit` = 物理暴击率
`magical critical hit` = 法术暴击率
`physical attack bonus` = 物理攻击力
`magical attack bonus` = 法术攻击力
`physical defense bonus` = 物理防御力
`magical defense bonus` = 法术防御力
`separate attack` = 独立攻击力
`physical attack` = 力量
`magical attack` = 智力
`physical defense` = 体力
`magical defense` = 精神
`HP MAX` = 生命值上限
`MP MAX` = 魔法值上限
`all elemental resistance` = 所有属性抗性
`fire resistance` = 火属性抗性
`light resistance` = 光属性抗性
`water resistance` = 冰属性抗性
`dark resistance` = 暗属性抗性
`all elemental attack` = 所有属性强化
`fire attack` = 火属性强化
`light attack` = 光属性强化
`water attack` = 冰属性强化
`dark attack` = 暗属性强化
`weight` = 重量
`hit recovery` = 硬直恢复
`jump power` = 跳跃力
`jump speed` = 跳跃速度
`HP regen speed` = 生命值恢复速度
`MP regen speed` = 魔法值恢复速度
`hold resistance` = 束缚抗性
`slow resistance` = 减速抗性
`burn resistance` = 灼伤抗性
`poison resistance` = 中毒抗性
`stun resistance` = 眩晕抗性
`sleep resistance` = 睡眠抗性
`stone resistance` = 石化抗性
`blind resistance` = 失明抗性
`disease resistance` = 疾病抗性
`confuse resistance` = 混乱抗性
`bleeding resistance` = 出血抗性
`silence resistance` = 沉默抗性
`freeze resistance` = 冰冻抗性
`curse resistance` = 诅咒抗性
`lightning resistance` = 感电抗性
`weakness resistance` = 虚弱抗性
`weapon break resistance` = 武器损坏抗性
`armor break resistance` = 防具损坏抗性
`piercing resistance` = 破甲抗性
`deelement resistance` = 属性剥离抗性
`deadlystrike resistance` = 致命一击抗性
`———————————————————————————`
//补充：
搭配下方这个标签可以隐藏道具自带的介绍文本 ↓
[use effect explain]
	0

隐藏完之后，可以使用下方这个标签自己写一个效果介绍文本 ↓
[explain]
	`（文本）`

**官方示例：090302stackablesample.stk**

```pvf
// 对自己应用以下效果，持续60秒
[stat change]
`+` 1000 `rigidity`    // 使用消耗品时硬直度增加1000
`+` 100 `fire attack`    // 使用消耗品时火属性攻击力增加100
`+` 101 `water attack`    // 使用消耗品时水属性攻击力增加101
`+` 102 `dark attack`    // 使用消耗品时暗属性攻击力增加102
`+` 103 `light attack`    // 使用消耗品时光属性攻击力增加103
[/stat change]
```

**官方示例：stackablesample.stk**

```pvf
// 对自身应用以下效果，持续60秒
[stat change]
`+` 1000 `rigidity`	// 使用消耗品时僵直度增加 1000
`+` 100 `fire attack`	// 使用消耗品时火属性攻击力增加 100
`+` 101 `water attack`	// 使用消耗品时水属性攻击力增加 101
`+` 102 `dark attack`	// 使用消耗品时暗属性攻击力增加 102
`+` 103 `light attack`	// 使用消耗品时光属性攻击力增加 103
[/stat change]
```

### `string data`

**标题**：- 宝珠可镶嵌的部位 / - 用于硬编码的字符串数据 / - 怪物卡片图像包 / - 配方类型 / - 指定对象路径的粒子脚本

宝珠可镶嵌的部位：
称号      `[title name]`
武器      `[weapon]`
上衣      `[coat]`
下装      `[pants]`
头肩      `[shoulder]`
腰带      `[waist]`
鞋子      `[shoes]`
手镯      `[wrist]`
项链      `[amulet]`
戒指      `[ring]`
魔法石  `[magic stone]`
护石      `[support]`

字符串工艺
精湛工艺		`[craftmanship]`

串数据（相关）：
工艺：craftmanship （制作：炼金、人偶）
机械：machinary
编织：weaving
三种都可以制作装备，具体对应未知

**官方示例：stackablesample-booster.stk**

```pvf
[string data]				// 用于硬编码的字符串数据
`ASDF.ptl`
`ASDF2.ptl`
[/string data]
```

**官方示例：stackablesample-monster_card.stk**

```pvf
[string data]
`Interface/MonsterCard/cut_cardimage.img`	// 怪物卡片图像包
`[weapon]`					// 附魔目标 (装备部位)
`[foil]` 					// 箔
`[unlimited challenge]`				// 事件名称
[/string data]
```

**官方示例：stackablesample-recipe.stk**

```pvf
[string data]
// 配方类型。
// 精工 - [craftmanship]
// 织造 - [weaving]
// 机械 - [machinary]
// 化学 - [chemistry]
// 附魔 - [enchant]
// 从以上选择
// 注意大小写准确！！
`[craftmanship]`
[/string data]
```

**官方示例：stackablesample.stk**

```pvf
[string data]				// 用于硬编码的字符串数据
`ASDF.ptl`
`ASDF2.ptl`
[/string data]
```

**官方示例：stackablesample-throwitem.stk**

```pvf
[string data]
`PassiveObject/ThrowItem/Particle/Boomerang.ptl`	// 指定对象路径的粒子脚本。绝对路径
`THROW`							// 投掷时发出的音效标签
[/string data]
```

### `usable job`

**标题**：- 在道具里为可以使用的职业 / - 可使用角色列表的开始

[usable job]在道具里为可以使用的职业

`[all]` = 所有职业
`[creator mage]` = 缔造者
`[swordman]` = 鬼剑士(男)
`[at swordman]` = 鬼剑士(女)
`[demonic swordman]` = 黑暗武士
`[fighter]` = 格斗家(女)
`[at fighter]` = 格斗家(男)
`[gunner]` = 神枪手(男)
`[at gunner]` = 神枪手(女)
`[mage]` = 魔法师(女)
`[at mage]` = 魔法师(男)
`[priest]` = 圣职者(男)
`[thief]` = 暗夜使者

**官方示例：stackablesample-booster.stk**

```pvf
[usable job]			// 可使用角色列表的开始
`[all]`					// 有 `[swordman]` `[fighter]` `[all]` 等选择
[/usable job]			// 必须用这个来结束
```

**官方示例：090302stackablesample.stk**

```pvf
[usable job]            // 可使用角色列表的开始
`[all]`                    // 有 `[swordman]` `[fighter]` `[all]` 等选择
[/usable job]            // 必须以此关闭
```

**官方示例：stackablesample.stk**

```pvf
[usable job]			// 可使用角色列表的开始
`[all]`					// 有 `[swordman]` `[fighter]` `[all]` 等选择
[/usable job]			// 必须用这个来结束
```

### `weight`

**标题**：- 重量 / - 重量 (单位

重量
此数值越高，角色或怪物被击飞后的下落速度越快
若为装备或物品时，将减少物品栏或金库的容量

**官方示例：stackablesample-booster.stk**

```pvf
[weight] 5				// 重量 (单位：10g)
```

**官方示例：090302stackablesample.stk**

```pvf
[weight] 5                // 重量
```

**官方示例：stackablesample.stk**

```pvf
[weight] 5				// 重量 (单位：10g)
```

---

## 任务（8 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `exposed by npc` | 是否显示在NPC的任务界面 | questsample.qst |
| `gold multiple` | 任务金币奖励倍数 | questsample.qst |
| `int data` | int数据 | questsample.qst |
| `job` | 职业 | questsample.qst |
| `reward int data` | 完成任务时给予的固定奖励 | questsample.qst |
| `reward selection int data` | 完成任务时 | questsample.qst |
| `sub type` | 子项目类型 | questsample.qst |
| `type` | 类型 | questsample.qst |

### `exposed by npc`

**标题**：是否显示在NPC的任务界面

是否显示在NPC的任务界面

0 = 不显示
1 = 显示

添加此标签并赋予0时，即便NPC有此任务也无法在游戏内接取

**官方示例：questsample.qst**

```pvf
[exposed by npc] 0 // 是否由NPC暴露。1: 暴露, 0 : 不暴露，默认为1（若没有则取默认值）。
```

### `gold multiple`

**标题**：任务金币奖励倍数

任务金币奖励倍数

* 在 [reward int data] 或[reward selection int data]奖励中, 有金币代码0才会生效。

* 实际奖励金额 = 等级奖励基数 * 任务难度 * 金币奖励倍数

* 等级奖励基数由 [ignore quest level 4 exp] 来决定是取决于角色等级还是任务等级，该标签不存在或为 0 时，按任务等级。

* 任务难度由 [difficulty] 决定。

* 等

**官方示例：questsample.qst**

```pvf
// 本任务完成时影响经验值奖励。
[gold multiple] 50 // 任务金币奖励倍数（百分比）。仅在[reward int data]中有金币索引0时才生效，
// （按级别金币奖励基本表）*（任务奖励难度）*（任务金币奖励倍数）的结果为最终金币奖励值。
```

### `int data`

**标题**：int数据

int数据
在任务.qst中
当 [type] = `[seeking]`时
两个数值
分别为: 所需物品 所需物品数量

当 [type] = `[condition under clear]` 时
三个数值
分别为: 副本代码 副本難度 组队人数
也可以只填写前2个参数 副本代码 副本难度

当[type]=[hunt monster]时
四个数值
分别为 副本代码 难度 怪物ID 怪物数量

当type=[[custom quest]]时
三个数值
1 0 1未知 有时最后一个数可能是任务怪物ID

`不修改前辈已有信息的补充：部分怪物会把机制信息写在int数据而不是
atk info里，想修改的话，有个笨方法，一个一个改，改对了就记住`

**官方示例：questsample.qst**

```pvf
[int data] // 整数资料。用法参考最底部的注释。
38 3
29 2
[/int data] // 闭合。

[int data] // APC解救任务的情况下，[int data]中写入<需通关的地图索引>和<apc的索引>。
<需通关的地图索引> <apc的索引>
[/int data]

[int data]
<地城索引> <难度> <对象索引> <对象种类> <对象数量> //// <对象种类>怪物为1，APC为2，被动对象为3。
[/int data]
```

### `job`

**标题**：职业

职业类型
[all] ————————所有职业(在一些文件中不适用)
[swordman] —————鬼剑士（男）
[at swordman] ————鬼剑士（女）
[fighter] ——————格斗家（女）
[at fighter] —————格斗家（男）
[gunner] ——————神枪手（男）
[at gunner] —————神枪手（女）
[mage] ———————魔法师（女）
[at mage] ——————魔法师（男）
[priest] ———————圣职者（男）
[thief] ———————暗夜使者
[creator mage] ————外传职业 : 缔造者
[demonic swordman] —外传职业 : 黑暗武士

//截止到2026/3/22还没有能改的女鬼剑，都是别的职业改过来的，注意辨别

**官方示例：questsample.qst**

```pvf
// 出现条件
[job] `[swordman]` // 可接受任务的职业。可选择 `[swordman]` `[fighter]` `[gunner]` `[priest]` `[mage]` `[at gunner]` `[thief]` `[all]` 之一。
```

### `reward int data`

**标题**：完成任务时给予的固定奖励

完成任务时给予的固定奖励

* 两个数值为一组，第一个为装备、道具代码，第二个为数量

* 赋予金币代码0时，任务金币奖励倍数[gold multiple]就会生效

**官方示例：questsample.qst**

```pvf
[reward int data] // 奖励的整数资料。用法参考最底部的注释。
10 1 // 若为`[hero]`则是[地城索引]。
2354 10
2356 `[job]` 2 1 10 // 在物品索引和数量之间添加`[job]`和职业索引、转职索引，则仅在该职业、转职时给予奖励。（若转职为-1则所有转职）。
[/reward int data] // 闭合。
```

### `reward selection int data`

**标题**：完成任务时

完成任务时，可以选择其中一种作为奖励

//此类有两种写法：
①与 [reward int data] 一致，同样是两个代码为一组
②根据不同职业发放道具、装备

//第②种写法的示例（第2种写法同样适用于固定奖励）：
	27012	`[job]`	0	-1	1
   为男鬼剑的全部职业发放一把短剑

	27611	`[job]`	0	1	1
   为男鬼剑的剑魂发放一把太刀

//五个代码为一组：
1 = 道具、装备 ID
2 = `[job]`
3 = 职业类型(0 到 10)
4 = -1代表是否转职都可以领，0到4代表限定某个职业
5 = 数量

//职业类型代码：
* 职业类型可在PVF主界面的character/character.lst查看
男鬼剑：0
女格斗：1
男枪手：2
女魔法：3
男圣职：4

//限定某个职业的代码：
-1不限职业  0男鬼剑士 1剑魂            2鬼泣         3狂战士      4阿修罗
-1不限职业  0女格斗     1女气功        2女散打     3女街霸      4女柔道家
-1不限职业  0女魔法师 1女元素师     2召唤师     3战斗法师  4魔道学者
-1不限职业  0男圣职者 1男圣骑士     2蓝拳圣使 3男驱魔师   4复仇者

**官方示例：questsample.qst**

```pvf
[reward selection int data] // 奖励的整数资料。用法参考最底部的注释。
10 1
2354 10
2356 `[job]` 2 10 // 在物品索引和数量之间添加`[job]`和职业索引，则仅在该职业时可以选择该物品。
[/reward selection int data] // 闭合。
```

### `sub type`

**标题**：子项目类型

子项目类型
--------------------------------------------------
在任务(*.qst)中，与 [type] 响应。
* 当 [type] = `[condition under clear]` 时，[sub type] 将对应以下子类型，其它类型则为 -1。
0 = 通关时间          （副本编号，副本难度，限时通关秒数）
1 = 被击数              （副本编号，副本难度，受击次数限制要求）

2 = 技巧                 （副本编号，副本难度，技巧要求  10=10%）

3 = 操作                 （副本编号，副本难度，操作要求  10=10%）
4 = 不使用复活币   （副本编号，副本难度）
5 = 组队                  （副本编号，副本难度，组队人数）
6 = 通关副本          （副本编号，副本难度）

7 =连击杀伤率       （副本编号，副本难度，连击杀伤率要求  10=10%）

10 = 连击数           （副本编号，副本难度，连击数要求）

**官方示例：questsample.qst**

```pvf
[sub type] 0 // 任务的子类型。

[sub type] 0 // APC解救任务的情况下，将任务条件类型设置为[clear map]，子类型为0。

[sub type] -1 // APC解救任务的情况下，将任务条件类型设置为[hunt enemy]，子类型为-1。
```

### `type`

**标题**：类型

[type]任务完成条件类型
`[condition under clear]`过图
`[seeking]`需要道具
`[hunt monster]`击杀怪物次数
`[meet npc]`对话NPC
`[custom quest]`按字面意思应该是自定任务 暂且叫私人任务或者个人任务吧 学习技能或者加点时使用 对话时也出现了
`[disjoint item]`分解装备
`[clear map]` 任务在地图里找人

**官方示例：questsample.qst**

```pvf
// 任务完成条件。
[type] `[seeking]` // 任务的类型。可选择 `[seeking]` `[condition under clear]` `[hunt monster]` `[hunt enemy]` `[clear map]` `[meet npc]` `[pvp rank]` `[powerwar win]` `[powerwar point]` 之一。

// ※ APC相关任务用法
// APC同行（解救后同行条件相同）。
[type] `[clear map]`

// apc简单解救。
[type] `[hunt enemy]`
```

---

## 动画（7 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `ATTACK BOX` | 攻击范围判定框 | animation.ani |
| `DELAY` | 一帧贴图的持续时间 | animation.ani |
| `FRAME MAX` | 整个动画过程播放的最大帧数 | animation.ani |
| `FRAME000` | FRAME000 | animation.ani |
| `IMAGE` | — | animation.ani |
| `IMAGE POS` | 动画贴图坐标 | animation.ani |
| `LOOP` | 循环 | animation.ani |

### `ATTACK BOX`

**标题**：攻击范围判定框

[ATTACK BOX]  攻击范围判定框
X1   Y1  Z1   X2  Y2  Z2

X1:以ani坐标为基点的碰撞框X轴坐标

Y1:以ani坐标为基点的碰撞框Y轴坐标

Z1:以ani坐标为基点的碰撞框Z轴坐标

X2:以ani坐标为基点的碰撞框X轴大小

Y2:以ani坐标为基点的碰撞框Y轴大小

Z2:以ani坐标为基点的碰撞框Z轴大小

**官方示例：animation.ani**

```pvf
[ATTACK BOX] -12 -7 -12 28 14 28				// 攻击盒大小
```

### `DELAY`

**标题**：一帧贴图的持续时间

一帧贴图的持续时间
1000=1秒

若要为此帧赋予霸体状态，需添加词条：
	[DAMAGE TYPE]
		`SUPERARMOR`

**官方示例：animation.ani**

```pvf
[DELAY] 70							// 帧持续时间
```

### `FRAME MAX`

**标题**：整个动画过程播放的最大帧数

**官方示例：animation.ani**

```pvf
[FRAME MAX] 3	// 总帧数：下面使用的 FRAME00X 编号数量必须与此相同。
		// 例如) [FRAME MAX] 3 的情况下，最后一帧必须以 FRAME002 结尾。
```

### `FRAME000`

**标题**：FRAME000

[FRAME000]
这是每个动画的第一帧，
001就是第二帧，
一般是不用专门改frame后面数字的，只要添加进动画就会自动按顺序改

**官方示例：animation.ani**

```pvf
[FRAME000]							// 当前帧编号
```

### `IMAGE`

[IMAGE]动画贴图
在此标签下添加npk路径以调用npk文件的贴图，贴图npk文件的位置在客户端的[ImagePacks2]文件夹

[ImagePacks2]内的贴图文件需借助npk解包工具查看
目前据作者所知的npk解包工具有：
ExtractorSharp（可编辑贴图、音乐）
黑猫（适合拿来做时装）

**官方示例：animation.ani**

```pvf
[IMAGE] `Monster/Golem/PassiveObject/GolemBullet.img` 0		// 图像路径,帧编号
```

### `IMAGE POS`

**标题**：动画贴图坐标

[IMAGE POS]动画贴图坐标
左边为X轴          右边为Y轴

**官方示例：animation.ani**

```pvf
[IMAGE POS] -51 -50						// 图像位置
```

### `LOOP`

**标题**：循环

循环

部分拥有位移效果的动作添加此标签后才可以生效
比如牛头怪或翼龙的冲撞，各个职业的行走、奔跑等等

**官方示例：animation.ani**

```pvf
[LOOP] 1	// 当前动画是否循环 (0:不循环 1:循环)
```

---

## 动作（6 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `BURN` | 异常效果 | actionsample.act、actionsamplebytool.act |
| `INDEX` | 大概是编号 | actionlibrary/080324ver/buster.act、actionlibrary/distance.act、actionlibrary/shootingstar.act、actionsample.act、actionsamplebytool.act |
| `LEVEL` | 等级 | actionlibrary/080324ver/buster.act、actionlibrary/shootingstar.act、actionsample.act、actionsamplebytool.act |
| `POS` | 位置 | actionlibrary/080324ver/buster.act、actionlibrary/distance.act、actionlibrary/shootingstar.act、actionsample.act |
| `SAY SPEECH` | 处于此行动状态时的台词 | actionsample.act |
| `SUMMON MONSTER` | 召唤物机制 | actionsample.act、actionsamplebytool.act |

### `BURN`

**标题**：异常效果

异常效果：灼伤

// 该词条位于彼诺修的烈焰护盾机制时，代表：
概率(%)，等级，持续时间，伤害，范围伤害，范围伤害选项(1表示范围伤害仅适用于敌军)、范围伤害间隔
//1000 = 1秒

// 彼诺修的烈焰护盾机制路径：
monster/soceress/action_keraha/proc_vinoshu.act

**官方示例：actionsample.act**

```pvf
**[ACTIVE STATUS]** [burn] 100 10 20000 1000 10 1 3000    // 概率, 等级, 持续时间, 伤害, 周围伤害, 周围伤害选项（1 表示只对敌军造成周围伤害）, 周围伤害应用间隔（时间）
```

**官方示例：actionsamplebytool.act**

```pvf
{must1}{exp}灼伤{/exp}[burn]		//ACTIVESTATUS_BURN
```

### `INDEX`

**标题**：大概是编号

**官方示例：actionlibrary/080324ver/buster.act**

```pvf
[INDEX] 23013	//索引编号
```

**官方示例：actionlibrary/distance.act**

```pvf
[INDEX] 40004//索引编号
```

**官方示例：actionlibrary/shootingstar.act**

```pvf
[INDEX] 40004//索引编号 40004 号 流星。
```

**官方示例：actionsample.act**

```pvf
[INDEX] 0        // [INDEX]: 队伍成员的索引（0 ~ 3）（必需参数）

[INDEX] 30001                        //索引编号

[INDEX] 30001 //索引编号

[INDEX] 30001//索引编号
```

**官方示例：actionsamplebytool.act**

```pvf
//[!PARTY TARGET]
		{prereq}[PARTY TARGET]{/prereq}{must2}{exp}索引{/exp}[INDEX]

//INDEX, 粒子文件名, LEVEL, POS 必须按顺序输入。其他可输可不输。
		{must1}{exp}被动物体索引编号{/exp}[INDEX]
			//mkjung 120516 int->rndint 修改。
			{must1}{exp}索引编号{/exp}{rndint(:)}

//INDEX, LEVEL, POS 必须按顺序输入。其他可输可不输。
		{must1}{exp}索引编号{/exp}[INDEX]
		//mkjung 120515 int->rndint 修改。
			{must1}{rndint(:)}

//INDEX, LEVEL, POS 必须按顺序输入。其他可输可不输。
		{must1}{exp}索引编号{/exp}[INDEX]
			{must1}{int(0:)}
```

### `LEVEL`

**标题**：等级

**官方示例：actionlibrary/080324ver/buster.act**

```pvf
[LEVEL] 32						// 魔法等级.
```

**官方示例：actionlibrary/shootingstar.act**

```pvf
[LEVEL] 40	// 流星的魔法等级
```

**官方示例：actionsample.act**

```pvf
**[GET TARGET]** 3 [LEVEL] [HIGH] // 按等级从高到低设置

[LEVEL] 0                        // 魔法等级。

[LEVEL] 70            // 等级
```

**官方示例：actionsamplebytool.act**

```pvf
//[RANDOM]不包含高/低。
		{prereq}[HP]|[MP]|[LEVEL]|[DISTANCE]|[LAST ATTACKSUCCESS]{/prereq}{must3}{exp}按降序（低者优先）排序{/exp}[LOW]
```

### `POS`

**标题**：位置

位置

此标签在召唤物机制内时，代表X、Y、Z轴的出现位置

**官方示例：actionlibrary/080324ver/buster.act**

```pvf
[POS] 0 0 300 // 父坐标的相对坐标 x y z
```

**官方示例：actionlibrary/distance.act**

```pvf
[POS] 0 0 300//x y z //目标地点高度以位置为准。
		//[USE TARGET TEAM] //
		//[USE MY DIRECTION]
		//[USE MY BASEPOS]
```

**官方示例：actionlibrary/shootingstar.act**

```pvf
[POS] 0 0 300 // 相对坐标。目标地点高度以位置为准。
```

**官方示例：actionsample.act**

```pvf
[POS] 100 200 0            // （基准坐标X,基准坐标Y,基准坐标Z）

[POS] 20 0 60                        // 父坐标的相对坐标 x y z

[POS] 20 0 60 //x y z

[POS] 20 0 60//x y z

[POS] 600 120 150    // （省略时，默认值：0 0 0）

[POS] 0 0        // 相对坐标（X, Y）

[POS] 0 0 0                // 要移动到的坐标。（中心轴）
        //[USE MY DIRECTION]            // 决定坐标基准 X 轴移动是否依据自己面对的方向。（默认是目标方向）
        //[USE MY BASEPOS]            // 指定相对坐标移动是否以自身坐标为准（默认是目标坐标）
        //[NOT USE OBJECT DIRECTION]        // 不进行方向修正
        //[USE MAP POS]                // 坐标移动使用地图绝对坐标。
        //[NOT USE OBJECT ZPOS]        // 不使用基准对象的 Z 位置
        //[MOVE ME]                // 自己移动到该坐标基准处
        //[MOVE TARGET]                // 目标移动到该坐标基准处。（默认）

[POS] 30 50 20            // 要移动的点们

[POS] 530 270 60            // *********** [注意] ：请将怪物移动 destination.ai 设置为 -1 ***********************
```

### `SAY SPEECH`

**标题**：处于此行动状态时的台词

处于此行动状态时的台词，比如克拉赫召唤哥布林

**官方示例：actionsample.act**

```pvf
**[SAY SPEECH]** `speech`                    // 输出台词。
```

### `SUMMON MONSTER`

**标题**：召唤物机制

[SUMMON MONSTER]召唤物机制，此机制分为3部分，分别是
		[INDEX]←召唤物编号（写什么怪物的编号就会召唤什么怪物）
			63
		[LEVEL]←召唤物等级（一般不用刻意设定1以外的等级）
			1
		[POS]←召唤物出现位置（X轴，Y轴，Z轴）
			100	0	0
		[MAGIC CIRCLE]←魔法阵（暂时不清楚这个标签的用意）

**官方示例：actionsample.act**

```pvf
**[SUMMON MONSTER]**            // INDEX, LEVEL, POS 必须按顺序输入。其余输入与否均可。
        [INDEX] 30001 //索引编号
        [LEVEL] 0

        [POS] 20 0 60 //x y z

        [NO EFFECT]                    // 无召唤特效出现。
        //[MAGIC CIRCLE]                // 绘制魔法阵召唤。默认值。
        //[JUMP OUT] 0 0 0 [LEFT] [UP]            // 像怪物跳出一样召唤。
                                // x 速度, y 速度, 高度
                                // [NEUTRAL] 或 [LEFT] 或 [RIGHT] 或 [RANDOM]
                                // [NEUTRAL] 或 [UP] 或 [DOWN] 或 [RANDOM]
        //[USE TARGET TEAM]                // 以目标的队伍出现。（默认是主人的队伍。）
        //[USE MY DIRECTION]                // 决定坐标基准 X 轴移动是否依据自己面对的方向。（默认是目标方向）
        //[USE MY BASEPOS]                // 指定相对坐标移动是否以自身坐标为准（默认是目标坐标）
        //[NOT USE OBJECT DIRECTION]            // 不进行方向修正
        //[USE MAP POS]                    // 坐标移动使用地图绝对坐标。
        //[TEAM] 100                     // 指定队伍 0~ 为角色队伍 100~ 怪物队伍 200~ 中立
        //[USE OBJECT ZPOS]                // 修改为跟随对象的 Z 坐标。
        //[SUMMON TIME] 1000                //设置召唤物存活时间

        //mkjung 120518 add.
        [SUMMON MARK] 0                    // 不显示地面召唤标记 //必须在 [SUMMON TIME] 之后书写
        [FIX DIRECTION] [LEFT] [RIGHT] [RANDOM] [NEUTRAL]        // 指定面对的方向。

    **[/SUMMON MONSTER]**
```

**官方示例：actionsamplebytool.act**

```pvf
{exp}召唤怪物{/exp}[SUMMON MONSTER]
		//INDEX, LEVEL, POS 必须按顺序输入。其他可输可不输。
		{must1}{exp}索引编号{/exp}[INDEX]
		//mkjung 120515 int->rndint 修改。
			{must1}{rndint(:)}
		[!INDEX]
		{must2}{exp}魔法等级{/exp}[LEVEL]
			{must1}{int(0:)}
		[!LEVEL]
		{must3}{exp}父坐标的相对坐标{/exp}[POS]
			{must1}{exp}召唤的X坐标（相对坐标）{/exp}{rndint(:)}
			{must2}{exp}召唤的Y坐标（相对坐标）{/exp}{rndint(:)}
			{must3}{exp}召唤的Z坐标（相对坐标）{/exp}{rndint(:)}
		[!POS]
		{opt1}{exp}无召唤效果出现{/exp}{etc}[NO EFFECT]
		{opt2}{exp}绘制魔法阵同时召唤{/exp}{etc}[MAGIC CIRCLE]
		{opt3}{exp}怪物如跳出般召唤{/exp}[JUMP OUT]
			{must1}{exp}X速度{/exp}{rndint(:)}
			{must2}{exp}Y速度{/exp}{rndint(:)}
			//mkjung 120515 int->rndint 修改。
			{must3}{exp}高度{/exp}{rndint(:)}
			{must4}{exp}中立{/exp}[NEUTRAL]
			{must4}{exp}左侧{/exp}[LEFT]
			{must4}{exp}右侧{/exp}[RIGHT]
			{must4}{exp}随机方向{/exp}[RANDOM]
			{must5}{exp}中立{/exp}[NEUTRAL]
			{must5}{exp}上{/exp}[UP]
			{must5}{exp}下{/exp}[DOWN]
			{must5}{exp}随机方向{/exp}[RANDOM]
		[!JUMP OUT]
		{opt4}{exp}以目标的队伍出现。（默认是主人的队伍。）{/exp}{etc}[USE TARGET TEAM]
		{opt5}{exp}坐标基准X轴移动是否按自己朝向的方向决定{/exp}{etc}[USE MY DIRECTION]
		{opt6}{exp}指定相对坐标移动是否以自己的坐标为基准{/exp}{etc}[USE MY BASEPOS]
		{opt7}{exp}不进行方向修正{/exp}{etc}[NOT USE OBJECT DIRECTION]
		{opt8}{exp}坐标移动使用地图绝对坐标{/exp}{etc}[USE MAP POS]
		{opt9}{exp}队伍指定{/exp}[TEAM]
			{must1}{exp}0~：角色队伍 100~：怪物队伍 200~：中立{/exp}{int(0:)}
		[!TEAM]
		{opt10}{exp}Z坐标跟随物体坐标修改{/exp}{etc}[USE OBJECT ZPOS]
		{opt11}{exp}设置召唤物的存活时间{/exp}[SUMMON TIME]
			{must1}{exp}存活时间（ms）{/exp}{int(0:)}
		[!SUMMON TIME]

		//mkjung 120518 添加。
		{opt12}[SUMMON MARK]
			{must1}{exp}召唤标记显示的值{/exp}{int(0:)} // 不显示地面召唤标记 //
		[!SUMMON MARK]

		//mkjung 120518 添加。
		{exp}指定要看向的方向{/exp}[FIX DIRECTION]
			{must1}{exp}中立{/exp}[NEUTRAL]
			{must1}{exp}左侧{/exp}[LEFT]
			{must1}{exp}右侧{/exp}[RIGHT]
			{must1}{exp}随机方向{/exp}[RANDOM]
		[!FIX DIRECTION]
	[/SUMMON MONSTER]
```

---

## 地下城（5 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `basis level` | 副本内怪物的平均等级 | dungeonsample_new_drop.dgn、dungeonsample.dgn |
| `champion` | champion | dungeonsample_new_drop.dgn、dungeonsample.dgn |
| `coin limit` | 副本内的复活次数 | dungeonsample_new_drop.dgn、dungeonsample.dgn |
| `experience increasing point` | 副本内的经验值获取倍率 | dungeonsample_new_drop.dgn、dungeonsample.dgn |
| `minimum required level` | 开启地下城的等级 | dungeonsample_new_drop.dgn、dungeonsample.dgn |

### `basis level`

**标题**：副本内怪物的平均等级

**官方示例：dungeonsample_new_drop.dgn**

```pvf
[basis level]  4            // 怪物的标准等级
```

**官方示例：dungeonsample.dgn**

```pvf
[basis level]  4            // 怪物的标准等级
```

### `champion`

**标题**：champion

[champion]
100	100	100	100	100

普通级、冒险级、勇士级、王者级、英雄级
出现精英怪的几率

1=1%
也就是说赋予100时，每个房间必出1个

**官方示例：dungeonsample_new_drop.dgn**

```pvf
[champion]  10 15 20 30            // 各难度下整个地下城中将出现的冠军怪物数量
```

**官方示例：dungeonsample.dgn**

```pvf
[champion]  10 15 20 30            // 各难度下整个地下城中将出现的冠军怪物数量
```

### `coin limit`

**标题**：副本内的复活次数

副本内的复活次数
[coin limit]
      6
上面这种代表副本内生命值耗尽时可复活6次
通过移除此标签或将数字改为-1即可不限制复活次数

**官方示例：dungeonsample_new_drop.dgn**

```pvf
// 不想指定则移除标签或将物品索引设为65535
[coin limit] 3                // 地下城中复活币限制使用次数。（队伍全体）移除标签或设为-1则无限制
```

**官方示例：dungeonsample.dgn**

```pvf
// 不想指定则移除标签或将物品索引设为65535
[coin limit] 3                // 地下城中复活币限制使用次数。（队伍全体）移除标签或设为-1则无限制
```

### `experience increasing point`

**标题**：副本内的经验值获取倍率

副本内的经验值获取倍率
0.5代表只有50%的获取效率

**官方示例：dungeonsample_new_drop.dgn**

```pvf
[experience increasing point]  1.3    // 经验值权重
```

**官方示例：dungeonsample.dgn**

```pvf
[experience increasing point]  1.3    // 经验值权重
```

### `minimum required level`

**标题**：开启地下城的等级

**官方示例：dungeonsample_new_drop.dgn**

```pvf
[minimum required level]  11        // 进入地下城所需的最低要求等级
```

**官方示例：dungeonsample.dgn**

```pvf
[minimum required level]  11        // 进入地下城所需的最低要求等级
```

---

## 地图（2 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `dungeon start area` | 进入该副本地图时的入场坐标（大概是） | mapsample.map |
| `sound` | — | mapsample.map |

### `dungeon start area`

**标题**：进入该副本地图时的入场坐标（大概是）

进入该副本地图时的入场坐标（大概是）
1、X轴位置
2、Y轴位置
3、
4、

**官方示例：mapsample.map**

```pvf
[dungeon start area] 950 219 114 172 //在地牢起始地图设置，角色开始地牢时位置的x坐标,y坐标,x大小,y大小
```

### `sound`

进入副本时会播放的背景音乐和环境音乐

背景音乐位置在客户端的[Music]
环境音乐位置在客户端的[SoundPacks]（大概是）

[SoundPacks]内的声音文件需借助npk解包工具查看
目前据作者所知的npk解包工具有：
ExtractorSharp（可编辑贴图、音乐）
黑猫（适合拿来做时装）

**官方示例：mapsample.map**

```pvf
[sound] //进入地图时输出的声音标签列表
`AMBIENT_FOREST`
`BGM_FOREST`
[/sound]
```

---

## 杂项（2 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `avatar` | - 时装 - 时装店出售的商品列表 | cashshopsample.etc |
| `difficulty` | - 在任务(*.qst)中 - difficulty 奖励权重 (百分比) | questparameter.etc |

### `avatar`

**标题**：- 时装 / - 时装店出售的商品列表

时装

商城里是装扮购买界面

**官方示例：cashshopsample.etc**

```pvf
[avatar]    // 时装店出售的商品列表。
5        // 自动进行子分类，并保持顺序。
300
34
23
[/avatar]
```

### `difficulty`

**标题**：- 在任务(*.qst)中 / - difficulty 奖励权重 (百分比)

在任务(*.qst)中，设置难度级别参数。
* 详情参考路径 : { n_quest/questparameter.etc }
————————<分割线>————————
该词条位于 : { etc/hellparty.etc }的路径里时，代表：

第1竖排 : [深渊难度] : 传奇、英雄、王者、勇士、冒险
     //对应地下城难度：英雄、王者、勇士、冒险、普通

第2竖排 : 各个难度下击杀深渊房最终怪物时，所掉落[装备]数量

第3竖排 : 各个难度下击杀深渊房最终怪物时，所掉落[道具]数量
              `（可能是，等后续测试完成会重新追加注释）`

第4竖排 : 各个难度下击杀深渊房最终怪物时，
                对掉落[更好品质装备]的{概率}或{权重}的增幅
             `（可能是，等后续测试完成会重新追加注释）`

第5竖排 : 同4

第6竖排 : （等待后续测试以追加标签注释）

`最后编辑时间 : 2026/3/18`

**官方示例：questparameter.etc**

```pvf
// difficulty 奖励权重 (百分比)
[difficulty]
`S`	300
`A`	250
`B`	200
`C`	150
`M`	100
[/difficulty]
```

---

## 角色（1 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `weapon hit info` | 武器命中信息 | charactersample.chr |

### `weapon hit info`

**标题**：武器命中信息

武器命中信息

//示例：
	`[cut]`
	`[blood]`	90	1.0	0.0	0.0

`[cut]` = 武器打击类型为`切割`，就像太刀一样
`[blood]` = 武器命中时`有出血视觉效果`

`出血视觉效果开关`的右边第1个数字也就是90代表普攻卡肉时间为0.09秒
——————————————————————
//示例2：
	`[blow]`
	`[no blood]`	100	1.2	0.1	-0.95

`[blow]` = 武器打击类型为`钝击`，就像钝器一样
`[no blood]` = 武器命中时`无出血视觉效果`
——————————————————————
补充：第二个数值是命中硬直比率，比如卡肉时间0.2秒，
           命中硬直比率为2.0，那么实际造成的硬直是0.4秒

**官方示例：charactersample.chr**

```pvf
[weapon hit info]            // 武器的子类型信息（详情请参考 AttackInfo 示例）
`[blow]` `[no blood]` 50 1.0
`[blow]` `[no blood]` 50 1.0
`[blow]` `[blood]` 10 1.0
`[blow]` `[no blood]` 50 1.0
`[blow]` `[no blood]` 100 2.0
`[cut]` `[no blood]` 100 2.0
[/weapon hit info]            // 必须用此关闭
```

---

## 无示例（179 条）

| 标签 | 标题 | 示例文件 |
| --- | --- | --- |
| `(ATTACK)` | 普攻 | 无 |
| `(BUFF)` | 空格键（可以单独作为一个手搓指令） | 无 |
| `(DOWN)` | 下 | 无 |
| `(LEFT)` | 左（同时也对应手搓指令的向后移动） | 无 |
| `(RIGHT)` | 右（同时也对应手搓指令的向前移动） | 无 |
| `(SKILL)` | Z（可以单独作为一个手搓指令） | 无 |
| `(UP)` | 上 | 无 |
| `additional character status` | APC的面板 | 无 |
| `ai pattern` | AI逻辑 | 无 |
| `ai pattern` | AI逻辑 | 无 |
| `amulet` | 装备 | 无 |
| `any` | 所有异常状态效果 | 无 |
| `apply ultimate` | 若此标签在 | 无 |
| `at fighter` | 男格斗 | 无 |
| `at mage` | 男魔法师 | 无 |
| `at swordman` | 女鬼剑士 | 无 |
| `atk super on scr` | 使用指定攻击动作时进入霸体 | 无 |
| `attack damage rate` | 伤害比例 | 无 |
| `ATTACK_SPEED` | 攻击速度 | 无 |
| `attackinfo` | 攻击数据信息 | 无 |
| `auction_button` | 拍卖行按钮 | 无 |
| `aura_gauge_lineardodge` | 光环槽按钮（或许是） | 无 |
| `avenger` | 圣骑士转职 | 无 |
| `back` | 判定方向 | 无 |
| `battlemage` | 战斗法师 | 无 |
| `beast` | 野兽 | 无 |
| `bleeding` | 异常效果 | 无 |
| `blind` | 异常效果 | 无 |
| `blow` | 打击类型 | 无 |
| `breakable` | 霸体 | 无 |
| `cerashop_button` | 商城按钮 | 无 |
| `character job` | 职业 | 无 |
| `character status rate` | APC的面板倍率 | 无 |
| `close-carefully` | 游击 | 无 |
| `close-manace` | 施压 | 无 |
| `close-passive` | 被动攻击 | 无 |
| `close-tough` | 贴身 | 无 |
| `coat` | 装备 | 无 |
| `coin` | 复活币 | 无 |
| `common` | 该词条位于导师技能商店内时 | 无 |
| `compound emblem` | 徽章合成 | 无 |
| `confuse` | 异常效果 | 无 |
| `convert avatar` | 重铸徽章 | 无 |
| `counter` | 破招 | 无 |
| `create guild agit` | 创建公会 | 无 |
| `creator mage` | 外传职业 | 无 |
| `creature` | 宠物 | 无 |
| `crusader` | 圣骑士 | 无 |
| `DAMAGE BOX` | 受击判定框 | 无 |
| `DAMAGE TYPE` | 霸体代码 | 无 |
| `deadlystrike` | 异常效果 | 无 |
| `deadlystrike resistance` | 致命一击抗性 | 无 |
| `deelement` | 异常效果 | 无 |
| `deelement resistance` | 元素属性剥离抗性 | 无 |
| `delete guild agit` | 解散公会 | 无 |
| `demonic swordman` | 黑暗武士 | 无 |
| `destination change term` | 存在多个敌对目标时 | 无 |
| `disease` | 异常效果 | 无 |
| `disjoint` | 分解 | 无 |
| `divine armor` | 神圣护甲 | 无 |
| `down` | 动作值判定 | 无 |
| `dragon` | 龙族 | 无 |
| `durability decrease rate` | 使用技能所消耗的耐久 | 无 |
| `elementalmaster` | 元素师 | 无 |
| `equipment` | 装备编号 品质 强化等级 | 无 |
| `exorcist` | 圣骑士转职 | 无 |
| `fighter` | 女格斗 | 无 |
| `fire attack` | 火属性强化 | 无 |
| `fixture` | 固定位置 | 无 |
| `fort armor` | 建筑护甲 | 无 |
| `freeze` | 异常效果 | 无 |
| `goblin` | 哥布林族 | 无 |
| `gold limit from level` | 每个等级可容纳的金币上限 | 无 |
| `grappler` | 柔道家 | 无 |
| `guild` | 公会 | 无 |
| `gunner` | 男枪手 | 无 |
| `hit horizon` | 攻击判定 | 无 |
| `hold` | 异常效果 | 无 |
| `HP_REGENRATE` | 每分钟恢复生命值 | 无 |
| `human` | 人形 | 无 |
| `human armor` | 人形护甲 | 无 |
| `hybrid` | 组合体 | 无 |
| `increase status type` | 使用此道具后获得的状态 | 无 |
| `infighter` | 蓝拳圣使 | 无 |
| `insect` | 昆虫 | 无 |
| `inventory_button` | 背包按钮 | 无 |
| `item shop` | NPC商店 | 无 |
| `job change` | 副职业 | 无 |
| `keep distance with target` | 与敌对目标保持的攻击距离 | 无 |
| `league ban` | 添加此代码可以在PVP对局中禁用此技能 | 无 |
| `lugaru` | 猫妖族 | 无 |
| `machine` | 机械 | 无 |
| `mage` | 女魔法 | 无 |
| `magic` | 魔法 | 无 |
| `MAGIC CIRCLE` | 魔法阵 | 无 |
| `magic stone` | 装备 | 无 |
| `magical` | 魔法伤害 | 无 |
| `magical attack bonus` | 魔法攻击力 | 无 |
| `magical critical hit` | 魔法暴击率 | 无 |
| `magical defense bonus` | 魔法防御力 | 无 |
| `minimum info` | APC的基础信息 | 无 |
| `MP_REGENRATE` | 每分钟恢复魔法值 | 无 |
| `myinfo_button` | 个人信息按钮 | 无 |
| `necromancer` | 暗夜使者转职 | 无 |
| `nenmaster` | 气功师 | 无 |
| `Never gonna give you up~~` | （歌词翻译）永远不会抛弃你♪♪ | 无 |
| `Never gonna see——goodbye~~` | （歌词翻译）永远不轻言再见♪♪ | 无 |
| `next skill` | 关联技能 | 无 |
| `none` | 该词条位于技能树时 | 无 |
| `on appear` | — | 无 |
| `on appear` | 出现在自身附近时 | 无 |
| `on attack` | 发起攻击 | 无 |
| `on damage` | 受到攻击 | 无 |
| `on die` | 生命值耗尽 | 无 |
| `on disappear` | [on appear]台词结束后接上的话 | 无 |
| `on etc` | 特殊触发 | 无 |
| `on revenge` | 产生仇恨目标时 | 无 |
| `on stand` | 处于站立状态时 | 无 |
| `on village` | 处于【怪物攻城战】期间时 | 无 |
| `package` | 礼包 | 无 |
| `pants` | 装备 | 无 |
| `party` | 对身边友军也会生效 | 无 |
| `physical` | 物理伤害 | 无 |
| `physical attack bonus` | 物理攻击力 | 无 |
| `physical critical hit` | 物理暴击率 | 无 |
| `physical defense bonus` | 物理防御力 | 无 |
| `physical magical change` | 物理、魔法伤害转换 | 无 |
| `piercing` | 异常效果 | 无 |
| `plant` | 植物 | 无 |
| `poison` | 异常效果 | 无 |
| `premium` | 时效道具 | 无 |
| `priest` | 男圣职 | 无 |
| `product item` | 生产 | 无 |
| `quest_button` | 任务按钮 | 无 |
| `quick item` | 快捷栏道具 | 无 |
| `quick skill` | 快捷栏技能 | 无 |
| `range combat` | 远程攻击 | 无 |
| `recover stamina` | 解除虚弱 | 无 |
| `rigidity` | 硬直 | 无 |
| `ring` | 装备 | 无 |
| `rogue` | 暗夜使者转职 | 无 |
| `secret shop` | 加百利商店 | 无 |
| `separate attack` | 独立攻击力 | 无 |
| `sera shop` | 进入商城 | 无 |
| `Seria Blessing` | 赛丽亚的祝福活动 | 无 |
| `shoes` | 装备 | 无 |
| `shoulder` | 装备 | 无 |
| `silence` | 异常效果 | 无 |
| `skill under cooltime effect each` | 冷却时间中的技能 | 无 |
| `skill_button` | 技能按钮 | 无 |
| `sleep` | 异常效果 | 无 |
| `sp table` | sp table | 无 |
| `spirit` | 精灵族 | 无 |
| `stat change duration` | 道具效果持续时间 | 无 |
| `stat weights by rarity` | stat weights by rarity | 无 |
| `stone` | 异常效果 | 无 |
| `streetfighter` | 街霸 | 无 |
| `striker` | 散打 | 无 |
| `stun` | 异常效果 | 无 |
| `summoner` | 召唤师 | 无 |
| `SUPERARMOR` | 霸体 | 无 |
| `support` | 装备 | 无 |
| `swordman` | 男鬼剑士 | 无 |
| `table` | 强化/增幅属性（从左到右） | 无 |
| `tau` | 牛头族 | 无 |
| `think term` | 思考时间（1000 = 1秒） | 无 |
| `time sand` | 导师技能商店（或许是） | 无 |
| `title name` | 装备 | 无 |
| `upgrade item` | 强化装备 | 无 |
| `url hyperlink` | URL超级链接 | 无 |
| `use effect explain` | 道具自带的使用效果介绍开关 | 无 |
| `use zoom rate` | 副本内镜头缩放倍率 | 无 |
| `vision` | 视力 | 无 |
| `waist` | 装备 | 无 |
| `warlike` | 攻击欲望 | 无 |
| `weapon` | 装备 | 无 |
| `witch` | 魔道学者 | 无 |
| `world drop` | 全局掉落 | 无 |
| `wrist` | 装备 | 无 |

### `(ATTACK)`

**标题**：普攻

（无示例）

### `(BUFF)`

**标题**：空格键（可以单独作为一个手搓指令）

（无示例）

### `(DOWN)`

**标题**：下

（无示例）

### `(LEFT)`

**标题**：左（同时也对应手搓指令的向后移动）

（无示例）

### `(RIGHT)`

**标题**：右（同时也对应手搓指令的向前移动）

（无示例）

### `(SKILL)`

**标题**：Z（可以单独作为一个手搓指令）

（无示例）

### `(UP)`

**标题**：上

（无示例）

### `additional character status`

**标题**：APC的面板

[additional character status]APC的面板，从左到右依次为：
1、最大生命值
2、最大魔法值
3、物理攻击力
4、物理防御
5、魔法攻击力
6、魔法防御
7、背包容量
8、生命值恢复效率
9、魔法值恢复效率
10、移动速度
11、攻击速度
12、施法速度
13、硬直
14、跳跃力
15、负重
16、耐力
17、火属性抗性
18、冰属性抗性
19、暗属性抗性
20、光属性抗性
21、减速抗性
22、冰冻抗性
23、中毒抗性
24、眩晕抗性
25、诅咒抗性
26、致盲抗性
27、感电抗性
28、石化抗性
29、睡眠抗性
30、灼烧抗性
31、武器损坏抗性
32、出血抗性
33、穿透抗性
34、卡顿抗性
35、混乱抗性
36、束缚抗性
37、装备损坏抗性

（无示例）

### `ai pattern`

**标题**：AI逻辑

（无示例）

### `ai pattern`（第 2 条）

**标题**：AI逻辑

（无示例）

### `amulet`

**标题**：装备

装备：项链

（无示例）

### `any`

**标题**：所有异常状态效果

（无示例）

### `apply ultimate`

**标题**：若此标签在

若此标签在
{ etc/ultimatedungeonlist.etc }
路径内，则将副本编号写入即可开放王者级难度

（无示例）

### `at fighter`

**标题**：男格斗

（无示例）

### `at mage`

**标题**：男魔法师

（无示例）

### `at swordman`

**标题**：女鬼剑士

（无示例）

### `atk super on scr`

**标题**：使用指定攻击动作时进入霸体

[atk super on scr]使用指定攻击动作时进入霸体

上方选择攻击动作（0为第1个，1为第2个，以此类推）
下方选择霸体类型：
`[breakable]`	 = 可以被破坏
`[unbreakable]` = 不可被破坏

`[breakable]`	和`[unbreakable]`通用写法介绍：
1、护盾耐久值，     根据最大生命值百分比决定，写多少就是多少百分比
2、护盾恢复效率，  写多少就是每秒恢复多少百分比（或许是）
3、近战防御力（固定值）
4、远程防御力（固定值）

（无示例）

### `attack damage rate`

**标题**：伤害比例

伤害比例
即1.0代表能打出100%的伤害
0.9代表只能打出90%的伤害

（无示例）

### `ATTACK_SPEED`

**标题**：攻击速度

（无示例）

### `attackinfo`

**标题**：攻击数据信息

（无示例）

### `auction_button`

**标题**：拍卖行按钮

（无示例）

### `aura_gauge_lineardodge`

**标题**：光环槽按钮（或许是）

（无示例）

### `avenger`

**标题**：圣骑士转职

圣骑士转职：复仇者

台改暗夜使者转职：影舞者

（无示例）

### `back`

**标题**：判定方向

判定方向：身后

（无示例）

### `battlemage`

**标题**：战斗法师

（无示例）

### `beast`

**标题**：野兽

（无示例）

### `bleeding`

**标题**：异常效果

异常效果：出血

（无示例）

### `blind`

**标题**：异常效果

异常效果：失明

（无示例）

### `blow`

**标题**：打击类型

打击类型：钝击

（无示例）

### `breakable`

**标题**：霸体

霸体：可以被破坏

（无示例）

### `cerashop_button`

**标题**：商城按钮

（无示例）

### `character job`

**标题**：职业

拥有此词条对象为技能树时，代表这是技能树坐标标签
//建议搭配工具修改坐标

//示例：
[character job]
	`[gunner]`        //选择职业
	`none`	          //选择职业分支
	[skill info]
		[index]
			4         //技能编号
		[icon pos]
			235	0  //技能坐标
	[/skill info]
[/character job]
以上代表男枪手的未转职职业拥有1个`膝撞（编号4）`技能，
该技能位于 X轴235，Y轴0 的技能树位置

职业：
	`[swordman]`//男鬼剑
	`[gunner]`//男枪手
	`[mage]`//女魔法
	`[fighter]`//女格斗
	`[priest]`//男圣职
	`[thief]`//暗夜使者

职业分支：
	`none`//	未转职

	`weaponmaster`//剑魂
	`soulbringer`//鬼泣
	`berserker`//狂战士
	`asura`//阿修罗

	`ranger`//漫游枪手
	`launcher`//枪炮师
	`mechanic`//机械师
	`spitfire`//弹药专家

	`elementalmaster`//元素师
	`summoner`//召唤师
	`battlemage`//战斗法师
	`witch`//魔道学者

	`nenmaster`//气功师
	`striker`//散打
	`streetfighter`//街霸
	`grappler`//柔道家

	`crusader`//圣骑士
	`infighter`//蓝拳圣使
	`exorcist`//驱魔师
	`avenger`//复仇者

	`rogue`//刺客
	`necromancer`//死灵术士
	`exorcist`//忍者（台改）
	`avenger`//影舞者（台改）

（无示例）

### `character status rate`

**标题**：APC的面板倍率

[character status rate]APC的面板倍率，从左到右依次为：
1、最大生命值倍率
2、最大魔法值倍率
3、力量倍率
4、体力倍率
5、智力倍率
6、精神倍率
7、物理攻击力倍率
8、物理防御倍率
9、魔法攻击力倍率
10、魔法防御倍率
11、背包容量倍率
12、生命值恢复效率倍率
13、魔法值恢复效率倍率
14、移动速度倍率
15、攻击速度倍率
16、施法速度倍率
17、硬直倍率
18、跳跃力倍率
19、负重倍率
20、耐力倍率
21、火属性抗性倍率
22、冰属性抗性倍率
23、暗属性抗性倍率
24、光属性抗性倍率
25、减速抗性倍率
26、冰冻抗性倍率
27、中毒抗性倍率
28、眩晕抗性倍率
29、诅咒抗性倍率
30、致盲抗性倍率
31、感电抗性倍率
32、石化抗性倍率
33、睡眠抗性倍率
34、灼烧抗性倍率
35、武器损坏抗性倍率
36、出血抗性倍率
37、穿透抗性倍率
38、卡顿抗性倍率
39、混乱抗性倍率
40、束缚抗性倍率
41、装备损坏抗性倍率

（无示例）

### `close-carefully`

**标题**：游击

（无示例）

### `close-manace`

**标题**：施压

（无示例）

### `close-passive`

**标题**：被动攻击

（无示例）

### `close-tough`

**标题**：贴身

（无示例）

### `coat`

**标题**：装备

装备：上衣

（无示例）

### `coin`

**标题**：复活币

复活币

商城里是道具→复活币购买界面

（无示例）

### `common`

**标题**：该词条位于导师技能商店内时

该词条位于导师技能商店内时，代表这是全职业通用技能，比如受身蹲伏等等

（无示例）

### `compound emblem`

**标题**：徽章合成

徽章合成

NPC的徽章合成功能

（无示例）

### `confuse`

**标题**：异常效果

异常效果：混乱

（无示例）

### `convert avatar`

**标题**：重铸徽章

重铸徽章

也就是NPC的分解时装为徽章功能，如达芙妮

（无示例）

### `counter`

**标题**：破招

（无示例）

### `create guild agit`

**标题**：创建公会

创建公会

博肯的创建公会功能

（无示例）

### `creator mage`

**标题**：外传职业

外传职业：缔造者

（无示例）

### `creature`

**标题**：宠物

宠物

商城里是宠物→消耗品购买界面

（无示例）

### `crusader`

**标题**：圣骑士

（无示例）

### `DAMAGE BOX`

**标题**：受击判定框

受击判定框
拥有该标签表示使用此技能时可以被命中，移除此标签可赋予一帧的无敌时间
[DAMAGE BOX]
X1   Y1  Z1   X2  Y2  Z2
X1:以ani坐标为基点的碰撞框X轴坐标
Y1:以ani坐标为基点的碰撞框Y轴坐标
Z1:以ani坐标为基点的碰撞框Z轴坐标
X2:以ani坐标为基点的碰撞框X轴大小
Y2:以ani坐标为基点的碰撞框Y轴大小
Z2:以ani坐标为基点的碰撞框Z轴大小

（无示例）

### `DAMAGE TYPE`

**标题**：霸体代码

霸体代码

	[DAMAGE TYPE]
		`SUPERARMOR`    超级护甲（一般拿来添加进帧数文件的）

（无示例）

### `deadlystrike`

**标题**：异常效果

异常效果：致命一击

//字面意思，直接清空血条的异常效果

（无示例）

### `deadlystrike resistance`

**标题**：致命一击抗性

（无示例）

### `deelement`

**标题**：异常效果

异常效果：属性剥离

//令该目标的所有攻击均变为无属性伤害

（无示例）

### `deelement resistance`

**标题**：元素属性剥离抗性

（无示例）

### `delete guild agit`

**标题**：解散公会

解散公会

博肯的解散公会功能

（无示例）

### `demonic swordman`

**标题**：黑暗武士

（无示例）

### `destination change term`

**标题**：存在多个敌对目标时

存在多个敌对目标时，转换目标所用时间

（无示例）

### `disease`

**标题**：异常效果

异常效果：疾病

（无示例）

### `disjoint`

**标题**：分解

（无示例）

### `divine armor`

**标题**：神圣护甲

（无示例）

### `down`

**标题**：动作值判定

动作值判定：击倒

（无示例）

### `dragon`

**标题**：龙族

（无示例）

### `durability decrease rate`

**标题**：使用技能所消耗的耐久

（无示例）

### `elementalmaster`

**标题**：元素师

（无示例）

### `equipment`

**标题**：装备编号 品质 强化等级

装备编号 品质 强化等级
武器
防具（上衣，头肩，下装，鞋子，腰带）
首饰（项链，手镯，戒指）
时装（第一个是头发 最后是鞋子）

（无示例）

### `exorcist`

**标题**：圣骑士转职

圣骑士转职：驱魔师

台改暗夜使者转职：忍者

（无示例）

### `fighter`

**标题**：女格斗

（无示例）

### `fire attack`

**标题**：火属性强化

火属性强化
光属性强化 = [light attack]
火属性强化 = [fire attack]
冰属性强化 = [water attack]
暗属性强化 = [dark attack]
所有属性强化 = [all elemental attack]

（无示例）

### `fixture`

**标题**：固定位置

（无示例）

### `fort armor`

**标题**：建筑护甲

（无示例）

### `freeze`

**标题**：异常效果

异常效果：冰冻

（无示例）

### `goblin`

**标题**：哥布林族

（无示例）

### `gold limit from level`

**标题**：每个等级可容纳的金币上限

[gold limit from level]每个等级可容纳的金币上限

左边是等级                  右边是金币上限

（无示例）

### `grappler`

**标题**：柔道家

（无示例）

### `guild`

**标题**：公会

公会

博肯的公会管理功能

（无示例）

### `gunner`

**标题**：男枪手

（无示例）

### `hit horizon`

**标题**：攻击判定

攻击判定：平推

（无示例）

### `hold`

**标题**：异常效果

异常效果：束缚

（无示例）

### `HP_REGENRATE`

**标题**：每分钟恢复生命值

（无示例）

### `human`

**标题**：人形

（无示例）

### `human armor`

**标题**：人形护甲

（无示例）

### `hybrid`

**标题**：组合体

（无示例）

### `increase status type`

**标题**：使用此道具后获得的状态

使用此道具后获得的状态：
`[expUp]` = 获得经验

（无示例）

### `infighter`

**标题**：蓝拳圣使

（无示例）

### `insect`

**标题**：昆虫

（无示例）

### `inventory_button`

**标题**：背包按钮

（无示例）

### `item shop`

**标题**：NPC商店

NPC商店

写多少号就是调用多少号的NPC商店，比如写8号，就是调用8号的诺顿商店

（无示例）

### `job change`

**标题**：副职业

副职业

NPC的副职业功能
1附魔师
2药剂师
3分解师
4人偶师

（无示例）

### `keep distance with target`

**标题**：与敌对目标保持的攻击距离

（无示例）

### `league ban`

**标题**：添加此代码可以在PVP对局中禁用此技能

（无示例）

### `lugaru`

**标题**：猫妖族

（无示例）

### `machine`

**标题**：机械

（无示例）

### `mage`

**标题**：女魔法

（无示例）

### `magic`

**标题**：魔法

（无示例）

### `MAGIC CIRCLE`

**标题**：魔法阵

魔法阵
也就是说加上这个标签之后召唤物机制会出现魔法阵特效
（应该可能也许大概是）

（无示例）

### `magic stone`

**标题**：装备

装备：魔法石

（无示例）

### `magical`

**标题**：魔法伤害

（无示例）

### `magical attack bonus`

**标题**：魔法攻击力

（无示例）

### `magical critical hit`

**标题**：魔法暴击率

（无示例）

### `magical defense bonus`

**标题**：魔法防御力

（无示例）

### `minimum info`

**标题**：APC的基础信息

[minimum info]APC的基础信息，从左到右依次为：
1、APC的名字
2、职业类型（职业类型可在PVF主界面的character/character.lst查看）
3、主成长类型
4、副成长类型
5、显示成长光环（开启改1，关闭改0）
6、等级
7、角色状态
8、用户类型（1为GM  0为玩家）
9、PVP排名
10、公会
11、坐骑
12、宠物编号
13、宠物名称
14、宠物能量满格（开启改1，关闭改0）
15、高级网吧特权
16、黑名单等级

（无示例）

### `MP_REGENRATE`

**标题**：每分钟恢复魔法值

（无示例）

### `myinfo_button`

**标题**：个人信息按钮

（无示例）

### `necromancer`

**标题**：暗夜使者转职

暗夜使者转职：死灵术士

（无示例）

### `nenmaster`

**标题**：气功师

（无示例）

### `Never gonna give you up~~`

**标题**：（歌词翻译）永远不会抛弃你♪♪

（无示例）

### `Never gonna see——goodbye~~`

**标题**：（歌词翻译）永远不轻言再见♪♪

（无示例）

### `next skill`

**标题**：关联技能

关联技能

将该词条赋予某个技能的技能树坐标标签内并填写其他技能编号时，
就会在游戏内技能树自动划线并显示箭头，代表这是其他技能的前置技能

（无示例）

### `none`

**标题**：该词条位于技能树时

无

该词条位于技能树时，代表未转职职业

（无示例）

### `on appear`

游走

（无示例）

### `on appear`（第 2 条）

**标题**：出现在自身附近时

（无示例）

### `on attack`

**标题**：发起攻击

（无示例）

### `on damage`

**标题**：受到攻击

（无示例）

### `on die`

**标题**：生命值耗尽

（无示例）

### `on disappear`

**标题**：[on appear]台词结束后接上的话

[on appear]台词结束后接上的话，需要分到同一组

（无示例）

### `on etc`

**标题**：特殊触发

（无示例）

### `on revenge`

**标题**：产生仇恨目标时

（无示例）

### `on stand`

**标题**：处于站立状态时

（无示例）

### `on village`

**标题**：处于【怪物攻城战】期间时

（无示例）

### `package`

**标题**：礼包

礼包

商城里是礼包购买界面

（无示例）

### `pants`

**标题**：装备

装备：下装

（无示例）

### `party`

**标题**：对身边友军也会生效

（无示例）

### `physical`

**标题**：物理伤害

（无示例）

### `physical attack bonus`

**标题**：物理攻击力

（无示例）

### `physical critical hit`

**标题**：物理暴击率

（无示例）

### `physical defense bonus`

**标题**：物理防御力

（无示例）

### `physical magical change`

**标题**：物理、魔法伤害转换

（无示例）

### `piercing`

**标题**：异常效果

异常效果：破甲

//暂不清楚是清空防御还是减少固定值防御还是按百分比减少防御

（无示例）

### `plant`

**标题**：植物

（无示例）

### `poison`

**标题**：异常效果

异常效果：中毒

（无示例）

### `premium`

**标题**：时效道具

时效道具

商城里是道具→优惠的购买界面

（无示例）

### `priest`

**标题**：男圣职

（无示例）

### `product item`

**标题**：生产

生产

罗杰的商店，同时也是生产材料功能

（无示例）

### `quest_button`

**标题**：任务按钮

（无示例）

### `quick item`

**标题**：快捷栏道具

快捷栏道具
左边是道具代码      右边是道具数量

（无示例）

### `quick skill`

**标题**：快捷栏技能

快捷栏技能

也就是ASDFGH以及QWERTY这种技能

左边是技能编号      右边是技能等级

（无示例）

### `range combat`

**标题**：远程攻击

（无示例）

### `recover stamina`

**标题**：解除虚弱

解除虚弱

NPC的解除虚弱功能

（无示例）

### `rigidity`

**标题**：硬直

（无示例）

### `ring`

**标题**：装备

装备：戒指

（无示例）

### `rogue`

**标题**：暗夜使者转职

暗夜使者转职：刺客

（无示例）

### `secret shop`

**标题**：加百利商店

（无示例）

### `separate attack`

**标题**：独立攻击力

（无示例）

### `sera shop`

**标题**：进入商城

进入商城

在NPC的功能里通过此功能跳转到游戏内商城

（无示例）

### `Seria Blessing`

**标题**：赛丽亚的祝福活动

（无示例）

### `shoes`

**标题**：装备

装备：鞋子

（无示例）

### `shoulder`

**标题**：装备

装备：头肩

（无示例）

### `silence`

**标题**：异常效果

异常效果：沉默

（无示例）

### `skill under cooltime effect each`

**标题**：冷却时间中的技能

（无示例）

### `skill_button`

**标题**：技能按钮

（无示例）

### `sleep`

**标题**：异常效果

异常效果：睡眠

（无示例）

### `sp table`

**标题**：sp table

[sp table]
左边是职业等级      右边是升到当前等级可获得的sp点

（无示例）

### `spirit`

**标题**：精灵族

（无示例）

### `stat change duration`

**标题**：道具效果持续时间

道具效果持续时间：
一般与[stat change]联动使用

//示例：
[stat change duration]
	7000
	`myself`
//以上为使用道具之后效果持续7秒，且仅对自身生效

1000 = 1秒

`myself` = 仅对自身生效
`party` = 对周边友军也会生效

（无示例）

### `stat weights by rarity`

**标题**：stat weights by rarity

[stat weights by rarity]
	0.4	0.7	1	1.25	1.4	1.1
[/stat weights by rarity]
控制强化附加的无视攻击（物理，魔法）比率，
6个数值对应[普通]-[高级]-[稀有]-[神器]-[史诗]-[异界（勇者）]6种类型，
例如修改第一个数值0.4改1.4，相应的游戏里强化[普通]级装备的无视攻击也会提高
同理控制增幅的路径{ etc/amplifyupgrade.etc }也有这个标签，对应增幅附加的四维

（无示例）

### `stone`

**标题**：异常效果

异常效果：石化

（无示例）

### `streetfighter`

**标题**：街霸

（无示例）

### `striker`

**标题**：散打

（无示例）

### `stun`

**标题**：异常效果

异常效果：眩晕

（无示例）

### `summoner`

**标题**：召唤师

（无示例）

### `SUPERARMOR`

**标题**：霸体

霸体：超级护甲

（无示例）

### `support`

**标题**：装备

装备：护石

（无示例）

### `swordman`

**标题**：男鬼剑士

男鬼剑士

该词条位于导师技能商店内时，代表这是男鬼剑专属技能，比如里鬼剑术、血之狂暴等等

（无示例）

### `table`

**标题**：强化/增幅属性（从左到右）

强化/增幅属性（从左到右）

1、
2、
3、
4、
5、
6、
7、概率 [计算公式]：(100000-X) / 100000
    （人话就是数字越小成功率越大，设置0就是100%成功）
8、失败时（1保级  2降级  3损坏）
9、保级时：写0
      降级时：写多少就掉多少级
      损坏时：写0
10、需求材料编号
11、需求材料消耗数量
12、
13、
14、
15、
16、
17、

（无示例）

### `tau`

**标题**：牛头族

（无示例）

### `think term`

**标题**：思考时间（1000 = 1秒）

[think term]思考时间（1000 = 1秒）
//在各种场景下做出对策的反应时间

与攻击延迟[attack delay]差不多

（无示例）

### `time sand`

**标题**：导师技能商店（或许是）

（无示例）

### `title name`

**标题**：装备

装备：称号

（无示例）

### `upgrade item`

**标题**：强化装备

强化装备

凯丽姐的强化功能

（无示例）

### `url hyperlink`

**标题**：URL超级链接

（无示例）

### `use effect explain`

**标题**：道具自带的使用效果介绍开关

道具自带的使用效果介绍开关

//隐藏或显示都不影响实际使用
改为0隐藏          改为1显示

隐藏过后就可以用下方这个标签自己编辑道具效果的介绍文本

[explain]
	`（文本）`

（无示例）

### `use zoom rate`

**标题**：副本内镜头缩放倍率

副本内镜头缩放倍率

1.0=100%

（无示例）

### `vision`

**标题**：视力

视力
此数值越高，越不容易因为距离过远而丢失目标

（无示例）

### `waist`

**标题**：装备

装备：腰带

（无示例）

### `warlike`

**标题**：攻击欲望

[warlike]攻击欲望
100=10%

（无示例）

### `weapon`

**标题**：装备

装备：武器

（无示例）

### `witch`

**标题**：魔道学者

（无示例）

### `world drop`

**标题**：全局掉落

[world drop]全局掉落
与使怪物专门掉落材料的独立掉落[item]不同，全局掉落是根据怪物等级来决定掉落材料的，
全局掉落分3部分组成：

A、怪物等级

B、左边为击杀该等级怪物之后随机掉落材料，
     右边为掉落材料的权重

C、-1（写-1为该等级收尾）

（无示例）

### `wrist`

**标题**：装备

装备：手环

（无示例）
